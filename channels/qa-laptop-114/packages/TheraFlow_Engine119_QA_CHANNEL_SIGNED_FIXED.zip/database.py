"""Local bootstrap backup/restore proof and guarded SQL prerequisite transition.

Only backup clones are restored. There is deliberately NO source-DB restore API.
The existing 1.1.4 control schema must already exist; this does not bootstrap an
unknown database or grant privileges. Calls require native host authorization.
"""
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys

from core import BootstrapError, save, sha


class Database:
    def __init__(self,bundle,work,profile):
        self.bundle=Path(bundle);self.work=Path(work);self.profile=profile
        sys.path.insert(0,str(self.bundle/'verifier-runtime'))
        from updates.updater import recovery_safety, maintenance
        self.safety=recovery_safety;self.maintenance=maintenance
        if not Path(recovery_safety.__file__).resolve().is_relative_to(self.bundle.resolve()):
            raise BootstrapError('verifier_import_origin')
        self.plan=dict(session_id=profile['session_id'],backup_root=str(work),
            canonical_env_path=profile['canonical_env_path'],current_version='1.1.4',
            target_version='1.1.5',postgres_tools=profile['postgres_tools'])
        self.source=maintenance.database_for_plan(self.plan)
        self.verifier=recovery_safety._verifier_config(self.plan)
        if self.source['host']!='127.0.0.1':raise BootstrapError('source_not_explicit_loopback')

    def connect(self):return self.safety._connect(self.source)

    def identities(self):
        with closing(self.connect()) as conn:
            identity=self.safety._identity(conn)
            if identity['cluster']!=self.profile['source_cluster_id']:raise BootstrapError('source_cluster_mismatch')
            if identity['database']!=self.profile['source_database']:raise BootstrapError('source_database_mismatch')
        with closing(self.safety._connect(dict(self.verifier,name='postgres'))) as conn:
            other=self.safety._identity(conn)
        if (other['cluster']!=self.verifier['cluster_id'] or other['cluster']==identity['cluster']
                or other['major']!=identity['major']):raise BootstrapError('restore_cluster_not_isolated')
        return identity

    def guard_bodies(self):
        sql=(self.bundle/'prerequisites/TheraFlow_1.1.5_RestoreGuard_v1.sql').read_text(encoding='utf-8')
        old=sql.split('$old_body$')[1].strip().replace('\r\n','\n')
        new=sql.split('$new_body$')[1].strip().replace('\r\n','\n')
        ddl=sql[sql.index('CREATE OR REPLACE FUNCTION'):sql.rindex('COMMIT;')]
        return old,new,ddl

    def check_control(self,cur,allow_owned=False):
        cur.execute("SELECT to_regprocedure('tf_update_control.guard_ddl()') IS NOT NULL")
        if not cur.fetchone()[0]:raise BootstrapError('maintenance_bootstrap_missing')
        cur.execute("""SELECT prosrc,prosecdef,proconfig,prorettype='event_trigger'::regtype
          FROM pg_proc WHERE oid='tf_update_control.guard_ddl()'::regprocedure""")
        body,secure,config,returns=cur.fetchone()
        if (body.strip().replace('\r\n','\n') not in self.guard_bodies()[:2] or not secure
                or config!=['search_path=pg_catalog'] or not returns):raise BootstrapError('unknown_sql_guard')
        cur.execute("""SELECT count(*) FROM pg_event_trigger WHERE evtenabled='O' AND
          ((evtname='tf_maintenance_ddl' AND evtfoid='tf_update_control.guard_ddl()'::regprocedure)
          OR (evtname='tf_maintenance_new_tables' AND evtfoid=to_regprocedure('tf_update_control.guard_new_tables()')))""")
        if cur.fetchone()[0]!=2:raise BootstrapError('maintenance_triggers_missing')
        cur.execute('SELECT session_id,active FROM tf_update_control.barrier WHERE singleton')
        row=cur.fetchone()
        if row and row[1] and not (allow_owned and row[0]==self.plan['session_id']):
            raise BootstrapError('another_maintenance_window')
        cur.execute("SELECT nspname FROM pg_namespace WHERE nspname NOT IN ('public','tf_update_control','information_schema') AND nspname NOT LIKE 'pg_%%'")
        if cur.fetchall():raise BootstrapError('nonstandard_source_schema')

    def preflight(self):
        self.identities()
        with closing(self.connect()) as conn,conn,conn.cursor() as cur:
            cur.execute('SET TRANSACTION READ ONLY');self.check_control(cur)
            fingerprint=self.safety._fingerprint(conn)
        expected=json.loads((self.bundle/'updater-files/updates/updater/baseline_114_migrations.json').read_text())
        if [r for r in fingerprint['migrations'] if r[0] in ('patients','updates')]!=expected:
            raise BootstrapError('source_not_114_schema')

    def dump(self,name,schema=None):
        command=[self.plan['postgres_tools']['pg_dump'],'--format=custom','--no-password',
                 '--host','127.0.0.1','--port',str(self.source['port']),
                 '--username',self.source['user'],'--dbname',self.source['name'],
                 '--file',str(self.work/name)]
        if schema:command+=['--schema',schema]
        env={k:os.environ[k] for k in ('SystemRoot','WINDIR','PATH','TEMP','TMP') if k in os.environ}
        env.update(PGPASSWORD=self.source['password'],PGPASSFILE=str(self.work/'absent-pgpass'),
                   PGSERVICEFILE=str(self.work/'absent-pgservice'),PGOPTIONS='-c statement_timeout=900000')
        result=subprocess.run(command,env=env,capture_output=True,timeout=900,
                              creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode:raise BootstrapError('bootstrap_backup_failed')
        check=subprocess.run([self.plan['postgres_tools']['pg_restore'],'--list',str(self.work/name)],
                             env=env,capture_output=True,timeout=120,
                             creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if check.returncode:raise BootstrapError('bootstrap_backup_invalid')

    def prepare(self,manifest):
        from psycopg2 import sql
        self.identities()
        for root in (Path(self.profile['media_root']),Path(self.plan['canonical_env_path']).parent):
            for directory,folders,files in os.walk(root,followlinks=False):
                for name in [directory,*[str(Path(directory)/n) for n in folders+files]]:
                    item=Path(name)
                    if item.is_symlink() or getattr(item,'is_junction',lambda:False)():
                        raise BootstrapError('backup_reparse_point_refused')
        # All writers and table DDL are drained/blocked while the backup proof
        # is created. SHARE locks allow pg_dump and independent read verification.
        # No source SQL function/table/row is changed before the round trips pass.
        with closing(self.connect()) as conn,conn,conn.cursor() as cur:
            cur.execute("SET LOCAL lock_timeout='15s'")
            cur.execute('SELECT pg_advisory_xact_lock(19483117,hashtext(current_database()))')
            cur.execute('SELECT session_id,active FROM tf_update_control.barrier FOR UPDATE')
            self.check_control(cur)
            cur.execute("SELECT count(*) FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid() AND backend_type='client backend'")
            if cur.fetchone()[0]:raise BootstrapError('other_database_clients_present')
            cur.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename")
            tables=[r[0] for r in cur.fetchall()]
            if not tables:raise BootstrapError('business_schema_missing')
            cur.execute(sql.SQL('LOCK TABLE {} IN SHARE MODE').format(sql.SQL(',').join(sql.Identifier('public',t) for t in tables)))
            # Existing business triggers must cover every guarded table. Unknown
            # bootstrap infrastructure is refused, never silently repaired.
            for table in (t for t in tables if t not in self.maintenance.EXCLUDED):
                cur.execute("""SELECT count(*) FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid
                 JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname=%s
                 AND t.tgname='tf_maintenance_guard' AND t.tgenabled='O'
                 AND t.tgfoid='tf_update_control.block_business_write()'::regprocedure""",(table,))
                if cur.fetchone()[0]!=1:raise BootstrapError('business_write_guard_missing')
            self.dump('theraflow_database_full.dump')
            self.dump('theraflow_database.dump','public')
            identity,fingerprint,restored=self.safety._database_roundtrip(self.plan,self.verifier)
            media_archive,media=self.safety._media_roundtrip(Path(self.profile['media_root']),self.work)
            config_dir=self.work/'configuration-proof';config_dir.mkdir()
            config_archive,config=self.safety._media_roundtrip(Path(self.plan['canonical_env_path']).parent,config_dir)
            proof=dict(protocol='bootstrap119-pre-sql-restore-v1',manifest_sha256=sha(self.bundle/'bootstrap-manifest.json'),
                session_id=self.plan['session_id'],identity=identity,fingerprint=fingerprint,
                restored=restored,media=media,media_sha256=sha(media_archive),
                configuration=config,configuration_sha256=sha(config_archive),business_rows_changed=False)
            save(self.work/'backup-restore-proof.json',proof)
            if self.safety._fingerprint(conn)!=fingerprint:raise BootstrapError('source_changed_before_sql_guard')
            # Apply the exact vetted prerequisite while the old barrier is inactive
            # and SHARE locks protect the proof. The regular prerequisite requires
            # this inactive state too. Preserve function ownership/grants.
            cur.execute(self.guard_bodies()[2])
            token=self.maintenance.key(self.plan,create=True)
            cur.execute("""INSERT INTO tf_update_control.barrier(singleton,session_id,key_hash,active)
              VALUES(true,%s,%s,true) ON CONFLICT(singleton) DO UPDATE SET session_id=excluded.session_id,
              key_hash=excluded.key_hash,active=true,started_at=clock_timestamp(),finished_at=NULL,outcome=NULL
              RETURNING started_at::text""",(self.plan['session_id'],hashlib.md5(token.encode()).hexdigest()))
            epoch=cur.fetchone()[0]
            # Save commit intent before committing: recovery checks the live row.
            save(self.work/'window.json',dict(session_id=self.plan['session_id'],epoch=epoch,source=identity))
        self.assert_window()

    def assert_window(self):
        expected=json.loads((self.work/'window.json').read_text())
        self.identities()
        with closing(self.connect()) as conn,conn,conn.cursor() as cur:
            self.check_control(cur,allow_owned=True)
            cur.execute('SELECT session_id,key_hash,active,started_at::text FROM tf_update_control.barrier WHERE singleton')
            row=cur.fetchone()
            if (not row or row!=(self.plan['session_id'],hashlib.md5(self.maintenance.key(self.plan).encode()).hexdigest(),True,expected['epoch'])):
                raise BootstrapError('bootstrap_window_changed')

    def restore_previous_guard(self):
        # A completed engine rollback restores the 1.1.8 SQL prerequisite only
        # after the application is back at 1.1.4 and inside the NEW window.
        self.assert_window()
        old=self.guard_bodies()[0]
        with closing(self.connect()) as conn,conn,conn.cursor() as cur:
            cur.execute('SET LOCAL lock_timeout=\'15s\'')
            cur.execute('SET LOCAL theraflow.update_key = %s',(self.maintenance.key(self.plan),))
            cur.execute('SELECT session_id,active FROM tf_update_control.barrier WHERE singleton FOR SHARE')
            if cur.fetchone()!=(self.plan['session_id'],True):raise BootstrapError('bootstrap_window_changed')
            self.check_control(cur,allow_owned=True)
            cur.execute('CREATE OR REPLACE FUNCTION tf_update_control.guard_ddl() RETURNS event_trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $guard$'+old+'$guard$')
        self.assert_previous_guard()

    def assert_previous_guard(self):
        with closing(self.connect()) as conn,conn,conn.cursor() as cur:
            self.check_control(cur,allow_owned=True)
            cur.execute("SELECT prosrc FROM pg_proc WHERE oid='tf_update_control.guard_ddl()'::regprocedure")
            if cur.fetchone()[0].strip().replace('\r\n','\n')!=self.guard_bodies()[0]:
                raise BootstrapError('old_guard_restore_failed')

    def assert_rollback_complete(self):
        self.assert_previous_guard()
        expected=json.loads((self.work/'window.json').read_text())
        with closing(self.connect()) as conn,conn,conn.cursor() as cur:
            cur.execute('SELECT session_id,key_hash,active,started_at::text,outcome FROM tf_update_control.barrier WHERE singleton')
            row=cur.fetchone()
            if row!=(self.plan['session_id'],hashlib.md5(self.maintenance.key(self.plan).encode()).hexdigest(),
                     False,expected['epoch'],'verified_engine118_rollback'):
                raise BootstrapError('engine_rollback_terminal_unverified')

    def release(self,outcome='verified_bootstrap119'):
        if outcome not in ('verified_bootstrap119','verified_engine118_rollback'):
            raise BootstrapError('invalid_bootstrap_outcome')
        # Safe for lost-ACK retries: never BEGIN/reopen maintenance. A different
        # epoch/session is a hard stop; absent window means no SQL was committed.
        marker=self.work/'window.json'
        if not marker.exists():return
        expected=json.loads(marker.read_text())
        self.identities()
        with closing(self.connect()) as conn,conn,conn.cursor() as cur:
            cur.execute('SELECT session_id,key_hash,active,started_at::text,outcome FROM tf_update_control.barrier WHERE singleton FOR UPDATE')
            row=cur.fetchone()
            if not row or row[0]!=self.plan['session_id']:
                # A crash before the transaction committed is recoverable, but
                # another active session must never be opened or released.
                if row and row[2]:raise BootstrapError('foreign_window')
                return
            if row[1]!=hashlib.md5(self.maintenance.key(self.plan).encode()).hexdigest() or row[3]!=expected['epoch']:
                raise BootstrapError('bootstrap_window_changed')
            if row[2]:
                cur.execute("UPDATE tf_update_control.barrier SET active=false,finished_at=clock_timestamp(),outcome=%s WHERE singleton",(outcome,))
            elif row[4]!=outcome:
                raise BootstrapError('bootstrap_terminal_outcome_changed')
