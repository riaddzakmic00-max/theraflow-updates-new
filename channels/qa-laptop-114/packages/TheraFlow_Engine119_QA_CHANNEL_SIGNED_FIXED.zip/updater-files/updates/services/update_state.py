import json
import os
import shutil
from pathlib import Path

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from updates.models import UpdateHistory, UpdateSession
from theraflow.version import __version__

from .update_paths import get_update_paths
from .manifest_identity import same_manifest


class UpdateLockedError(RuntimeError):
    pass


SAFE_MANIFEST_FIELDS = (
    "version", "release_date", "mandatory", "sha256", "size_bytes",
    "min_supported_version", "release_notes", "download_url",
    "minimum_repair_build", "payload_repair_build", "payload_updater_version",
)


def sanitized_manifest(manifest):
    from .update_checker import validate_manifest
    if isinstance(manifest, dict) and 'signed_manifest' in manifest:
        manifest = manifest['signed_manifest']
    return validate_manifest(manifest)


def state_payload(session):
    return {
        "session_id": str(session.pk),
        "target_version": session.target_version,
        "current_version": __version__,
        "status": session.status,
        "is_active": session.is_active,
        "package_path": session.package_path,
        "package_sha256": session.package_sha256,
        "backup_directory": session.backup_directory,
        "database_backup_path": session.database_backup_path,
        "config_backup_path": session.config_backup_path,
        "staging_directory": session.staging_directory,
        "install_plan_path": session.install_plan_path,
        "install_plan_sha256": session.install_plan_sha256,
        "application_root": str(Path(settings.BASE_DIR).resolve()),
        "data_root": str(get_update_paths().data_root),
        "service_name": settings.THERAFLOW_SERVICE_NAME,
        "health_check_url": settings.THERAFLOW_HEALTH_CHECK_URL,
        "manifest_snapshot": session.manifest_snapshot,
        "database_backup_validated": session.database_backup_validated,
        "staging_validated": session.staging_validated,
        "error_message": session.error_message,
        "error_code": session.error_code,
        "prepared_at": session.prepared_at.isoformat() if session.prepared_at else None,
        "updated_at": session.updated_at.isoformat() if session.updated_at else timezone.now().isoformat(),
        "updater_pid": session.updater_pid,
        "updater_request_id": (
            str(session.updater_request_id) if session.updater_request_id else None
        ),
        "updater_request_created_at": (
            session.updater_request_created_at.isoformat()
            if session.updater_request_created_at
            else None
        ),
        "install_started_at": session.install_started_at.isoformat() if session.install_started_at else None,
        "install_completed_at": session.install_completed_at.isoformat() if session.install_completed_at else None,
    }


def write_state_file(session):
    root = get_update_paths().sessions
    destination = root / f"{session.pk}.json"
    temporary = destination.with_suffix(".json.tmp")
    payload = state_payload(session)
    try:
        existing = json.loads(destination.read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError):
        existing = None
    if isinstance(existing, dict) and existing.get("session_id") == str(session.pk):
        # Executor/service fields which are not database columns remain durable
        # across a later web-process save.  DB-backed identity fields below
        # still win, so stale status/request data cannot revive a session.
        existing.update(payload)
        payload = existing
    temporary.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    os.replace(temporary, destination)
    return destination


def save_session(session, update_fields=None):
    fields = list(update_fields or [])
    if fields and "updated_at" not in fields:
        fields.append("updated_at")
    session.save(update_fields=fields or None)
    write_state_file(session)
    return session


def _remove_superseded_artifacts(session):
    """Remove only disposable package/staging data; preserve backup and audit."""
    paths = get_update_paths()
    for value, parent in (
        (session.package_path, paths.packages),
        (session.staging_directory, paths.staging),
    ):
        if not value:
            continue
        candidate = Path(value).resolve()
        root = parent.resolve()
        if candidate.parent != root or candidate.is_symlink():
            continue
        if candidate.is_dir():
            shutil.rmtree(candidate)
        elif candidate.is_file():
            candidate.unlink()


@transaction.atomic
def register_downloaded_package(manifest, package_path, user=None):
    manifest = sanitized_manifest(manifest)
    active = UpdateSession.objects.select_for_update().filter(is_active=True).first()
    version = str(manifest["version"])
    if active:
        if active.status not in UpdateSession.ACTIVE_STATUSES:
            # Service responses and dead workers are reconciled before deciding
            # whether a downloaded package may reuse an active row.
            from .crash_recovery import reconcile_session

            reconcile_session(active)
            active.refresh_from_db()
            if not active.is_active:
                active = None
        if active and active.status not in UpdateSession.ACTIVE_STATUSES:
            raise UpdateLockedError(
                "Prethodni update zahtjev je još aktivan. Sačekajte završetak ili pregledajte prikazanu grešku."
            )
    if active:
        if same_manifest(active.manifest_snapshot, manifest):
            active.package_path = str(Path(package_path).resolve())
            active.package_sha256 = str(manifest["sha256"]).lower()
            active.prepared_by = user
            return save_session(active, ["package_path", "package_sha256", "prepared_by"])
        active.status = UpdateSession.SUPERSEDED
        active.is_active = False
        active.error_message = "Session je zamijenjen drugim manifestom (verzija + SHA-256 + URL)."
        save_session(active, ["status", "is_active", "error_message"])
        UpdateHistory.objects.update_or_create(
            session=active,
            defaults={
                "source_version": __version__, "target_version": active.target_version,
                "started_at": active.created_at, "completed_at": timezone.now(),
                "status": UpdateHistory.SUPERSEDED,
                "initiated_by": active.prepared_by,
                "package_sha256": active.package_sha256,
                "safe_error_summary": active.error_message,
                "final_active_version": __version__,
            },
        )
        _remove_superseded_artifacts(active)
    session = UpdateSession.objects.create(
        target_version=version,
        status=UpdateSession.PACKAGE_DOWNLOADED,
        package_path=str(Path(package_path).resolve()),
        package_sha256=str(manifest["sha256"]).lower(),
        manifest_snapshot=sanitized_manifest(manifest),
        prepared_by=user,
    )
    write_state_file(session)
    return session
