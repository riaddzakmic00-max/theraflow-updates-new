import hashlib
import json


def manifest_identity(manifest):
    return (
        str(manifest.get("version", "")).strip(),
        str(manifest.get("sha256", "")).strip().lower(),
        str(manifest.get("download_url", "")).strip(),
    )


def manifest_fingerprint(manifest):
    payload = json.dumps(manifest_identity(manifest), separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def same_manifest(left, right):
    if left.get('release_signature') or right.get('release_signature'):
        from theraflow.release_signing import canonical_manifest_bytes
        return canonical_manifest_bytes(left) == canonical_manifest_bytes(right) and left.get('release_signature') == right.get('release_signature')
    return manifest_identity(left) == manifest_identity(right)
