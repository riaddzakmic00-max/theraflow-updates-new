import json
import logging
import os
import shutil
import sys
import zipfile
from contextlib import contextmanager
from pathlib import Path

from django.conf import settings
from django.utils import timezone

from dashboard.postgres_backup import BackupError, executable_path
from theraflow.environment import canonical_env_path
from theraflow.version import __version__
from updates.models import UpdateSession

from .package_staging import (
    PACKAGE_COMPATIBILITY_STEP_LABEL,
    PACKAGE_COMPATIBILITY_USER_MESSAGE,
    PackageValidationError,
    StagingError,
    create_install_plan,
    is_package_compatibility_error,
    revalidate_package,
    safe_extract,
    validate_staging,
)
from .preparation_backup import ConfigBackupError, create_config_backup, create_database_backup, process_identity, sha256_file
from .update_paths import get_update_paths
from .update_state import save_session
from updates.updater.state_writer import trace_update_step, write_state
from updates.updater.plan_loader import load_and_validate
from updates.updater.recovery_safety import RecoverySafetyError


logger = logging.getLogger(__name__)
PHASE3_RESERVE = 512 * 1024 * 1024
DATABASE_ESTIMATE = 256 * 1024 * 1024
CONFIG_ESTIMATE = 64 * 1024 * 1024
REQUIRED_PLAN_FIELDS = {
    "session_id", "current_version", "target_version", "application_root",
    "staging_root", "payload_root", "backup_root", "database_backup_path",
    "config_backup_path", "preserve_paths", "replace_paths", "delete_paths",
    "migration_required", "collectstatic_required", "service_name",
    "health_check_url", "created_at", "package_sha256", "package_manifest_sha256",
    "python_executable", "canonical_env_path", "plan_schema_version", "plan_hmac_sha256",
    "package_url", "manifest_identity", "backup_identity",
    "installed_repair_build", "installed_updater_version",
    "payload_repair_build", "payload_updater_version",
    "publisher_receipt",
}


class InsufficientSpaceError(RuntimeError):
    def __init__(self, required, available):
        self.required = int(required)
        self.available = int(available)
        super().__init__(f"Potrebno je približno {self.required} B, a dostupno je {self.available} B.")


class PreparationLockedError(RuntimeError):
    pass


class PrecheckError(RuntimeError):
    pass


def _application_size(root=None):
    root = Path(root or settings.BASE_DIR).resolve()
    excluded = {".git", ".venv", "backups", "logs", "media", "staticfiles", "data", "__pycache__", "node_modules"}
    total = 0
    for current, dirs, files in os.walk(root):
        dirs[:] = [name for name in dirs if name not in excluded]
        for name in files:
            try:
                total += (Path(current) / name).stat().st_size
            except OSError:
                continue
    return total


def estimate_required_space(package_path, application_root=None):
    package_path = Path(package_path)
    package_size = package_path.stat().st_size
    try:
        with zipfile.ZipFile(package_path) as archive:
            expanded_size = sum(item.file_size for item in archive.infolist())
    except (OSError, zipfile.BadZipFile):
        expanded_size = package_size * 4
    application_size = _application_size(application_root)
    return package_size + expanded_size + (application_size * 2) + DATABASE_ESTIMATE + CONFIG_ESTIMATE + PHASE3_RESERVE


def check_free_space(package_path, data_root=None, disk_usage=None, application_root=None):
    data_root = Path(data_root or get_update_paths().data_root)
    required = estimate_required_space(package_path, application_root)
    available = (disk_usage or shutil.disk_usage)(data_root).free
    logger.info("Update provjera prostora: potrebno=%s dostupno=%s.", required, available)
    if available < required:
        raise InsufficientSpaceError(required, available)
    return {"required_bytes": required, "available_bytes": available}


@contextmanager
def preparation_lock():
    lock_path = get_update_paths().sessions / "prepare.lock"
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(descriptor, str(os.getpid()).encode("ascii"))
        os.close(descriptor)
    except FileExistsError as exc:
        raise PreparationLockedError("Priprema ažuriranja je već u toku.") from exc
    try:
        yield lock_path
    finally:
        lock_path.unlink(missing_ok=True)


def _load_json(path, description):
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise PrecheckError(f"{description} nije validan.") from exc
    if not isinstance(value, dict):
        raise PrecheckError(f"{description} nije validan.")
    return value


def run_precheck(session, *, disk_usage=None, lock_owned=False, tool_resolver=None):
    package = revalidate_package(session)
    if not session.database_backup_validated:
        raise PrecheckError("Database backup nije validiran.")
    metadata = _load_json(Path(session.backup_directory) / "backup_metadata.json", "Database backup metadata")
    if metadata.get("validation") != "pg_restore_list_passed" or sha256_file(session.database_backup_path) != metadata.get("dump_sha256"):
        raise PrecheckError("Database backup validacija nije potvrđena.")
    if not Path(session.config_backup_path).is_file():
        raise PrecheckError("Backup konfiguracije nije pronađen.")
    if not session.staging_validated or not Path(session.staging_directory).is_dir():
        raise PrecheckError("Staging paket nije validiran.")
    plan = _load_json(session.install_plan_path, "Install plan")
    if REQUIRED_PLAN_FIELDS - plan.keys():
        raise PrecheckError("Install plan nema sva obavezna polja.")
    if plan.get("current_version") != __version__:
        raise PrecheckError("Aktivna verzija se ne podudara s install planom.")
    if plan.get("session_id") != str(session.pk) or plan.get("target_version") != session.target_version:
        raise PrecheckError("Install plan ne odgovara update sessionu.")
    application_root = Path(settings.BASE_DIR).resolve()
    trusted_paths = {
        "application_root": application_root,
        "staging_root": Path(session.staging_directory).resolve(),
        "backup_root": Path(session.backup_directory).resolve(),
        "database_backup_path": Path(session.database_backup_path).resolve(),
        "config_backup_path": Path(session.config_backup_path).resolve(),
    }
    if any(Path(plan[key]).resolve() != expected for key, expected in trusted_paths.items()):
        raise PrecheckError("Install plan sadrži neočekivanu serversku putanju.")
    if plan.get("service_name") != settings.THERAFLOW_SERVICE_NAME or plan.get("health_check_url") != settings.THERAFLOW_HEALTH_CHECK_URL:
        raise PrecheckError("Install plan ne odgovara serverskoj konfiguraciji.")
    if plan.get("package_sha256") != session.package_sha256:
        raise PrecheckError("Install plan nema očekivani SHA-256 paketa.")
    package_manifest_path = Path(session.staging_directory) / "theraflow-update.json"
    if not package_manifest_path.is_file() or sha256_file(package_manifest_path) != plan.get("package_manifest_sha256"):
        raise PrecheckError("Package manifest je izmijenjen nakon validacije.")
    if not application_root.is_dir() or not (application_root / "manage.py").is_file():
        raise PrecheckError("Aktivni application root ili manage.py nije pronađen.")
    payload_root = Path(plan["payload_root"]).resolve()
    if Path(session.staging_directory).resolve() not in payload_root.parents or not (payload_root / "manage.py").is_file():
        raise PrecheckError("Novi manage.py nije pronađen.")
    if not settings.THERAFLOW_SERVICE_NAME:
        raise PrecheckError("Naziv TheraFlow servisa nije konfigurisan.")
    resolver = tool_resolver or executable_path
    resolver("pg_dump")
    resolver("pg_restore")
    if not Path(sys.executable).is_file():
        raise PrecheckError("Python runtime nije pronađen.")
    if not lock_owned and (get_update_paths().sessions / "prepare.lock").exists():
        raise PrecheckError("Drugi update lock je aktivan.")
    check_free_space(package, disk_usage=disk_usage, application_root=application_root)
    return plan


def _transition(session, status, **values):
    session.status = status
    fields = ["status"]
    for key, value in values.items():
        setattr(session, key, value)
        fields.append(key)
    return save_session(session, fields)


def _failure(session, status, message, *, error_code=""):
    session.is_active = False
    return _transition(
        session,
        status,
        is_active=False,
        error_message=message[:1000],
        error_code=str(error_code or "")[:80],
    )


def _package_validation_failure(session, exc):
    """Persist a safe UI failure while retaining diagnostics only in logs."""
    compatibility_failure = is_package_compatibility_error(exc)
    error_code = str(getattr(exc, "code", "PACKAGE_VALIDATION_FAILED"))
    message = (
        PACKAGE_COMPATIBILITY_USER_MESSAGE
        if compatibility_failure
        else str(exc)
    )
    step_label = (
        PACKAGE_COMPATIBILITY_STEP_LABEL
        if compatibility_failure
        else "Provjera paketa"
    )
    logger.warning(
        "UPDATE PACKAGE VALIDATION FAIL session=%s step=%s error_code=%s "
        "technical_detail=%s",
        session.pk,
        step_label,
        error_code,
        str(exc),
    )
    _failure(
        session,
        UpdateSession.VALIDATION_FAILED,
        message,
        error_code=error_code,
    )
    state_path = get_update_paths().sessions / f"{session.pk}.json"
    write_state(
        state_path,
        status=UpdateSession.VALIDATION_FAILED,
        is_active=False,
        current_step=step_label,
        failed_step="package_compatibility" if compatibility_failure else "package_validation",
        failed_step_label=step_label,
        error_code=error_code,
        error_message=message,
    )
    return _result(session, "validation_failed", message)


def _result(session, status=None, message=""):
    return {
        "status": status or session.status,
        "message": message,
        "session_id": str(session.pk),
        "current_version": __version__,
        "target_version": session.target_version,
        "backup_time": session.prepared_at.isoformat() if session.prepared_at else None,
        "backup_location": Path(session.backup_directory).name if session.backup_directory else None,
        "database_validation": "pg_restore_list_passed" if session.database_backup_validated else "not_validated",
        "staging_validation": "validated" if session.staging_validated else "not_validated",
    }


def _prepare_update_impl(session, *, disk_usage=None):
    if not isinstance(session, UpdateSession) or not session.is_active or session.status != UpdateSession.PACKAGE_DOWNLOADED:
        return _result(session, "validation_failed", "Update session nije spreman za pripremu.")
    identity = process_identity()
    resolved_env_path = canonical_env_path()
    logger.info(
        "UPDATE PHASE elevation_gate resolved_env_path=%s process_identity=%s elevated=%s authorized=%s pid=%s",
        resolved_env_path,
        identity["identity"], identity["elevated"], identity["authorized"], identity["pid"],
    )
    if getattr(settings, "PRODUCTION_MODE", False) and os.name == "nt" and not identity["authorized"]:
        message = (
            "Update priprema zahtijeva administrator/LocalSystem identitet. "
            "Kanonski .env nije provjeravan; prvo pokrenite repair installer i potvrdite UAC."
        )
        logger.error(
            "UPDATE PHASE elevation_gate FAIL process_identity=%s exception_type=ElevationRequired",
            identity["identity"],
        )
        trace_update_step(
            "Elevation gate", "FAIL", session_id=session.pk,
            function_name="prepare_update",
            paths={"canonical_env": resolved_env_path},
            message=(f"process_identity={identity['identity']} elevated={identity['elevated']} "
                     f"authorized=false exception_type=ElevationRequired"),
            exit_code=1,
        )
        return _result(session, "elevation_required", message)
    trace_update_step(
        "Elevation gate", "PASS", session_id=session.pk,
        function_name="prepare_update",
        paths={"canonical_env": resolved_env_path},
        message=(f"process_identity={identity['identity']} elevated={identity['elevated']} "
                 f"authorized=true exception_type=NONE"),
        exit_code=0,
    )
    try:
        with preparation_lock():
            logger.info("Početak pripreme update sessiona %s.", session.pk)
            try:
                package = revalidate_package(session)
            except PackageValidationError as exc:
                result = _package_validation_failure(session, exc)
                trace_update_step(
                    PACKAGE_COMPATIBILITY_STEP_LABEL
                    if is_package_compatibility_error(exc)
                    else 3,
                    "FAIL",
                    session_id=session.pk,
                    function_name="prepare_update",
                    exception=exc,
                    exit_code=1,
                )
                return result
            try:
                check_free_space(package, disk_usage=disk_usage)
            except InsufficientSpaceError as exc:
                _failure(session, UpdateSession.ERROR, str(exc))
                result = _result(session, "insufficient_space", str(exc))
                result.update({"required_bytes": exc.required, "available_bytes": exc.available})
                return result

            timestamp = timezone.localtime().strftime("%Y%m%d_%H%M%S")
            paths = get_update_paths()
            backup_root = paths.backups / f"{timestamp}_v{session.target_version}_{str(session.pk)[:8]}"
            staging_root = paths.staging / f"{session.target_version}_{session.pk}"
            backup_root.mkdir(parents=False, exist_ok=False)
            from updates.updater.maintenance import django_begin
            django_begin(session, backup_root)
            _transition(session, UpdateSession.BACKUP_IN_PROGRESS, backup_directory=str(backup_root))
            dump_path = backup_root / "theraflow_database.dump"
            trace_update_step(5, "START", session_id=session.pk, function_name="prepare_update", paths={"backup_root": backup_root, "database_backup": dump_path})
            try:
                logger.info("STEP START code=database_backup session=%s", session.pk)
                database_path, _metadata = create_database_backup(backup_root, __version__, session.target_version)
                metadata_path = backup_root / "backup_metadata.json"
                if metadata_path.is_file():
                    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
                    metadata["session_id"] = str(session.pk)
                    metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
                session.database_backup_validated = True
                session.database_backup_path = str(database_path)
                save_session(session, ["database_backup_validated", "database_backup_path"])
                logger.info("STEP COMPLETE code=database_backup session=%s", session.pk)
                logger.info("STEP START code=config_backup session=%s", session.pk)
                config_path, _manifest_path, _manifest = create_config_backup(backup_root)
                if Path(_manifest_path).is_file():
                    config_manifest = json.loads(Path(_manifest_path).read_text(encoding="utf-8"))
                    config_manifest["session_id"] = str(session.pk)
                    Path(_manifest_path).write_text(json.dumps(config_manifest, indent=2, ensure_ascii=False), encoding="utf-8")
                session.config_backup_path = str(config_path)
                _transition(session, UpdateSession.BACKUP_COMPLETED, config_backup_path=str(config_path))
                logger.info("STEP COMPLETE code=config_backup session=%s", session.pk)
                trace_update_step(5, "PASS", session_id=session.pk, function_name="prepare_update", paths={"backup_root": backup_root, "database_backup": database_path, "config_backup": config_path}, exit_code=0)
            except (BackupError, ConfigBackupError, OSError) as exc:
                if not session.database_backup_validated:
                    dump_path.unlink(missing_ok=True)
                _failure(session, UpdateSession.BACKUP_FAILED, str(exc))
                logger.exception(
                    "STEP FAIL code=preparation_backup session=%s error_type=%s exception_type=%s error_code=%s resolved_path=%s",
                    session.pk,
                    type(exc).__name__,
                    getattr(exc, "exception_type", type(exc).__name__),
                    getattr(exc, "code", "backup_io_error"),
                    getattr(exc, "path", "NONE"),
                )
                trace_update_step(
                    5, "FAIL", session_id=session.pk, function_name="prepare_update",
                    paths={"backup_root": backup_root, "database_backup": dump_path, "canonical_env": resolved_env_path},
                    message=(f"exception_type={getattr(exc, 'exception_type', type(exc).__name__)} "
                             f"error_code={getattr(exc, 'code', 'backup_io_error')}"),
                    exception=exc, exit_code=getattr(exc, "returncode", 1),
                )
                return _result(session, "backup_failed", str(exc))

            _transition(session, UpdateSession.STAGING_IN_PROGRESS, staging_directory=str(staging_root))
            trace_update_step(7, "START", session_id=session.pk, function_name="prepare_update", paths={"package": package, "staging_root": staging_root})
            try:
                logger.info("STEP START code=staging session=%s", session.pk)
                logger.info("Početak staging procesa za update session %s.", session.pk)
                safe_extract(package, staging_root)
                package_manifest, manifest_path, payload_root = validate_staging(staging_root, session.target_version)
                session.staging_validated = True
                save_session(session, ["staging_validated"])
                plan_path, _plan = create_install_plan(
                    session, package_manifest, manifest_path, payload_root,
                    session.database_backup_path, session.config_backup_path,
                    postgres_tools={name: executable_path(name) for name in ("pg_dump", "pg_restore", "psql")},
                )
                session.install_plan_path = str(plan_path)
                session.install_plan_sha256 = sha256_file(plan_path)
                save_session(session, ["install_plan_path", "install_plan_sha256"])
                run_precheck(session, disk_usage=disk_usage, lock_owned=True)
                # Re-open through the same validator used by the independent
                # LocalSystem worker before READY_TO_INSTALL is durable.
                load_and_validate(plan_path)
                logger.info("STEP COMPLETE code=staging session=%s", session.pk)
                logger.info("Staging i završni precheck za update session %s su uspješni.", session.pk)
                trace_update_step(7, "PASS", session_id=session.pk, function_name="prepare_update", paths={"package": package, "staging_root": staging_root, "payload_root": payload_root, "install_plan": plan_path}, exit_code=0)
            except InsufficientSpaceError as exc:
                shutil.rmtree(staging_root, ignore_errors=True)
                _failure(session, UpdateSession.STAGING_FAILED, str(exc))
                result = _result(session, "insufficient_space", str(exc))
                result.update({"required_bytes": exc.required, "available_bytes": exc.available})
                trace_update_step(7, "FAIL", session_id=session.pk, function_name="prepare_update", paths={"package": package, "staging_root": staging_root}, exception=exc, exit_code=1)
                return result
            except PackageValidationError as exc:
                shutil.rmtree(staging_root, ignore_errors=True)
                result = _package_validation_failure(session, exc)
                trace_update_step(
                    PACKAGE_COMPATIBILITY_STEP_LABEL
                    if is_package_compatibility_error(exc)
                    else 7,
                    "FAIL",
                    session_id=session.pk,
                    function_name="prepare_update",
                    paths={"package": package, "staging_root": staging_root},
                    exception=exc,
                    exit_code=1,
                )
                return result
            except (StagingError, PrecheckError, BackupError, OSError, ValueError) as exc:
                shutil.rmtree(staging_root, ignore_errors=True)
                _failure(session, UpdateSession.STAGING_FAILED, str(exc))
                logger.warning("Update staging/precheck nije uspio: %s", type(exc).__name__)
                trace_update_step(7, "FAIL", session_id=session.pk, function_name="prepare_update", paths={"package": package, "staging_root": staging_root}, exception=exc, exit_code=getattr(exc, "returncode", 1))
                return _result(session, "staging_failed", str(exc))

            prepared_at = timezone.now()
            _transition(
                session,
                UpdateSession.READY_TO_INSTALL,
                prepared_at=prepared_at,
                error_message="",
            )
            logger.info("Update session %s je ready_to_install.", session.pk)
            return _result(session, "ready_to_install", "Ažuriranje je spremno za instalaciju.")
    except RecoverySafetyError as exc:
        if isinstance(session, UpdateSession) and session.pk:
            _failure(session, UpdateSession.ERROR, str(exc), error_code=exc.code)
        return _result(session, exc.code, str(exc))
    except PreparationLockedError as exc:
        trace_update_step(5, "FAIL", session_id=getattr(session, "pk", "none"), function_name="prepare_update", exception=exc, exit_code=1)
        return _result(session, "locked", str(exc))
    except Exception as exc:
        trace_update_step(5, "FAIL", session_id=getattr(session, "pk", "none"), function_name="prepare_update", exception=exc, exit_code=getattr(exc, "returncode", 1))
        logger.exception("Neočekivana greška tokom pripreme update sessiona %s.", getattr(session, "pk", "unknown"))
        if isinstance(session, UpdateSession) and session.pk:
            _failure(session, UpdateSession.ERROR, "Priprema ažuriranja nije uspjela.")
        return _result(session, "error", "Priprema ažuriranja nije uspjela.")


def _recover_application_service(session):
    """Preparation never owns a stopped application service."""
    if not (getattr(settings, "PRODUCTION_MODE", False) and os.name == "nt"):
        return
    from updates.updater import service_manager

    identity = process_identity()
    if not identity["authorized"]:
        logger.warning(
            "UPDATE PHASE preparation_recovery SKIP process_identity=%s "
            "exception_type=ElevationRequired", identity["identity"],
        )
        return
    service_name = settings.THERAFLOW_SERVICE_NAME
    try:
        observed = service_manager.query(service_name)
        if observed["state"] != "RUNNING":
            service_manager.start(service_name)
        final = service_manager.query(service_name)
        if final["state"] != "RUNNING":
            raise service_manager.ServiceError(
                f"Servis nije vraćen u RUNNING stanje (state={final['state']})."
            )
        logger.info(
            "UPDATE PHASE preparation_recovery PASS service=%s state=%s "
            "process_identity=%s exception_type=NONE",
            service_name, final["state"], identity["identity"],
        )
    except Exception as exc:
        logger.exception(
            "UPDATE PHASE preparation_recovery FAIL service=%s "
            "process_identity=%s exception_type=%s",
            service_name, identity["identity"], type(exc).__name__,
        )
        trace_update_step(
            "Preparation service recovery", "FAIL",
            session_id=getattr(session, "pk", "none"),
            function_name="prepare_update", exception=exc, exit_code=1,
            message=f"process_identity={identity['identity']} exception_type={type(exc).__name__}",
        )
        raise


def prepare_update(session, *, disk_usage=None):
    try:
        return _prepare_update_impl(session, disk_usage=disk_usage)
    finally:
        _recover_application_service(session)
