"""Authenticated seal and fresh maintenance window for post-success rollback.

The pre-install backup may only replace current business data when the entire
post-install database and media still match the sealed successful state.
"""
from contextlib import closing
import hashlib
import hmac
import json
import os
from pathlib import Path

from . import maintenance, recovery_safety
from .plan_loader import read_version, sha256_file
from .plan_security import key_path_for_plan, load_service_key
from .state_writer import write_state

PROTOCOL = 'completed-rollback-seal-v1'


class CompletedRollbackError(RuntimeError):
    pass


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':')).encode('utf-8')


def _key(plan):
    return load_service_key(key_path_for_plan(plan['_plan_path']))


def _capture(plan):
    root = Path(plan['application_root'])
    if read_version(root/'theraflow/version.py') != plan['target_version']:
        raise CompletedRollbackError('Post-update version differs from approved target')
    with closing(recovery_safety._connect(maintenance.database_for_plan(plan))) as conn, conn:
        with conn.cursor() as cur:
            cur.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        identity = recovery_safety._identity(conn)
        fingerprint = recovery_safety._fingerprint(conn)
    media = recovery_safety._catalog(plan['media_root'])
    config = sha256_file(plan['canonical_env_path'])
    return dict(source_identity=identity, database=fingerprint, media=media,
                canonical_env_sha256=config, version=plan['target_version'])


def seal_success(plan):
    """Call after health and metadata checks, before the original barrier opens."""
    maintenance.assert_active(plan)
    window = recovery_safety.inspect_guard(plan)
    payload = dict(protocol=PROTOCOL, session_id=plan['session_id'],
                   plan_sha256=sha256_file(plan['_plan_path']),
                   original_window=window, state=_capture(plan))
    if recovery_safety.inspect_guard(plan) != window:
        raise CompletedRollbackError('Maintenance epoch changed while sealing success')
    payload['hmac_sha256'] = hmac.new(_key(plan), _canonical(payload), hashlib.sha256).hexdigest()
    path = Path(plan['backup_root'])/'post_update_seal.json'
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        stream.flush(); os.fsync(stream.fileno())
    return sha256_file(path)


def verify_seal(plan, state):
    path = Path(plan['backup_root'])/'post_update_seal.json'
    if not path.is_file() or state.get('post_update_seal_sha256') != sha256_file(path):
        raise CompletedRollbackError('Authenticated post-update seal missing or changed')
    value = json.loads(path.read_text(encoding='utf-8'))
    mac = value.pop('hmac_sha256', None)
    expected = hmac.new(_key(plan), _canonical(value), hashlib.sha256).hexdigest()
    if not isinstance(mac, str) or not hmac.compare_digest(mac, expected):
        raise CompletedRollbackError('Post-update seal authentication failed')
    if (value.get('protocol') != PROTOCOL or value.get('session_id') != plan['session_id']
            or value.get('plan_sha256') != sha256_file(plan['_plan_path'])
            or value.get('state') != _capture(plan)):
        raise CompletedRollbackError('Business data, media, configuration or application changed after update; automatic rollback refused')
    return value


def enter(plan, state, state_path):
    """Two checks close the race with writers: once before and once inside the barrier."""
    verify_seal(plan, state)
    write_state(state_path, completed_rollback_intent=True,
                current_step='Entering a new maintenance window for completed rollback')
    observed = recovery_safety.inspect_guard(plan, require_active=False)
    if observed['active']:
        # Retry after a power cut between begin() and durable window recording.
        maintenance.assert_active(plan)
    else:
        maintenance.begin(plan)
    window = recovery_safety.inspect_guard(plan)
    write_state(state_path, completed_rollback_window=window)
    # A write between the first seal check and begin() is caught here, while
    # business writes remain blocked. Never restore the old database on drift.
    verify_seal(plan, state)
    return window
