"""Installed update-source policy for signed production and GitHub pilot.

The initial policy is enrolled by an authenticated administrator/installer. It
must never be learned from the remote manifest which it is meant to verify.
"""
import ctypes
import argparse
from datetime import datetime, timezone
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import subprocess
import uuid
from urllib.parse import urlsplit

from theraflow.installed_paths import installed_paths
from theraflow.environment import canonical_env_path
from theraflow.release_signing import PROTOCOL, ReleaseSignatureError, canonical_manifest_bytes, parse_json_strict, validate_trust_profile, verify_release_manifest
from theraflow.version import __release_channel__, parse_version, validate_version_identifier


PILOT_MANIFEST_URL = ('https://raw.githubusercontent.com/riaddzakmic00-max/'
                      'theraflow-updates-new/main/channels/pilot/manifest.json')
PILOT_RELEASE_BASE = ('https://github.com/riaddzakmic00-max/'
                      'theraflow-updates-new/releases/download/')
PILOT_PROTOCOL = 'theraflow-pilot-github-v1'
PILOT_APPROVAL_FILE = 'pilot-update-approvals.json'
PILOT_APPROVAL_PROTOCOL = 'theraflow-pilot-approval-v1'
_SHA256 = re.compile(r'^[0-9a-fA-F]{64}$')


def validate_pilot_github_manifest(manifest, configured_manifest_url, approval):
    """Pilot policy: fixed GitHub origin plus independently approved SHA-256.

    The manifest is data, not authority to redirect the updater to another
    repository. Production releases continue through the signed policy below.
    """
    if configured_manifest_url != PILOT_MANIFEST_URL or type(manifest) is not dict:
        raise ReleaseSignatureError('Pilot GitHub channel is not configured')
    if manifest.get('channel') != 'pilot' or 'release_signature' in manifest:
        raise ReleaseSignatureError('Pilot manifest channel or format differs')
    try:
        version = validate_version_identifier(manifest['version'])
        minimum = validate_version_identifier(manifest['min_supported_version'])
        if parse_version(minimum) > parse_version(version):
            raise ValueError('Minimum version exceeds release version')
    except (KeyError, ValueError) as exc:
        raise ReleaseSignatureError('Pilot manifest version is invalid') from exc
    digest = manifest.get('sha256')
    if not isinstance(digest, str) or not _SHA256.fullmatch(digest):
        raise ReleaseSignatureError('Pilot package SHA-256 is invalid')
    tag = manifest.get('release_tag', 'v' + version + '-pilot')
    if (not isinstance(tag, str)
            or not re.fullmatch(r'v' + re.escape(version) + r'-pilot(?:-[a-z0-9-]+)?', tag)):
        raise ReleaseSignatureError('Pilot release tag differs from version')
    expected = PILOT_RELEASE_BASE + tag + '/TheraFlow_Update_' + version + '-pilot.zip'
    url = manifest.get('download_url')
    if not isinstance(url, str) or url != expected:
        raise ReleaseSignatureError('Pilot package repository, tag or asset differs')
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or parsed.hostname != 'github.com' or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ReleaseSignatureError('Pilot package URL is unsafe')
    if (type(approval) is not dict or approval.get('protocol') != PILOT_APPROVAL_PROTOCOL
            or type(approval.get('releases')) is not list):
        raise ReleaseSignatureError('Independent pilot approval file is invalid')
    matches = [item for item in approval['releases'] if type(item) is dict and item.get('version') == version]
    if (len(matches) != 1 or any(type(item) is not dict or set(item) != {'version', 'download_url', 'sha256'}
                                 for item in approval['releases'])):
        raise ReleaseSignatureError('Independent pilot approval is ambiguous')
    approved = matches[0]
    if (approved['download_url'] != url or not isinstance(approved['sha256'], str)
            or not _SHA256.fullmatch(approved['sha256'])
            or approved['sha256'].lower() != digest.lower()):
        raise ReleaseSignatureError('Independent pilot package approval differs')
    canonical = json.dumps(manifest, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                           allow_nan=False).encode('utf-8')
    return {'verified': True, 'protocol': PILOT_PROTOCOL, 'channel': 'pilot',
            'manifest_sha256': hashlib.sha256(canonical).hexdigest(),
            'package_sha256': digest.lower(), 'version': version,
            'approval_sha256': hashlib.sha256(json.dumps(approved, sort_keys=True,
                separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()}


def _verify_pilot_runtime_manifest(manifest):
    # The canonical installed .env is protected by the same Windows ACL policy
    # as the existing publisher trust files. Never take the channel from the
    # remote manifest or an override in the updater process environment.
    config = _common_appdata() / 'TheraFlow' / 'config'
    env_path = config / '.env'
    if (installed_paths().config.resolve() != config.resolve()
            or canonical_env_path().resolve() != env_path.resolve()):
        raise ReleaseSignatureError('Pilot/runtime configuration tree differs')
    assert_protected(env_path)
    from .database_restore import _env_file
    configured = _env_file(env_path).get('THERAFLOW_UPDATE_MANIFEST_URL', '')
    approval_path = config / PILOT_APPROVAL_FILE
    if not approval_path.is_file():
        raise ReleaseSignatureError('Independent pilot package approval is missing')
    assert_protected(approval_path)
    try:
        approval = parse_json_strict(approval_path.read_bytes())
    except (OSError, ValueError) as exc:
        raise ReleaseSignatureError('Independent pilot package approval is invalid') from exc
    return validate_pilot_github_manifest(manifest, configured, approval)


def _assert_signed_pilot_source(manifest):
    """Signed pilot releases keep the fixed GitHub origin after one-time trust enrollment."""
    config = _common_appdata() / 'TheraFlow' / 'config'
    env_path = config / '.env'
    if (installed_paths().config.resolve() != config.resolve()
            or canonical_env_path().resolve() != env_path.resolve()):
        raise ReleaseSignatureError('Pilot/runtime configuration tree differs')
    assert_protected(env_path)
    from .database_restore import _env_file
    if _env_file(env_path).get('THERAFLOW_UPDATE_MANIFEST_URL') != PILOT_MANIFEST_URL:
        raise ReleaseSignatureError('Signed pilot GitHub channel is not configured')
    if type(manifest) is not dict or manifest.get('channel') != 'pilot':
        raise ReleaseSignatureError('Signed pilot manifest channel differs')
    url = manifest.get('download_url')
    parsed = urlsplit(url) if isinstance(url, str) else None
    if (parsed is None or parsed.scheme != 'https' or parsed.hostname != 'github.com'
            or parsed.username or parsed.password or parsed.query or parsed.fragment
            or not url.startswith(PILOT_RELEASE_BASE)):
        raise ReleaseSignatureError('Signed pilot package is outside the fixed GitHub repository')


def merge_pilot_approval(document, version, download_url, sha256):
    """Add one separately supplied digest without replacing older approvals."""
    if __release_channel__ != 'pilot':
        raise ReleaseSignatureError('Pilot approval is unavailable on this channel')
    if document is None:
        document = {'protocol': PILOT_APPROVAL_PROTOCOL, 'releases': []}
    if (type(document) is not dict or set(document) != {'protocol', 'releases'}
            or document['protocol'] != PILOT_APPROVAL_PROTOCOL
            or type(document['releases']) is not list):
        raise ReleaseSignatureError('Pilot approval file is invalid')
    seen = set()
    for prior_entry in document['releases']:
        if type(prior_entry) is not dict or set(prior_entry) != {'version', 'download_url', 'sha256'}:
            raise ReleaseSignatureError('Pilot approval file has an invalid entry')
        prior_version = prior_entry['version']
        if prior_version in seen:
            raise ReleaseSignatureError('Pilot approval file repeats a version')
        seen.add(prior_version)
        prior_tail = prior_entry['download_url'][len(PILOT_RELEASE_BASE):] if isinstance(
            prior_entry['download_url'], str) and prior_entry['download_url'].startswith(PILOT_RELEASE_BASE) else ''
        prior_probe = {'channel': 'pilot', 'version': prior_version,
                       'min_supported_version': prior_version,
                       'release_tag': prior_tail.split('/')[0],
                       'download_url': prior_entry['download_url'], 'sha256': prior_entry['sha256']}
        validate_pilot_github_manifest(prior_probe, PILOT_MANIFEST_URL,
            {'protocol': PILOT_APPROVAL_PROTOCOL, 'releases': [prior_entry]})
    tail = download_url[len(PILOT_RELEASE_BASE):] if isinstance(download_url, str) and download_url.startswith(PILOT_RELEASE_BASE) else ''
    tag = tail.split('/')[0]
    entry = {'version': version, 'download_url': download_url, 'sha256': sha256}
    probe = {'channel': 'pilot', 'version': version, 'min_supported_version': version,
             'release_tag': tag, 'download_url': download_url, 'sha256': sha256}
    validate_pilot_github_manifest(probe, PILOT_MANIFEST_URL,
        {'protocol': PILOT_APPROVAL_PROTOCOL, 'releases': [entry]})
    prior = [item for item in document['releases'] if type(item) is dict and item.get('version') == version]
    if len(prior) > 1 or prior and prior[0] != entry:
        raise ReleaseSignatureError('Pilot version already approved with another identity')
    if prior:
        return document
    return {'protocol': PILOT_APPROVAL_PROTOCOL, 'releases': [*document['releases'], entry]}


def record_pilot_approval(version, download_url, sha256):
    """Administrator records a SHA-256 obtained separately from GitHub."""
    if os.name != 'nt' or not ctypes.windll.shell32.IsUserAnAdmin():
        raise ReleaseSignatureError('Administrator token is required for pilot approval')
    config = _common_appdata() / 'TheraFlow' / 'config'
    if installed_paths().config.resolve() != config.resolve():
        raise ReleaseSignatureError('Pilot configuration tree differs')
    assert_protected(config)
    path = config / PILOT_APPROVAL_FILE
    if path.exists():
        assert_protected(path)
        try:
            document = parse_json_strict(path.read_bytes())
        except (OSError, ValueError) as exc:
            raise ReleaseSignatureError('Pilot approval file is invalid') from exc
    else:
        document = None
    updated = merge_pilot_approval(document, version, download_url, sha256)
    if updated == document:
        return path
    temporary = config / (PILOT_APPROVAL_FILE + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with os.fdopen(os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'w', encoding='utf-8') as stream:
            json.dump(updated, stream, sort_keys=True, separators=(',', ':'))
            stream.flush()
            os.fsync(stream.fileno())
        assert_protected(temporary)
        os.replace(temporary, path)
        assert_protected(path)
    finally:
        if temporary.exists():
            temporary.unlink()
    return path


_ACL_SCRIPT = r'''
$ErrorActionPreference='Stop'
$p=([Console]::In.ReadToEnd() | ConvertFrom-Json).path
$item=Get-Item -LiteralPath $p -Force
$target=$true
$allowed=@('S-1-5-18','S-1-5-32-544')
$ancestorOwners=$allowed+@('S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')
$targetMask=[int][Security.AccessControl.FileSystemRights]::Write -bor [int][Security.AccessControl.FileSystemRights]::Delete -bor [int][Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor [int][Security.AccessControl.FileSystemRights]::ChangePermissions -bor [int][Security.AccessControl.FileSystemRights]::TakeOwnership
$ancestorMask=[int][Security.AccessControl.FileSystemRights]::Delete -bor [int][Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor [int][Security.AccessControl.FileSystemRights]::ChangePermissions -bor [int][Security.AccessControl.FileSystemRights]::TakeOwnership
function Resolve-Sid($identity) {
 if ([string]$identity -match '^S-1-') { return [string]$identity }
 return ([Security.Principal.NTAccount][string]$identity).Translate([Security.Principal.SecurityIdentifier]).Value
}
while ($null -ne $item) {
 if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'reparse' }
 $acl=Get-Acl -LiteralPath $item.FullName
 $owner=Resolve-Sid $acl.Owner
 if ($target -and $owner -notin $allowed) { throw 'owner' }
 if (-not $target -and $owner -notin $ancestorOwners) { throw 'ancestor_owner' }
 $mask=if ($target) {$targetMask} else {$ancestorMask}
 $writers=if ($target) {$allowed} else {$ancestorOwners}
 foreach ($r in $acl.Access) {
  if (($r.PropagationFlags -band [Security.AccessControl.PropagationFlags]::InheritOnly) -ne 0) { continue }
  $sid=$r.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
  if ($r.AccessControlType -eq 'Allow' -and $sid -notin $writers -and ([int]$r.FileSystemRights -band $mask)) { throw 'writable_or_replaceable' }
 }
 $target=$false
 $item=if ($item -is [IO.FileInfo]) { $item.Directory } else { $item.Parent }
}
[Console]::Out.Write('OK')
'''


def _powershell():
    if os.name != 'nt':
        raise ReleaseSignatureError('Windows publisher trust required')
    buffer = ctypes.create_unicode_buffer(32768)
    if not ctypes.windll.kernel32.GetSystemDirectoryW(buffer, len(buffer)):
        raise ReleaseSignatureError('Windows system directory unavailable')
    return str(Path(buffer.value) / 'WindowsPowerShell/v1.0/powershell.exe')


def assert_protected(path):
    path = Path(path)
    result = subprocess.run([_powershell(), '-NoProfile', '-NonInteractive', '-Command', _ACL_SCRIPT],
        input=json.dumps({'path': str(path)}), text=True, capture_output=True, timeout=30,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), shell=False)
    if result.returncode or result.stdout.strip() != 'OK':
        raise ReleaseSignatureError('Publisher trust storage is not protected')


def _common_appdata():
    """Machine-known common AppData cannot be selected by process environment."""
    if os.name != 'nt':
        raise ReleaseSignatureError('Windows publisher trust required')
    buffer = ctypes.create_unicode_buffer(32768)
    # CSIDL_COMMON_APPDATA. No fallback to PROGRAMDATA or manifest supplied paths.
    if ctypes.windll.shell32.SHGetFolderPathW(None, 35, None, 0, buffer) != 0:
        raise ReleaseSignatureError('Windows common AppData unavailable')
    path = Path(buffer.value)
    if not path.is_absolute() or str(path).startswith('\\\\'):
        raise ReleaseSignatureError('Windows common AppData unavailable')
    return path


def _paths():
    config = _common_appdata() / 'TheraFlow' / 'config'
    return config / 'release-trust.json', config / 'release-state.json', config / 'release-signature-audit.jsonl'


def _read_protected(path):
    assert_protected(path)
    try:
        return parse_json_strict(Path(path).read_bytes())
    except (OSError, ValueError) as exc:
        raise ReleaseSignatureError('Publisher policy/state unavailable') from exc


def _profile_digest(trust):
    return hashlib.sha256(json.dumps(trust, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _audit(event):
    _, _, path = _paths()
    assert_protected(path.parent)
    if path.exists():
        assert_protected(path)
    event = dict(event, at=datetime.now(timezone.utc).isoformat())
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(event, sort_keys=True, separators=(',', ':')) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    assert_protected(path)


def _verify_qa_database(trust):
    from .database_restore import _env_file
    import psycopg2
    env_path = _paths()[0].parent / '.env'
    assert_protected(env_path)
    values = _env_file(env_path)
    if (values.get('DB_NAME') != 'theraflow' or values.get('DB_HOST') not in ('127.0.0.1', 'localhost', '::1')
            or values.get('DB_PORT') != '5433'):
        raise ReleaseSignatureError('QA database configuration differs')
    try:
        connection = psycopg2.connect(dbname=values['DB_NAME'], host=values['DB_HOST'], port=5433,
            user=values.get('DB_USER', 'theraflow_user'), password=values.get('DB_PASSWORD', ''), connect_timeout=5)
        try:
            connection.set_session(readonly=True)
            with connection.cursor() as cursor:
                cursor.execute('SELECT current_database(), inet_server_addr()::text, inet_server_port(), current_user')
                database, address, port, user = cursor.fetchone()
                if database != 'theraflow' or port != 5433 or not ipaddress.ip_address(address.split('/')[0]).is_loopback or user != values.get('DB_USER', 'theraflow_user'):
                    raise ReleaseSignatureError('QA database endpoint differs')
        finally:
            connection.close()
    except ReleaseSignatureError:
        raise
    except Exception as exc:
        raise ReleaseSignatureError('QA read-only database identity unavailable') from exc


def verify_runtime_manifest(manifest, *, phase='check', recovery_receipt=None):
    """Reverify the envelope, never a caller supplied verified=True boolean.

    recovery_receipt is only passed after the existing plan HMAC has been checked.
    It anchors recovery to the local acceptance time without authorizing a new
    install of an expired release. Recovery still verifies its CMS signature.
    """
    if __release_channel__ == 'pilot' and not (type(manifest) is dict and 'release_signature' in manifest):
        receipt = _verify_pilot_runtime_manifest(manifest)
        if recovery_receipt is not None and (
                type(recovery_receipt) is not dict
                or recovery_receipt.get('protocol') != PILOT_PROTOCOL
                or recovery_receipt.get('manifest_sha256') != receipt['manifest_sha256']
                or recovery_receipt.get('package_sha256') != receipt['package_sha256']
                or recovery_receipt.get('approval_sha256') != receipt['approval_sha256']):
            raise ReleaseSignatureError('Pilot recovery receipt differs')
        return receipt
    if __release_channel__ == 'pilot' and manifest.get('channel') == 'pilot':
        _assert_signed_pilot_source(manifest)
    trust_path, state_path, _ = _paths()
    try:
        # Publisher trust and every existing updater/Django path must refer to
        # the same machine-owned tree. A process PROGRAMDATA override cannot
        # authenticate here and then operate on a different config/database.
        config = trust_path.parent.resolve()
        if (installed_paths().config.resolve() != config
                or canonical_env_path().resolve() != config / '.env'):
            raise ReleaseSignatureError('Publisher/runtime configuration tree differs')
        trust = _read_protected(trust_path)
        scope = trust.get('scope')
        host = os.environ.get('COMPUTERNAME', '')
        # Machine identity comes from Windows, never the process environment.
        if os.name == 'nt':
            buffer = ctypes.create_unicode_buffer(256)
            size = ctypes.c_ulong(len(buffer))
            if not ctypes.windll.kernel32.GetComputerNameW(buffer, ctypes.byref(size)):
                raise ReleaseSignatureError('Machine identity unavailable')
            host = buffer.value
        state = _read_protected(state_path) if state_path.exists() else {}
        clock = None
        if recovery_receipt is not None:
            digest = hashlib.sha256(canonical_manifest_bytes(manifest)).hexdigest()
            if recovery_receipt.get('manifest_sha256') != digest:
                raise ReleaseSignatureError('Recovery publisher receipt differs')
            clock = datetime.fromisoformat(recovery_receipt['accepted_at'].replace('Z', '+00:00'))
        receipt = verify_release_manifest(manifest, trust, expected_scope=scope, host=host, now=clock)
        if scope == 'qa':
            if host != 'DESKTOP-OTO3E25' or trust.get('source_database') != 'theraflow' or trust.get('allowed_database_ports') != [5433]:
                raise ReleaseSignatureError('QA database policy is not isolated')
            _verify_qa_database(trust)
        elif scope != 'production':
            raise ReleaseSignatureError('Unknown publisher scope')
        if state:
            if state.get('profile_id') != trust.get('profile_id'):
                raise ReleaseSignatureError('Publisher state/profile differ')
            prior = state.get('release_sequence')
            if type(prior) is not int or receipt['release_sequence'] < prior:
                raise ReleaseSignatureError('Release replay refused')
            if receipt['release_sequence'] == prior and receipt['manifest_sha256'] != state.get('manifest_sha256'):
                raise ReleaseSignatureError('Release sequence reused for different content')
        receipt['profile_id'] = trust['profile_id']
        receipt['trust_profile_sha256'] = _profile_digest(trust)
        receipt.setdefault('accepted_at', datetime.now(timezone.utc).isoformat())
        _audit(dict(receipt, phase=phase, result='PASS'))
        return receipt
    except Exception as exc:
        try:
            _audit({'phase': phase, 'result': 'FAIL', 'error_type': type(exc).__name__})
        except Exception:
            pass
        if isinstance(exc, ReleaseSignatureError):
            raise
        raise ReleaseSignatureError('Publisher authentication failed') from exc


def commit_release(receipt):
    """Call after durable update success; no rollback of accepted publisher state."""
    if __release_channel__ == 'pilot' and receipt.get('protocol') == PILOT_PROTOCOL:
        if (type(receipt) is not dict or receipt.get('verified') is not True
                or receipt.get('protocol') != PILOT_PROTOCOL
                or receipt.get('channel') != 'pilot'
                or not _SHA256.fullmatch(str(receipt.get('manifest_sha256', '')))
                or not _SHA256.fullmatch(str(receipt.get('package_sha256', '')))
                or not _SHA256.fullmatch(str(receipt.get('approval_sha256', '')))):
            raise ReleaseSignatureError('Pilot GitHub receipt is invalid')
        # The existing HMAC plan, package digest, version and backup checks
        # remain authoritative. There is no CMS publisher state in pilot mode.
        return
    trust_path, state_path, _ = _paths()
    trust = _read_protected(trust_path)
    validate_trust_profile(trust, expected_scope=trust.get('scope'))
    if (type(receipt) is not dict or receipt.get('verified') is not True or receipt.get('protocol') != PROTOCOL
            or receipt.get('profile_id') != trust['profile_id']
            or receipt.get('trust_profile_sha256') != _profile_digest(trust)
            or receipt.get('release_scope') != trust['scope'] or receipt.get('channel') not in trust['channels']):
        raise ReleaseSignatureError('Publisher policy changed during update')
    if type(receipt.get('release_sequence')) is not int or receipt['release_sequence'] < max(1, trust['minimum_sequence']):
        raise ReleaseSignatureError('Publisher sequence is invalid')
    signer = next((cert for cert in trust['certificates'] if cert['key_id'] == receipt.get('key_id')), None)
    if (signer is None or signer['scope'] != receipt['release_scope']
            or signer['sha256'].lower() != receipt.get('certificate_sha256')):
        raise ReleaseSignatureError('Publisher signer changed during update')
    assert_protected(state_path.parent)
    if state_path.exists():
        current = _read_protected(state_path)
        prior = current.get('release_sequence')
        if current.get('profile_id') != trust['profile_id'] or type(prior) is not int:
            raise ReleaseSignatureError('Publisher state/profile differ')
        if prior > receipt['release_sequence']:
            raise ReleaseSignatureError('Publisher sequence cannot decrease')
        if prior == receipt['release_sequence'] and current.get('manifest_sha256') != receipt.get('manifest_sha256'):
            raise ReleaseSignatureError('Publisher sequence reused for different content')
    temporary = state_path.with_name(state_path.name + '.tmp')
    with temporary.open('x', encoding='utf-8') as stream:
        json.dump(receipt, stream, sort_keys=True)
        stream.flush()
        os.fsync(stream.fileno())
    assert_protected(temporary)
    os.replace(temporary, state_path)
    _audit(dict(receipt, phase='commit', result='PASS'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Record an independently approved pilot package SHA-256')
    parser.add_argument('action', choices=('approve-pilot',))
    parser.add_argument('--version', required=True)
    parser.add_argument('--download-url', required=True)
    parser.add_argument('--sha256', required=True)
    options = parser.parse_args()
    record_pilot_approval(options.version, options.download_url, options.sha256)
    print('PILOT_APPROVAL_OK version=' + options.version + ' sha256=' + options.sha256.lower())
