"""Durable PostgreSQL write barrier, independent of web/worker lifetimes.

Control schema survives transactional public-schema restore. No patient data is
stored here. Only the updater's scoped child connections receive the random key.
An interrupted update remains blocked until verified recovery; no timed expiry.
"""
import hashlib
import json
import logging
import secrets
from contextlib import closing
from pathlib import Path

import psycopg2
from psycopg2 import sql

SCHEMA = 'tf_update_control'
LOG = logging.getLogger(__name__)
EXCLUDED = {'django_migrations', 'django_session', 'updates_updatehistory', 'updates_updatesession'}


def connection_config(database):
    return dict(dbname=database.get('NAME', database.get('name')),
                host=database.get('HOST', database.get('host', '127.0.0.1')),
                port=database.get('PORT', database.get('port', '5433')),
                user=database.get('USER', database.get('user')),
                password=database.get('PASSWORD', database.get('password', '')))


def database_for_plan(plan):
    from .database_restore import _env_file
    values = _env_file(plan['canonical_env_path'])
    if not all(values.get(n) for n in ('DB_NAME', 'DB_HOST', 'DB_PORT', 'DB_USER')):
        raise RuntimeError('Maintenance requires explicit database identity')
    return {k: values['DB_' + k.upper()] for k in ('name', 'host', 'port', 'user', 'password')}


def key_file(plan):
    return Path(plan['backup_root']) / 'maintenance-key.json'


def key(plan, create=False):
    path = key_file(plan)
    if create and not path.exists():
        with path.open('x', encoding='utf-8') as f:
            json.dump({'session_id': str(plan['session_id']), 'key': secrets.token_hex(32)}, f)
    value = json.loads(path.read_text(encoding='utf-8'))
    if value['session_id'] != str(plan['session_id']) or len(value['key']) != 64:
        raise RuntimeError('Maintenance key/session mismatch')
    return value['key']


def environment(plan):
    # Never copy this environment to the application or backup scheduler.
    return {'PGOPTIONS': '-c theraflow.update_key=' + key(plan)}


def _tables(cur):
    cur.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename")
    return [row[0] for row in cur.fetchall() if row[0] not in EXCLUDED]


def _guards(cur, tables):
    cur.execute('''CREATE OR REPLACE FUNCTION tf_update_control.block_business_write()
        RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $guard$
        BEGIN
          IF EXISTS (SELECT 1 FROM tf_update_control.barrier
              WHERE active AND key_hash IS DISTINCT FROM
                    md5(coalesce(current_setting('theraflow.update_key', true), ''))) THEN
            RAISE EXCEPTION 'TheraFlow održavanje: poslovni upisi su privremeno zaustavljeni.'
              USING ERRCODE='55000';
          END IF;
          RETURN NULL;
        END $guard$''')
    for name in tables:
        cur.execute(sql.SQL('DROP TRIGGER IF EXISTS tf_maintenance_guard ON public.{}').format(sql.Identifier(name)))
        cur.execute(sql.SQL('CREATE TRIGGER tf_maintenance_guard BEFORE INSERT OR UPDATE OR DELETE OR TRUNCATE ON public.{} FOR EACH STATEMENT EXECUTE FUNCTION tf_update_control.block_business_write()').format(sql.Identifier(name)))


def begin(plan, database=None):
    token = key(plan, create=True)
    database = database or database_for_plan(plan)
    with closing(psycopg2.connect(**connection_config(database), options=environment(plan)['PGOPTIONS'])) as conn, conn:
        with conn.cursor() as cur:
            cur.execute("SELECT count(*) FROM pg_event_trigger WHERE evtname IN ('tf_maintenance_ddl','tf_maintenance_new_tables') AND evtenabled='O'")
            if cur.fetchone()[0] != 2:
                raise RuntimeError('Maintenance database bootstrap missing; backup refused')
            cur.execute("SELECT nspname FROM pg_namespace WHERE nspname NOT IN ('public','tf_update_control','information_schema') AND nspname NOT LIKE 'pg_%%'")
            if cur.fetchall():
                raise RuntimeError('Additional schemas require an explicitly reviewed full backup strategy')
            cur.execute("SET LOCAL lock_timeout='30s'")
            cur.execute('SELECT pg_advisory_xact_lock(19483117, hashtext(current_database()))')
            cur.execute('SELECT session_id,active FROM tf_update_control.barrier FOR UPDATE')
            previous = cur.fetchone()
            if previous and previous[1] and previous[0] != str(plan['session_id']):
                raise RuntimeError('Another maintenance session remains active')
            tables = _tables(cur)
            if not tables:
                raise RuntimeError('No business schema; backup preparation refused')
            # Drain transactions that already wrote; retain locks until active
            # flag and every trigger commit together, before pg_dump can start.
            cur.execute(sql.SQL('LOCK TABLE {} IN ACCESS EXCLUSIVE MODE').format(
                sql.SQL(',').join(sql.Identifier('public', n) for n in tables)))
            _guards(cur, tables)
            cur.execute('''INSERT INTO tf_update_control.barrier(singleton,session_id,key_hash,active)
                VALUES(true,%s,%s,true) ON CONFLICT(singleton) DO UPDATE
                SET session_id=excluded.session_id,key_hash=excluded.key_hash,active=true,
                    started_at=clock_timestamp(),finished_at=NULL,outcome=NULL''',
                (str(plan['session_id']), hashlib.md5(token.encode()).hexdigest()))
    LOG.info('MAINTENANCE ACTIVE session=%s guarded_tables=%s drained=true', plan['session_id'], len(tables))
    return {'active': True, 'session_id': str(plan['session_id']), 'guarded_tables': tables}


def assert_active(plan, database=None):
    with closing(psycopg2.connect(**connection_config(database or database_for_plan(plan)))) as conn:
        with conn.cursor() as cur:
            cur.execute('SELECT session_id,key_hash,active FROM tf_update_control.barrier')
            row = cur.fetchone()
            if row != (str(plan['session_id']), hashlib.md5(key(plan).encode()).hexdigest(), True):
                raise RuntimeError('Write barrier missing or belongs to another session')
    return True


def refresh(plan, database=None):
    assert_active(plan, database)
    with closing(psycopg2.connect(**connection_config(database or database_for_plan(plan)), options=environment(plan)['PGOPTIONS'])) as conn, conn:
        with conn.cursor() as cur:
            _guards(cur, _tables(cur))


def finish(plan, outcome, database=None):
    if outcome not in ('verified_success', 'verified_rollback'):
        raise ValueError('Only verified terminal outcomes can release maintenance')
    assert_active(plan, database)
    with closing(psycopg2.connect(**connection_config(database or database_for_plan(plan)))) as conn, conn:
        with conn.cursor() as cur:
            cur.execute('''UPDATE tf_update_control.barrier SET active=false,
                finished_at=clock_timestamp(),outcome=%s WHERE session_id=%s AND active''',
                (outcome, str(plan['session_id'])))
            if cur.rowcount != 1:
                raise RuntimeError('Maintenance release lost ownership')
    LOG.info('MAINTENANCE RELEASED session=%s outcome=%s', plan['session_id'], outcome)


def assert_finished(plan, outcome, database=None):
    with closing(psycopg2.connect(**connection_config(database or database_for_plan(plan)))) as conn:
        with conn.cursor() as cur:
            cur.execute('SELECT session_id,key_hash,active,outcome FROM tf_update_control.barrier WHERE singleton')
            row=cur.fetchone()
            expected=(str(plan['session_id']),hashlib.md5(key(plan).encode()).hexdigest(),False,outcome)
            if row!=expected:
                raise RuntimeError('Verified maintenance terminal outcome missing')
    return True


def django_begin(session, backup_root):
    from django.conf import settings
    if len(settings.DATABASES) != 1 or settings.DATABASE_ROUTERS:
        raise RuntimeError('All database aliases must be explicitly guarded before preparation')
    if settings.DATABASES['default']['ENGINE'] != 'django.db.backends.postgresql':
        raise RuntimeError('Production maintenance requires PostgreSQL')
    if getattr(settings, 'PRODUCTION_MODE', False):
        # Apply before creating the key or any database/configuration dump.
        # Narrow only this newly-created backup directory to SYSTEM/Admins.
        from .plan_security import apply_restricted_acl
        apply_restricted_acl(backup_root)
    return begin({'session_id': str(session.pk), 'backup_root': str(backup_root)}, settings.DATABASES['default'])
