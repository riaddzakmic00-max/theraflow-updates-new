"""Mandatory local recovery proof. Never restore or migrate the source database."""
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import uuid
import zipfile

import psycopg2
from psycopg2 import sql

from . import maintenance
from .plan_loader import sha256_file

PROTOCOL = 'local-independent-restore-v1'
VOLATILE_TABLES = {'django_session', 'updates_updatesession', 'updates_updatehistory'}
GUARD_SHA256 = '946218264dca1ce460c1758cf435011bb2966f739b7ba0f2843b5f722d317670'


class RecoverySafetyError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def fail(code, message):
    raise RecoverySafetyError(code, message)


def _connect(database):
    return psycopg2.connect(**maintenance.connection_config(database), connect_timeout=10,
                           options='-c statement_timeout=120000 -c lock_timeout=10000')


def _identity(connection):
    with connection.cursor() as cur:
        cur.execute('SELECT system_identifier::text FROM pg_control_system()')
        cluster = cur.fetchone()[0]
        cur.execute('SELECT current_database(),current_user,inet_server_port(),current_setting(\'server_version_num\')')
        database, role, port, version = cur.fetchone()
    return dict(cluster=cluster, database=database, role=role, port=port, major=int(version)//10000)


def inspect_guard(plan, *, require_active=True, database=None):
    with closing(_connect(database or maintenance.database_for_plan(plan))) as conn, conn, conn.cursor() as cur:
        cur.execute('SET TRANSACTION READ ONLY')
        cur.execute("SELECT to_regprocedure('tf_update_control.guard_ddl()') IS NOT NULL")
        if not cur.fetchone()[0]:
            fail('restore_guard_missing', 'SQL zaštita oporavka nedostaje. Potrebna je provjerena nadogradnja updatera.')
        cur.execute("""SELECT prosrc,prosecdef,proconfig,prorettype='event_trigger'::regtype
                       FROM pg_proc WHERE oid='tf_update_control.guard_ddl()'::regprocedure""")
        body, secure, config, returns_event = cur.fetchone()
        digest = hashlib.sha256(body.replace('\r\n', '\n').strip().encode('utf-8')).hexdigest()
        cur.execute("""SELECT count(*) FROM pg_event_trigger WHERE evtenabled='O' AND
          ((evtname='tf_maintenance_ddl' AND evtfoid='tf_update_control.guard_ddl()'::regprocedure)
           OR (evtname='tf_maintenance_new_tables' AND evtfoid=to_regprocedure('tf_update_control.guard_new_tables()')))""")
        if (digest != GUARD_SHA256 or not secure or not returns_event
                or config != ['search_path=pg_catalog'] or cur.fetchone()[0] != 2):
            fail('restore_guard_invalid', 'SQL zaštita oporavka nije potvrđena. Instalacija je zaustavljena.')
        cur.execute('SELECT session_id,key_hash,active,started_at::text FROM tf_update_control.barrier WHERE singleton')
        row = cur.fetchone()
        if require_active:
            token_hash = hashlib.md5(maintenance.key(plan).encode()).hexdigest()
            if not row or row[:3] != (str(plan['session_id']), token_hash, True):
                fail('restore_window_closed', 'Prozor održavanja nije aktivan. Povrat stare baze i aplikacije je zaustavljen radi zaštite novih upisa.')
        return dict(guard_sha256=digest, epoch=row[3] if row else None, active=bool(row and row[2]))


def _fingerprint(connection):
    result = dict(rows={}, columns=[], constraints=[], indexes=[], sequences=[], migrations=[])
    with connection.cursor() as cur:
        cur.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename")
        tables = [row[0] for row in cur.fetchall() if row[0] not in VOLATILE_TABLES]
        for table in tables:
            # Stream deterministic row JSON locally; neither rows nor identifiers enter logs/UI.
            digest = hashlib.sha256(); count = 0
            cur.execute(sql.SQL('SELECT to_jsonb(t)::text FROM public.{} t ORDER BY to_jsonb(t)::text').format(sql.Identifier(table)))
            while rows := cur.fetchmany(512):
                for (value,) in rows:
                    data = value.encode('utf-8'); digest.update(len(data).to_bytes(8, 'big')); digest.update(data); count += 1
            result['rows'][table] = dict(count=count, sha256=digest.hexdigest())
        queries = {
            'columns': "SELECT table_name,column_name,row_number() OVER(PARTITION BY table_name ORDER BY ordinal_position),data_type,udt_name,is_nullable,column_default,is_identity,identity_generation FROM information_schema.columns WHERE table_schema='public' ORDER BY table_name,ordinal_position",
            'constraints': "SELECT c.relname,x.conname,pg_get_constraintdef(x.oid) FROM pg_constraint x JOIN pg_class c ON c.oid=x.conrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' ORDER BY 1,2",
            'indexes': "SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='public' ORDER BY 1,2",
            'migrations': "SELECT app,name FROM public.django_migrations ORDER BY app,name",
        }
        for name, query in queries.items():
            cur.execute(query); result[name] = cur.fetchall()
            if name in ('constraints', 'indexes'):
                result[name] = [(*row[:-1], _canonical_definition(row[-1])) for row in result[name]]
        cur.execute("""SELECT s.sequencename,s.start_value,s.min_value,s.max_value,s.increment_by,s.cycle,s.cache_size
          FROM pg_sequences s WHERE s.schemaname='public' AND NOT EXISTS
          (SELECT 1 FROM pg_depend d JOIN pg_class t ON t.oid=d.refobjid
           WHERE d.objid=('public.'||quote_ident(s.sequencename))::regclass
             AND d.deptype IN ('a','i') AND t.relname=ANY(%s)) ORDER BY 1""", (sorted(VOLATILE_TABLES),))
        sequences = cur.fetchall()
        for row in sequences:
            cur.execute(sql.SQL('SELECT last_value,is_called FROM public.{}').format(sql.Identifier(row[0])))
            result['sequences'].append((*row, *cur.fetchone()))
    # Canonical JSON avoids tuple/list differences after sealing the receipt.
    return json.loads(json.dumps(result, sort_keys=True, default=str))


def _canonical_definition(value):
    # pg_dump/reparse distributes a cast over an ARRAY of unbounded varchar
    # literals. Normalize only this proven equivalent representation, retaining
    # literal values, order, operators, predicates and all other SQL unchanged.
    literal = r"'(?:[^']|'')*'::character varying"
    pattern = r"\(ARRAY\[(" + literal + r"(?:,\s*" + literal + r")*)\]\)::text\[\]"
    def distribute(match):
        values = re.findall(literal, match.group(1))
        return 'ARRAY[' + ', '.join('(' + item + ')::text' for item in values) + ']'
    return re.sub(pattern, distribute, value)


def _catalog(root):
    root = Path(root)
    if not root.is_dir() or root.is_symlink() or root.is_junction():
        fail('media_root_invalid', 'Direktorij dokumenata nije potvrđen.')
    entries = {}; folded = set()
    for current, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            path = Path(current) / name
            if path.is_symlink() or path.is_junction():
                fail('media_link_refused', 'Dokumenti sadrže simboličku vezu; potreban je pregled backupa.')
        for name in files:
            path = Path(current) / name; relative = path.relative_to(root).as_posix()
            if relative.casefold() in folded:
                fail('media_name_collision', 'Dokumenti imaju konflikt naziva datoteka.')
            folded.add(relative.casefold())
            entries[relative] = dict(bytes=path.stat().st_size, sha256=sha256_file(path))
    return entries


def _media_roundtrip(root, backup):
    _catalog(root)  # Refuse a junction before resolve() hides it.
    root, backup = Path(root).resolve(), Path(backup).resolve()
    if root == backup or root in backup.parents or backup in root.parents:
        fail('media_backup_overlap', 'Lokacija backupa preklapa se s dokumentima.')
    before = _catalog(root)
    archive = backup/'media_backup.zip'
    restored = backup/('media_restore_probe_' + uuid.uuid4().hex)
    restored.mkdir(exist_ok=False)
    try:
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as target:
            for name in sorted(before): target.write(root/name, name)
        with zipfile.ZipFile(archive) as source:
            if source.testzip() is not None or set(source.namelist()) != set(before):
                fail('media_backup_invalid', 'Arhiva dokumenata nije ispravna.')
            for name in source.namelist():
                relative = PurePosixPath(name)
                if relative.is_absolute() or '..' in relative.parts or '\\' in name or ':' in name:
                    fail('media_backup_path_invalid', 'Arhiva sadrži nedozvoljenu putanju.')
                target = restored/name; target.parent.mkdir(parents=True, exist_ok=True)
                with source.open(name) as incoming, target.open('xb') as outgoing:
                    shutil.copyfileobj(incoming, outgoing)
        if _catalog(restored) != before or _catalog(root) != before:
            fail('media_restore_mismatch', 'Obnova dokumenata ili stabilnost izvornih datoteka nije potvrđena.')
        return archive, before
    finally:
        # Delete only the newly created probe under this exact protected backup root.
        assert restored.resolve().parent == backup and restored.name.startswith('media_restore_probe_')
        shutil.rmtree(restored)


def _verifier_config(plan):
    path = Path(plan['canonical_env_path']).resolve().parent/'recovery-verifier.json'
    try: value = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        fail('recovery_verifier_missing', 'Lokalno okruženje za probnu obnovu nije pripremljeno. Instalacija je zaustavljena.')
    if (value.get('host') != '127.0.0.1' or not str(value.get('cluster_id', '')).isdigit()
                or type(value.get('port')) is not int or not 1024 <= value['port'] <= 65535
                or not value.get('user') or not isinstance(value.get('password'), str)):
        fail('recovery_verifier_invalid', 'Lokalno okruženje za oporavak nije validno registrovano.')
    return value


def _preflight(plan, database=None):
    if plan['target_version'] == '1.1.5' and plan['current_version'] != '1.1.4':
        fail('source_version_unsupported', 'Za ovaj paket mora biti potvrđena polazna verzija 1.1.4.')
    inspect_guard(plan, require_active=False, database=database)
    verifier = _verifier_config(plan)
    with closing(_connect(database or maintenance.database_for_plan(plan))) as source, source:
        with source.cursor() as cur: cur.execute('SET TRANSACTION READ ONLY')
        identity = _identity(source)
    with closing(_connect(dict(verifier, name='postgres'))) as destination, destination:
        with destination.cursor() as cur: cur.execute('SET TRANSACTION READ ONLY')
        actual = _identity(destination)
    if (actual['cluster'] != verifier['cluster_id'] or actual['cluster'] == identity['cluster']
            or actual['major'] != identity['major']):
        fail('recovery_cluster_not_isolated', 'Probna obnova zahtijeva odvojeni lokalni PostgreSQL iste glavne verzije.')
    return dict(status='PASS', source_major=identity['major'], separate_verifier=True)


def _pg_restore(plan, archive, target):
    from .database_restore import _executable
    env = {k: os.environ[k] for k in ('SystemRoot','WINDIR','PATH','PATHEXT','COMSPEC','TEMP','TMP') if k in os.environ}
    env.update(PGPASSWORD=target['password'], PGOPTIONS='-c statement_timeout=120000',
               PGPASSFILE=str(Path(plan['backup_root'])/'absent-pgpass'),
               PGSERVICEFILE=str(Path(plan['backup_root'])/'absent-pgservice'))
    if any(Path(env[k]).exists() for k in ('PGPASSFILE', 'PGSERVICEFILE')):
        fail('recovery_environment_invalid', 'Izolovana konfiguracija probne obnove nije potvrđena.')
    try:
        result = subprocess.run([_executable('pg_restore', plan), '--exit-on-error', '--no-owner', '--no-privileges',
            '--host','127.0.0.1','--port',str(target['port']),'--username',target['user'],'--dbname',target['name'],
            '--no-password',str(archive)], env=env, capture_output=True, timeout=900, shell=False,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except (OSError, subprocess.TimeoutExpired):
        fail('recovery_restore_failed', 'Probna obnova baze nije završena. Instalacija je zaustavljena.')
    if result.returncode:
        # PostgreSQL COPY diagnostics may contain patient values: do not expose them.
        fail('recovery_restore_failed', 'Probna obnova baze nije uspjela. Instalacija je zaustavljena.')


def _database_roundtrip(plan, verifier):
    database = maintenance.database_for_plan(plan)
    with closing(_connect(database)) as source, source:
        with source.cursor() as cur: cur.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        identity = _identity(source); expected = _fingerprint(source)
    control = dict(verifier, name='postgres')
    name = 'tf_restore_probe_' + uuid.uuid4().hex
    target = dict(verifier, name=name)
    created = False
    with closing(_connect(control)) as connection:
        actual = _identity(connection); connection.rollback(); connection.autocommit = True
        if (actual['cluster'] != verifier['cluster_id'] or actual['cluster'] == identity['cluster']
                or actual['major'] != identity['major']):
            fail('recovery_cluster_not_isolated', 'Probna obnova zahtijeva odvojeni lokalni PostgreSQL iste glavne verzije.')
        try:
            with connection.cursor() as cur:
                cur.execute(sql.SQL('CREATE DATABASE {} TEMPLATE template0').format(sql.Identifier(name))); created = True
            results = []
            # Prove both the full archival backup and the actual public-schema rollback dump.
            for index, filename in enumerate(('theraflow_database_full.dump', 'theraflow_database.dump')):
                if index:
                    # The public archive references control-schema functions. Preserve
                    # those from the verified full restore. Modify only our new clone.
                    with closing(_connect(target)) as clone, clone, clone.cursor() as cur:
                        assert _identity(clone)['cluster'] == actual['cluster'] != identity['cluster']
                        cur.execute('UPDATE tf_update_control.barrier SET active=false')
                        cur.execute('DROP SCHEMA public CASCADE')
                _pg_restore(plan, Path(plan['backup_root'])/filename, target)
                with closing(_connect(target)) as restored, restored:
                    with restored.cursor() as cur: cur.execute('SET TRANSACTION READ ONLY')
                    if _fingerprint(restored) != expected:
                        fail('recovery_data_mismatch', 'Obnovljena baza ne odgovara izvornim podacima, šemi ili sekvencama.')
                results.append(dict(file=filename, sha256=sha256_file(Path(plan['backup_root'])/filename), restored=True))
            with closing(_connect(database)) as source, source:
                with source.cursor() as cur: cur.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
                if _fingerprint(source) != expected:
                    fail('source_changed_during_proof', 'Podaci su promijenjeni tokom provjere backupa. Potrebna je nova priprema.')
            return identity, expected, results
        finally:
            if created:
                # Never target the source cluster or any pre-existing database; no FORCE.
                assert name.startswith('tf_restore_probe_') and actual['cluster'] != identity['cluster']
                with connection.cursor() as cur: cur.execute(sql.SQL('DROP DATABASE {}').format(sql.Identifier(name)))


def _prepare_proof(plan, media_root):
    if plan['target_version'] == '1.1.5' and plan['current_version'] != '1.1.4':
        fail('source_version_unsupported', 'Za ovaj paket mora biti potvrđena polazna verzija 1.1.4.')
    window = inspect_guard(plan)
    backup = Path(plan['backup_root']).resolve()
    if any((backup/name).exists() for name in ('recovery-verification.json', 'media_backup.zip')):
        fail('recovery_proof_exists', 'Dokaz oporavka već postoji. Koristite novu update sesiju.')
    verifier = _verifier_config(plan)
    identity, fingerprint, restored = _database_roundtrip(plan, verifier)
    if plan['target_version'] == '1.1.5':
        expected = json.loads(Path(__file__).with_name('baseline_114_migrations.json').read_text(encoding='utf-8'))
        observed = [row for row in fingerprint['migrations'] if row[0] in ('patients', 'updates')]
        if observed != expected:
            fail('source_migrations_mismatch', 'Migracije baze ne odgovaraju polaznoj verziji 1.1.4. Potrebna je provjera kompatibilnosti.')
    media_archive, media_files = _media_roundtrip(media_root, backup)
    if inspect_guard(plan) != window:
        fail('recovery_window_changed', 'Prozor održavanja promijenjen je tokom provjere.')
    receipt = dict(protocol=PROTOCOL, session_id=str(plan['session_id']), package_sha256=plan['package_sha256'],
        current_version=plan['current_version'], target_version=plan['target_version'], window=window,
        source_identity=identity, source_fingerprint=fingerprint, restored_databases=restored,
        config_sha256=sha256_file(plan['config_backup_path']), media_files=media_files,
        media_sha256=sha256_file(media_archive), media_root=str(Path(media_root).resolve()),
        owner_acl_note='Clone restores omit owners/grants; original archives retain them. Source grants are not modified.')
    file = backup/'recovery-verification.json'
    with file.open('x', encoding='utf-8') as handle:
        json.dump(receipt, handle, ensure_ascii=False, sort_keys=True); handle.flush(); os.fsync(handle.fileno())
    return dict(recovery_protocol=PROTOCOL, recovery_receipt_sha256=sha256_file(file),
                media_backup_sha256=receipt['media_sha256'], media_root=receipt['media_root'])


def _verify_proof(plan, *, check_live=False, completed_window=None, completed=False):
    backup = Path(plan['backup_root']).resolve(); file = backup/'recovery-verification.json'
    if plan.get('recovery_protocol') != PROTOCOL or not file.is_file():
        fail('recovery_proof_missing', 'Nedostaje dokaz stvarne obnove baze i dokumenata. Instalacija je zaustavljena.')
    if sha256_file(file) != plan.get('recovery_receipt_sha256'):
        fail('recovery_proof_changed', 'Dokaz oporavka promijenjen je nakon potpisivanja plana.')
    receipt = json.loads(file.read_text(encoding='utf-8'))
    if receipt.get('protocol') != PROTOCOL:
        fail('recovery_proof_protocol', 'Nepodržan format dokaza oporavka.')
    for key in ('session_id','package_sha256','current_version','target_version','media_root'):
        if receipt.get(key) != plan.get(key): fail('recovery_proof_identity', 'Dokaz oporavka ne pripada ovoj instalaciji.')
    observed = inspect_guard(plan, require_active=(completed_window.get('active', False)
                            if completed_window else not completed))
    if completed_window:
        if observed != completed_window:
            fail('recovery_window_changed', 'Novi prozor za potvrđeni rollback je promijenjen.')
    elif completed:
        if observed != dict(receipt['window'], active=False):
            fail('recovery_window_changed', 'Završeni prozor instalacije je promijenjen.')
    elif receipt['window'] != observed:
        fail('recovery_window_changed', 'Prvobitni prozor održavanja je završen ili promijenjen. Povrat stare baze je zabranjen.')
    if len(receipt['restored_databases']) != 2 or {r['file'] for r in receipt['restored_databases']} != {'theraflow_database_full.dump','theraflow_database.dump'}:
        fail('recovery_proof_incomplete', 'Nisu provjerene obje arhive baze.')
    for item in receipt['restored_databases']:
        if not item['restored'] or sha256_file(backup/item['file']) != item['sha256']:
            fail('recovery_backup_changed', 'Backup baze je promijenjen nakon probne obnove.')
    if sha256_file(plan['config_backup_path']) != receipt['config_sha256']:
        fail('recovery_config_changed', 'Backup konfiguracije je promijenjen.')
    if sha256_file(backup/'media_backup.zip') != receipt['media_sha256'] or receipt['media_sha256'] != plan.get('media_backup_sha256'):
        fail('recovery_media_changed', 'Backup dokumenata je promijenjen nakon probne obnove.')
    if check_live:
        if _catalog(Path(plan['media_root'])) != receipt['media_files']:
            fail('live_media_changed', 'Dokumenti su promijenjeni nakon pripreme. Instalacija je zaustavljena.')
        with closing(_connect(maintenance.database_for_plan(plan))) as conn, conn:
            with conn.cursor() as cur: cur.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
            if _identity(conn) != receipt['source_identity'] or _fingerprint(conn) != receipt['source_fingerprint']:
                fail('live_database_changed', 'Baza je promijenjena nakon pripreme. Instalacija je zaustavljena.')
    return receipt


def _safe_call(function, *args, **kwargs):
    try:
        return function(*args, **kwargs)
    except RecoverySafetyError:
        raise
    except (OSError, ValueError, KeyError, TypeError, psycopg2.Error):
        # Do not expose DB errors, connection strings or local patient filenames.
        raise RecoverySafetyError('recovery_verification_failed',
            'Provjera oporavka nije uspjela. Provjerite lokalno QA okruženje, dozvole i backup; instalacija je zaustavljena.') from None


def prepare_proof(plan, media_root):
    return _safe_call(_prepare_proof, plan, media_root)


def preflight(plan, database=None):
    """Read-only prerequisites, before maintenance activation or source backup."""
    return _safe_call(_preflight, plan, database)


def verify_proof(plan, *, check_live=False, completed_window=None, completed=False):
    return _safe_call(_verify_proof, plan, check_live=check_live,
                      completed_window=completed_window, completed=completed)


def assert_rollback_allowed(plan):
    # This precedes any service stop, file replacement or emergency/old restore.
    return verify_proof(plan, check_live=False)
