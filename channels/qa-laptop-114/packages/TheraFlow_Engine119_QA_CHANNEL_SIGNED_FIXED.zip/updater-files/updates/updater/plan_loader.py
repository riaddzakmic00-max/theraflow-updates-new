import hashlib
import json
import re
from pathlib import Path, PurePosixPath, PureWindowsPath

from packaging.requirements import InvalidRequirement, Requirement
from packaging.utils import canonicalize_name
from packaging.version import InvalidVersion, Version

from .plan_security import PlanSecurityError, load_service_key, verify_plan_signature
from theraflow.environment import canonical_env_path, production_mode
from theraflow.installed_paths import installed_paths
from theraflow.repair_baseline import REPAIR_BASELINE, UPDATER_ENGINE_VERSION
from .release_policy import verify_runtime_manifest
from theraflow.release_signing import ReleaseSignatureError


REQUIRED_FIELDS = {
    "session_id", "current_version", "target_version", "application_root", "staging_root",
    "payload_root", "backup_root", "database_backup_path", "config_backup_path",
    "preserve_paths", "replace_paths", "delete_paths", "migration_required",
    "collectstatic_required", "service_name", "health_check_url", "created_at",
    "package_sha256", "package_manifest_sha256", "python_executable", "canonical_env_path",
    "plan_schema_version", "plan_hmac_sha256", "package_url", "manifest_identity",
    "backup_identity",
    "installed_repair_build", "installed_updater_version",
    "payload_repair_build", "payload_updater_version",
    "component",
    "publisher_receipt",
}


class PlanValidationError(RuntimeError):
    pass


ENGINE_OWNED_FILES = frozenset({
    "updates/updater_service.py",
    "theraflow/repair_baseline.py",
    "theraflow/release_signing.py",
    "theraflow/installed_paths.py",
    "theraflow/environment.py",
    "install_runtime.bat",
    "install_runtime.ps1",
    "start_theraflow.bat",
    "verify_test_update.bat",
    "verify_test_update.ps1",
})
ENGINE_OWNED_DIRECTORIES = ("updates/updater/", "updates/services/", "service/")


def is_engine_owned_path(value):
    """The app release may contain UI and data migrations, never engine code."""
    name = str(safe_relative(value, "Package putanja")).casefold()
    return name in ENGINE_OWNED_FILES or any(
        name == prefix[:-1] or name.startswith(prefix)
        for prefix in ENGINE_OWNED_DIRECTORIES
    )


def deletes_engine_path(value):
    name = str(safe_relative(value, "Delete putanja")).casefold().rstrip("/")
    if is_engine_owned_path(name):
        return True
    return any(path.startswith(name + "/") for path in ENGINE_OWNED_FILES) or any(
        prefix.startswith(name + "/") for prefix in ENGINE_OWNED_DIRECTORIES
    )


def validate_application_boundary(manifest, payload):
    """Recheck in the privileged worker; a signed plan alone is insufficient."""
    if manifest.get("component") != "application":
        raise PlanValidationError("Paket nije označen kao zasebna aplikacijska nadogradnja.")
    if (str(manifest.get("payload_updater_version")) != UPDATER_ENGINE_VERSION
            or str(manifest.get("payload_repair_build")) != REPAIR_BASELINE):
        raise PlanValidationError("Aplikacijski paket nije kompatibilan s instaliranim engineom i repair baselineom.")
    for name in manifest.get("delete_paths", []):
        if deletes_engine_path(name):
            raise PlanValidationError("Aplikacijski paket pokušava obrisati komponentu enginea.")
    payload = Path(payload)
    for path in payload.rglob("*"):
        if path.is_file() and is_engine_owned_path(path.relative_to(payload).as_posix()):
            raise PlanValidationError("Aplikacijski paket pokušava zamijeniti komponentu enginea.")


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_local(path, label):
    path = Path(path)
    if not path.is_absolute() or str(path).startswith("\\\\"):
        raise PlanValidationError(f"{label} nije dozvoljena lokalna apsolutna putanja.")
    return path.resolve()


def child(path, parent, label):
    path, parent = safe_local(path, label), safe_local(parent, label)
    if path == parent or parent not in path.parents:
        raise PlanValidationError(f"{label} izlazi iz dozvoljenog direktorija.")
    return path


def safe_relative(value, label):
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise PlanValidationError(f"Neispravna {label}.")
    posix, windows = PurePosixPath(value), PureWindowsPath(value)
    if value == "." or posix.is_absolute() or windows.is_absolute() or windows.drive or ".." in posix.parts:
        raise PlanValidationError(f"Neispravna {label}.")
    return posix


def read_version(path):
    match = re.search(r"__version__\s*=\s*['\"]([^'\"]+)['\"]", Path(path).read_text(encoding="utf-8"))
    if not match:
        raise PlanValidationError("version.py nema validnu verziju.")
    return match.group(1)


def _json(path, label):
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError) as exc:
        raise PlanValidationError(f"{label} nije validan JSON.") from exc
    if not isinstance(value, dict):
        raise PlanValidationError(f"{label} nije JSON objekat.")
    return value


def load_and_validate(plan_path, rollback=False, recovery_only=False):
    if recovery_only and not rollback:
        raise PlanValidationError(
            "Recovery-only plan validation je dozvoljena samo za rollback."
        )
    plan_path = safe_local(plan_path, "Install plan")
    plan = _json(plan_path, "Install plan")
    if REQUIRED_FIELDS - plan.keys():
        raise PlanValidationError("Install plan nema sva obavezna polja.")
    if production_mode():
        layout = installed_paths()
        expected_plan = (
            layout.sessions / str(plan.get("session_id") or "") / "install_plan.json"
        ).resolve()
        if plan_path != expected_plan:
            raise PlanValidationError(
                "Install plan nije na kanonskoj ProgramData update sessions putanji."
            )
        data_root = layout.root.resolve()
        service_key = layout.updater_service_key
    else:
        try:
            data_root = plan_path.parents[3]
        except IndexError as exc:
            raise PlanValidationError("Install plan putanja nije validna.") from exc
        service_key = data_root / "config" / "updater_service.key"
    try:
        verify_plan_signature(plan, load_service_key(service_key))
    except PlanSecurityError as exc:
        raise PlanValidationError(str(exc)) from exc
    session_root = plan_path.parent
    sessions_root = session_root.parent
    if sessions_root != (data_root / "updates" / "sessions").resolve():
        raise PlanValidationError("Update sessions root nije kanonski.")
    canonical_env = safe_local(plan["canonical_env_path"], "Canonical env")
    if canonical_env != canonical_env_path():
        raise PlanValidationError("Canonical env putanja nije očekivana ProgramData konfiguracija.")
    state_path = sessions_root / f"{plan['session_id']}.json"
    state = _json(state_path, "Update state")
    if state.get("session_id") != plan["session_id"] or session_root.name != plan["session_id"]:
        raise PlanValidationError("Session identitet se ne podudara.")
    if state.get("install_plan_sha256") != sha256_file(plan_path):
        raise PlanValidationError("Install plan je izmijenjen nakon pripreme.")
    manifest_snapshot = state.get("manifest_snapshot") or {}
    try:
        publisher = verify_runtime_manifest(manifest_snapshot, phase='recovery_plan' if rollback else 'install_plan',
            recovery_receipt=plan['publisher_receipt'] if rollback else None)
        if publisher['manifest_sha256'] != plan['publisher_receipt'].get('manifest_sha256'):
            raise ReleaseSignatureError('Publisher receipt differs from HMAC plan')
    except ReleaseSignatureError as exc:
        raise PlanValidationError('Porijeklo install plana nije potvrđeno.') from exc
    from updates.services.manifest_identity import manifest_fingerprint
    if (
        plan.get("package_url") != str(manifest_snapshot.get("download_url", ""))
        or plan.get("manifest_identity") != manifest_fingerprint(manifest_snapshot)
    ):
        raise PlanValidationError("Install plan ne odgovara URL-u i identitetu manifesta.")
    app = safe_local(plan["application_root"], "Application root")
    if str(app) != str(Path(state.get("application_root", "")).resolve()) or not (app / "manage.py").is_file():
        raise PlanValidationError("Application root nije očekivana instalacija.")
    staging = child(plan["staging_root"], data_root / "updates" / "staging", "Staging root")
    payload = child(plan["payload_root"], staging, "Payload root")
    backup = child(plan["backup_root"], data_root / "backups" / "updates", "Backup root")
    if not payload.is_dir() or not backup.is_dir():
        raise PlanValidationError("Staging ili backup direktorij ne postoji.")
    if state.get("service_name") != plan["service_name"] or state.get("health_check_url") != plan["health_check_url"]:
        raise PlanValidationError("Servisna konfiguracija se ne podudara.")
    current_version = read_version(app / "theraflow" / "version.py")
    target_version = read_version(payload / "theraflow" / "version.py")
    package_manifest_path = staging / "theraflow-update.json"
    package_manifest = _json(package_manifest_path, "Package manifest")
    allowed_current = {plan["current_version"], plan["target_version"]} if rollback else {plan["current_version"]}
    if current_version not in allowed_current or target_version != plan["target_version"] or str(package_manifest.get("version")) != plan["target_version"]:
        raise PlanValidationError("Verzije install plana, aplikacije i staginga se ne podudaraju.")
    if sha256_file(package_manifest_path) != plan["package_manifest_sha256"]:
        raise PlanValidationError("Package manifest SHA-256 nije ispravan.")
    if package_manifest.get("component") != plan["component"]:
        raise PlanValidationError("Komponenta paketa i install plana se ne podudaraju.")
    if not rollback:
        validate_application_boundary(package_manifest, payload)
    try:
        installed_repair = Version(REPAIR_BASELINE)
        installed_engine = Version(UPDATER_ENGINE_VERSION)
        recorded_repair = Version(str(plan["installed_repair_build"]))
        recorded_engine = Version(str(plan["installed_updater_version"]))
        if recovery_only:
            # A newer repair is allowed to finish recovery for an older signed
            # plan, but never to apply that older payload.  All canonical path,
            # HMAC, package, backup, version and session gates above still run.
            if recorded_repair > installed_repair:
                raise PlanValidationError(
                    "Recovery plan tvrdi noviji repair baseline od instaliranog."
                )
            if recorded_engine > installed_engine:
                raise PlanValidationError(
                    "Recovery plan tvrdi noviji updater engine od instaliranog."
                )
        else:
            if recorded_repair != installed_repair:
                raise PlanValidationError("Install plan repair baseline više nije aktivan.")
            if recorded_engine != installed_engine:
                raise PlanValidationError("Install plan updater engine više nije aktivan.")
            if Version(str(plan["payload_repair_build"])) < installed_repair:
                raise PlanValidationError("Payload pokušava vratiti stariji repair baseline.")
            if Version(str(plan["payload_updater_version"])) < installed_engine:
                raise PlanValidationError("Payload pokušava vratiti stariji updater engine.")
    except InvalidVersion as exc:
        raise PlanValidationError("Install plan compatibility verzija nije ispravna.") from exc
    if (
        str(package_manifest.get("payload_repair_build"))
        != str(plan["payload_repair_build"])
        or str(package_manifest.get("payload_updater_version"))
        != str(plan["payload_updater_version"])
    ):
        raise PlanValidationError("Package i install plan compatibility identitet se ne podudaraju.")
    package_path = safe_local(state.get("package_path", ""), "Update paket")
    if package_path.parent != data_root / "updates" / "packages" or not package_path.is_file() or sha256_file(package_path) != plan["package_sha256"]:
        raise PlanValidationError("Update paket SHA-256 nije ispravan.")
    db_path = safe_local(plan["database_backup_path"], "Database backup")
    config_path = safe_local(plan["config_backup_path"], "Config backup")
    metadata = _json(backup / "backup_metadata.json", "Backup metadata")
    if not db_path.is_file() or metadata.get("validation") != "pg_restore_list_passed" or sha256_file(db_path) != metadata.get("dump_sha256"):
        raise PlanValidationError("Database backup nije validiran.")
    if not config_path.is_file():
        raise PlanValidationError("Config backup nije pronađen.")
    backup_identity = plan.get("backup_identity") or {}
    if (
        backup_identity.get("database_sha256") != sha256_file(db_path)
        or backup_identity.get("config_sha256") != sha256_file(config_path)
    ):
        raise PlanValidationError("Install plan backup identitet nije validan.")
    for key in ("preserve_paths", "replace_paths", "delete_paths"):
        if not isinstance(plan[key], list):
            raise PlanValidationError(f"{key} mora biti lista.")
        plan[key] = [str(safe_relative(item, key)) for item in plan[key]]
    python = safe_local(plan["python_executable"], "Python runtime")
    if not python.is_file():
        raise PlanValidationError("Python runtime nije pronađen.")
    plan.update({"_plan_path": str(plan_path), "_state_path": str(state_path), "_data_root": str(data_root), "_package_path": str(package_path)})
    from .recovery_safety import verify_proof
    completed_window = state.get('completed_rollback_window') if rollback else None
    if rollback and state.get('completed_rollback_intent') and not completed_window:
        from . import recovery_safety, maintenance
        observed = recovery_safety.inspect_guard(plan, require_active=False)
        if observed['active']:
            maintenance.assert_active(plan)
            completed_window = observed
    if completed_window:
        # A terminal rollback may already have released this exact new epoch.
        if state.get('rollback_completed_at'):
            from .recovery_safety import inspect_guard
            observed = inspect_guard(plan, require_active=False)
            completed_window = dict(completed_window, active=observed['active'])
        verify_proof(plan, completed_window=completed_window)
    else:
        verify_proof(plan, completed=bool(rollback and (
            state.get('status') == 'update_completed' or state.get('completed_rollback_intent'))))
    return plan, state


def _dependency_snapshot(path):
    path = Path(path)
    snapshot = {
        "path": str(path),
        "exists": path.is_file(),
        "raw_sha256": None,
        "fingerprint": None,
        "packages": {},
        "errors": [],
    }
    if not snapshot["exists"]:
        return snapshot

    snapshot["raw_sha256"] = sha256_file(path)
    try:
        text = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        snapshot["errors"].append(f"requirements se ne može pročitati: {type(exc).__name__}")
        return snapshot

    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            requirement = Requirement(line)
        except InvalidRequirement:
            snapshot["errors"].append(f"neispravna stavka u redu {line_number}")
            continue
        name = canonicalize_name(requirement.name)
        normalized = {
            "extras": sorted(canonicalize_name(extra) for extra in requirement.extras),
            "specifier": sorted(str(item) for item in requirement.specifier),
            "marker": str(requirement.marker) if requirement.marker else "",
            "url": requirement.url or "",
        }
        if name in snapshot["packages"]:
            snapshot["errors"].append(f"dupla zavisnost: {name}")
            continue
        snapshot["packages"][name] = normalized

    canonical = json.dumps(
        snapshot["packages"],
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    snapshot["fingerprint"] = hashlib.sha256(canonical).hexdigest()
    return snapshot


def _offline_dependency_details(plan):
    root = Path(plan["payload_root"]) / "offline_dependencies"
    wheels = sorted(root.glob("*.whl")) if root.is_dir() else []
    entries = [f"{wheel.name}:{sha256_file(wheel)}" for wheel in wheels]
    fingerprint = hashlib.sha256("\n".join(entries).encode("utf-8")).hexdigest() if entries else None
    return {
        "expected_path": str(root),
        "exists": root.is_dir(),
        "wheel_count": len(wheels),
        "sha256": fingerprint,
    }


def dependency_diagnostics(plan):
    current = _dependency_snapshot(Path(plan["application_root"]) / "requirements.txt")
    target = _dependency_snapshot(Path(plan["payload_root"]) / "requirements.txt")
    current_packages = current["packages"]
    target_packages = target["packages"]
    added = sorted(set(target_packages) - set(current_packages))
    removed = sorted(set(current_packages) - set(target_packages))
    changed = sorted(
        name
        for name in set(current_packages) & set(target_packages)
        if current_packages[name] != target_packages[name]
    )
    offline = _offline_dependency_details(plan)

    if not target["exists"]:
        supported = True
        reason = "Update payload ne mijenja requirements.txt."
    elif not current["exists"]:
        supported = False
        reason = "Instalirani requirements.txt nije pronađen."
    elif current["errors"] or target["errors"]:
        supported = False
        reason = "Dependency fajl nije moguće sigurno normalizovati."
    elif not added and not removed and not changed:
        supported = True
        reason = (
            "Python zavisnosti su semantički identične; razlika u kodiranju "
            "ili završecima redova se ignoriše."
        )
    else:
        supported = False
        reason = (
            "Stvarna promjena Python zavisnosti je pronađena, a ovaj updater "
            "nema validiran offline dependency install plan."
        )

    return {
        "supported": supported,
        "reason": reason,
        "current": current,
        "target": target,
        "added": added,
        "removed": removed,
        "changed": changed,
        "offline": offline,
    }


def dependencies_supported(plan):
    return dependency_diagnostics(plan)["supported"]


def validate_database_backup(plan):
    backup = Path(plan["backup_root"])
    db_path = Path(plan["database_backup_path"])
    metadata = _json(backup / "backup_metadata.json", "Backup metadata")
    if not db_path.is_file() or metadata.get("validation") != "pg_restore_list_passed" or sha256_file(db_path) != metadata.get("dump_sha256"):
        raise PlanValidationError("Database backup više nije validan.")
    return True
