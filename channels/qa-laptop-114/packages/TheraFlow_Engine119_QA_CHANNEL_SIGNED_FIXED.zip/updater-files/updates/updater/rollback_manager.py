import json
import os
from datetime import datetime, timezone
from pathlib import Path

from . import config_restore, database_restore, django_commands, health_check, history_writer, service_manager, snapshot_restore, windows_metadata
from .plan_loader import read_version
from .state_writer import read_state, safe_message, trace_update_step, write_state


class RollbackError(RuntimeError):
    def __init__(self, code, message, failed_step="rollback_recovery"):
        self.code = code
        self.failed_step = failed_step
        super().__init__(message)


def rollback_type_for(plan, state):
    started = state.get("migration_started")
    completed = state.get("migration_completed")
    # Stvarno izvrĹˇeno stanje je autoritativno. Updater uvijek poziva
    # ``migrate --noinput`` ÄŤak i kada manifest tvrdi da migracija nije
    # potrebna, pa se nakon zapoÄŤete migracije mora vratiti i baza.
    if started is True or completed is True:
        return "full"
    if started is False and completed is False:
        return "file-only"
    if started is None and completed is None:
        # Phase 3 writes both explicit false values before changing files.
        return "full"
    return "full"


def should_rollback(state):
    return bool(state.get("files_changed")) and not state.get("rollback_started_at")


def is_resumable_file_only_recovery(plan, state):
    """Recognize only the proven post-file-restore/pre-migration failure shape."""
    return all((
        state.get("status") == "manual_recovery_required",
        state.get("manual_action_required") is True,
        state.get("files_changed") is True,
        state.get("files_restored") is True,
        state.get("migration_started") is False,
        state.get("migration_completed") is False,
        state.get("database_restored") is False,
        state.get("rollback_type") == "file-only",
        state.get("previous_version_restored") == plan.get("current_version"),
    ))


def is_legacy_identity_failure_recovery(plan, state):
    """Match only the proven pre-lock LocalSystem identity failure shape.

    This is deliberately narrower than the ordinary resumable file-only state.
    A missing lock for any other failure remains fail-closed.
    """

    return is_resumable_file_only_recovery(plan, state) and all((
        str(plan.get("session_id") or "") == str(state.get("session_id") or ""),
        str(plan.get("current_version") or "") == "1.0.0",
        str(plan.get("target_version") or "") == "1.0.2",
        str(plan.get("installed_repair_build") or "") == "3.4.17",
        str(plan.get("installed_updater_version") or "") == "1.1.0",
        state.get("failed_step") == "django_check",
        state.get("last_attempted_step") == "django_check",
        state.get("last_successful_step") == "configuration_validated",
        state.get("rollback_trigger") == "automatic",
        state.get("execution_owner") == "TheraFlowUpdaterService",
        state.get("config_restored") is False,
        state.get("install_completed_at") is None,
        state.get("error_code") == "rollback_failed",
        state.get("rollback_error_code") == "rollback_failed",
        state.get("error_message") == "No username set in the environment",
        state.get("rollback_error_message") == "No username set in the environment",
    ))


def _require_owned_rollback_lock(plan, state_path):
    lock = Path(state_path).resolve().parent / "rollback.lock"
    try:
        owner = lock.read_text(encoding="utf-8").strip()
    except FileNotFoundError as exc:
        raise RollbackError(
            "rollback_recovery_lock_missing",
            "Kontrolisani recovery nema pripadajuÄ‡i rollback lock.",
        ) from exc
    except OSError as exc:
        raise RollbackError(
            "rollback_recovery_lock_unreadable",
            "Kontrolisani recovery ne moĹľe potvrditi rollback lock.",
        ) from exc
    if owner != str(plan["session_id"]):
        raise RollbackError(
            "rollback_recovery_lock_identity_mismatch",
            "Rollback lock pripada drugom update sessionu.",
        )
    return lock


def _field_recovery_audit(
    plan, state, *, outcome, code="", failed_step="", required=False
):
    """Append-only safe recovery evidence; never replace the original report."""
    destination = Path(plan["backup_root"]) / "field_recovery_audit.json"
    try:
        existing = json.loads(destination.read_text(encoding="utf-8")) if destination.is_file() else {}
        attempts = list(existing.get("attempts") or [])
    except (OSError, ValueError, TypeError):
        attempts = []
    attempts.append({
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "session_id": str(plan.get("session_id") or ""),
        "outcome": outcome,
        "error_code": code,
        "failed_step": failed_step,
        "original_error_code": str(
            state.get("rollback_error_code") or state.get("error_code") or ""
        ),
        "safe_error_message": safe_message(
            state.get("rollback_error_message") or state.get("error_message") or ""
        ),
        "status": state.get("status"),
        "service_status": state.get("service_status"),
        "files_restored": state.get("files_restored"),
        "migration_started": state.get("migration_started"),
        "migration_completed": state.get("migration_completed"),
        "database_restored": state.get("database_restored"),
        "backup_evidence_preserved": True,
        "snapshot_restore_repeated": False,
    })
    report = {
        "schema_version": 1,
        "session_id": str(plan.get("session_id") or ""),
        "attempts": attempts,
    }
    temporary = destination.with_suffix(".json.tmp")
    try:
        temporary.write_text(
            json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        os.replace(temporary, destination)
    except OSError as exc:
        # Audit write failure is separately logged, but does not mask the
        # original recovery exception or remove evidence/lock files.
        trace_update_step(
            "rollback_recovery_audit",
            "FAIL",
            session_id=plan.get("session_id", "none"),
            function_name="updates.updater.rollback_manager._field_recovery_audit",
            paths={"audit": destination},
            message="Field recovery audit nije bilo moguÄ‡e zapisati.",
            data_root=plan.get("data_root"),
        )
        if required:
            raise RollbackError(
                "rollback_recovery_audit_write_failed",
                "Field recovery audit nije bilo moguÄ‡e trajno zapisati.",
                "rollback_recovery_audit",
            ) from exc


def _validate_field_recovery_evidence(plan):
    required_payload = (
        Path(plan["application_root"]) / "manage.py",
        Path(plan["application_root"]) / "run_theraflow.py",
        Path(plan["application_root"]) / "theraflow" / "version.py",
        Path(plan["application_root"]) / "updates" / "updater" / "rollback_manager.py",
        Path(plan["application_root"]) / "updates" / "updater" / "django_commands.py",
        Path(plan["application_root"]) / "updates" / "services" / "crash_recovery.py",
    )
    missing = [path.name for path in required_payload if not path.is_file()]
    if missing:
        raise RollbackError(
            "rollback_recovery_payload_incomplete",
            "Finalni repair payload nije potpun.",
            "rollback_recovery_payload_validation",
        )
    evidence = {
        "database_backup": Path(plan.get("database_backup_path", "")),
        "config_backup": Path(plan.get("config_backup_path", "")),
        "snapshot_manifest": Path(plan.get("backup_root", ""))
        / "application_snapshot_manifest.json",
    }
    missing_evidence = [name for name, path in evidence.items() if not path.is_file()]
    if missing_evidence:
        raise RollbackError(
            "rollback_recovery_evidence_missing",
            "Nedostaje validirani recovery dokaz: " + ", ".join(missing_evidence),
            "rollback_recovery_evidence_validation",
        )
    application_env = Path(plan["application_root"]) / ".env"
    if application_env.exists():
        raise RollbackError(
            "rollback_recovery_noncanonical_env",
            "Recovery je pronaĹˇao nedozvoljenu kopiju .env unutar aplikacijskog payload-a.",
            "rollback_recovery_configuration_validation",
        )
    return evidence


def _require_safe_recovery(plan, state_path):
    from .recovery_safety import assert_rollback_allowed, RecoverySafetyError
    try:
        assert_rollback_allowed(plan)
    except RecoverySafetyError as exc:
        write_state(state_path, status="manual_recovery_required", manual_action_required=True,
                    current_step=str(exc), error_code=exc.code, error_message=str(exc),
                    database_restored=False)
        raise RollbackError(exc.code, str(exc)) from None


def resume_file_only_recovery(
    plan,
    state_path,
    *,
    release_lock=True,
    recovery_lock=None,
    maintenance_window=False,
):
    """Finish a proven file-only rollback without restoring files a second time."""
    _require_safe_recovery(plan, state_path)
    state_path = Path(state_path).resolve()
    state = read_state(state_path)
    if not is_resumable_file_only_recovery(plan, state):
        error = RollbackError(
            "rollback_recovery_state_not_eligible",
            "Session nije u dokazano sigurnom file-only recovery stanju.",
            "rollback_recovery_state_validation",
        )
        trace_update_step(
            "rollback_recovery",
            "FAIL",
            session_id=plan.get("session_id", "none"),
            function_name="updates.updater.rollback_manager.resume_file_only_recovery",
            paths={"state": state_path},
            exception=error,
            data_root=plan.get("data_root"),
        )
        raise error
    try:
        if recovery_lock is None:
            lock = _require_owned_rollback_lock(plan, state_path)
            lock_kind = "rollback_lock_v1"
            lock_fingerprint = ""
        else:
            recovery_lock.verify_owned()
            lock = recovery_lock.path
            lock_kind = "exclusive_legacy_recovery_lock"
            lock_fingerprint = recovery_lock.nonce_sha256
    except Exception as exc:
        code = getattr(exc, "code", None) or "rollback_recovery_lock_failed"
        failed_step = getattr(exc, "failed_step", None)
        if not failed_step or failed_step == "rollback_recovery":
            failed_step = "rollback_recovery_lock_validation"
        _field_recovery_audit(
            plan,
            state,
            outcome="manual_recovery_required",
            code=code,
            failed_step=failed_step,
        )
        trace_update_step(
            "rollback_recovery",
            "FAIL",
            session_id=plan.get("session_id", "none"),
            function_name="updates.updater.rollback_manager.resume_file_only_recovery",
            paths={"state": state_path, "lock": state_path.parent / "rollback.lock"},
            exception=exc,
            message=f"error_code={code} failed_step={failed_step} lock_removed=false",
            data_root=plan.get("data_root"),
        )
        raise
    service_state = str(state.get("service_status") or "UNKNOWN")
    failed_step = "rollback_recovery_evidence_validation"
    try:
        trace_update_step(
            "rollback_recovery",
            "BEGIN",
            session_id=plan.get("session_id", "none"),
            function_name="updates.updater.rollback_manager.resume_file_only_recovery",
            paths={
                "state": state_path,
                "application_root": plan.get("application_root"),
                "backup_root": plan.get("backup_root"),
            },
            message=(
                "file_only=true snapshot_restore_repeated=false "
                f"lock_release=last lock_kind={lock_kind} "
                f"lock_nonce_sha256={lock_fingerprint or 'not_applicable'} "
                f"maintenance_window={str(bool(maintenance_window)).lower()}"
            ),
            data_root=plan.get("data_root"),
        )
        _validate_field_recovery_evidence(plan)
        if recovery_lock is not None:
            _field_recovery_audit(
                plan,
                state,
                outcome="legacy_recovery_evidence_validated",
                code=str(
                    state.get("rollback_error_code")
                    or state.get("error_code")
                    or "rollback_failed"
                ),
                failed_step=str(state.get("failed_step") or "django_check"),
                required=True,
            )
        write_state(
            state_path,
            status="rollback_application_check",
            current_step="Provjera veÄ‡ vraÄ‡ene prethodne verzije",
            progress_percent=82,
            last_attempted_step="rollback_recovery_application_check",
        )
        failed_step = "rollback_recovery_version_validation"
        restored_version = read_version(
            Path(plan["application_root"]) / "theraflow" / "version.py"
        )
        if restored_version != plan["current_version"]:
            raise RollbackError(
                "rollback_version_mismatch",
                "Prethodna verzija nije ispravno vraÄ‡ena.",
            )
        failed_step = "rollback_recovery_django_schema_validation"
        django_commands.validate_recovered_application(plan)
        # snapshot_restore already restored journal-owned static assets exactly.

        if maintenance_window:
            # The repair installer owns the maintenance window.  The legacy
            # session must be durably closed before it starts application,
            # updater and scheduler services and performs the final health gate.
            service_state = "STOPPED"
            health_status = "deferred_to_installer_final_gate"
            last_successful_step = "rollback_recovery_application_check"
        else:
            write_state(
                state_path,
                status="rollback_service_starting",
                current_step="Pokretanje veÄ‡ vraÄ‡ene prethodne verzije",
                progress_percent=90,
                last_successful_step="rollback_recovery_application_check",
            )
            failed_step = "rollback_recovery_service_start"
            service_manager.start(plan["service_name"])
            service_state = "RUNNING"
            write_state(
                state_path,
                status="rollback_health_check",
                current_step="Health-check veÄ‡ vraÄ‡ene prethodne verzije",
                progress_percent=95,
                service_status=service_state,
            )
            failed_step = "rollback_recovery_health_check"
            health_check.check(plan["health_check_url"], plan["current_version"])
            health_status = "health_check_passed"
            last_successful_step = "rollback_recovery_health_check"
        failed_step = "rollback_recovery_windows_metadata"
        metadata_report = windows_metadata.restore(
            plan["application_root"],
            state.get("windows_metadata_previous"),
        )
        completed_at = datetime.now(timezone.utc).isoformat()
        final = write_state(
            state_path,
            status="rollback_completed",
            is_active=False,
            current_step="Prethodna verzija je sigurno vraÄ‡ena",
            rollback_completed_at=completed_at,
            completed_at=completed_at,
            install_completed_at=completed_at,
            progress_percent=100,
            health_check_status=health_status,
            rollback_error_code="",
            rollback_error_message="",
            error_code="",
            error_message="",
            manual_action_required=False,
            service_status=service_state,
            updater_pid=None,
            last_successful_step=last_successful_step,
            step_completed_at=completed_at,
            windows_metadata_status=(
                "restored" if metadata_report.get("restored") else "not_applicable"
            ),
        )
        _field_recovery_audit(
            plan, final, outcome="rollback_completed", required=True
        )
        history_writer.write_history_event(plan, final, "failed_rolled_back")
        from . import maintenance
        maintenance.finish(plan, 'verified_rollback')
        if release_lock:
            # The lock is deliberately the final durable artifact removed.
            if recovery_lock is None:
                lock.unlink()
            else:
                recovery_lock.release()
        return final
    except Exception as exc:
        code = getattr(exc, "code", None) or "rollback_recovery_failed"
        failed_step = getattr(exc, "failed_step", None) or failed_step
        failed_at = datetime.now(timezone.utc).isoformat()
        failed = write_state(
            state_path,
            status="manual_recovery_required",
            is_active=True,
            current_step="Kontrolisani recovery nije zavrĹˇen",
            rollback_error_code=code,
            rollback_error_message=str(exc),
            error_code=code,
            error_message=str(exc),
            manual_action_required=True,
            service_status=service_state,
            failed_step=failed_step,
            last_attempted_step=failed_step,
            step_completed_at=failed_at,
        )
        _field_recovery_audit(
            plan,
            failed,
            outcome="manual_recovery_required",
            code=code,
            failed_step=failed_step,
        )
        trace_update_step(
            "rollback_recovery",
            "FAIL",
            session_id=plan.get("session_id", "none"),
            function_name="updates.updater.rollback_manager.resume_file_only_recovery",
            paths={"state": state_path, "backup_root": plan.get("backup_root")},
            exception=exc,
            message=f"error_code={code} failed_step={failed_step} evidence_preserved=true lock_preserved=true",
            data_root=plan.get("data_root"),
        )
        # Never remove the lock, backup, audit, session or staging evidence on
        # a failed recovery attempt.
        if isinstance(exc, RollbackError):
            raise
        raise RollbackError(code, str(exc), failed_step) from exc


def _recovery_report(plan, state, code, service_state="UNKNOWN"):
    report = {
        "session_id": plan.get("session_id"),
        "source_version": plan.get("current_version"),
        "target_version": plan.get("target_version"),
        "last_successful_step": state.get("last_successful_step"),
        "service_state": service_state,
        "application_version": None,
        "database_backup_status": "available_not_proof_of_restore" if Path(plan.get("database_backup_path", "")).is_file() else "missing",
        "snapshot_status": "available" if (Path(plan.get("backup_root", "")) / "application_snapshot_manifest.json").is_file() else "missing",
        "config_backup_status": "available" if Path(plan.get("config_backup_path", "")).is_file() else "missing",
        "emergency_backup_status": "available" if (Path(plan.get("backup_root", "")) / "pre_rollback_database.dump").is_file() else "missing",
        "recommended_next_step": "Pregledati saÄŤuvane rollback artefakte prije ruÄŤnog oporavka.",
        "error_codes": [code],
        "database_restore_report": str(Path(plan["backup_root"]) / "database_restore_result.json"),
        "database_restored": bool(state.get("database_restored")),
    }
    try:
        report["application_version"] = read_version(Path(plan["application_root"]) / "theraflow" / "version.py")
    except Exception:
        report["application_version"] = "unknown"
    destination = Path(plan["backup_root"]) / "recovery_report.json"
    destination.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


def execute(plan, state_path, trigger="automatic", reason="update_failed"):
    state_path = Path(state_path).resolve()
    state = read_state(state_path)
    sessions_root = state_path.parent
    lock = sessions_root / "rollback.lock"
    if state.get("rollback_completed_at"):
        return state
    _require_safe_recovery(plan, state_path)
    if trigger == "manual" and is_resumable_file_only_recovery(plan, state):
        return resume_file_only_recovery(plan, state_path)
    if trigger == "manual" and lock.is_file():
        try:
            if lock.read_text(encoding="utf-8").strip() == plan["session_id"]:
                lock.unlink()
        except OSError:
            pass
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(descriptor, str(plan["session_id"]).encode("ascii"))
        os.close(descriptor)
    except FileExistsError as exc:
        raise RollbackError("rollback_locked", "Rollback je veÄ‡ pokrenut.") from exc

    rollback_type = rollback_type_for(plan, state)
    started_at = datetime.now(timezone.utc).isoformat()
    write_state(
        state_path, status="rollback_starting", current_step="Pokretanje sigurnog oporavka",
        rollback_type=rollback_type, rollback_reason=safe_message(reason), rollback_trigger=trigger,
        rollback_started_at=started_at, manual_action_required=False, progress_percent=10,
        database_restored=False,
    )
    service_state = "UNKNOWN"
    database_context = None
    try:
        write_state(state_path, status="rollback_validating", current_step="Provjera rollback artefakata", progress_percent=15)
        snapshot_restore.validate_snapshot(plan)
        if rollback_type == "full":
            database_context = database_restore.validate_original_backup(plan)

        write_state(state_path, status="rollback_service_stopping", current_step="Zaustavljanje servisa", progress_percent=20)
        service_manager.stop(plan["service_name"])
        service_state = "STOPPED"

        write_state(state_path, status="rollback_files_restoring", current_step="VraÄ‡anje aplikacijskih fajlova", progress_percent=35)
        snapshot_restore.restore_snapshot(plan)
        write_state(state_path, files_restored=True, previous_version_restored=plan["current_version"], last_successful_step="application_files_restored")

        write_state(state_path, status="rollback_config_restoring", current_step="Provjera lokalne konfiguracije", progress_percent=50)
        config_report = config_restore.restore_config(plan)
        write_state(state_path, config_restored=bool(config_report["restored"]), last_successful_step="configuration_validated")

        if rollback_type == "full":
            write_state(state_path, status="rollback_database_backing_up", current_step="Emergency backup baze", progress_percent=58)
            dump, _metadata, database = database_context
            emergency = database_restore.create_emergency_backup(plan, database)
            write_state(
                state_path, status="rollback_database_restoring", current_step="VraÄ‡anje baze prije aĹľuriranja",
                emergency_backup_path=str(emergency), progress_percent=64,
            )
            database_restore.restore_original_database(plan, dump, database)
            write_state(state_path, database_restored=True, progress_percent=72, last_successful_step="database_restored")
        else:
            write_state(state_path, database_restored=False)

        write_state(state_path, status="rollback_application_check", current_step="Provjera prethodne verzije", progress_percent=80)
        if read_version(Path(plan["application_root"]) / "theraflow" / "version.py") != plan["current_version"]:
            raise RollbackError("rollback_version_mismatch", "Prethodna verzija nije ispravno vraÄ‡ena.")
        from . import maintenance
        maintenance.refresh(plan)
        django_commands.django_check(plan)
        # Do not regenerate static assets after their exact snapshot restoration.

        write_state(state_path, status="rollback_service_starting", current_step="Pokretanje prethodne verzije", progress_percent=90)
        service_manager.start(plan["service_name"])
        service_state = "RUNNING"
        write_state(state_path, status="rollback_health_check", current_step="Provjera prethodne verzije", progress_percent=95, service_status="RUNNING")
        health_check.check(plan["health_check_url"], plan["current_version"])
        metadata_report = windows_metadata.restore(
            plan["application_root"],
            state.get("windows_metadata_previous"),
        )
        completed_at = datetime.now(timezone.utc).isoformat()
        final = write_state(
            state_path, status="rollback_completed", is_active=False,
            current_step="Prethodna verzija je sigurno vraÄ‡ena",
            rollback_completed_at=completed_at, completed_at=completed_at, progress_percent=100,
            health_check_status="health_check_passed", rollback_error_code="",
            rollback_error_message="", manual_action_required=False, service_status="RUNNING",
            install_completed_at=completed_at, updater_pid=None,
            windows_metadata_status=("restored" if metadata_report.get("restored") else "not_applicable"),
        )
        history_writer.write_history_event(plan, final, "failed_rolled_back")
        from . import maintenance
        maintenance.finish(plan, 'verified_rollback')
        lock.unlink(missing_ok=True)
        return final
    except Exception as exc:
        completed_at = datetime.now(timezone.utc).isoformat()
        latest_state = read_state(state_path)
        code = getattr(exc, "code", None) or (
            "rollback_files_failed" if isinstance(exc, snapshot_restore.SnapshotRestoreError)
            else "database_restore_failed" if isinstance(exc, database_restore.DatabaseRestoreError)
            else "rollback_failed"
        )
        state = write_state(
            state_path, status="manual_recovery_required", current_step="Potrebna ruÄŤna intervencija",
            rollback_error_code=code, rollback_error_message=str(exc), error_code=code,
            error_message=str(exc), manual_action_required=True, service_status=service_state,
            failed_step=latest_state.get("last_attempted_step") or latest_state.get("status") or "rollback",
            completed_at=completed_at, step_completed_at=completed_at,
        )
        history_writer.write_history_event(plan, state, "failed_manual_recovery")
        _recovery_report(plan, state, code, service_state)
        raise RollbackError(code, str(exc)) from exc
