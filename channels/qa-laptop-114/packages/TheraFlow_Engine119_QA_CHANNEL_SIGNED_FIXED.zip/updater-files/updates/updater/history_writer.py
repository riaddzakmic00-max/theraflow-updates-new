import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .state_writer import safe_message


def write_history_event(plan, state, status):
    event = {
        "session_id": plan["session_id"],
        "source_version": plan["current_version"],
        "target_version": plan["target_version"],
        "status": status,
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "rollback_type": state.get("rollback_type", ""),
        "rollback_result": state.get("status", ""),
        "final_active_version": state.get("previous_version_restored") or plan["target_version"],
        "safe_error_summary": safe_message(state.get("rollback_error_message") or state.get("error_message") or ""),
    }
    destination = Path(plan["backup_root"]) / "update_history_event.json"
    # Keep every terminal event even when the latest-event compatibility file
    # is replaced by a later intentional rollback report.
    if not re.fullmatch(r'[a-z_]+', status):
        raise ValueError('Invalid update history status')
    archive = Path(plan['backup_root']) / 'update_history_events'
    archive.mkdir(exist_ok=True)
    immutable = archive / (event['recorded_at'].replace(':','-') + '_' + status + '_' + uuid.uuid4().hex + '.json')
    with immutable.open('x', encoding='utf-8') as stream:
        json.dump(event, stream, indent=2, ensure_ascii=False)
        stream.flush();os.fsync(stream.fileno())
    temporary = destination.with_suffix(".json.tmp")
    with temporary.open('w', encoding='utf-8') as stream:
        json.dump(event, stream, indent=2, ensure_ascii=False)
        stream.flush();os.fsync(stream.fileno())
    os.replace(temporary, destination)
    return destination
