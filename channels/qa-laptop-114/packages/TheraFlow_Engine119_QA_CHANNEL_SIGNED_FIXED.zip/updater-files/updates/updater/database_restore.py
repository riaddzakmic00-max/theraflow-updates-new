import json
import os
import re
import subprocess
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .plan_loader import sha256_file


class DatabaseRestoreError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def _env_file(path):
    values = {}
    path = Path(path)
    if not path.is_file():
        return values
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _executable(name, plan=None):
    configured = (plan or {}).get("postgres_tools", {}).get(name)
    if configured:
        configured = Path(configured).resolve()
        if configured.is_file():
            return str(configured)
    if plan and plan.get("application_root"):
        candidate = Path(plan["application_root"]).resolve().parent / "runtime" / "postgresql" / "bin" / f"{name}.exe"
        if candidate.is_file():
            return str(candidate)
    raise DatabaseRestoreError("postgres_tool_missing", f"PostgreSQL alat {name} nije pronađen.")


def _database(plan, metadata):
    from .maintenance import environment
    values = _env_file(plan["canonical_env_path"])
    expected = str(metadata.get("database_name") or "")
    actual = values.get("DB_NAME", expected or "theraflow")
    if not expected or actual != expected:
        raise DatabaseRestoreError("database_identity_mismatch", "Database backup ne odgovara lokalnoj bazi.")
    if "=" in actual or "://" in actual:
        raise DatabaseRestoreError("database_identity_mismatch", "Naziv baze ne smije biti connection string.")
    return {
        "name": actual,
        "user": values.get("DB_USER", "theraflow_user"),
        "password": values.get("DB_PASSWORD", ""),
        "host": values.get("DB_HOST", "127.0.0.1"),
        "port": values.get("DB_PORT", "5433"),
        "maintenance_options": environment(plan)['PGOPTIONS'],
    }


def _run(command, database, timeout=900, runner=None):
    env = {key: os.environ[key] for key in ("SystemRoot", "WINDIR", "PATH", "PATHEXT", "COMSPEC", "TEMP", "TMP") if key in os.environ}
    if database["password"]:
        env["PGPASSWORD"] = database["password"]
    if database.get("maintenance_options"):
        env["PGOPTIONS"] = database["maintenance_options"] + ' -c theraflow.restoring=1'
    runner = runner or subprocess.run
    try:
        result = runner(command, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False, timeout=timeout, shell=False)
    except subprocess.TimeoutExpired as exc:
        raise DatabaseRestoreError("database_command_timeout", "PostgreSQL restore je prekoračio dozvoljeno vrijeme.") from exc
    if result.returncode:
        detail = ((result.stderr or result.stdout or "")[-2000:]).replace(database["password"], "[REDACTED]") if database["password"] else (result.stderr or result.stdout or "")[-2000:]
        raise DatabaseRestoreError("database_command_failed", detail or "PostgreSQL restore komanda nije uspjela.")
    return result


def validate_original_backup(plan, runner=None):
    backup = Path(plan["backup_root"]).resolve()
    dump = Path(plan["database_backup_path"]).resolve()
    try:
        metadata = json.loads((backup / "backup_metadata.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise DatabaseRestoreError("database_metadata_invalid", "Database backup metadata nije validan.") from exc
    if dump.parent != backup or not dump.is_file() or metadata.get("session_id") != plan["session_id"]:
        raise DatabaseRestoreError("database_session_mismatch", "Database backup ne pripada ovom update sessionu.")
    if metadata.get("validation") != "pg_restore_list_passed" or sha256_file(dump) != metadata.get("dump_sha256"):
        raise DatabaseRestoreError("database_backup_invalid", "Database backup hash nije ispravan.")
    database = _database(plan, metadata)
    _run([_executable("pg_restore", plan), "--list", str(dump)], database, timeout=120, runner=runner)
    return dump, metadata, database


def create_emergency_backup(plan, database, runner=None):
    destination = Path(plan["backup_root"]) / "pre_rollback_database.dump"
    # A retry must never overwrite the only copy of the post-update database.
    if destination.exists() or destination.with_suffix(".partial").exists():
        destination = destination.with_name(f"pre_rollback_database_{uuid.uuid4().hex}.dump")
    partial = destination.with_suffix(".partial")
    command = [
        _executable("pg_dump", plan), "--format=custom", "--schema=public", "--file", str(partial),
        "--dbname", database["name"], "--host", database["host"],
        "--port", str(database["port"]), "--username", database["user"], "--no-password",
    ]
    _run(command, database, runner=runner)
    if not partial.is_file() or partial.stat().st_size == 0:
        raise DatabaseRestoreError("emergency_backup_failed", "Emergency database backup nije kreiran.")
    _run([_executable("pg_restore", plan), "--list", str(partial)], database, timeout=120, runner=runner)
    os.replace(partial, destination)
    receipt = {"session_id": plan["session_id"], "database_name": database["name"],
               "path": str(destination.resolve()), "sha256": sha256_file(destination),
               "created_at": datetime.now(timezone.utc).isoformat()}
    _write_json(destination.with_suffix(".json"), receipt)
    _write_json(destination.parent / "emergency_backup_latest.json", receipt)
    return destination


RESTORE_PROTOCOL = "transactional-public-schema-v1"


def _write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def _archive_contract(toc):
    """Fail closed outside the standard TheraFlow public-schema database."""
    tables, data_tables, selected = [], [], []
    for line in toc.splitlines():
        if line.startswith(";") or not line.strip():
            selected.append(line)
            continue
        match = re.match(r"^\d+; \d+ \d+ (.*)$", line)
        if not match:
            raise DatabaseRestoreError("restore_archive_unsupported", "Nečitljiv sadržaj backupa.")
        entry = match.group(1)
        if entry.startswith("SCHEMA "):
            if not entry.startswith("SCHEMA - public "):
                raise DatabaseRestoreError("restore_archive_unsupported", "Backup sadrži dodatnu šemu; potreban je servisni oporavak.")
            continue  # Preserve the installed schema owner/ACL in the transaction.
        if entry.startswith(("COMMENT - SCHEMA public ", "ACL - SCHEMA public ")):
            continue
        if entry.startswith(("EXTENSION ", "BLOB", "LARGE OBJECT", "DATABASE ", "TABLESPACE ", "FOREIGN ", "SUBSCRIPTION ")):
            raise DatabaseRestoreError("restore_archive_unsupported", "Backup sadrži nestandardne objekte; potreban je servisni oporavak.")
        if entry.startswith("TABLE ") and not entry.startswith("TABLE DATA "):
            table = re.fullmatch(r"TABLE public ([a-z_][a-z0-9_]*) \S+", entry)
            if not table:
                raise DatabaseRestoreError("restore_archive_unsupported", "Backup sadrži nepodržanu tabelu ili šemu.")
            tables.append(table.group(1))
        if entry.startswith("TABLE DATA "):
            data_table = re.fullmatch(r"TABLE DATA public ([a-z_][a-z0-9_]*) \S+", entry)
            if not data_table:
                raise DatabaseRestoreError("restore_archive_unsupported", "Nepodržan zapis podataka u backupu.")
            data_tables.append(data_table.group(1))
        selected.append(line)
    if not {"django_migrations", "auth_user", "patients_pacijent"}.issubset(tables) or len(tables) != len(set(tables)):
        raise DatabaseRestoreError("restore_archive_incomplete", "Backup nema obavezne TheraFlow tabele.")
    if sorted(data_tables) != sorted(tables):
        raise DatabaseRestoreError("restore_archive_incomplete", "Backup nema podatke za sve tabele.")
    return sorted(tables), "\n".join(selected) + "\n"


def _cleanup_sql(plan):
    # Both the cleanup and the restore run inside ONE psql transaction. An error
    # rolls back the schema drop as well. Preserve owner and schema grants; no
    # CREATEDB, superuser or changes to database credentials are required.
    from .recovery_safety import assert_rollback_allowed
    receipt = assert_rollback_allowed(plan)
    session = str(uuid.UUID(plan['session_id']))
    epoch = receipt['window']['epoch']
    if not re.fullmatch(r"[0-9 :.+-]+", epoch):
        raise DatabaseRestoreError('restore_epoch_invalid', 'Prozor oporavka nije validan.')
    guard = """
DO $window$
DECLARE owned boolean;
BEGIN
 SELECT active AND session_id='%s' AND started_at='%s'::timestamptz
        AND key_hash=md5(coalesce(current_setting('theraflow.update_key',true),''))
 INTO owned FROM tf_update_control.barrier WHERE singleton FOR SHARE;
 IF owned IS DISTINCT FROM true THEN
   RAISE EXCEPTION 'Zatvoren prozor oporavka; baza nije promijenjena.' USING ERRCODE='55000';
 END IF;
END $window$;
""" % (session, epoch)
    return "SET LOCAL lock_timeout = '15s';\n" + guard + """
SET LOCAL lock_timeout = '15s';
SELECT pg_advisory_xact_lock(19483109, hashtext(current_database()));
DO $restore$
DECLARE owner_name text; grant_row record; grants jsonb; schema_comment text;
BEGIN
  IF EXISTS (SELECT 1 FROM pg_namespace WHERE nspname NOT IN ('public', 'tf_update_control')
             AND nspname <> 'information_schema' AND nspname NOT LIKE 'pg_%')
     OR EXISTS (SELECT 1 FROM pg_extension WHERE extname <> 'plpgsql')
     OR EXISTS (SELECT 1 FROM pg_default_acl WHERE defaclnamespace = 'public'::regnamespace)
     OR EXISTS (SELECT 1 FROM pg_largeobject_metadata) THEN
    RAISE EXCEPTION 'Nestandardna schema/extension/large object; baza nije promijenjena.';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_stat_activity WHERE datname = current_database()
             AND pid <> pg_backend_pid() AND backend_type = 'client backend') THEN
    RAISE EXCEPTION 'Drugi proces koristi bazu; oporavak zaustavljen.';
  END IF;
  SELECT pg_get_userbyid(nspowner), obj_description(oid, 'pg_namespace'),
    (SELECT jsonb_agg(jsonb_build_object('grantee', grantee, 'privilege', privilege_type,
                                       'grantable', is_grantable))
     FROM aclexplode(coalesce(nspacl, acldefault('n', nspowner))))
  INTO owner_name, schema_comment, grants FROM pg_namespace WHERE nspname = 'public';
  IF owner_name IS NULL THEN RAISE EXCEPTION 'Public schema nedostaje.'; END IF;
  DROP SCHEMA public CASCADE;
  EXECUTE format('CREATE SCHEMA public AUTHORIZATION %I', owner_name);
  REVOKE ALL ON SCHEMA public FROM PUBLIC;
  FOR grant_row IN SELECT * FROM jsonb_to_recordset(grants)
      AS x(grantee oid, privilege text, grantable boolean) LOOP
    EXECUTE format('GRANT %s ON SCHEMA public TO %s%s', grant_row.privilege,
        CASE WHEN grant_row.grantee = 0 THEN 'PUBLIC'
             ELSE quote_ident(pg_get_userbyid(grant_row.grantee)) END,
        CASE WHEN grant_row.grantable THEN ' WITH GRANT OPTION' ELSE '' END);
  END LOOP;
  EXECUTE format('COMMENT ON SCHEMA public IS %L', schema_comment);
END $restore$;
"""


def _verification_sql(tables):
    expected = ",".join("'" + name + "'" for name in tables)
    return f"""
DO $verify$
DECLARE actual text[];
BEGIN
 SELECT array_agg(tablename::text ORDER BY tablename) INTO actual
 FROM pg_tables WHERE schemaname = 'public';
 IF actual IS DISTINCT FROM ARRAY[{expected}]::text[] THEN
   RAISE EXCEPTION 'Obnovljene tabele ne odgovaraju backupu.';
 END IF;
 IF NOT EXISTS (SELECT 1 FROM public.django_migrations WHERE app = 'patients') THEN
   RAISE EXCEPTION 'Evidencija migracija nije obnovljena.';
 END IF;
END $verify$;
"""


def restore_original_database(plan, dump, database, runner=None):
    from .recovery_safety import assert_rollback_allowed
    assert_rollback_allowed(plan)
    backup = Path(plan["backup_root"]).resolve()
    checked_dump, _metadata, checked_database = validate_original_backup(plan, runner=runner)
    if Path(dump).resolve() != checked_dump or database != checked_database:
        raise DatabaseRestoreError("database_identity_mismatch", "Cilj obnove nije validiran.")
    try:
        receipt = json.loads((backup / "emergency_backup_latest.json").read_text(encoding="utf-8"))
        emergency = Path(receipt["path"]).resolve()
        if (emergency.parent != backup or receipt["session_id"] != plan["session_id"]
                or receipt["database_name"] != database["name"] or sha256_file(emergency) != receipt["sha256"]):
            raise ValueError("emergency mismatch")
    except (OSError, ValueError, KeyError) as exc:
        raise DatabaseRestoreError("emergency_backup_invalid", "Validirana kopija baze prije oporavka nije dostupna.") from exc

    attempt = backup / ("database_restore_" + uuid.uuid4().hex)
    attempt.mkdir()
    journal = {"protocol": RESTORE_PROTOCOL, "session_id": plan["session_id"],
               "original_sha256": sha256_file(dump), "emergency_backup_path": str(emergency),
               "emergency_sha256": receipt["sha256"], "attempt_path": str(attempt),
               "database_restored": False, "phase": "preparing"}

    def record(phase, **extra):
        journal.update(phase=phase, updated_at=datetime.now(timezone.utc).isoformat(), **extra)
        _write_json(attempt / "result.json", journal)
        _write_json(backup / "database_restore_result.json", journal)

    record("preparing")
    try:
        pg_restore = _executable("pg_restore", plan)
        toc = _run([pg_restore, "--list", str(dump)], database, runner=runner).stdout
        tables, selected = _archive_contract(toc)
        selection, sql = attempt / "archive.list", attempt / "restore.sql"
        selection.write_text(selected, encoding="utf-8")
        _run([pg_restore, "--no-owner", "--no-privileges", "--exit-on-error",
              "--use-list", str(selection), "--file", str(sql), str(dump)], database, runner=runner)
        if not sql.is_file() or not sql.stat().st_size:
            raise DatabaseRestoreError("restore_sql_missing", "SQL za obnovu nije pripremljen.")
        cleanup, verify = attempt / "cleanup.sql", attempt / "verify.sql"
        cleanup.write_text(_cleanup_sql(plan), encoding="utf-8")
        verify.write_text(_verification_sql(tables), encoding="utf-8")
        connection = ["--dbname", database["name"], "--host", database["host"], "--port", str(database["port"]),
                      "--username", database["user"], "--no-password"]
        psql = _executable("psql", plan)
        # Only disconnect application clients. Maintenance workers belong to
        # PostgreSQL and cannot be signalled by an ordinary database owner.
        # PostgreSQL coordinates their locks with transactional DDL itself.
        _run([psql, "-X", "--set", "ON_ERROR_STOP=1", *connection, "--command",
              "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
              "WHERE datname = current_database() AND pid <> pg_backend_pid() "
              "AND backend_type = 'client backend';"],
             database, timeout=60, runner=runner)
        command = [psql, "-X", "--set", "ON_ERROR_STOP=1", "--single-transaction", *connection,
                   "--file", str(cleanup), "--file", str(sql), "--file", str(verify)]
        record("transaction_running", command=command, expected_tables=tables)
        _run(command, database, runner=runner)
        # A new connection must verify the committed state too. A lost commit
        # response is never converted into a success claim or an automatic retry.
        record("transaction_committed_unverified")
        _run([psql, "-X", "--set", "ON_ERROR_STOP=1", *connection, "--file", str(verify)], database, runner=runner)
        record("verified", database_restored=True)
        return True
    except Exception as exc:
        record("failed_or_interrupted", error_code=getattr(exc, "code", "database_restore_failed"),
               # PostgreSQL COPY errors can contain patient data. Keep diagnostics
               # inside the protected backup folder, not in the browser status.
               error_detail=str(exc)[-4000:])
        raise DatabaseRestoreError("database_restore_incomplete",
            "Obnova baze nije potvrđena. Sačuvani su originalni backup, kopija prije oporavka i izvještaj; potrebna je provjera oporavka.") from exc


def restore_database(plan, runner=None):
    from .recovery_safety import assert_rollback_allowed
    assert_rollback_allowed(plan)
    dump, _metadata, database = validate_original_backup(plan, runner=runner)
    emergency = create_emergency_backup(plan, database, runner=runner)
    restore_original_database(plan, dump, database, runner=runner)
    return {"database_restored": True, "emergency_backup_path": str(emergency)}
