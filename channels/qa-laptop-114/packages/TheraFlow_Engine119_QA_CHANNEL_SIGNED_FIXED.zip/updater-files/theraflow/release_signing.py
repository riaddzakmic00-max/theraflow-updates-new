"""Pinned detached CMS signatures for TheraFlow release manifests.

This module uses only the Python standard library and Windows' built-in SignedCms.
The locally provisioned certificate DER SHA-256 pin is the trust anchor: HTTPS or
a checksum from the same remote manifest is not publisher authentication. A public
commercial CA chain is neither substituted for that pin nor required by this CMS
protocol. Authenticode verification of executable bootstrap files is separate.
"""

from __future__ import annotations

import base64
import binascii
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

PROTOCOL = "theraflow-cms-sha256-v1"
MAX_JSON_BYTES = 1024 * 1024
MAX_CMS_BYTES = 256 * 1024
QA_HOST = "DESKTOP-OTO3E25"
QA_CERTIFICATE_MARKER = "TheraFlow Isolated QA Signing"
TRUST_DIRECTORY = Path(r"C:\ProgramData\TheraFlow\config")
_KEY_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,79}\Z")
_DIGEST = re.compile(r"[0-9a-fA-F]{64}\Z")
_CHANNEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")
_HOST = re.compile(r"[A-Za-z0-9][A-Za-z0-9.-]{0,252}\Z")
_UTC_DATE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z\Z")


class ReleaseSignatureError(ValueError):
    """A safe, machine-readable failure without signed content or credentials."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def _reject(code: str) -> None:
    raise ReleaseSignatureError(code)


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            _reject("RELEASE_JSON_DUPLICATE_KEY")
        result[key] = value
    return result


def _validate_json_value(value: Any, depth: int = 0) -> None:
    if depth > 32:
        _reject("RELEASE_JSON_TOO_DEEP")
    if value is None or type(value) is bool:
        return
    if type(value) is int:
        if abs(value) > 2**53 - 1:
            _reject("RELEASE_JSON_INTEGER_RANGE")
        return
    if type(value) is str:
        try:
            value.encode("utf-8", errors="strict")
        except UnicodeError:
            _reject("RELEASE_JSON_INVALID_UNICODE")
        return
    if type(value) is list:
        for entry in value:
            _validate_json_value(entry, depth + 1)
        return
    if type(value) is dict:
        for key, entry in value.items():
            if type(key) is not str:
                _reject("RELEASE_JSON_INVALID_KEY")
            _validate_json_value(key, depth + 1)
            _validate_json_value(entry, depth + 1)
        return
    _reject("RELEASE_JSON_UNSUPPORTED_TYPE")


def parse_json_strict(raw: bytes | str) -> dict[str, Any]:
    """Parse a bounded JSON object, rejecting duplicates and ambiguous numbers."""
    if not isinstance(raw, (str, bytes)):
        _reject("RELEASE_JSON_INVALID_INPUT")
    try:
        encoded = raw.encode("utf-8", errors="strict") if isinstance(raw, str) else raw
        if len(encoded) > MAX_JSON_BYTES:
            _reject("RELEASE_JSON_TOO_LARGE")
        decoded = encoded.decode("utf-8", errors="strict")
        result = json.loads(decoded, object_pairs_hook=_unique_object)
        if type(result) is not dict:
            _reject("RELEASE_JSON_NOT_OBJECT")
        _validate_json_value(result)
        return result
    except ReleaseSignatureError:
        raise
    except (ValueError, UnicodeError, RecursionError):
        _reject("RELEASE_JSON_INVALID")


def canonical_manifest_bytes(manifest: dict[str, Any]) -> bytes:
    """UTF-8 JSON, sorted keys, no spaces, only root release_signature excluded.

    All other fields, including extensions unknown to this version, are signed.
    Publishers must use this exact canonicalization before creating detached CMS.
    """
    if type(manifest) is not dict:
        _reject("RELEASE_JSON_NOT_OBJECT")
    _validate_json_value(manifest)
    try:
        result = json.dumps(
            {key: value for key, value in manifest.items() if key != "release_signature"},
            sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False,
        ).encode("utf-8")
    except (ValueError, UnicodeError, RecursionError):
        _reject("RELEASE_JSON_INVALID")
    if len(result) > MAX_JSON_BYTES:
        _reject("RELEASE_JSON_TOO_LARGE")
    return result


def _date(value: Any, code: str) -> datetime:
    if type(value) is not str or not _UTC_DATE.fullmatch(value):
        _reject(code)
    try:
        return datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError:
        _reject(code)


def _positive_sequence(value: Any, code: str, *, allow_zero: bool = False) -> int:
    if type(value) is not int or value < (0 if allow_zero else 1) or value > 2**53 - 1:
        _reject(code)
    return value


def validate_trust_profile(profile: Any, *, expected_scope: str = "production") -> dict[str, Any]:
    if expected_scope not in ("qa", "production"):
        _reject("RELEASE_SCOPE_INVALID")
    if type(profile) is not dict:
        _reject("RELEASE_TRUST_MISSING")
    _validate_json_value(profile)
    if type(profile.get("schema_version")) is not int or profile["schema_version"] != 1:
        _reject("RELEASE_TRUST_SCHEMA_INVALID")
    if profile.get("scope") != expected_scope:
        _reject("RELEASE_TRUST_SCOPE_MISMATCH")
    if type(profile.get("profile_id")) is not str or not _KEY_ID.fullmatch(profile["profile_id"]):
        _reject("RELEASE_TRUST_PROFILE_INVALID")
    hosts = profile.get("allowed_hosts")
    if type(hosts) is not list or not hosts:
        _reject("RELEASE_TRUST_HOSTS_INVALID")
    if any(type(host) is not str or (host != "*" and not _HOST.fullmatch(host)) for host in hosts):
        _reject("RELEASE_TRUST_HOSTS_INVALID")
    if len(set(host.upper() for host in hosts)) != len(hosts):
        _reject("RELEASE_TRUST_HOSTS_INVALID")
    if expected_scope == "qa" and {host.upper() for host in hosts} != {QA_HOST}:
        _reject("RELEASE_QA_HOST_RESTRICTION")
    channels = profile.get("channels")
    if type(channels) is not list or not channels or any(type(value) is not str or not _CHANNEL.fullmatch(value) for value in channels):
        _reject("RELEASE_TRUST_CHANNELS_INVALID")
    if len(set(channels)) != len(channels):
        _reject("RELEASE_TRUST_CHANNELS_INVALID")
    _positive_sequence(profile.get("minimum_sequence"), "RELEASE_TRUST_SEQUENCE_INVALID", allow_zero=True)
    certs = profile.get("certificates")
    if type(certs) is not list or not certs:
        _reject("RELEASE_TRUST_CERTIFICATES_MISSING")
    identities: set[str] = set()
    fingerprints: set[str] = set()
    for cert in certs:
        if type(cert) is not dict or type(cert.get("key_id")) is not str or not _KEY_ID.fullmatch(cert["key_id"]):
            _reject("RELEASE_TRUST_CERTIFICATE_INVALID")
        digest = cert.get("sha256")
        if type(digest) is not str or not _DIGEST.fullmatch(digest) or cert.get("scope") != expected_scope:
            _reject("RELEASE_TRUST_CERTIFICATE_INVALID")
        if cert["key_id"] in identities or digest.lower() in fingerprints:
            _reject("RELEASE_TRUST_CERTIFICATE_DUPLICATE")
        identities.add(cert["key_id"])
        fingerprints.add(digest.lower())
    return profile


_WINDOWS_CMS_COMMAND = r"""
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest
[Console]::InputEncoding=New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
try {
  Add-Type -AssemblyName System.Security
  $r=[Console]::In.ReadToEnd() | ConvertFrom-Json
  $content=[Convert]::FromBase64String([string]$r.content)
  $encoded=[Convert]::FromBase64String([string]$r.signature)
  $cms=New-Object System.Security.Cryptography.Pkcs.SignedCms -ArgumentList (New-Object System.Security.Cryptography.Pkcs.ContentInfo -ArgumentList (,$content)),$true
  $cms.Decode($encoded)
  if (-not $cms.Detached -or $cms.SignerInfos.Count -ne 1) { throw 'CMS_STRUCTURE' }
  $signer=$cms.SignerInfos[0]
  if ($signer.DigestAlgorithm.Value -ne '2.16.840.1.101.3.4.2.1' -or $signer.CounterSignerInfos.Count -ne 0) { throw 'CMS_ALGORITHM' }
  $cert=$signer.Certificate
  if ($null -eq $cert -or $cert.PublicKey.Oid.Value -ne '1.2.840.113549.1.1.1') { throw 'CMS_KEY' }
  $key=$cert.PublicKey.Key
  if (-not ($key -is [System.Security.Cryptography.RSA]) -or $key.KeySize -lt 2048) { throw 'CMS_KEY' }
  $hasCodeSigning=$false
  foreach ($extension in $cert.Extensions) {
    if ($extension.Oid.Value -eq '2.5.29.37') {
      foreach ($usage in $extension.EnhancedKeyUsages) { if ($usage.Value -eq '1.3.6.1.5.5.7.3.3') { $hasCodeSigning=$true } }
    }
  }
  if (-not $hasCodeSigning) { throw 'CMS_EKU' }
  $now=[DateTimeOffset]::Parse([string]$r.now,[Globalization.CultureInfo]::InvariantCulture).UtcDateTime
  if ($now -lt $cert.NotBefore.ToUniversalTime() -or $now -gt $cert.NotAfter.ToUniversalTime()) { throw 'CMS_CERT_TIME' }
  $sha=[System.Security.Cryptography.SHA256]::Create()
  try { $fingerprint=([BitConverter]::ToString($sha.ComputeHash($cert.RawData))).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose() }
  if ($fingerprint -cne [string]$r.certificate_sha256) { throw 'CMS_PIN' }
  $cms.CheckSignature($true)
  [Console]::Out.Write((@{signature_valid=$true;signer_count=1;digest_algorithm='sha256';key_algorithm='rsa';key_size=$key.KeySize;code_signing_eku=$true;certificate_valid=$true;certificate_sha256=$fingerprint;certificate_subject=$cert.Subject} | ConvertTo-Json -Compress))
} catch {
  [Console]::Out.Write('{"error":"RELEASE_CMS_REJECTED"}')
  exit 1
}
"""


def windows_powershell_executable() -> str:
    """Resolve the Windows system binary without PATH or SystemRoot overrides."""
    if os.name != "nt":
        _reject("RELEASE_WINDOWS_VERIFIER_UNAVAILABLE")
    buffer = ctypes.create_unicode_buffer(32768)
    length = ctypes.windll.kernel32.GetSystemDirectoryW(buffer, len(buffer))
    if not length or length >= len(buffer):
        _reject("RELEASE_WINDOWS_VERIFIER_UNAVAILABLE")
    executable = Path(buffer.value) / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    if not executable.is_file():
        _reject("RELEASE_WINDOWS_VERIFIER_UNAVAILABLE")
    return str(executable)


def _windows_call(command: str, request: dict[str, Any]) -> dict[str, Any]:
    try:
        completed = subprocess.run(
            [windows_powershell_executable(), "-NoProfile", "-NonInteractive", "-Command", command],
            input=json.dumps(request, ensure_ascii=True), text=True, encoding="utf-8",
            capture_output=True, timeout=30, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except ReleaseSignatureError:
        raise
    except (OSError, subprocess.SubprocessError):
        _reject("RELEASE_WINDOWS_VERIFIER_FAILED")
    if completed.returncode != 0:
        _reject("RELEASE_CMS_REJECTED")
    return parse_json_strict(completed.stdout)


def windows_cms_verify(content: bytes, signature: bytes, certificate_sha256: str, now: datetime) -> dict[str, Any]:
    """Verify detached CMS with an explicit local certificate pin and no store writes."""
    return _windows_call(_WINDOWS_CMS_COMMAND, {
        "content": base64.b64encode(content).decode("ascii"),
        "signature": base64.b64encode(signature).decode("ascii"),
        "certificate_sha256": certificate_sha256.lower(),
        "now": now.astimezone(timezone.utc).isoformat(),
    })


def verify_release_manifest(
    manifest: dict[str, Any], trust_profile: dict[str, Any], *,
    expected_scope: str = "production", host: str | None = None,
    now: datetime | None = None, minimum_sequence: int | None = None,
    verifier: Callable[[bytes, bytes, str, datetime], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Fail closed and return only a safe verification receipt.

    Persisted replay state must additionally bind each sequence to this receipt's
    manifest_sha256. Rechecking that exact manifest may reuse its sequence; a
    different manifest at an already accepted sequence must be rejected by caller.
    """
    profile = validate_trust_profile(trust_profile, expected_scope=expected_scope)
    canonical = canonical_manifest_bytes(manifest)
    if manifest.get("release_scope") != expected_scope:
        _reject("RELEASE_SCOPE_MISMATCH")
    channel = manifest.get("channel")
    if type(channel) is not str or channel not in profile["channels"]:
        _reject("RELEASE_CHANNEL_REJECTED")
    machine = socket.gethostname() if host is None else host
    if type(machine) is not str or not _HOST.fullmatch(machine):
        _reject("RELEASE_HOST_INVALID")
    machine = machine.upper()
    if expected_scope == "qa" and machine != QA_HOST:
        _reject("RELEASE_QA_HOST_RESTRICTION")
    hosts = {value.upper() for value in profile["allowed_hosts"]}
    if "*" not in hosts and machine not in hosts:
        _reject("RELEASE_HOST_REJECTED")
    sequence = _positive_sequence(manifest.get("release_sequence"), "RELEASE_SEQUENCE_INVALID")
    floor = profile["minimum_sequence"]
    if minimum_sequence is not None:
        floor = max(floor, _positive_sequence(minimum_sequence, "RELEASE_SEQUENCE_INVALID", allow_zero=True))
    if sequence < floor:
        _reject("RELEASE_SEQUENCE_REPLAY")
    clock = datetime.now(timezone.utc) if now is None else now
    if not isinstance(clock, datetime) or clock.tzinfo is None or clock.utcoffset() is None:
        _reject("RELEASE_CLOCK_INVALID")
    clock = clock.astimezone(timezone.utc)
    issued = _date(manifest.get("issued_at"), "RELEASE_ISSUED_AT_INVALID")
    expires = _date(manifest.get("expires_at"), "RELEASE_EXPIRES_AT_INVALID")
    if expires <= issued or expires <= clock:
        _reject("RELEASE_EXPIRED")
    if issued > clock + timedelta(minutes=5):
        _reject("RELEASE_NOT_YET_VALID")
    signature = manifest.get("release_signature")
    if type(signature) is not dict or set(signature) != {"protocol", "key_id", "value"}:
        _reject("RELEASE_SIGNATURE_MISSING")
    if signature.get("protocol") != PROTOCOL:
        _reject("RELEASE_SIGNATURE_PROTOCOL_INVALID")
    key_id = signature.get("key_id")
    if type(key_id) is not str or not _KEY_ID.fullmatch(key_id):
        _reject("RELEASE_SIGNATURE_KEY_INVALID")
    cert = next((entry for entry in profile["certificates"] if entry["key_id"] == key_id), None)
    if cert is None:
        _reject("RELEASE_SIGNER_UNTRUSTED")
    value = signature.get("value")
    if type(value) is not str or not value or len(value) > ((MAX_CMS_BYTES + 2) // 3) * 4:
        _reject("RELEASE_SIGNATURE_INVALID")
    try:
        encoded_signature = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error):
        _reject("RELEASE_SIGNATURE_INVALID")
    if not encoded_signature or len(encoded_signature) > MAX_CMS_BYTES or base64.b64encode(encoded_signature).decode("ascii") != value:
        _reject("RELEASE_SIGNATURE_INVALID")
    fingerprint = cert["sha256"].lower()
    try:
        result = (verifier or windows_cms_verify)(canonical, encoded_signature, fingerprint, clock)
    except ReleaseSignatureError:
        raise
    except Exception:
        _reject("RELEASE_CMS_REJECTED")
    if (type(result) is not dict or result.get("signature_valid") is not True
            or type(result.get("signer_count")) is not int or result["signer_count"] != 1
            or result.get("digest_algorithm") != "sha256" or result.get("key_algorithm") != "rsa"
            or type(result.get("key_size")) is not int or result["key_size"] < 2048
            or result.get("code_signing_eku") is not True or result.get("certificate_valid") is not True
            or result.get("certificate_sha256") != fingerprint
            or type(result.get("certificate_subject")) is not str or not result["certificate_subject"]):
        _reject("RELEASE_CMS_REJECTED")
    # The dedicated isolated QA certificate remains forbidden in production
    # even if an administrator mistakenly labels its pin production in policy.
    if expected_scope == "production" and QA_CERTIFICATE_MARKER.casefold() in result["certificate_subject"].casefold():
        _reject("RELEASE_QA_CERTIFICATE_IN_PRODUCTION")
    return {
        "protocol": PROTOCOL, "verified": True, "profile_id": profile["profile_id"],
        "release_scope": expected_scope, "channel": channel, "release_sequence": sequence,
        "key_id": key_id, "certificate_sha256": fingerprint,
        "manifest_sha256": hashlib.sha256(canonical).hexdigest(),
        "verified_at": clock.isoformat().replace("+00:00", "Z"),
        "accepted_at": clock.isoformat().replace("+00:00", "Z"),
    }


_PROTECTED_PROFILE_COMMAND = r"""
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest
[Console]::InputEncoding=New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
try {
  $r=[Console]::In.ReadToEnd() | ConvertFrom-Json
  $path=[string]$r.path
  if ($path -cne 'C:\ProgramData\TheraFlow\config\release-trust.json') { throw 'PROFILE_PATH' }
  $protected=@('C:\ProgramData\TheraFlow','C:\ProgramData\TheraFlow\config',$path)
  $writers=@('S-1-5-18','S-1-5-32-544')
  $writeMask=[System.Security.AccessControl.FileSystemRights]::Write -bor [System.Security.AccessControl.FileSystemRights]::Delete -bor [System.Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor [System.Security.AccessControl.FileSystemRights]::ChangePermissions -bor [System.Security.AccessControl.FileSystemRights]::TakeOwnership
  foreach ($itemPath in $protected) {
    $item=Get-Item -LiteralPath $itemPath -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'PROFILE_REPARSE' }
    $acl=Get-Acl -LiteralPath $itemPath
    $owner=$acl.Owner
    if ($owner -notmatch '^S-1-') { $owner=([Security.Principal.NTAccount]$owner).Translate([Security.Principal.SecurityIdentifier]).Value }
    if ($owner -notin $writers) { throw 'PROFILE_OWNER' }
    foreach ($rule in $acl.Access) {
      if ($rule.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and ($rule.FileSystemRights -band $writeMask) -ne 0) {
        $sid=$rule.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
        if ($sid -notin $writers) { throw 'PROFILE_WRITABLE' }
      }
    }
  }
  $length=(Get-Item -LiteralPath $path).Length
  if ($length -gt 1048576) { throw 'PROFILE_TOO_LARGE' }
  $bytes=[IO.File]::ReadAllBytes($path)
  [Console]::Out.Write((@{profile_base64=[Convert]::ToBase64String($bytes)} | ConvertTo-Json -Compress))
} catch { [Console]::Out.Write('{"error":"RELEASE_TRUST_UNPROTECTED"}'); exit 1 }
"""


def load_local_trust_profile(*, expected_scope: str = "production") -> dict[str, Any]:
    """Read only the fixed protected local profile; no manifest-selected trust.

    Production is the default. QA expectation must be selected explicitly and is
    accepted only on DESKTOP-OTO3E25. Administrators provision the canonical local
    config/release-trust.json outside distribution.
    """
    if expected_scope not in ("qa", "production"):
        _reject("RELEASE_SCOPE_INVALID")
    if expected_scope == "qa" and socket.gethostname().upper() != QA_HOST:
        _reject("RELEASE_QA_HOST_RESTRICTION")
    path = TRUST_DIRECTORY / "release-trust.json"
    try:
        result = _windows_call(_PROTECTED_PROFILE_COMMAND, {"path": str(path)})
        encoded = result.get("profile_base64")
        if type(encoded) is not str:
            _reject("RELEASE_TRUST_UNPROTECTED")
        raw = base64.b64decode(encoded, validate=True)
        return validate_trust_profile(parse_json_strict(raw), expected_scope=expected_scope)
    except ReleaseSignatureError as exc:
        if exc.code.startswith("RELEASE_TRUST_") or exc.code == "RELEASE_QA_HOST_RESTRICTION":
            raise
        _reject("RELEASE_TRUST_UNPROTECTED")
    except (ValueError, binascii.Error):
        _reject("RELEASE_TRUST_UNPROTECTED")
