"""Installed repair/updater compatibility identity.

The repair installer ships this module.  A full application payload may only
replace updater code when it declares a baseline and engine at least as new as
the installed values.
"""

REPAIR_BASELINE = "3.4.23"
UPDATER_ENGINE_VERSION = "1.1.9"
