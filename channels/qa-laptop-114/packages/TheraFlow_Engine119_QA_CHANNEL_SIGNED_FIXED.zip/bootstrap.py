"""Entry point for the authenticated Windows QA bootstrap only."""
import argparse
import json
import os
from pathlib import Path
import sys

from core import Bootstrap, BootstrapError
from windows import Windows


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=['Apply','Recover','Rollback'],required=True)
    parser.add_argument('--profile',type=Path,required=True)
    args=parser.parse_args()
    bundle=Path(__file__).resolve().parent
    profile=json.loads(args.profile.read_text(encoding='utf-8'))
    work=Path(os.environ['ProgramData'])/'TheraFlow/bootstrap'/profile['session_id']
    adapter=Windows(bundle,args.profile,work)
    engine=Bootstrap(bundle,profile['application_root'],work,adapter)
    try:
        outcome={'Apply':engine.apply,'Recover':engine.recover,'Rollback':engine.rollback}[args.mode]()
        print(json.dumps(dict(status=outcome,application='1.1.4',production_allowed=False)))
        return 0
    except Exception as exc:
        # No database errors, configuration, patient values or service command
        # lines are written to shared console output.
        print(json.dumps(dict(status='BLOCKED',code=str(exc) if isinstance(exc,BootstrapError) else 'local_review_required',
                              recovery='Use the same signed bundle/profile and Recover; never restore an old DB automatically.')))
        return 1

if __name__=='__main__':sys.exit(main())
