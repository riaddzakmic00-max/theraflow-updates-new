"""Exclusive, process-bound lease for legacy manual update recovery.

The legacy public 1.0.2 updater predates the durable rollback-lock protocol.
This lease does not replace any validation from the signed install plan.  It
only serializes the narrow field-recovery path while those validations run.
"""

import hashlib
import hmac
import json
import os
import secrets
import stat
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from dashboard.scheduler_lease import (
    inspect_process,
    normalize_process_creation_utc_epoch_ms,
)
from theraflow.environment import current_process_identity


class RecoveryLockError(RuntimeError):
    def __init__(self, code, message, failed_step="legacy_recovery_lock"):
        self.code = code
        self.failed_step = failed_step
        super().__init__(message)


def _is_reparse_point(path):
    path = Path(path)
    try:
        details = os.lstat(path)
    except FileNotFoundError:
        return False
    attributes = int(getattr(details, "st_file_attributes", 0) or 0)
    reparse_flag = int(getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))
    return path.is_symlink() or bool(attributes & reparse_flag)


def ensure_no_reparse_components(paths):
    """Reject symlink/junction/reparse components in protected recovery paths."""

    for raw_path in paths:
        if raw_path in (None, ""):
            continue
        path = Path(raw_path)
        if not path.is_absolute():
            raise RecoveryLockError(
                "legacy_recovery_path_not_absolute",
                "Recovery dokaz nije na lokalnoj apsolutnoj putanji.",
                "legacy_recovery_path_validation",
            )
        current = path
        while True:
            if current.exists() and _is_reparse_point(current):
                raise RecoveryLockError(
                    "legacy_recovery_reparse_path",
                    "Recovery putanja sadrži nedozvoljeni reparse point.",
                    "legacy_recovery_path_validation",
                )
            parent = current.parent
            if parent == current:
                break
            current = parent


def _canonical_path(value):
    return os.path.normcase(os.path.normpath(os.path.abspath(str(value))))


def _epoch_ms_iso(value):
    epoch = datetime(1970, 1, 1, tzinfo=timezone.utc)
    return (epoch + timedelta(milliseconds=int(value))).isoformat().replace(
        "+00:00", "Z"
    )


class ExclusiveLegacyRecoveryLock:
    """An O_EXCL lease tied to session, PID, creation time and random nonce."""

    SCHEMA_VERSION = 1

    def __init__(
        self,
        path,
        session_id,
        *,
        inspector=None,
        identity_reader=None,
    ):
        self.path = Path(path)
        self.session_id = str(session_id)
        self.inspector = inspector or inspect_process
        self.identity_reader = identity_reader or current_process_identity
        self.pid = os.getpid()
        self.nonce = ""
        self.creation_epoch_ms = None
        self.acquired = False

    @property
    def nonce_sha256(self):
        return hashlib.sha256(self.nonce.encode("ascii")).hexdigest() if self.nonce else ""

    def _current_identity(self):
        actual = self.inspector(self.pid)
        if not isinstance(actual, dict) or int(actual.get("pid") or 0) != self.pid:
            raise RecoveryLockError(
                "legacy_recovery_process_identity_unavailable",
                "Identitet recovery procesa nije moguće potvrditi.",
            )
        creation = normalize_process_creation_utc_epoch_ms(
            actual.get("created_at_utc_epoch_ms", actual.get("created_at"))
        )
        if creation is None:
            raise RecoveryLockError(
                "legacy_recovery_process_creation_invalid",
                "Vrijeme kreiranja recovery procesa nije validno.",
            )
        executable = str(actual.get("executable") or "").strip()
        command_line = str(actual.get("command_line") or "").strip()
        if not executable or not command_line:
            raise RecoveryLockError(
                "legacy_recovery_process_command_invalid",
                "Executable ili command identity recovery procesa nije dostupna.",
            )
        return actual, creation, executable, command_line

    def _payload(self):
        actual, creation, executable, command_line = self._current_identity()
        owner = self.identity_reader()
        owner_name = str((owner or {}).get("identity") or "unknown")
        self.creation_epoch_ms = creation
        self.nonce = secrets.token_hex(32)
        return {
            "schema_version": self.SCHEMA_VERSION,
            "session_id": self.session_id,
            "pid": self.pid,
            "process_created_at_utc_epoch_ms": creation,
            "process_created_at_utc_iso": _epoch_ms_iso(creation),
            "executable": executable,
            "command_line": command_line,
            "owner": owner_name,
            "nonce": self.nonce,
            "nonce_sha256": self.nonce_sha256,
            "acquired_at": datetime.now(timezone.utc).isoformat(),
        }

    def _create(self, payload):
        descriptor = os.open(
            str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600
        )
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())

    def _read(self):
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError, UnicodeError) as exc:
            raise RecoveryLockError(
                "legacy_recovery_lock_invalid",
                "Postojeći legacy recovery lock nije validan.",
            ) from exc
        if not isinstance(payload, dict):
            raise RecoveryLockError(
                "legacy_recovery_lock_invalid",
                "Postojeći legacy recovery lock nije JSON objekat.",
            )
        return payload

    def _existing_owner_is_active(self, payload):
        if (
            payload.get("schema_version") != self.SCHEMA_VERSION
            or str(payload.get("session_id") or "") != self.session_id
            or not str(payload.get("nonce") or "")
        ):
            raise RecoveryLockError(
                "legacy_recovery_lock_identity_invalid",
                "Postojeći recovery lock nema očekivani session/owner identitet.",
            )
        try:
            owner_pid = int(payload.get("pid") or 0)
        except (TypeError, ValueError) as exc:
            raise RecoveryLockError(
                "legacy_recovery_lock_identity_invalid",
                "Postojeći recovery lock nema validan PID.",
            ) from exc
        recorded_creation = normalize_process_creation_utc_epoch_ms(
            payload.get("process_created_at_utc_epoch_ms")
        )
        if owner_pid <= 0 or recorded_creation is None:
            raise RecoveryLockError(
                "legacy_recovery_lock_identity_invalid",
                "Postojeći recovery lock nema validan PID/creation-time identitet.",
            )
        actual = self.inspector(owner_pid)
        if not isinstance(actual, dict):
            return False
        actual_creation = normalize_process_creation_utc_epoch_ms(
            actual.get("created_at_utc_epoch_ms", actual.get("created_at"))
        )
        if actual_creation is None:
            raise RecoveryLockError(
                "legacy_recovery_lock_owner_unverifiable",
                "Aktivni PID recovery locka nema provjerljivo vrijeme kreiranja.",
            )
        if abs(actual_creation - recorded_creation) > 1:
            # The PID has been reused; the recorded process no longer exists.
            return False
        executable_matches = hmac.compare_digest(
            _canonical_path(actual.get("executable") or ""),
            _canonical_path(payload.get("executable") or ""),
        )
        command_matches = hmac.compare_digest(
            str(actual.get("command_line") or ""),
            str(payload.get("command_line") or ""),
        )
        if not executable_matches or not command_matches:
            raise RecoveryLockError(
                "legacy_recovery_lock_owner_identity_mismatch",
                "Aktivni recovery lock PID nema isti executable/command identitet.",
            )
        return True

    def acquire(self):
        try:
            parsed_session = str(uuid.UUID(self.session_id))
        except (ValueError, TypeError, AttributeError) as exc:
            raise RecoveryLockError(
                "legacy_recovery_session_id_invalid",
                "Legacy recovery session UUID nije validan.",
            ) from exc
        if parsed_session != self.session_id.lower():
            raise RecoveryLockError(
                "legacy_recovery_session_id_invalid",
                "Legacy recovery session UUID nije kanonski.",
            )
        ensure_no_reparse_components((self.path.parent,))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = self._payload()
        for _attempt in range(3):
            try:
                self._create(payload)
            except FileExistsError as exc:
                ensure_no_reparse_components((self.path,))
                existing = self._read()
                if self._existing_owner_is_active(existing):
                    raise RecoveryLockError(
                        "legacy_recovery_parallel_lock",
                        "Drugi verificirani recovery proces već posjeduje ovu sesiju.",
                    ) from exc
                quarantine = self.path.with_name(
                    f"{self.path.name}.stale.{uuid.uuid4().hex}"
                )
                try:
                    os.replace(self.path, quarantine)
                except FileNotFoundError:
                    continue
                quarantine.unlink(missing_ok=True)
                continue
            self.acquired = True
            self.verify_owned()
            return self
        raise RecoveryLockError(
            "legacy_recovery_lock_acquire_failed",
            "Ekskluzivni legacy recovery lock nije moguće atomski preuzeti.",
        )

    def verify_owned(self):
        if not self.acquired:
            raise RecoveryLockError(
                "legacy_recovery_lock_not_owned",
                "Trenutni proces nije preuzeo recovery lock.",
            )
        ensure_no_reparse_components((self.path,))
        payload = self._read()
        actual, current_creation, executable, command_line = self._current_identity()
        try:
            recorded_pid = int(payload.get("pid") or 0)
        except (TypeError, ValueError):
            recorded_pid = 0
        recorded_creation = normalize_process_creation_utc_epoch_ms(
            payload.get("process_created_at_utc_epoch_ms")
        )
        nonce = str(payload.get("nonce") or "")
        matches = all(
            (
                payload.get("schema_version") == self.SCHEMA_VERSION,
                str(payload.get("session_id") or "") == self.session_id,
                recorded_pid == self.pid,
                recorded_creation is not None,
                abs(recorded_creation - current_creation) <= 1,
                self.creation_epoch_ms is not None,
                abs(self.creation_epoch_ms - current_creation) <= 1,
                bool(nonce),
                hmac.compare_digest(nonce, self.nonce),
                hmac.compare_digest(
                    _canonical_path(payload.get("executable") or ""),
                    _canonical_path(executable),
                ),
                hmac.compare_digest(
                    str(payload.get("command_line") or ""), command_line
                ),
            )
        )
        if not matches:
            raise RecoveryLockError(
                "legacy_recovery_lock_ownership_lost",
                "Recovery lock više ne pripada trenutnom process identitetu.",
            )
        return True

    def release(self):
        if not self.acquired:
            return False
        self.verify_owned()
        self.path.unlink()
        self.acquired = False
        return True
