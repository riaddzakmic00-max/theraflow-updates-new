import hashlib
import hmac
import json
import os
import subprocess
from pathlib import Path

from theraflow.environment import production_mode
from theraflow.installed_paths import installed_paths


PLAN_SCHEMA_VERSION = 2
SIGNATURE_FIELD = "plan_hmac_sha256"


class PlanSecurityError(RuntimeError):
    pass


def _canonical_bytes(plan):
    unsigned = {key: value for key, value in plan.items() if key != SIGNATURE_FIELD}
    return json.dumps(
        unsigned,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def key_path_for_plan(plan_path):
    plan_path = Path(plan_path).resolve()
    if production_mode():
        layout = installed_paths()
        if (
            plan_path.name != "install_plan.json"
            or plan_path.parent.parent != layout.sessions.resolve()
        ):
            raise PlanSecurityError(
                "Install plan nije pod kanonskim ProgramData update sessions putem."
            )
        return layout.updater_service_key
    # <ProgramData>/TheraFlow/updates/sessions/<uuid>/install_plan.json
    try:
        data_root = plan_path.parents[3]
    except IndexError as exc:
        raise PlanSecurityError("Install plan putanja nema canonical ProgramData strukturu.") from exc
    return data_root / "config" / "updater_service.key"


def load_service_key(path):
    try:
        key = Path(path).read_bytes().strip()
    except OSError as exc:
        raise PlanSecurityError("Updater service ključ nije dostupan za install plan.") from exc
    if len(key) < 32:
        raise PlanSecurityError("Updater service ključ nije validan za install plan.")
    return key


def sign_plan(plan, key):
    signed = dict(plan)
    signed["plan_schema_version"] = PLAN_SCHEMA_VERSION
    signed[SIGNATURE_FIELD] = hmac.new(key, _canonical_bytes(signed), hashlib.sha256).hexdigest()
    return signed


def verify_plan_signature(plan, key):
    if plan.get("plan_schema_version") != PLAN_SCHEMA_VERSION:
        raise PlanSecurityError("Install plan schema verzija nije podržana.")
    signature = str(plan.get(SIGNATURE_FIELD, ""))
    expected = hmac.new(key, _canonical_bytes(plan), hashlib.sha256).hexdigest()
    if len(signature) != 64 or not hmac.compare_digest(signature, expected):
        raise PlanSecurityError("Install plan HMAC nije validan.")
    return True


def apply_restricted_acl(path, run=subprocess.run):
    if os.name != "nt":
        return
    result = run(
        [
            "icacls.exe", str(Path(path).resolve()), "/inheritance:r",
            "/grant:r", "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F",
        ],
        capture_output=True,
        text=True,
        check=False,
        shell=False,
        timeout=30,
    )
    if result.returncode != 0:
        raise PlanSecurityError("Restriktivni ACL install plana nije primijenjen.")


def atomic_write_signed_plan(path, plan, *, key_path=None, acl_runner=subprocess.run, restrict_acl=True):
    path = Path(path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    key = load_service_key(key_path or key_path_for_plan(path))
    signed = sign_plan(plan, key)
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(signed, handle, indent=2, ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        if restrict_acl:
            apply_restricted_acl(path.parent, run=acl_runner)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    reloaded = json.loads(path.read_text(encoding="utf-8"))
    verify_plan_signature(reloaded, key)
    return path, reloaded
