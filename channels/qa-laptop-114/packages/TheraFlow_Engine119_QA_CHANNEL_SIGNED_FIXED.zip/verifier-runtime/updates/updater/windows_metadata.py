import os
from pathlib import Path


APP_ID_KEY = r"{A3D7F1F5-4E94-4E2E-BCC6-6F7A0E8B9A15}_is1"
UNINSTALL_PATH = rf"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{APP_ID_KEY}"


class WindowsMetadataError(RuntimeError):
    pass


def _is_production_install(application_root):
    program_files = os.environ.get("ProgramFiles")
    if not program_files:
        return False
    install_root = Path(application_root).resolve().parent
    expected = (Path(program_files) / "TheraFlow").resolve()
    return os.path.normcase(str(install_root)) == os.path.normcase(str(expected))


def _open_key(access):
    import winreg

    errors = []
    for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
        try:
            return winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                UNINSTALL_PATH,
                0,
                access | view,
            )
        except FileNotFoundError as exc:
            errors.append(exc)
    raise FileNotFoundError(UNINSTALL_PATH) from (errors[-1] if errors else None)


def snapshot(application_root):
    if os.name != "nt":
        return {"available": False, "required": False}
    import winreg

    required = _is_production_install(application_root)
    try:
        with _open_key(winreg.KEY_READ) as key:
            display_name = str(winreg.QueryValueEx(key, "DisplayName")[0])
            display_version = str(winreg.QueryValueEx(key, "DisplayVersion")[0])
            install_location = str(winreg.QueryValueEx(key, "InstallLocation")[0])
    except FileNotFoundError as exc:
        if required:
            raise WindowsMetadataError("TheraFlow Installed Apps metadata nije pronađen.") from exc
        return {"available": False, "required": False}
    except OSError as exc:
        raise WindowsMetadataError("TheraFlow Installed Apps metadata nije moguće pročitati.") from exc

    expected_root = Path(application_root).resolve().parent
    if not display_name.lower().startswith("theraflow"):
        raise WindowsMetadataError("Uninstall zapis ne pripada TheraFlow aplikaciji.")
    if os.path.normcase(str(Path(install_location).resolve())) != os.path.normcase(str(expected_root)):
        raise WindowsMetadataError("TheraFlow InstallLocation ne odgovara install planu.")
    return {
        "available": True,
        "required": required,
        "display_name": display_name,
        "display_version": display_version,
    }


def set_version(application_root, version, previous=None):
    if os.name != "nt":
        return {"updated": False, "reason": "non_windows"}
    import winreg

    previous = previous or snapshot(application_root)
    if not previous.get("available"):
        return {"updated": False, "reason": "metadata_not_installed"}
    try:
        with _open_key(winreg.KEY_READ | winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "DisplayVersion", 0, winreg.REG_SZ, str(version))
            winreg.SetValueEx(key, "DisplayName", 0, winreg.REG_SZ, f"TheraFlow Pilot {version}")
    except PermissionError as exc:
        raise WindowsMetadataError("Nema dozvole za ažuriranje TheraFlow Installed Apps metadata.") from exc
    except OSError as exc:
        raise WindowsMetadataError("TheraFlow Installed Apps metadata nije moguće ažurirati.") from exc
    return {"updated": True, "display_version": str(version)}


def restore(application_root, previous):
    if os.name != "nt" or not previous or not previous.get("available"):
        return {"restored": False}
    import winreg

    try:
        with _open_key(winreg.KEY_READ | winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "DisplayVersion", 0, winreg.REG_SZ, previous["display_version"])
            winreg.SetValueEx(key, "DisplayName", 0, winreg.REG_SZ, previous["display_name"])
    except OSError as exc:
        raise WindowsMetadataError("Prethodni TheraFlow Installed Apps metadata nije moguće vratiti.") from exc
    return {"restored": True, "display_version": previous["display_version"]}
