"""Transactional static assets. Never clear a directory or delete unknown files."""
import json
import os
from pathlib import Path

from .plan_loader import safe_relative, sha256_file


class StaticAssetError(RuntimeError):
    pass


def safe_path(root, relative):
    root = Path(root).absolute()
    parts = safe_relative(relative, "Static asset").parts
    target = root.joinpath(*parts)
    for item in (root, *reversed(target.parents), target):
        if item.exists() or item.is_symlink():
            status = item.lstat()
            if item.is_symlink() or getattr(status, "st_file_attributes", 0) & 0x400:
                raise StaticAssetError("Static asset reparse point is forbidden: " + str(item))
    if root.resolve() not in target.resolve().parents:
        raise StaticAssetError("Static asset escaped its root")
    return target


def inventory(root):
    root = Path(root)
    if not root.exists():
        return {}
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            relative = (Path(directory) / name).relative_to(root).as_posix()
            path = safe_path(root, relative)
            if path.is_file():
                result[relative] = sha256_file(path)
    return result


def _write(path, value):
    temporary = path.with_suffix('.tmp')
    with temporary.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def capture_ownership(plan):
    """Run before replacing code; finder names define application ownership."""
    from .django_commands import run_manage
    destination = Path(plan['backup_root']) / 'static_ownership_before.json'
    code = (
        "import json; from pathlib import Path; from django.contrib.staticfiles.finders import get_finders; "
        "names=sorted({('/'.join(filter(None,[getattr(storage,'prefix',''),name]))).replace(chr(92),'/') "
        "for finder in get_finders() for name,storage in finder.list(['CVS','.*','*~'])}); "
        f"Path({str(destination)!r}).write_text(json.dumps(names),encoding='utf-8')"
    )
    run_manage(plan, ['shell', '-c', code])
    names = json.loads(destination.read_text(encoding='utf-8'))
    for name in names:
        safe_path(Path(plan['application_root']) / 'staticfiles', name)


def _baseline(plan):
    manifest = json.loads((Path(plan['backup_root']) / 'application_snapshot_manifest.json').read_text(encoding='utf-8'))
    if manifest['session_id'] != plan['session_id']:
        raise StaticAssetError('Snapshot session mismatch')
    return {r['original_path'][12:]: r['sha256'] for r in manifest['files'] if r['original_path'].startswith('staticfiles/')}


def install_staged(plan, stage):
    """Persist intent before any write; interrupted copying is recoverable."""
    from .file_installer import _atomic_copy
    backup = Path(plan['backup_root'])
    root = Path(plan['application_root']) / 'staticfiles'
    before = _baseline(plan)
    owned = set(json.loads((backup / 'static_ownership_before.json').read_text(encoding='utf-8')))
    generated = inventory(stage)
    current = inventory(root)
    for name in generated:
        if name in before and name not in owned:
            raise StaticAssetError('New asset would overwrite a user file: ' + name)
        if current.get(name) != before.get(name):
            raise StaticAssetError('Static asset changed since snapshot: ' + name)
    journal = {'session_id': plan['session_id'], 'state': 'intent', 'files': generated}
    _write(backup / 'static_install_journal.json', journal)
    for name, digest in generated.items():
        target = safe_path(root, name)
        if current.get(name) != digest:
            _atomic_copy(safe_path(stage, name), target)
        if sha256_file(target) != digest:
            raise StaticAssetError('Static installation hash mismatch: ' + name)
    journal['state'] = 'installed'
    _write(backup / 'static_install_journal.json', journal)
    return {'exit_code': 0, 'static_assets': len(generated), 'ownership_journal': str(backup / 'static_install_journal.json')}


def collect(plan):
    from .django_commands import run_manage
    stage = Path(plan['backup_root']) / 'generated_static'
    if stage.exists():
        raise StaticAssetError('Static staging already exists; preserve it for recovery')
    code = (
        'from django.conf import settings; from django.core.management import call_command; '
        f'settings.STATIC_ROOT={str(stage)!r}; '
        'from django.core.files.storage import storages; from django.contrib.staticfiles.storage import staticfiles_storage; '
        'from django.utils.functional import empty; from pathlib import Path; '
        "storages._storages.pop('staticfiles',None); staticfiles_storage._wrapped=empty; "
        f'assert Path(staticfiles_storage.location).resolve()==Path({str(stage)!r}).resolve(); '
        "call_command('collectstatic',interactive=False,verbosity=0)"
    )
    run_manage(plan, ['shell', '-c', code], timeout=600)
    return install_staged(plan, stage)


def restore(plan):
    from .file_installer import _atomic_copy
    backup = Path(plan['backup_root'])
    journal_path = backup / 'static_install_journal.json'
    if not journal_path.exists():
        # Failure before static installation. No generated files were copied.
        if not (backup / 'static_ownership_before.json').is_file():
            raise StaticAssetError('Static ownership record missing; legacy rollback requires review')
        return {'restored': [], 'removed': [], 'not_installed': True}
    journal = json.loads(journal_path.read_text(encoding='utf-8'))
    if journal['session_id'] != plan['session_id'] or journal['state'] not in ('intent', 'installed'):
        raise StaticAssetError('Static journal identity mismatch')
    before = _baseline(plan)
    root = Path(plan['application_root']) / 'staticfiles'
    restored, removed, operations = [], [], []
    # Validate every target before changing any; unknown edits are preserved.
    for name, new_hash in journal['files'].items():
        target = safe_path(root, name)
        if target.exists() and not target.is_file():
            raise StaticAssetError('Static target is no longer a file: ' + name)
        current = sha256_file(target) if target.exists() else None
        old_hash = before.get(name)
        if current == old_hash:
            continue
        if current != new_hash:
            raise StaticAssetError('Preserved unexpected user change; manual recovery required: ' + name)
        source = None
        if old_hash is not None:
            source = safe_path(backup / 'application_snapshot/staticfiles', name)
            if not source.is_file() or sha256_file(source) != old_hash:
                raise StaticAssetError('Static backup failed hash validation: ' + name)
        operations.append((name, target, source, old_hash))
    for name, target, source, old_hash in operations:
        if source is not None:
            _atomic_copy(source, target)
            if sha256_file(target) != old_hash:
                raise StaticAssetError('Static restore hash mismatch: ' + name)
            restored.append(name)
        else:
            target.unlink()  # exact journal-owned file with the recorded new hash
            removed.append(name)
    report = {'restored': restored, 'removed': removed, 'unknown_files_preserved': True}
    _write(backup / 'static_rollback_report.json', report)
    return report
