import json
import logging
import os
import re
import threading
import time
import subprocess
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path


PUBLIC_STATE_FIELDS = {
    "session_id", "current_version", "target_version", "status", "current_step",
    "progress_percent", "started_at", "updated_at", "completed_at", "updater_pid",
    "error_code", "error_message",
    "migration_started", "migration_completed", "service_status", "health_check_status",
    "rollback_type", "rollback_reason", "rollback_started_at", "rollback_completed_at",
    "rollback_trigger", "rollback_error_code", "rollback_error_message",
    "files_restored", "config_restored", "database_restored",
    "previous_version_restored", "manual_action_required", "last_successful_step",
    "last_attempted_step", "failed_step", "step_started_at", "step_completed_at",
    "failed_step_label",
    "windows_metadata_status",
    "updater_request_id", "updater_request_created_at", "execution_owner",
    "reconciliation_pending",
}


_STATE_WRITE_LOCK = threading.RLock()

PROCESS_STEPS = {
    1: "Manifest loaded",
    2: "Version comparison",
    3: "Update package downloaded",
    4: "SHA256 verified",
    5: "Backup created",
    6: "Stop service",
    7: "Extract package",
    8: "Replace files",
    9: "Run migrations",
    10: "Collectstatic",
    11: "Start service",
    12: "Health check",
    13: "Cleanup",
}

INTERNAL_STEP_TO_PROCESS = {
    "plan_validation": "Pre-install validation",
    "service_stop": "STEP 6 - Stop service",
    "application_backup": "STEP 5 - Backup created (application snapshot)",
    "install": "STEP 8 - Replace files",
    "django_check": "STEP 9 - Run migrations (Django pre-check)",
    "migrate": "STEP 9 - Run migrations",
    "collectstatic": "STEP 10 - Collectstatic",
    "restart": "STEP 11 - Start service",
    "health_check": "STEP 12 - Health check",
    "windows_metadata": "Windows Installed Apps metadata",
    "finalize": "STEP 13 - Cleanup",
}


def process_step_label(step):
    if isinstance(step, int):
        return f"STEP {step} - {PROCESS_STEPS.get(step, 'Unknown')}"
    return INTERNAL_STEP_TO_PROCESS.get(str(step), str(step or "Unknown step"))


def _trace_path(data_root=None):
    if data_root:
        root = Path(data_root)
    else:
        try:
            from django.conf import settings
            root = Path(
                settings.THERAFLOW_PROGRAM_DATA_ROOT
                if getattr(settings, "PRODUCTION_MODE", False)
                else settings.THERAFLOW_DATA_DIR
            )
        except Exception:
            from theraflow.installed_paths import installed_paths

            root = installed_paths().root
    destination = root.resolve() / "logs" / "update_process.log"
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination


def trace_update_step(
    step,
    event,
    *,
    session_id="none",
    function_name="",
    paths=None,
    exit_code=None,
    exception=None,
    message="",
    data_root=None,
):
    """Upiši jednu potpunu, redaktovanu fazu u zajednički updater log."""
    timestamp = datetime.now(timezone.utc).isoformat()
    label = process_step_label(step)
    path_values = {
        str(key): str(value)
        for key, value in dict(paths or {}).items()
        if value is not None
    }
    exception_type = type(exception).__name__ if exception else ""
    exception_message = safe_message(exception or message)
    if exception and exception.__traceback__:
        traceback_text = "".join(
            traceback.format_exception(type(exception), exception, exception.__traceback__)
        )
    elif exception:
        traceback_text = "".join(traceback.format_stack()[:-1])
    else:
        traceback_text = ""
    lines = [
        (
            f"{timestamp} session={session_id} {label} event={event} "
            f"function={function_name or '-'} exit_code={exit_code if exit_code is not None else '-'} "
            f"paths={json.dumps(path_values, ensure_ascii=False, sort_keys=True)}"
        )
    ]
    if message or exception:
        lines.append(
            f"exception_type={exception_type or '-'} exception_message={exception_message or '-'}"
        )
    if message and exception:
        lines.append(f"context={_redact_text(message)}")
    if traceback_text:
        lines.append("TRACEBACK:")
        lines.append(_redact_text(traceback_text))
    try:
        with _trace_path(data_root).open("a", encoding="utf-8") as handle:
            handle.write("\n".join(lines) + "\n")
    except OSError:
        logging.getLogger(__name__).exception("Zajednički updater trace log nije dostupan.")
    return label


def read_state(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Update state nije validan.")
    return data


def write_state(path, **changes):
    path = Path(path).resolve()
    with _STATE_WRITE_LOCK:
        state = read_state(path) if path.exists() else {}
        if "error_message" in changes:
            changes["error_message"] = safe_message(changes["error_message"])
        if "rollback_error_message" in changes:
            changes["rollback_error_message"] = safe_message(changes["rollback_error_message"])
        state.update(changes)
        state["updated_at"] = datetime.now(timezone.utc).isoformat()
        _atomic_json_replace(path, state)
        return state


def write_terminal_success(path, *, completed_at=None, **changes):
    """Persist every success invariant in one durable JSON replacement.

    A preceding UI/recovery observation is audit information, not live failure
    state.  Finalization therefore clears transient failure fields instead of
    merging them into a successful result.
    """

    terminal_at = str(completed_at or datetime.now(timezone.utc).isoformat())
    success = {
        "status": "update_completed",
        "is_active": False,
        "progress_percent": 100,
        "failed_step": None,
        "failed_step_label": "",
        "error_code": "",
        "error_message": "",
        "rollback_error_code": "",
        "rollback_error_message": "",
        "install_completed_at": terminal_at,
        "completed_at": terminal_at,
        "last_attempted_step": "finalize",
        "last_successful_step": "finalize",
        "step_completed_at": terminal_at,
        "manual_action_required": False,
        "reconciliation_pending": False,
        "updater_pid": None,
    }
    success.update(changes)
    # Callers cannot accidentally reintroduce contradictory terminal fields.
    success.update(
        {
            "status": "update_completed",
            "is_active": False,
            "progress_percent": 100,
            "failed_step": None,
            "failed_step_label": "",
            "error_code": "",
            "error_message": "",
            "install_completed_at": terminal_at,
            "completed_at": terminal_at,
            "last_attempted_step": "finalize",
            "last_successful_step": "finalize",
            "step_completed_at": terminal_at,
            "manual_action_required": False,
            "reconciliation_pending": False,
            "updater_pid": None,
        }
    )
    return write_state(path, **success)


def _atomic_json_replace(path, state):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(
        f".{path.name}.tmp.{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex}"
    )
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(state, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        for attempt in range(9):
            try:
                os.replace(temporary, path)
                break
            except OSError as exc:
                if attempt == 0 or attempt == 8:
                    _record_replace_failure(path, temporary, exc, attempt)
                # A short-lived reader/AV handle can deny rename. This bounded
                # retry is a resilience measure, not a historical root-cause claim.
                if os.name != 'nt' or getattr(exc, 'winerror', None) not in (5, 32) or attempt == 8:
                    raise
                time.sleep(0.1)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def _record_replace_failure(path, temporary, error, attempt):
    def facts(p):
        try:
            s = p.stat()
            return {'exists': True, 'attributes': getattr(s, 'st_file_attributes', None), 'size': s.st_size}
        except OSError as e:
            return {'exists': False, 'stat_winerror': getattr(e, 'winerror', None)}
    record = {'utc': datetime.now(timezone.utc).isoformat(), 'operation': 'os.replace',
              'pid': os.getpid(), 'thread': threading.get_ident(), 'attempt': attempt,
              'winerror': getattr(error, 'winerror', None), 'source': str(temporary),
              'destination': str(path), 'source_facts': facts(temporary), 'destination_facts': facts(path)}
    if os.name == 'nt':
        for label, command in [('identity', ['whoami.exe', '/user', '/fo', 'csv', '/nh']),
                               ('current_acl', ['icacls.exe', str(path)])]:
            try:
                value = subprocess.run(command, capture_output=True, text=True, timeout=3,
                                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                record[label] = value.stdout.strip()[:4000]
            except (OSError, subprocess.SubprocessError):
                record[label] = 'unavailable'
    try:
        with (path.parent / 'atomic_replace_errors.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(record, ensure_ascii=False) + '\n')
    except OSError:
        logging.getLogger(__name__).exception('Atomic replacement evidence could not be saved')


def public_state(state):
    result = {key: state.get(key) for key in PUBLIC_STATE_FIELDS if key in state}
    if "error_message" in result:
        result["error_message"] = safe_message(result["error_message"])
    if "rollback_error_message" in result:
        result["rollback_error_message"] = safe_message(result["rollback_error_message"])
    return result


def safe_message(value):
    value = str(value or "")[:1000]
    value = _redact_text(value)
    return re.sub(r"(?:[A-Za-z]:[\\/]|\\\\)[^\s'\"]+", "[PATH]", value)


def _redact_text(value):
    value = re.sub(r"(?i)(password|secret_key|token)\s*[=:]\s*\S+", r"\1=[REDACTED]", str(value or ""))
    return value
