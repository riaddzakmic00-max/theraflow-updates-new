"""Process-bound install handoff shared by the launcher, updater and recovery.

The file lives inside the copied updater runtime as well as the application so
the LocalSystem worker and the restarted web process evaluate identical proof.
"""

import hmac
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from dashboard.scheduler_lease import (
    inspect_process,
    normalize_process_creation_utc_epoch_ms,
)


INSTALL_LOCK_FORMAT_VERSION = 2


def _canonical_path(value):
    value = os.path.expandvars(str(value or "").strip().strip('"'))
    if not value:
        return ""
    return os.path.normcase(os.path.normpath(os.path.abspath(value)))


def _atomic_lock_replace(path, payload):
    path = Path(path).resolve()
    temporary = path.with_name(f".{path.name}.bind.{os.getpid()}.tmp")
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def read_install_lock(path):
    path = Path(path).resolve()
    try:
        raw = path.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeError):
        return None
    if not raw:
        return None
    try:
        value = json.loads(raw)
    except ValueError:
        # Build 3.4.20 and earlier used only the session UUID.  It is accepted
        # solely as launcher handoff input and never as process ownership proof.
        return {"format_version": 1, "session_id": raw}
    return value if isinstance(value, dict) else None


def bind_install_lock(path, session_id, *, inspector=inspect_process):
    """Upgrade the launcher's session lock to a PID+creation-time lease."""

    path = Path(path).resolve()
    existing = read_install_lock(path)
    if not existing or str(existing.get("session_id") or "") != str(session_id):
        raise RuntimeError("Install lock ne odgovara update sessionu.")
    pid = os.getpid()
    actual = inspector(pid)
    if not isinstance(actual, dict) or int(actual.get("pid") or 0) != pid:
        raise RuntimeError("Updater process identitet nije dostupan.")
    creation = normalize_process_creation_utc_epoch_ms(
        actual.get("created_at_utc_epoch_ms", actual.get("created_at"))
    )
    executable = _canonical_path(actual.get("executable"))
    command_line = str(actual.get("command_line") or "").strip()
    if creation is None or not executable or not command_line:
        raise RuntimeError("Updater PID/creation/executable identitet nije potpun.")
    payload = {
        "format_version": INSTALL_LOCK_FORMAT_VERSION,
        "session_id": str(session_id),
        "pid": pid,
        "process_created_at_utc_epoch_ms": creation,
        "executable": executable,
        "command_line": command_line,
        "bound_at": datetime.now(timezone.utc).isoformat(),
    }
    _atomic_lock_replace(path, payload)
    return payload


def install_lock_identity(path, session_id, *, inspector=inspect_process):
    """Return fail-closed ownership predicates for a process-bound lock."""

    lock = read_install_lock(path)
    predicates = {
        "exists": bool(lock),
        "format": False,
        "session": False,
        "pid": False,
        "creation": False,
        "executable": False,
        "command": False,
        "active": False,
    }
    if not lock:
        return predicates
    predicates["format"] = lock.get("format_version") == INSTALL_LOCK_FORMAT_VERSION
    predicates["session"] = str(lock.get("session_id") or "") == str(session_id)
    if not predicates["format"] or not predicates["session"]:
        return predicates
    try:
        pid = int(lock.get("pid") or 0)
    except (TypeError, ValueError):
        return predicates
    actual = inspector(pid) if pid > 0 else None
    if not isinstance(actual, dict):
        return predicates
    predicates["pid"] = int(actual.get("pid") or 0) == pid
    recorded_creation = normalize_process_creation_utc_epoch_ms(
        lock.get("process_created_at_utc_epoch_ms")
    )
    actual_creation = normalize_process_creation_utc_epoch_ms(
        actual.get("created_at_utc_epoch_ms", actual.get("created_at"))
    )
    predicates["creation"] = (
        recorded_creation is not None
        and actual_creation is not None
        and abs(recorded_creation - actual_creation) <= 1
    )
    predicates["executable"] = hmac.compare_digest(
        _canonical_path(lock.get("executable")),
        _canonical_path(actual.get("executable")),
    )
    predicates["command"] = hmac.compare_digest(
        str(lock.get("command_line") or ""),
        str(actual.get("command_line") or ""),
    )
    predicates["active"] = all(
        predicates[key]
        for key in ("format", "session", "pid", "creation", "executable", "command")
    )
    predicates["lock"] = lock
    return predicates


def release_install_lock(path, session_id, *, inspector=inspect_process):
    proof = install_lock_identity(path, session_id, inspector=inspector)
    if not proof.get("active") or int((proof.get("lock") or {}).get("pid") or 0) != os.getpid():
        raise RuntimeError("Install lock ownership je izgubljen; lock ostaje sačuvan.")
    Path(path).resolve().unlink()
    return True

