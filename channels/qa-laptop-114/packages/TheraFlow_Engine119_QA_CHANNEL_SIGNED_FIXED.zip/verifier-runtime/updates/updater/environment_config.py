from pathlib import Path
from theraflow.environment import canonical_env_path as _canonical_env_path


class CanonicalEnvironmentError(RuntimeError):
    pass


def canonical_env_path(program_data_root=None):
    """Return the only production .env path accepted by the updater."""
    if program_data_root is not None:
        return (Path(program_data_root) / "TheraFlow" / "config" / ".env").resolve()
    return _canonical_env_path()


def require_canonical_env_file(program_data_root=None):
    path = canonical_env_path(program_data_root)
    if not path.is_file():
        raise CanonicalEnvironmentError(
            f"Kanonski TheraFlow .env nije pronađen: {path}"
        )
    return path
