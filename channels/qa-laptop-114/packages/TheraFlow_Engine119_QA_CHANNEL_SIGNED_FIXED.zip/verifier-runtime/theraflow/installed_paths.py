"""Canonical installed-mode paths shared by every updater process.

This module deliberately has no Django dependency.  The web application,
LocalSystem worker, copied updater runtime and repair recovery command must all
derive durable update paths from the same source.
"""

from dataclasses import dataclass
import os
from pathlib import Path


@dataclass(frozen=True)
class InstalledTheraFlowPaths:
    root: Path
    config: Path
    canonical_env: Path
    updates: Path
    packages: Path
    staging: Path
    sessions: Path
    service_requests: Path
    backups: Path
    logs: Path
    updater_service_key: Path


def _resolved_local(path):
    resolved = Path(path).expanduser().resolve()
    if str(resolved).startswith("\\\\"):
        raise ValueError("Mrežna putanja nije dozvoljena za TheraFlow instalaciju.")
    return resolved


def paths_from_root(root):
    root = _resolved_local(root)
    config = root / "config"
    updates = root / "updates"
    return InstalledTheraFlowPaths(
        root=root,
        config=config,
        canonical_env=config / ".env",
        updates=updates,
        packages=updates / "packages",
        staging=updates / "staging",
        sessions=updates / "sessions",
        service_requests=updates / "service_requests",
        backups=root / "backups" / "updates",
        logs=root / "logs",
        updater_service_key=config / "updater_service.key",
    )


def installed_paths(program_data=None):
    """Return the canonical ProgramData/TheraFlow layout."""
    program_data = program_data or os.environ.get("PROGRAMDATA", r"C:\ProgramData")
    return paths_from_root(_resolved_local(program_data) / "TheraFlow")


def canonical_session_plan(session_id, *, program_data=None):
    return installed_paths(program_data).sessions / str(session_id) / "install_plan.json"
