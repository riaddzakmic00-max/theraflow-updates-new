import os
from pathlib import Path


def _windows_account_name():
    """Read the current Windows token account without environment variables."""
    import ctypes
    from ctypes import wintypes

    # NameSamCompatible produces DOMAIN\\user (including NT AUTHORITY\\SYSTEM)
    # from the process token.  Unlike getpass.getuser(), this does not depend on
    # LOGNAME/USER/LNAME/USERNAME being present in a service environment.
    name_sam_compatible = 2
    secur32 = ctypes.WinDLL("secur32", use_last_error=True)
    get_user_name_ex = secur32.GetUserNameExW
    get_user_name_ex.argtypes = [wintypes.ULONG, wintypes.LPWSTR, ctypes.POINTER(wintypes.ULONG)]
    get_user_name_ex.restype = wintypes.BOOL
    size = wintypes.ULONG(0)
    get_user_name_ex(name_sam_compatible, None, ctypes.byref(size))
    if size.value:
        buffer = ctypes.create_unicode_buffer(size.value)
        if get_user_name_ex(name_sam_compatible, buffer, ctypes.byref(size)):
            value = buffer.value.strip()
            if value:
                return value

    # Some restricted tokens do not expose an extended SAM name.  The basic
    # Win32 API still reads the token identity and remains environment-free.
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    get_user_name = advapi32.GetUserNameW
    get_user_name.argtypes = [wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    get_user_name.restype = wintypes.BOOL
    basic_size = wintypes.DWORD(256)
    basic_buffer = ctypes.create_unicode_buffer(basic_size.value)
    if not get_user_name(basic_buffer, ctypes.byref(basic_size)):
        raise ctypes.WinError(ctypes.get_last_error())
    value = basic_buffer.value.strip()
    if not value:
        raise OSError("Windows process token has no account name")
    return value


def current_process_identity():
    """Return non-fatal diagnostic identity details for the current process.

    Security authorization must continue to use explicit elevation, LocalSystem,
    signed-plan, PID and ownership gates.  This helper is diagnostic only and is
    deliberately fail-safe: inability to format an account name returns
    ``unknown`` and can never abort an update or rollback.
    """
    try:
        if os.name == "nt":
            identity = _windows_account_name()
            source = "windows_process_token"
        else:
            import pwd

            identity = pwd.getpwuid(os.geteuid()).pw_name
            source = "posix_process_uid"
        identity = str(identity or "").strip()
        if not identity:
            raise OSError("Process token identity is empty")
        return {"identity": identity, "source": source, "error_type": ""}
    except Exception as exc:  # diagnostic logging must never block safety work
        return {
            "identity": "unknown",
            "source": "fallback",
            "error_type": type(exc).__name__,
        }


def current_process_elevation():
    """Return the Windows elevation state without weakening unknown to allowed."""
    if os.name != "nt":
        return None
    try:
        import ctypes

        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return None


def production_mode(environ=None):
    environ = environ or os.environ
    return str(environ.get("THERAFLOW_PRODUCTION", "False")).lower() in {
        "1", "true", "yes", "on",
    }


def canonical_env_path(environ=None):
    """Return the sole supported installed-mode configuration path."""
    environ = environ or os.environ
    program_data = Path(environ.get("PROGRAMDATA", r"C:\ProgramData"))
    return (program_data / "TheraFlow" / "config" / ".env").resolve()


def resolve_env_path(*, base_dir=None, environ=None, installed=None):
    environ = environ or os.environ
    installed = production_mode(environ) if installed is None else bool(installed)
    if installed:
        # THERAFLOW_ENV_FILE must never redirect an installed instance into the
        # working directory, Program Files, an update package, or staging.
        return canonical_env_path(environ)
    base_dir = Path(base_dir or Path.cwd()).resolve()
    return Path(environ.get("THERAFLOW_ENV_FILE", base_dir / ".env")).resolve()
