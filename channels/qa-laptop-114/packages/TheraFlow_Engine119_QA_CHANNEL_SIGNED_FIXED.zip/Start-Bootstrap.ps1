# Sign this final generated launcher with the approved publisher certificate.
# No self-signed publisher is created by the build. No execution-policy override.
[CmdletBinding()]
param(
 [ValidateSet('Inspect','Apply','Recover','Rollback')][string]$Mode='Inspect',
 [string]$Profile
)
$ErrorActionPreference='Stop'
$bundle=$PSScriptRoot
$expectedManifest='73d8fa7252e250c8488ba655045cab74ff7954e356391f0088f0f0ab85fe2e54'
$manifestPath=Join-Path $bundle 'bootstrap-manifest.json'
if ((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedManifest) { throw 'Manifest integrity mismatch.' }
$m=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$allowed=@($m.bundle_files.PSObject.Properties.Name)+@('bootstrap-manifest.json','Start-Bootstrap.ps1')
$found=@()
$pending=New-Object 'Collections.Generic.Queue[string]'
$pending.Enqueue($bundle)
while ($pending.Count -gt 0) {
 foreach ($item in @(Get-ChildItem -LiteralPath $pending.Dequeue() -Force)) {
  if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse points in release bundle are forbidden.' }
  if ($item.PSIsContainer) { $pending.Enqueue($item.FullName) }
  else {
   $name=$item.FullName.Substring($bundle.Length+1).Replace('\','/')
   if ($name -notin $allowed) { throw 'Unexpected release file; possible Python module shadowing.' }
   $found+=$name
  }
 }
}
if ($found.Count -ne $allowed.Count) { throw 'Release file inventory mismatch.' }
foreach ($entry in $m.bundle_files.PSObject.Properties) {
 if ($entry.Name.Contains('..') -or $entry.Name.Contains(':') -or $entry.Name.StartsWith('/') -or $entry.Name.Contains('\')) { throw 'Unsafe bundle path.' }
 $path=Join-Path $bundle $entry.Name
 if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Value) { throw 'Bundle file hash mismatch.' }
}
if ($Mode -eq 'Inspect') {
 [ordered]@{status='QA_CANDIDATE_NOT_APPROVED';source_app='1.1.4';source_engine='1.1.8';target_engine='1.1.9';application_unchanged=$true;manifest_sha256=$expectedManifest;native_qa='BLOCKED';production_allowed=$false} | ConvertTo-Json
 exit 0
}
if (-not $Profile) { throw 'Explicit protected local profile is required.' }
$signature=Get-AuthenticodeSignature -LiteralPath $PSCommandPath
if ($signature.Status -ne 'Valid') { throw 'Trusted publisher signature required. Do not bypass signature verification.' }
$p=Get-Content -LiteralPath $Profile -Raw | ConvertFrom-Json
$work=Join-Path $env:ProgramData ('TheraFlow\bootstrap\'+$p.session_id)
& (Join-Path $bundle 'Native.ps1') -Action Authorize -Profile $Profile -Bundle $bundle -Work $work | Out-Null
if (-not $?) { throw 'Local authorization failed.' }
$python=[string]$p.python_executable
& $python -B (Join-Path $bundle 'bootstrap.py') --mode $Mode --profile $Profile
if ($LASTEXITCODE -ne 0) { throw 'Bootstrap stopped. Retain protected journal and use controlled recovery.' }

# SIG # Begin signature block
# MIIHkAYJKoZIhvcNAQcCoIIHgTCCB30CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBkss7c+zNCavJh
# xt1wHuN+eqOuF0+WGYXSPO80sXrSb6CCBFwwggRYMIICwKADAgECAhBzMIILveQ7
# iERUyr3xCdgkMA0GCSqGSIb3DQEBCwUAMEQxFTATBgNVBAoMDFRoZXJhRmxvdyBR
# QTErMCkGA1UEAwwiVGhlcmFGbG93IElzb2xhdGVkIFFBIFNpZ25pbmcgMjAyNjAe
# Fw0yNjEwMTgxNTA0MzhaFw0yODEwMTgxNTE0MzdaMEQxFTATBgNVBAoMDFRoZXJh
# RmxvdyBRQTErMCkGA1UEAwwiVGhlcmFGbG93IElzb2xhdGVkIFFBIFNpZ25pbmcg
# MjAyNjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBAKgKtDaRNSZYwpHb
# FbacHFgABXiLqpNg+4Ba3xfsan7fsgJsKVG0tj2amE6jDIzgCnQt8bMG4Dkx6tOe
# w74UbgjKHM9I2Jd6aqRvqP44o1b4pq7WjqyZFCzy56TKSatAlgYqQgGex5jfwUZU
# I396XSM/C0ABHD+r4Rex7cluvddzFsGI3Q2FIHKUrjGHuYVSd1uqf71wDRFQzD0O
# F/o/MMBH/kF/uCkm7Se38inzj/RxWVcFdO+sAmopJjH8H3Q0U8LDBUyDdJMgQKRu
# ZV3zcxVJxna49MLfXP6dKBdds3lGpxR0L7cKUPXp5CJuWLpsYph9UB3LyMPgM0zj
# 58dSN5ccXIJEIGsKDb+gRe94Uo0jFR6gaiY7V7MEhySkRaWG1YlZ4YfAsHCxPysU
# y1xB2c8U176QEiLkqXG0wePhvBWOW75o1HT7B5FthecHXJfxOljKaFtLitr7Xtpb
# QC2stSeLIFBejKK4G6kuYUE83ZoRYq30xTlecW11EdlQWZI7AQIDAQABo0YwRDAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFPZO
# JufXPRpeNx7TiAkHLyTFoV77MA0GCSqGSIb3DQEBCwUAA4IBgQCnCFvNW/FOy+Db
# /BzL11lmv6f4xRd7+1UO/tSchnDbDCh4g9pcl0RI3OxUCdeeLZV8mqFI6U2m3CIV
# USTpShYtbF8d1+jtQ8CEZO4IDt7/ygh35nuE6p5ajHCB45re7tmQKjin+nQY/Ctp
# jqqoPnTu94vKCGlMByygn3ts/v71/41/MS6+RbKE+CARhl89mGmjoYyiP1U2o0cz
# Sy4beIizvfDcKVaD8WCkLQksp69DK2S6vAb4cN9B/7OO+dZOgZ/xnXSTrQqO6f4H
# PyFTcWOlso1+4+578QurGQyg/3pGDeqLNcvFMlKWaMkTLOiXMNbhPbkDspxacNGD
# 0WIUXwTTQdZkQ7Xji7E0lesaYL1cqNl4dic8uYSKbt776fWZyQL6fe3eLxNwXbFa
# f4Han6GKVslHRsBd9YVxwv7yAza0EQXEkEHhQPeQg1vzmjfgBRKqkMvfr/6EbJMG
# Q5kLpAl45kQllcQ5nMzAecoNrdhCM/KVaO/YQDPCqnxGoY818H4xggKKMIIChgIB
# ATBYMEQxFTATBgNVBAoMDFRoZXJhRmxvdyBRQTErMCkGA1UEAwwiVGhlcmFGbG93
# IElzb2xhdGVkIFFBIFNpZ25pbmcgMjAyNgIQczCCC73kO4hEVMq98QnYJDANBglg
# hkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCBTqXZ2mTg1yAOSSxeuMbwnAnvdeILFZFdyrLdUhgW4
# kjANBgkqhkiG9w0BAQEFAASCAYBYkLNnFEwDQnnkEC+XNphHmGZmYa0pPb4mT0wG
# R5NmaQrz+HsrEPHhkLKlWUZdr4ji2WUQEqJCEuIopXxeOCzrQdAWUgsggd/kubNQ
# xZy5VGU0F6o51djTi5stgN51A64cTe1HX8cciRqs56c26OzWktKJCpjErR7l6pfi
# oPqiKx9NAJKqz7j0YZ4a0L88zlauqbekVDighVKsYXo6MINSWymJBuPLAS1k+y+T
# fLzbPfFyExAfMWqT0pr4N3Hghvh3SktrehGuSMYNrUB6pNASlJVv8pHlBNAYVkQD
# pK9oNFFl01U65d1pDqlECsWESOZcuzdsQII6IeV5yVTdqrlpXO2pH5UA6bKPGoQ0
# i8FT9YsdcJNRVmgpDaV2+QHIQXkDHxPOikK/ZLolcdMuK25F0w7cMXr2bp+EQY+J
# 4wHJ/4s+IR+n5b2O7NVNGJUyW+2K99UuzEM6kAmeBj+UVPcTL90jIrvW8OXAqACJ
# dRbXRf9u8I/zEiUU/i+AGJqh6zs=
# SIG # End signature block
