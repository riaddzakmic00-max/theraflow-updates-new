"""Journaled updater-only bootstrap. No business migration or database rollback.

Native operations are injected so fault tests never operate Windows services.
The native adapter is responsible for authenticated release/host authorization,
exclusive process locks, protected storage, services and verified DB recovery.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil


class BootstrapError(RuntimeError):
    pass


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path, content):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.bootstrap-tmp')
    with temporary.open('wb') as stream:
        stream.write(content);stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)


def save(path, value):
    atomic(path,json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2).encode())


def relative(root, name):
    p=PurePosixPath(name)
    if (not name or '\\' in name or ':' in name or p.is_absolute()
            or any(x in ('..','.') for x in p.parts)):
        raise BootstrapError('unsafe_relative_path')
    root=Path(root).absolute()
    target=root.joinpath(*p.parts)
    # Reject junctions/reparse points too, including the root and its ancestors.
    for item in [target,*target.parents]:
        if item.exists() and (item.is_symlink() or getattr(item,'is_junction',lambda:False)()):
            raise BootstrapError('reparse_point_refused')
    if not target.resolve().is_relative_to(root.resolve()):raise BootstrapError('path_escape')
    return target


ALLOWED={
 'theraflow/version.py','theraflow/repair_baseline.py','updates/services/package_staging.py',
 'updates/services/update_preparation.py','updates/services/updater_launcher.py',
 'updates/updater/baseline_114_migrations.json','updates/updater/database_restore.py',
 'updates/updater/maintenance.py','updates/updater/plan_loader.py',
 'updates/updater/file_installer.py','updates/updater/snapshot_restore.py',
 'updates/updater/recovery_safety.py','updates/updater/rollback_manager.py',
 'updates/updater/runner.py','updates/updater/completed_rollback.py',
 'updates/updater/history_writer.py',
 'theraflow/release_signing.py','updates/updater/release_policy.py',
 'updates/services/update_checker.py','updates/services/update_downloader.py',
 'updates/services/update_state.py','updates/services/manifest_identity.py'}


class Bootstrap:
    def __init__(self,bundle,app,work,adapter):
        self.bundle=Path(bundle).resolve();self.app=Path(app).resolve();self.work=Path(work).resolve()
        self.adapter=adapter;self.journal=self.work/'journal.json'
        self.manifest=json.loads((self.bundle/'bootstrap-manifest.json').read_text(encoding='utf-8'))
        self.identity=sha(self.bundle/'bootstrap-manifest.json')
        self.rows=self.manifest['files']
        if len(self.rows)!=len(ALLOWED) or {r['path'] for r in self.rows}!=ALLOWED:raise BootstrapError('allowlist_mismatch')
        if (self.manifest['source_application'],self.manifest['source_engine'],self.manifest['target_engine'])!=('1.1.4','1.1.8','1.1.9'):
            raise BootstrapError('version_contract')
        if self.work==self.app or self.work.is_relative_to(self.app) or self.app.is_relative_to(self.work):
            raise BootstrapError('workspace_overlap')
        for row in self.rows:
            if sha(relative(self.bundle/'updater-files',row['path']))!=row['target_sha256']:
                raise BootstrapError('payload_integrity')

    def record(self,phase,**extra):
        self.state.update(phase=phase,**extra);save(self.journal,self.state)
        self.adapter.checkpoint(phase)

    def source(self):
        for name,digest in self.manifest['source_files'].items():
            path=relative(self.app,name)
            if not path.is_file() or sha(path)!=digest:raise BootstrapError('source_fingerprint_mismatch')
        for row in self.rows:
            if row['source_114_sha256'] is None and relative(self.app,row['path']).exists():
                raise BootstrapError('unexpected_existing_target')

    def snapshot(self):
        for row in self.rows:
            if row['source_114_sha256'] is not None:
                target=relative(self.work/'snapshot',row['path'])
                atomic(target,relative(self.app,row['path']).read_bytes())
                if sha(target)!=row['source_114_sha256']:raise BootstrapError('snapshot_integrity')

    def validate_snapshot(self):
        for row in self.rows:
            if row['source_114_sha256'] is not None:
                if sha(relative(self.work/'snapshot',row['path']))!=row['source_114_sha256']:
                    raise BootstrapError('snapshot_integrity')

    def validate_current(self):
        # Recovery never overwrites an unrelated/newer application, even if the
        # journal claims a replacement was in progress.
        changed={r['path']:r for r in self.rows}
        for name,digest in self.manifest['source_files'].items():
            path=relative(self.app,name)
            allowed={digest}
            if name in changed:allowed.add(changed[name]['target_sha256'])
            if not path.is_file() or sha(path) not in allowed:raise BootstrapError('unknown_current_file')
        for row in self.rows:
            if row['source_114_sha256'] is None:
                path=relative(self.app,row['path'])
                if path.exists() and sha(path)!=row['target_sha256']:raise BootstrapError('unknown_current_file')

    def install(self):
        # Metadata is last, but a reboot is blocked from starting all three app
        # services until the recovery task finishes. Multi-file rename is not atomic.
        for row in sorted(self.rows,key=lambda r:(r['path']=='theraflow/repair_baseline.py',r['path'])):
            self.record('replacing',next_file=row['path'])
            atomic(relative(self.app,row['path']),relative(self.bundle/'updater-files',row['path']).read_bytes())
            if sha(relative(self.app,row['path']))!=row['target_sha256']:raise BootstrapError('installed_hash_mismatch')
            self.adapter.checkpoint('replaced:'+row['path'])

    def target(self):
        for row in self.rows:
            if sha(relative(self.app,row['path']))!=row['target_sha256']:raise BootstrapError('target_fingerprint_mismatch')
        for name,digest in self.manifest['source_files'].items():
            if name not in ALLOWED and sha(relative(self.app,name))!=digest:raise BootstrapError('unrelated_file_changed')

    def restore_source_files(self):
        self.validate_snapshot()
        self.validate_current()
        for row in self.rows:
            self.record('rollback_replacing',next_file=row['path'])
            target=relative(self.app,row['path'])
            if row['source_114_sha256'] is None:
                if target.exists():target.unlink()
            else:
                atomic(target,relative(self.work/'snapshot',row['path']).read_bytes())
            self.adapter.checkpoint('rollback_replaced:'+row['path'])
        self.source()

    def rollback(self):
        """Explicit post-commit engine rollback; never entered by Recover alone."""
        self.adapter.authorize(self.bundle,self.identity,recovery=True)
        with self.adapter.exclusive():
            self.state=json.loads(self.journal.read_text(encoding='utf-8'))
            self._validate_journal()
            if self.state['phase']=='rolled_back':
                return self._finish_rollback()
            if self.state['phase']!='complete':raise BootstrapError('rollback_requires_completed_install')
            self.target();self.validate_snapshot()
            self.adapter.preflight_rollback()
            self.record('rollback_intent')
            self.adapter.register_recovery()
            return self._finish_rollback()

    def _validate_journal(self):
        if (self.state['manifest_sha256']!=self.identity or self.state['app']!=str(self.app)
                or self.state['protocol']!=1 or self.state['context_sha256']!=self.adapter.context_identity()):
            raise BootstrapError('journal_identity')

    def _finish_rollback(self):
        phase=self.state['phase']
        if phase=='rolled_back':
            self.source();self.adapter.assert_rollback_complete()
            self.adapter.complete_services(self.state['original_services'])
            self.adapter.unregister_recovery();return 'ROLLED_BACK'
        if phase=='rollback_intent':
            self.target()
            self.adapter.quiesce(self.state['original_services'])
            self.record('rollback_quiesced')
            phase='rollback_quiesced'
        if phase=='rollback_quiesced':
            # A new verified backup and a fresh keyed maintenance epoch are
            # required; the already released installation window is never reused.
            self.adapter.prepare_rollback(self.manifest)
            self.record('rollback_window_ready')
            phase='rollback_window_ready'
        if phase in ('rollback_window_ready','rollback_replacing','rollback_files_complete',
                     'rollback_sql_complete','rollback_health_verified'):
            self.adapter.assert_rollback_window()
        if phase in ('rollback_window_ready','rollback_replacing'):
            self.restore_source_files();self.purge_caches()
            self.record('rollback_files_complete')
            phase='rollback_files_complete'
        if phase=='rollback_files_complete':
            self.adapter.restore_previous_guard()
            self.record('rollback_sql_complete')
            phase='rollback_sql_complete'
        if phase=='rollback_sql_complete':
            self.adapter.start_and_health(self.state['original_services'])
            self.record('rollback_health_verified')
            phase='rollback_health_verified'
        if phase=='rollback_health_verified':
            self.record('rollback_commit_intent')
            phase='rollback_commit_intent'
        if phase=='rollback_commit_intent':
            self.source();self.adapter.assert_previous_guard()
            self.adapter.release_rollback_window()
            self.record('rolled_back',files_may_have_changed=False)
            self.adapter.complete_services(self.state['original_services'])
            self.adapter.unregister_recovery()
            return 'ROLLED_BACK'
        raise BootstrapError('unknown_rollback_phase')

    def purge_caches(self):
        # Same-second/same-size source replacements must not reuse bytecode from
        # the opposite engine version. Remove only caches for owned paths.
        for row in self.rows:
            source=relative(self.app,row['path'])
            if source.suffix!='.py':continue
            cache=relative(self.app,(Path(row['path']).parent/'__pycache__').as_posix())
            if cache.exists():
                for file in cache.glob(source.stem+'.*.pyc'):
                    checked=relative(self.app,file.relative_to(self.app).as_posix())
                    checked.unlink()

    def apply(self):
        self.adapter.authorize(self.bundle,self.identity,recovery=False)
        with self.adapter.exclusive():
            if self.journal.exists():raise BootstrapError('existing_session_use_recover')
            self.source()
            self.adapter.preflight()
            self.work.mkdir(parents=True,exist_ok=False)
            self.adapter.protect(self.work)
            self.state=dict(protocol=1,manifest_sha256=self.identity,app=str(self.app),phase='created',
                            context_sha256=self.adapter.context_identity(),
                            original_services=self.adapter.service_inventory(),files_may_have_changed=False)
            self.record('created')
            try:
                # Task registration and the original service states are durable
                # before the first service is disabled.
                self.adapter.register_recovery()
                self.record('recovery_registered')
                self.adapter.quiesce(self.state['original_services'])
                self.record('quiesced')
                self.source();self.snapshot();self.record('snapshot_complete')
                # All database/media recovery proof is BEFORE SQL guard changes.
                self.adapter.backup_restore_and_guard(self.manifest)
                self.record('backup_guard_complete')
                self.record('applying',files_may_have_changed=True)
                self.install();self.target();self.purge_caches();self.record('files_complete')
                self.adapter.start_and_health(self.state['original_services'])
                self.record('health_verified')
                # Durable commit intent BEFORE opening writes. An uncertain
                # finish never triggers file or database rollback.
                self.record('commit_intent')
                self.adapter.release_window()
                self.record('complete')
                self.adapter.complete_services(self.state['original_services'])
                self.adapter.unregister_recovery()
                return 'COMPLETE'
            except Exception:
                # Crash/kill fault tests use BaseException and leave the journal
                # exactly as a power interruption would.
                if self.state['phase'] in ('commit_intent','complete'):
                    raise BootstrapError('commit_uncertain_use_recovery') from None
                self._recover()
                raise BootstrapError('bootstrap_failed_files_recovered') from None

    def recover(self):
        self.adapter.authorize(self.bundle,self.identity,recovery=True)
        with self.adapter.exclusive():
            self.state=json.loads(self.journal.read_text(encoding='utf-8'))
            self._validate_journal()
            self.adapter.validate_recovery_context()
            if self.state['phase'].startswith('rollback_') or self.state['phase']=='rolled_back':
                return self._finish_rollback()
            return self._recover()

    def _recover(self):
        phase=self.state['phase']
        if phase in ('recovery_commit_intent','recovered'):
            self.source()
            self.purge_caches()
            self.adapter.start_and_health(self.state['original_services'])
            self.adapter.release_window()
            self.record('recovered',files_may_have_changed=False)
            self.adapter.complete_services(self.state['original_services'])
            self.adapter.unregister_recovery()
            return 'RECOVERED'
        if phase in ('commit_intent','complete'):
            # Verify 1.1.4/1.1.9 still present before doing anything. If 1.1.5
            # was subsequently installed, stop and leave that newer code alone.
            self.target()
            self.purge_caches()
            self.adapter.start_and_health(self.state['original_services'])
            self.adapter.release_window()
            self.record('complete')
            self.adapter.complete_services(self.state['original_services'])
            self.adapter.unregister_recovery()
            return 'COMPLETE'
        self.adapter.quiesce(self.state['original_services'])
        self.validate_current()
        if self.state['files_may_have_changed']:
            self.adapter.assert_original_window()
            self.validate_snapshot()
            self.record('recovering_files')
            for row in self.rows:
                target=relative(self.app,row['path'])
                self.adapter.checkpoint('before_recover:'+row['path'])
                if row['source_114_sha256'] is None:
                    if target.exists():target.unlink()
                else:atomic(target,relative(self.work/'snapshot',row['path']).read_bytes())
            self.source()
        self.purge_caches()
        self.adapter.start_and_health(self.state['original_services'])
        # A second crash here must not reopen an old maintenance window.
        self.record('recovery_commit_intent')
        self.adapter.release_window()
        self.record('recovered',files_may_have_changed=False)
        self.adapter.complete_services(self.state['original_services'])
        self.adapter.unregister_recovery()
        return 'RECOVERED'
