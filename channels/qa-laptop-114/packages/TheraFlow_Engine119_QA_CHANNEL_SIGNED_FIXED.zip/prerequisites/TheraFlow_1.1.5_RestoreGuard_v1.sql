-- TheraFlow 1.1.5 REQUIRED restore-safety prerequisite, revision 1.
-- Apply only after verified backup/restore and explicit approval on the target.
-- Existing business tables/rows, function owner and grants are not changed.
-- Unknown or incomplete maintenance installations are refused atomically.
BEGIN;
SET LOCAL lock_timeout='15s';
SET LOCAL statement_timeout='60s';
DO $preflight$
DECLARE existing text;
BEGIN
 IF current_database() IN ('postgres','template0','template1') THEN
   RAISE EXCEPTION 'Select the explicitly approved application database.';
 END IF;
 IF to_regprocedure('tf_update_control.guard_ddl()') IS NULL
    OR to_regclass('tf_update_control.barrier') IS NULL THEN
   RAISE EXCEPTION 'Existing maintenance bootstrap is required; no changes applied.';
 END IF;
 IF (SELECT count(*) FROM pg_event_trigger WHERE evtname='tf_maintenance_ddl'
       AND evtenabled='O' AND evtfoid='tf_update_control.guard_ddl()'::regprocedure) <> 1
    OR (SELECT count(*) FROM pg_event_trigger WHERE evtname='tf_maintenance_new_tables'
       AND evtenabled='O' AND evtfoid='tf_update_control.guard_new_tables()'::regprocedure) <> 1 THEN
   RAISE EXCEPTION 'Expected enabled maintenance event triggers are required.';
 END IF;
 IF EXISTS (SELECT 1 FROM tf_update_control.barrier WHERE active) THEN
   RAISE EXCEPTION 'An update is already active; prerequisite installation refused.';
 END IF;
 IF NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_language l ON l.oid=p.prolang
     WHERE p.oid='tf_update_control.guard_ddl()'::regprocedure
       AND p.prosecdef AND p.prorettype='event_trigger'::regtype
       AND l.lanname='plpgsql' AND p.proconfig=ARRAY['search_path=pg_catalog']) THEN
   RAISE EXCEPTION 'Unexpected maintenance function security attributes; review required.';
 END IF;
 SELECT replace(prosrc,E'\r\n',E'\n') INTO existing FROM pg_proc
   WHERE oid='tf_update_control.guard_ddl()'::regprocedure;
 IF btrim(existing) NOT IN (btrim($old_body$
BEGIN
 IF EXISTS (SELECT 1 FROM tf_update_control.barrier WHERE active AND
    key_hash IS DISTINCT FROM md5(coalesce(current_setting('theraflow.update_key',true),''))) THEN
   RAISE EXCEPTION 'TheraFlow održavanje: DDL je dozvoljen samo updateru.' USING ERRCODE='55000';
 END IF;
END $old_body$),btrim($new_body$
BEGIN
 -- TheraFlow restore-window guard v1: protect already accepted business writes.
 IF current_setting('theraflow.restoring',true)='1' THEN
   -- Keep the active barrier locked until the entire restore transaction ends.
   -- A separate maintenance.finish cannot open business writes in this window.
   PERFORM 1 FROM tf_update_control.barrier
    WHERE singleton AND active AND key_hash =
      md5(coalesce(current_setting('theraflow.update_key',true),''))
    FOR SHARE;
   IF NOT FOUND THEN
     RAISE EXCEPTION 'TheraFlow restore refused: active keyed maintenance window required.'
       USING ERRCODE='55000';
   END IF;
 END IF;
 IF EXISTS (SELECT 1 FROM tf_update_control.barrier WHERE active AND
    key_hash IS DISTINCT FROM md5(coalesce(current_setting('theraflow.update_key',true),''))) THEN
   RAISE EXCEPTION 'TheraFlow održavanje: DDL je dozvoljen samo updateru.' USING ERRCODE='55000';
 END IF;
END
$new_body$)) THEN
   RAISE EXCEPTION 'Unknown maintenance guard definition; review required, no changes applied.';
 END IF;
END
$preflight$;
CREATE OR REPLACE FUNCTION tf_update_control.guard_ddl()
RETURNS event_trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $guard$
BEGIN
 -- TheraFlow restore-window guard v1: protect already accepted business writes.
 IF current_setting('theraflow.restoring',true)='1' THEN
   -- Keep the active barrier locked until the entire restore transaction ends.
   -- A separate maintenance.finish cannot open business writes in this window.
   PERFORM 1 FROM tf_update_control.barrier
    WHERE singleton AND active AND key_hash =
      md5(coalesce(current_setting('theraflow.update_key',true),''))
    FOR SHARE;
   IF NOT FOUND THEN
     RAISE EXCEPTION 'TheraFlow restore refused: active keyed maintenance window required.'
       USING ERRCODE='55000';
   END IF;
 END IF;
 IF EXISTS (SELECT 1 FROM tf_update_control.barrier WHERE active AND
    key_hash IS DISTINCT FROM md5(coalesce(current_setting('theraflow.update_key',true),''))) THEN
   RAISE EXCEPTION 'TheraFlow održavanje: DDL je dozvoljen samo updateru.' USING ERRCODE='55000';
 END IF;
END
$guard$;
COMMIT;
