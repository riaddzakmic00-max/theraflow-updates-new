-- Read-only verification. Select the approved TheraFlow database explicitly.
-- A PASS is only a metadata check; it does not replace backup/restore or QA.
BEGIN READ ONLY;
SET LOCAL statement_timeout='15s';
DO $verify$
BEGIN
 IF current_database() IN ('postgres','template0','template1') THEN
   RAISE EXCEPTION 'Select the approved application database.';
 END IF;
 IF to_regprocedure('tf_update_control.guard_ddl()') IS NULL
    OR to_regclass('tf_update_control.barrier') IS NULL THEN
   RAISE EXCEPTION 'Required maintenance bootstrap is missing.';
 END IF;
 IF (SELECT count(*) FROM pg_event_trigger WHERE evtname='tf_maintenance_ddl'
       AND evtenabled='O' AND evtfoid='tf_update_control.guard_ddl()'::regprocedure) <> 1
    OR (SELECT count(*) FROM pg_event_trigger WHERE evtname='tf_maintenance_new_tables'
       AND evtenabled='O' AND evtfoid='tf_update_control.guard_new_tables()'::regprocedure) <> 1 THEN
   RAISE EXCEPTION 'Required maintenance event triggers are missing or disabled.';
 END IF;
 IF EXISTS (SELECT 1 FROM tf_update_control.barrier WHERE active) THEN
   RAISE EXCEPTION 'Maintenance remains active; stop and investigate.';
 END IF;
 IF NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_language l ON l.oid=p.prolang
     WHERE p.oid='tf_update_control.guard_ddl()'::regprocedure
       AND p.prosecdef AND p.prorettype='event_trigger'::regtype
       AND l.lanname='plpgsql' AND p.proconfig=ARRAY['search_path=pg_catalog']
       AND btrim(replace(p.prosrc,E'\r\n',E'\n'))=btrim($expected$
BEGIN
 -- TheraFlow restore-window guard v1: protect already accepted business writes.
 IF current_setting('theraflow.restoring',true)='1' THEN
   -- Keep the active barrier locked until the entire restore transaction ends.
   -- A separate maintenance.finish cannot open business writes in this window.
   PERFORM 1 FROM tf_update_control.barrier
    WHERE singleton AND active AND key_hash =
      md5(coalesce(current_setting('theraflow.update_key',true),''))
    FOR SHARE;
   IF NOT FOUND THEN
     RAISE EXCEPTION 'TheraFlow restore refused: active keyed maintenance window required.'
       USING ERRCODE='55000';
   END IF;
 END IF;
 IF EXISTS (SELECT 1 FROM tf_update_control.barrier WHERE active AND
    key_hash IS DISTINCT FROM md5(coalesce(current_setting('theraflow.update_key',true),''))) THEN
   RAISE EXCEPTION 'TheraFlow održavanje: DDL je dozvoljen samo updateru.' USING ERRCODE='55000';
 END IF;
END
$expected$)) THEN
   RAISE EXCEPTION 'Restore guard v1 is absent or changed. Update is not approved.';
 END IF;
END
$verify$;
SELECT 'PASS_RESTORE_GUARD_V1_INACTIVE' AS result;
ROLLBACK;
