# Native adapter. Invoked only after the signed launcher and local policy gate.
[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateSet('Authorize','Inventory','Protect','Register','Unregister','Quiesce','Start','Complete','ActiveCheck')][string]$Action,
 [Parameter(Mandatory=$true)][string]$Profile,
 [Parameter(Mandatory=$true)][string]$Bundle,
 [Parameter(Mandatory=$true)][string]$Work
)
$ErrorActionPreference='Stop'
$p=Get-Content -LiteralPath $Profile -Raw | ConvertFrom-Json
$names=@('TheraFlow','TheraFlowBackupScheduler','TheraFlowUpdaterService')
function Assert-Admin {
 if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Administrator token required; no elevation attempted.' }
}
function Assert-Private([string]$Path) {
 $item=Get-Item -LiteralPath $Path
 $target=$true
 $allowed=@('S-1-5-18','S-1-5-32-544')
 $ancestorOwners=$allowed+@('S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')
 $targetMask=[int][Security.AccessControl.FileSystemRights]::Write -bor [int][Security.AccessControl.FileSystemRights]::Delete -bor [int][Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor [int][Security.AccessControl.FileSystemRights]::ChangePermissions -bor [int][Security.AccessControl.FileSystemRights]::TakeOwnership
 $ancestorMask=[int][Security.AccessControl.FileSystemRights]::Delete -bor [int][Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor [int][Security.AccessControl.FileSystemRights]::ChangePermissions -bor [int][Security.AccessControl.FileSystemRights]::TakeOwnership
 while ($null -ne $item) {
  if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse path refused.' }
  $acl=Get-Acl -LiteralPath $item.FullName
  $owner=if ([string]$acl.Owner -match '^S-1-') {[string]$acl.Owner} else {([Security.Principal.NTAccount]$acl.Owner).Translate([Security.Principal.SecurityIdentifier]).Value}
  if ($target -and $owner -notin $allowed) { throw 'Protected path owner is not SYSTEM/Administrators.' }
  if (-not $target -and $owner -notin $ancestorOwners) { throw 'Untrusted ancestor owner refused.' }
  $writeMask=if ($target) {$targetMask} else {$ancestorMask}
  $writers=if ($target) {$allowed} else {$ancestorOwners}
  foreach ($rule in $acl.Access) {
   if (($rule.PropagationFlags -band [Security.AccessControl.PropagationFlags]::InheritOnly) -ne 0) { continue }
   $sid=$rule.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
   if ($rule.AccessControlType -eq 'Allow' -and $sid -notin $writers -and ([int]$rule.FileSystemRights -band $writeMask)) { throw 'Untrusted writable or replaceable ACL refused.' }
  }
  $target=$false
  $item=if ($item -is [IO.FileInfo]) {$item.Directory} else {$item.Parent}
 }
}
function Invoke-SC([string[]]$Arguments) {
 & "$env:SystemRoot\System32\sc.exe" @Arguments | Out-Null
 if ($LASTEXITCODE -ne 0) { throw 'SCM operation failed; recovery journal retained.' }
}
function Read-Inventory {
 $services=@(Get-CimInstance Win32_Service | Where-Object { $_.Name -in ($names+@('TheraFlowPostgres')) })
 if ($services.Count -ne 4) { throw 'Expected exactly four TheraFlow services.' }
 $result=@()
 foreach ($s in $services) {
  $expected=$p.services.($s.Name)
  if ($null -eq $expected) { throw 'Service baseline missing.' }
  $bytes=[Text.Encoding]::UTF8.GetBytes([string]$s.PathName)
  $h=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace('-','').ToLowerInvariant()
  if ($h -ne $expected.path_sha256 -or $s.StartName -ne $expected.account) { throw 'Service command/account differs from locally approved baseline.' }
  # No executable arguments or secrets are included in output.
  $result+=@{name=$s.Name;state=$s.State;start_mode=$s.StartMode;command_sha256=$h}
 }
 return $result
}
Assert-Admin
$actualHost=[Environment]::MachineName
if ($actualHost -ne 'DESKTOP-OTO3E25' -or $p.host -ne 'DESKTOP-OTO3E25' -or $p.scope -ne 'ISOLATED_QA_ONLY') { throw 'This artifact is restricted to the approved DESKTOP-OTO3E25 host.' }
$taskName='TheraFlowBootstrap119-'+[string]$p.session_id
switch ($Action) {
 'Authorize' {
  $policyPath=Join-Path $env:ProgramData 'TheraFlow\config\bootstrap-policy.json'
  Assert-Private $policyPath
  Assert-Private $Profile
  Assert-Private $Bundle
  $policy=Get-Content -LiteralPath $policyPath -Raw | ConvertFrom-Json
  $signature=Get-AuthenticodeSignature -LiteralPath (Join-Path $Bundle 'Start-Bootstrap.ps1')
  if ($signature.Status -ne 'Valid' -or -not $policy.publisher_thumbprint -or $signature.SignerCertificate.Thumbprint -ne $policy.publisher_thumbprint) { throw 'Publisher signature/identity is not approved.' }
  $nativeSignature=Get-AuthenticodeSignature -LiteralPath $PSCommandPath
  if ($nativeSignature.Status -ne 'Valid' -or $nativeSignature.SignerCertificate.Thumbprint -ne $policy.publisher_thumbprint) { throw 'Native publisher signature is not approved.' }
  $releaseTrustPath=Join-Path $env:ProgramData 'TheraFlow\config\release-trust.json'
  Assert-Private $releaseTrustPath
  $releaseTrust=Get-Content -LiteralPath $releaseTrustPath -Raw | ConvertFrom-Json
  $sha=[Security.Cryptography.SHA256]::Create()
  try { $publisherSha=[BitConverter]::ToString($sha.ComputeHash($signature.SignerCertificate.RawData)).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose() }
  if ($releaseTrust.scope -ne 'qa' -or @($releaseTrust.allowed_hosts).Count -ne 1 -or $releaseTrust.allowed_hosts[0] -ne 'DESKTOP-OTO3E25' -or $releaseTrust.source_database -ne 'theraflow' -or @($releaseTrust.certificates | Where-Object { $_.scope -eq 'qa' -and $_.sha256 -eq $publisherSha }).Count -ne 1) { throw 'Release trust is not bound to this QA publisher and database.' }
  $manifestHash=(Get-FileHash -LiteralPath (Join-Path $Bundle 'bootstrap-manifest.json') -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($policy.manifest_sha256 -ne $manifestHash -or $p.manifest_sha256 -ne $manifestHash -or $policy.host -ne $actualHost) { throw 'Package/host authorization mismatch.' }
  if (-not $policy.qa_execution_approved -or $policy.production_execution_approved) { throw 'QA-only approval required; production activation is forbidden.' }
  $null=[Guid]::Parse([string]$p.session_id)
  if ([IO.Path]::GetFullPath($Work) -ne [IO.Path]::GetFullPath((Join-Path $env:ProgramData ('TheraFlow\bootstrap\'+$p.session_id)))) { throw 'Noncanonical recovery journal.' }
  # DESKTOP-OTO3E25 runs the approved isolated application from this fixed root.
  if ([IO.Path]::GetFullPath($p.application_root) -ne [IO.Path]::GetFullPath('C:\Program Files\TheraFlow\app')) { throw 'Unknown application layout.' }
  if ([IO.Path]::GetFullPath($p.canonical_env_path) -ne [IO.Path]::GetFullPath((Join-Path $env:ProgramData 'TheraFlow\config\.env'))) { throw 'Unknown configuration layout.' }
  $uninstall='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{A3D7F1F5-4E94-4E2E-BCC6-6F7A0E8B9A15}_is1'
  $installed=Get-ItemProperty -LiteralPath $uninstall
  if ($installed.DisplayVersion -ne '1.1.4' -or [IO.Path]::GetFullPath((Join-Path $installed.InstallLocation 'app')) -ne [IO.Path]::GetFullPath($p.application_root)) { throw 'Uninstall registry does not match approved 1.1.4 installation.' }
  foreach ($path in @($p.application_root,$p.python_executable,$p.canonical_env_path,(Split-Path -Parent $p.canonical_env_path),$p.media_root)) { Assert-Private $path }
  $manifest=Get-Content -LiteralPath (Join-Path $Bundle 'bootstrap-manifest.json') -Raw | ConvertFrom-Json

  $serviceRoot='C:\Program Files\TheraFlow\scripts\service'
  Assert-Private $serviceRoot
  foreach ($entry in $manifest.external_service_files.PSObject.Properties) {
   if ($entry.Name -notmatch '^[A-Za-z0-9_.-]+$') { throw 'Unsafe installed service file name.' }
   $path=Join-Path $serviceRoot $entry.Name
   Assert-Private $path
   if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine [string]$entry.Value) { throw 'Installed service script differs from signed source inventory.' }
  }

  foreach ($tool in @('pg_dump','pg_restore','psql')) {
   $path=$p.postgres_tools.$tool;Assert-Private $path
   if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $p.tool_hashes.$tool) { throw 'PostgreSQL tool identity mismatch.' }
  }
  if ((Get-FileHash -LiteralPath $p.python_executable -Algorithm SHA256).Hash.ToLowerInvariant() -ne $p.python_sha256) { throw 'Python runtime identity mismatch.' }
  @{status='AUTHORIZED_QA_ONLY'} | ConvertTo-Json -Compress
 }
 'Inventory' { @(Read-Inventory) | ConvertTo-Json -Depth 4 -Compress }
 'ActiveCheck' {
  $root=Split-Path -Parent $p.canonical_env_path
  $data=Split-Path -Parent $root
  foreach ($folder in @('updates\sessions','updates\service_requests')) {
   $path=Join-Path $data $folder
   if (Test-Path -LiteralPath $path) {
    foreach ($file in @(Get-ChildItem -LiteralPath $path -File -Recurse)) {
     if ($file.Extension -eq '.lock') { throw 'Existing updater lock; manual review required.' }
     if ($file.Extension -eq '.json') {
      $v=Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
      if ($v.is_active -or $v.status -in @('pending','running','install_starting','ready_to_install')) { throw 'Active updater session/request.' }
     }
    }
   }
  }
  foreach ($process in @(Get-CimInstance Win32_Process)) {
   if ($process.CommandLine -match 'updater\.runner|THERAFLOW_UPDATER_MODE|updates[\\/]sessions.+runtime') { throw 'Updater child process still exists; it will not be killed automatically.' }
  }
 }
 'Protect' {
  $acl=New-Object Security.AccessControl.DirectorySecurity
  $acl.SetAccessRuleProtection($true,$false)
  foreach ($sid in @('S-1-5-18','S-1-5-32-544')) {
   $identity=New-Object Security.Principal.SecurityIdentifier($sid)
   $rule=New-Object Security.AccessControl.FileSystemAccessRule($identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow')
   $acl.AddAccessRule($rule)
  }
  $acl.SetOwner((New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')))
  Set-Acl -LiteralPath $Work -AclObject $acl
  Assert-Private $Work
 }
 'Register' {
  if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) { throw 'Recovery task already exists.' }
  $launcher=Join-Path $Bundle 'Start-Bootstrap.ps1'
  foreach ($path in @($launcher,$Profile)) { if ($path.Contains('"') -or $path.Contains("`r") -or $path.Contains("`n")) { throw 'Unsafe task argument.' } }
  $arguments='-NoProfile -NonInteractive -File "'+$launcher+'" -Mode Recover -Profile "'+$Profile+'"'
  $action=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument $arguments
  $trigger=New-ScheduledTaskTrigger -AtStartup
  $principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 2)
  Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings | Out-Null
  $task=Get-ScheduledTask -TaskName $taskName
  if ($task.Principal.UserId -notin @('SYSTEM','S-1-5-18') -or $task.Actions.Arguments -ne $arguments) { throw 'Recovery task verification failed.' }
 }
 'Unregister' { if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false } }
 'Quiesce' {
  $null=Read-Inventory
  # Disable BEFORE stopping: a reboot cannot launch partially replaced code.
  foreach ($name in $names) { Invoke-SC @('config',$name,'start=','disabled') }
  foreach ($name in @('TheraFlowUpdaterService','TheraFlowBackupScheduler','TheraFlow')) {
   $service=Get-Service -Name $name
   if ($service.Status -ne 'Stopped') { Stop-Service -Name $name -ErrorAction Stop; $service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(60)) }
  }
 }
 'Start' {
  foreach ($name in @('TheraFlowBackupScheduler','TheraFlow','TheraFlowUpdaterService')) {
   Invoke-SC @('config',$name,'start=','demand')
   Start-Service -Name $name -ErrorAction Stop
   (Get-Service -Name $name).WaitForStatus('Running',[TimeSpan]::FromSeconds(60))
  }
 }
 'Complete' {
  $journal=Get-Content -LiteralPath (Join-Path $Work 'journal.json') -Raw | ConvertFrom-Json
  if ($journal.phase -notin @('complete','recovered','rolled_back')) { throw 'Unverified terminal state.' }
  foreach ($name in $names) {
   $original=@($journal.original_services | Where-Object name -eq $name)
   if ($original.Count -ne 1 -or $original[0].start_mode -ne 'Auto' -or $original[0].state -ne 'Running') { throw 'Unexpected original service state.' }
   Invoke-SC @('config',$name,'start=','auto')
  }
  foreach ($s in @(Read-Inventory)) { if ($s.state -ne 'Running' -or $s.start_mode -ne 'Auto') { throw 'Service restoration not verified.' } }
 }
}

# SIG # Begin signature block
# MIIHkAYJKoZIhvcNAQcCoIIHgTCCB30CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAprqOcMGpmXxYu
# qk7DkQRysxLAah+UZdDrll47wKjmpaCCBFwwggRYMIICwKADAgECAhBzMIILveQ7
# iERUyr3xCdgkMA0GCSqGSIb3DQEBCwUAMEQxFTATBgNVBAoMDFRoZXJhRmxvdyBR
# QTErMCkGA1UEAwwiVGhlcmFGbG93IElzb2xhdGVkIFFBIFNpZ25pbmcgMjAyNjAe
# Fw0yNjEwMTgxNTA0MzhaFw0yODEwMTgxNTE0MzdaMEQxFTATBgNVBAoMDFRoZXJh
# RmxvdyBRQTErMCkGA1UEAwwiVGhlcmFGbG93IElzb2xhdGVkIFFBIFNpZ25pbmcg
# MjAyNjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBAKgKtDaRNSZYwpHb
# FbacHFgABXiLqpNg+4Ba3xfsan7fsgJsKVG0tj2amE6jDIzgCnQt8bMG4Dkx6tOe
# w74UbgjKHM9I2Jd6aqRvqP44o1b4pq7WjqyZFCzy56TKSatAlgYqQgGex5jfwUZU
# I396XSM/C0ABHD+r4Rex7cluvddzFsGI3Q2FIHKUrjGHuYVSd1uqf71wDRFQzD0O
# F/o/MMBH/kF/uCkm7Se38inzj/RxWVcFdO+sAmopJjH8H3Q0U8LDBUyDdJMgQKRu
# ZV3zcxVJxna49MLfXP6dKBdds3lGpxR0L7cKUPXp5CJuWLpsYph9UB3LyMPgM0zj
# 58dSN5ccXIJEIGsKDb+gRe94Uo0jFR6gaiY7V7MEhySkRaWG1YlZ4YfAsHCxPysU
# y1xB2c8U176QEiLkqXG0wePhvBWOW75o1HT7B5FthecHXJfxOljKaFtLitr7Xtpb
# QC2stSeLIFBejKK4G6kuYUE83ZoRYq30xTlecW11EdlQWZI7AQIDAQABo0YwRDAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFPZO
# JufXPRpeNx7TiAkHLyTFoV77MA0GCSqGSIb3DQEBCwUAA4IBgQCnCFvNW/FOy+Db
# /BzL11lmv6f4xRd7+1UO/tSchnDbDCh4g9pcl0RI3OxUCdeeLZV8mqFI6U2m3CIV
# USTpShYtbF8d1+jtQ8CEZO4IDt7/ygh35nuE6p5ajHCB45re7tmQKjin+nQY/Ctp
# jqqoPnTu94vKCGlMByygn3ts/v71/41/MS6+RbKE+CARhl89mGmjoYyiP1U2o0cz
# Sy4beIizvfDcKVaD8WCkLQksp69DK2S6vAb4cN9B/7OO+dZOgZ/xnXSTrQqO6f4H
# PyFTcWOlso1+4+578QurGQyg/3pGDeqLNcvFMlKWaMkTLOiXMNbhPbkDspxacNGD
# 0WIUXwTTQdZkQ7Xji7E0lesaYL1cqNl4dic8uYSKbt776fWZyQL6fe3eLxNwXbFa
# f4Han6GKVslHRsBd9YVxwv7yAza0EQXEkEHhQPeQg1vzmjfgBRKqkMvfr/6EbJMG
# Q5kLpAl45kQllcQ5nMzAecoNrdhCM/KVaO/YQDPCqnxGoY818H4xggKKMIIChgIB
# ATBYMEQxFTATBgNVBAoMDFRoZXJhRmxvdyBRQTErMCkGA1UEAwwiVGhlcmFGbG93
# IElzb2xhdGVkIFFBIFNpZ25pbmcgMjAyNgIQczCCC73kO4hEVMq98QnYJDANBglg
# hkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCCN+wg1Y7Axrn9PgjgcHEQno9Gvj1ggaLfE4qi6dATh
# QTANBgkqhkiG9w0BAQEFAASCAYBXVLdvumqbE+txUrekPFNvfoPf2OsCqAQYBnES
# SPneiACcM7rSFhF9GjccrUN1tiSbdMqIuetGIPfrZatni9xTtnTOya+22n7DpJWq
# hjI6skdbwFgCQZVmEDffkI1ODFQI6Cagf380uRRCK6mwkqgUDNpU0Dl0w1E2vH6Q
# sL8Hk27WeWDaPUVevSPkUgkIRPTc3mgTdMrDe+EuiZCeMWcIi6cndPg6jjaB9i+g
# G3tEjlxw4VwMeeg76fMVxIZ45URzsKyE+eVQA7lGT+oJvIoo119yL2BtACSaqbNX
# +IYHkt7oxhQcBFFMfY2z0jVVgKhJMnYYCgsmdjADVTZWQV8ApTIV8Sz90DiU4lVs
# 9QsIa6xtAMTmJVfMn3NZXP4IFfRRwSxII9diWQpvNFID8s9RA2/M9fdjG/v5l5XN
# c4gZPZI1qjEPQmLCiNJN0rTbSPoP59N+QRC9Sjx9ftyNa4z7F2H2oPzL9qZdsZfr
# tnbg1ZqHPkmR8ohPtpU+Ca7Y85s=
# SIG # End signature block
