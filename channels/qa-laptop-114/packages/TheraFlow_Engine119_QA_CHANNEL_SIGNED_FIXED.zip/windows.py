"""Native adapter, restricted to DESKTOP-OTO3E25 and an authenticated local approval.
Never auto-elevates. PostgreSQL service is never stopped/reconfigured.
"""
from contextlib import contextmanager
import ctypes
import json
import os
from pathlib import Path
import subprocess
import shutil
import time
from urllib.request import urlopen

from core import BootstrapError, sha
from database import Database


class Windows:
    def __init__(self,bundle,profile,work):
        self.bundle=Path(bundle);self.profile_path=Path(profile);self.work=Path(work)
        self.profile=json.loads(self.profile_path.read_text(encoding='utf-8'))
        self.db=None
        self.rollback_db=None

    def native(self,action):
        shell=Path(os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
        result=subprocess.run([str(shell),'-NoProfile','-NonInteractive','-File',str(self.bundle/'Native.ps1'),
            '-Action',action,'-Profile',str(self.profile_path),'-Bundle',str(self.bundle),'-Work',str(self.work)],
            capture_output=True,timeout=300,creationflags=subprocess.CREATE_NO_WINDOW)
        if result.returncode:raise BootstrapError('native_'+action.lower()+'_failed')
        if result.stdout.strip():return json.loads(result.stdout.decode('utf-8-sig'))

    def authorize(self,bundle,identity,recovery=False):
        if os.name!='nt' or not ctypes.windll.shell32.IsUserAnAdmin():raise BootstrapError('administrator_required')
        self.native('Authorize')
        index=json.loads((bundle/'bootstrap-manifest.json').read_text(encoding='utf-8'))['bundle_files']
        from core import relative
        for name,digest in index.items():
            if sha(relative(bundle,name))!=digest:raise BootstrapError('bundle_file_integrity')
        self.db=Database(self.bundle,self.work,self.profile)

    @contextmanager
    def exclusive(self):
        # Kernel mutex is automatically released after process death. Never delete
        # a PID-file lock and guess another process is dead.
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.CreateMutexW.argtypes=[ctypes.c_void_p,ctypes.c_bool,ctypes.c_wchar_p]
        kernel.CreateMutexW.restype=ctypes.c_void_p
        kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
        kernel.ReleaseMutex.argtypes=[ctypes.c_void_p]
        kernel.CloseHandle.argtypes=[ctypes.c_void_p]
        handle=kernel.CreateMutexW(None,False,'Global\\TheraFlowBootstrap119')
        if not handle:raise BootstrapError('bootstrap_mutex_unavailable')
        acquired=False
        try:
            result=kernel.WaitForSingleObject(handle,0)
            if result not in (0,0x80):raise BootstrapError('bootstrap_already_running')
            acquired=True
            yield
        finally:
            if acquired:kernel.ReleaseMutex(handle)
            kernel.CloseHandle(handle)

    def checkpoint(self,phase):pass
    def context_identity(self):return sha(self.profile_path)
    def protect(self,path):self.native('Protect')
    def service_inventory(self):return self.native('Inventory')
    def register_recovery(self):self.native('Register')
    def unregister_recovery(self):self.native('Unregister')
    def quiesce(self,original):self.native('Quiesce')
    def complete_services(self,original):self.native('Complete')

    def preflight(self):
        inventory=self.service_inventory()
        if len(inventory)!=4 or any(s['state']!='Running' or s['start_mode']!='Auto' for s in inventory):
            raise BootstrapError('initial_services_not_ready')
        if self.work.exists():raise BootstrapError('session_already_exists')
        data=Path(self.profile['canonical_env_path']).parent.parent
        # Refuse existing install/update or rollback locks, running updater child
        # sessions and queued service requests, including a currently idle host.
        for folder in ('updates/sessions','updates/service_requests'):
            directory=data/folder
            if directory.exists():
                for file in directory.rglob('*'):
                    if file.is_file() and file.suffix=='.lock':raise BootstrapError('existing_update_lock')
                    if file.is_file() and file.suffix=='.json':
                        value=json.loads(file.read_text(encoding='utf-8'))
                        if value.get('is_active') or value.get('status') in ('pending','running','install_starting','ready_to_install'):
                            raise BootstrapError('existing_active_update')
        self.native('ActiveCheck')
        self.db.preflight()
        with self.db.connect() as connection,connection.cursor() as cursor:
            cursor.execute('SELECT pg_database_size(current_database())');database_bytes=cursor.fetchone()[0]
        media=Path(self.profile['media_root'])
        media_bytes=sum(p.stat().st_size for p in media.rglob('*') if p.is_file())
        # Conservative estimate; native QA must also measure actual expansion.
        required=6*database_bytes+3*media_bytes+1024**3
        for path in (Path(self.profile['application_root']),self.work.parent):
            while not path.exists():path=path.parent
            if shutil.disk_usage(path).free<required:raise BootstrapError('insufficient_free_space')

    def validate_recovery_context(self):
        self.native('Inventory')
        self.db.identities()

    def preflight_rollback(self):
        inventory=self.service_inventory()
        if len(inventory)!=4 or any(s['state']!='Running' or s['start_mode']!='Auto' for s in inventory):
            raise BootstrapError('rollback_services_not_ready')
        self.native('ActiveCheck')
        self.db.preflight()
        if (self.work/'rollback').exists():raise BootstrapError('rollback_backup_already_exists')
        # The same conservative reserve used for Apply also covers the new
        # database/media/configuration backup made before rollback.
        with self.db.connect() as connection,connection.cursor() as cursor:
            cursor.execute('SELECT pg_database_size(current_database())');database_bytes=cursor.fetchone()[0]
        media=Path(self.profile['media_root'])
        media_bytes=sum(p.stat().st_size for p in media.rglob('*') if p.is_file())
        if shutil.disk_usage(self.work).free < 6*database_bytes+3*media_bytes+1024**3:
            raise BootstrapError('rollback_insufficient_free_space')

    def rollback_database(self):
        if self.rollback_db is None:
            self.rollback_db=Database(self.bundle,self.work/'rollback',self.profile)
        return self.rollback_db

    def prepare_rollback(self,manifest):
        self.native('ActiveCheck')
        directory=self.work/'rollback'
        if directory.exists():
            # Power loss after the SQL transaction committed but before the
            # bootstrap journal advanced. Only the exact owned epoch resumes.
            if (directory/'window.json').is_file():
                self.rollback_database().assert_window()
                return
            raise BootstrapError('rollback_backup_incomplete_manual_review')
        directory.mkdir(exist_ok=False)
        # Parent has the pinned SYSTEM/Administrators ACL; explicitly reapply it.
        self.rollback_database().prepare(manifest)

    def assert_rollback_window(self):self.rollback_database().assert_window()
    def restore_previous_guard(self):self.rollback_database().restore_previous_guard()
    def assert_previous_guard(self):self.rollback_database().assert_previous_guard()
    def assert_rollback_complete(self):self.rollback_database().assert_rollback_complete()
    def release_rollback_window(self):self.rollback_database().release('verified_engine118_rollback')

    def backup_restore_and_guard(self,manifest):
        # Services have now stopped: reject a race with a request submitted after
        # the original read-only preflight. There must be no live helper process.
        self.native('ActiveCheck')
        self.db.prepare(manifest)

    def assert_original_window(self):self.db.assert_window()
    def release_window(self):self.db.release()

    def start_and_health(self,original):
        self.native('Start')
        url=self.profile['health_url']
        if not url.startswith('http://127.0.0.1:') or not url.endswith('/health/update/'):
            raise BootstrapError('health_url_not_loopback')
        for _ in range(30):
            try:
                with urlopen(url,timeout=3) as response:value=json.loads(response.read())
                if (value.get('version')=='1.1.4' and value.get('status')=='ok' and
                    value.get('database')=='ok' and value.get('backup_scheduler')=='ok'):
                    return
            except Exception:pass
            time.sleep(2)
        raise BootstrapError('bootstrap_health_failed')
