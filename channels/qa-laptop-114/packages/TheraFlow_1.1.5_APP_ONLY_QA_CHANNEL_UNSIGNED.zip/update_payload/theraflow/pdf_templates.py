"""Application-owned PDF forms; never resolved from mutable patient media."""
from functools import wraps
from io import BytesIO
import logging
from pathlib import Path

PDF_TEMPLATE_MAP = {
    "zahtjev_zavod": "za_zavod.pdf",
    "razduzenje_zavod": "razduzivanje_sablon.pdf",
    "lista_terapije": "lista_terapije.pdf",
}
REQUIRED_PDF_TEMPLATES = tuple(PDF_TEMPLATE_MAP.values())
PDF_RESOURCE_DIRECTORY = Path("resources") / "pdf_templates"
logger = logging.getLogger(__name__)


class PDFTemplateError(RuntimeError):
    def __init__(self, name, detail="nedostaje ili nije ispravan"):
        self.template_name = name if name in REQUIRED_PDF_TEMPLATES else "nepoznati obrazac"
        self.user_message = (
            f"Štampa nije dostupna: PDF obrazac „{self.template_name}“ {detail}. "
            "Predlošci se isporučuju uz TheraFlow ažuriranje. Obratite se održavanju "
            "radi provjere ili popravke aplikacijskih datoteka, pa ponovite štampu."
        )
        super().__init__(self.user_message)


def _template_path(name, app_root=None):
    if name not in REQUIRED_PDF_TEMPLATES:
        raise PDFTemplateError(name, "nije konfigurisan za ovaj postupak")
    if app_root is None:
        from django.conf import settings
        app_root = settings.BASE_DIR
    return Path(app_root) / PDF_RESOURCE_DIRECTORY / name


def load_pdf_template(name, *, app_root=None):
    """Read and validate into memory before a print makes any output or updates."""
    from PyPDF2 import PdfReader
    path = _template_path(name, app_root)
    try:
        data = path.read_bytes()
        if not data.startswith(b"%PDF-"):
            raise ValueError("Missing PDF header")
        reader = PdfReader(BytesIO(data))
        if reader.is_encrypted or not reader.pages:
            raise ValueError("Encrypted or empty PDF")
        for page in reader.pages:
            if float(page.mediabox.width) <= 0 or float(page.mediabox.height) <= 0:
                raise ValueError("Invalid page size")
        return reader
    except Exception as exc:
        # Parser failures and filesystem failures have the same controlled UI;
        # paths and technical detail are confined to the local application log.
        logger.warning("PDF template unavailable: %s (%s)", path, type(exc).__name__)
        raise PDFTemplateError(name) from exc


def get_pdf_template_path(name, *, app_root=None):
    load_pdf_template(name, app_root=app_root)
    return _template_path(name, app_root)


def validate_pdf_templates(*, app_root=None):
    errors = []
    for name in REQUIRED_PDF_TEMPLATES:
        try:
            load_pdf_template(name, app_root=app_root)
        except PDFTemplateError as exc:
            errors.append(exc)
    return errors


def pdf_template_errors(view):
    """Use outside atomic decorators so failures still roll back the operation."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        from django.http import HttpResponse
        try:
            return view(*args, **kwargs)
        except PDFTemplateError as exc:
            response = HttpResponse(exc.user_message, status=503, content_type="text/plain; charset=utf-8")
            response["Cache-Control"] = "no-store"
            return response
    return wrapped


def main():
    """Read-only build preflight, including a staged app root; no Django/DB boot."""
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-root", type=Path)
    parser.add_argument("--list-paths", action="store_true")
    args = parser.parse_args()
    if args.list_paths:
        for name in REQUIRED_PDF_TEMPLATES:
            print((PDF_RESOURCE_DIRECTORY / name).as_posix())
        return 0
    if args.check_root is None:
        parser.error("--check-root or --list-paths is required")
    errors = validate_pdf_templates(app_root=args.check_root)
    for error in errors:
        print(f"PDF_TEMPLATE_INVALID: {error.template_name}")
    if not errors:
        print(f"PDF_TEMPLATES_OK: {len(REQUIRED_PDF_TEMPLATES)}")
    return int(bool(errors))


if __name__ == "__main__":
    raise SystemExit(main())
