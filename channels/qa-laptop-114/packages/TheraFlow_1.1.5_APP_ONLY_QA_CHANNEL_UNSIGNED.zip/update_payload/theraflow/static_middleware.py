"""Serve the static tree maintained transactionally by installed engine 1.1.8."""
from pathlib import Path

from django.conf import settings
from whitenoise.middleware import WhiteNoiseMiddleware


class UpdaterStaticMiddleware(WhiteNoiseMiddleware):
    def __init__(self, get_response=None):
        super().__init__(get_response)
        if settings.PRODUCTION_MODE:
            updater_root = Path(settings.BASE_DIR) / "staticfiles"
            configured_root = Path(settings.STATIC_ROOT).resolve() if settings.STATIC_ROOT else None
            if updater_root.is_dir() and updater_root.resolve() != configured_root:
                # WhiteNoise gives later roots precedence for matching URLs.
                # Keep configured assets as fallback, including user-owned files.
                # This performs no writes and stays behind the existing security
                # and maintenance middleware. Rollback restores the old middleware.
                self.add_files(updater_root, prefix=self.static_prefix)
