from django import forms
from patients import models as m
from patients.retrospective_history import patient_at
from patients.retrospective_events import day
from .retrospective_forms import EventForm, NamedChoice


class BatchRowForm(EventForm):
    count_reservation_id = NamedChoice(label='Preostala bočica je već rezervisana 30.09. — poveži taj zapis',
        required=False, queryset=m.PacijentRezervacija.objects.none(),
        empty_label='Nema već evidentirane rezervacije iste preostale količine')
    receipt_mode = forms.ChoiceField(label='Je li ova isporuka već evidentirana?',required=False,
        choices=[('NEW','Nije — evidentiraj samo ovu raspodjelu'),('EXISTING','Jeste — poveži postojeći prijem bez novog knjiženja')])
    existing_receipt_id = NamedChoice(label='Već evidentirana raspodjela',required=False,
        queryset=m.EvidencijaSaglasnostiZaprimanja.objects.none())
    stock_correction_id = NamedChoice(label='Ranije brojanje koje već uključuje ovaj manjak',required=False,
        queryset=m.PhysicalStockCorrection.objects.none(),empty_label='Nije povezano s ranijim brojanjem')
    count_link_confirmed = forms.BooleanField(required=False,
        label='Provjerio/la sam da ovaj događaj objašnjava označeni raniji manjak')
    count_link_reason = forms.CharField(required=False,max_length=500,
        label='Dokaz veze s brojanjem (dokument ili izvršena provjera)')

    def __init__(self,*args,kind,patient,reconstruction=False,**kwargs):
        super().__init__(*args,kind=kind,patient_context=None if kind=='receipt' or reconstruction else patient,**kwargs)
        self.proposal='';self.proposal_error=''
        selected={key:self.data.get(self.add_prefix(key)) for key in self.fields} if self.is_bound else self.initial
        medicine=m.Lijek.objects.filter(pk=selected.get('medicine_id')).first() if str(selected.get('medicine_id','')).isdigit() else None
        if medicine:
            self.fields['quantity'].label=f'Količina — jedinica: {medicine.jedinice_zalihe[0]}'
        if reconstruction and kind=='receipt':
            request=m.Trebovanje.objects.filter(pk=selected.get('request_id')).first() if str(selected.get('request_id','')).isdigit() else None
            if request:
                self.fields['count_reservation_id'].queryset=m.PacijentRezervacija.objects.filter(
                    pacijent=request.pacijent,lijek=request.lijek,komisija=request.komisija,
                    aktivno=True,datum_rezervacije='2026-09-30')
            self.fields['count_reservation_id'].help_text='Samo preostala raspodjela iste količine, pacijenta i odobrenja. Postojeća rezervacija se ne povećava i ne troši za raniju primjenu.'
        else:self.fields.pop('count_reservation_id')
        if reconstruction and kind!='receipt':
            selected_patient=m.Pacijent.objects.filter(pk=selected.get('patient_id')).first() if str(selected.get('patient_id','')).isdigit() else None
            patient=selected_patient or patient
        if kind=='receipt':
            self.fields['batch']=forms.CharField(label='Serija (prazno ako nije dokumentovana)',required=False,max_length=100)
            self.fields['expires']=forms.DateField(label='Rok trajanja (ako je poznat)',required=False,
                widget=forms.DateInput(attrs={'type':'date'},format='%Y-%m-%d'))
            self.fields['separate_event']=forms.BooleanField(required=False,label='Provjereno je da ovo nije duplikat nego druga stvarna isporuka')
            self.fields['request_id'].help_text='Za zajedničku isporuku dodajte red za svaku odobrenu stavku; datum, otpremnica, lijek i serija moraju se podudarati. Zbir se knjiži jednom.'
            self.fields['request_id'].queryset=m.Trebovanje.objects.filter(komisijski_ciklus__isnull=False,
                komisija__isnull=False).select_related('pacijent','lijek','komisijski_ciklus')
            self.fields['cycle_id'].required=False
            self.fields['cycle_id'].queryset=m.KomisijskiCiklus.objects.all()
            claims=m.EvidencijaSaglasnostiZaprimanja.objects.filter(fizicka_transakcija__isnull=False).select_related('pacijent','trebovanje__lijek')
            if medicine:claims=claims.filter(trebovanje__lijek=medicine)
            self.fields['existing_receipt_id'].queryset=claims
            for key in ('stock_correction_id','count_link_confirmed','count_link_reason','history_confirmed'):self.fields.pop(key,None)
        else:
            for key in ('receipt_mode','existing_receipt_id'):self.fields.pop(key)
            counts=m.PhysicalStockCorrection.objects.filter(razlika__lt=0,pregled__cause='COUNT_UNKNOWN')
            self.fields['stock_correction_id'].queryset=counts.filter(lijek=medicine) if medicine else counts.none()
            if not self.fields['stock_correction_id'].queryset.exists():
                for key in ('stock_correction_id','count_link_confirmed','count_link_reason'):self.fields.pop(key)
            if reconstruction:
                for key in ('stock_correction_id','count_link_confirmed','count_link_reason'):self.fields.pop(key,None)
            try:
                historical=patient_at(patient,day(selected.get('event_date')))
                from patients.individual_protocols import get_current_step
                step=get_current_step(historical)
                self.proposal=f'Prijedlog za provjeru na odabrani datum: {historical.lijek}.'
                if step:self.proposal+=f' Doza {step.doza_mg} mg; {step.broj_jedinica} jedinica; interval {step.interval_sedmica} sedmica.'
                if historical._retrospective_changes:
                    self.proposal+=' Iz sačuvane promjene terapije; potvrdite izvorni nalog i fazu u napomeni.'
                else:self.fields.pop('history_confirmed',None)
            except ValueError as exc:
                if selected.get('event_date'):self.proposal_error=str(exc)


class CheckpointForm(forms.Form):
    count_id=NamedChoice(label='Kontrolni popis zajedničke zalihe od 30.09.2026.',
        queryset=m.PhysicalStockCorrection.objects.none())
    evidence=forms.CharField(label='Izvor provjere popisa, stvarnih prijema i primjena',max_length=500,
        widget=forms.Textarea(attrs={'rows':2}))
    verified=forms.BooleanField(label='Provjerio/la sam da ovaj popis predstavlja fizički prebrojanu količinu na 30.09.')

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['count_id'].queryset=m.PhysicalStockCorrection.objects.filter(
            pregled__event_date='2026-09-30',pregled__cause='COUNT_UNKNOWN').select_related('lijek')


def posted_rows(data):
    from patients.data_corrections import require
    try:count=int(data.get('row_count',0))
    except (ValueError,TypeError):count=-1
    require(0<=count<=20,'Jedan unos može imati do 20 događaja.')
    bools={'history_confirmed','separate_event','count_link_confirmed'}
    allowed=set(EventForm.base_fields)|set(BatchRowForm.base_fields)
    return [{key:(data.get(f'row-{index}-{key}') in ('on','true','True','1') if key in bools
                  else data.get(f'row-{index}-{key}','')) for key in allowed} for index in range(count)]
