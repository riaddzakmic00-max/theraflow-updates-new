"""Print the same documented facts as the nurse list, without inferring dates."""
from io import BytesIO
from xml.sax.saxutils import escape

from django.utils import timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import LongTable, Paragraph, SimpleDocTemplate, Spacer, TableStyle

from .monthly_consumption_views import quantity_text
from .pdf_overlay import PDF_FONT_BOLD, PDF_FONT_FALLBACK, register_pdf_fonts


def render_hyrimoz_pdf(report):
    register_pdf_fonts()
    output = BytesIO()
    document = SimpleDocTemplate(output, pagesize=landscape(A4), leftMargin=32,
        rightMargin=32, topMargin=32, bottomMargin=36, title="Hyrimoz - lista za sestru",
        author="TheraFlow")
    normal = ParagraphStyle("Hyrimoz", fontName=PDF_FONT_FALLBACK, fontSize=9, leading=13)
    heading = ParagraphStyle("HyrimozHeading", parent=normal, fontName=PDF_FONT_BOLD,
        fontSize=17, leading=22, spaceAfter=8)
    bold = ParagraphStyle("HyrimozBold", parent=normal, fontName=PDF_FONT_BOLD)
    def paragraph(lines, style=normal):
        return Paragraph("<br/>".join(escape(str(line)) for line in lines), style)
    def day(value):
        return value.strftime("%d/%m/%Y")
    story = [paragraph(["Hyrimoz - lista za sestru"], heading),
        paragraph([f"Stanje evidencije do {day(report['today'])}. Broj stavki: {len(report['rows'])}."]),
        Spacer(1, 7), paragraph(["Izdavanje lijeka nije dokaz primjene. Izjava pacijenta prikazana je odvojeno od potvrđene primjene.",
            "Poništeni i budući zapisi nisu uključeni. Uključeni su pacijenti na Hyrimozu i pacijenti s njegovom evidencijom."]), Spacer(1, 12)]
    headers = ["Pacijent", "Prezentacija", "Posljednje kućno izdavanje", "Dokumentovana primjena", "Prema izjavi pacijenta"]
    data = [[paragraph([text], bold) for text in headers]]
    for row in report["rows"]:
        patient, drug = row["patient"], row["drug"]
        identity = [f"{patient.ime} {patient.prezime}", f"Karton {patient.broj_kartona or '—'}"]
        if not patient.aktivan:
            identity.append("Neaktivan")
        elif patient.lijek_id != drug.pk:
            identity.append("Sada druga prezentacija/terapija")
        issue, application, statement = row["issue"], row["application"], row["statement"]
        issue_lines = ["Nema dokumentovanog izdavanja"]
        if issue:
            quantity = "Količina nepoznata" if issue["quantity"] is None else f"{quantity_text(issue['quantity'])} {issue['unit']}"
            issue_lines = [day(issue["date"]), quantity, issue["source"]]
        application_lines = [day(application["date"]), application["source"]] if application else ["Nije evidentirana"]
        statement_lines = ["Nema izjave"]
        if statement:
            remaining = "nepoznato" if statement["remaining"] is None else f"{quantity_text(statement['remaining'])} {statement['unit']}"
            statement_lines = [f"Provjera {day(statement['date'])}",
                "Naveden datum primjene: " + (day(statement["application_date"]) if statement["application_date"] else "nije naveden"),
                "Preostalo: " + remaining, statement["source"]]
        data.append([paragraph(identity), paragraph([drug.prikaz_naziv, drug.jedinice_zalihe[1]]),
            paragraph(issue_lines), paragraph(application_lines), paragraph(statement_lines)])
    if report["rows"]:
        table = LongTable(data, colWidths=[143, 151, 161, 153, document.width - 608], repeatRows=1, hAlign="LEFT")
        table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#edf4f7")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LINEBELOW", (0, 0), (-1, -1), .4, colors.HexColor("#ccdce5")),
            ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
            ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
        story.append(table)
    else:
        story.append(paragraph(["Nema pacijenata ni evidentiranih događaja za Hyrimoz."]))
    generated = timezone.localtime(report["generated_at"]).strftime("%d/%m/%Y %H:%M")
    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont(PDF_FONT_FALLBACK, 8)
        canvas.drawString(32, 20, f"TheraFlow · Generisano {generated}")
        canvas.drawRightString(landscape(A4)[0] - 32, 20, f"Stranica {doc.page}")
        canvas.restoreState()
    document.build(story, onFirstPage=footer, onLaterPages=footer)
    return output.getvalue()
