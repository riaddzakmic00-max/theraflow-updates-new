"""Small, progressive forms for the correction center."""
import json
import logging
from datetime import date
from decimal import Decimal

from django import forms
from django.contrib.auth.decorators import login_required
from django.core import signing
from django.core.exceptions import ValidationError
from django.db import DatabaseError
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods

from patients import models as m, nurse_corrections as service
from patients.correction_protocol import contention_message
from .correction_center_views import render_in_center

logger = logging.getLogger(__name__)
CORRECTIONS = [
    ('dose', 'Doza i terapija', 'capsule', 'Ispravite propisanu dozu.'),
    ('reservation', 'Zaduženje pacijenta', 'person-check', 'Unesite tačnu količinu za pacijenta.'),
    ('physical', 'Fizičko stanje lijeka', 'box-seam', 'Unesite prebrojanu količinu u ambulanti.'),
    ('route', 'Put primjene IV / SC', 'arrow-left-right', 'Pregledajte promjenu oblika lijeka.'),
    ('interval', 'Interval terapije', 'calendar-week', 'Ispravite razmak između terapija.'),
    ('appointment', 'Zakazani termin', 'calendar-event', 'Promijenite datum ili vrijeme naredne zakazane terapije.'),
    ('last_date', 'Datum posljednje terapije', 'calendar-check', 'Ispravite datum iz ranije dokumentacije.'),
    ('plan', 'Terapijski plan', 'clipboard2-pulse', 'Promijenite lijek ili terapijski protokol.'),
]
EVENTS = [
    ('therapy', 'Terapija je primijenjena', 'clipboard2-check', 'Unesite stvarni datum i primijenjenu dozu.'),
    ('receipt', 'Lijek je zaprimljen', 'box-arrow-in-down', 'Dodajte ranije zaprimljenu količinu.'),
    ('home', 'Kućna terapija je izdata', 'house', 'Evidentirajte stvarno izdavanje pacijentu.'),
    ('deferred', 'Terapija nije primijenjena / odgođena', 'calendar-x', 'Evidentirajte ishod ranijeg termina.'),
    ('change', 'Promjena terapije ili puta primjene', 'arrow-left-right', 'Unesite promjenu prema odluci ljekara.'),
    ('other', 'Drugi događaj', 'journal-text', 'Dodajte opis događaja u historiju.'),
]
LABELS = {key: title for key, title, _, _ in CORRECTIONS+EVENTS}
LABELS['appointment'] = 'Promijeni zakazani termin'


def date_field(label, **kwargs):
    return forms.DateField(label=label, widget=forms.DateInput(attrs={'type':'date'}, format='%Y-%m-%d'), **kwargs)


class BalanceForm(forms.Form):
    change_patient = forms.BooleanField(label='Promijeni zaduženje pacijenta', required=False)
    patient_quantity = forms.DecimalField(label='Novo zaduženje pacijenta', min_value=0, max_digits=8, decimal_places=0, required=False)
    change_physical = forms.BooleanField(label='Promijeni fizičku zalihu', required=False)
    physical_quantity = forms.DecimalField(label='Nova fizička zaliha', min_value=0, max_digits=8, decimal_places=0, required=False)
    lot = forms.ChoiceField(label='Serija kojoj pripada razlika', required=False)
    reason_code = forms.ChoiceField(label='Razlog ispravke', choices=[('', 'Odaberite razlog')]+service.REASONS)
    reason = forms.CharField(label='Kratko objašnjenje', required=False, max_length=400, widget=forms.Textarea(attrs={'rows':2}))

    def __init__(self, *args, patient, medicine, category, **kwargs):
        super().__init__(*args, **kwargs)
        self.current = service.amounts(patient, medicine)
        self.initial.update(change_patient=category=='reservation', change_physical=category=='physical',
            patient_quantity=self.current['patient'], physical_quantity=self.current['physical'])
        self.patient = patient
        if not patient:
            self.fields.pop('change_patient'); self.fields.pop('patient_quantity')
        from patients.stock_lots import lot_balances
        self.fields['lot'].choices = [('', 'Bez dokumentovane serije')]+[
            (json.dumps([batch, str(expiry or '')]), f'{batch} · rok {expiry or "nije poznat"} · {quantity:g}')
            for (batch, expiry), quantity in lot_balances(medicine).items() if batch]
        if len(self.fields['lot'].choices) == 1:
            self.fields['lot'].widget = forms.HiddenInput()
        elif len(self.fields['lot'].choices) == 2:
            self.initial['lot'] = self.fields['lot'].choices[1][0]

    def clean(self):
        data = super().clean()
        for checkbox, field in [('change_patient','patient_quantity'), ('change_physical','physical_quantity')]:
            if data.get(checkbox) and data.get(field) is None:
                self.add_error(field, 'Unesite novo stanje.')
        if data.get('reason_code') == 'other' and len(data.get('reason', '').strip()) < 5:
            self.add_error('reason', 'Opišite razlog ispravke (najmanje 5 znakova).')
        if data.get('change_physical') and len(self.fields['lot'].choices) > 1 and not data.get('lot'):
            self.add_error('lot', 'Odaberite seriju kojoj pripada razlika.')
        return data


class ReceiptForm(forms.Form):
    quantity = forms.DecimalField(label='Zaprimljena količina', min_value=1, max_digits=8, decimal_places=0)
    event_date = date_field('Datum stvarnog zaprimanja')
    batch = forms.CharField(label='Serija (ako je poznata)', required=False, max_length=100)
    expires = date_field('Rok trajanja (ako je poznat)', required=False)
    request_id = forms.ModelChoiceField(label='Komisija / isporuka (ako postoji veza)',
        queryset=m.Trebovanje.objects.none(), required=False, empty_label='Veza nije poznata')
    delivery_reference = forms.CharField(label='Oznaka isporuke (ako je poznata)', required=False, max_length=120)
    note = forms.CharField(label='Napomena / razlog naknadnog unosa', min_length=5, max_length=500, widget=forms.Textarea(attrs={'rows':2}))

    def __init__(self, *args, medicine, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['quantity'].label += ' — '+medicine.jedinice_zalihe[0]
        self.fields['request_id'].queryset = m.Trebovanje.objects.filter(lijek=medicine, komisija__isnull=False,
            komisijski_ciklus__isnull=False, status__in=['ODOBRENO', 'CEKA_ISPORUKU']).select_related('pacijent','komisijski_ciklus')
        self.fields['request_id'].label_from_instance = lambda obj: f'{obj.pacijent} · {obj.komisijski_ciklus} · primljeno {obj.zaprimljene_doze:g}/{obj.odobrene_doze:g}'
        self.fields['event_date'].widget.attrs['max'] = str(timezone.localdate())


class DeferredForm(forms.Form):
    appointment_id = forms.ModelChoiceField(label='Raniji termin', queryset=m.Termin.objects.none())
    decision = forms.ChoiceField(label='Šta se dogodilo?', choices=[('postpone','Terapija je odgođena'),('no_show','Pacijent nije došao')])
    new_date = date_field('Novi datum (ako je dogovoren)', required=False)
    note = forms.CharField(label='Razlog / napomena', min_length=5, max_length=500, widget=forms.Textarea(attrs={'rows':2}))

    def __init__(self, *args, patient, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['appointment_id'].queryset = m.Termin.objects.filter(pacijent=patient,
            status=m.Termin.STATUS_PLANIRANA, datum__lte=timezone.localdate()).order_by('-datum')

    def clean(self):
        data = super().clean()
        if data.get('new_date') and data.get('decision') != 'postpone':
            self.add_error('new_date', 'Novi datum se unosi samo za odgođenu terapiju.')
        if data.get('new_date') and data.get('appointment_id') and data['new_date'] <= data['appointment_id'].datum:
            self.add_error('new_date', 'Novi datum mora biti poslije ranijeg termina.')
        return data


class OtherForm(forms.Form):
    event_date = date_field('Datum stvarnog događaja')
    description = forms.CharField(label='Šta se dogodilo?', min_length=5, max_length=500, widget=forms.Textarea(attrs={'rows':3}))
    note = forms.CharField(label='Razlog naknadnog unosa', min_length=5, max_length=500, widget=forms.Textarea(attrs={'rows':2}))


class AppointmentMoveForm(forms.Form):
    appointment_id = forms.ModelChoiceField(label='Zakazani termin', queryset=m.Termin.objects.none())
    new_date = date_field('Novi datum')
    new_time = forms.TimeField(label='Novo vrijeme', widget=forms.TimeInput(attrs={'type': 'time'}, format='%H:%M'))
    move_scope = forms.ChoiceField(label='Koje termine pomjeriti?', widget=forms.RadioSelect)
    note = forms.CharField(label='Razlog promjene termina', min_length=5, max_length=500, widget=forms.Textarea(attrs={'rows': 2}))

    def __init__(self, *args, patient, initial=None, **kwargs):
        from patients.appointment_reschedule import scheduled, SCOPES
        super().__init__(*args, initial=initial, **kwargs)
        self.fields['appointment_id'].queryset = scheduled(patient)
        self.fields['appointment_id'].label_from_instance = lambda t: f'{t.datum:%d.%m.%Y.} {t.vrijeme:%H:%M} · {t.lijek} · {t.lijek.put_primjene}'
        self.fields['move_scope'].choices = SCOPES
        self.initial.setdefault('move_scope', 'one')
        self.fields['new_date'].widget.attrs['min'] = str(timezone.localdate())
        selected = self.fields['appointment_id'].queryset.filter(pk=self.initial.get('appointment_id')).first() if self.initial.get('appointment_id') else None
        if selected:
            self.initial.setdefault('new_date', selected.datum)
            self.initial.setdefault('new_time', selected.vrijeme)
        if not self.fields['appointment_id'].queryset.exists():
            self.blocked = 'Pacijent nema današnji ili budući zakazani termin. Otvorite raspored ili historiju termina.'


class LastDateForm(forms.Form):
    event_date = date_field('Novi datum posljednje terapije')
    razlog = forms.CharField(label='Kratko objašnjenje', min_length=5, max_length=400, widget=forms.Textarea(attrs={'rows':2}))


def form_for(category, patient, medicine, data=None, initial=None):
    if category == 'appointment':
        return AppointmentMoveForm(data, patient=patient, initial=initial)
    if category in ('reservation', 'physical'):
        return BalanceForm(data, patient=patient, medicine=medicine, category=category)
    if category in ('dose', 'interval'):
        from .quick_change_views import QuickChangeForm
        form = QuickChangeForm(data, patient=patient, kind=category)
        if category == 'dose' and not medicine.oralna_terapija and 'doza_mg' in form.fields:
            from patients.guided_reconciliation import documented_mg
            known = documented_mg(patient)
            form.fields['doza_mg'].initial = known
            if known is None:
                form.fields['doza_mg'].help_text = 'Propisana mg doza nije poznata. Potrebna je ručna potvrda prema nalogu; broj bočica nije dokaz mg doze.'
    elif category == 'last_date':
        therapy = service.latest_application(patient,medicine)
        snapshot = m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient).first() if not therapy else None
        current_date = therapy.datum if therapy else snapshot.datum_posljednje_terapije if snapshot else None
        form = LastDateForm(data, initial=dict(event_date=current_date))
        form.current_date = current_date
        form.fields['event_date'].widget.attrs['max'] = str(timezone.localdate())
    elif category in ('plan', 'route', 'medicine', 'change'):
        from .correction_plan_views import form_for as plan_form
        form = plan_form(patient, 'medicine', data)
        form.ustek_program_ids = ','.join(str(pk) for pk in
            form.fields['nova_terapija'].queryset.filter(protokol_kljuc='ustekinumab').values_list('pk',flat=True))
    elif category == 'therapy':
        from .retrospective_simple_views import SimpleEventForm
        if data is not None:
            data = data.copy()
            data['kind'] = 'therapy'
        form = SimpleEventForm(data, patient=patient, mode='explicit_effects',
            initial=dict(kind='therapy', patient_id=patient.pk, medicine_id=medicine.pk, **(initial or {})))
        for key in ('patient_id',):
            form.fields.pop(key, None)
        # One source note serves the existing clinical and attribution audit.
        # Nurses need not enter the same explanation in two text areas.
        form.fields.pop('link_reason')
        form.fields['note'] = forms.CharField(label='Razlog i izvor provjere naknadnog unosa',
            min_length=5,max_length=1000,widget=forms.Textarea(attrs={'rows':2}))
        form.fields['event_date'].label = 'Datum stvarne primjene'
        form.initial.setdefault('event_date', timezone.localdate())
        form.fields['dose_mg'] = forms.DecimalField(label='Primijenjena doza (mg)', min_value=Decimal('.01'), max_digits=8, decimal_places=2)
        from patients.late_event_sources import event_route, historical_reservations, protected_future_rows
        try:
            route = event_route(medicine)
        except ValueError:
            route = ''
        form.fields['route'] = forms.ChoiceField(label='Put primjene', choices=[('', 'Odaberite prezentaciju'), ('IV','IV'),('SC','SC'),('PO','Oralno')], initial=route)
        if route == 'PO':
            form.fields['route'].disabled = True
        form.fields['accounting_choice'].label = 'Kako evidentirati potrošenu dozu?'
        form.fields['accounting_choice'].widget = forms.RadioSelect()
        form.fields['accounting_choice'].choices = [
            ('both','Skini iz zaduženja pacijenta i fizičke zalihe'),
            ('patient','Skini samo iz zaduženja pacijenta'),
            ('stock','Skini samo iz fizičke zalihe — potroši iz slobodne fizičke zalihe'),
            ('neither','Ne mijenjaj zalihu ni zaduženje')]
        form.fields['accounting_choice'].help_text = ''
        form.fields['quantity'].label = 'Potrošena količina — '+medicine.jedinice_zalihe[0]
        form.fields['reservation_id'].label = 'Zaduženje iz kojeg je doza potrošena'
        form.fields['skip_reason'].label = 'Zašto se dio evidencije ne mijenja?'
        # Only medicine-specific links appear; the existing service validates
        # their real date and appointment as well at preview and confirmation.
        try:
            when = form.fields['event_date'].clean(data.get('event_date') if data else form.initial['event_date'])
        except ValidationError:
            when = None
        sources = historical_reservations(patient, medicine, when)
        form.fields['reservation_id'].queryset = sources
        form.fields['reservation_id'].empty_label = 'Odaberite odgovarajuće historijsko zaduženje'
        form.protected_reservations = protected_future_rows(patient, when) if when else []
        form.fields['commission_id'].queryset = form.fields['commission_id'].queryset.filter(lijek_id__in=medicine.physical_equivalent_ids())
        if when:
            form.fields['commission_id'].queryset = form.fields['commission_id'].queryset.filter(datum_odobrenja__lte=when)
        if not data:
            first = sources.first()
            if first:
                form.initial['reservation_id'] = first.pk
        form.fields['source_id'].queryset = form.fields['source_id'].queryset.filter(lijek=medicine)
        form.fields['source_id'].label = 'Serija / prijem potrošenog lijeka (ako je poznat)'
        for name in ('reservation_id','commission_id','source_id'):
            form.fields[name].help_text = ''
        form.fields['reservation_id'].label_from_instance = lambda obj: f'{obj.kolicina:g} {medicine.jedinice_zalihe[0]} · '+(
            obj.termin.datum.strftime('%d.%m.%Y.') if obj.termin_id else 'bez vezanog termina')
        form.fields['commission_id'].label_from_instance = lambda obj: f'{obj.broj_saglasnosti or "Bez broja saglasnosti"} · preostalo {obj.preostale_doze:g}'
        form.fields['source_id'].label_from_instance = lambda obj: f'{obj.datum:%d.%m.%Y.} · {obj.serija or "Serija nije navedena"} · {obj.kolicina:g}'
    elif category == 'receipt':
        return ReceiptForm(data, medicine=medicine)
    elif category == 'home':
        from .retrospective_forms import EventForm
        form = EventForm(data, kind='home', patient_context=patient, medicine_context=medicine)
        form.fields.pop('patient_id', None)
        form.fields['commission_id'].queryset = form.fields['commission_id'].queryset.filter(lijek=medicine)
        form.fields['commission_id'].label_from_instance = lambda obj: f'{obj.broj_saglasnosti or "Bez broja saglasnosti"} · preostalo {obj.preostale_doze:g}'
        form.fields['note'].min_length = 5
        form.fields['note'].required = True
        if medicine.oralna_terapija:
            from patients.oral_therapy import approval_options
            form.fields['quantity'].label = 'Količina tableta'
            form.fields['quantity'].decimal_places = 0
            form.fields['route'] = forms.ChoiceField(label='Put primjene', choices=[('PO', 'Oralno')], initial='PO', disabled=True)
            form.fields['commission_id'].required = False
            form.fields['commission_id'].widget = forms.HiddenInput()
            form.fields.pop('separate_event', None)
            form.fields.pop('history_confirmed', None)
            form.fields['approval_source'] = forms.ChoiceField(label='Odobrena saglasnost', required=False,
                choices=[('', 'Odaberite saglasnost ili komisijsko odobrenje')]+[(o['value'], o['label']) for o in approval_options(patient, medicine)])
        else:
            form.fields['route'] = forms.ChoiceField(label='Put primjene', choices=[('SC', 'SC')], initial='SC', disabled=True)
    elif category == 'deferred':
        return DeferredForm(data, patient=patient)
    else:
        return OtherForm(data)
    if category in ('dose', 'interval', 'last_date', 'plan', 'route', 'medicine'):
        form.fields['reason_code'] = forms.ChoiceField(label='Razlog ispravke', choices=[('', 'Odaberite razlog')]+service.REASONS)
    if category == 'change':
        form.fields['datum_pocetka_nove_terapije'].label = 'Datum stvarne promjene terapije'
        form.fields['datum_pocetka_nove_terapije'].widget.attrs['max'] = str(timezone.localdate())
    if category in ('therapy', 'home'):
        from patients.late_event_sources import event_route
        form.fields['medicine_id'].queryset = m.Lijek.objects.all().order_by('naziv', 'pk')
        form.initial['medicine_id'] = medicine.pk
        form.fields['medicine_id'].label = 'Stvarni lijek / prezentacija događaja'
        form.catalogue = []
        for product in form.fields['medicine_id'].queryset:
            try:
                route = event_route(product)
            except ValueError:
                route = ''
            form.catalogue.append(dict(id=str(product.pk), route=route, oral=product.oralna_terapija))
    return form


def raw_data(form, category, patient, medicine):
    data = {key:value.pk if hasattr(value, 'pk') else value for key,value in form.cleaned_data.items()}
    if category in ('plan', 'route', 'medicine', 'change'):
        # These are ModelForms. Rebuild through the original adapter using
        # submitted fields, not the generated product object in cleaned_data.
        data = {key:form.data.get(key, form.get_initial_for_field(field,key))
                for key,field in form.fields.items()}
        data['therapy_selection_kind'] = 'program'
    if data.get('reason_code'):
        key = 'razlog' if category in ('dose', 'interval', 'last_date') else 'napomena' if category in ('plan','route','medicine') else 'reason'
        data[key] = (dict(service.REASONS)[data['reason_code']]+': '+str(data.get(key,'')).strip()).rstrip(': ')
    if category in ('therapy', 'home'):
        data.update(patient_id=patient.pk, kind=category)
        medicine = m.Lijek.objects.get(pk=data['medicine_id'])
        if category == 'therapy':
            data['entry_mode'] = 'explicit_effects'
            data['link_reason'] = data['note']
            data['actual_route'] = data['route']
            from patients.late_event_sources import event_route
            if data['route'] != event_route(medicine):
                raise ValueError('Put primjene mora odgovarati odabranom obliku lijeka. Odaberite odgovarajući IV, SC ili oralni lijek.')
            if data['accounting_choice'] in ('stock', 'neither'):
                data['reservation_id'] = None
            if data['approval_action'] == 'unresolved':
                data['commission_id'] = None
    return data


@login_required
@never_cache
@require_http_methods(['GET','POST'])
def workflow(request, category):
    from django.http import Http404
    if category not in LABELS and category != 'medicine':
        raise Http404
    service.authorize(request.user, category)
    if hasattr(request, 'correction_center'):
        request.correction_center['nurse_workflow'] = True
    patient_id = request.GET.get('cc_patient')
    patient = get_object_or_404(m.Pacijent, pk=patient_id) if patient_id else None
    medicine_id = request.GET.get('cc_medicine') or (patient.lijek_id if patient else None)
    if category in ('therapy', 'home', 'appointment') and request.method == 'POST':
        medicine_id = request.POST.get('medicine_id') or medicine_id
        if request.POST.get('action') == 'confirm':
            try:
                payload = signing.loads(request.POST.get('token', ''), salt=service.SALT)
                if payload.get('patient') == (patient.pk if patient else None) and payload.get('category') == category:
                    medicine_id = payload['medicine']
            except (signing.BadSignature, KeyError):
                pass
    if category == 'appointment' and request.POST.get('action') != 'confirm':
        identity = request.POST.get('appointment_id') or request.GET.get('appointment_id')
        if identity and str(identity).isdigit() and patient:
            selected = m.Termin.objects.filter(pk=identity, pacijent=patient).first()
            if selected:
                medicine_id = selected.lijek_id
    medicine = get_object_or_404(m.Lijek, pk=medicine_id)
    if not patient and category not in ('physical','receipt'):
        raise Http404('Odaberite pacijenta.')
    if category == 'route' and medicine.genericki_naziv.lower() == 'ustekinumab':
        from .ustekinumab_transition_views import transition
        return transition(request, patient.pk)
    action = request.POST.get('action')
    data = request.POST if request.method=='POST' and action != 'confirm' else None
    if action == 'sources' and category == 'therapy':
        from patients.late_event_sources import event_route
        data = data.copy()
        try:
            data['route'] = event_route(medicine)
        except ValueError:
            data['route'] = ''
    continuation = {key:request.GET[key] for key in ('event_date','quantity','dose_mg')
                    if category == 'therapy' and request.method == 'GET' and request.GET.get(key)}
    if category == 'appointment' and request.method == 'GET':
        continuation = {key: request.GET[key] for key in ('appointment_id', 'new_date', 'new_time', 'move_scope') if request.GET.get(key)}
    form = form_for(category, patient, medicine, data, initial=continuation)
    if request.method == 'GET' and category == 'therapy' and request.GET.get('accounting_choice') in ('stock','both','neither'):
        form.initial['accounting_choice'] = request.GET['accounting_choice']
    if action in ('sources', 'edit'):
        # Source refresh is a partial form step; display submitted values
        # without running validation for dose, note and accounting choices.
        from django.forms.utils import ErrorDict
        form._errors = ErrorDict()
    context = dict(category=category, title=LABELS.get(category, 'Promjena terapije'), form=form,
        sidebar_active_section='retrospective',
        patient=patient, medicine=medicine, current_medicine=patient.lijek if patient and category in ('therapy', 'home', 'appointment') else None,
        event_mode=category in {key for key,_,_,_ in EVENTS},
        current=service.amounts(patient,medicine),
        original_fields=[(key, value) for key in request.POST for value in request.POST.getlist(key)
                         if key not in ('action','token','csrfmiddlewaretoken','confirmed','acknowledge','guided_actions','guided_choices','rejection_reason')])
    from .correction_center_views import center_url
    context['center_home'] = center_url(patient=patient, medicine=medicine)
    if patient:
        try:
            from patients.quick_changes import current_regimen
            context['regimen'] = current_regimen(patient)
            if category == 'dose' and not medicine.oralna_terapija:
                from patients.guided_reconciliation import documented_mg
                context['regimen']['doza_mg'] = documented_mg(patient)
        except ValidationError:
            pass
    try:
        if request.method=='POST':
            if action == 'confirm':
                service.require_reviewed_selection(request.POST, request.POST.get('token',''))
                service.require(request.POST.get('confirmed') == 'yes', 'Potvrdite pregled izmjene.')
                receipt, _ = service.confirm(request.POST.get('token',''), request.user, category=category,
                    patient_id=patient.pk if patient else None, medicine_id=medicine.pk,
                    acknowledge=request.POST.get('acknowledge') == 'yes')
                context.update(saved=receipt, preview=receipt.posljedice)
            elif action in ('recommend', 'choose'):
                context['preview'], context['token'] = service.revise_preview(request.POST.get('token',''), request.user,
                    category=category, patient_id=patient.pk if patient else None, medicine_id=medicine.pk,
                    apply_recommended=action=='recommend', selected=request.POST.getlist('guided_actions'),
                    rejection_reason=request.POST.get('rejection_reason',''))
            elif action == 'preview' and form.is_valid():
                context['preview'], context['token'] = service.preview(category, patient, medicine,
                    raw_data(form, category, patient, medicine), request.user)
    except (ValueError, ValidationError, signing.BadSignature) as exc:
        context['error'] = ' '.join(exc.messages) if isinstance(exc, ValidationError) else str(exc)
    except DatabaseError as exc:
        logger.exception('Guided correction failed; category=%s', category)
        context['error'] = contention_message(exc) or 'Izmjena nije sačuvana. Provjerite dostupnost baze pa ponovite pregled.'
    if category == 'appointment' and action == 'confirm' and context.get('error'):
        # A failed atomic commit returns the user's requested dates, scope and
        # reason for a fresh preview, rather than reverting the input fields.
        form = form_for(category, patient, medicine, request.POST)
        context['form'] = form
    # One screen contains only the relevant fields. Conditional groups are
    # disabled in JS and validated independently on the server.
    for field in form:
        field.field.widget.attrs.setdefault('class', 'cc-input')
    if context.get('preview') and category == 'therapy':
        preview = context['preview']; effect = preview['accounting']
        context['review_rows'] = [
            dict(label='Terapija', before='Nije evidentirana', after=f'{medicine} · {preview["data"].get("actual_route", "")} · {preview["data"]["dose_mg"]} mg · {preview["data"]["quantity"]} {medicine.jedinice_zalihe[0]} · '+
                date.fromisoformat(preview['data']['event_date']).strftime('%d.%m.%Y.')),
            dict(label='Zaduženje pacijenta', before=effect['reserved'], after=effect['reserved_after'], unit=medicine.jedinice_zalihe[0]),
            dict(label='Fizička zaliha', before=effect['physical'], after=effect['physical_after'], unit=medicine.jedinice_zalihe[0]),
            *[row for row in effect['rows'] if 'pravo' in row['label'].lower() or 'odobrenj' in row['label'].lower()],
            *effect.get('protected_reservations', []), preview['rows'][-1]]
    elif context.get('preview') and category in ('plan','route','change'):
        context['review_rows'] = [row for row in context['preview']['rows'] if row['label'] in
            ('Ukupna fizička zaliha','Pacijentovo zaduženje u frižideru','Trenutna terapija / proizvod')]
        context['review_rows'].append(dict(label='Novi protokol i doza', before='Dosadašnji nalog', after='Prema odabranoj terapiji'))
    if context.get('preview'):
        import re
        context['display_warnings'] = [re.sub(r'\s*#\d+', '', warning).replace(
            'Kontrolni popis ostaje sačuvan. Ne knjiži se kompenzacijski prijem.', 'Raniji popis ostaje sačuvan.')
            for warning in context['preview'].get('warnings', [])]
        context['guided_impact'] = context['preview'].get('guided_impact')
        if context['guided_impact']:
            context['review_rows'] = context['guided_impact']['final_preview']
    if context.get('error') or form.errors or getattr(form, 'blocked', ''):
        from patients.guided_reconciliation import recovery
        if category == 'therapy' and form.errors.get('reservation_id') and str(request.POST.get('reservation_id','')).isdigit():
            chosen = m.PacijentRezervacija.objects.filter(pk=request.POST['reservation_id'], pacijent=patient).select_related('termin').first()
            when = form.cleaned_data.get('event_date')
            if chosen and chosen.termin and when and chosen.termin.datum > when:
                context['error'] = (f'Rezervacija od {chosen.termin.datum:%d.%m.%Y.} pripada budućem terminu i neće biti potrošena '
                                    f'za terapiju od {when:%d.%m.%Y.}. Odaberite drugi siguran izvor.')
        message = context.get('error') or getattr(form, 'blocked', '') or form.errors.as_text()
        context['guided_recovery'] = recovery(category, patient, medicine, message, raw=request.POST)
        if category == 'appointment' and patient:
            from patients.appointment_reschedule import links
            identity = request.POST.get('appointment_id') or request.GET.get('appointment_id')
            if str(identity or '').isdigit():
                context['guided_recovery']['safe_next_actions'] = links(patient, medicine, identity, request.POST)
    return render_in_center(request, 'dashboard/nurse_correction_form.html', context)
