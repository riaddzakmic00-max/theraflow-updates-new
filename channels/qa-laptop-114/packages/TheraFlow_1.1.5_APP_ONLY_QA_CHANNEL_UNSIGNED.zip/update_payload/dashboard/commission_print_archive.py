"""Original commission PDFs. Historical documents are read, never rebuilt."""
from contextlib import contextmanager
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import re
import shutil
import uuid

from django.conf import settings
from django.db import transaction
from PyPDF2 import PdfReader, PdfWriter


def request_archive_metadata(request):
    snapshot = request.print_snapshot
    archive = snapshot.get('document_archive') if isinstance(snapshot, dict) else None
    return archive if isinstance(archive, dict) else {}


def snapshot_digest(snapshot):
    if not isinstance(snapshot, dict):
        return ''
    payload = {key: value for key, value in snapshot.items() if key != 'document_archive'}
    return sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                            separators=(',', ':')).encode('utf-8')).hexdigest()


def archive_file_metadata(path, **extra):
    path = Path(path)
    with path.open('r+b') as source:
        data = source.read()
        os.fsync(source.fileno())
    return dict(filename=path.name, path=path.resolve().relative_to(
        Path(settings.MEDIA_ROOT).resolve()).as_posix(),
        sha256=sha256(data).hexdigest(), **extra)


def resolve_archive_file(request, metadata):
    """Reject missing, changed, foreign, malformed or escaped archived files."""
    archive = request_archive_metadata(request)
    if archive.get('request_id') != request.pk or archive.get('cycle_id') != request.komisijski_ciklus_id:
        return None
    if archive.get('payload_sha256') != snapshot_digest(request.print_snapshot):
        return None
    generation = archive.get('generation_id', '')
    if not isinstance(generation, str) or not re.fullmatch(r'[A-Za-z0-9_-]+', generation) or not isinstance(metadata, dict):
        return None
    filename = metadata.get('filename', '')
    if not isinstance(filename, str) or not filename or Path(filename).name != filename or '/' in filename or '\\' in filename:
        return None
    expected = Path('generated') / 'commission_phase2' / f'cycle_{request.komisijski_ciklus_id}' / generation / filename
    if metadata.get('path') != expected.as_posix():
        return None
    root = Path(settings.MEDIA_ROOT).resolve()
    candidate = root / expected
    try:
        if candidate.resolve().parent != (root / expected.parent).resolve() or not candidate.resolve().is_relative_to(root):
            return None
        data = candidate.read_bytes()
        if not data.startswith(b'%PDF-') or sha256(data).hexdigest() != metadata.get('sha256'):
            return None
        pdf = PdfReader(BytesIO(data))
        if pdf.is_encrypted or not pdf.pages:
            return None
        return candidate
    except (OSError, ValueError, TypeError, KeyError):
        return None
    except Exception:
        # Corrupt PDF parser errors have the same safe outcome as a missing copy.
        return None


def resolve_request_archive(request):
    archive = request_archive_metadata(request)
    if archive.get('filename') != f'zahtjev_{request.pk}.pdf':
        return None
    return resolve_archive_file(request, archive)


def write_request_archive(request, page, directory, generation_id):
    """Persist the exact page from the generated category, without re-rendering."""
    directory = Path(directory)
    expected = (Path(settings.MEDIA_ROOT) / 'generated' / 'commission_phase2'
                / f'cycle_{request.komisijski_ciklus_id}' / generation_id)
    if directory.resolve() != expected.resolve() or not directory.resolve().is_relative_to(Path(settings.MEDIA_ROOT).resolve()):
        raise ValueError('Archive directory does not belong to this request')
    target = directory / f'zahtjev_{request.pk}.pdf'
    writer = PdfWriter()
    writer.add_page(page)
    with target.open('xb') as output:
        writer.write(output)
        output.flush()
        os.fsync(output.fileno())
    return archive_file_metadata(target, request_id=request.pk,
        cycle_id=request.komisijski_ciklus_id, generation_id=generation_id,
        payload_sha256=snapshot_digest(request.print_snapshot))


def write_legacy_batch_archives(documents):
    """Stage all new legacy pages before replacing any existing active copy."""
    if not documents:
        return
    root = (Path(settings.MEDIA_ROOT) / 'generated').resolve()
    if not root.is_relative_to(Path(settings.MEDIA_ROOT).resolve()):
        raise OSError('Archive directory escaped the configured media root')
    root.mkdir(parents=True, exist_ok=True)
    attempt = root / f'.commission-archive-{uuid.uuid4().hex}'
    attempt.mkdir(exist_ok=False)
    previous, installed = {}, []
    try:
        for target, data in documents:
            target = Path(target).resolve()
            if target.parent != root or not re.fullmatch(r'zahtjev_zavodu_trebovanje_[0-9]+\.pdf', target.name):
                raise ValueError('Legacy archive path escaped the generated directory')
            previous[target] = target.read_bytes() if target.exists() else None
            with (attempt / target.name).open('xb') as output:
                output.write(data)
                output.flush()
                os.fsync(output.fileno())
        for target in previous:
            os.replace(attempt / target.name, target)
            installed.append(target)
    except Exception:
        for target in reversed(installed):
            if previous[target] is None:
                target.unlink()
            else:
                restore = attempt / target.name
                restore.write_bytes(previous[target])
                os.replace(restore, target)
        raise
    finally:
        if attempt.parent == root and attempt.name.startswith('.commission-archive-'):
            shutil.rmtree(attempt)


@contextmanager
def legacy_finalization_archives(requests, render):
    """Keep original legacy pages and the existing send operation together.

    Only active selected requests are rendered. All pages are staged before
    replacing any flat archive; a failed send restores the prior bytes.
    """
    from patients.medicine_document_metadata import is_active_document
    from patients.transaction_locking import select_for_update_self

    previous, documents = {}, []
    root = attempt = None
    installation_attempted = False

    def restore_originals():
        if not installation_attempted:
            return
        for target in previous:
            if target.is_symlink() or target.resolve() != target:
                raise OSError('Rollback archive path escaped its request target')
        fallback = []
        for target, data in previous.items():
            if data is None:
                continue
            original = attempt / f'.original-{target.name}'
            if original.is_file():
                if original.is_symlink() or original.resolve().parent != attempt:
                    raise OSError('Original archive escaped the staging directory')
                os.replace(original, target)
            else:
                fallback.append((target, data))
        write_legacy_batch_archives(fallback)
        for target, data in previous.items():
            if data is None:
                target.unlink(missing_ok=True)

    def cleanup_stage():
        if attempt is None or (not attempt.is_symlink() and not attempt.exists()):
            return
        if (attempt.is_symlink() or attempt.resolve().parent != root
                or not attempt.name.startswith('.commission-finalization-')):
            raise OSError('Archive staging cleanup escaped its owned directory')
        shutil.rmtree(attempt)

    try:
        with transaction.atomic():
            selected = list(select_for_update_self(requests)
                .select_related('pacijent', 'lijek', 'komisijski_ciklus').order_by('pk'))
            active = [item for item in selected if is_active_document(item)]
            if not active:
                yield
                return

            media_root = Path(settings.MEDIA_ROOT).resolve()
            root = (media_root / 'generated').resolve()
            if not root.is_relative_to(media_root):
                raise OSError('Archive directory escaped the configured media root')
            root.mkdir(parents=True, exist_ok=True)
            attempt = root / f'.commission-finalization-{uuid.uuid4().hex}'
            attempt.mkdir(exist_ok=False)
            try:
                for item in active:
                    target = root / f'zahtjev_zavodu_trebovanje_{item.pk}.pdf'
                    if target.is_symlink() or target.resolve() != target:
                        raise OSError('Legacy archive path escaped its request target')
                    previous[target] = target.read_bytes() if target.exists() else None
                    if previous[target] is not None:
                        with (attempt / f'.original-{target.name}').open('xb') as original:
                            original.write(previous[target])
                            original.flush()
                            os.fsync(original.fileno())
                for item in active:
                    target = root / f'zahtjev_zavodu_trebovanje_{item.pk}.pdf'
                    staged = attempt / target.name
                    render(item, staged)
                    if staged.is_symlink() or staged.resolve().parent != attempt:
                        raise OSError('Rendered archive escaped the staging directory')
                    with staged.open('r+b') as source:
                        data = source.read()
                        os.fsync(source.fileno())
                    try:
                        pdf = PdfReader(BytesIO(data))
                        valid = data.startswith(b'%PDF-') and not pdf.is_encrypted and bool(pdf.pages)
                    except Exception as exc:
                        raise OSError('Original legacy PDF could not be preserved') from exc
                    if not valid:
                        raise OSError('Original legacy PDF could not be preserved')
                    documents.append((target, data))

                installation_attempted = True
                write_legacy_batch_archives(documents)
                yield
                cleanup_stage()
            except BaseException:
                # Compensate while selected request locks are still held.
                restore_originals()
                installation_attempted = False
                raise
    except BaseException:
        # The atomic block can also fail when releasing its savepoint/commit.
        restore_originals()
        raise
    finally:
        cleanup_stage()
