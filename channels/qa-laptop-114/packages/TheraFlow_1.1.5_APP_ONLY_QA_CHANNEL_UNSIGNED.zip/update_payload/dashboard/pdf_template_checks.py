from django.core.checks import Error, Tags, register

from theraflow.pdf_templates import validate_pdf_templates


@register(Tags.files)
def check_pdf_templates(app_configs=None, **kwargs):
    """The existing engine runs manage.py check --deploy after installing files."""
    return [Error(error.user_message, id="pdf_templates.E001") for error in validate_pdf_templates()]


def log_startup_pdf_templates():
    # WSGI startup also checks availability, without requiring a database query
    # or taking the entire clinical application offline for a missing form.
    from theraflow.pdf_templates import logger
    for error in validate_pdf_templates():
        logger.error("PDF startup preflight: %s", error.user_message)
