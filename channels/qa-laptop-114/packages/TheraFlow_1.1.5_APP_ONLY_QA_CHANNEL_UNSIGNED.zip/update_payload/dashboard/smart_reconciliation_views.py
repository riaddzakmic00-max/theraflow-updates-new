"""Phase 2: one guided administrative therapy review inside Correction Center."""
import logging
from datetime import timedelta
from urllib.parse import urlencode

from django import forms
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import DatabaseError
from django.http import Http404
from django.shortcuts import redirect
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from patients import models as m, smart_reconciliation as service
from patients.data_corrections import CorrectionBlocked
from patients.correction_protocol import correction_transaction, contention_message
from .postgres_backup import BackupError
from .correction_center_views import render_in_center

logger = logging.getLogger(__name__)


class ReviewFilters(forms.Form):
    start = forms.DateField(label='Datum OD', widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
    end = forms.DateField(label='Datum DO', widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
    medicine = forms.ModelChoiceField(label='Lijek / prezentacija', queryset=m.Lijek.objects.order_by('naziv'), required=False, empty_label='Svi lijekovi')
    patient = forms.ModelChoiceField(label='Pacijent', queryset=m.Pacijent.objects.order_by('prezime', 'ime'), required=False, empty_label='Svi pacijenti')
    reason = forms.CharField(label='Razlog provjere', min_length=5, max_length=500,
                            initial='Naknadno usklađivanje terapija')


def url(session=None, *, absence=False):
    section = 'absence' if absence or session and session.workflow == 'absence' else 'smart'
    return reverse('correction_center') + '?' + urlencode({'section': section, **({'session': session.pk} if session else {})})


@login_required
@require_http_methods(['GET', 'POST'])
def index(request, *, absence=False):
    service.authorize(request.user)
    session = None
    context = {'decisions': service.DECISIONS, 'smart_home': url(absence=absence), 'absence': absence}
    today = timezone.localdate()
    form = ReviewFilters(initial=dict(start=request.GET.get('start') or today-timedelta(days=29), end=request.GET.get('end') or today,
        patient=request.GET.get('cc_patient'), medicine=request.GET.get('cc_medicine'),
        reason=request.GET.get('reason') or ('Usklađivanje perioda odsustva' if absence else 'Naknadno usklađivanje terapija')))
    if request.GET.get('session'):
        try:
            session = service.own_session(request.GET['session'], request.user)
            if session.workflow == 'absence' and not absence: return redirect(url(session))
            if absence:
                from patients import absence_reconciliation
                # Refresh belongs inside the database error boundary below.
        except (m.ReconciliationSession.DoesNotExist, ValueError):
            raise Http404('Proces nije pronađen.') from None
    try:
        if session and absence:
            session = absence_reconciliation.refresh(session.pk, request.user)
        if request.method == 'POST':
            action = request.POST.get('action')
            if action == 'check':
                form = ReviewFilters(request.POST)
                if form.is_valid():
                    if absence:
                        from patients.absence_reconciliation import start_session
                    else: start_session = service.start_session
                    session = start_session(user=request.user, **form.cleaned_data)
                    return redirect(url(session))
            else:
                if not session: raise Http404
                if action == 'preview':
                    context['preview'], context['token'] = service.prepare(session.pk, request.POST, request.user)
                elif action == 'confirm':
                    service.require(request.POST.get('confirmed') == 'yes', 'Potvrdite da ste pregledali posljedice.')
                    saved, created = service.confirm(request.POST.get('token', ''), request.user, session_id=session.pk)
                    service.require(saved.session_id == session.pk, 'Potvrda ne pripada ovom procesu.')
                    return redirect(url(session) + '&saved=' + str(saved.pk))
                elif action in ('finish', 'cancel'):
                    service.finish(session.pk, request.user, cancel=action == 'cancel')
                    return redirect(url(session))
                elif action == 'discard':
                    # Discard the capability, retaining the process and all committed events.
                    with correction_transaction():
                        session = service.own_session(session.pk, request.user, lock=True)
                        session.preview = {}; session.preview_fingerprint = ''; session.revision += 1
                        if session.status == 'previewed': session.status = 'partially_applied' if session.actions.exists() else 'draft'
                        session.save(update_fields=['preview', 'preview_fingerprint', 'revision', 'status'])
                    return redirect(url(session))
                else:
                    raise Http404
    except (ValueError, ValidationError) as exc:
        context['error'] = '; '.join(exc.messages) if isinstance(exc, ValidationError) else str(exc)
    except (BackupError, DatabaseError) as exc:
        logger.exception('Pametno usklađivanje nije potvrđeno; transakcija je vraćena.')
        context['error'] = contention_message(exc) or 'Usklađivanje nije primijenjeno. Backup ili pristup bazi nije uspio; nijedna posljedica ovog događaja nije sačuvana.'
    if session:
        session.refresh_from_db()
        done = set(session.actions.exclude(decision='skip').exclude(event__reversed_at__isnull=False).values_list('appointment_id', flat=True))
        cards = []
        for finding in session.findings:
            if finding.get('id') in done: continue
            term = m.Termin.objects.select_related('pacijent', 'lijek').filter(pk=finding.get('id')).first() if finding.get('id') else None
            item = service.card(term) if term else finding
            if item.get('actual_ids'):
                item['actual_url'] = reverse('profil_pacijenta', args=[item['patient_id']])
            cards.append(item)
        if absence:
            cards = absence_reconciliation.therapy_cards(session)
        context.update(session=session, cards=cards, actions=session.actions.select_related('appointment', 'user', 'event'),
            session_url=url(session), open_session=session.status not in ('completed', 'cancelled', 'aligned'))
        if absence:
            from patients import absence_reconciliation
            context.update(step=1, steps=absence_reconciliation.STEPS, overview=absence_reconciliation.summary(session))
        if session.status == 'previewed' and session.preview and not context.get('error'):
            context.update(preview=session.preview['plan'], token=service.preview_token(session, request.user))
            context['preview_stale'] = session.preview_fingerprint != service.digest(service.domain_snapshot())
        if context.get('preview'):
            context['preview_fields'] = {k: v for k, v in context['preview']['data'].items() if v is not None}
        if request.GET.get('saved'):
            context['saved'] = session.actions.filter(pk=request.GET['saved']).first()
    context.update(form=form, recent=m.ReconciliationSession.objects.filter(user=request.user)[:12])
    return render_in_center(request, 'dashboard/smart_reconciliation.html', context)
