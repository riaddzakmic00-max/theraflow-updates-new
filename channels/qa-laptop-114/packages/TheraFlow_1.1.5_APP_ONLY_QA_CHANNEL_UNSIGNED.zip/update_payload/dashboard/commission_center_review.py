"""Review the existing live planner and delegate confirmation to its established writer."""
from decimal import Decimal
from uuid import uuid4
from django.core import signing
from django.core.exceptions import ValidationError
from django.http import QueryDict
from patients.data_corrections import digest
from patients.commission_request_types import (
    classify_commission_request, preload_commission_classification_history,
)
from patients.commission_request_state import APPROVED, CONFIRMED, PARTIALLY_RECEIVED, SENT
from patients.commission_eligibility import STATUS_RIZIK_PREKIDA
from .permissions import je_komisijski_tim

SALT = 'theraflow.commission-center.review.v1'


def planning_records():
    """Read planner inputs only; large audit/document archives are irrelevant."""
    from patients import models as m
    from patients.data_corrections import serial
    names = ('Pacijent', 'Lijek', 'TerapijskiProgram', 'TerapijskiProtokol', 'TerapijskiKorakProtokola',
        'IndividualniProtokolPacijenta', 'IndividualniKorakProtokola', 'FazniProtokolPacijenta',
        'Terapija', 'Termin', 'Komisija', 'Trebovanje', 'KucnoIzdavanje', 'KucnaTerapijaPodatak',
        'PacijentZaduzenje', 'PacijentRezervacija', 'Zaliha', 'ZalihaTransakcija',
        'PostavkeSistema', 'PromjenaTerapije', 'MigracijskiSnapshotPacijenta',
        'KomisijskiCiklus', 'KomisijskiRucniUnos', 'KomisijskoIskljucenje',
        'KomisijskiZahtjev', 'KomisijskaStavkaLijeka', 'KomisijskaSaglasnost')
    records = {}
    for name in names:
        model = getattr(m, name)
        records[model._meta.db_table] = {str(row['id']): serial(row) for row in model.objects.order_by('pk').values()}
    return records


def planning_fingerprint():
    return digest(planning_records())


def annotate_rows(rows, user):
    preload_commission_classification_history(row['pacijent'] for row in rows)
    for row in rows:
        quantity = Decimal(str(row.get('final_procurement_units', row.get('za_novu_komisiju', 0)) or 0))
        classification = classify_commission_request(row['pacijent'])
        row['cc_classification'] = classification
        demand = row.get('demand')
        row['cc_free_stock_available'] = Decimal(str(demand.dostupno_po_izvoru.get('SLOBODNO_U_FRIZIDERU_DOSTUPNO', 0) or 0)) if demand else Decimal('0')
        eligibility = row.get('commission_eligibility')
        horizon = getattr(eligibility, 'obracunski_ciljni_datum', None)
        details = [detail for detail in row.get('_projekcija_zalihe_detalji', ())
                   if horizon is None or detail.datum_terapije <= horizon]
        def allocated(sources):
            return sum((allocation.quantity for detail in details
                        for allocation in detail.izvori_pokrica if allocation.source in sources), Decimal('0'))
        row['cc_physical_coverage'] = allocated({'KOD_PACIJENTA', 'REZERVISANO_U_FRIZIDERU'})
        row['cc_timely_incoming'] = allocated({'ODOBRENO_CEKA_DOSTAVU'})
        row['cc_remaining_shortage'] = max(Decimal('0'), Decimal(str(row.get('minimalno_potrebno', 0) or 0))
            + Decimal(str(row.get('sigurnosna_rezerva', 0) or 0))
            - Decimal(str(row.get('vec_pokriveno_za_preporuku', 0) or 0)))
        state = getattr(row['pacijent'], 'aktivni_fazni_protokol', None)
        state = state() if callable(state) else state
        initial = getattr(state, 'pocetni_komisijski_zahtjev', None) if state else None
        row['cc_initial_phased_request'] = initial if initial and initial.stavke_lijeka.count() > 1 else None
        result = row.get('planning_result')
        from patients.individual_protocols import infliximab_logistics_review_reason
        vial_error = infliximab_logistics_review_reason(row['pacijent'])
        review = bool(vial_error or row.get('za_pregled') or (result and not result.planiranje_moguce)
                      or (quantity > 0 and classification.requires_confirmation)
                      or bool(row['cc_initial_phased_request'] and row['cc_initial_phased_request'].status == 'nacrt'))
        ready = bool(row.get('included_in_draft', row.get('ukljucen_u_nacrt'))
                     and quantity > 0 and not review and not row.get('rucno_iskljucen'))
        decision = row.get('commission_decision')
        existing_request = bool(decision and getattr(decision, 'existing_request_state_code', '')
                                in {CONFIRMED, SENT, APPROVED, PARTIALLY_RECEIVED})
        # Legacy draft flags may lag behind an already confirmed document.
        # The canonical request state must prevent another confirmation.
        ready = ready and not existing_request
        delivery_warning = (
            getattr(eligibility, 'razlog', '')
            if getattr(eligibility, 'status', '') == STATUS_RIZIK_PREKIDA else
            row.get('status_razlog', '')
            if row.get('rizik_dostave') or row.get('rizik_prekida_terapije') else ''
        )
        if vial_error:
            reason = vial_error
        elif row['cc_initial_phased_request'] and row['cc_initial_phased_request'].status == 'nacrt':
            reason = 'Pregledajte postojeći početni zahtjev s odvojenim IV i SC stavkama.'
        elif quantity > 0 and classification.requires_confirmation:
            reason = classification.reason
        elif result and not result.planiranje_moguce:
            reason = result.razlog
        elif review:
            # A complete protocol can still have an unconfirmed home schedule.
            # The positive planning message must not hide the actual problem.
            reason = row.get('status_razlog') or getattr(decision, 'recommendation_text', '')
        elif existing_request:
            reason = ' '.join((
                getattr(decision, 'recommendation_text', ''),
                'Ne treba pripremati novi isti zahtjev za ovaj ciklus.',
            )).strip()
        else:
            reason = row.get('status_razlog', '')
        if delivery_warning and delivery_warning not in reason:
            reason = ' '.join((reason, delivery_warning)).strip()
        row.update(cc_ready=ready, cc_can_edit=je_komisijski_tim(user),
                   cc_status_label='Potrebna provjera' if review else
                       'Treba trebovati' if ready else 'Ne treba trebovati',
                   cc_status_class='amber' if review else 'blue' if ready else 'green',
                   cc_review_reason=reason,
                   cc_delivery_warning=delivery_warning,
                   cc_existing_request=existing_request,
                   cc_status_detail='Novi zahtjev nije potreban' if existing_request and not review else '')
    return rows


def reviewed_items(rows):
    return [{'patient': row['pacijent'].pk, 'medicine': row['lijek'].pk,
             'system': str(row['sistem_predlaze']),
             'quantity': str(row['final_procurement_units']),
             'request_type': row['cc_classification'].legacy_request_type,
             'reason': getattr(row.get('rucni_unos'), 'razlog', '') or ''}
            for row in rows if row['cc_ready']]


def make_review(rows, plan_key, user):
    from patients.commission_demand import commission_demand_v2_enabled
    if not commission_demand_v2_enabled() or not je_komisijski_tim(user):
        return ''
    items = reviewed_items(rows)
    if not items:
        return ''
    return signing.dumps({'operation': uuid4().hex, 'user': user.pk,
        'scope': plan_key, 'items': items, 'fingerprint': planning_fingerprint()},
        salt=SALT, compress=True)


def load_review(token, user):
    try:
        payload = signing.loads(token, salt=SALT, max_age=1800)
    except signing.BadSignature as exc:
        raise ValidationError('Pregled je istekao ili nije ispravan. Osvježite nacrt.') from exc
    if not je_komisijski_tim(user) or payload['user'] != user.pk:
        raise ValidationError('Pregled pripada drugom korisniku komisijskog tima.')
    return payload


def cycle_name(payload):
    return 'KC-' + payload['operation']


def confirmation_post(payload):
    data = QueryDict('', mutable=True)
    data['plan_cycle'] = payload['scope']
    for item in payload['items']:
        pk = item['patient']
        data[f'broj_doza_{pk}'] = item['quantity']
        data[f'vrsta_zahtjeva_{pk}'] = item['request_type']
        data[f'razlog_odstupanja_{pk}'] = item['reason']
    return data


def patient_basis(patient, records=None):
    """Relevant clinical/logistics inputs; exclude document state and audit journals."""
    from patients import models as m
    records = records if records is not None else planning_records()
    patient_models = (m.Terapija, m.Termin, m.Komisija, m.PacijentRezervacija,
        m.PacijentZaduzenje, m.KucnoIzdavanje, m.KucnaTerapijaPodatak, m.PromjenaTerapije,
        m.IndividualniProtokolPacijenta, m.FazniProtokolPacijenta, m.MigracijskiSnapshotPacijenta)
    selected = {}
    for model in patient_models:
        table = model._meta.db_table
        selected[table] = {key: row for key, row in records.get(table, {}).items()
                           if row.get('pacijent_id') == patient.pk}
    table = m.Pacijent._meta.db_table
    selected[table] = {str(patient.pk): records.get(table, {}).get(str(patient.pk))}
    medicine_ids = set(m.Lijek.objects.filter(terapijski_program_id=patient.terapijski_program_id).values_list('pk', flat=True)) if patient.terapijski_program_id else {patient.lijek_id}
    table = m.Lijek._meta.db_table
    selected[table] = {key: row for key,row in records.get(table, {}).items() if int(key) in medicine_ids}
    table = m.Zaliha._meta.db_table
    selected[table] = {key: row for key,row in records.get(table, {}).items() if row.get('lijek_id') in medicine_ids}
    for model in (m.TerapijskiProtokol, m.TerapijskiKorakProtokola, m.IndividualniKorakProtokola):
        table = model._meta.db_table
        if model is m.TerapijskiProtokol:
            rows = {key: row for key,row in records.get(table, {}).items() if row.get('lijek_id') in medicine_ids}
            protocol_ids = {int(key) for key in rows}
        elif model is m.TerapijskiKorakProtokola:
            rows = {key: row for key,row in records.get(table, {}).items() if row.get('protokol_id') in protocol_ids}
        else:
            individual_ids = {int(key) for key in selected[m.IndividualniProtokolPacijenta._meta.db_table]}
            rows = {key: row for key,row in records.get(table, {}).items() if row.get('protokol_id') in individual_ids}
        selected[table] = rows
    selected[m.PostavkeSistema._meta.db_table] = records.get(m.PostavkeSistema._meta.db_table, {})
    return digest(selected)


def phased_document_token(document, user):
    if document.status != 'nacrt' or not je_komisijski_tim(user):
        return ''
    state = document.pokrenuti_fazni_protokoli.filter(aktivan=True, protokol_kljuc='ustekinumab', faza='CEKA_IV_INDUKCIJU').first()
    if not state or not state.indukcijska_doza_mg or not state.indukcijski_broj_jedinica:
        return ''
    return signing.dumps({'user': user.pk, 'document': document.pk, 'state': state.pk,
        'fingerprint': planning_fingerprint()}, salt=SALT+'.phased', compress=True)
