"""Read-only presentation of the native stock calculation and its evidence."""
from decimal import Decimal
from urllib.parse import urlencode

from django.core.paginator import Paginator
from django.db.models import Sum
from django.urls import reverse
from patients import models as m
from patients.inventory import _physical_medicine_ids, free_stock_quantity
from .permissions import je_sestra_ili_admin


ZERO = Decimal(0)
PAGE_SIZE = 40
ISSUES = {
    'availability': ('Dostupna količina zahtijeva provjeru.',
        'Pregledajte izvorne promete i ispravke raspodjele prije nove dodjele.'),
    'physical': ('Promet i fizičko stanje se razlikuju.',
        'Provjerite kontrolno stanje, izvorne promete i stvarno prebrojanu količinu.'),
    'catalogue': ('Kataloški obuhvat zahtijeva provjeru.',
        'Provjerite identitet prezentacija u postojećem obračunu; nemojte spajati različite oblike.'),
    'reservations': ('Rezervacije zahtijevaju provjeru.',
        'Provjerite aktivna zaduženja i njihovo fizičko pokriće.'),
}


def signed(value):
    value = Decimal(value)
    text = format(abs(value), 'f')
    if '.' in text:
        text = text.rstrip('0').rstrip('.')
    return ('+' if value > 0 else '−' if value < 0 else '') + text


def page_url(request, key, number):
    params = request.GET.copy()
    params[key] = number
    return request.path + '?' + params.urlencode()


def page_info(request, query, key):
    page = Paginator(query, PAGE_SIZE).get_page(request.GET.get(key))
    return page, dict(number=page.number, pages=page.paginator.num_pages, count=page.paginator.count,
        previous=page_url(request, key, page.previous_page_number()) if page.has_previous() else '',
        next=page_url(request, key, page.next_page_number()) if page.has_next() else '')


def presentation_key(medicine):
    """Do not infer a missing route or strength from another catalogue record."""
    return (medicine.genericki_naziv.strip().casefold(), medicine.put_primjene,
        medicine.jacina_mg, medicine.strength.strip().casefold(), medicine.pharmaceutical_form.strip().casefold(),
        medicine.farmaceutski_oblik, medicine.jedinice_zalihe)


def context(explanation, request):
    medicine, position = explanation['medicine'], explanation['position']
    ids = _physical_medicine_ids(medicine)
    medicines = list(m.Lijek.objects.filter(pk__in=ids).order_by('pk'))
    initials = {x.lijek_id: x for x in m.MigracijskoPocetnoStanjeZalihe.objects.filter(
        lijek_id__in=ids).select_related('kreirao', 'izmijenio')}
    physical = dict(m.Zaliha.objects.filter(lijek_id__in=ids).values('lijek_id')
        .annotate(total=Sum('u_frizideru')).values_list('lijek_id', 'total'))
    catalogue = {}
    for med in medicines:
        key = presentation_key(med)
        known = bool(med.put_primjene and (med.jacina_mg is not None or med.strength))
        group = catalogue.setdefault(key if known else ('unknown', med.pk),
            dict(label=str(med), route=med.put_primjene or 'Nije evidentiran',
                strength=med.strength or (f'{med.jacina_mg:g} mg' if med.jacina_mg is not None else 'Nije evidentirana'),
                form=med.pharmaceutical_form or med.get_farmaceutski_oblik_display() or 'Nije evidentiran',
                unit=med.jedinice_zalihe[1], known=known, records=[]))
        initial = initials.get(med.pk)
        group['records'].append(dict(id=med.pk, name=med.naziv, physical=physical.get(med.pk, ZERO),
            initial=initial.kolicina if initial else ZERO, checkpoint=initial.ledger_checkpoint_id if initial else None,
            recorded=initial.kreirano if initial else None,
            user=initial.kreirao if initial else None))
    known_keys = {presentation_key(x) for x in medicines if x.put_primjene and (x.jacina_mg is not None or x.strength)}
    catalogue_review = len(known_keys) > 1 or any(not x['known'] for x in catalogue.values())
    initial_total = sum((x.kolicina for x in initials.values()), ZERO)
    summary = [dict(label='Početno / kontrolno stanje', amount=initial_total, signed=signed(initial_total))]
    summary += [dict(label=x['label'], amount=x['delta'], signed=signed(x['delta']))
        for x in explanation['movement_groups'] if x['delta'] != 0]
    summary_matches = sum((x['amount'] for x in summary), ZERO) == explanation['ledger']

    restriction_query = m.ZalihaTransakcija.objects.filter(lijek_id__in=ids,
        korekcija__scope='inventory_allocation').select_related('korekcija__korisnik',
        'izvorna_transakcija', 'lijek').order_by('datum', 'pk')
    reservation_net = restriction_query.aggregate(total=Sum('promjena_rezervacije'))['total'] or ZERO
    proven_restricted = max(ZERO, -reservation_net)
    restriction_page, restriction_paging = page_info(request, restriction_query, 'restriction_page')
    restrictions = [dict(id=x.pk, receipt=x.korekcija_id, date=x.datum, recorded=x.korekcija.kreirano,
        medicine=str(x.lijek), signed=signed(-x.promjena_rezervacije), unit=x.lijek.jedinica_zalihe_za_kolicinu(abs(x.promjena_rezervacije)), reason=x.korekcija.razlog,
        original=x.izvorna_transakcija_id, user=x.korekcija.korisnik,
        url=reverse('inventory_correction_receipt', args=[x.korekcija_id]))
        for x in restriction_page.object_list]

    reservation_query = m.PacijentRezervacija.objects.filter(lijek_id__in=ids, aktivno=True,
        kolicina__gt=0).select_related('pacijent', 'lijek', 'termin').order_by('pacijent__prezime', 'pacijent__ime', 'pk')
    reservation_total = reservation_query.aggregate(total=Sum('kolicina'))['total'] or ZERO
    reservation_page, reservation_paging = page_info(request, reservation_query, 'reservation_page')
    reservations = [dict(id=x.pk, patient=str(x.pacijent), quantity=x.kolicina, medicine=str(x.lijek),
        patient_url=reverse('profil_pacijenta', args=[x.pacijent_id]), appointment=x.termin,
        status='Aktivna rezervacija', note=x.napomena) for x in reservation_page.object_list]

    movement_query = m.ZalihaTransakcija.objects.filter(lijek_id__in=ids).select_related(
        'lijek', 'pacijent', 'korisnik', 'korekcija__korisnik').order_by('datum', 'pk')
    history_page, history_paging = page_info(request, movement_query, 'history_page')
    movement_rows = list(history_page.object_list)
    audited_users = {}
    for audit in m.AktivnostLog.objects.filter(objekat_tip='ZalihaTransakcija',
            objekat_id__in=[str(x.pk) for x in movement_rows], korisnik__isnull=False
            ).select_related('korisnik').order_by('datum_vrijeme', 'pk'):
        audited_users.setdefault(str(audit.objekat_id), audit)
    history = []
    for x in movement_rows:
        initial = initials.get(x.lijek_id)
        audit = audited_users.get(str(x.pk))
        history.append(dict(id=x.pk, date=x.datum, recorded=x.kreirano, type=x.get_tip_display(),
            signed=signed(x.frizider_delta()), medicine=str(x.lijek), catalogue_id=x.lijek_id,
            included=x.pk > (initial.ledger_checkpoint_id or 0) if initial else True,
            source=f'{x.referenca_tip} #{x.referenca_id}' if x.referenca_tip and x.referenca_id else 'Izvor nije evidentiran',
            patient=x.pacijent, patient_url=reverse('patient_timeline', args=[x.pacijent_id]) if x.pacijent_id else '',
            user=x.korisnik or (x.korekcija.korisnik if x.korekcija_id else audit.korisnik if audit else None),
            user_source='Promet' if x.korisnik_id else 'Ispravka' if x.korekcija_id else
                f'Audit #{audit.pk}: {audit.akcija}' if audit else '',
            receipt_url=reverse('inventory_correction_receipt', args=[x.korekcija_id]) if x.korekcija_id else '',
            original=x.izvorna_transakcija_id, note=x.napomena))

    unreserved = position['in_fridge'] - position['reserved_in_fridge']
    native_free = free_stock_quantity(medicine)
    availability_verified = (proven_restricted == position['restricted_after_correction']
        and position['freely_available'] == max(ZERO, unreserved - proven_restricted)
        and position['freely_available'] == native_free)
    reservations_verified = reservation_total == position['reserved_in_fridge']
    issues = []
    if not availability_verified: issues.append('availability')
    if not explanation['ledger_matches'] or not summary_matches: issues.append('physical')
    if not reservations_verified or position['physical_reservation_shortfall']: issues.append('reservations')
    if catalogue_review: issues.append('catalogue')
    issue = issues[0] if issues else ''
    params = dict(cc_medicine=medicine.pk, section='corrections', balance_issue=issue)
    if explanation['patient']: params['cc_patient'] = explanation['patient'].pk
    return dict(unit=medicine.jedinice_zalihe[1], reservation_unit=medicine.jedinica_zalihe_za_kolicinu(reservation_total), summary=summary, summary_matches=summary_matches,
        unreserved=unreserved, availability_verified=availability_verified, proven_restricted=proven_restricted,
        restrictions=restrictions, restriction_paging=restriction_paging, restriction_count=restriction_query.count(),
        reservations=reservations, reservation_paging=reservation_paging, reservation_total=reservation_total,
        reservations_verified=reservations_verified, history=history, history_paging=history_paging,
        catalogue=list(catalogue.values()), catalogue_review=catalogue_review,
        issues=[dict(code=x, title=ISSUES[x][0], help=ISSUES[x][1]) for x in issues],
        correction_url=reverse('correction_center')+'?'+urlencode(params) if issue and je_sestra_ili_admin(request.user) else '',
        review_url=reverse('medicine_corrections', args=[medicine.pk]),
        confirmed=not issues, source_count=len(ids))
