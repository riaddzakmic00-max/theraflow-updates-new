"""Read-only cycle scopes for commission screens; no quantity calculations."""
from django.core.exceptions import ValidationError
from django.db.models import Count, F
from django.http import Http404
from django.shortcuts import redirect
from django.urls import reverse

from patients.commission_exclusions import planning_commission_date, visible_commission_requests
from patients.models import KomisijskiCiklus, Trebovanje


def approval_redirect(request):
    key = request.POST.get('cycle')
    if key == 'unassigned' or (key and key.isdigit() and KomisijskiCiklus.objects.filter(
            pk=int(key), tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI).exists()):
        return redirect(f"{reverse('komisijsko_odobrenje')}?cycle={key}")
    return redirect('komisijsko_odobrenje')


def plan_key(row):
    day = planning_commission_date(row)
    return day.isoformat() if day else "unassigned"


def planning_scope(rows, overview, requested=None):
    """Plans are dated windows; persisted requests remain scoped by cycle ID.

    Several historical/simulation records may have the same date. A plan is
    not relabelled as one of those records and selecting it does not edit them.
    """
    options = {}
    for row in rows:
        key = plan_key(row)
        window = row.get("planirati_za_komisiju") or row.get("preporuceni_komisijski_ciklus")
        option = options.setdefault(key, {
            "key": key, "date": planning_commission_date(row),
            "deadline": getattr(window, "rok_pripreme", None), "patients": 0,
        })
        option["patients"] += 1
    next_day = overview.get("next_date")
    if next_day:
        key = next_day.isoformat()
        options.setdefault(key, {"key": key, "date": next_day,
                                "deadline": overview.get("next_preparation_deadline"), "patients": 0})
        if not options[key]["deadline"]:
            options[key]["deadline"] = overview.get("next_preparation_deadline")
    if not options:
        options["unassigned"] = {"key": "unassigned", "date": None, "deadline": None, "patients": 0}
    # Prefer the administrative next window when it has patients. If it is
    # empty, open a populated canonical window instead of an empty screen.
    preferred = next_day.isoformat() if next_day else None
    populated = next((key for key, option in options.items() if option['patients']), None)
    default = preferred if preferred and options[preferred]['patients'] else populated or preferred or next(iter(options))
    key = requested or default
    if key not in options:
        raise Http404("Odabrani planski ciklus nije dostupan. Vratite se u planiranje.")
    selected_rows = [row for row in rows if plan_key(row) == key]
    selected = dict(options[key])
    selected["status"] = "Potrebna provjera" if key == "unassigned" else "Planski prijedlog"
    return {"selected_plan": selected,
            "plan_options": sorted(options.values(), key=lambda item: item['key']),
            "scoped_rows": selected_rows,
            "unassigned_count": sum(plan_key(row) == 'unassigned' for row in rows)}


def stored_cycle_choices():
    cycles = list(KomisijskiCiklus.objects.filter(tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI)
                  .annotate(request_count=Count('trebovanja', distinct=True),
                            document_request_count=Count('zahtjevi_faza1', distinct=True))
                  .order_by(F('datum_komisije').desc(nulls_last=True), '-pk'))
    for cycle in cycles:
        # Explicit logistical status, not a guessed status based on its date.
        cycle.display_status = cycle.get_status_display()
    return cycles


def selected_approval_cycle(cycles, requested, requests):
    if requested == 'unassigned':
        return None
    if requested:
        for cycle in cycles:
            if str(cycle.pk) == requested:
                return cycle
        raise Http404("Odabrani komisijski ciklus nije pronađen.")
    ready_ids = set(requests.filter(status='U_PRIPREMI').values_list('komisijski_ciklus_id', flat=True))
    return next((cycle for cycle in cycles if cycle.pk in ready_ids),
                None if None in ready_ids else cycles[0] if cycles else None)


def cycle_process_step(cycle):
    status = cycle.status if cycle else ''
    if status in {'DJELOMICNO_ZAPRIMLJENO', 'ZAPRIMLJENO'}:
        return 5
    if status in {'ZAVRSENO', 'zavrseno'}:
        return 6
    if status in {'ODOBRENO', 'CEKA_ISPORUKU'}:
        return 4
    return 3  # The document/decision stage, including submitted applications.


def validated_batch(ids, selected_cycle=None, *, for_send=False):
    """Reject the whole selection instead of silently dropping foreign rows.

    Older clients may omit cycle; they still must submit exactly one scope.
    Legacy unassigned requests remain a separate, explicit scope.
    """
    try:
        requested_ids = {int(value) for value in ids}
    except (TypeError, ValueError) as exc:
        raise ValidationError("Izbor zahtjeva nije ispravan. Ponovo otvorite odabrani ciklus.") from exc
    if not requested_ids:
        raise ValidationError("Niste označili nijedan zahtjev.")
    queryset = Trebovanje.objects.filter(pk__in=requested_ids, tip_zahtjeva=Trebovanje.TIP_REDOVNI)
    rows = list(queryset.select_for_update().order_by('pk'))
    if {row.pk for row in rows} != requested_ids:
        raise ValidationError("Dio odabranih zahtjeva više nije dostupan u redovnom ciklusu. Osvježite stranicu.")
    scopes = {row.komisijski_ciklus_id for row in rows}
    if len(scopes) != 1:
        raise ValidationError("Odabrani zahtjevi pripadaju različitim ciklusima. Štampajte ili šaljite jedan ciklus odjednom.")
    scope = next(iter(scopes))
    if selected_cycle is not None and selected_cycle != (str(scope) if scope is not None else 'unassigned'):
        raise ValidationError("Izbor ne pripada prikazanom ciklusu. Osvježite stranicu i ponovo označite zahtjeve.")
    if set(visible_commission_requests(queryset).values_list('pk', flat=True)) != requested_ids:
        raise ValidationError("Pacijent je u međuvremenu ručno isključen iz trebovanja. Osvježite izbor.")
    if for_send and any(row.status != 'U_PRIPREMI' for row in rows):
        raise ValidationError("Dio zahtjeva više nije u pripremi. Slanje nije izvršeno; osvježite ciklus.")
    return queryset
