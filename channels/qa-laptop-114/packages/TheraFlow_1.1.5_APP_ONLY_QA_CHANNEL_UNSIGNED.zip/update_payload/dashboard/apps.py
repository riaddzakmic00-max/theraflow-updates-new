from django.apps import AppConfig


class DashboardConfig(AppConfig):
    name = 'dashboard'

    def ready(self):
        from .pdf_template_checks import log_startup_pdf_templates
        log_startup_pdf_templates()
