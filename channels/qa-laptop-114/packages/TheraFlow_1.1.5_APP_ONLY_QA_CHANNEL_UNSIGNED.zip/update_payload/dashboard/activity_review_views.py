"""GET-only review screens. All actions link back to existing workflows."""
from datetime import date, timedelta
from urllib.parse import urlencode

from django import forms
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, render
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET

from patients import activity_review as review, models as m
from .permissions import je_admin, je_terapijski_tim, je_sestra_ili_admin


class PeriodForm(forms.Form):
    start = forms.DateField(label='Datum OD', widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
    end = forms.DateField(label='Datum DO', widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))

    def clean(self):
        data = super().clean()
        if data.get('start') and data.get('end') and data['start'] > data['end']:
            raise forms.ValidationError('Datum OD mora biti prije ili jednak datumu DO.')
        return data


def _access(request):
    if not request.user.is_active or not je_terapijski_tim(request.user):
        raise PermissionDenied('Pregled je dostupan terapijskom timu.')
    return je_admin(request.user)


@login_required
@never_cache
@require_GET
def patient_timeline(request, patient_id):
    admin = _access(request)
    patient = get_object_or_404(m.Pacijent, pk=patient_id)
    fragment = request.GET.get('fragment') == '1'
    form = PeriodForm(request.GET if 'start' in request.GET or 'end' in request.GET else None)
    context = dict(patient=patient, form=form, admin=admin, fragment=fragment)
    if not form.is_bound or form.is_valid():
        dates = form.cleaned_data if form.is_bound else {}
        with review.read_projection():
            context.update(review.patient_timeline(patient_id, limit=20 if fragment else 200, **dates))
            for item in context['items']:
                session = item.get('session')
                if session and admin and session.user_id == request.user.pk:
                    item['links'].append(('Otvori usklađivanje', review.session_url(session)))
                if item.get('late_id') and admin:
                    item['links'].append(('Otvori povezani audit', reverse('retrospective_detail', args=[item['late_id']])))
    if fragment:
        # Fragments need no global sidebar/commission context processors.
        return HttpResponse(render_to_string('dashboard/_activity_timeline.html', context))
    return render(request, 'dashboard/activity_timeline.html', context)


@login_required
@never_cache
@require_GET
def business_review(request, mode='attention'):
    admin = _access(request)
    today = timezone.localdate()
    default_start = date.min if mode == 'attention' else today if mode == 'today' else today - timedelta(days=29)
    form = PeriodForm(request.GET if 'start' in request.GET or 'end' in request.GET else None,
                      initial={'start': default_start, 'end': today})
    context = dict(mode=mode, form=form, admin=admin, smart_allowed=je_sestra_ili_admin(request.user), fragment=request.GET.get('fragment') == '1')
    if not form.is_bound or form.is_valid():
        start, end = (form.cleaned_data['start'], form.cleaned_data['end']) if form.is_bound else (default_start, today)
        if mode == 'today': start = end = today
        with review.read_projection():
            context.update(review.attention_items(start, end, admin=admin, user=request.user, include_open_sessions=mode != 'period'))
            if mode == 'attention' and not context['fragment']:
                from .attention_presentation import grouped_attention
                context['attention_groups'] = grouped_attention(context['items'], guided_allowed=context['smart_allowed'], admin=admin)
            context['summary'] = review.today_summary(today) if mode == 'today' else review.period_summary(start, end) if mode == 'period' else []
        if context['fragment']:
            context['more_count'] = max(0, len(context['items']) - 5)
            context['items'] = context['items'][:5]
        context.update(start=start, end=end)
        context['smart_url'] = reverse('correction_center') + '?' + urlencode(dict(section='smart', start=start.isoformat(), end=end.isoformat()))
    if context['fragment']:
        return HttpResponse(render_to_string('dashboard/_activity_attention.html', context))
    if mode == 'attention':
        context['sidebar_active_section'] = 'retrospective'
        return render(request, 'dashboard/attention_center.html', context)
    return render(request, 'dashboard/activity_review.html', context)
