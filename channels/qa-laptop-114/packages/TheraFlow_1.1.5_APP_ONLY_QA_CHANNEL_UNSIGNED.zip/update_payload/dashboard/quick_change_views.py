import logging
from decimal import Decimal
from django import forms
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import DatabaseError
from django.shortcuts import get_object_or_404, render
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods
from django.utils import timezone

from patients.models import Pacijent
from patients.correction_protocol import contention_message
from patients.quick_changes import (authorize, current_regimen, transfer_sources, medicine_mg,
    make_preview, confirm, confirmation_payload, confirmation_status, preview)

from .correction_center_views import render_in_center as render

logger = logging.getLogger(__name__)
LABELS = {"interval": "Promijeni interval", "dose": "Promijeni dozu", "transfer": "Prebaci zaduženje"}


class QuickChangeForm(forms.Form):
    def __init__(self, *args, patient, kind, protocol_step=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.blocked = ""
        self.current_interval = None
        current = {}
        medicine = patient.lijek
        try:
            if not medicine:
                raise ValidationError("Pacijent nema odabranu prezentaciju lijeka.")
            if kind == "transfer":
                sources = list(transfer_sources(patient))
                self.fields["rezervacija"] = forms.TypedChoiceField(label="Dostupna količina u ambulanti", coerce=int,
                    choices=[(s.pk, f"{s.kolicina:g} {medicine.jedinica_za_kolicinu(s.kolicina)} — rezervacija #{s.pk}" +
                        (f" · komisija #{s.komisija_id}" if s.komisija_id else "")) for s in sources])
                recipients = Pacijent.objects.filter(lijek=medicine, aktivan=True).exclude(pk=patient.pk).order_by("prezime", "ime")
                self.fields["primalac"] = forms.TypedChoiceField(label="Pacijent koji prima lijek", coerce=int,
                    choices=[("", "Odaberite pacijenta")] + [(p.pk, str(p)) for p in recipients])
                from patients.models import Komisija
                self.fields['komisija_primaoca'] = forms.TypedChoiceField(label='Odobrenje primaoca (ako ih ima više)',
                    coerce=int, required=False, empty_value='',
                    choices=[('', 'Automatski samo ako je jednoznačno')] +
                    [(a.pk, f'{a.pacijent} · #{a.pk} · {a.broj_saglasnosti} · preostalo {a.preostale_doze}')
                     for a in Komisija.objects.filter(pacijent__in=recipients, lijek=medicine,
                        status__in=Komisija.VAZECI_STATUSI).select_related('pacijent')])
                self.fields["kolicina"] = forms.DecimalField(label=f"Količina za prijenos ({medicine.jedinica_za_kolicinu(2)})",
                    min_value=1, max_digits=10, decimal_places=0)
                if not sources:
                    self.blocked = "Nema neiskorištene fizičke rezervacije u ambulanti. Lijek izdat kući i već primijenjene količine ne prenose se ovom radnjom."
            else:
                current = current_regimen(patient, protocol_step=protocol_step)
                if kind == "interval":
                    oral = medicine.oralna_terapija
                    key = "uzimanja_dnevno" if oral else "interval_sedmica"
                    self.current_interval = f"{current[key]} {'puta dnevno' if oral else 'sedmica'}"
                    self.fields[key] = forms.IntegerField(label="Novi broj uzimanja dnevno" if oral else "Novi interval (sedmice)",
                        min_value=1, max_value=12 if oral else 52, initial=current[key],
                        help_text="" if oral else "Jedna sedmica je 7 dana.")
                else:
                    self.fields["doza_mg"] = forms.DecimalField(label="Nova propisana doza po primjeni/uzimanju (mg)",
                        min_value=Decimal("0.01"), max_digits=10, decimal_places=2, initial=current.get("doza_mg"),
                        help_text=f"Trenutno propisano: {current.get('doza_mg') or 'nije evidentirano'} mg.")
                    if not medicine_mg(medicine):
                        self.fields["broj_jedinica"] = forms.DecimalField(label=f"Fizička količina po primjeni ({medicine.jedinica_za_kolicinu(2)})",
                            min_value=1, max_digits=10, decimal_places=0, initial=current["broj_jedinica"],
                            help_text="Jačina za automatski preračun nije evidentirana. Unesite fizičku količinu iz naloga ljekara.")
                self.fields["vrijedi_od"] = forms.DateField(label="Od kada vrijedi novi nalog", initial=timezone.localdate,
                    widget=forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"))
        except ValidationError as exc:
            self.blocked = " ".join(exc.messages)
        if protocol_step:
            self.fields['protocol_step'] = forms.ChoiceField(choices=[('maintenance','SC održavanje')],
                initial=protocol_step, widget=forms.HiddenInput)
            if kind == 'interval' and not self.blocked:
                self.fields['interval_sedmica'] = forms.TypedChoiceField(label='Novi interval SC održavanja (sedmice)',
                    coerce=int, choices=[(8,'8 sedmica'),(12,'12 sedmica')], initial=current['interval_sedmica'])
        self.fields["razlog"] = forms.CharField(label="Kratak razlog prijenosa" if kind == "transfer" else "Nalog ljekara / razlog promjene",
            min_length=3, max_length=500, widget=forms.Textarea(attrs={"rows": 2}))


@login_required
@never_cache
@require_http_methods(["GET", "POST"])
def quick_change(request, pacijent_id, kind):
    authorize(request.user)
    if kind == 'transfer':
        from .permissions import authorize_transfer as administrator
        administrator(request.user)
    if kind not in LABELS:
        from django.http import Http404
        raise Http404
    patient = get_object_or_404(Pacijent.objects.select_related("lijek"), pk=pacijent_id)
    action = request.POST.get('action') if request.method == 'POST' else 'open'
    submitted = request.POST if action == 'preview' else None
    payload = None
    if action in ('confirm', 'status'):
        try:
            payload = confirmation_payload(request.POST.get('token', ''), patient, request.user, max_age=None, kind=kind)
            submitted = payload['data']
        except ValidationError as exc:
            return JsonResponse({'error': ' '.join(exc.messages)}, status=400)
    protocol_step = (submitted or {}).get('protocol_step') or request.GET.get('protocol_step')
    form = QuickChangeForm(submitted,
        patient=patient, kind=kind, protocol_step=protocol_step, initial={'rezervacija': request.GET.get('rezervacija')})
    from .patient_action_views import protocol_navigation
    phase_navigation = protocol_navigation(patient, kind) if not protocol_step else None
    previous_change=request.GET.get('previous_change')
    if previous_change and kind in ('interval','dose'):
        from patients.models import BrzaIzmjenaPacijenta
        previous=get_object_or_404(BrzaIzmjenaPacijenta,pk=previous_change,pacijent=patient,vrsta=kind)
        old=previous.prije.get('regimen') or {}
        form.initial.update({key:value for key,value in old.items() if key in form.fields})
    plan = token = receipt = None
    response_status = 200
    state = None
    if request.method == "POST":
        try:
            if action == 'status':
                receipt, payload = confirmation_status(request.POST['token'], patient, request.user, kind=kind)
                state = 'saved' if receipt else 'not_saved'
                if not receipt:
                    confirmation_payload(request.POST['token'], patient, request.user, kind=kind)
                    plan = preview(patient, kind, payload['data'], request.user)
                    if plan['fingerprint'] != payload['fingerprint']:
                        raise ValidationError('Podaci su se promijenili. Provjerite sačuvane unose i ponovo prikažite promjenu.')
                    token = request.POST['token']
            elif action == "confirm":
                receipt, _created = confirm(request.POST.get("token", ""), patient, request.user)
            elif action == 'preview' and not form.blocked and form.is_valid():
                data = {k: str(v) for k,v in form.cleaned_data.items()}
                if previous_change:data['previous_change']=int(previous_change)
                plan, token = make_preview(patient, kind, data, request.user)
        except (ValidationError, ValueError) as exc:
            plan = token = None
            response_status = 422
            state = 'review_required'
            form.add_error(None, " ".join(exc.messages) if isinstance(exc, ValidationError) else str(exc))
        except DatabaseError as exc:
            logger.exception("Quick action was not confirmed; patient_id=%s", patient.pk)
            return JsonResponse({'error': contention_message(exc) or 'Podaci su trenutno zauzeti. Pokušajte ponovo.'}, status=503)
    template = "dashboard/_quick_change_form.html" if request.headers.get("X-Requested-With") == "TheraFlowQuickChange" else "dashboard/quick_change.html"
    context = {"pacijent": patient, "kind": kind, "title": LABELS[kind],
        "form": form, "preview": plan, "token": token, "receipt": receipt,
        "phase_navigation": phase_navigation, "protocol_step": protocol_step,
        "presentation_mg": medicine_mg(patient.lijek) if patient.lijek else None}
    if action == 'status':
        return JsonResponse({'state': state, 'html': render_to_string('dashboard/_quick_change_form.html',context,request)}, status=response_status)
    response = render(request, template, context, status=response_status)
    response['X-TheraFlow-Quick-Result'] = 'saved' if receipt else 'review'
    return response
