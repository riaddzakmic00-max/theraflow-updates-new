from django import forms
from django.utils import timezone
from django.db.models import Model
from patients import models as m
from patients.medicine_registry import patient_product_for_selection
from patients.retrospective_events import matching_appointments


class NamedChoice(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        if isinstance(obj, m.Trebovanje):
            return f'#{obj.pk} · {obj.komisijski_ciklus} · {obj.pacijent} · {obj.lijek} · primljeno {obj.zaprimljene_doze:g}/{obj.odobrene_doze}'
        if isinstance(obj, m.Komisija):
            return f'#{obj.pk} · {obj.pacijent} · {obj.lijek} · {obj.broj_saglasnosti} · preostalo {obj.preostale_doze:g}'
        if isinstance(obj, m.Termin):
            return f'#{obj.pk} · {obj.datum:%d.%m.%Y.} u {obj.vrijeme:%H:%M} · {obj.lijek}'
        if isinstance(obj, m.PhysicalStockCorrection):
            return f'#{obj.pk} · {obj.lijek} · {obj.pregled.get("event_date", "")} · razlika {obj.razlika:g} · {obj.razlog}'
        if isinstance(obj, m.EvidencijaSaglasnostiZaprimanja):
            return f'#{obj.pk} · {obj.pacijent} · {obj.trebovanje.lijek} · prijem #{obj.fizicka_transakcija_id}'
        return str(obj)


class EventForm(forms.Form):
    kind = forms.ChoiceField(choices=m.RetrospectiveEvent.KINDS, widget=forms.HiddenInput)
    patient_id = NamedChoice(label='Pacijent', queryset=m.Pacijent.objects.none())
    medicine_id = NamedChoice(label='Lijek', queryset=m.Lijek.objects.all().order_by('naziv'))
    event_date = forms.DateField(label='Stvarni datum događaja', initial=timezone.localdate,
                                widget=forms.DateInput(attrs={'type':'date'}, format='%Y-%m-%d'))
    quantity = forms.DecimalField(label='Količina (pojedinačne jedinice lijeka)', max_digits=8, decimal_places=2, min_value=0.01)
    dose_mg = forms.DecimalField(label='Primijenjena doza u mg (ako je primjenjivo)', required=False, min_value=0.01)
    appointment_id = NamedChoice(label='Postojeći nepotvrđeni termin', required=False, queryset=m.Termin.objects.none(),
        empty_label='Nema odgovarajućeg termina',
        help_text='Samo nepotvrđeni termini za stvarni datum događaja i proizvod važeći tada. Budući termini ostaju sačuvani.')
    commission_id = NamedChoice(label='Odobrenje pacijenta', required=False, queryset=m.Komisija.objects.none())
    cycle_id = NamedChoice(label='Komisijski ciklus', required=False, queryset=m.KomisijskiCiklus.objects.none())
    request_id = NamedChoice(label='Konkretna odobrena stavka', required=False, queryset=m.Trebovanje.objects.none())
    delivery_reference = forms.CharField(label='Broj otpremnice ili oznaka zasebne isporuke', max_length=120, required=False)
    batch = forms.CharField(label='Serija', max_length=100, required=False)
    expires = forms.DateField(label='Rok trajanja', required=False, widget=forms.DateInput(attrs={'type':'date'},format='%Y-%m-%d'))
    separate_event = forms.BooleanField(label='Ovo je druga stvarna predaja, različita od ranije evidentirane', required=False)
    note = forms.CharField(label='Razlog i izvor naknadnog unosa', min_length=5, max_length=2000,
        widget=forms.Textarea(attrs={'rows':3}))
    history_confirmed = forms.BooleanField(required=False,
        label='Provjerio/la sam predloženu historijsku terapiju i protokol prema izvornom nalogu',
        help_text='Ako se terapija mijenjala, navedite izvor provjere u napomeni. Današnja terapija nije dokaz ranije doze.')

    def __init__(self, *args, kind, patient_context=None, medicine_context=None, **kwargs):
        super().__init__(*args, **kwargs)
        if patient_context:
            self.initial['patient_id'] = patient_context.pk
            self.initial.setdefault('medicine_id', medicine_context.pk if medicine_context else patient_context.lijek_id)
            self.fields['patient_id'].disabled = True
        self.fields['kind'].initial = kind
        selected = ({key:self.data.get(self.add_prefix(key)) for key in self.fields}
                    if self.is_bound else self.initial)
        patient_id = patient_context.pk if patient_context else selected.get('patient_id')
        patient_id = patient_id if str(patient_id or '').isdigit() else None
        self.fields['patient_id'].queryset = m.Pacijent.objects.filter(lijek__isnull=False).order_by('prezime','ime')
        if kind == 'therapy':
            medicine_id = selected.get('medicine_id')
            medicine_id = medicine_id if str(medicine_id or '').isdigit() else None
            patient = m.Pacijent.objects.filter(pk=patient_id).select_related('lijek').first()
            product = m.Lijek.objects.filter(pk=medicine_id).first()
            date_field = self.fields['event_date']
            raw_date = selected.get('event_date') if self.is_bound else self.get_initial_for_field(date_field, 'event_date')
            try:
                event_date = date_field.clean(raw_date)
            except forms.ValidationError:
                event_date = None
            from patients.retrospective_history import product_at
            try:
                current = product_at(patient, product, event_date) if patient and event_date else None
            except ValueError:
                current = None
            appointments = matching_appointments(patient, current, event_date)
            self.fields['appointment_id'].queryset = appointments
            count = appointments.count()
            if count:
                self.fields['appointment_id'].empty_label = (
                    'Automatski poveži jedini termin za ovaj datum' if count == 1
                    else 'Odaberite termin za ovaj datum')
        self.fields['commission_id'].queryset = m.Komisija.objects.filter(pacijent_id=patient_id).select_related('pacijent','lijek').order_by('-datum_odobrenja')
        self.fields['cycle_id'].queryset = m.KomisijskiCiklus.objects.filter(status__in=['ODOBRENO','CEKA_ISPORUKU','DJELOMICNO_ZAPRIMLJENO'])
        self.fields['request_id'].queryset = m.Trebovanje.objects.filter(komisijski_ciklus__isnull=False,komisija__isnull=False,
            status__in=['ODOBRENO','CEKA_ISPORUKU']).select_related('komisijski_ciklus','pacijent','lijek')
        if patient_context:
            self.fields['request_id'].queryset = self.fields['request_id'].queryset.filter(pacijent=patient_context)
            self.fields['cycle_id'].queryset = self.fields['cycle_id'].queryset.filter(trebovanja__pacijent=patient_context).distinct()
        remove = {'therapy':['commission_id','cycle_id','request_id','delivery_reference','separate_event'],
                  'home':['dose_mg','appointment_id','cycle_id','request_id','delivery_reference'],
                  'receipt':['patient_id','dose_mg','appointment_id','commission_id','batch','expires','separate_event']}[kind]
        for key in remove:self.fields.pop(key)
        for key in ('commission_id','cycle_id','request_id','delivery_reference'):
            if key in self.fields:self.fields[key].required = True
        self.fields['event_date'].widget.attrs['max'] = str(timezone.localdate())

    def event_data(self):
        return {key:(value.pk if isinstance(value, Model) else value) for key,value in self.cleaned_data.items()}


class LotForm(forms.Form):
    quantity = forms.DecimalField(label='Količina', max_digits=8, decimal_places=2, min_value=0.01)
    batch = forms.CharField(label='Serija', max_length=100, required=False)
    expires = forms.DateField(label='Rok trajanja', required=False, widget=forms.DateInput(attrs={'type':'date'},format='%Y-%m-%d'))


class BaseLotFormSet(forms.BaseFormSet):
    def add_fields(self, form, index):
        super().add_fields(form,index)
        form.fields['DELETE'].label='Ukloni ovu seriju'


LotFormSet = forms.formset_factory(LotForm, formset=BaseLotFormSet, extra=1, max_num=20,
    validate_max=True, min_num=1, validate_min=True, can_delete=True)
