import logging

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import DatabaseError
from django.http import HttpResponseForbidden
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.http import require_http_methods

from patients.models import PhysicalStockCorrection
from patients.correction_protocol import contention_message
from patients.physical_stock_corrections import (
    CorrectionBlocked, apply_signed_correction, make_preview_token, stock_summary,
)
from .permissions import je_admin
from .stock_correction_forms import PhysicalStockCorrectionForm, StockMedicineForm

from .correction_center_views import render_in_center as render

logger = logging.getLogger(__name__)


@login_required
@require_http_methods(["GET", "POST"])
def correct_physical_stock(request):
    if not request.user.is_active or not je_admin(request.user):
        from .permissions import administrative_denial
        return administrative_denial(request)
    selector = StockMedicineForm(request.GET if request.GET.get("lijek") else None)
    medicine = selector.cleaned_data["lijek"] if selector.is_bound and selector.is_valid() else None
    form = PhysicalStockCorrectionForm(
        request.POST if request.method == "POST" and request.POST.get("action") != "confirm" else None,
        initial={"lijek": medicine, 'obuhvat': request.GET.get('obuhvat', 'TOTAL'),
                 'serija': request.GET.get('serija', ''), 'rok_trajanja': request.GET.get('rok', '')},
    )
    previous_count = request.GET.get('previous_count')
    previous = None
    if previous_count:
        from django.shortcuts import get_object_or_404
        previous=get_object_or_404(PhysicalStockCorrection,pk=previous_count,lijek=medicine)
        form.initial.update(kolicina=previous.prethodna_kolicina,obuhvat=previous.pregled.get('scope','TOTAL'),
            serija=previous.pregled.get('batch',''),rok_trajanja=previous.pregled.get('expires') or None,
            datum_dogadjaja=previous.pregled.get('event_date'))
    plan = token = None
    if request.method == "POST":
        try:
            if request.POST.get("action") == "confirm":
                if request.POST.get("confirmed") != "yes":
                    raise CorrectionBlocked("Potvrdite da ste pregledali lijek, količine i razlog korekcije.")
                if request.POST.get('causes_reviewed') != 'yes':
                    raise CorrectionBlocked('Najprije provjerite moguće uzroke i potvrdite da razliku nije moguće objasniti stvarnim događajem.')
                receipt, created = apply_signed_correction(request.POST.get("preview_token", ""), request.user)
                messages.success(request, f"Fizička zaliha je ispravljena. Evidencija #{receipt.pk}." if created else
                                 f"Ova ispravka je već spremljena (#{receipt.pk}); nije ponovljena.")
                for warning in receipt.pregled.get("warnings", []):
                    messages.warning(request, warning)
                return redirect(reverse("ispravi_fizicku_zalihu") + f"?lijek={receipt.lijek_id}")
            if request.POST.get("action") == "preview":
                valid = form.is_valid()
                medicine = form.cleaned_data.get("lijek", medicine)
                if valid:
                    if previous:form.cleaned_data['previous_correction_id']=previous.pk
                    plan, token = make_preview_token(form, request.user)
        except CorrectionBlocked as exc:
            form.cleaned_data = getattr(form, "cleaned_data", {})
            form.add_error(None, str(exc))
        except DatabaseError as exc:
            logger.exception("Korekcija fizičke zalihe nije potvrđena")
            form.cleaned_data = getattr(form, "cleaned_data", {})
            form.add_error(None, contention_message(exc) or "Baza je zauzeta ili nije dostupna. Ponovite pregled. Ako je odgovor prekinut pri spremanju, ista potvrda je zaštićena od dvostrukog knjiženja.")
    summary = stock_summary(medicine) if medicine else None
    if medicine:
        selector = StockMedicineForm(initial={"lijek": medicine})
    from patients.stock_lots import lot_balances
    lots = [{'batch': batch, 'expiry': str(expiry or ''), 'quantity': str(quantity)}
            for (batch, expiry), quantity in lot_balances(medicine).items()] if medicine else []
    from patients.correction_impact import possible_stock_causes
    causes=possible_stock_causes(medicine) if medicine and plan else None
    return render(request, "dashboard/ispravi_fizicku_zalihu.html", {
        "selector": selector, "medicine": medicine, "summary": summary,
        'stock_lots': lots,
        "form": form, "preview": plan, "preview_token": token,
        'stock_causes':causes,
        "corrections": PhysicalStockCorrection.objects.filter(lijek=medicine).select_related("korisnik")[:20]
                       if medicine else [],
    })
