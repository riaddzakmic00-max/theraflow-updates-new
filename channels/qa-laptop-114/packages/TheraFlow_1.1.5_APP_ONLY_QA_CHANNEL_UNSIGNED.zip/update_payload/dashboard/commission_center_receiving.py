"""Connect reviewed document decisions to the established receiving ledger."""
from decimal import Decimal
from django.core.exceptions import ValidationError
from django.db import transaction
from patients.models import KomisijskiCiklus, KomisijskiZahtjev, Komisija, Trebovanje
from patients.transaction_locking import select_for_update_self
from patients.utils import upisi_log
from .commission_phase2 import save_commission_agreement, normalize_agreement_quantities


@transaction.atomic
def save_agreement_for_receiving(**kwargs):
    correction_reason = kwargs.pop('correction_reason', '').strip()
    original = kwargs['commission_request']
    cycle = KomisijskiCiklus.objects.select_for_update().get(pk=original.komisijski_ciklus_id)
    request = select_for_update_self(KomisijskiZahtjev.objects.select_related('pacijent')).get(pk=original.pk)
    if request.status == KomisijskiZahtjev.Status.NACRT:
        raise ValidationError('Prvo pregledajte i potvrdite komisijski zahtjev.')
    items = list(request.stavke_lijeka.select_for_update().select_related('lijek').order_by('redoslijed', 'pk'))
    if not items:
        raise ValidationError('Zahtjev nema stavke lijeka. Potrebna je provjera.')
    normalized = normalize_agreement_quantities(request, kwargs['decision'], kwargs['approved_quantities'])
    # One receiving row per presentation, including explicit IV/SC items.
    if len({item.lijek_id for item in items}) != len(items):
        raise ValidationError('Ponovljeni proizvod u zahtjevu: pregledajte stavke prije odobrenja.')
    linked = {}
    from patients.commission_receiving import received_commission_quantity
    for item in items:
        candidates = list(select_for_update_self(Trebovanje.objects.filter(
            komisijski_ciklus=cycle, pacijent=request.pacijent, lijek=item.lijek)
            .exclude(status=Trebovanje.STATUS_OTKAZANO)).order_by('pk'))
        if len(candidates) > 1:
            raise ValidationError('Više evidencija trebovanja za isti proizvod. Potrebna je kontrolisana provjera.')
        legacy = candidates[0] if candidates else None
        commission = (Komisija.objects.select_for_update().get(pk=legacy.komisija_id)
                      if legacy and legacy.komisija_id else None)
        used = max(Decimal('0'), commission.broj_odobrenih_doza - commission.preostale_doze) if commission else Decimal('0')
        physically_received = received_commission_quantity(legacy) if legacy else Decimal('0')
        if legacy and (physically_received > 0 or used > 0):
            if (legacy.odobrene_doze != normalized[item.pk]
                or (commission and ((commission.broj_saglasnosti or '').strip() != (kwargs['agreement_number'] or '').strip()
                    or commission.datum_odobrenja != kwargs['agreement_date']))):
                raise ValidationError('Odobrenje je već korišteno ili djelimično zaprimljeno. Izmjenu izvršite kroz kontrolisanu korekciju.')
        linked[item.pk] = (legacy, commission)
    previous = getattr(request, 'saglasnost', None)
    previous_date = previous.datum_saglasnosti if previous else None
    if previous:
        changed = (previous.broj_saglasnosti != ((kwargs['agreement_number'] or '').strip() or None)
            or previous.datum_saglasnosti != kwargs['agreement_date']
            or previous.odluka != kwargs['decision'] or previous.napomena != kwargs.get('note', '')
            or any(item.odobrena_kolicina != normalized[item.pk] for item in items))
        if changed and not correction_reason:
            raise ValidationError('Unesite razlog ispravke prethodno evidentirane odluke.')
        if changed:
            upisi_log(kwargs.get('user'), 'Razlog ispravke komisijske odluke',
                      pacijent=request.pacijent, objekat=previous, opis=correction_reason)
    kwargs['commission_request'] = request
    result = save_commission_agreement(**kwargs)
    agreement = result[0]
    for item in items:
        approved = normalized[item.pk]
        legacy, commission = linked[item.pk]
        if legacy is None and approved == 0:
            continue
        if legacy is None:
            legacy = Trebovanje.objects.create(pacijent=request.pacijent, lijek=item.lijek,
                komisijski_ciklus=cycle, broj_doza=item.kolicina,
                sistemski_prijedlog=item.kolicina, kreirao=kwargs.get('user'), status='PREDATO')
        received = Decimal(str(legacy.zaprimljene_doze or 0))
        if approved > 0 and commission is None:
            commission = Komisija.objects.create(pacijent=request.pacijent, lijek=item.lijek,
                datum_odobrenja=agreement.datum_saglasnosti, broj_odobrenih_doza=approved,
                preostale_doze=approved, status='ODOBRENA', broj_saglasnosti=agreement.broj_saglasnosti,
                napomena=f'Odluka komisijskog zahtjeva {request.pk}, stavka {item.pk}.')
        elif commission and received == 0 and commission.preostale_doze == commission.broj_odobrenih_doza:
            commission.broj_odobrenih_doza = approved
            commission.preostale_doze = approved
            commission.broj_saglasnosti = agreement.broj_saglasnosti
            commission.datum_odobrenja = agreement.datum_saglasnosti
            commission.status = 'ODOBRENA' if approved else 'PONISTENA'
            commission.save(update_fields=['broj_odobrenih_doza', 'preostale_doze', 'broj_saglasnosti', 'datum_odobrenja', 'status'])
        legacy.komisija = commission
        legacy.odobrene_doze = approved
        legacy.status = ('ODBIJENO' if approved == 0 else 'ZAPRIMLJENO' if received >= approved
                         else 'ODOBRENO')
        legacy.save(update_fields=['komisija', 'odobrene_doze', 'status'])
        upisi_log(kwargs.get('user'), 'Saglasnost povezana sa zaprimanjem', pacijent=request.pacijent,
            objekat=legacy, opis=f'Zahtjev {request.pk}, proizvod {item.lijek_id}: odobreno {approved}, već zaprimljeno {received}.')
    positive = list(cycle.trebovanja.filter(odobrene_doze__gt=0).select_related('lijek', 'komisija'))
    if positive:
        from collections import defaultdict
        from .receipt_display import physically_complete, receipt_totals
        grouped = defaultdict(list)
        for row in positive:
            grouped[row.lijek_id].append(row)
        received_any = any(receipt_totals(cycle, rows[0].lijek, rows)['physical_before'] > 0
                           or any(row.zaprimljene_doze > 0 for row in rows) for rows in grouped.values())
        cycle.status = ('ZAPRIMLJENO' if physically_complete(cycle, positive)
                        else 'DJELOMICNO_ZAPRIMLJENO' if received_any else 'CEKA_ISPORUKU')
        changed_fields = ['status', 'updated_at']
        if previous is None or previous_date != agreement.datum_saglasnosti:
            dates = [row.komisija.datum_odobrenja for row in positive
                     if row.komisija_id and row.komisija.datum_odobrenja]
            if dates:
                cycle.datum_odobrenja = max(dates)
                changed_fields.append('datum_odobrenja')
        cycle.save(update_fields=changed_fields)
    return result
