"""Preview/confirmation gate around existing patient-card mutations.

The original view validates and applies its own clinical workflow. This layer
only signs the reviewed input, serializes confirmation and links its audit.
"""
from functools import wraps
from copy import copy
from uuid import uuid4

from django.core import signing
from django.http import HttpResponseBadRequest
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect
from django.db import transaction, DatabaseError
from django.utils import timezone

from patients import models as m
from patients.correction_protocol import correction_transaction, contention_message
from patients.data_corrections import captured_rows, digest, serial
from .correction_center_views import render_in_center

SALT='theraflow.card-change-review.v1'


def protocol_steps_label(steps):
    return '; '.join(f"Sedmica {s.get('sedmica_od_pocetka', '—')} · {s.get('doza_mg', '—')} mg · "
        f"{s.get('broj_jedinica', '—')} jedinica · {s.get('nacin_primjene', '—')}" for s in steps) or 'Nema indukcijskih koraka'


def preview_card_change(request,patient,plan):
    """Called only after the original view's forms have passed validation."""
    if getattr(request,'reviewed_card_change',False):
        return None
    # Both wrapped views perform only DB domain/audit writes. Use their exact
    # mutation path inside a savepoint; suppress request-only success messages.
    from patients.correction_center import state, rows
    class PreviewMessages:
        def add(self,*args,**kwargs):pass
        def __iter__(self):return iter(())
    with correction_transaction():
        before=captured_rows()
        before_stock=state(patient,patient.lijek)
        probe=copy(request)
        probe.reviewed_card_change=True
        probe._messages=PreviewMessages()
        savepoint=transaction.savepoint()
        try:
            response=request.card_preview_executor(probe)
            if response.status_code not in (302,303):
                return response
            after_stock=state(m.Pacijent.objects.get(pk=patient.pk),patient.lijek)
            plan['rows'].extend(row for row in rows(before_stock,after_stock) if not row['unchanged'])
        finally:
            # A preview cannot retain audit, clinical order, status or balance writes.
            if not transaction.get_rollback():
                transaction.savepoint_rollback(savepoint)
        if captured_rows()!=before:
            raise ValueError('Pregled je promijenio podatke; promjena je poništena.')
        fingerprint=digest(before)
    payload=dict(operation=str(uuid4()),user=request.user.pk,patient=patient.pk,
                 path=request.path,raw=dict(request.POST.lists()),fingerprint=fingerprint,
                 review_date=str(timezone.localdate()),plan=serial(plan))
    payload['raw'].pop('csrfmiddlewaretoken',None)
    token=signing.dumps(payload,salt=SALT,compress=True)
    return render_in_center(request,'dashboard/card_change_review.html',dict(
        pacijent=patient,medicine=patient.lijek,preview=plan,token=token,title='Pregled promjene terapijskog plana'))


def reviewed_card_change(view):
    @wraps(view)
    def guarded(request,*args,**kwargs):
        if request.method!='POST' or not request.POST.get('impact_token'):
            request.card_preview_executor=lambda probe:view(probe,*args,**kwargs)
            try:
                return view(request,*args,**kwargs)
            except DatabaseError as exc:
                message=contention_message(exc)
                if not message:raise
                return HttpResponseBadRequest(message)
        from .permissions import je_doktor_ili_admin
        if not request.user.is_active or not je_doktor_ili_admin(request.user):
            raise PermissionDenied('Promjenu plana može potvrditi ovlašteni klinički korisnik.')
        try:
            payload=signing.loads(request.POST['impact_token'],salt=SALT)
            if (payload['user']!=request.user.pk or payload['path']!=request.path or
                    payload['patient']!=(kwargs.get('pacijent_id') or (args[0] if args else None)) or request.POST.get('confirmed')!='yes'):
                raise ValueError('Potvrdite pregled promjene iz ovog kartona.')
            with correction_transaction():
                existing=m.PatientDataCorrection.objects.filter(operation_id=payload['operation']).first()
                if existing:
                    return redirect('profil_pacijenta',pacijent_id=payload['patient'])
                signing.loads(request.POST['impact_token'],salt=SALT,max_age=1800)
                if payload['review_date']!=str(timezone.localdate()):
                    raise ValueError('Datum pregleda se promijenio. Ponovo pokrenite provjeru.')
                before=captured_rows()
                if digest(before)!=payload['fingerprint']:
                    raise ValueError('Podaci su promijenjeni nakon pregleda. Ponovo pokrenite provjeru.')
                raw=request.POST.copy();raw.clear()
                for key,values in payload['raw'].items():raw.setlist(key,values)
                request.POST=raw
                request.reviewed_card_change=True
                response=view(request,*args,**kwargs)
                if response.status_code in (302,303):
                    after=captured_rows()
                    if before!=after:
                        plan=payload['plan']
                        # Link to original clinical audit; do not copy its detailed snapshots.
                        # The established protocol editor replaces internal step rows;
                        # its own version audit preserves their prior contents.
                        plan['source_records']={table:[key for key in set(before[table])|set(after[table])
                            if before[table].get(key)!=after[table].get(key)] for table in before
                            if before[table]!=after[table]}
                        m.PatientDataCorrection.objects.create(operation_id=payload['operation'],
                            pacijent_id=payload['patient'],korisnik=request.user,scope='card_plan_review',
                            razlog=plan['reason'][:500],prije={},poslije={},posljedice=plan)
                return response
        except (signing.BadSignature,ValueError) as exc:
            return HttpResponseBadRequest(str(exc))
        except DatabaseError as exc:
            message=contention_message(exc)
            if not message:raise
            return HttpResponseBadRequest(message)
    return guarded
