"""Preview/confirm adapters for existing dated plan and pause models/services."""
from datetime import date, timedelta, time
from uuid import uuid4
from django import forms
from django.contrib.auth.decorators import login_required
from django.core import signing
from django.db import transaction, DatabaseError
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.views.decorators.http import require_http_methods
from patients import models as m, correction_center as center
from patients.correction_protocol import correction_transaction, contention_message
from patients.data_corrections import serial,captured_rows,digest,differences,require,backup_before_correction
from .correction_center_views import render_in_center

SALT='theraflow.center-plan.v1'


class PauseForm(forms.Form):
    mode=forms.ChoiceField(label='Odluka ljekara',choices=[('pause','Privremeni prekid'),('resume','Nastavak nakon prekida')])
    date=forms.DateField(label='Vrijedi od',widget=forms.DateInput(attrs={'type':'date'},format='%Y-%m-%d'))
    end=forms.DateField(label='Planirani kraj pauze (ako je poznat)',required=False,widget=forms.DateInput(attrs={'type':'date'},format='%Y-%m-%d'))
    reason=forms.CharField(label='Odluka ljekara i razlog',min_length=5,max_length=500,widget=forms.Textarea(attrs={'rows':3}))


def form_for(patient,kind,data=None):
    if kind=='pause':return PauseForm(data)
    from .forms import PromjenaTerapijeForm
    class CenterMedicineForm(PromjenaTerapijeForm):
        def clean(self):
            cleaned=super().clean()
            if self.data.get('previous_plan'):
                original=m.PatientDataCorrection.objects.filter(pk=self.data['previous_plan'],pacijent=patient,scope='center_plan').first()
                old=m.Lijek.objects.filter(pk=(original.posljedice.get('old_medicine') if original else None)).first()
                program=cleaned.get('nova_terapija')
                if not old or not program or old.terapijski_program_id!=program.pk:
                    raise forms.ValidationError('Za povezano poništavanje odaberite prethodnu terapiju iz originalne odluke.')
                # A program's default SKU may differ from the original product.
                # A compensating decision preserves that exact documented SKU.
                cleaned['novi_proizvod']=old
                if cleaned.get('datum_pocetka_nove_terapije'):
                    from patients.scheduling import validate_therapy_date
                    validate_therapy_date(cleaned['datum_pocetka_nove_terapije'],lijek=old)
            return cleaned
    form=CenterMedicineForm(data,pacijent=patient,preostale_doze=0)
    form.fields['therapy_selection_kind']=forms.CharField(initial='program',widget=forms.HiddenInput())
    form.fields['ljekar_koji_je_donio_odluku'].required=True
    form.fields['datum_odluke'].required=True
    form.fields['postupanje_sa_preostalim_dozama'].widget=forms.HiddenInput()
    form.fields['postupanje_sa_preostalim_dozama'].initial=m.PromjenaTerapije.POSTUPANJE_RUCNO_KASNIJE
    form.fields['napomena'].required=True
    form.fields['napomena'].help_text='Obavezni razlog i izvor odluke. Stare količine i odobrenja ostaju sačuvani; ne prebacuju se na novi lijek.'
    return form


def apply_plan(patient,kind,form,user, *, historical=False):
    data=form.cleaned_data
    if kind=='pause':
        from patients.therapy_workflow import pause_patient_therapy,resume_patient_therapy
        require(data['date']>=timezone.localdate(),'Za novu odluku odaberite današnji ili budući datum. Historijski događaj evidentirajte zasebno.')
        if data['mode']=='pause':
            return pause_patient_therapy(pacijent=patient,start_date=data['date'],planned_end_date=data['end'],reason=data['reason'],user=user)
        return resume_patient_therapy(pacijent=patient,resume_date=data['date'],reason=data['reason'],user=user)
    old=patient.lijek;new=data['novi_proizvod'];program=data['nova_terapija'];start=data['datum_pocetka_nove_terapije']
    require(start<=timezone.localdate() if historical else start>=timezone.localdate(),
        'Stvarna promjena mora biti danas ili ranije.' if historical else 'Nova terapija počinje danas ili ubuduće; postojeće primjene se ne prepisuju.')
    if historical:
        require(not patient.promjene_terapije.filter(datum_pocetka_nove_terapije__gte=start).exists(),
            'Već postoji kasnija promjena terapije. Otvorite historiju i ispravite odgovarajući nalog.')
    require(not patient.na_aktivnoj_pauzi(),'Pacijent je na pauzi. U istom centru izaberite Privremeni prekid / nastavak, zatim se vratite na ovaj unos.')
    require(old.pk!=new.pk,'Odaberite drugu prezentaciju; za dozu i interval koristite odgovarajuću radnju.')
    # The dedicated IV→SC flow validates the actual induction and explicit reservations.
    require(not (old.genericki_naziv.lower()=='ustekinumab' and new.genericki_naziv.lower()=='ustekinumab'),
        'Za isti ustekinumab koristite Prelazak IV → SC; tu se provjerava stvarno evidentirana indukcija.')
    protocol=new.aktivni_protokol()
    changed=m.PromjenaTerapije.objects.create(pacijent=patient,stari_lijek=old,novi_lijek=new,
        stari_protokol=patient.terapijski_protokol,novi_protokol=protocol,datum_odluke=data['datum_odluke'],
        ljekar_koji_je_donio_odluku=data['ljekar_koji_je_donio_odluku'],povezani_dokument=data.get('povezani_dokument'),
        datum_zavrsetka_stare_terapije=start-timedelta(days=1),datum_pocetka_nove_terapije=start,
        razlog=data['razlog'],napomena=data['napomena'],postupanje_sa_preostalim_dozama=m.PromjenaTerapije.POSTUPANJE_RUCNO_KASNIJE,
        nova_terapija_pocinje=data['nova_terapija_pocinje'],izvrsio=user)
    from patients.therapy_workflow import record_status_history
    for appointment in m.Termin.objects.filter(pacijent=patient,lijek=old,status=m.Termin.STATUS_PLANIRANA,datum__gte=start):
        before={'datum':str(appointment.datum),'lijek_id':old.pk,'status':appointment.status}
        appointment.status=m.Termin.STATUS_OTKAZANA;appointment.save(update_fields=['status'])
        record_status_history(pacijent=patient,termin=appointment,new_status=appointment.status,
            reason=data['napomena'],user=user,previous_state=before,new_state={'status':appointment.status})
    patient.lijek=new;patient.terapijski_program=program;patient.terapijski_protokol=protocol
    patient.pocetna_faza_terapije=(m.Pacijent.FAZA_ODRZAVANJE if data['nova_terapija_pocinje']==m.PromjenaTerapije.NOVA_FAZA_ODRZAVANJE else m.Pacijent.FAZA_INDUKCIJA)
    if protocol and protocol.interval_odrzavanja_sedmica:patient.interval_sedmica=protocol.interval_odrzavanja_sedmica
    patient.save(update_fields=['lijek','terapijski_program','terapijski_protokol','pocetna_faza_terapije','interval_sedmica'])
    if getattr(form, 'guided_workflow', False):
        # The old per-patient override must not carry an old medicine's dose
        # into the newly selected product. Its original value stays in audit.
        patient.kolicina_po_terapiji=None
        patient.save(update_fields=['kolicina_po_terapiji'])
    m.FazniProtokolPacijenta.objects.filter(pacijent=patient).exclude(terapijski_program=program).update(aktivan=False)
    if program.protokol_kljuc:
        from patients.phased_protocols import configure_program_protocol
        configure_program_protocol(patient=patient,program=program,maintenance_interval=patient.interval_sedmica,
            user=user,prescribed_iv_dose_mg=data.get('pocetna_iv_doza_mg'))
    if patient.trenutni_korak_je_ambulanta():
        from patients.therapy_workflow import schedule_therapy_appointment
        from patients.scheduling import adjust_to_allowed_therapy_date
        first_date = adjust_to_allowed_therapy_date(max(start,timezone.localdate()), lijek=new, protokol=protocol).datum
        schedule_therapy_appointment(pacijent=patient,lijek=new,datum=first_date,vrijeme=time(8),user=user,reason=data['napomena'])
    return changed


def preview(patient,kind,raw,user, *, historical=False, guided=False):
    form=form_for(patient,kind,raw);require(form.is_valid(),str(form.errors.as_text()))
    form.guided_workflow=guided
    previous=None
    if raw.get('previous_plan'):
        previous=m.PatientDataCorrection.objects.filter(pk=raw['previous_plan'],pacijent=patient,scope='center_plan').first()
        require(previous is not None,'Odaberite postojeću korekciju plana iz historije.')
        require(not previous.naknadne_ispravke.exists(),'Plan već ima povezanu korekciju. Otvorite posljednji zapis u historiji.')
        require(previous.posljedice.get('kind')==kind,'Vrsta nove odluke ne odgovara originalnoj korekciji.')
        require(previous.posljedice.get('clinical')==clinical_state(patient),
            'Nakon te odluke postoje nove ili ispravljene primjene. Historija se ne vraća unazad. U Ispravi terapijski plan unesite novu odluku ljekara za naredni period; postojeće primjene ostaju sačuvane.')
        if kind=='pause':
            require(form.cleaned_data['mode']!=previous.posljedice['mode'],'Za poništavanje pauze potvrdite nastavak, a za poništavanje nastavka novu pauzu.')
        else:
            require(form.cleaned_data['novi_proizvod'].pk==previous.posljedice['old_medicine'],
                'Za poništavanje potvrdite prethodni lijek. Za drugi lijek pokrenite novu promjenu plana.')
    medicine=patient.lijek;before=center.state(patient,medicine);old_name=str(medicine)
    protected=(m.Zaliha,m.ZalihaTransakcija,m.PacijentRezervacija,m.PacijentZaduzenje,m.Komisija,m.Terapija)
    original={model:list(model.objects.order_by('pk').values()) for model in protected}
    with transaction.atomic():
        apply_plan(patient,kind,form,user,historical=historical);patient.refresh_from_db()
        after=center.state(patient,medicine)
        require(all(original[model]==list(model.objects.order_by('pk').values()) for model in protected),
            'Promjena plana pokušala je izmijeniti količinu ili primjenu. Ništa nije sačuvano.')
        display=center.rows(before,after)+[dict(label='Trenutna terapija / proizvod',before=old_name,after=str(patient.lijek))]
        if kind=='pause':display.append(dict(label='Pauza',before='Dosadašnji plan',after=str(form.cleaned_data['date'])+' · '+form.cleaned_data['mode']))
        transaction.set_rollback(True)
    patient.refresh_from_db()
    return dict(title='Terapijski plan',rows=display,reason=form.cleaned_data.get('reason') or form.cleaned_data.get('napomena'),
        kind=kind,mode=form.cleaned_data.get('mode'),old_medicine=medicine.pk,
        clinical=clinical_state(patient),previous_plan=previous.pk if previous else None,
        impacts=['Fizička i slobodna zaliha, zaduženja, kućna izdavanja, komisijska prava i postojeće primjene ostaju sačuvani.',
                 'Rezervacije starog lijeka nisu prenesene na novi lijek. Eventualno oslobađanje potvrdite zasebno u ovom centru.'],warnings=[])


def clinical_state(patient):
    return serial(list(m.Terapija.objects.filter(pacijent=patient).order_by('pk').values('pk','datum','lijek_id','kolicina','workflow_status')))


@login_required
@require_http_methods(['GET','POST'])
def change(request,pacijent_id,kind):
    center.authorize(request.user)
    if kind not in ('pause','medicine'):raise forms.ValidationError('Nepoznata radnja.')
    patient=get_object_or_404(m.Pacijent,pk=pacijent_id)
    context={'pacijent':patient,'medicine':patient.lijek,'title':'Privremeni prekid / nastavak' if kind=='pause' else 'Promjena lijeka prema odluci ljekara',
        'form':form_for(patient,kind,request.POST if request.method=='POST' and request.POST.get('action')!='confirm' else None)}
    previous_id=request.GET.get('previous_plan')
    if previous_id and request.method=='GET':
        original=get_object_or_404(m.PatientDataCorrection,pk=previous_id,pacijent=patient,scope='center_plan')
        if kind=='pause':context['form'].initial.update(mode='resume' if original.posljedice.get('mode')=='pause' else 'pause',date=timezone.localdate())
        elif original.posljedice.get('old_medicine'):
            old=m.Lijek.objects.get(pk=original.posljedice['old_medicine'])
            context['form'].initial.update(nova_terapija=old.terapijski_program_id)
        context['title']='Poništi ispravku plana novom odlukom ljekara'
    try:
        if request.method=='POST':
            with correction_transaction():
                if request.POST.get('action')=='confirm':
                    require(request.POST.get('confirmed')=='yes','Potvrdite pregled promjene plana.')
                    payload=signing.loads(request.POST.get('token',''),salt=SALT)
                    require(payload['user']==request.user.pk and payload['patient']==patient.pk and payload['kind']==kind,'Potvrda ne pripada ovom planu.')
                    receipt=m.PatientDataCorrection.objects.filter(operation_id=payload['operation']).first()
                    if not receipt:
                        signing.loads(request.POST['token'],salt=SALT,max_age=1800)
                        require(digest(captured_rows())==payload['fingerprint'],'Podaci su izmijenjeni nakon pregleda. Ponovo pregledajte plan.')
                        plan=preview(patient,kind,payload['raw'],request.user)
                        form=form_for(patient,kind,payload['raw']);require(form.is_valid(),str(form.errors))
                        try:backup=backup_before_correction(payload['operation'])
                        except Exception as exc:raise ValueError('Backup nije verificiran; ništa nije knjiženo. U aplikaciji otvorite Backup i provjerite ručnu kopiju, zatim ponovite pregled plana.') from exc
                        before=captured_rows()
                        apply_plan(patient,kind,form,request.user)
                        old,new=differences(before,captured_rows())
                        receipt=m.PatientDataCorrection.objects.create(operation_id=payload['operation'],pacijent=patient,
                            korisnik=request.user,scope='center_plan',razlog=plan['reason'][:500],
                            datum_dogadjaja=form.cleaned_data.get('date') or form.cleaned_data['datum_pocetka_nove_terapije'],
                            prije=old,poslije=new,posljedice=plan,backup=backup,ponistava_id=plan.get('previous_plan'))
                    context.update(receipt=receipt,preview=receipt.posljedice)
                elif context['form'].is_valid():
                    raw=request.POST.dict();raw.pop('csrfmiddlewaretoken',None)
                    if previous_id:raw['previous_plan']=previous_id
                    context['preview']=preview(patient,kind,raw,request.user)
                    context['token']=signing.dumps(dict(operation=str(uuid4()),user=request.user.pk,patient=patient.pk,
                        kind=kind,raw=raw,fingerprint=digest(captured_rows())),salt=SALT,compress=True)
    except (ValueError,forms.ValidationError,signing.BadSignature) as exc:context['error']=str(exc)
    except DatabaseError as exc:
        context['error']=contention_message(exc)
        if not context['error']:raise
    return render_in_center(request,'dashboard/correction_action.html',context)
