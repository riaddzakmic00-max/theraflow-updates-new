from django import forms
from django.db.models import Q
from patients.models import Lijek


class MedicineChoice(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return " · ".join(filter(None, [obj.naziv, obj.strength, obj.put_primjene]))


class StockMedicineForm(forms.Form):
    lijek = MedicineChoice(queryset=Lijek.objects.none(), label="Lijek / prezentacija")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["lijek"].queryset = Lijek.objects.filter(Q(aktivan=True) | Q(zaliha__isnull=False)).order_by("naziv", "pk")


class PhysicalStockCorrectionForm(StockMedicineForm):
    obuhvat = forms.ChoiceField(label="Obuhvat brojanja", required=False,
        choices=[('TOTAL', 'Ukupno — serije nisu dokumentovane'), ('LOT', 'Konkretna serija i rok')])
    serija = forms.CharField(label="Serija", max_length=100, required=False)
    rok_trajanja = forms.DateField(label="Rok trajanja", required=False,
        widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
    datum_dogadjaja = forms.DateField(label="Datum fizičkog brojanja", required=False,
        widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
    razlog_kod = forms.ChoiceField(label="Vrsta razlike", required=False,
        choices=[('COUNT_UNKNOWN', 'Razlika pri popisu — uzrok za provjeru'),
                 ('INITIAL_ERROR', 'Pogrešno početno stanje'),
                 ('RECEIPT_ERROR', 'Pogrešno zaprimanje — otvori izvorni prijem')])
    kolicina = forms.DecimalField(label="Nova ispravna fizička količina", min_value=0,
                                 max_digits=8, decimal_places=2,
                                 widget=forms.NumberInput(attrs={"step": "1", "min": "0"}))
    razlog = forms.CharField(label="Razlog korekcije", min_length=5, max_length=500, strip=True,
                            widget=forms.Textarea(attrs={"rows": 3}))

    def clean_kolicina(self):
        value = self.cleaned_data["kolicina"]
        if value != value.to_integral_value():
            raise forms.ValidationError("Unesite cijeli broj pojedinačnih jedinica lijeka.")
        return value
