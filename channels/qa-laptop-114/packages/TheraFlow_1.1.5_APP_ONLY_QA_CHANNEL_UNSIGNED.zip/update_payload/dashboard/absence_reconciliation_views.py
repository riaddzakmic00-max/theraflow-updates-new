"""Five-step absence review in the existing administrator Correction Center."""
import logging
import uuid
from decimal import Decimal

from django import forms
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import DatabaseError
from django.http import Http404
from django.shortcuts import redirect
from django.views.decorators.http import require_http_methods

from patients import absence_reconciliation as service, models as m, smart_reconciliation as smart
from patients.correction_protocol import contention_message
from .correction_center_views import render_in_center
from .smart_reconciliation_views import url
from .postgres_backup import BackupError

logger = logging.getLogger(__name__)


class ActualReceiptForm(forms.Form):
    event_date = forms.DateField(label='Stvarni datum prijema', widget=forms.DateInput(attrs={'type':'date'}, format='%Y-%m-%d'))
    quantity = forms.DecimalField(label='Količina pojedinačnih jedinica', min_value=Decimal('.01'), max_digits=8, decimal_places=2)
    batch = forms.CharField(label='Serija / LOT', max_length=100, required=False)
    expires = forms.DateField(label='Rok trajanja', required=False, widget=forms.DateInput(attrs={'type':'date'}, format='%Y-%m-%d'))
    delivery_reference = forms.CharField(label='Oznaka stvarne isporuke / otpremnice', min_length=2, max_length=120)
    note = forms.CharField(label='Razlog / napomena', max_length=2000, required=False, widget=forms.Textarea(attrs={'rows':2}))
    duplicate_ack = forms.BooleanField(label='Provjerio/la sam ranije prijeme; ovo je druga stvarna isporuka (uz dokaz u napomeni)', required=False)


@login_required
@require_http_methods(['GET', 'POST'])
def index(request):
    smart.authorize(request.user)
    if not request.GET.get('session'):
        from .smart_reconciliation_views import index as therapy_index
        return therapy_index(request, absence=True)
    try: session = service.own(request.GET['session'], request.user)
    except (m.ReconciliationSession.DoesNotExist, ValueError): raise Http404('Proces nije pronađen.') from None
    context = dict(absence=True, session=session, steps=service.STEPS, smart_home=url(absence=True))
    try:
        if request.method == 'POST':
            action = request.POST.get('action')
            if action in ('navigate', 'save_later'):
                session = service.advance(session.pk, request.user, request.POST.get('step') or session.current_step, save_later=action == 'save_later')
                return redirect(url(session)+('&paused=1' if action == 'save_later' else ''))
            if action in ('finish', 'cancel'):
                service.finish(session.pk, request.user, cancel=action == 'cancel')
                return redirect(url(session))
        session = service.refresh(session.pk, request.user)
        if session.current_step == 1:
            from .smart_reconciliation_views import index as therapy_index
            return therapy_index(request, absence=True)
        if request.method == 'POST':
            action = request.POST.get('action')
            if action == 'preview':
                context['preview'], context['token'] = service.prepare(session.pk, request.POST, request.user)
            elif action == 'confirm':
                service.require(request.POST.get('confirmed') == 'yes', 'Potvrdite da ste pregledali posljedice.')
                saved, _ = service.confirm(request.POST.get('token', ''), request.user, session_id=session.pk)
                return redirect(url(session)+'&saved='+str(saved.pk))
            elif action == 'count':
                try: operation = uuid.UUID(request.POST.get('operation_id', ''))
                except ValueError: raise service.events.CorrectionBlocked('Popis nije važeći; ponovo otvorite ekran.') from None
                service.record_count(session.pk, request.POST.get('medicine_id'), request.POST.get('counted'), request.user, operation_id=operation)
                return redirect(url(session))
            elif action == 'explain':
                context['explanations'] = service.explain(session.pk, request.POST.get('medicine_id'), request.user)
                context['explain_medicine_id'] = request.POST.get('medicine_id')
            elif action == 'discard':
                service.advance(session.pk, request.user, session.current_step)
                return redirect(url(session))
            else: raise Http404('Nepoznata radnja.')
    except (ValueError, ValidationError) as exc:
        context['error'] = '; '.join(exc.messages) if isinstance(exc, ValidationError) else str(exc)
    except (BackupError, DatabaseError) as exc:
        logger.exception('Usklađivanje odsustva vraćeno bez djelimičnog događaja.')
        context['error'] = contention_message(exc) or 'Događaj nije primijenjen. Backup ili pristup bazi nije uspio; sve njegove poslovne posljedice su vraćene.'
    session.refresh_from_db()
    overview = service.summary(session)
    receipt_candidates = service.receipt_cards(session, include_reviewed=True)
    for row in receipt_candidates:
        row['form'] = ActualReceiptForm(initial={'event_date':session.period_end, 'quantity':row['remaining']}, auto_id=False)
    for row in overview['counts']: row['operation_id'] = str(uuid.uuid4())
    for row in overview['reservations']:
        row['recipients'] = m.Pacijent.objects.filter(lijek_id=row['medicine_id'], aktivan=True).exclude(pk=row['patient_id'])
        row['target_choices'] = [dict(value=f'patient_stock:{row["patient_id"]}', label='Ukupna količina ovog pacijenta u frižideru')]
        if row['id']:
            from patients.inventory_corrections import receipt_date
            claims=m.EvidencijaSaglasnostiZaprimanja.objects.filter(rezervacija_id=row['id']).select_related('fizicka_transakcija', 'komisijski_ciklus')
            row['target_choices'] += [dict(value=f'allocation:{claim.pk}', label=f'Raspodjela {claim.zaprimljena_kolicina} · {claim.komisijski_ciklus} · prijem {receipt_date(claim.fizicka_transakcija)}') for claim in claims if claim.fizicka_transakcija_id]
        row['approvals']=m.Komisija.objects.filter(pacijent_id=row['patient_id'],lijek_id=row['medicine_id'],status__in=m.Komisija.VAZECI_STATUSI)
        from patients.patient_fridge_corrections import sources
        row['source_choices']=[dict(id=tx.pk,label=f'Prijem {tx.datum:%d.%m.%Y.} · slobodno {quantity} · serija {tx.serija or "nije dokumentovana"}') for tx,quantity in sources(m.Lijek.objects.get(pk=row['medicine_id']))]
    home_patients = m.Pacijent.objects.filter(lijek__nacin_primjene=m.Lijek.NACIN_KUCNA_TERAPIJA)
    if session.patient_id: home_patients = home_patients.filter(pk=session.patient_id)
    if session.medicine_id: home_patients = home_patients.filter(lijek_id__in=session.medicine.equivalent_ids())
    context.update(session=session, step=session.current_step, overview=overview, actions=overview['actions'],
        open_session=session.status not in ('aligned', 'cancelled', 'completed'),
        medicines=service.relevant_medicines(session), receipt_form=ActualReceiptForm(initial={'event_date':session.period_end}, auto_id=False),
        receipt_medicines=m.Lijek.objects.filter(pk__in=session.medicine.equivalent_ids()) if session.medicine_id else m.Lijek.objects.order_by('naziv'),
        receipt_candidates=receipt_candidates,
        home_patients=home_patients,
        home_medicines=m.Lijek.objects.filter(pk__in=home_patients.values('lijek_id')),
        home_approvals=m.Komisija.objects.filter(pacijent__in=home_patients, status__in=m.Komisija.VAZECI_STATUSI),
        recent=m.ReconciliationSession.objects.filter(user=request.user, workflow='absence')[:12])
    if session.preview.get('source') == 'absence' and not context.get('error'):
        context.update(preview=session.preview['plan'], token=service.preview_token(session, request.user))
        context['preview_stale'] = session.preview_fingerprint != service.digest(smart.domain_snapshot())
    if request.GET.get('saved'): context['saved'] = session.actions.filter(pk=request.GET['saved']).first()
    return render_in_center(request, 'dashboard/absence_reconciliation.html', context)
