"""Display adapter for existing attention findings; never resolves or writes them."""
from urllib.parse import urlencode

from django.urls import reverse

GROUPS = (
    ('therapy', 'Terapije i termini', 'calendar3-week'),
    ('stock', 'Zaduženja i zalihe', 'box-seam'),
    ('receipts', 'Zaprimanja', 'box-arrow-in-down'),
    ('approvals', 'Komisije i odobrenja', 'journal-check'),
    ('other', 'Ostala neslaganja', 'search'),
)
PRESENTATION = {
    'term': ('therapy', 'Termin', 'Provjerite status termina i stvarnu primjenu, pa odaberite odgovarajuću vođenu ispravku.'),
    'consumption': ('therapy', 'Primjena', 'Uporedite primjenu s prometom zalihe prije izbora učinka ispravke.'),
    'future': ('therapy', 'Pregledani plan', 'Otvorite postojeći postupak i provjerite naredni termin prema pregledanom nalogu.'),
    'reservation': ('stock', 'Zaduženje', 'Provjerite povezani događaj prije izmjene ili oslobađanja zaduženja.'),
    'physical': ('stock', 'Fizički popis u postupku', 'Otvorite postojeći postupak i ponovo provjerite fizički popis.'),
    'receipt': ('receipts', 'Trebovanje', 'Provjerite stvarni prijem i komisijsku vezu; već primljenu isporuku ne zaprimajte ponovo.'),
    'unlinked': ('receipts', 'Prijem', 'Pregledajte postojeći prijem i povežite odgovarajuću komisijsku stavku ako postoji.'),
    'commission': ('approvals', 'Komisija', 'Provjerite izvorno odobrenje i povezane stavke prije ispravke.'),
    'approval': ('approvals', 'Odobrenje', 'Provjerite izvorno odobrenje i povezane stavke prije ispravke.'),
    'session': ('other', 'Postupak usklađivanja', 'Nastavite postojeći postupak i pregledajte preostale korake.'),
}


def grouped_attention(items, *, guided_allowed=False, admin=False):
    """Preserve every native finding and source link, adding presentation only."""
    from patients import models as m
    from .correction_center_views import center_url

    ids = {'term': [], 'consumption': []}
    for item in items:
        kind, _, identifier = item['key'].partition('-')
        if kind in ids and identifier.isdigit():
            ids[kind].append(int(identifier))
    contexts = {}
    if guided_allowed:
        for kind, model in (('term', m.Termin), ('consumption', m.Terapija)):
            if ids[kind]:
                contexts.update({f'{kind}-{row["pk"]}': row for row in model.objects.filter(
                    pk__in=ids[kind]).values('pk', 'pacijent_id', 'lijek_id')})
    groups = [dict(key=key, title=title, icon=icon, items=[]) for key, title, icon in GROUPS]
    by_key = {group['key']: group for group in groups}
    for item in items:
        kind, _, identifier = item['key'].partition('-')
        group, label, recommendation = PRESENTATION.get(kind, (
            'other', 'Povezani zapis', 'Otvorite povezani zapis i provjerite izvorne podatke prije ispravke.'))
        action_url = item['url']
        native = contexts.get(item['key'])
        if native:
            action_url = center_url(patient=native['pacijent_id'], medicine=native['lijek_id']) + '&' + urlencode(
                dict(section='corrections', from_card='1'))
        elif admin and kind in ('reservation', 'unlinked'):
            # The existing permitted service keeps its exact record identity.
            action_url = center_url(item['url'])
        row = dict(item, source_url=item['url'], action_url=action_url,
                   record_label=f'{label} #{identifier}', recommendation=recommendation)
        by_key[group]['items'].append(row)
    return groups
