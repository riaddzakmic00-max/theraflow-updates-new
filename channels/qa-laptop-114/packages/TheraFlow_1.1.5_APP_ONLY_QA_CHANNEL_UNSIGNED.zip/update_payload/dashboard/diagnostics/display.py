LABELS = {
    'operation_id':'Izvorna radnja','unit_snapshot':'Jedinica sačuvana pri radnji',
    'original_movement_id':'Izvorni fizički promet',
    'cycle_received_gross':'Evidentirani zajednički fizički ulaz (prije korekcija)',
    'cycle_corrections':'Izričite korekcije tog ulaza',
    'cycle_received':'Neto knjiženje ulaza nakon korekcija (nije dokaz neisporuke)',
    'receipt_state':'Pouzdanost veze prijema', 'nonreceipt_confirmed':'Postoji potvrda neisporuke',
    'approved_subtotal':'Odobreno u dostupnoj historiji (jednom po odobrenju)',
    'home_issued_subtotal':'Izdato kući — potvrđene radnje u dostupnoj historiji',
    'administered_subtotal':'Primijenjeno — potvrđene radnje u dostupnoj historiji',
    'known_subtotal':'Poznati podzbir (nije potpuna historija)',
    'requested_quantity':'Traženo (ručno isključeno nije stvarni zahtjev)',
    'approved_quantity':'Odobreno','physical_received':'Stvarno zaprimljeno — povezani neto ulaz',
    'allocated_quantity':'Trenutno fizički raspodijeljeno','linked_consumption':'Izričito povezani izlazi iz rezervacija',
    'received_ledger_subtotal':'Neto zaprimanja u dostupnom prometu (nije ukupna historija)',
    'issued_ledger_subtotal':'Izdato/primijenjeno u dostupnom prometu, prije povrata',
    'age_days':'Dana od odobrenja','stale_threshold_days':'Prag ručne provjere (dani)',
    'conversion_factor':'Eksplicitni faktor konverzije','converted_quantity':'Konvertovana odobrena količina',
    'cycle_id':'Izvorni ciklus','request_status':'Faza zahtjeva',
    'dose_mg':'Propisana doza (mg)', 'interval_weeks':'Važeći interval (sedmice)',
    'manual_exception':'Dokumentovana ručna količina','appointment_status':'Status termina',
    'report_dates_differ':'Izjave nisu na isti datum',
    'reported_subtotal':'Poznati podzbir izjava (nije ukupno stanje)',
    'reports_expected':'Pacijenti obuhvaćeni zbirnim prikazom', 'reports_known':'Poznate izjave',
    'reports_missing':'Nedostajuće ili zastarjele izjave','reports_complete':'Sve izjave poznate',
    'source_quantity':'Stvarno evidentirana količina izvorne radnje',
    'expected_return':'Očekivani povrat','returned_quantity':'Povezani povrat',
    'return_difference':'Razlika povrata (promet − očekivano)',
    'expected_effect':'Očekivani fizički učinak','effect_difference':'Razlika fizičkog učinka',
    'migration_declared':'Tražena migracijska alokacija (nije potvrda današnjeg fizičkog stanja)',
    'expected_quantity':'Očekivana količina prema povezanim učincima', 'active':'Aktivno zaduženje',
    'future_reserved':'Od fizički zaduženog — za buduće termine', 'awaiting_coverage':'Čeka fizičko pokriće (nije fizička zaliha)',
    'home_recorded_subtotal':'Evidentirano preostalo u kućnim zaduženjima (nije novo brojanje)',
    'destination_id':'Odredišna rezervacija', 'workflow_status':'Status terapije', 'received_quantity':'Evidentirano zaprimljeno',
    'allocation_origin_quantity':'Dokazani izvor prije transfera',
    'transferred_in':'Ulaz preko povezanih transfera','transferred_out':'Izlaz preko povezanih transfera',
    'calculation_source':'Izvor obračuna','planning_possible':'Planiranje moguće prema postojećem servisu',
    'usable_approval':'Upotrebljivo postojeće odobrenje u obračunu','existing_request_quantity':'Postojeći zahtjev u obračunu',
    'daily_consumption':'Planirana dnevna potrošnja (nije evidentirana primjena)',
    'target_days':'Ciljni period u danima','package_size':'Jedinica u pakovanju','package_count':'Broj pakovanja',
    'remaining_quantity':'Preostala količina','total_quantity':'Ukupna količina','period_start':'Početak obračunskog perioda',
    'period_end':'Kraj obračunskog perioda','needed':'Potrebno u obračunskom periodu','physically_secured':'Fizički osigurano u obračunu',
    'confirmed_incoming':'Pouzdan dolazak u obračunu','uncovered_need':'Nepokrivena potreba','reserve':'Rezerva prema postojećem pravilu',
    'raw_request':'Potreba prije pravila pakovanja','first_uncovered':'Prva nepokrivena planirana primjena',
    'recorded_fridge':'Evidentirano u frižideru','recorded_at_patient':'Evidentirano kod pacijenata',
    'expected_fridge':'Saldo iz početnog stanja i prometa','difference':'Razlika (evidentirano − obračunato)',
    'unit':'Jedinica zalihe','route':'Put primjene','history_reliable':'Historija dovoljna za poređenje',
    'opening_quantity':'Potvrđeno početno stanje','checkpoint_id':'Posljednje uključeno kretanje',
    'recorded_on':'Datum potvrđenog početnog stanja','event_type':'Vrsta kretanja','event_date':'Datum događaja',
    'quantity':'Količina','fridge_delta':'Promjena fizičkog stanja frižidera','source_type':'Vrsta izvora',
    'source_id':'ID izvornog zapisa','reserved':'Važeće fizičke rezervacije','physical_shortfall':'Fizički nepokrivene rezervacije',
    'issued_on':'Datum izdavanja','issued_quantity':'Izdata količina','last_application':'Potvrđeni datum kućne primjene',
    'reported_remaining':'Preostalo prema izjavi pacijenta','checked_on':'Datum provjere s pacijentom',
    'proposal':'Konačna količina za komisiju','system_proposal':'Prijedlog sistema','delivery_date':'Kanonski datum očekivane isporuke',
    'delivery_estimated':'Isporuka je procjena','covered_until':'Fizički osigurano do','manual_exclusion':'Ne trebuje se — ručno',
    'later_uncovered_period':'Zahtjev pokriva kasniji period s nepokrivenom potrebom',
    'included':'Uključen u nacrt','at_patient':'Količina kod pacijenta','reserved_in_fridge':'Rezervisano u frižideru',
    'free_fridge':'Slobodno u frižideru','unused_approved':'Odobreno, neiskorišteno','approved_waiting_delivery':'Odobreno, čeka isporuku',
    'submitted':'Već predato komisiji','atc_present':'ATC evidentiran','form_present':'Oblik evidentiran',
    'strength_present':'Jačina evidentirana','approval_date':'Datum pripadajućeg odobrenja',
    'approval_number_present':'Broj pripadajuće saglasnosti evidentiran','event_id':'Identifikator tehničkog događaja',
    'error_category':'Kategorija tehničke greške','document_kind':'Vrsta dokumenta',
}


def display_evidence(item):
    from .export import NUMBERS
    from .inventory_display import amount
    sources={'COMMISSION_DECISION':'Završna komisijska odluka','HOME_EXPLANATION':'Obračun kućne terapije',
             'ORAL_CALCULATION':'Obračun oralne terapije','UNAVAILABLE':'Obračun nije dostupan'}
    non_quantities={'age_days','stale_threshold_days','target_days','interval_weeks','dose_mg','conversion_factor',
                    'package_count','package_size','reports_expected','reports_known','reports_missing'}
    values=[]
    for key,value in item['values'].items():
        if key in NUMBERS and key not in non_quantities and value is not None:
            value=amount(value)+' '+(item['values'].get('unit') or '(jedinica nije poznata)')
        elif key=='calculation_source': value=sources.get(value,value)
        elif key=='receipt_state': value={'UNLINKED_BULK':'Prijem postoji; pojedinačna raspodjela nerazjašnjena',
            'NO_RECEIPT_RECORD':'Nema povezanog zapisa; nije potvrđena neisporuka',
            'UNRESOLVED_HISTORY':'Historija prijema nije razjašnjena','LINKED_RECEIPT':'Potvrđen povezani prijem'}.get(value,value)
        elif value is True: value='Da'
        elif value is False: value='Ne'
        values.append((LABELS.get(key,key),value))
    return {**item,'display_values':values}
