"""Administrator diagnostics: readers and explanations, never repair commands."""
