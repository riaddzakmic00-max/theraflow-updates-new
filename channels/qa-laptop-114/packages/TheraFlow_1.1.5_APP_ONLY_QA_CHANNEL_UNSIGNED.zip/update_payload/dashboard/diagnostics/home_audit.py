"""Reconcile recorded home balances, never estimated administrations.

PacijentZaduzenje is a book balance; Zaliha.kod_pacijenata is the injection
aggregate. Statements are dated observations, not ledger transactions. Oral
issuance does NOT update that aggregate and its time-based remainder cannot
be used as evidence of consumption. Corrections without a dated full basis
and legacy allocations remain limitations.
"""
from collections import defaultdict
from decimal import Decimal
from patients import models as m
from patients.monthly_consumption import REVERSALS

ZERO=Decimal('0')


def check_home_ledger(run):
    data=run.inventory_records
    if data is None:
        raise ValueError('Inventory census required')
    refs={}
    def proof(obj, values=None):
        key=(type(obj).__name__,obj.pk)
        if key not in refs or values is not None:
            refs[key]=run.evidence_for(key[0],obj.pk,patient_id=getattr(obj,'pacijent_id',None),
                medicine_id=getattr(obj,'lijek_id',None),values=values or {})
        return refs[key]
    therapies={t.pk:t for t in data['therapies']}
    snapshots={s.pk:s for s in data['snapshots']}
    assignments_by_id={a.pk:a for a in data['assignments']}
    uncertain_pairs=set()
    for t in data['therapies']:
        run.checkpoint()
        state=t.workflow_snapshot or {}
        if state.get('vrsta')!='KUCNA_PRIMJENA':
            continue
        pair=(t.pacijent_id,t.lijek_id)
        changes=state.get('zaduzenja_promjene',[])
        if not changes:
            uncertain_pairs.add(pair)
            run.add('HOME_LEDGER','home','UNKNOWN',[proof(t)],reasons=['HOME_LEDGER_HISTORY'])
            continue
        amounts=[]
        for change in changes:
            a=assignments_by_id.get(change.get('zaduzenje_id'))
            if a is None or (a.pacijent_id,a.lijek_id)!=pair:
                uncertain_pairs.add(pair)
                run.add('HOME_LEDGER','home','ISSUE',[proof(t)],reasons=['SOURCE_MISSING' if a is None else 'SOURCE_IDENTITY'])
            if change.get('kolicina') is None:
                uncertain_pairs.add(pair)
                run.add('HOME_LEDGER','home','UNKNOWN',[proof(t)],reasons=['HOME_LEDGER_HISTORY'])
            else:
                amounts.append(Decimal(str(change['kolicina'])))
        if len(amounts)==len(changes) and (sum(amounts,ZERO)!=t.kolicina or any(q<=0 for q in amounts)):
            uncertain_pairs.add(pair)
            ref=proof(t,{'expected_quantity':t.kolicina,'quantity':sum(amounts,ZERO),
                         'difference':sum(amounts,ZERO)-t.kolicina})
            run.add('HOME_LEDGER','home','ISSUE',[ref],reasons=['SOURCE_QUANTITY'])
    by_assignment=defaultdict(list)
    for issue in data['issues']:
        if issue.pacijent_zaduzenje_id:
            by_assignment[issue.pacijent_zaduzenje_id].append(issue)
        else:
            run.add('HOME_LEDGER','home','UNKNOWN',[proof(issue)],reasons=['HOME_LEDGER_HISTORY'])
    outcomes, events_by_pair, proofs_by_pair = {}, defaultdict(list), defaultdict(list)
    scope=run.new_scope('home','PacijentZaduzenje',len(data['assignments']),label='Kućna zaduženja: početak, izdavanja, primjene i povrati')
    scope['loaded']=scope['records']
    for a in data['assignments']:
        run.checkpoint()
        drug=data['drugs'][a.lijek_id]
        related=[proof(a)]
        issues=by_assignment[a.pk]
        events=[]; reasons=[]; bad=False
        if (a.pacijent_id,a.lijek_id) in uncertain_pairs:
            reasons.append('HOME_LEDGER_HISTORY')
        snapshot=snapshots.get(a.migracijski_snapshot_id)
        if drug.oralna_terapija:
            reasons.append('HOME_ORAL_ESTIMATE')
        if drug.jedinice_zalihe[0] not in {'bočica','pen','šprica','tableta','ampula'}:
            reasons.append('SOURCE_UNIT')
        if snapshot:
            related.append(proof(snapshot,{'opening_quantity':snapshot.kod_pacijenta,'event_date':snapshot.kreirano.date()}))
            if (snapshot.pacijent_id,snapshot.lijek_id)!=(a.pacijent_id,a.lijek_id):
                bad=True
            openings=[t for t in data['ledger'] if t.referenca_tip=='MigracijskiSnapshotPacijenta'
                and t.referenca_id==snapshot.pk and t.lokacija=='KOD_PACIJENTA']
            if snapshot.kod_pacijenta is None or any(t.tip=='KOREKCIJA' for t in openings):
                reasons.append('HOME_LEDGER_HISTORY')
            elif (snapshot.kod_pacijenta==0 or len(openings)==1 and
                  openings[0].tip=='POCETNO_STANJE_MIGRACIJE' and openings[0].kolicina==snapshot.kod_pacijenta):
                events.append((snapshot.kreirano.date(),snapshot.kod_pacijenta))
            else:
                reasons.append('HOME_LEDGER_HISTORY')
        elif not issues:
            reasons.append('HOME_LEDGER_HISTORY')
        for i in issues:
            run.checkpoint()
            related.append(proof(i,{'issued_on':i.datum,'issued_quantity':i.kolicina}))
            if (i.pacijent_id,i.lijek_id)!=(a.pacijent_id,a.lijek_id):
                bad=True
            events.append((i.datum,i.efektivna_kolicina))
            issued=[t for t in data['ledger'] if t.tip=='KUCNO_IZDAVANJE' and
                    (t.referenca_tip,t.referenca_id) in {('KucnoIzdavanje',i.pk),('Terapija',i.terapija_id)}]
            related += [proof(t,{'quantity':t.kolicina,'event_date':t.datum,'fridge_delta':t.frizider_delta()}) for t in issued]
            if not issued or sum((t.kolicina for t in issued),ZERO)!=i.kolicina:
                reasons.append('HOME_LEDGER_HISTORY')
            returns=[t for t in data['ledger'] if t.tip=='POVRAT' and
                ((REVERSALS.get(t.referenca_tip,t.referenca_tip),t.referenca_id) in {
                    ('KucnoIzdavanje',i.pk),('Terapija',i.terapija_id)} or
                 t.referenca_tip=='ZalihaTransakcija' and any(
                    o.pk==t.referenca_id and (o.referenca_tip,o.referenca_id) in {
                        ('KucnoIzdavanje',i.pk),('Terapija',i.terapija_id)} for o in data['ledger']))]
            for tx in returns:
                related.append(proof(tx,{'quantity':tx.kolicina,'event_date':tx.datum}))
                if tx.lijek_id!=a.lijek_id or tx.pacijent_id!=a.pacijent_id:
                    bad=True
                events.append((tx.datum,-tx.kolicina))
            therapy=therapies.get(i.terapija_id)
            if therapy and (therapy.ponistena_at or therapy.workflow_status=='PONISTENA'):
                if sum((t.kolicina for t in returns),ZERO)!=i.kolicina:
                    reasons.append('HOME_LEDGER_HISTORY')
        for t in data['therapies']:
            state=t.workflow_snapshot or {}
            changes=[v for v in state.get('zaduzenja_promjene',[]) if v.get('zaduzenje_id')==a.pk]
            for change in changes:
                related.append(proof(t,{'quantity':t.kolicina,'event_date':t.datum}))
                if (t.pacijent_id,t.lijek_id)!=(a.pacijent_id,a.lijek_id):
                    bad=True
                if change.get('kolicina') is None:
                    reasons.append('HOME_LEDGER_HISTORY'); continue
                qty=Decimal(str(change['kolicina']))
                events.append((t.datum,-qty))
                if t.workflow_status=='PONISTENA' or t.ponistena_at:
                    if t.ponistena_at:
                        events.append((t.ponistena_at.date(),qty))
                    else:
                        reasons.append('HOME_LEDGER_HISTORY')
        # Transfers/therapy switches or undocumented applications cannot be
        # reconstructed by treating the current total as a historical opening.
        if any(t.pacijent_id==a.pacijent_id and t.lijek_id==a.lijek_id and
               t.lokacija=='KOD_PACIJENTA' and t.tip in {'OTPIS','KOREKCIJA'} for t in data['ledger']):
            reasons.append('HOME_LEDGER_HISTORY')
        if any(day>run.today for day,q in events):
            reasons.append('HOME_LEDGER_HISTORY')
        expected=None if reasons else sum((q for day,q in events if day<=run.today),ZERO)
        recorded=a.preostalo if a.aktivno else ZERO
        ref=proof(a,{'expected_quantity':expected,'remaining_quantity':recorded,'total_quantity':a.ukupno_zaduzeno,
            'difference':recorded-expected if expected is not None else None,'unit':drug.jedinice_zalihe[0]})
        if bad:
            run.add('HOME_LEDGER','home','ISSUE',[ref,*related],reasons=['SOURCE_IDENTITY'])
        status='UNKNOWN' if reasons else 'OK' if expected==recorded else 'ISSUE'
        run.add('HOME_LEDGER','home',status,[ref,*related],reasons=reasons or (['HOME_LEDGER_DIFFERENCE'] if status=='ISSUE' else []))
        outcomes[a.pk]=expected is not None and not bad
        proofs_by_pair[(a.pacijent_id,a.lijek_id)].extend([ref,*related])
        if reasons:
            run.skip_record(scope,reasons[0])
        else:
            scope['checked']+=1
            events_by_pair[(a.pacijent_id,a.lijek_id)].extend(events)
    # Compare comparable injection book balances even with no patient statement.
    # A statement is not required to prove 3 ledger units != 0 aggregate units.
    drugs=set(a.lijek_id for a in data['assignments']) | set(i.lijek_id for i in data['issues']) | set(o.lijek_id for o in data['oral'])
    total_scope=run.new_scope('home','Zaliha',len(drugs),label='Kućni zbir: ista prezentacija i knjigovodstveni presjek')
    total_scope['loaded']=len(drugs)
    for drug_id in sorted(drugs):
        run.checkpoint()
        drug=data['drugs'][drug_id]; stock=data['stocks'].get(drug_id)
        assignments=[a for a in data['assignments'] if a.lijek_id==drug_id]
        complete=bool(assignments) and all(outcomes.get(a.pk) for a in assignments) and not drug.oralna_terapija
        complete=complete and not any(i.lijek_id==drug_id and not i.pacijent_zaduzenje_id for i in data['issues'])
        complete=complete and not any(s.lijek_id==drug_id and s.kod_pacijenta is None for s in data['snapshots'])
        complete=complete and not any(s.lijek_id==drug_id and s.kod_pacijenta and
            s.pk not in {a.migracijski_snapshot_id for a in assignments} for s in data['snapshots'])
        complete=complete and not any(did==drug_id for pid,did in uncertain_pairs)
        expected=sum((a.preostalo for a in assignments if a.aktivno),ZERO) if complete else None
        recorded=stock.kod_pacijenata if stock else None
        ref=run.evidence_for('Lijek',drug_id,values={'expected_quantity':expected,'recorded_at_patient':recorded,
            'difference':recorded-expected if recorded is not None and expected is not None else None,'unit':drug.jedinice_zalihe[0]})
        status='UNKNOWN' if expected is None or recorded is None else 'OK' if expected==recorded else 'ISSUE'
        reason='HOME_ORAL_ESTIMATE' if drug.oralna_terapija else 'HOME_LEDGER_HISTORY'
        run.add('HOME_LEDGER','home',status,[ref,*[proof(a) for a in assignments]],
            reasons=[reason] if status=='UNKNOWN' else ['HOME_LEDGER_DIFFERENCE'] if status=='ISSUE' else [])
        if status=='UNKNOWN': run.skip_record(total_scope,reason)
        else: total_scope['checked']+=1
        for row in run.inventory['stocks']:
            if row['drug_id']==drug_id:
                row['at_patient']=str(expected) if expected is not None else None
    reports=[r for r in data['reports'] if r.vrsta=='IZJAVA']
    report_scope=run.new_scope('home','KucnaTerapijaPodatak',len(reports),label='Izjave prema knjigovodstvenom presjeku na datum provjere')
    report_scope['loaded']=len(reports)
    for r in reports:
        run.checkpoint()
        pair=(r.pacijent_id,r.lijek_id)
        assignments=[a for a in data['assignments'] if (a.pacijent_id,a.lijek_id)==pair]
        events=events_by_pair[pair]
        reliable=bool(assignments and events) and all(outcomes.get(a.pk) for a in assignments)
        reliable=reliable and min((day for day,q in events),default=run.today)<=r.datum_provjere<=run.today
        expected=sum((q for day,q in events if day<=r.datum_provjere),ZERO) if reliable else None
        value=r.preostala_kolicina
        ref=proof(r,{'reported_remaining':value,'checked_on':r.datum_provjere,'expected_quantity':expected,
            'difference':value-expected if value is not None and expected is not None else None})
        status='UNKNOWN' if value is None or expected is None else 'OK' if value==expected else 'REVIEW'
        reason='HOME_QUANTITY_UNKNOWN' if value is None else 'HOME_LEDGER_HISTORY'
        run.add('HOME_STATEMENT','home',status,[ref,*dict.fromkeys(proofs_by_pair[pair])],
            reasons=[reason] if status=='UNKNOWN' else ['HOME_STATEMENT_DIFFERENCE'] if status=='REVIEW' else [],
            limitation='Očekivano koristi samo događaje do datuma izjave. Priložena historija može sadržavati i kasnije događaje radi pregleda; oni nisu pribrojeni ovom presjeku.')
        if status=='UNKNOWN': run.skip_record(report_scope,reason)
        else: report_scope['checked']+=1
