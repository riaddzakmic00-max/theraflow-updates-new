from contextlib import contextmanager
from time import monotonic

from django.db import connection, transaction
from patients.request_cache import begin_request_cache, end_request_cache


class ReadOnlyViolation(RuntimeError):
    pass


class BudgetExceeded(RuntimeError):
    pass


@contextmanager
def diagnostic_snapshot(seconds=15):
    """A fresh, consistent DB snapshot with two independent write barriers.

    PostgreSQL enforces READ ONLY (including writes hidden in SQL functions).
    The execute wrapper also rejects ORM writes before they reach the database.
    Do not reuse an outer transaction/cache: it may contain a different snapshot.
    """
    if connection.in_atomic_block:
        raise ReadOnlyViolation('Dijagnostika zahtijeva vlastiti presjek podataka.')
    deadline = monotonic() + seconds
    token = begin_request_cache()

    def guard(execute, sql, params, many, context):
        if monotonic() >= deadline:
            raise BudgetExceeded()
        command = sql.lstrip().split(None, 1)[0].upper()
        if command not in {'SELECT', 'SAVEPOINT', 'RELEASE', 'ROLLBACK'}:
            raise ReadOnlyViolation('Zaustavljen pokušaj upisa pomoćnog servisa.')
        if connection.vendor == 'postgresql' and command == 'SELECT':
            # This SET is ours, not supplied by a checker. Bound each query by
            # both its individual limit and the remaining total budget.
            remaining = max(1, min(1500, int((deadline - monotonic()) * 1000)))
            execute(f"SET LOCAL statement_timeout = {remaining}", None, False, context)
        result = execute(sql, params, many, context)
        if monotonic() >= deadline:
            raise BudgetExceeded()
        return result

    sqlite_query_only = None
    try:
        if connection.vendor == 'sqlite':
            with connection.cursor() as cursor:
                cursor.execute('PRAGMA query_only')
                sqlite_query_only = cursor.fetchone()[0]
                cursor.execute('PRAGMA query_only=ON')
        with transaction.atomic():
            if connection.vendor == 'postgresql':
                with connection.cursor() as cursor:
                    cursor.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
            elif connection.vendor != 'sqlite':
                raise ReadOnlyViolation('Ovaj backend nema provjeren režim dijagnostike samo za čitanje.')
            with connection.execute_wrapper(guard):
                yield
    finally:
        if sqlite_query_only is not None:
            with connection.cursor() as cursor:
                cursor.execute(f'PRAGMA query_only={int(sqlite_query_only)}')
        end_request_cache(token)
