"""Positive allowlist, shared by preview, download and external AI requests."""
import re
from .catalog import AREAS, CHECKS, CHECK_VERSION, REASONS, NOT_IMPLEMENTED, finding_contract
from .inventory_display import inventory_display

NUMBERS = {'remaining_quantity','total_quantity','needed','physically_secured','confirmed_incoming','uncovered_need','reserve','raw_request',
    'expected_quantity','future_reserved','awaiting_coverage','home_recorded_subtotal','received_quantity','migration_declared',
    'usable_approval','existing_request_quantity','daily_consumption','target_days','package_size','package_count',
    'recorded_fridge','recorded_at_patient','expected_fridge','difference','opening_quantity','quantity',
    'fridge_delta','reserved','physical_shortfall','issued_quantity','reported_remaining','proposal','system_proposal',
    'at_patient','reserved_in_fridge','free_fridge','unused_approved','approved_waiting_delivery','submitted'}
BOOLS = {'active','history_reliable','delivery_estimated','manual_exclusion','included','atc_present','form_present','strength_present','approval_number_present','planning_possible'}
DATES = {'period_start','period_end','first_uncovered','event_date','recorded_on','issued_on','last_application','checked_on','delivery_date','covered_until','approval_date'}
NUMBERS |= {'reported_subtotal','reports_expected','reports_known','reports_missing','source_quantity',
            'expected_return','returned_quantity','return_difference','expected_effect','effect_difference'}
BOOLS.add('reports_complete')
BOOLS |= {'report_dates_differ','manual_exception'}
NUMBERS |= {'dose_mg','interval_weeks'}
NUMBERS |= {'requested_quantity','approved_quantity','physical_received','allocated_quantity',
    'linked_consumption','received_ledger_subtotal','issued_ledger_subtotal','age_days','stale_threshold_days',
    'conversion_factor','converted_quantity'}
NUMBERS |= {'cycle_received','approved_subtotal','home_issued_subtotal','administered_subtotal','known_subtotal'}
NUMBERS |= {'cycle_received_gross','cycle_corrections'}
NUMBERS |= {'allocation_origin_quantity','transferred_in','transferred_out'}
BOOLS.add('nonreceipt_confirmed')
BOOLS.add('later_uncovered_period')
ENUMS = {
    'calculation_source': {'COMMISSION_DECISION','HOME_EXPLANATION','ORAL_CALCULATION','UNAVAILABLE'},
    'unit': {'bočica','bočice','flakon','pen','penovi','šprica','šprice','tableta','tablete','pakovanje','pakovanja','ampula','ampule','doza'},
    'route': {'IV','SC','PO','IM'},
    'event_type': {'ZAPRIMANJE','AMBULANTNA_POTROSNJA','KUCNO_IZDAVANJE','ORALNO_IZDAVANJE','POVRAT','OTPIS','KOREKCIJA',
        'POCETNO_STANJE_MIGRACIJE','RELEASE_TO_FREE_STOCK','ASSIGN_FREE_STOCK_TO_PATIENT'},
    'error_category': {'TIME_LIMIT','WRITE_BLOCKED','CHECK_ERROR','VALIDATION','GENERATOR','UNAVAILABLE'},
    'document_kind': {'KARTON','RAZDUZENJE','ZAHTJEV'},
}
KINDS = {'PacijentRezervacija','MigracijskiSnapshotPacijenta','PotrebaFizickogPokrica','PatientDataCorrection','BrzaIzmjenaPacijenta','PacijentZaduzenje','Zaliha','ZalihaTransakcija','MigracijskoPocetnoStanjeZalihe','Pacijent','Lijek','Terapija','Komisija','Provjera','TehnickiDogadjaj'}
KINDS |= {'Trebovanje','KucnaTerapijaPodatak','KucnoIzdavanje','IzdavanjeOralneTerapije'}
KINDS |= {'ClinicalAction','KomisijskiCiklus','PromjenaTerapije'}
KINDS |= {'Termin','TerapijaStatusHistorija','KomisijskaStavkaLijeka','KomisijskiZahtjev'}
KINDS.add('EvidencijaSaglasnostiZaprimanja')
ENUMS['request_status']={'nacrt','potvrdjen','poslan','ceka_saglasnost','odluceno'}
ENUMS['receipt_state']={'UNLINKED_BULK','UNRESOLVED_HISTORY','NO_RECEIPT_RECORD','LINKED_RECEIPT'}
ENUMS['appointment_status']={'ZAKAZAN','OBAVLJEN','ODGODJENA','PAUZIRANA','NIJE_DOSAO','OTKAZAN','PONISTENA'}
ENUMS['workflow_status']={'POTVRDJENA','PONISTENA'}

INVENTORY_COUNTS = {'patients_checked','stocks_checked','presentations_checked','reservations_checked',
    'active_reservations_checked','movements_checked','allocation_unknown','patients_without_assignments','catalog_without_inventory'}
INVENTORY_COUNTS |= {'patients_loaded','stocks_loaded','presentations_loaded','reservations_loaded',
                     'reservations_skipped','active_reservations_loaded','movements_loaded'}


def allowed_values(values):
    result={}
    for key,value in values.items():
        if key in NUMBERS and (value is None or re.fullmatch(r'-?\d{1,10}(\.\d{1,4})?',str(value))):
            result[key]=value
        elif key in BOOLS and type(value) is bool:
            result[key]=value
        elif key in DATES and (value is None or re.fullmatch(r'\d{4}-\d{2}-\d{2}',str(value))):
            result[key]=str(value)[:7] if value else None
        elif key in ENUMS and value in ENUMS[key]:
            result[key]=value
    return result


def export_report(run, *, finding_id=None):
    # Never copy arbitrary titles, descriptions, paths, record IDs or raw logs.
    findings=[f for f in run['findings'] if f['code'] in CHECKS and (not finding_id or f['id']==finding_id)]
    wanted={key for f in findings for key in f['evidence_ids']}
    evidence=[]
    local_aliases={}
    for item in run['evidence']:
        if item['id'] not in wanted or item['kind'] not in KINDS:
            continue
        key=(item['kind'],item['record_id'] if item['record_id'] is not None else item['id'])
        alias=local_aliases.setdefault(key,f'Zapis-{len(local_aliases)+1:03d}')
        evidence.append({'id':item['id'],'record':alias,'type':item['kind'],'values':allowed_values(item['values'])})
    valid_refs={e['id'] for e in evidence}
    displayed=inventory_display(run)
    presentation_proof=[]
    for stock in displayed['stocks']:
        selected=[f for f in stock['checks'] if f in findings]
        if not selected:
            continue
        statuses={f['status'] for f in selected}
        presentation_proof.append({
            'record':local_aliases.setdefault(('Lijek',stock['drug_id']),f'Zapis-{len(local_aliases)+1:03d}'),
            'confirmed_issue':'ISSUE' in statuses,'needs_review':'REVIEW' in statuses,
            'incomplete':bool(statuses & {'UNKNOWN','ERROR'}) or (not finding_id and stock['incomplete']),
            'finding_ids':[f['id'] for f in selected],
            'counts':{k:sum(f['status']==k for f in selected) for k in ('ISSUE','REVIEW','UNKNOWN','ERROR')}})
    return {'application_version':run['version'], 'check_version':run.get('check_version',CHECK_VERSION),
        'status':run['status'], 'period':run['started_at'][:7],
        'execution_status':run.get('execution_status','UNKNOWN'),
        'inventory':{'complete':run.get('inventory',{}).get('complete',False),
            'summary':displayed['summary'],
            'summary_scope':'ALL_PRESENTATIONS', 'presentations':presentation_proof,
            **{k:v for k,v in run.get('inventory',{}).items() if k in INVENTORY_COUNTS and type(v) is int}},
        'limited_areas':[a for a in run.get('limited_areas',[]) if a in AREAS],
        'scope':[{'area':s['area'],'records':s['records'],'checked':s['checked'],
            **{k:s[k] for k in ('loaded','skipped','unprocessed') if k in s},
            'skip_reasons':{r:n for r,n in s.get('skip_reasons',{}).items() if r in REASONS},
            **({'entity':s['entity']} if s.get('entity') in KINDS else {}),
            **({'operation':s['operation']} if s.get('operation') in {'scan','reconcile'} else {})}
            for s in run['scope'] if s['area'] in AREAS],
        'unexamined_areas':[a for a in run['unexamined_areas'] if a in AREAS],
        'not_implemented':[{'code':k,'description':NOT_IMPLEMENTED[k]} for k in run.get('not_implemented',[]) if k in NOT_IMPLEMENTED],
        'findings':[{'id':f['id'],'code':f['code'],'area':f['area'],'status':f['status'],
            **finding_contract(f['code'],f['status']),
            'title':CHECKS[f['code']][0],'possible_cause':CHECKS[f['code']][1],'next_check':CHECKS[f['code']][2],
            'reason_codes':[r for r in f.get('reason_codes',[]) if r in REASONS],
            'reason_labels':[REASONS[r] for r in f.get('reason_codes',[]) if r in REASONS],
            'evidence_ids':[ref for ref in f['evidence_ids'] if ref in valid_refs]} for f in findings],
        'quantity_trails':[{
            'record':local_aliases.setdefault(('Lijek',s['drug_id']),f'Zapis-{len(local_aliases)+1:03d}'),
            'steps':[{'key':p['key'],'values':allowed_values({p['key']:p['quantity'],'unit':p['unit'],
                'known_subtotal':p.get('known_subtotal')}),
                'evidence_ids':[e for e in p['evidence_ids'] if e in valid_refs]}
                for p in s.get('quantity_trail',[]) if p['key'] in NUMBERS and any(e in valid_refs for e in p['evidence_ids'])]
            } for s in run.get('inventory',{}).get('stocks',[]) if any(
                e in valid_refs for p in s.get('quantity_trail',[]) for e in p['evidence_ids'])],
        'receipt_groups':[{
            'cycle':local_aliases.setdefault(('KomisijskiCiklus',g['cycle_id']),f'Zapis-{len(local_aliases)+1:03d}'),
            'finding_ids':[f for f in g['finding_ids'] if any(x['id']==f for x in findings)],
            'presentations':[{'record':local_aliases.setdefault(('Lijek',p['medicine_id']),f'Zapis-{len(local_aliases)+1:03d}'),
                'values':allowed_values(p['values']), 'evidence_ids':[e for e in p['evidence_ids'] if e in valid_refs]}
                for p in g['presentations'] if any(e in valid_refs for e in p['evidence_ids'])]
            } for g in run.get('receipt_groups',[]) if any(f['id'] in g['finding_ids'] for f in findings)],
        'evidence':evidence,
        'limitations':['Obuhvat je ograničen navedenim provjerama i limitima.',
            'Brojanje frižidera nije izvršeno ovom provjerom.',
            'Oznake zapisa vrijede samo unutar ovog izvještaja. Smanjenje podataka nije garancija anonimnosti.',
            'Provjera ulaza dokumenta nije potvrda uspješnog generisanja ili štampe.']}
