# Administratorska dijagnostika

Razvojni modul, verzija provjera `admin-diagnostics-9`. Ne mijenja poslovne podatke
i nije automatska popravka. Verzija aplikacije i update kanal ostaju nepromijenjeni.

## Sljedivost transfera — admin-diagnostics-9 (25.09.2026)

`allocation_trace.py` je adapter postojećeg popisa zaliha i `ALLOCATION_BALANCE`,
bez vlastite baze, akcija popravke ili drugog izvještaja. Provjerava graf
`EvidencijaSaglasnostiZaprimanja.fizicka_transakcija/rezervacija` → izvorna
rezervacija → `BrzaIzmjenaPacijenta` → odredišna rezervacija. Računa izvor +
ulazni transferi − eksplicitni učinci terapija/izdavanja − izlazni transferi.
Različiti prijemi istog dana ostaju povezani svojim ID-ovima; dva ulaza u jednu
rezervaciju čine njen dokazani zajednički osnov, bez FIFO pripisivanja jednog
prenesenog pena određenoj pošiljci ili seriji.

Novi transferi u postojećem JSON tragu čuvaju izričite veze prijema i numeričko
stanje prije/poslije, uz FK obje rezervacije i postojeći idempotency ključ.
`inventory_trace.explicit_receipt_basis` omogućuje provjeru izvora kada ista
rezervacija ima ulaz po zahtjevu i ulaz po ciklusu. Provjerava količinski budžet
svakog vezanog fizičkog ulaza; ne bira zamjenski prijem po datumu/količini.
Ne mijenjaju se komisijsko pravo ni fizički saldo zbog transfera.

Nepovezani historijski prijem, nepotpuni učinci izdavanja, nepouzdane naknadne
korekcije i nepodržana per-rezervacijska historija oralnih izdavanja ostaju
UNKNOWN. Eksplicitno pogrešan pacijent/prezentacija, prekoračen izvor ili saldo
različit od dokazanog očekivanja daje ISSUE. Cikličan graf je neispravna veza;
lanac duži od 100 koraka ostaje UNKNOWN (ograničenje obuhvata).

Regresije: `patients.test_transfer_diagnostics`; dokazi prije/poslije,
read-only otisci i izvještaj: `output/transfer-trace-20260925/`. Nema novih
migracija, backfilla, brisanja kartona ili pripreme ambulantnog paketa.

## Tačni operativni scenariji — admin-diagnostics-8 (25.09.2026)

`COMMISSION_COVERAGE` više ne označava zahtjev kao moguću prekomjernu nabavku
samo zato što sadašnje pokriće traje duže od procijenjene isporuke, kada
kanonski obračun izričito pokazuje nepokrivenu potrebu u kasnijem periodu.
Količine se preuzimaju iz postojećeg obračuna; nema novog računanja doza ili
salda. Nedostajući period/potreba ne pretvaraju se u dokaz opravdanosti.
Izvoz i UI prikazuju `later_uncovered_period`; procjena isporuke ostaje
označena. Potpuni `MEDICINE_TRAIL/OK` više nema kontradiktornu oznaku
`TRAIL_PARTIAL`.

`patients.test_diagnostics_scenarios` provjerava tražene količine, stvarni
ValidationError iz modela, rollback/replay i nepromijenjene otiske pri
svakom pokretanju enginea. Odvojeni su potpuno povezani kontrolni slučaj
i namjerno nepotpuna historija. Aktivnih pet TEST kartona se ne mijenja.

Tada otvoreni transfer 1 pena T01 → T02 (7/5, fizički 12) dokumentovan je
u `output/diagnostics11/`. Verzija 9 iznad zatvara taj slučaj dokazom obje
rezervacije; stariji sačuvani izvještaji nisu prepisani.

## Trag prijema i izvori svake količine — admin-diagnostics-7 (25.09.2026)

Ova sekcija ima prednost nad historijskim opisima ispod. Nastavlja isti engine,
UI, dozvole, cache i očišćeni izvoz; nema drugog dijagnostičkog sistema.

- `MEDICINE_TRAIL` povezuje odobreno, neto zaprimljeno, stanje, rezervisano,
  slobodno, izdato kući i potvrđenu primjenu s vlastitim izvorima iste
  prezentacije/jedinice. Podzbirovi dostupne historije nisu doživotni promet.
  Nema pretvaranja nedostajućeg podatka u nulu; nepotvrđeno izdavanje ne daje
  ni poznati nulti podzbir. Plansko nezaprimljeno posebno je označeno kao
  administrativni obračun, a ne dokaz fizičke neisporuke.
- `receipt_proofs` provjerava svaki fizički ulaz zasebno, sve njegove
  raspodjele, neto količinu, ciklus, pacijenta i prezentaciju. Jedan ulaz
  ne može biti ponovo pripisan. Višestruki historijski snapshotovi s istim
  ukupnim zbirom nisu dokaz jedinstvene raspodjele. Stari jednoznačni ulazi
  s potpunim dokazima ostaju provjerljivi bez upisivanja naknadnih veza.
- `RECEIPT_PROGRESS` ostaje UNKNOWN kada nema dokaza prijema. Prag 30 dana
  označava provjeru otpremnice; nije dokaz greške niti neisporuke. Prikazuje
  se zajednički bruto ulaz, povezana korekcija i neto, uz nerazjašnjene
  pojedinačne veze. `receipt_groups` grupiše povezane zahtjeve po ciklusu.
- Nalazi imaju ISSUE/REVIEW/UNKNOWN/OK, pravilo, pouzdanost, količine,
  izvore i narednu provjeru. UI otvara ciklus, karton ili dokaze jedne
  brojke. Izvoz dodaje alias grupe ciklusa i `quantity_trails`; ne prenosi
  lokalne identitete, URL-ove, operation UUID ili slobodni tekst.
- Dijagnostika, pregled i preuzimanje ostaju read-only, uključujući audit.
  AI je isključen; nije uvedeno vanjsko slanje ili model za računanje.

Odvojeno od čitanja dijagnostike, obične buduće radnje prijema/korekcije
bilježe izvor preko `patients.inventory_trace` i aditivne migracije
`0106_inventory_provenance`: UUID radnje, jedinica u trenutku knjiženja,
izričiti ciklus/izvorni promet te fizički ulaz i rezervacija evidencije prijema.
FK-ovi su opcionalni za historiju, nema data backfilla. Nova veza nastaje u
istoj atomskoj operaciji; zaključavanje i ograničenje sprečavaju ponovno
trošenje ulaza. Dijagnostika nikada ne poziva taj writer.

Dokaz: `output/diagnostics9/IZVJESTAJ.md`. V6 i V7 su pokrenuti na istoj
izdvojenoj PostgreSQL kopiji, uz jednake otiske svih 53 patients/auth modela
prije/poslije. Rezultat: 258 OK / 120 UNKNOWN / 8 REVIEW, bez ISSUE/ERROR.
308 testova prošlo je u objedinjenom prolazu; nakon posljednje dopune
poznatih podzbirova prošla su još 33 ciljana testa (preklapaju se).

## Aktivne provjere izvora — admin-diagnostics-6 (25.09.2026)

Nadogradnja postojećih adaptera, istog pokretanja, UI-ja i očišćenog izvoza.
Nema nove baze, modela, migracije, poslovnog write servisa ili AI obračuna.
Lokalno pokretanje i preuzimanje su read-only i za AktivnostLog; privremeni
rezultat ostaje u postojećem cacheu. Dozvole administratora, CSRF, potpis izvoza,
SQL READ ONLY, query guard, dosljedni presjek i vremenski limiti ostaju aktivni.

- Svaki nalaz nosi `rule`, `confidence`, `confidence_label`, razloge, količine
  s jedinicama, lokalne izvore i narednu provjeru. HIGH označava pouzdanost
  kontradikcije/pravila, ne uzroka ili kliničke odluke. REVIEW je MEDIUM;
  UNKNOWN/ERROR su UNDETERMINED. Ove vrijednosti ne određuje jezički model.
- `free_fridge` je potpisana razlika fizičko − rezervisano. Negativna vrijednost
  je dokaziva kontradikcija raspodjele (ISSUE). Nedostajući fizički red i dalje
  daje null. Zbirovi zaprimanja/izdavanja označeni su kao dostupna historija,
  ne ukupna historija prije migracije; početna zaliha se ne proglašava prijemom.
- `receipt_proofs` koristi postojeću `EvidencijaSaglasnostiZaprimanja`.
  Pacijent/ciklus/prezentacija i cijeli zbirni neto ulaz moraju se slagati prije
  nego što se potvrdi pojedinačna raspodjela. Reverzne korekcije računaju se
  jednom; stari snapshot nakon poništavanja bez jedinstvene raspodjele ostaje
  UNKNOWN. Direktni ulaz i zbirni ulaz ne dodaju se ponovo odobrenju.
- Rezervacija nastala prijemom može se razriješiti samo uz jedinstven izvor,
  dokazanu raspodjelu i izričite učinke rezervacije. Prijenosi, korekcije,
  više historijskih rezervacija i oralni izlazi bez pojedinačnih učinaka ostaju
  ograničenje. Odvojeno se otkrivaju raspodjela iznad prijema i mogući dupli redovi.
- Komisija prikazuje traženo, odobreno, stvarno neto zaprimljeno i trenutno
  raspodijeljeno. Zahtjev koji još čeka odluku može imati provjerenu fazu uz
  null odobreno/zaprimljeno. Postojeće odobrenje bez količine na modernoj
  stavci ostaje UNKNOWN s konkretnim razlogom. Ručno isključen zapis nije
  zahtjev i nije lažna količinska greška. Ponavljanja se grupišu po tačnom
  pacijentu/prezentaciji/ciklusu; drugi ciklus nije duplikat.
- Djelimičan prijem je valjano stanje. Prag ≥30 dana od odobrenja ili prošao
  očekivani datum izdvajaju REVIEW za otpremnicu/preostalu isporuku, bez
  proglašenja gubitka. Prag je eksplicitno prikazan u dokazu i izvozu.
- Pakovanje se konvertuje samo eksplicitnim brojem tableta ili definisanim
  fizičkim jedinicama pakovanja. Podrazumijevani faktor 1 nije izmišljena
  konverzija. IV, SC, PO, doze i jedinice različitih prezentacija se ne spajaju.
- Izjava o kućnom ostatku ima povezane izvore knjigovodstvenog poređenja.
  Izdavanje, potvrđena primjena, izjava i procjena ostaju odvojeni.

Sažetak filtrira ISSUE/REVIEW/UNKNOWN, a pojedinačni red otvara činjenice i
radnju „Šta provjeriti — izvori i dokazi”. Filter ne mijenja obuhvat izvoza.
Izvoz proširuje postojeću pozitivnu listu i zadržava lokalne alias oznake;
ne prenosi identitete pacijenata, brojeve saglasnosti, ciklus ID ili slobodni tekst.
AI ostaje isključen; postojeći adapter dodatno zabranjuje modelu računanje
salda/konverzija. Nije aktivirano nikakvo slanje van instalacije.

Regresije: `dashboard/test_diagnostics_active.py` uz sve ranije testove.
Primjeri, poređenje sa 140 UNKNOWN / 8 REVIEW i devet prezentacija, tačne
provjere i ograničenja: `output/diagnostics-active/IZVJESTAJ.md`.
Stari opisi faza ispod predstavljaju razvojnu historiju; ova sekcija ima prednost.

## Faza 1 — vjerodostojnost rezultata i izvori prometa (23.09.2026)

- `home_summary.home_summary()` razlikuje nedostajuću izjavu, zastarjelu izjavu
  nakon novog izdavanja i izričitu nulu. `reported_remaining` je `null` dok nisu
  poznate izjave za sve obuhvaćene osobe; `reported_subtotal` i brojevi izjava
  ostaju zasebni. Historijske izjave nisu dokaz današnjeg fizičkog brojanja.
- Interna veza nalaza s prezentacijom (`medicine_ids`) prenosi i nepovezani
  migracijski izvor i `QUANTITY_INVARIANT` u status lijeka. Ne izvozi lokalne
  ID-jeve. Neslaganje i nepotpunost su nezavisne oznake; sažetak ih ne sabira.
- `movement_audit.check_movements()` provjerava oba smjera veze između
  `Terapija`, `KucnoIzdavanje`, `IzdavanjeOralneTerapije` i prometa. Poredi
  pacijenta, tačnu prezentaciju, poznatu jedinicu, zbir izlaza, zbir povrata i
  fizički učinak. Količina radnje je stvarno evidentirana količina, ne mg doze.
  Valjani dijelovi 1 + 3 nisu duplikat. Kućno izdavanje i njegov zapis terapije
  provjeravaju se zajedno; kućna primjena ne stvara drugi izlaz.
- Poništavanja koriste iste oznake izvora/statusa kao poslovni servis i mjesečni
  izvještaj. Zamjenska terapija je zasebna radnja. Djelimični povrat povezan s
  izlaznom transakcijom ne proglašava se automatski potpunim poništavanjem.
  Nepostojeći izričit izvor je greška; odsustvo historijskog prometa ograničenje.
- Poznati neterapijski izvori provjeravaju se po postojanju i dostupnom
  identitetu, bez poređenja delta korekcije s trenutnom količinom promjenjivog
  izvora. Njihova klinička potrošnja nije primjenjiva. Slobodni tekst i nepoznate
  konverzije ostaju ograničenje. Ne rekonstruira se izmišljena historija jedinica.
- `scope` razdvaja `records`, `loaded`, `checked`, `skipped`, `unprocessed`,
  `skip_reasons` i učitavanje od usaglašavanja. Preskočeno zbog nepoznatih ulaza
  ne ulazi u `checked`. Jedan zapis može učestvovati u više različitih provjera;
  brojevi kroz oblasti nisu zbir jedinstvenih pacijenata.
- SQL READ ONLY, dosljedni presjek, zaštita od upisa i postojeći vremenski/SQL
  limiti ostaju aktivni. Poslovni servisi za izmjenu se ne pozivaju. Postojeći
  zasebni audit bilježi pokretanje/preuzimanje, bez izmjene poslovnih podataka.

**Naredna faza:** termini, potpuno kućno usaglašavanje i komisijske veze po
ciklusima. `not_implemented` je vidljiv na ekranu i u izvozu; završeno izvršavanje
ove faze nije potvrda da je cijeli sistem potpuno provjeren.

Testovi: `dashboard.test_diagnostics_phase1` i postojeći dijagnostički skupovi.
Dokaz i status svih osam reprodukcija: `output/diagnostics-phase1/IZVJESTAJ.md`.

## Pristup i korištenje

Dopuna „Svi pacijenti i zaduženja u frižideru“, 21.09.2026:

- Jedan poziv obuhvata sve pacijente (i neaktivne), sve prezentacije s evidencijom,
  sva aktivna i zatvorena zaduženja, sav promet, migracijske izvore, terapijske
  učinke, ispravke i prijenose. Paginacija po ID-u od 500 zapisa ne ograničava
  ukupan broj; ne koristi se uzorak od 300 za popis zaduženja.
- Tabela razdvaja svaki konkretan `Lijek`/SKU, jačinu, oblik, put primjene i
  kanonsku jedinicu. Budući termin je podskup fizički zaduženog. Čekanje fizičkog
  pokrića i nezaprimljeno odobrenje nisu fizička zaliha i mogu se preklapati.
- Kućna zaduženja prikazuju evidentirani ostatak, a ne procijenjenu primjenu.
  Oralna procjena, nepoznat ostatak ili razlika prema izjavi ne prikazuju se kao
  potvrđena nula. Izvorno izdavanje i izjava s datumom dostupni su u dokazima.
- Pojedinačni očekivani saldo koristi jednoznačno povezani migracijski izvor
  ili prijenos, preostalu potrebu pokrića i eksplicitne učinke potvrđenih
  terapija. Poništene terapije se ne odbijaju ponovo. Potrošnja istog pacijenta
  bez veze s rezervacijom ne raspoređuje se nagađanjem. Stari zajednički ulazi,
  nedokumentirano zatvaranje ili nepotpuna migracija ostaju ograničenje.
- Prikazani su očekivano, evidentirano, razlika i događaji. Migracijska tražena
  alokacija jasno je odvojena od potvrđenog ukupnog početnog stanja frižidera.
- `inventory.complete` označava završeni popis/analizu zaduženja. Brojevi svake
  faze, uključujući neobrađeni ostatak u slučaju prekida, nalaze se u `coverage`.
  Izvoz ima pozitivno dopuštene brojače, `scope.entity` i `scope.operation`.
  Drugi postojeći limiti (vrijeme, ukupna historijska analiza, komisijski planer)
  ostaju zaštita; prekid nikada ne postaje potvrda urednosti.

Dokaz: `output/diagnostics-all-stock/IZVJESTAJ.md`. Nema nove migracije niti
promjene poslovnih servisa, količina, korisnika, konfiguracije ili update kanala.

Dopuna nakon analize razvojnog izvještaja 21.09.2026: `execution_status` odvojeno
opisuje završetak pokretanja. `status=PARTIAL` uz `execution_status=COMPLETED`
znači da su predviđene provjere izvršene, ali nedostaju ulazi za pouzdan zaključak.
`reason_codes` i statički `reason_labels` prikazuju konkretne razloge na ekranu
i u očišćenom izvozu. `limited_areas` označava obuhvat ograničen brojem zapisa ili
vremenom; nepoznat podatak nije automatski tehnički pad. Stari sačuvani rezultat
pri izvozu zadržava svoju verziju provjera; za nove razloge treba pokrenuti novu provjeru.

Za jedinicu se koristi `Lijek.jedinice_zalihe`, uključujući postojeći fallback za
starije zapise s generičkom jedinicom „doza“. Komisijski detalji čitaju završni
`CommissionDecision` ili postojeći `oralni_obracun`; ne računaju se ponovo.
Nepostojeći datum perioda se ne izmišlja. Oralni izvor može umjesto datuma imati
ciljni broj dana. Delta korekcije koje referenciraju isto postojeće početno stanje
prikazuju se kao `STOCK_CORRECTION_HISTORY`, jer ta veza nije ID jedne operacije.
To ne potvrđuje ispravnost svakog iznosa: provjera salda ostaje zasebna, a drugi
ponovljeni ili nepostojeći izvori zadržavaju status sumnje.

Dokaz dopune: `output/diagnostics-report-review/IZVJESTAJ.md`.

Pristup je **Postavke → Sistemske postavke → Administratorska dijagnostika**, odnosno
`/postavke/dijagnostika/`, administrator bira **Pokreni provjeru**. **Pokaži dokaze**
otvara izračun, lokalne ID-jeve i poveznice, mogući uzrok označen kao hipoteza,
preporučenu provjeru i ograničenja. Djelimičan rezultat ne proglašava ostale
oblasti ispravnim. Broj provjerenih zapisa povećava se tek nakon obrade zapisa.

Pristup svih osam endpointa provjerava `dashboard.permissions.je_admin`: grupa
`Admin` ili superuser. `is_staff` sam nije dovoljan. Pokretanje, preuzimanje i AI
slanje zahtijevaju POST i CSRF. Rezultat pripada administratoru koji ga je pokrenuo.

## Postojeća poslovna logika

| Oblast | Ponovo korišteni servis / pravilo |
| --- | --- |
| Fizička zaliha | `patients.inventory.izracunaj_frizider_iz_transakcija` |
| Pouzdan početak i historija | `patients.fridge_history.fridge_balances_at` |
| Efektivne rezervacije | `patients.inventory.patient_reservation_breakdown` |
| Komisija | `patients.commission_planning.commission_planning_rows`, cijeli podržani skup pacijenata |
| Kućna terapija | `patients.home_therapy_evidence.home_evidence` |
| Podaci prezentacije | `patients.medicine_document_metadata.presentation_metadata` |
| Saglasnost dokumenta | `treatment_review_commission`, `approval_document_values`, stroga ekvivalencija prezentacije |
| Negativne količine | Skalarne invarijante iz `patients.integrity`, bez pokretanja njegovih neograničenih provjera |
| Audit | Postojeći `AktivnostLog`, bez novog modela |

Nema paralelnog obračuna komisije ili inventara. Nedovoljna historija nije nula.
Rezervacija iznad evidentirane fizičke zalihe je ISSUE raspodjele, bez tvrdnje o uzroku ili pogrešnoj potrošnji. Više kretanja istog izvora je
sumnja, ne dokaz dupliranja. Izdavanje kući nije datum primjene. Fizičko brojanje
nije obavljeno dijagnostikom. Oblik, jačina, put primjene i jedinica ostaju odvojeni.

Provjera dokumenata provjerava ulaze i pripadajuću vezu; ne generiše masovno PDF-ove
i ne tvrdi da je štampa uspjela. Sintetički testovi stvarno pozivaju postojeće
generatore kartona i razduženja, te provjeravaju PDF tekst i očuvanje poslovnih redova.

## Zaštita od upisa i ograničenje rada

`readonly.diagnostic_snapshot` koristi novu PostgreSQL transakciju
`REPEATABLE READ READ ONLY`, uz SQL zaštitu od upisa i svjež lokalni cache.
Skriveni `get_or_create` u komisijskim postavkama zaobilazi se samo učitavanjem
postojećih postavki u taj cache. Nedostajuće postavke se ne kreiraju.
Kontekst bočne navigacije ne pokreće poslovne izračune na dijagnostičkim ekranima.
Od verzije 6 pokretanje i preuzimanje lokalne dijagnostike ne upisuju ni audit.
Rezultat se čuva samo u postojećem privremenom cacheu. Odvojeni, isključeni AI tok
zadržava postojeće zaštite i audit nakon posebno odobrenog slanja.

Podrazumijevani limit je 15 s; pojedinačni PostgreSQL upit najviše 1,5 s.
Limit je 300 zapisa po ograničenom skupu, 150 aktivnih pacijenata za cijeli komisijski
planer i 20.000 kretanja za cijeli obračun historije. Veći zajednički komisijski skup
se preskače uz jasno ograničenje; ne računa se uzorak koji bi pogrešno raspodijelio
zajedničku zalihu. Vremenski limit se provjerava na upitima, ne prekida proizvoljan
Python CPU poziv. Veliki sintetički skup i prekid su zasebno testirani.

Rezultati i njihove lokalne mape vrijede 30 minuta u postojećem Django cacheu.
U zadanoj konfiguraciji cache je procesni: restart briše rezultate; više procesa
nema zajedničke rezultate/lock. Modul nije trajni arhiv niti distribuirani nadzor.
SQLite read-only fallback postoji, ali završni testovi ovog zadatka koriste PostgreSQL.

Middleware za štampu čuva samo UUID, vrijeme, vrstu dokumenta i kategoriju greške:
najviše 100 događaja / 24 h. Sačuvan je originalni HTTP odgovor i dodat
`X-TheraFlow-Event`. Sirovi logovi i stare greške nisu analizirani. Događaj nema
pacijentske identifikatore; za povezivanje konkretnog zahtjeva služi ID događaja.

## Očišćeni izvoz i opcionalni AI

Izvoz koristi pozitivnu listu dozvoljenih tipiziranih polja. Ne prenosi lokalne
ID-jeve, nazive pacijenata/lijekova iz slobodnih polja, dijagnoze, putanje, bilješke,
kontakte, sirove logove niti tajne. Datumi su svedeni na mjesec. Oznake `Zapis-001`
važe samo u tom izvještaju. Smanjenje podataka nije dokaz potpune anonimnosti.
Administrator prvo vidi tačan JSON. Potpisani token veže preuzimanje/slanje za
taj sadržaj, korisnika, nalaz i pokretanje. Izvoz se ne šalje automatski.

Adapter je izdvojen u `ai.py`. Provjerena je službena dokumentacija
[OpenAI Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
za Responses API i `text.format` sa strogom JSON shemom. Koristi se fiksni HTTPS
endpoint `/v1/responses`, `store: false`, bez tools, SQL-a, komandi, redirecta i
automatskih ponavljanja. Ključ je samo HTTP autorizacija na serveru.

Odgovor mora imati pet cjelina i poznate reference na dokaze. Neispravna struktura,
nepoznate reference, odbijanje, nepotpun ili prevelik odgovor se odbacuju. Linkove
na lokalne zapise stvara aplikacija. Strukturna provjera ne dokazuje činjeničnu
tačnost svakog teksta modela: AI objašnjenje je odvojeno od lokalnih nalaza.

Limit zahtjeva je 24 KB, odgovora 64 KB / 1.200 tokena; mrežni timeout zadano 8 s.
Jedan pokušaj istog nalaza u minuti i razmak 30 s po administratoru; uspješan odgovor
se privremeno čuva. DNS/realna mrežna latencija nije potvrđena stvarnim API pozivom.
Postavka `store: false` nije zamjena za ustanovino odobrenje obrade podataka.

### Serverska konfiguracija

Lokalni modul početno radi: `ADMIN_DIAGNOSTICS_ENABLED=true`. Za isključenje postaviti
`false` u serversko okruženje i ponovo pokrenuti razvojnu aplikaciju.

Vanjsko slanje je početno isključeno. Za budući odobreni test trebaju **sve** postavke:

```text
DIAGNOSTICS_AI_ENABLED=true
DIAGNOSTICS_EXTERNAL_AI_APPROVED=true
DIAGNOSTICS_AI_PROVIDER=openai
DIAGNOSTICS_AI_MODEL=<model koji podržava strogi JSON izlaz>
DIAGNOSTICS_OPENAI_API_KEY=<ključ samo na serveru>
```

Postavke se učitavaju pri pokretanju. Ključ ne unositi u kod ili browser.
Prvo koristiti samo sintetičke podatke i pregledati sadržaj prije potvrde slanja.
Ovim zadatkom nisu izmijenjeni `.env` niti aktivirana ova dva prekidača.
**Stvarni AI poziv nije izvršen: nema konfigurisanog ključa/modela ni aktivacije.**
Provjereni su kontrolisani odgovori, timeout, odbijanje, format, reference i očuvanje podataka.

## Lokalna provjera

Namjenski PostgreSQL UI skup i testna baza su odvojeni od redovne razvojne baze:
`diagnostics_ui` i `test_admin_diagnostics` na lokalnom testnom klasteru, port 55437.
Privremeni server koristi iste izvorne datoteke, `settings_diagnostics` iz
`output/admin-diagnostics`, zasebne kolačiće i sintetički media direktorij.

```powershell
$env:PYTHONPATH="$PWD\output\admin-diagnostics;$PWD"
.\.venv\Scripts\python.exe -B manage.py test dashboard.test_admin_diagnostics --settings=settings_diagnostics --keepdb --noinput
.\.venv\Scripts\python.exe -B manage.py runserver 127.0.0.1:8095 --settings=settings_diagnostics --noreload
```

`seed_ui.py` je jednokratna izrada sintetičke baze; odbija ponovno kreiranje postojeće
baze. Ne pokretati taj seed nad drugim postavkama ili ambulantnom bazom.
Korisnik sintetičke instance je `diagnostika-admin`, lozinka `Dijagnostika-test-2026!`.
To nije račun redovne aplikacije niti ambulante.

Nisu potrebne nove migracije, biblioteke ili promjene pakovanja. Detaljni rezultati,
poznati prethodni padovi regresija, logovi i screenshots su u
`output/admin-diagnostics/IZVJESTAJ.md`. Ovaj zadatak ne odobrava objavu ili instalaciju.

## Faza 2 — admin-diagnostics-5 (23.09.2026)

`appointment_audit.py` provjerava zasebnu oblast termina: budući aktivan termin
neaktivnog pacijenta, tačan ključ duplikata iz `schedule_therapy_appointment`,
veze/status prema `workflow_snapshot.termin_id` i statusnoj historiji te datirane
naloge preko read-only `appointment_plan`. Zatvorena historija ne poredi se s
današnjim aktivnim statusom. Ručna odluka i odgoda se poštuju; novi interval bez
naknadne odluke o rasporedu je REVIEW, ne automatsko pomjeranje. Nema medicinske
procjene optimalnog datuma. `patients.integrity.run_database_integrity_check`
nije pozvan kao cjelina: njegova provjera neaktivnih uključuje i historijske
termine, a dodatni pomoćni tokovi nisu potrebni ovom ograničenom adapteru.

Značenje kućnih podataka (provjereno prema stvarnim servisima):

| Evidencija | Značenje i korištenje |
| --- | --- |
| `PacijentZaduzenje.ukupno_zaduzeno/preostalo` | Knjigovodstvena raspodjela, ne potvrđeno fizičko brojanje. Izvor je povezano izdavanje ili migracijski početak. |
| `Zaliha.kod_pacijenata` | Zbirni injekcijski saldo; kućno izdavanje ga povećava, dokumentovana primjena smanjuje, poništavanje vraća učinak. |
| `KucnoIzdavanje` + vezana `Terapija` | Jedno izdavanje, ne dvije primjene. `zaduzenje_izdavanje` bilježi povećanje raspodjele. |
| `Terapija.workflow_snapshot.zaduzenja_promjene` | Izričito evidentirane količine iz pojedinačnih zaduženja; provjera izvora, identiteta i zbira. Kućna primjena nema drugi izlaz iz frižidera. |
| `KucnaTerapijaPodatak.IZJAVA` | Ostatak prema pacijentu na `datum_provjere`, ne promet. Nula je poznata; null nije nula. Izjave različitih datuma ne čine jedinstven saldo. |
| Migracijski snapshot | Historijski početak samo uz jednoznačno povezano početno kretanje. Naknadne promjenjive korekcije bez pouzdanog datiranog presjeka ostaju UNKNOWN. |
| `IzdavanjeOralneTerapije` | Stvarno izdate tablete jesu izlaz iz frižidera. Servis ne povećava `Zaliha.kod_pacijenata`; vremenski izračunat ostatak je projekcija. Ne poredi se sa injekcijskim zbirnim saldom kao dokaz manjka. |

`home_audit.py` obračunava samo povezane učinke i eksplicitne povrate/poništavanja.
`home_summary.py` zasebno prenosi potpunost i datume izjava u UI/JSON. Neslaganje
3 prema 0 može biti dokazano i bez izjave kada je knjigovodstvena historija
potpuna; izjava nije zamjena za knjigovodstvo.

`commission_audit.py` provjerava stvarne veze i količine nezavisno od datuma
isporuke. Djelimični ulazi i izričite reverzne korekcije ulaza računaju se jednom.
Zbirni ulaz ciklusa provjerava se zbirno; nedokumentovana pojedinačna raspodjela
ne nagađa se. Potrošnja i poništavanje koriste izričite komisijske učinke.
Migracijski ostatak ostaje kanonsko pravo, ne izmišljena historija potrošnje.
Opcioni `medicine_ids` u `patient_commission_coverage` omogućuje izvještaj po
tačnoj prezentaciji istim pravilima, uključujući migracijske izuzetke. Pozivi bez
tog argumenta zadržavaju prethodnu kliničku grupu i obračun. Slobodna zaliha se
ovdje ne dodjeljuje. Projekcija zadržava globalni `commission_planning_rows`;
prelazak njegovog limita preskače cijeli planer, nikad ga ne pokreće po stranicama.

Sažetak razlikuje ISSUE, REVIEW i UNKNOWN/ERROR; broje se prezentacije, ne nalazi.
Svaka ima reference na konkretne F-oznake. U očišćenom izvozu one i Zapis-oznake
vrijede samo unutar izvještaja; ne izvoze se lokalni identifikatori ni nazivi.
Nedostajući broj saglasnosti je dokumentacijski REVIEW, ne dokazan manjak lijeka.

Trajne regresije: `dashboard/test_diagnostics_phase2.py`, uz sačuvane i dopunjene
regresije faze 1. Dokazi, ograničenja i završni rezultat:
`output/diagnostics-phase2/IZVJESTAJ.md`. Nema novih migracija, objave ili izmjene
poslovnih podataka; pristup i SQL/time/write zaštite ostaju na serveru.
