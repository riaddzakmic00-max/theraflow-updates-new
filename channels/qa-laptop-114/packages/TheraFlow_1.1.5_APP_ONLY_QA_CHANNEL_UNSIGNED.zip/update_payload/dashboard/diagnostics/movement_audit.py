"""Bidirectional, read-only checks of recorded clinical actions and stock effects.

Reuse the reporting service's source/cancellation semantics. Never infer a
clinical event, allocate an unlinked movement, convert an unknown unit, or
merge two presentations. Clinical quantities and returns are checked separately
so a matching net zero cannot hide an incorrect cancellation.
"""
from collections import defaultdict
from decimal import Decimal

from patients import models as m
from patients.monthly_consumption import OUTFLOW, REVERSALS, source_kind, is_cancelled

ZERO = Decimal('0')
UNITS = {'bočica','pen','šprica','tableta','ampula'}
CLINICAL = {'Terapija':m.Terapija, 'KucnoIzdavanje':m.KucnoIzdavanje,
            'IzdavanjeOralneTerapije':m.IzdavanjeOralneTerapije}
OTHER_SOURCES = {name:getattr(m,name) for name in (
    'MigracijskiSnapshotPacijenta','MigracijskoPocetnoStanjeZalihe',
    'PatientDataCorrection','Trebovanje','KomisijskiCiklus','PromjenaTerapije',
    'PacijentRezervacija','PotrebaFizickogPokrica','Komisija','Zaliha','ZalihaTransakcija','Pacijent')}


def check_movements(run):
    data = run.inventory_records
    if data is None:
        raise ValueError('Inventory census required')
    ledger, drugs = data['ledger'], data['drugs']
    sources = {'Terapija':{x.pk:x for x in data['therapies']},
               'KucnoIzdavanje':{x.pk:x for x in data['issues']},
               'IzdavanjeOralneTerapije':{x.pk:x for x in data['oral']}}
    by_tx = {t.pk:t for t in ledger}
    home_by_therapy = defaultdict(list)
    for issue in data['issues']:
        if issue.terapija_id:
            home_by_therapy[issue.terapija_id].append(issue)
    refs, movements = {}, defaultdict(list)
    invalid_events = set()

    def evidence(obj, values=None):
        key = (type(obj).__name__,obj.pk)
        if key not in refs or values is not None:
            if isinstance(obj,m.ZalihaTransakcija):
                values = {'quantity':obj.kolicina,'event_date':obj.datum,'event_type':obj.tip,
                          'fridge_delta':obj.frizider_delta(),'source_type':obj.referenca_tip,'source_id':obj.referenca_id}
                if obj.operation_id:
                    values.update(operation_id=str(obj.operation_id),cycle_id=obj.komisijski_ciklus_id,
                        unit_snapshot=obj.jedinica_snapshot, original_movement_id=obj.izvorna_transakcija_id)
            refs[key] = run.evidence_for(key[0],obj.pk,patient_id=getattr(obj,'pacijent_id',None),
                medicine_id=getattr(obj,'lijek_id',None),values=values or {})
        return refs[key]

    def canonical(kind, pk):
        if kind=='Terapija' and len(home_by_therapy.get(pk,()))==1:
            return 'KucnoIzdavanje',home_by_therapy[pk][0].pk
        return kind,pk

    # Positive registry only. Custom/free-text references are limitations.
    others = {'ZalihaTransakcija':by_tx}
    for name,model in OTHER_SOURCES.items():
        if name in others:
            continue
        ids = {t.referenca_id for t in ledger if t.referenca_tip==name and t.referenca_id}
        if ids:
            others[name] = {o.pk:o for o in run.scan_all(model.objects.filter(pk__in=ids),
                'Učitavanje izvora prometa — '+name)}

    scope = run.new_scope('stock','ZalihaTransakcija',len(ledger),label='Promet prema izvorima — veze; klinički promet i fizički učinak')
    scope['loaded']=len(ledger)
    run.inventory['coverage'].append(scope)
    for tx in ledger:
        run.checkpoint()
        kind = REVERSALS.get(tx.referenca_tip,tx.referenca_tip)
        pk = tx.referenca_id
        original = None
        if kind=='ZalihaTransakcija' and tx.tip=='POVRAT':
            original = by_tx.get(pk)
            if original and original.tip in OUTFLOW:
                kind = REVERSALS.get(original.referenca_tip,original.referenca_tip)
                pk = original.referenca_id
        source = sources.get(kind,others.get(kind,{})).get(pk)
        tx_ref = evidence(tx)
        status, reasons = 'OK', []
        known_type = kind in CLINICAL or kind in OTHER_SOURCES
        if not known_type or pk is None:
            status,reasons = 'UNKNOWN',['RECEIPT_UNLINKED' if tx.tip=='ZAPRIMANJE' and not kind and pk is None else 'SOURCE_UNSUPPORTED']
        elif source is None:
            status,reasons = 'ISSUE',['SOURCE_MISSING']
        else:
            # Patient's current medicine can differ from a historical release.
            source_drug = None if kind=='Pacijent' else getattr(source,'lijek_id',getattr(source,'stari_lijek_id',None))
            source_patient = source.pk if kind=='Pacijent' else getattr(source,'pacijent_id',None)
            # Free-stock assignment is allowed to reference another patient's
            # release transaction. It is not a clinical transfer or consumption.
            clinical = kind in CLINICAL and tx.tip in {*OUTFLOW,'POVRAT'}
            if (source_drug is not None and source_drug!=tx.lijek_id
                    or source_patient is not None and tx.pacijent_id is not None
                       and kind!='ZalihaTransakcija' and source_patient!=tx.pacijent_id):
                status,reasons='ISSUE',['SOURCE_IDENTITY']
            elif clinical and tx.pacijent_id is None:
                status,reasons='UNKNOWN',['SOURCE_HISTORY']
            elif not clinical:
                # Existence/presentation checked. Clinical quantity comparison
                # does not apply to a mutable migration/correction source.
                reasons=['NON_THERAPEUTIC']
                if tx.tip in {'RELEASE_TO_FREE_STOCK','ASSIGN_FREE_STOCK_TO_PATIENT'}:
                    if tx.frizider_delta()!=ZERO or tx.kolicina<0:
                        status,reasons='ISSUE',['SOURCE_EFFECT']
                    elif kind=='Pacijent':
                        status,reasons='UNKNOWN',['RELEASE_HISTORY']
                elif tx.tip=='ZAPRIMANJE' and (tx.frizider_delta()!=tx.kolicina or tx.kolicina<0):
                    status,reasons='ISSUE',['SOURCE_EFFECT']
            elif drugs[tx.lijek_id].jedinice_zalihe[0] not in UNITS:
                status,reasons='UNKNOWN',['SOURCE_UNIT']
            if clinical:
                key = canonical(kind,pk)
                movements[key].append(tx)
                if status!='OK':
                    invalid_events.add(key)
                home_application = kind=='Terapija' and (source.workflow_snapshot or {}).get('vrsta')=='KUCNA_PRIMJENA'
                expected_delta = ZERO if home_application else (-1 if tx.tip in OUTFLOW else 1)*tx.kolicina
                locations = {'','FRIZIDER','KOD_PACIJENTA'} if home_application else {'','FRIZIDER'}
                if tx.kolicina<0 or tx.frizider_delta()!=expected_delta or tx.lokacija not in locations:
                    # This is a definite wrong physical effect even if the
                    # record also has an unknown unit or missing patient.
                    run.add('MOVEMENT_SOURCE','stock','ISSUE',[tx_ref,evidence(source)],reasons=['SOURCE_EFFECT'])
                    invalid_events.add(key)
        extra=[]
        if tx.operation_id:
            expected_cycle=source.pk if kind=='KomisijskiCiklus' and source else getattr(source,'komisijski_ciklus_id',None)
            if tx.komisijski_ciklus_id and expected_cycle and tx.komisijski_ciklus_id!=expected_cycle:
                status,reasons='ISSUE',['COMMISSION_LINK']
            if tx.jedinica_snapshot and tx.jedinica_snapshot!=drugs[tx.lijek_id].jedinice_zalihe[0]:
                status,reasons='UNKNOWN',['SOURCE_UNIT']
            if tx.izvorna_transakcija_id and (tx.referenca_tip,tx.referenca_id)!=('ZalihaTransakcija',tx.izvorna_transakcija_id):
                status,reasons='ISSUE',['SOURCE_IDENTITY']
            correction=next((c for c in data['corrections'] if c.operation_id==tx.operation_id),None)
            if correction: extra.append(evidence(correction))
        run.add('MOVEMENT_SOURCE','stock',status,
                [tx_ref,*([evidence(source)] if source is not None else []),*extra],reasons=reasons)
        if status=='UNKNOWN':
            run.skip_record(scope,reasons[0])
        else:
            scope['checked']+=1

    all_sources = [*data['therapies'],*data['issues'],*data['oral']]
    source_scope = run.new_scope('stock','ClinicalAction',len(all_sources),label='Primjene i izdavanja prema prometu — količina, izlaz i povrat')
    source_scope['loaded']=len(all_sources)
    run.inventory['coverage'].append(source_scope)
    for source in all_sources:
        run.checkpoint()
        name = type(source).__name__
        key = (name,source.pk)
        if name=='Terapija' and home_by_therapy.get(source.pk):
            if len(home_by_therapy[source.pk])==1:
                run.skip_record(source_scope,'SAME_HOME_EVENT')
                continue
        txs = movements[key]
        source_ref = evidence(source)
        proof = [source_ref,*[evidence(t) for t in txs]]
        unit = drugs[source.lijek_id].jedinice_zalihe[0]
        # Source model stores stock units, oral issuance specifically tablets.
        qty = Decimal(source.kolicina_tableta) if name=='IzdavanjeOralneTerapije' else source.kolicina
        migration = bool(getattr(source,'is_migration',False) or getattr(source,'is_migration_snapshot',False))
        state = source.workflow_snapshot or {} if name=='Terapija' else {}
        home_application = name=='Terapija' and state.get('vrsta')=='KUCNA_PRIMJENA'
        reasons, problem = [], []
        if migration:
            reasons.append('SOURCE_LEGACY')
        if unit not in UNITS or name=='IzdavanjeOralneTerapije' and unit!='tableta':
            reasons.append('SOURCE_UNIT')
        kind = source_kind(source)
        if kind is None and not migration and not home_application:
            reasons.append('SOURCE_HISTORY')
        if key in invalid_events:
            reasons.append('SOURCE_HISTORY')
        if name=='KucnoIzdavanje' and source.terapija_id:
            therapy = sources['Terapija'].get(source.terapija_id)
            if therapy:
                proof.append(evidence(therapy))
                if (therapy.pacijent_id,therapy.lijek_id)!=(source.pacijent_id,source.lijek_id):
                    problem.append('SOURCE_IDENTITY')
                elif therapy.kolicina!=qty:
                    problem.append('SOURCE_QUANTITY')
        if name=='Terapija' and state.get('zaliha_kolicina') is not None:
            try:
                snapshot_qty=Decimal(str(state['zaliha_kolicina']))
                if not snapshot_qty.is_finite():
                    raise ValueError()
                if snapshot_qty!=qty:
                    problem.append('SOURCE_QUANTITY')
            except (ValueError,ArithmeticError):
                reasons.append('SOURCE_HISTORY')
        outs = [t for t in txs if t.tip in OUTFLOW]
        returns = [t for t in txs if t.tip=='POVRAT']
        cancelled = is_cancelled(source)
        expected_type = 'ORALNO_IZDAVANJE' if name=='IzdavanjeOralneTerapije' else 'KUCNO_IZDAVANJE' if kind=='home' else 'AMBULANTNA_POTROSNJA'
        if any(t.tip!=expected_type for t in outs) and not home_application:
            problem.append('SOURCE_EFFECT')
        if qty<=0 and not migration:
            problem.append('SOURCE_QUANTITY')
        comparable = not reasons
        expected_out = ZERO if home_application else qty if not migration else None
        expected_return = ZERO if home_application else qty if cancelled else ZERO
        out_quantity = sum((t.kolicina for t in outs),ZERO) if outs else None
        return_quantity = sum((t.kolicina for t in returns),ZERO) if returns else None
        # Absence of expected historical movements does not establish a zero.
        if not home_application and not migration and not outs:
            reasons.append('SOURCE_HISTORY')
        if cancelled and not home_application and not migration and not returns:
            reasons.append('SOURCE_HISTORY')
        if not cancelled and returns:
            if any(t.referenca_tip in REVERSALS for t in returns):
                problem.append('SOURCE_EFFECT')
            else:
                # A linked, partial return is not proof of cancellation. Check
                # its bounds and physical effect, not an invented full reversal.
                expected_return=None
                if comparable and return_quantity>qty:
                    problem.append('SOURCE_QUANTITY')
        if home_application:
            out_quantity = sum((-t.frizider_delta() for t in outs),ZERO)
            return_quantity = sum((t.frizider_delta() for t in returns),ZERO)
        elif not cancelled and not returns:
            return_quantity=ZERO
        out_difference = out_quantity-expected_out if comparable and out_quantity is not None and expected_out is not None else None
        return_difference = return_quantity-expected_return if comparable and return_quantity is not None and expected_return is not None else None
        if comparable and (out_difference not in {None,ZERO} or return_difference not in {None,ZERO}):
            problem.append('SOURCE_QUANTITY')
        physical = sum((t.frizider_delta() for t in txs),ZERO) if txs or home_application else None
        expected_effect = -expected_out+expected_return if not reasons and expected_out is not None and expected_return is not None else None
        effect_difference = physical-expected_effect if physical is not None and expected_effect is not None else None
        if comparable and effect_difference not in {None,ZERO}:
            problem.append('SOURCE_EFFECT')
        values={'unit':unit,'source_quantity':qty,'expected_quantity':expected_out,
                'quantity':out_quantity if comparable else None,'difference':out_difference,
                'expected_return':expected_return,'returned_quantity':return_quantity if comparable else None,
                'return_difference':return_difference,'expected_effect':expected_effect,
                'fridge_delta':physical,'effect_difference':effect_difference}
        proof[0]=evidence(source,values)
        if problem:
            run.add('MOVEMENT_BALANCE','stock','ISSUE',proof,reasons=problem)
        if reasons:
            run.add('MOVEMENT_BALANCE','stock','UNKNOWN',proof,reasons=reasons)
            run.skip_record(source_scope,reasons[0])
        else:
            source_scope['checked']+=1
            if not problem:
                run.add('MOVEMENT_BALANCE','stock','OK',proof,
                        reasons=['HOME_APPLICATION_ONLY'] if home_application else [])
                run.valid_split_sources.update((t.referenca_tip,t.referenca_id,t.tip,t.lijek_id) for t in txs)
