"""Bounded structured technical events; deliberately no raw exceptions/logs."""
from threading import Lock
from uuid import uuid4
from django.conf import settings
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.utils import timezone

PRINT_VIEWS={'print_karton':'KARTON','print_razduzivanje':'RAZDUZENJE','print_razduzenje_izdavanja':'RAZDUZENJE',
             'print_zahtjev_zavodu':'ZAHTJEV','print_zahtjev_zavodu_trebovanje':'ZAHTJEV'}
_lock=Lock()
KEY='diagnostics:print-events:v1'


def record_print_failure(kind,exception):
    event={'id':str(uuid4()),'date':timezone.localdate().isoformat(),'at':timezone.now().timestamp(),
           'category':'VALIDATION' if isinstance(exception,ValidationError) else 'GENERATOR','kind':kind}
    with _lock:
        events=print_events()
        cache.set(KEY,(events+[event])[-100:],86400)
    return event['id']


def print_events():
    cutoff=timezone.now().timestamp()-86400
    return [e for e in cache.get(KEY,[]) if e['at']>=cutoff]


class DiagnosticPrintEventsMiddleware:
    def __init__(self,get_response):
        self.get_response=get_response

    def __call__(self,request):
        response=self.get_response(request)
        kind=PRINT_VIEWS.get(getattr(getattr(request,'resolver_match',None),'url_name',''))
        if kind and response.status_code in {400,500,502,503} and not getattr(request,'diagnostic_print_event',None) and getattr(settings,'ADMIN_DIAGNOSTICS_ENABLED',True):
            try:
                request.diagnostic_print_event=record_print_failure(kind,ValidationError('') if response.status_code==400 else RuntimeError())
            except Exception:
                pass
        if getattr(request,'diagnostic_print_event',None):
            response['X-TheraFlow-Event']=request.diagnostic_print_event
        return response

    def process_exception(self,request,exception):
        kind=PRINT_VIEWS.get(getattr(getattr(request,'resolver_match',None),'url_name',''))
        if kind and getattr(settings,'ADMIN_DIAGNOSTICS_ENABLED',True):
            try:
                request.diagnostic_print_event=record_print_failure(kind,exception)
            except Exception:
                pass  # Observability must not replace the original print error.
        return None
