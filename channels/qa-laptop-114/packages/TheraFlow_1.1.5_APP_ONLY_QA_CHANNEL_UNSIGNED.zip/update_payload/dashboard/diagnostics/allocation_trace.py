"""Read-only replay of explicitly linked receipt / reservation / transfer graphs.

This adapter consumes the existing inventory census. It never chooses a receipt
by patient, date, amount or FIFO, and never writes or repairs historical links.
"""
from decimal import Decimal, InvalidOperation

ZERO = Decimal('0')


def transfer_reservation_expectation(reservation, data):
    graph = data.get('_transfer_graph')
    if graph is None:
        graph = data['_transfer_graph'] = TransferGraph(data)
    return graph.expected(reservation.pk)


class TransferGraph:
    def __init__(self, data):
        self.data = data
        self.reservations = {r.pk:r for r in data['reservations']}
        self.incoming, self.outgoing = {}, {}
        for t in data['transfers']:
            self.incoming.setdefault(t.odredisna_rezervacija_id, []).append(t)
            self.outgoing.setdefault(t.izvorna_rezervacija_id, []).append(t)
        self.cache, self.visiting = {}, set()
        data['_allocation_components'] = {}

    def valid_link(self, transfer):
        source = self.reservations.get(transfer.izvorna_rezervacija_id)
        dest = self.reservations.get(transfer.odredisna_rezervacija_id)
        q = transfer.kolicina
        if not (source and dest and source.pk != dest.pk and q is not None
                and q.is_finite() and q > ZERO
                and (source.pacijent_id,source.lijek_id)==(transfer.pacijent_id,transfer.lijek_id)
                and (dest.pacijent_id,dest.lijek_id)==(transfer.primalac_id,transfer.lijek_id)
                and source.pacijent_id != dest.pacijent_id):
            return False
        # New transfers preserve typed before/after values in the existing JSON
        # audit. Older FK-linked transfers are still usable when their root and
        # every effect can independently be proved; JSON is not a substitute FK.
        metadata = transfer.izvor
        if not isinstance(metadata, dict):
            return False
        if metadata.get('reservation_id',source.pk) != source.pk:
            return False
        trace = metadata.get('allocation_trace')
        if trace is not None:
            if not isinstance(trace,dict) or trace.get('version')!=1:
                return False
            try:
                before,after,start,end = (Decimal(trace[k]) for k in
                    ('source_before','source_after','destination_before','destination_after'))
                if not all(n.is_finite() and n>=ZERO for n in (before,after,start,end)):
                    return False
                if before-after!=q or start!=ZERO or end!=q:
                    return False
                if trace.get('unit') != self.data['drugs'][transfer.lijek_id].jedinice_zalihe[0]:
                    return False
            except (KeyError, TypeError, ValueError, InvalidOperation):
                return False
        return True

    def receipt_basis(self, reservation):
        from patients.patient_fridge_corrections import allocation_basis
        linked, quantity, movement = allocation_basis(reservation)
        if linked:
            return quantity, None if quantity is not None else 'SOURCE_LINK_MISMATCH', [movement] if movement else []
        proof = self.data['receipt_proofs'].get(reservation.trebovanje_id,{})
        sources = list(proof.get('sources',[]))
        audits = [a for a in self.data['receipt_audits'] if a.rezervacija_id==reservation.pk]
        if not reservation.trebovanje_id or not proof.get('allocation_proved') or not audits:
            return None,'TRANSFER_HISTORY',sources
        # Unlike the old request-wide fallback, exact per-reservation audits
        # support two receipts into one row and distinct rows of the same SKU.
        own = [a for a in self.data['receipt_audits'] if a.trebovanje_id==reservation.trebovanje_id]
        if any(not a.fizicka_transakcija_id or not a.rezervacija_id for a in own):
            return None,'TRANSFER_HISTORY',sources
        if any(a.trebovanje_id!=reservation.trebovanje_id or a.pacijent_id!=reservation.pacijent_id for a in audits):
            return None,'SOURCE_LINK_MISMATCH',sources
        request = reservation.trebovanje
        if (request.pacijent_id,request.lijek_id)!=(reservation.pacijent_id,reservation.lijek_id):
            return None,'SOURCE_LINK_MISMATCH',sources
        ledger = {t.pk:t for t in self.data['ledger']}
        unit = self.data['drugs'][reservation.lijek_id].jedinice_zalihe[0]
        for audit in audits:
            tx = ledger.get(audit.fizicka_transakcija_id)
            if not tx or not tx.jedinica_snapshot:
                return None,'TRANSFER_HISTORY',sources
            if tx.jedinica_snapshot!=unit or tx.komisijski_ciklus_id!=request.komisijski_ciklus_id:
                return None,'SOURCE_LINK_MISMATCH',sources
        from .commission_audit import corrected_allocation
        return sum((corrected_allocation(a, self.data['ledger']) for a in audits),ZERO),None,sources

    def effects_complete(self, reservation):
        """Ignore an unrelated receipt only through its explicit allocation FK."""
        from .commission_audit import reservation_effects, known_inventory_correction, reservation_start
        used,events,complete = reservation_effects(reservation,self.data)
        pair = (reservation.pacijent_id,reservation.lijek_id)
        if any(c.pacijent_id==reservation.pacijent_id and c.scope=='stock' for c in self.data['corrections']):
            complete=False
        if any(n.trebovanje_id and n.trebovanje_id==reservation.trebovanje_id and n.preostala_kolicina>0 for n in self.data['needs']):
            complete=False
        therapy_ids = {t.pk for t in self.data['therapies'] if (t.pacijent_id,t.lijek_id)==pair}
        issue_therapies = {i.pk:i.terapija_id for i in self.data['issues'] if (i.pacijent_id,i.lijek_id)==pair}
        for tx in self.data['ledger']:
            if known_inventory_correction(tx):
                continue
            if (tx.pacijent_id,tx.lijek_id)!=pair or tx.datum<reservation_start(reservation, self.data):
                continue
            if tx.lokacija=='KOD_PACIJENTA' and tx.frizider_delta()==ZERO:
                continue
            if tx.tip=='ZAPRIMANJE':
                claims=[a for a in self.data['receipt_audits'] if a.fizicka_transakcija_id==tx.pk]
                if claims and all(a.rezervacija_id and self.data['receipt_proofs'].get(a.trebovanje_id,{}).get('allocation_proved') for a in claims):
                    continue
            elif tx.tip in {'KUCNO_IZDAVANJE','AMBULANTNA_POTROSNJA'}:
                therapy_id=(tx.referenca_id if tx.referenca_tip=='Terapija' else
                            issue_therapies.get(tx.referenca_id) if tx.referenca_tip=='KucnoIzdavanje' else None)
                if therapy_id in therapy_ids:
                    continue  # Exact reservation effects are checked above.
            elif tx.tip=='POVRAT' and tx.referenca_tip in {'Terapija','Poništena terapija'} and tx.referenca_id in therapy_ids:
                continue
            elif tx.tip=='POCETNO_STANJE_MIGRACIJE' and tx.referenca_tip=='MigracijskiSnapshotPacijenta':
                if any(s.pk==tx.referenca_id and (s.pacijent_id,s.lijek_id)==pair for s in self.data['snapshots']):
                    continue
            complete=False
            events.append(tx)
        return used,events,complete

    def expected(self, pk):
        if pk in self.cache:
            return self.cache[pk]
        if pk in self.visiting:
            return None,'SOURCE_LINK_MISMATCH',[]
        if len(self.visiting)>=100:
            return None,'TRANSFER_HISTORY',[]
        self.visiting.add(pk)
        try:
            result=self.calculate(pk)
            self.cache[pk]=result
            return result
        finally:
            self.visiting.remove(pk)

    def calculate(self, pk):
        from .inventory_audit import reservation_expectation
        reservation=self.reservations[pk]
        incoming=self.incoming.get(pk,[]);outgoing=self.outgoing.get(pk,[])
        sources=[reservation,*incoming,*outgoing]
        if len(incoming)>1 or any(not self.valid_link(t) for t in incoming+outgoing):
            return None,'SOURCE_LINK_MISMATCH',sources
        for linked in (reservation.komisija,reservation.trebovanje):
            if linked and (linked.pacijent_id,linked.lijek_id)!=(reservation.pacijent_id,reservation.lijek_id):
                return None,'SOURCE_LINK_MISMATCH',sources
        used,events,complete=self.effects_complete(reservation)
        sources.extend(events)
        received=ZERO;transferred_in=ZERO
        if incoming:
            # A transfer creates a new dedicated row; it cannot simultaneously
            # claim a receipt, migration opening, or another patient's approval.
            if (reservation.trebovanje_id or reservation.migracijski_snapshot_id
                    or reservation.migracijsko_pocetno_stanje_id or reservation.potreba_fizickog_pokrica_id
                    or any(a.rezervacija_id==pk for a in self.data['receipt_audits'])):
                return None,'SOURCE_LINK_MISMATCH',sources
            parent,reason,ancestry=self.expected(incoming[0].izvorna_rezervacija_id)
            sources.extend(ancestry)
            if reason:
                return None,reason,sources
            if parent is None:
                return None,'TRANSFER_HISTORY',sources
            transferred_in=incoming[0].kolicina
            basis=transferred_in
        elif reservation.migracijski_snapshot_id:
            # Keep the existing strictly linked migration-opening proof. Missing
            # openings/corrections are not reconstructed by this transfer adapter.
            pair=(reservation.pacijent_id,reservation.lijek_id)
            base,reason=reservation_expectation(reservation,
                transactions=[t for t in self.data['ledger'] if (t.pacijent_id,t.lijek_id)==pair],
                therapies=[t for t in self.data['therapies'] if (t.pacijent_id,t.lijek_id)==pair],
                transfers=[],corrections=self.data['corrections'],issues=self.data['issues'],needs=self.data['needs'])
            sources.append(reservation.migracijski_snapshot)
            if reason:
                return None,reason,sources
            basis=base+used
        else:
            received,reason,receipts=self.receipt_basis(reservation)
            sources.extend(receipts)
            if reason:
                return None,reason,sources
            basis=received
        if not complete or not reservation.aktivno and reservation.kolicina>ZERO:
            return None,'TRANSFER_HISTORY',sources
        transferred_out=sum((t.kolicina for t in outgoing),ZERO)
        expected=basis-used-transferred_out
        self.data['_allocation_components'][pk]={
            'allocation_origin_quantity':basis-transferred_in,
            'transferred_in':transferred_in,'transferred_out':transferred_out,'linked_consumption':used}
        return expected,'TRANSFER_QUANTITY' if expected<ZERO else None,sources
