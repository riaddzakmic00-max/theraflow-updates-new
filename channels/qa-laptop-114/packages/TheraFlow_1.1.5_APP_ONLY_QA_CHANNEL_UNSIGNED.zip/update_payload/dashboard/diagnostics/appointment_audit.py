"""Read-only appointment checks. Dates are never inferred from dispensing.

The broad inactive-patient query in patients.integrity also includes closed
history; only its future active subset is applicable here. Duplicate identity
is the exact idempotent key used by schedule_therapy_appointment. No scheduling,
reservation canonicalisation or sync_pending_order (all writers) is invoked.
"""
from collections import defaultdict
from decimal import Decimal
from patients import models as m
from patients.appointment_plan import appointment_plan


def check_appointments(run):
    area = 'appointments'
    appointments = list(run.scan_all(m.Termin.objects.select_related('pacijent__lijek','lijek'),
                                    'Svi termini', area=area))
    histories = list(run.scan_all(m.TerapijaStatusHistorija.objects.all(), 'Historija termina', area=area))
    therapies = list(run.scan_all(m.Terapija.objects.all(), 'Veze terapija na termine', area=area))
    changes = list(run.scan_all(m.BrzaIzmjenaPacijenta.objects.filter(vrsta__in=['dose','interval']),
                               'Datirani nalozi', area=area))
    by_term, history, duplicates = defaultdict(dict), defaultdict(list), defaultdict(list)
    terms = {a.pk:a for a in appointments}
    therapy_map = {t.pk:t for t in therapies}
    for t in therapies:
        pk = (t.workflow_snapshot or {}).get('termin_id')
        if pk:
            by_term[pk][t.pk] = t
            if pk not in terms:
                ref = run.evidence_for('Terapija',t.pk,patient_id=t.pacijent_id,medicine_id=t.lijek_id)
                run.add('APPOINTMENT_LINKS',area,'ISSUE',[ref],reasons=['SOURCE_MISSING'])
    for h in histories:
        if h.termin_id:
            history[h.termin_id].append(h)
            if h.terapija_id in therapy_map:
                by_term[h.termin_id][h.terapija_id] = therapy_map[h.terapija_id]
    for a in appointments:
        if a.status==m.Termin.STATUS_PLANIRANA:
            duplicates[(a.pacijent_id,a.lijek_id,a.datum,a.vrijeme)].append(a.pk)
    scope=run.new_scope(area,'Termin',len(appointments),label='Veze/status i režim termina')
    scope['loaded']=len(appointments)
    for a in appointments:
        run.checkpoint()
        ref=run.evidence_for('Termin',a.pk,patient_id=a.pacijent_id,medicine_id=a.lijek_id,
            values={'event_date':a.datum,'quantity':a.kolicina_po_terapiji,'appointment_status':a.status})
        reasons=[]
        future_active=a.datum>=run.today and a.status in {m.Termin.STATUS_PLANIRANA,m.Termin.STATUS_ODGODJENA}
        if future_active and not a.pacijent.aktivan:
            reasons.append('APPOINTMENT_INACTIVE')
        key=(a.pacijent_id,a.lijek_id,a.datum,a.vrijeme)
        if a.status==m.Termin.STATUS_PLANIRANA and len(duplicates[key])>1:
            reasons.append('APPOINTMENT_DUPLICATE')
        linked=list(by_term[a.pk].values())
        active=[t for t in linked if t.workflow_status=='POTVRDJENA' and not t.ponistena_at]
        if any(t.pacijent_id!=a.pacijent_id or t.lijek_id!=a.lijek_id for t in linked):
            reasons.append('APPOINTMENT_LINK')
        if active and a.status!='OBAVLJEN' or len(active)>1:
            reasons.append('APPOINTMENT_LINK')
        if linked and not active and a.status=='OBAVLJEN':
            reasons.append('APPOINTMENT_LINK')
        refs=[ref]+[run.evidence_for('Terapija',t.pk,patient_id=t.pacijent_id,medicine_id=t.lijek_id,
                    values={'event_date':t.datum,'quantity':t.kolicina,'workflow_status':t.workflow_status}) for t in linked]
        run.add('APPOINTMENT_LINKS',area,'ISSUE' if reasons else 'OK',refs,reasons=reasons)
        if a.status=='OBAVLJEN' and not linked:
            run.add('APPOINTMENT_LINKS',area,'UNKNOWN',[ref],reasons=['APPOINTMENT_HISTORY'])
            run.skip_record(scope,'APPOINTMENT_HISTORY'); continue
        if not future_active:
            # Status/link checks above still ran. No historical prescription is guessed.
            scope['checked']+=1
            continue
        applicable=[c for c in changes if c.pacijent_id==a.pacijent_id and c.lijek_id==a.lijek_id and c.vrijedi_od<=a.datum]
        applicable.sort(key=lambda c:(c.vrijedi_od,c.kreirano,c.pk))
        if a.pacijent.lijek_id!=a.lijek_id:
            # Dated therapy switches and IV->SC plans are valid exceptions.
            from patients.phased_protocols import phased_protocol_for_patient, current_phase_details
            phase=phased_protocol_for_patient(a.pacijent)
            valid_phase=phase and current_phase_details(phase,a.datum)['medicine'].pk==a.lijek_id
            switches=m.PromjenaTerapije.objects.filter(pacijent_id=a.pacijent_id,
                novi_lijek_id=a.lijek_id,datum_pocetka_nove_terapije__lte=a.datum).exists()
            run.add('APPOINTMENT_REGIMEN',area,'UNKNOWN' if valid_phase or switches else 'REVIEW',[ref],
                    reasons=['APPOINTMENT_HISTORY' if valid_phase or switches else 'APPOINTMENT_LINK'])
            run.skip_record(scope,'APPOINTMENT_HISTORY'); continue
        if not applicable:
            run.add('APPOINTMENT_REGIMEN',area,'UNKNOWN',[ref],reasons=['APPOINTMENT_HISTORY'])
            run.skip_record(scope,'APPOINTMENT_HISTORY'); continue
        plan=appointment_plan(a)
        proof=run.evidence_for('Termin',a.pk,patient_id=a.pacijent_id,medicine_id=a.lijek_id,values={
            'event_date':a.datum,'quantity':a.kolicina_po_terapiji,'expected_quantity':plan['quantity'],
            'difference':a.kolicina_po_terapiji-plan['quantity'] if a.kolicina_po_terapiji is not None else None,
            'dose_mg':plan['dose_mg'],'interval_weeks':plan['interval'], 'manual_exception':plan['source']=='MANUAL'})
        status,why='OK',[]
        if plan['conflict']:
            status,why='REVIEW',['APPOINTMENT_MANUAL']
        elif plan['source']=='REGIMEN' and a.kolicina_po_terapiji is not None and a.kolicina_po_terapiji!=plan['quantity']:
            status,why='ISSUE',['APPOINTMENT_QUANTITY']
        run.add('APPOINTMENT_REGIMEN',area,status,[proof],reasons=why)
        interval_orders=[c for c in applicable if 'interval_sedmica' in c.promjena_rezima]
        # A dated interval is shown, but it is not an order to silently move a
        # booked date. An explicit later scheduling decision resolves this review.
        if interval_orders:
            order=interval_orders[-1]
            decided=any(h.datum_vrijeme>=order.kreirano and
                (h.novo_stanje or {}).get('tip_dogadjaja') in {
                    'TERMIN_ODGODJEN','TERMIN_PROMIJENJEN','TERAPIJA_PAUSIRANA','NOVI_TERMIN'}
                for h in history[a.pk])
            if not decided:
                run.add('APPOINTMENT_REGIMEN',area,'REVIEW',[proof],reasons=['APPOINTMENT_INTERVAL'])
        scope['checked']+=1
