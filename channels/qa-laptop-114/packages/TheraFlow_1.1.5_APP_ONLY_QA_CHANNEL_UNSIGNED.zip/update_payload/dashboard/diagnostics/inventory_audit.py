"""Complete, read-only inventory census. Missing history is never an inferred loss.

Current quantities follow inventory.patient_reservation_breakdown semantics:
every active physical reservation counts, including inactive patients/old drugs.
Future appointment reservations are a SUBSET of physical assignments. Pending
coverage and commission rights are administrative, not fridge inventory.
"""
from collections import defaultdict
from decimal import Decimal, InvalidOperation

from django.urls import reverse
from patients import models as m
from .home_summary import home_summary

ZERO = Decimal('0')


def grouped(items, key):
    result = defaultdict(list)
    for item in items:
        result[key(item)].append(item)
    return result


def quantity(items, field):
    return sum((getattr(item, field) for item in items), ZERO)


def reservation_expectation(reservation, *, transactions, therapies, transfers, corrections, issues, needs):
    """Replay only explicitly linked allocation effects, not patient consumption.

The migration declaration is not automatically today's balance. A receipt may
cover several allocations, and a therapy can use free stock. Without exact
allocation effects we report unknown instead of assigning either to this row.
"""
    incoming = [t for t in transfers if t.odredisna_rezervacija_id == reservation.pk]
    from patients.patient_fridge_corrections import allocation_basis
    linked, corrected_basis, _ = allocation_basis(reservation)
    if linked:
        if corrected_basis is None:
            return None, 'SOURCE_LINK_MISMATCH'
        for therapy in therapies:
            state = therapy.workflow_snapshot or {}
            if (therapy.datum >= reservation.datum_rezervacije and not therapy.is_migration
                    and therapy.workflow_status != 'PONISTENA' and state.get('vrsta') != 'KUCNA_PRIMJENA'
                    and not ('rezervacijske_promjene' in state or 'fazne_rezervacijske_promjene' in state)):
                return None, 'ALLOCATION_HISTORY'
        if any(tx.tip == 'RELEASE_TO_FREE_STOCK' and tx.datum >= reservation.datum_rezervacije for tx in transactions):
            return None, 'ALLOCATION_HISTORY'
        from patients.inventory_corrections import reservation_consumption
        consumed, _ = reservation_consumption(reservation)
        outgoing = sum((t.kolicina for t in transfers if t.izvorna_rezervacija_id == reservation.pk), ZERO)
        return corrected_basis-consumed-outgoing, None
    for source in (reservation.komisija, reservation.trebovanje):
        if source and (source.pacijent_id, source.lijek_id) != (reservation.pacijent_id, reservation.lijek_id):
            return None, 'SOURCE_LINK_MISMATCH'
    snapshot = reservation.migracijski_snapshot
    basis = None
    if snapshot:
        if (snapshot.pacijent_id, snapshot.lijek_id) != (reservation.pacijent_id, reservation.lijek_id):
            return None, 'SOURCE_LINK_MISMATCH'
        openings = [t for t in transactions if t.tip == 'POCETNO_STANJE_MIGRACIJE'
                    and t.referenca_tip == 'MigracijskiSnapshotPacijenta' and t.referenca_id == snapshot.pk
                    and t.lokacija == 'FRIZIDER']
        if len(openings) != 1:
            return None, 'ALLOCATION_HISTORY'
        # Controlled migration corrections also update this declaration. Their
        # ledger delta must not be subtracted from the corrected basis again.
        basis = snapshot.fizicki_u_frizideru
        # Migration declares a requested allocation; the unsupported portion
        # explicitly remains pending rather than physically in the fridge.
        basis -= sum((n.preostala_kolicina for n in needs if n.migracijski_snapshot_id == snapshot.pk
                      and n.status == m.PotrebaFizickogPokrica.STATUS_CEKA), ZERO)
    elif len(incoming) == 1:
        item = incoming[0]
        if (item.primalac_id, item.lijek_id) != (reservation.pacijent_id, reservation.lijek_id):
            return None, 'SOURCE_LINK_MISMATCH'
        basis = item.kolicina
    # Historical receipt/free-stock allocation rows do not universally preserve
    # their original quantity per reservation. Never distribute a shared receipt
    # by a guessed FIFO order in a diagnostic report.
    if basis is None:
        return None, 'ALLOCATION_HISTORY' if reservation.trebovanje_id or reservation.komisija_id else 'ALLOCATION_NO_SOURCE'
    relevant_ids = {t.pk for t in therapies}
    issues = {issue.pk: issue.terapija_id for issue in issues}
    known_corrections = {c.pk for c in corrections if c.scope == 'stock' and snapshot
                         and str(snapshot.pk) in c.poslije.get('patients_migracijskisnapshotpacijenta', {})}
    for tx in transactions:
        if tx.datum < reservation.datum_rezervacije:
            continue
        if tx.tip == 'POCETNO_STANJE_MIGRACIJE':
            continue
        if tx.lokacija == 'KOD_PACIJENTA' and tx.frizider_delta() == ZERO:
            continue
        if tx.tip in {'AMBULANTNA_POTROSNJA', 'KUCNO_IZDAVANJE', 'ORALNO_IZDAVANJE'}:
            therapy_id = tx.referenca_id if tx.referenca_tip == 'Terapija' else issues.get(tx.referenca_id) if tx.referenca_tip == 'KucnoIzdavanje' else None
            if therapy_id not in relevant_ids:
                return None, 'ALLOCATION_HISTORY'
        elif tx.tip == 'KOREKCIJA' and tx.referenca_tip == 'PatientDataCorrection' and tx.referenca_id in known_corrections:
            continue
        elif tx.tip == 'POVRAT' and tx.referenca_tip in {'Terapija','Poništena terapija'} and tx.referenca_id in relevant_ids:
            continue  # Canceled therapy snapshots are excluded below.
        else:
            return None, 'ALLOCATION_HISTORY'
    for therapy in therapies:
        if therapy.datum < reservation.datum_rezervacije or therapy.is_migration:
            continue
        if therapy.workflow_status == 'PONISTENA':
            continue
        state = therapy.workflow_snapshot or {}
        if state.get('vrsta') == 'KUCNA_PRIMJENA':
            continue  # Already removed from fridge at issuance.
        if therapy.workflow_status != 'POTVRDJENA':
            continue
        if 'rezervacijske_promjene' not in state and 'fazne_rezervacijske_promjene' not in state:
            return None, 'ALLOCATION_HISTORY'
        try:
            for effect in state.get('rezervacijske_promjene', []) + state.get('fazne_rezervacijske_promjene', []):
                if effect.get('rezervacija_id') == reservation.pk:
                    used = Decimal(str(effect['kolicina']))
                    if not used.is_finite() or used < 0:
                        return None, 'ALLOCATION_HISTORY'
                    basis -= used
        except (ValueError, TypeError, KeyError, InvalidOperation):
            return None, 'ALLOCATION_HISTORY'
    for transfer in transfers:
        if transfer.izvorna_rezervacija_id == reservation.pk:
            basis -= transfer.kolicina
    # A closed row can retain its former quantity after a release/reallocation.
    # No event stream exists for every legacy close; don't invent a current zero.
    if not reservation.aktivno and reservation.kolicina > 0:
        return None, 'ALLOCATION_HISTORY'
    return basis, None


def check_inventory(run):
    """One census covers every patient, SKU, assignment and ledger row."""
    data = run.inventory
    patients = {p.pk: p for p in run.scan_all(m.Pacijent.objects.all(), 'Svi pacijenti (aktivni i neaktivni)')}
    drugs = {d.pk: d for d in run.scan_all(m.Lijek.objects.all(), 'Sve prezentacije lijekova (uključujući neaktivne)')}
    stocks = {s.lijek_id: s for s in run.scan_all(m.Zaliha.objects.all(), 'Svi zapisi fizičke zalihe')}
    reservations = list(run.scan_all(m.PacijentRezervacija.objects.select_related('migracijski_snapshot', 'termin', 'komisija', 'trebovanje'), 'Sva zaduženja u frižideru (aktivna i zatvorena)'))
    assignments = list(run.scan_all(m.PacijentZaduzenje.objects.all(), 'Sva kućna zaduženja'))
    needs = list(run.scan_all(m.PotrebaFizickogPokrica.objects.all(), 'Sve potrebe fizičkog pokrića'))
    commissions = list(run.scan_all(m.Komisija.objects.all(), 'Sva komisijska odobrenja'))
    requests = list(run.scan_all(m.Trebovanje.objects.all(), 'Sva trebovanja'))
    snapshots = list(run.scan_all(m.MigracijskiSnapshotPacijenta.objects.all(), 'Svi migracijski snapshoti'))
    ledger = list(run.scan_all(m.ZalihaTransakcija.objects.all(), 'Sva kretanja zalihe'))
    transfers = list(run.scan_all(m.BrzaIzmjenaPacijenta.objects.filter(vrsta='transfer'), 'Svi prijenosi zaduženja'))
    therapies = list(run.scan_all(m.Terapija.objects.select_related('lijek'), 'Sve terapije — povezani učinci na zaduženja'))
    corrections = list(run.scan_all(m.PatientDataCorrection.objects.all(), 'Sve evidentirane ispravke'))
    oral = list(run.scan_all(m.IzdavanjeOralneTerapije.objects.select_related('lijek'), 'Sva oralna izdavanja'))
    home_evidence = list(run.scan_all(m.KucnaTerapijaPodatak.objects.all(), 'Svi podaci kućne terapije'))
    issues = list(run.scan_all(m.KucnoIzdavanje.objects.select_related('lijek','terapija'), 'Sva kućna izdavanja'))
    receipt_audits = list(run.scan_all(m.EvidencijaSaglasnostiZaprimanja.objects.all(), 'Izričita raspodjela zaprimanja po pacijentu i ciklusu'))
    run.inventory_records = {'drugs':drugs, 'ledger':ledger, 'therapies':therapies,
                             'issues':issues, 'oral':oral, 'patients':patients, 'stocks':stocks,
                             'assignments':assignments, 'snapshots':snapshots, 'reports':home_evidence,
                             'commissions':commissions, 'requests':requests, 'reservations':reservations,
                             'corrections':corrections, 'receipt_audits':receipt_audits,
                             'needs':needs, 'transfers':transfers}
    from .commission_audit import receipt_proofs
    run.inventory_records['receipt_proofs'] = receipt_proofs(run.inventory_records)
    pairs = lambda item: (item.pacijent_id, item.lijek_id)
    reservations_by_pair = grouped(reservations, pairs)
    ledger_by_pair, therapies_by_pair = grouped(ledger, pairs), grouped(therapies, pairs)
    issues_by_pair = grouped(issues, pairs)
    ledger_by_source = grouped(ledger, lambda tx:(tx.lijek_id, tx.referenca_tip, tx.referenca_id))
    needs_by_snapshot = grouped(needs, lambda n:n.migracijski_snapshot_id)
    corrections_by_patient = grouped(corrections, lambda c: c.pacijent_id)
    transfers_by_reservation = defaultdict(list)
    for item in transfers:
        transfers_by_reservation[item.izvorna_rezervacija_id].append(item)
        transfers_by_reservation[item.odredisna_rezervacija_id].append(item)
    evidence_cache = {}

    def evidence(item):
        key = (type(item).__name__, item.pk)
        if key not in evidence_cache:
            values = {}
            if isinstance(item, m.ZalihaTransakcija):
                values = {'event_type': item.tip, 'event_date': item.datum, 'quantity': item.kolicina,
                          'fridge_delta': item.frizider_delta(), 'source_type': item.referenca_tip, 'source_id': item.referenca_id}
            elif isinstance(item, m.MigracijskiSnapshotPacijenta):
                values = {'migration_declared': item.fizicki_u_frizideru, 'recorded_at_patient': item.kod_pacijenta,
                          'remaining_quantity': item.preostalo_po_komisiji, 'event_date': item.kreirano.date()}
            elif isinstance(item, m.BrzaIzmjenaPacijenta):
                values = {'quantity': item.kolicina, 'fridge_delta': ZERO, 'event_date': item.kreirano.date(),
                          'source_id': item.izvorna_rezervacija_id, 'destination_id': item.odredisna_rezervacija_id}
            elif isinstance(item, m.Terapija):
                values = {'quantity': item.kolicina, 'event_date': item.datum, 'workflow_status': item.workflow_status}
            elif isinstance(item, m.PatientDataCorrection):
                values = {'event_date': item.kreirano.date()}
            elif isinstance(item, m.PotrebaFizickogPokrica):
                values = {'remaining_quantity': item.preostala_kolicina, 'total_quantity':item.trazena_kolicina}
            elif isinstance(item, m.Trebovanje):
                values = {'total_quantity':item.odobrene_doze,'received_quantity':item.zaprimljene_doze}
            elif isinstance(item, m.KucnaTerapijaPodatak):
                values = {'issued_on':item.datum_izdavanja,'issued_quantity':item.izdata_kolicina,
                          'reported_remaining':item.preostala_kolicina,'checked_on':item.datum_provjere,'last_application':item.datum_primjene}
            elif isinstance(item, m.KucnoIzdavanje):
                values = {'issued_on':item.datum,'issued_quantity':item.kolicina}
            elif isinstance(item, m.IzdavanjeOralneTerapije):
                values = {'issued_on':item.datum_izdavanja,'issued_quantity':item.kolicina_tableta}
            elif isinstance(item, m.EvidencijaSaglasnostiZaprimanja):
                values = {'received_quantity':item.zaprimljena_kolicina,'event_date':item.kreirano.date()}
            medicine_id=getattr(item,'lijek_id',None)
            if isinstance(item,m.EvidencijaSaglasnostiZaprimanja):
                medicine_id=next((r.lijek_id for r in requests if r.pk==item.trebovanje_id),None)
            evidence_cache[key] = run.evidence_for(key[0], item.pk, values=values, patient_id=getattr(item, 'pacijent_id', None), medicine_id=medicine_id)
        return evidence_cache[key]

    detail_by_drug = defaultdict(list)
    active_reservations = [r for r in reservations if r.aktivno and r.kolicina > 0]
    active_home = [a for a in assignments if a.aktivno and a.preostalo > 0]
    reservation_scope = run.new_scope('stock','PacijentRezervacija',len(reservations),
                                     label='Pojedinačna zaduženja — provjera izvora i učinaka')
    reservation_scope['loaded']=len(reservations)
    data['coverage'].append(reservation_scope)
    for reservation in reservations:
        run.checkpoint()
        patient, drug = patients[reservation.pacijent_id], drugs[reservation.lijek_id]
        key = pairs(reservation)
        related = [evidence(t) for t in ledger_by_pair[key]]
        related += [evidence(t) for t in therapies_by_pair[key]]
        related += [evidence(t) for t in transfers_by_reservation[reservation.pk]]
        related += [evidence(c) for c in corrections_by_patient[patient.pk]]
        if reservation.migracijski_snapshot:
            related.append(evidence(reservation.migracijski_snapshot))
            related += [evidence(n) for n in needs_by_snapshot[reservation.migracijski_snapshot_id]]
        if reservation.trebovanje:
            request = reservation.trebovanje
            related.append(evidence(request))
            related += [evidence(t) for t in ledger_by_source[(drug.pk,'Trebovanje',request.pk)]]
            if request.komisijski_ciklus_id:
                related += [evidence(t) for t in ledger_by_source[(drug.pk,'KomisijskiCiklus',request.komisijski_ciklus_id)]]
        has_transfers=bool(transfers_by_reservation[reservation.pk])
        if has_transfers:
            from .allocation_trace import transfer_reservation_expectation
            expected,reason,sources=transfer_reservation_expectation(reservation,run.inventory_records)
            related += [evidence(s) for s in sources]
        else:
            expected, reason = reservation_expectation(reservation,
                transactions=ledger_by_pair[key], therapies=therapies_by_pair[key],
                transfers=[], corrections=corrections_by_patient[patient.pk],
                issues=issues_by_pair[key], needs=needs)
        # Resolve receipt-backed allocations only when the original per-patient
        # allocation and every subsequent effect can be proved.
        if not has_transfers and reason == 'ALLOCATION_HISTORY' and reservation.trebovanje_id:
            from .commission_audit import receipt_reservation_expectation
            expected, reason, sources = receipt_reservation_expectation(reservation, run.inventory_records)
            related += [evidence(s) for s in sources]
        recorded = reservation.kolicina if reservation.aktivno else ZERO
        status = 'UNKNOWN' if reason else 'OK' if expected == recorded else 'ISSUE'
        if reason in {'SOURCE_LINK_MISMATCH','TRANSFER_QUANTITY'}:
            status = 'ISSUE'
        future = bool(reservation.aktivno and reservation.termin and reservation.termin.status == 'ZAKAZAN'
                      and reservation.termin.datum > run.today)
        ref = run.evidence_for('PacijentRezervacija', reservation.pk, patient_id=patient.pk, medicine_id=drug.pk,
            title=f'{patient} · {drug.naziv} · {drug.strength} · {drug.pharmaceutical_form} · zaduženje #{reservation.pk}',
            values={'quantity':recorded, 'expected_quantity':expected,
                'difference':recorded-expected if expected is not None else None,
                'unit':drug.jedinice_zalihe[0], 'route':drug.put_primjene,
                'active':reservation.aktivno, 'future_reserved':recorded if future else ZERO,
                'source_id':reservation.migracijski_snapshot_id or reservation.trebovanje_id or reservation.komisija_id,
                **run.inventory_records.get('_allocation_components',{}).get(reservation.pk,{})})
        run.add('ALLOCATION_BALANCE','stock',status,[ref,*dict.fromkeys(related)], reasons=[reason] if reason else [],
            limitation='Očekivano je računato samo iz jednoznačnog izvora i povezanih učinaka. Prazno znači nedovoljno podataka, ne nulu. Lista događaja obuhvata i kontekst istog kartona/prezentacije; svaki događaj nije nužno potrošnja ove rezervacije.')
        detail_by_drug[drug.pk].append({'patient':str(patient),'patient_url':reverse('profil_pacijenta',args=[patient.pk]),
            'record_id':reservation.pk,'active':reservation.aktivno,'recorded':str(recorded),
            'expected':str(expected) if expected is not None else None,
            'difference':str(recorded-expected) if expected is not None else None,
            'future':future,'status':status,'finding_id':run.findings[-1]['id'],'evidence_id':ref})
        if status=='UNKNOWN':
            run.skip_record(reservation_scope,reason)
        else:
            reservation_scope['checked'] += 1

    snapshot_reservation_ids = {r.migracijski_snapshot_id for r in reservations}
    for snapshot in snapshots:
        if snapshot.fizicki_u_frizideru > 0 and snapshot.pk not in snapshot_reservation_ids:
            run.add('ALLOCATION_BALANCE','stock','UNKNOWN',[evidence(snapshot),
                *[evidence(t) for t in ledger_by_pair[pairs(snapshot)]]], reasons=['MIGRATION_ALLOCATION_MISSING'],
                limitation='Snapshot navodi fizičku količinu, ali nema povezano zaduženje. To može biti nepotpuna historija migracije; nije pretpostavljena potrošnja ni nestanak lijeka.')

    # Distinct SKU keys prevent brands, IV/SC, strengths or units being merged.
    by_drug = lambda items: grouped(items, lambda item: item.lijek_id)
    ar, ah, ns, cs, rs, ss, ls = map(by_drug, (active_reservations, active_home, needs, commissions, requests, snapshots, ledger))
    drug_ids = set(stocks) | set(ar) | set(ah) | set(ns) | set(cs) | set(rs) | set(ss) | set(ls) | set(detail_by_drug)
    drug_ids |= {a.lijek_id for a in assignments} | {t.lijek_id for t in therapies} | {i.lijek_id for i in issues}
    drug_ids |= {o.lijek_id for o in oral} | {e.lijek_id for e in home_evidence}
    for drug_id in sorted(drug_ids):
        run.checkpoint()
        drug, stock = drugs[drug_id], stocks.get(drug_id)
        physical = stock.u_frizideru if stock else None
        assigned = quantity(ar[drug_id], 'kolicina')
        future = sum((r.kolicina for r in ar[drug_id] if r.termin and r.termin.status=='ZAKAZAN' and r.termin.datum>run.today),ZERO)
        home = quantity(ah[drug_id], 'preostalo')
        statements = home_summary(drug_id, assignments=assignments, snapshots=snapshots,
            reports=home_evidence, issues=issues, oral=oral,
            therapies={t.pk:t for t in therapies}, today=run.today)
        unknown_home = bool(statements['reports_expected'] and
                            (not statements['reports_complete'] or statements['reported_remaining']!=home)
                            or stock and stock.kod_pacijenata!=home)
        if unknown_home:
            report_ref = run.evidence_for('Lijek',drug.pk,values=statements)
            run.add('HOME_TOTAL','stock','UNKNOWN',[report_ref],reasons=[
                'HOME_STATEMENT_DATES' if statements['report_dates_differ'] else
                'HOME_REPORTS_INCOMPLETE' if not statements['reports_complete'] else 'HOME_STATEMENT_DIFFERENCE'])
        awaiting = quantity([n for n in ns[drug_id] if n.status==m.PotrebaFizickogPokrica.STATUS_CEKA], 'preostala_kolicina')
        # Filled only by the canonical service in the independent links checker.
        # If it is interrupted, unknown stays unknown, never an approximate zero.
        approved_waiting = None
        from .commission_audit import receipt_balance
        receipts=[t for t in ls[drug_id] if t.tip=='ZAPRIMANJE']
        net_receipts,_,receipt_valid=receipt_balance(receipts,ls[drug_id])
        outflows=[t for t in ls[drug_id] if t.tip in {'AMBULANTNA_POTROSNJA','KUCNO_IZDAVANJE','ORALNO_IZDAVANJE'}]
        restricted = -sum((t.promjena_rezervacije for t in ls[drug_id] if t.korekcija_id and t.korekcija.scope == 'inventory_allocation'), ZERO)
        values = {'recorded_fridge':physical, 'reserved':assigned, 'restricted_after_correction':restricted,
            'received_ledger_subtotal':net_receipts if receipts and receipt_valid else None,
            'issued_ledger_subtotal':sum((t.kolicina for t in outflows),ZERO) if outflows else None,
            'free_fridge':physical-assigned-restricted if physical is not None else None,
            'future_reserved':future,'awaiting_coverage':awaiting,'approved_waiting_delivery':approved_waiting,
            'at_patient':None if unknown_home else home,'home_recorded_subtotal':home, **statements,
            'physical_shortfall':max(ZERO,assigned-physical) if physical is not None else None,
            'expected_quantity':assigned,'quantity':physical,
            'difference':physical-assigned if physical is not None else None,
            'unit':drug.jedinice_zalihe[0], 'route':drug.put_primjene}
        ref = run.evidence_for('Lijek',drug.pk,title=f'{drug.naziv} · {drug.strength} · {drug.pharmaceutical_form}',values=values)
        refs = [ref,*[r['evidence_id'] for r in detail_by_drug[drug_id]],*[evidence(t) for t in ls[drug_id]]]
        for c in cs[drug_id]:
            refs.append(run.evidence_for('Komisija',c.pk,patient_id=c.pacijent_id,medicine_id=drug.pk,values={'remaining_quantity':c.preostale_doze,'total_quantity':c.broj_odobrenih_doza}))
        for need in ns[drug_id]:
            refs.append(run.evidence_for('PotrebaFizickogPokrica',need.pk,patient_id=need.pacijent_id,values={'remaining_quantity':need.preostala_kolicina}))
        for home_row in ah[drug_id]:
            refs.append(run.evidence_for('PacijentZaduzenje',home_row.pk,patient_id=home_row.pacijent_id,values={'remaining_quantity':home_row.preostalo,'total_quantity':home_row.ukupno_zaduzeno}))
        refs += [evidence(item) for item in [*issues,*oral,*home_evidence] if item.lijek_id==drug_id]
        refs += [evidence(item) for item in rs[drug_id]]
        status = 'UNKNOWN' if physical is None else 'ISSUE' if assigned>physical else 'UNKNOWN' if restricted else 'OK'
        run.add('INVENTORY_DISTRIBUTION','stock',status,refs,reasons=['STOCK_ROW_MISSING'] if physical is None else ['STOCK_OVERALLOCATED'] if assigned>physical else ['ALLOCATION_RELEASE_PENDING'] if restricted else [],
            limitation='Budući termin je podskup fizičkog zaduženja; ne sabirati ponovo. Potreba pokrića može biti pokrivena istim odobrenjem; nije dodatna fizička količina. Slobodno stanje je fizičko − zaduženo − izdvojeno nakon korekcije raspodjele. Izdvojene jedinice čekaju provjeru dostupnosti; negativno fizičko − zaduženo je nepokrivena raspodjela. Aktivno administrativno pravo bez dokaza zaprimanja nije fizička zaliha.')
        data['stocks'].append({'drug_id':drug.pk,'stock_id':stock.pk if stock else None,'name':drug.naziv,'strength':drug.strength,
            'form':drug.pharmaceutical_form,'unit':drug.jedinice_zalihe[0],'route':drug.put_primjene,
            **{key:str(value) if isinstance(value,Decimal) else value for key,value in values.items()},
            'details':detail_by_drug[drug_id],'finding_id':run.findings[-1]['id']})
    for patient in patients.values():
        related = [r for r in reservations if r.pacijent_id==patient.pk]
        data['patients'].append({'id':patient.pk,'name':str(patient),'url':reverse('profil_pacijenta',args=[patient.pk]),
            'active':patient.aktivan,'assignments':len(related),'physical_assignments':sum(1 for r in related if r.aktivno and r.kolicina>0)})
    data.update(complete=True, patients_loaded=len(patients), stocks_loaded=len(stocks),
        presentations_loaded=len(drug_ids), reservations_loaded=len(reservations),
        reservations_checked=reservation_scope['checked'], reservations_skipped=reservation_scope['skipped'],
        active_reservations_loaded=len(active_reservations), movements_loaded=len(ledger),
        allocation_unknown=sum(r['status']=='UNKNOWN' for rows in detail_by_drug.values() for r in rows),
        patients_without_assignments=sum(not p['assignments'] for p in data['patients']),
        catalog_without_inventory=len(drugs)-len(drug_ids))


def check_quantity_trail(run):
    """Attach each number to its own sources, using reconciled clinical actions.

    Issuance and administration are independent facts. Migration anchors are
    never reclassified as doses; the available subtotal is not lifetime use.
    """
    from patients.monthly_consumption import source_kind, is_cancelled
    from .commission_audit import receipt_balance
    data=run.inventory_records
    evidence=run.evidence_index
    action_checks=defaultdict(list)
    for f in run.findings:
        if f['code']=='MOVEMENT_BALANCE' and f['evidence_ids']:
            e=evidence[f['evidence_ids'][0]]
            action_checks[(e['kind'],e['record_id'])].append(f)
    home_therapies={i.terapija_id for i in data['issues'] if i.terapija_id}
    for row in run.inventory['stocks']:
        did=row['drug_id']; unit=row['unit']; trail=[]
        def ref(obj, values):
            return run.evidence_for(type(obj).__name__,obj.pk,medicine_id=did,
                patient_id=getattr(obj,'pacijent_id',None),values=values)
        def metric(key,value,refs,*,known=None):
            if unit not in {'pen','šprica','bočica','tableta','ampula'}: value=None
            er=run.evidence_for('Lijek',did,values={key:value,'unit':unit,
                **({'known_subtotal':known} if known is not None else {})})
            trail.append({'key':key,'quantity':str(value) if value is not None else None,
                'known_subtotal':str(known) if known is not None else None,
                'unit':unit,'evidence_ids':[er,*dict.fromkeys(refs)]})
        approvals=[c for c in data['commissions'] if c.lijek_id==did]
        metric('approved_subtotal',sum((c.broj_odobrenih_doza for c in approvals),ZERO) if approvals else None,
            [ref(c,{'approved_quantity':c.broj_odobrenih_doza}) for c in approvals])
        receipts=[t for t in data['ledger'] if t.lijek_id==did and t.tip=='ZAPRIMANJE']
        net,corrections,valid=receipt_balance(receipts,data['ledger'])
        metric('received_ledger_subtotal',net if receipts and valid else None,
            [ref(t,{'quantity':t.kolicina,'fridge_delta':t.frizider_delta(),'event_date':t.datum}) for t in receipts+corrections])
        stock=data['stocks'].get(did)
        stock_refs=[ref(stock,{'recorded_fridge':stock.u_frizideru})] if stock else []
        reservations=[r for r in data['reservations'] if r.lijek_id==did and r.aktivno]
        reservation_refs=[ref(r,{'quantity':r.kolicina,'active':r.aktivno}) for r in reservations]
        metric('recorded_fridge',stock.u_frizideru if stock else None,stock_refs)
        reserved=sum((r.kolicina for r in reservations),ZERO)
        metric('reserved',reserved,reservation_refs)
        metric('free_fridge',stock.u_frizideru-reserved if stock else None,stock_refs+reservation_refs)
        quantities={'home':ZERO,'clinic':ZERO}; refs={'home':[],'clinic':[]}; incomplete=set(); seen=set(); verified=set()
        for obj in data['therapies']+data['issues']+data['oral']:
            if obj.lijek_id!=did: continue
            kind=type(obj).__name__
            if kind=='Terapija' and obj.pk in home_therapies: continue
            state=(obj.workflow_snapshot or {}) if kind=='Terapija' else {}
            home_application=state.get('vrsta')=='KUCNA_PRIMJENA'
            group='clinic' if home_application else source_kind(obj)
            if group is None:
                # No inference of treatment or location from a migration date.
                incomplete.update(('home','clinic'))
                er=ref(obj,{'event_date':getattr(obj,'datum',None)})
                refs['home'].append(er);refs['clinic'].append(er)
                continue
            seen.add(group)
            checks=action_checks[(kind,obj.pk)]
            refs[group] += [e for f in checks for e in f['evidence_ids']]
            qty=Decimal(obj.kolicina_tableta) if kind=='IzdavanjeOralneTerapije' else obj.kolicina
            refs[group].append(ref(obj,{'quantity':qty,'event_date':getattr(obj,'datum',getattr(obj,'datum_izdavanja',None))}))
            if not checks or any(f['status']!='OK' for f in checks):
                incomplete.add(group)
                continue
            verified.add(group)
            if not is_cancelled(obj): quantities[group]+=qty
        for group,key in [('home','home_issued_subtotal'),('clinic','administered_subtotal')]:
            metric(key,quantities[group] if group in seen and group not in incomplete else None,
                refs[group],known=quantities[group] if group in verified else None)
        row['quantity_trail']=trail
        refs=[e for step in trail for e in step['evidence_ids']]
        incomplete=any(step['quantity'] is None for step in trail)
        run.add('MEDICINE_TRAIL','stock','UNKNOWN' if incomplete else 'OK',refs,
            reasons=['TRAIL_PARTIAL'] if incomplete else [],medicine_ids=[did],
            limitation='Historijski podzbirovi imaju različite izvore i vremenski obuhvat. Ne sabirati odobrenje s prijemom ili današnje stanje s historijskom potrošnjom. Nema naknadno pretpostavljenih primjena.')
        for step in trail: step['finding_id']=run.findings[-1]['id']
