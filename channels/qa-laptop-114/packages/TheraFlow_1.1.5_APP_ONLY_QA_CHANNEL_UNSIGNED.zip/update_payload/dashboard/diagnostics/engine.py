"""Read-only adapters over canonical TheraFlow services."""
from datetime import date, datetime
from decimal import Decimal
from time import monotonic
from uuid import uuid4

from django.conf import settings
from django.db import connection, transaction
from django.db.models import Count, Q, F
from django.urls import reverse
from django.utils import timezone
from patients import models as m
from patients.request_cache import set_cached
from theraflow.version import __version__
from .catalog import AREAS, CHECKS, CHECK_VERSION, STATUS_LABELS, REASONS, NOT_IMPLEMENTED, finding_contract
from .readonly import diagnostic_snapshot, BudgetExceeded, ReadOnlyViolation


def scalar(value):
    if isinstance(value, (Decimal, date, datetime)):
        return str(value)
    if isinstance(value, (str, int, bool)) or value is None:
        return value
    raise TypeError('Nedozvoljen tip dokaza')


class Run:
    def __init__(self, *, today=None):
        self.id = str(uuid4())
        self.today = today or timezone.localdate()
        self.started = timezone.now().isoformat()
        self.findings, self.evidence, self.scope = [], [], []
        self.receipt_groups = []
        self.evidence_index = {}
        self.valid_split_sources = set()
        self.inventory_records = None
        self.source_identities = None
        self.inventory = {'complete': False, 'coverage': [], 'stocks': [], 'patients': []}
        self.deadline = None
        self.max_records = min(2000, max(1, int(getattr(settings, 'DIAGNOSTICS_MAX_RECORDS', 300))))

    def evidence_for(self, kind, pk=None, *, values=None, patient_id=None, medicine_id=None, title=''):
        values = dict(values or {})
        medicine_id = medicine_id if medicine_id is not None else pk if kind == 'Lijek' else None
        if self.inventory_records and self.source_identities is None:
            self.source_identities={}
            for records in self.inventory_records.values():
                rows=records.values() if isinstance(records,dict) else records
                if not isinstance(rows,(list,tuple)) and not isinstance(records,dict): continue
                for row in rows:
                    if hasattr(row,'pk') and getattr(row,'lijek_id',None):
                        self.source_identities[(type(row).__name__,row.pk)]=row.lijek_id
        if medicine_id is None:
            medicine_id=(self.source_identities or {}).get((kind,pk))
        drug = (self.inventory_records or {}).get('drugs', {}).get(medicine_id)
        if drug:
            values.setdefault('unit', drug.jedinice_zalihe[0])
            values.setdefault('route', drug.put_primjene)
        url = ''
        if patient_id:
            url = reverse('profil_pacijenta', args=[patient_id])
        elif kind == 'KomisijskiCiklus' and pk:
            # Receipt GET has no draft-reconciliation writer, unlike centre GET.
            url = reverse('zaprimanje_ciklusa', args=[pk])
        elif kind in {'Zaliha', 'ZalihaTransakcija', 'Lijek', 'MigracijskoPocetnoStanjeZalihe'}:
            url = reverse('lista_zaliha')
        identifier = f'E{len(self.evidence)+1:04d}'
        self.evidence.append({'id': identifier, 'kind': kind, 'record_id': pk,
            'medicine_id': medicine_id if medicine_id is not None else pk if kind == 'Lijek' else None,
            'label': title or (f'{kind} #{pk}' if pk else kind), 'url': url,
            'values': {k: scalar(v) for k, v in (values or {}).items()}})
        self.evidence_index[identifier] = self.evidence[-1]
        return identifier

    def add(self, code, area, status, refs=(), *, limitation='', severity=None, reasons=(), medicine_ids=()):
        title, cause, action = CHECKS[code]
        reasons=list(dict.fromkeys(reason for reason in reasons if reason in REASONS))
        medicines = set(medicine_ids)
        medicines.update(self.evidence_index.get(ref, {}).get('medicine_id') for ref in refs)
        medicines.discard(None)
        self.findings.append({'id': f'F{len(self.findings)+1:04d}', 'code': code,
            'area': area, 'area_label': AREAS[area], 'status': status, 'status_label': STATUS_LABELS[status],
            'severity': severity or ('Visoka' if status == 'ISSUE' else 'Upozorenje' if status in {'REVIEW','ERROR'} else 'Informacija'),
            'title': title, 'possible_cause': cause, 'next_check': action, 'evidence_ids': list(refs),
            'limitation': limitation, 'reason_codes':reasons, 'reason_labels':[REASONS[r] for r in reasons],
            'medicine_ids': sorted(medicines),
            **finding_contract(code, status),
            'checked_at': timezone.now().isoformat()})

    def new_scope(self, area, entity, records, *, operation='reconcile', label=''):
        scope = {'area':area, 'entity':entity, 'operation':operation, 'label':label or entity,
                 'records':records, 'loaded':0, 'checked':0, 'skipped':0, 'skip_reasons':{}}
        self.scope.append(scope)
        return scope

    def skip_record(self, scope, reason, count=1):
        scope['skipped'] += count
        scope['skip_reasons'][reason] = scope['skip_reasons'].get(reason, 0) + count

    def bounded(self, queryset, area):
        count = queryset.count()
        scope = self.new_scope(area, queryset.model.__name__, count)
        if count > self.max_records:
            self.skip_record(scope, 'RECORD_LIMIT', count-self.max_records)
            self.add('CHECK_LIMIT', area, 'UNKNOWN', reasons=['RECORD_LIMIT'], limitation=f'Obuhvaćeno prvih {self.max_records} od {count} zapisa po ID-u.')
        items = list(queryset.order_by('pk')[:self.max_records])
        scope['loaded'] = len(items)
        for item in items:
            self.checkpoint()
            skipped = scope['skipped']
            yield item
            if scope['skipped'] == skipped:
                scope['checked'] += 1

    def checkpoint(self):
        if self.deadline is not None and monotonic() >= self.deadline:
            raise BudgetExceeded()

    def scan_all(self, queryset, label, *, operation='scan', area='stock'):
        """Full inventory census, including inactive records; no sample limit."""
        scope = self.new_scope(area, queryset.model.__name__, queryset.count(), operation=operation, label=label)
        if area == 'stock':
            self.inventory['coverage'].append(scope)
        # Ordinary SELECT pages cooperate with the per-query timeout guard.
        # A PostgreSQL named cursor cannot execute that guard's SET LOCAL.
        last_pk = 0
        while True:
            self.checkpoint()
            page = list(queryset.filter(pk__gt=last_pk).order_by('pk')[:500])
            scope['loaded'] += len(page)
            if not page:
                break
            for item in page:
                self.checkpoint()
                skipped = scope['skipped']
                yield item
                if operation != 'scan' and scope['skipped'] == skipped:
                    scope['checked'] += 1
                last_pk = item.pk


def check_stock(run):
    from patients.fridge_history import fridge_balances_at
    from patients.inventory import izracunaj_frizider_iz_transakcija, patient_reservation_breakdown
    # The historical reader scans the ledger as a whole: never silently truncate
    # that scan and then declare a partially counted balance correct.
    ledger_limit = min(100000, int(getattr(settings, 'DIAGNOSTICS_MAX_LEDGER', 20000)))
    if m.ZalihaTransakcija.objects.count() > ledger_limit:
        scope=run.new_scope('stock','Zaliha',m.Zaliha.objects.count(),label='Saldi i dodatne provjere — preskočeno zbog limita prometa')
        run.skip_record(scope,'LEDGER_LIMIT',scope['records'])
        run.add('CHECK_LIMIT', 'stock', 'UNKNOWN', reasons=['LEDGER_LIMIT'], limitation='Promet prelazi limit cijelog obračuna; saldo nije djelimično sabiran.')
        return
    balances = fridge_balances_at(run.today, current=False)
    stocks = m.Zaliha.objects.select_related('lijek')
    for stock in run.scan_all(stocks, 'Fizički saldi — poređenje s prometom', operation='reconcile'):
        drug = stock.lijek
        initial = m.MigracijskoPocetnoStanjeZalihe.objects.filter(lijek=drug).first()
        txs = m.ZalihaTransakcija.objects.filter(lijek=drug)
        boundary = (initial.ledger_checkpoint_id or 0) if initial else 0
        relevant = txs.filter(pk__gt=boundary)
        balance = balances.get(drug.pk, {})
        reliable = balance.get('quantity') is not None and not relevant.filter(datum__gt=run.today).exists()
        expected = izracunaj_frizider_iz_transakcija(drug) if reliable else None
        refs = [run.evidence_for('Zaliha', stock.pk, medicine_id=drug.pk, title=f'{drug.naziv} · {drug.strength} · {drug.pharmaceutical_form}', values={
            'recorded_fridge': stock.u_frizideru, 'recorded_at_patient': stock.kod_pacijenata,
            'expected_fridge': expected, 'difference': stock.u_frizideru-expected if expected is not None else None,
            'unit': drug.jedinice_zalihe[0], 'route': drug.put_primjene, 'history_reliable': reliable})]
        if initial:
            refs.append(run.evidence_for('MigracijskoPocetnoStanjeZalihe', initial.pk, values={
                'opening_quantity': initial.kolicina, 'checkpoint_id': boundary, 'recorded_on': initial.izmijenjeno.date()}))
        for tx in relevant.order_by('-pk')[:30]:
            refs.append(run.evidence_for('ZalihaTransakcija', tx.pk, patient_id=tx.pacijent_id, values={
                'event_type': tx.tip, 'event_date': tx.datum, 'quantity': tx.kolicina,
                'fridge_delta': tx.frizider_delta(), 'source_type': tx.referenca_tip, 'source_id': tx.referenca_id}))
        truncated = 'Prikazano je najviše 30 posljednjih kretanja; obračun obuhvata sva kretanja.' if relevant.count()>30 else ''
        run.add('STOCK_BALANCE' if reliable else 'STOCK_HISTORY', 'stock',
            ('OK' if stock.u_frizideru == expected else 'ISSUE') if reliable else 'UNKNOWN', refs,
            reasons=[] if reliable else ['HISTORY_INSUFFICIENT'],
            limitation=truncated if reliable else 'Nema dovoljno pouzdanih podataka. Današnji saldo nije dokaz historijskog početka; fizičko brojanje treba posebno evidentirati.')
        if not reliable:
            run.skip_record(run.scope[-1], 'HISTORY_INSUFFICIENT')
        if stock.u_frizideru < 0 or stock.kod_pacijenata < 0:
            run.add('STOCK_NEGATIVE', 'stock', 'ISSUE', refs[:1])
        patients = m.Pacijent.objects.filter(rezervacije_lijeka__lijek=drug, rezervacije_lijeka__aktivno=True).distinct()
        reserved = sum((patient_reservation_breakdown(p, medicine_ids=(drug.pk,))['total_effective'] for p in patients), Decimal('0'))
        reserve_ref = run.evidence_for('Zaliha', stock.pk, medicine_id=drug.pk, values={'reserved':reserved, 'recorded_fridge':stock.u_frizideru,
            'physical_shortfall':max(Decimal('0'),reserved-stock.u_frizideru), 'unit':drug.jedinice_zalihe[0]})
        run.add('STOCK_RESERVATIONS','stock','ISSUE' if reserved>stock.u_frizideru else 'OK',[reserve_ref],
                reasons=['STOCK_OVERALLOCATED'] if reserved>stock.u_frizideru else [])
    duplicated = m.ZalihaTransakcija.objects.exclude(referenca_tip='').filter(referenca_id__isnull=False).values(
        'referenca_tip','referenca_id','tip','lijek_id').annotate(number=Count('pk')).filter(number__gt=1)
    if duplicated.count()>run.max_records:
        run.add('CHECK_LIMIT','stock','UNKNOWN',reasons=['RECORD_LIMIT'],limitation='Potencijalno ponovljeni izvori prelaze limit prikaza.')
    for item in duplicated.order_by('lijek_id','referenca_tip','referenca_id','tip')[:run.max_records]:
        if (item['referenca_tip'], item['referenca_id'], item['tip'], item['lijek_id']) in run.valid_split_sources:
            continue  # A full source reconciliation proved this split quantity and effect.
        refs=[run.evidence_for('ZalihaTransakcija',tx.pk,patient_id=tx.pacijent_id,values={
                  'event_type':tx.tip,'quantity':tx.kolicina,'event_date':tx.datum,'fridge_delta':tx.frizider_delta(),
                  'source_type':tx.referenca_tip,'source_id':tx.referenca_id})
              for tx in m.ZalihaTransakcija.objects.filter(referenca_tip=item['referenca_tip'],referenca_id=item['referenca_id'],
                  tip=item['tip'],lijek_id=item['lijek_id']).order_by('pk')[:30]]
        # uskladi_pocetno_stanje_zalihe records every new count as a delta
        # referencing the same mutable opening balance. That reference is not
        # an idempotency key. Keep this history visible without a false alarm.
        correction_series=(item['tip']==m.ZalihaTransakcija.TIP_KOREKCIJA
            and item['referenca_tip']=='MigracijskoPocetnoStanjeZalihe'
            and m.MigracijskoPocetnoStanjeZalihe.objects.filter(pk=item['referenca_id'],lijek_id=item['lijek_id']).exists())
        if item['tip']==m.ZalihaTransakcija.TIP_KOREKCIJA and item['referenca_tip']=='MigracijskiSnapshotPacijenta':
            snapshot=m.MigracijskiSnapshotPacijenta.objects.filter(pk=item['referenca_id'],lijek_id=item['lijek_id']).first()
            # data_corrections: repeated home counts reference the same mutable
            # snapshot; each is a separate delta, with zero fridge effect.
            series=m.ZalihaTransakcija.objects.filter(referenca_tip=item['referenca_tip'],referenca_id=item['referenca_id'],
                tip=item['tip'],lijek_id=item['lijek_id'])
            correction_series=bool(snapshot and not series.exclude(pacijent_id=snapshot.pacijent_id,
                lokacija='KOD_PACIJENTA',promjena_salda=0).exists())
        run.add('STOCK_CORRECTION_HISTORY' if correction_series else 'STOCK_DUPLICATE','stock',
            'OK' if correction_series else 'REVIEW',refs,
            medicine_ids=[item['lijek_id']],
            reasons=['CORRECTION_SERIES'] if correction_series else [],
            limitation='Prikazano najviše 30 kretanja po izvoru. Zajednička veza sama ne dokazuje duplikat niti ispravnost iznosa.')
    # Same scalar invariants as patients.integrity; these are validations,
    # not a second inventory/commission calculation.
    for model, predicate in ((m.Komisija,Q(preostale_doze__lt=0)|Q(broj_odobrenih_doza__lt=0)),
                             (m.PacijentZaduzenje,Q(preostalo__lt=0)|Q(ukupno_zaduzeno__lt=0)|Q(preostalo__gt=F('ukupno_zaduzeno')))):
        for item in run.bounded(model.objects.filter(predicate),'stock'):
            values={'remaining_quantity':getattr(item,'preostale_doze',getattr(item,'preostalo',None)),
                    'total_quantity':getattr(item,'broj_odobrenih_doza',getattr(item,'ukupno_zaduzeno',None))}
            ref=run.evidence_for(model.__name__,item.pk,patient_id=item.pacijent_id,medicine_id=item.lijek_id,values=values)
            run.add('QUANTITY_INVARIANT','stock','ISSUE',[ref])


def check_home(run):
    from patients.home_therapy_evidence import home_evidence, supports_home_evidence
    for patient in run.bounded(m.Pacijent.objects.filter(aktivan=True,lijek__isnull=False).select_related('lijek'),'home'):
        evidence = home_evidence(patient,today=run.today)
        if evidence is None:
            reason = 'HOME_NO_EVIDENCE' if supports_home_evidence(patient) else 'HOME_NOT_APPLICABLE'
            run.skip_record(run.scope[-1], reason)
            if reason == 'HOME_NO_EVIDENCE':
                ref = run.evidence_for('Pacijent',patient.pk,patient_id=patient.pk,medicine_id=patient.lijek_id)
                run.add('HOME_REVIEW','home','UNKNOWN',[ref],reasons=[reason])
            continue
        ref=run.evidence_for('Pacijent',patient.pk,patient_id=patient.pk,medicine_id=patient.lijek_id,values={
            'issued_on':evidence.issued_on,'issued_quantity':evidence.issued_quantity,
            'last_application':evidence.last_application,'reported_remaining':evidence.remaining_quantity,
            'checked_on':evidence.report.datum_provjere if evidence.report else None})
        run.add('HOME_APPLICATION' if evidence.last_application is None else 'HOME_REVIEW','home',
            'UNKNOWN' if evidence.needs_review else 'OK',[ref],
            reasons=home_reasons(evidence),
             limitation='Izdavanje, izjava pacijenta i procjena sistema su odvojene evidencije. Nije kreirana primjena ni termin.')
        if evidence.needs_review:
            run.skip_record(run.scope[-1], home_reasons(evidence)[0])


def home_reasons(evidence):
    if not evidence:
        return []
    reasons=[]
    if evidence.last_application is None:
        reasons.append('HOME_APPLICATION_UNKNOWN')
    if evidence.remaining_quantity is None:
        reasons.append('HOME_QUANTITY_UNKNOWN')
    if evidence.needs_review and not reasons:
        reasons.append('HOME_EVIDENCE_REVIEW')
    return reasons


def commission_calculation_values(row):
    """Project existing calculations into evidence; never recalculate needs."""
    fields=('period_start','period_end','needed','physically_secured','confirmed_incoming','uncovered_need','reserve','raw_request')
    explanation=row.get('objasnjenje_kolicine_komisije')
    values={key:explanation.get(key) if explanation else None for key in fields}
    decision=row.get('commission_decision')
    oral=row.get('oralni_obracun')
    if decision is not None:
        mapping={'period_start':'period_start','period_end':'period_end','needed':'minimum_required_quantity',
            'physically_secured':'physically_covered_quantity','confirmed_incoming':'confirmed_delivery_quantity',
            'reserve':'safety_reserve_quantity','raw_request':'calculated_quantity',
            'usable_approval':'usable_existing_approval_quantity','existing_request_quantity':'existing_request_quantity'}
        values.update({field:getattr(decision,attribute) for field,attribute in mapping.items()})
        values['calculation_source']='COMMISSION_DECISION'
    elif oral is not None:
        # Oral planning publishes a different canonical structure. A daily
        # consumption or an approved amount is not a confirmed physical receipt.
        mapping={'needed':'bruto_potreba','uncovered_need':'neto_potreba','raw_request':'neto_potreba',
            'daily_consumption':'dnevna_potrosnja','target_days':'ciljni_period_dana',
            'package_size':'velicina_pakovanja','package_count':'broj_pakovanja'}
        values.update({field:oral.get(attribute) for field,attribute in mapping.items()})
        values['reserve']=row.get('sigurnosna_rezerva')
        values['calculation_source']='ORAL_CALCULATION'
    else:
        values['calculation_source']='HOME_EXPLANATION' if explanation else 'UNAVAILABLE'
    return values


def commission_finding(run, row):
    patient, drug = row['pacijent'], row['lijek']
    delivery = row.get('kanonski_ocekivana_isporuka') or row.get('ocekivana_pouzdana_isporuka')
    estimated = bool(row.get('ocekivani_datum_dolaska_je_procjena', True))
    covered = row.get('sigurno_pokriven_do') or row.get('fizicki_pokriven_do')
    quantity = row.get('final_procurement_units')
    coverage = row.get('coverage') or {}
    values={'proposal':quantity, 'system_proposal':row.get('sistem_predlaze'), 'delivery_date':delivery,
        'delivery_estimated':estimated, 'covered_until':covered, 'manual_exclusion':bool(row.get('rucno_iskljucen')),
        'included':bool(row.get('included_in_draft')), 'unit':drug.jedinice_zalihe[0],
        **{key:coverage.get(key) for key in ('at_patient','reserved_in_fridge','free_fridge','unused_approved','approved_waiting_delivery','submitted')}}
    values.update(commission_calculation_values(row))
    values['first_uncovered']=row.get('prva_nepokrivena_terapija')
    home = row.get('home_evidence')
    possible = getattr(row.get('planning_result'), 'planiranje_moguce', False)
    values['planning_possible']=bool(possible)
    # A delivery may precede the period being ordered for. Coverage until that
    # delivery alone says nothing about a later, explicitly uncovered period.
    # Use canonical quantities; do not recompute the clinical schedule here.
    later_uncovered = bool(covered and values.get('period_start') and
        values.get('period_end') and covered < values['period_start'] <= values['period_end'] and
        values.get('uncovered_need') is not None and values['uncovered_need'] > 0)
    values['later_uncovered_period']=later_uncovered
    ref=run.evidence_for('Pacijent',patient.pk,patient_id=patient.pk,medicine_id=drug.pk,values=values)
    reasons=home_reasons(home)
    if not delivery:
        reasons.append('DELIVERY_MISSING')
    if not possible:
        reasons.append('PLAN_UNAVAILABLE')
    if row.get('relativna_pocetna_projekcija'):
        reasons.append('RELATIVE_PLAN')
    if reasons:
        code,status='COMMISSION_INPUTS','UNKNOWN'
    elif row.get('rucno_iskljucen'):
        code,status='COMMISSION_PLAN','OK'
    elif quantity and covered and covered>=delivery and not later_uncovered:
        code,status='COMMISSION_COVERAGE','REVIEW'
    else:
        code,status='COMMISSION_PLAN','OK'
    if estimated and delivery:
        reasons.append('DELIVERY_ESTIMATED')
        if status == 'OK':
            code = 'COMMISSION_PROJECTION'
    run.add(code,'commission',status,[ref],reasons=reasons,limitation='Prikazan je izlaz istog servisa kao Komisijski centar, uz navedenu pretpostavku isporuke. Nezavisne veze i količine su zasebna oblast. Odobreno bez zaprimanja nije fizička zaliha.')


def check_commission(run):
    from patients.commission_planning import commission_planning_rows
    settings_row=m.PostavkeSistema.objects.filter(pk=1).first()
    if settings_row is None:
        scope=run.new_scope('commission','Pacijent',m.Pacijent.objects.filter(aktivan=True,lijek__isnull=False).count())
        run.skip_record(scope,'SETTINGS_MISSING',scope['records'])
        run.add('COMMISSION_INPUTS','commission','UNKNOWN',reasons=['SETTINGS_MISSING'],limitation='Nisu evidentirane postavke sistema. Dijagnostika ih ne kreira.')
        return
    # Existing get_settings() calls get_or_create. Seed only the isolated cache
    # with the already existing object, so it has no implicit initialisation path.
    set_cached('commission_settings',1,settings_row)
    count=m.Pacijent.objects.filter(aktivan=True,lijek__isnull=False).count()
    limit=min(run.max_records, int(getattr(settings,'DIAGNOSTICS_MAX_COMMISSION_PATIENTS',150)))
    if count>limit:
        scope=run.new_scope('commission','Pacijent',count)
        run.skip_record(scope,'COMMISSION_LIMIT',count)
        run.add('CHECK_LIMIT','commission','UNKNOWN',reasons=['COMMISSION_LIMIT'],limitation=f'{count} aktivnih pacijenata prelazi limit {limit}. Zajednički planer nije pokrenut na nepotpunom uzorku.')
        return
    rows=commission_planning_rows(today=run.today)
    scope=run.new_scope('commission','Pacijent',count)
    scope['loaded']=len(rows)
    for row in rows:
        run.checkpoint()
        commission_finding(run,row)
        if run.findings[-1]['status']=='UNKNOWN':
            run.skip_record(scope,run.findings[-1]['reason_codes'][0])
        else:
            scope['checked']+=1


def check_documents(run):
    from patients.medication_groups import strict_equivalent_medicine_ids
    from patients.medicine_document_metadata import presentation_metadata, MedicineMetadataError
    from patients.treatment_review_approval import treatment_review_commission, approval_document_values, TreatmentReviewApprovalError
    drugs=m.Lijek.objects.filter(pacijent__aktivan=True).distinct()
    # Use the actual FK related_query_name, which is 'pacijent' in this model.
    for drug in run.bounded(drugs,'documents'):
        ref=run.evidence_for('Lijek',drug.pk,values={'atc_present':bool(drug.atc_code.strip()),
            'form_present':bool(drug.pharmaceutical_form.strip()),'strength_present':bool(drug.strength.strip())})
        try:
            presentation_metadata(drug)
            status='OK'
        except MedicineMetadataError:
            status='ISSUE'
        run.add('DOCUMENT_METADATA','documents',status,[ref])
    therapies=m.Terapija.objects.filter(workflow_status=m.Terapija.STATUS_POTVRDJENA,is_migration=False).select_related('pacijent','lijek')
    for therapy in run.bounded(therapies,'documents'):
        ref=run.evidence_for('Terapija',therapy.pk,patient_id=therapy.pacijent_id,medicine_id=therapy.lijek_id,values={'event_date':therapy.datum,'quantity':therapy.kolicina})
        try:
            commission=treatment_review_commission(therapy.pacijent,therapy)
            # A link to another presentation cannot validate this document.
            if commission.lijek_id not in strict_equivalent_medicine_ids(therapy.lijek) or commission.datum_odobrenja>therapy.datum:
                run.add('DOCUMENT_LINK','documents','ISSUE',[ref])
                continue
            values=approval_document_values(commission)
            approval_ref=run.evidence_for('Komisija',commission.pk,patient_id=therapy.pacijent_id,values={
                'approval_date':commission.datum_odobrenja,'approval_number_present':bool(values['broj_saglasnosti'])})
            run.add('DOCUMENT_INPUTS','documents','OK' if values['broj_saglasnosti'] else 'REVIEW',[ref,approval_ref],
                reasons=[] if values['broj_saglasnosti'] else ['APPROVAL_NUMBER_MISSING'],
                limitation='Provjereni su ulazi i veza. Generisanje stvarnog PDF-a nije pokrenuto.')
        except TreatmentReviewApprovalError:
            run.add('DOCUMENT_LINK','documents','REVIEW',[ref],limitation='Nije jednoznačno utvrđeno pripadajuće odobrenje. Nije izabrana najnovija saglasnost.')


def check_technical(run):
    from .events import print_events
    for event in print_events():
        ref=run.evidence_for('TehnickiDogadjaj',values={
            'event_id':event['id'],'event_date':event['date'],'error_category':event['category'],'document_kind':event['kind']})
        run.add('PRINT_FAILURE','technical','REVIEW' if event['category']=='VALIDATION' else 'ISSUE',[ref])
    run.add('TECHNICAL_SCOPE','technical','OK',limitation='Provjera štampe ne generiše pacijentske dokumente. Stariji nestrukturirani logovi i stvarni printer nisu provjereni.')


def check_all_stock(run):
    from .inventory_audit import check_inventory
    from .movement_audit import check_movements
    check_inventory(run)
    check_movements(run)
    check_stock(run)
    from .inventory_audit import check_quantity_trail
    check_quantity_trail(run)


from .appointment_audit import check_appointments
from .commission_audit import check_commission_links

def check_all_home(run):
    from .home_audit import check_home_ledger
    check_home_ledger(run)
    check_home(run)

CHECKERS=(('stock',check_all_stock),('appointments',check_appointments),('home',check_all_home),
          ('commission_links',check_commission_links),('commission',check_commission),
          ('documents',check_documents),('technical',check_technical))


def run_diagnostics(*, today=None, seconds=None):
    run=Run(today=today)
    start=monotonic()
    completed=[]
    seconds = min(30, max(.01,float(seconds if seconds is not None else getattr(settings,'DIAGNOSTICS_TIMEOUT_SECONDS',15))))
    run.deadline = start + seconds
    current='stock'
    try:
        with diagnostic_snapshot(seconds):
            for current,check in CHECKERS:
                try:
                    with transaction.atomic():
                        check(run)
                    completed.append(current)
                except BudgetExceeded:
                    raise
                except Exception as exc:
                    if getattr(getattr(exc,'__cause__',None),'pgcode',None)=='57014':
                        raise BudgetExceeded() from None
                    ref=run.evidence_for('Provjera',values={'error_category':'WRITE_BLOCKED' if isinstance(exc,ReadOnlyViolation) else 'CHECK_ERROR'})
                    run.add('CHECK_FAILED',current,'ERROR',[ref],reasons=['WRITE_BLOCKED' if isinstance(exc,ReadOnlyViolation) else 'CHECK_ERROR'],limitation='Ovaj dio nije završen. Ostale provjere nastavljaju u istom presjeku podataka.')
    except Exception as exc:
        # Never include exception messages, SQL, filenames or arbitrary log text.
        category='TIME_LIMIT' if isinstance(exc,BudgetExceeded) or getattr(getattr(exc,'__cause__',None),'pgcode',None)=='57014' else 'WRITE_BLOCKED' if isinstance(exc,ReadOnlyViolation) else 'CHECK_ERROR'
        ref=run.evidence_for('Provjera',values={'error_category':category})
        run.add('CHECK_LIMIT' if category=='TIME_LIMIT' else 'CHECK_FAILED',current,'ERROR',[ref],
            reasons=[category],
            limitation='Prekinuto prije završetka. Neprovjereni dijelovi nisu proglašeni ispravnim.')
    statuses={f['status'] for f in run.findings}
    status='FAILED' if not completed and 'ERROR' in statuses else 'PARTIAL' if len(completed)<len(CHECKERS) or statuses & {'UNKNOWN','ERROR'} else 'COMPLETED'
    limited_areas=list(dict.fromkeys(f['area'] for f in run.findings if f['code']=='CHECK_LIMIT'))
    execution_status='FAILED' if status=='FAILED' else 'PARTIAL' if len(completed)<len(CHECKERS) or limited_areas else 'COMPLETED'
    for scope in run.scope:
        scope['unprocessed'] = max(0, scope['records'] - (scope.get('loaded',0) if scope.get('operation')=='scan'
                                                       else scope['checked']+scope.get('skipped',0)))
    return {'id':run.id,'version':__version__,'check_version':CHECK_VERSION,'read_only':True,'started_at':run.started,
        'finished_at':timezone.now().isoformat(),'status':status,'execution_status':execution_status,
        'limited_areas':limited_areas,'elapsed_seconds':round(monotonic()-start,3),
        'findings':run.findings,'evidence':run.evidence,'scope':run.scope,'inventory':run.inventory,
        'receipt_groups':run.receipt_groups,
        'completed_areas':completed,'unexamined_areas':[a for a,_ in CHECKERS if a not in completed],
        'not_implemented':list(NOT_IMPLEMENTED),
        'snapshot':'REPEATABLE READ / READ ONLY' if connection.vendor=='postgresql' else 'SQLite read transaction / query_only',
        'notice':'Softver prikazuje evidentirano stanje. Stvarno stanje frižidera potvrđuje se evidentiranim brojanjem.'}
