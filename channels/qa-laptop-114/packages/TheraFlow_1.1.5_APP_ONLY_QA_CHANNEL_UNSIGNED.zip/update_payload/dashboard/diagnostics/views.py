import hashlib
import json
from functools import wraps

from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.core import signing
from django.core.cache import cache
from django.core.exceptions import PermissionDenied
from django.http import Http404, HttpResponse
from django.shortcuts import redirect, render
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET, require_POST

from dashboard.permissions import je_admin
from patients.models import AktivnostLog
from . import ai
from .engine import run_diagnostics
from .export import export_report
from .display import display_evidence
from .inventory_display import inventory_display
from .catalog import AREAS, REASONS, NOT_IMPLEMENTED

TTL=1800
RUN_LABELS={'COMPLETED':'Završena provjera','PARTIAL':'Djelimična provjera','FAILED':'Neuspjela provjera'}


def admin_only(view):
    @login_required
    @never_cache
    @wraps(view)
    def wrapped(request,*args,**kwargs):
        if not je_admin(request.user):
            raise PermissionDenied('Ova dijagnostika je dostupna samo administratoru TheraFlowa.')
        if not getattr(settings,'ADMIN_DIAGNOSTICS_ENABLED',True):
            raise Http404('Administratorska dijagnostika je isključena.')
        return view(request,*args,**kwargs)
    return wrapped


def store(run,user):
    cache.set('diagnostics:run:'+run['id'],{'owner':user.pk,'run':run},TTL)


def load(run_id,user):
    item=cache.get('diagnostics:run:'+str(run_id))
    if not item or item['owner']!=user.pk:
        raise Http404('Rezultat nije dostupan ili je istekao. Pokrenite novu provjeru.')
    return item['run']


def audit(user,action,run_id):
    try:
        AktivnostLog.objects.create(korisnik=user,akcija=action,objekat_tip='AdministratorskaDijagnostika',
                                   opis='Pokretanje '+run_id)
        return True
    except Exception:
        return False


@admin_only
@require_GET
def index(request):
    return render(request,'dashboard/diagnostics/index.html',{'ai_message':ai.availability()[1]})


@admin_only
@require_POST
def start(request):
    if not cache.add('diagnostics:running',request.user.pk,40):
        return render(request,'dashboard/diagnostics/index.html',{
            'ai_message':ai.availability()[1],'error':'Provjera je već u toku. Sačekajte završetak pa pokušajte ponovo.'},status=429)
    try:
        run=run_diagnostics()
        run['read_only']=True  # This phase also leaves the business audit unchanged.
        store(run,request.user)
    finally:
        cache.delete('diagnostics:running')
    return redirect('admin_diagnostics_result',run_id=run['id'])


def context(run):
    scopes=[{**s,'label':s.get('label',AREAS.get(s['area'],s['area'])),
             'skip_labels':[(REASONS.get(r,r),n) for r,n in s.get('skip_reasons',{}).items()]}
            for s in run['scope']]
    by_id={e['id']:e for e in run['evidence']}
    findings=[]
    for f in run['findings']:
        first=next((by_id[ref] for ref in f['evidence_ids'] if ref in by_id),None)
        facts=display_evidence(first)['display_values'] if first else []
        findings.append({**f,'source_label':first['label'] if first else '',
                         'source_url':first['url'] if first else '', 'brief_facts':facts})
    groups=[]
    for group in run.get('receipt_groups',[]):
        children=[f for f in findings if f['id'] in group['finding_ids']]
        groups.append({**group,'findings':children,'request_count':len(children),
            'presentations':[{**p,'display_values':display_evidence({'values':p['values']})['display_values']}
                for p in group['presentations']]})
    grouped={f['id'] for g in groups for f in g['findings']}
    return {'run':run,'inventory_display':inventory_display(run),'run_label':RUN_LABELS[run['status']],
            'receipt_groups':groups,
            'finding_counts':{s:sum(f['status']==s for f in findings) for s in ('ISSUE','REVIEW','UNKNOWN','OK')},
            'not_implemented_labels':[NOT_IMPLEMENTED[k] for k in run.get('not_implemented',[]) if k in NOT_IMPLEMENTED],
            'inventory_scopes':[s for s in scopes if s['area']=='stock'],
            'unknown_count':sum(f['status']=='UNKNOWN' for f in run['findings']),
            'limited_labels':[AREAS[a] for a in run.get('limited_areas',[]) if a in AREAS],
            'unexamined_labels':[AREAS.get(area,area) for area in run['unexamined_areas']],
            'scope_display':scopes,
            'findings':sorted((f for f in findings if f['status']!='OK' and f['id'] not in grouped),key=lambda f:{'ISSUE':0,'REVIEW':1,'ERROR':2,'UNKNOWN':3}[f['status']]),
            'passed':[f for f in findings if f['status']=='OK' and f['id'] not in grouped],
            'ai_message':ai.availability()[1]}


@admin_only
@require_GET
def result(request,run_id):
    data=context(load(run_id,request.user))
    selected=request.GET.get('status','')
    if selected in {'ISSUE','REVIEW','UNKNOWN','ERROR','OK'}:
        data['findings']=[f for f in data['findings']+data['passed'] if f['status']==selected]
        data['passed']=[]
        data['receipt_groups']=[{**g,'findings':[f for f in g['findings'] if f['status']==selected]}
            for g in data['receipt_groups'] if any(f['status']==selected for f in g['findings'])]
        data['selected_status']=selected
    return render(request,'dashboard/diagnostics/result.html',data)


def finding_context(run,finding_id):
    finding=next((f for f in run['findings'] if f['id']==finding_id),None)
    if not finding:
        raise Http404()
    by_id={e['id']:e for e in run['evidence']}
    return {**context(run),'finding':finding,'evidence':[display_evidence(by_id[ref])
        for ref in dict.fromkeys(finding['evidence_ids']) if ref in by_id]}


@admin_only
@require_GET
def evidence(request,run_id,finding_id):
    run=load(run_id,request.user)
    data=finding_context(run,finding_id)
    quantity=request.GET.get('quantity')
    if quantity and data['finding']['code']=='MEDICINE_TRAIL':
        wanted={e for s in run.get('inventory',{}).get('stocks',[]) for p in s.get('quantity_trail',[])
            if p['finding_id']==finding_id and p['key']==quantity for e in p['evidence_ids']}
        if wanted: data['evidence']=[e for e in data['evidence'] if e['id'] in wanted]
    return render(request,'dashboard/diagnostics/evidence.html',data)


def preview_context(run,user,*,finding_id=None):
    payload=export_report(run,finding_id=finding_id)
    text=json.dumps(payload,ensure_ascii=False,indent=2)
    token=signing.dumps({'run':run['id'],'user':user.pk,'finding':finding_id,
        'digest':hashlib.sha256(text.encode()).hexdigest()},salt='diagnostics-preview')
    return payload,text,token


def verify_preview(request,run,finding_id=None):
    payload,text,_=preview_context(run,request.user,finding_id=finding_id)
    try:
        token=signing.loads(request.POST.get('preview_token',''),salt='diagnostics-preview',max_age=TTL)
        if token != {'run':run['id'],'user':request.user.pk,'finding':finding_id,'digest':hashlib.sha256(text.encode()).hexdigest()}:
            raise signing.BadSignature()
    except signing.BadSignature:
        raise PermissionDenied('Ponovo pregledajte tačan sadržaj prije izvoza ili AI slanja.') from None
    return payload,text


@admin_only
@require_GET
def export_preview(request,run_id):
    run=load(run_id,request.user)
    _,text,token=preview_context(run,request.user)
    return render(request,'dashboard/diagnostics/export.html',{**context(run),'payload_json':text,'preview_token':token})


@admin_only
@require_POST
def download(request,run_id):
    run=load(run_id,request.user)
    _,text=verify_preview(request,run)
    response=HttpResponse(text,content_type='application/json; charset=utf-8')
    response['Content-Disposition']='attachment; filename="TheraFlow_dijagnostika.json"'
    return response


@admin_only
@require_GET
def ai_preview(request,run_id,finding_id):
    run=load(run_id,request.user)
    data=finding_context(run,finding_id)
    _,text,token=preview_context(run,request.user,finding_id=finding_id)
    return render(request,'dashboard/diagnostics/ai.html',{**data,'payload_json':text,'preview_token':token,'ai_available':ai.availability()[0]})


@admin_only
@require_POST
def explain(request,run_id,finding_id):
    run=load(run_id,request.user)
    data=finding_context(run,finding_id)
    payload,text=verify_preview(request,run,finding_id)
    key=f'diagnostics:ai:{run_id}:{finding_id}'
    answer=cache.get(key)
    error=None
    if not answer:
        try:
            if not ai.availability()[0]:
                raise ai.AIUnavailable(ai.availability()[1])
            if not cache.add(key+':cooldown',True,60):
                raise ai.AIUnavailable('Zahtjev je u toku ili je nedavno pokušan. Ponovite za jednu minutu; lokalni dokaz ostaje dostupan.')
            if not cache.add(f'diagnostics:ai-user:{request.user.pk}',True,30):
                raise ai.AIUnavailable('Pričekajte 30 sekundi između AI zahtjeva. Lokalni nalazi su dostupni.')
            answer=ai.explain(payload)
            cache.set(key,answer,TTL)
            audit(request.user,'Administratorska dijagnostika — AI objašnjenje',run['id'])
        except ai.AIUnavailable as exc:
            error=str(exc)
    _,_,token=preview_context(run,request.user,finding_id=finding_id)
    labels={'sazetak':'Sažetak','dokazi':'Dokazi','moguci_uzroci':'Mogući uzroci — hipoteze',
            'sljedeca_provjera':'Sljedeća provjera','ogranicenja':'Ograničenja'}
    sections=[{'label':labels[k],**v} for k,v in (answer or {}).items()]
    return render(request,'dashboard/diagnostics/ai.html',{**data,'payload_json':text,'preview_token':token,
        'ai_available':ai.availability()[0],'error':error,'sections':sections})
