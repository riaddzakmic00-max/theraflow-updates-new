"""Read-only statement totals. A known subtotal is never a complete remainder."""
from collections import defaultdict
from decimal import Decimal

ZERO = Decimal('0')


def home_summary(drug_id, *, assignments, snapshots, reports, issues, oral, therapies, today):
    participants = {a.pacijent_id for a in assignments if a.lijek_id==drug_id and a.aktivno}
    participants |= {s.pacijent_id for s in snapshots if s.lijek_id==drug_id
                     and (s.kod_pacijenta is None or s.kod_pacijenta>0)}
    relevant_reports = [r for r in reports if r.lijek_id==drug_id]
    participants |= {r.pacijent_id for r in relevant_reports}
    statements, issuances = defaultdict(list), defaultdict(list)
    for row in relevant_reports:
        if row.vrsta=='IZJAVA':
            statements[row.pacijent_id].append(row)
        elif row.vrsta=='IZDAVANJE':
            issuances[row.pacijent_id].append((row.datum_izdavanja,row.kreirano))
    for row in issues:
        therapy = therapies.get(row.terapija_id)
        if row.lijek_id==drug_id and not (therapy and (therapy.workflow_status=='PONISTENA' or therapy.ponistena_at)):
            participants.add(row.pacijent_id)
            issuances[row.pacijent_id].append((row.datum,row.kreirano))
    for row in oral:
        if row.lijek_id==drug_id and row.status!='PONISTENO':
            participants.add(row.pacijent_id)
            issuances[row.pacijent_id].append((row.datum_izdavanja,row.kreirano))
    subtotal, known, dates = ZERO, 0, set()
    for patient_id in participants:
        candidates = [r for r in statements[patient_id] if r.datum_provjere and r.datum_provjere<=today]
        statement = max(candidates, key=lambda r:(r.datum_provjere,r.kreirano,r.pk), default=None)
        if statement is None or statement.preostala_kolicina is None or statement.preostala_kolicina<0:
            continue
        if any(day is None or day>statement.datum_provjere or created>statement.kreirano
               for day,created in issuances[patient_id]):
            continue
        subtotal += statement.preostala_kolicina
        known += 1
        dates.add(statement.datum_provjere)
    complete = bool(participants) and known==len(participants) and len(dates)==1
    return {'reported_remaining':subtotal if complete else None,
            'reported_subtotal':subtotal if known else None,
            'reports_expected':len(participants), 'reports_known':known,
            'reports_missing':len(participants)-known, 'reports_complete':complete,
            'report_dates_differ':len(dates)>1,
            'checked_on':next(iter(dates)) if len(dates)==1 else None}
