"""Actual commission links and quantities, independent of delivery projections.

Uses the canonical coverage service for unreceived rights. Does not invoke
approval/receiving writers or allocate shared free stock per page/patient.
"""
from collections import defaultdict
from copy import copy
from decimal import Decimal, InvalidOperation
from patients import models as m
from patients.commission_exclusions import visible_commission_requests
from patients.commission_service import patient_commission_coverage
from patients.request_cache import set_cached

ZERO=Decimal('0')

def corrected_allocation(audit, ledger):
    return audit.zaprimljena_kolicina + sum((t.promjena_rezervacije for t in ledger
        if t.izvorna_transakcija_id == audit.fizicka_transakcija_id
        and t.rezervacija_id == audit.rezervacija_id and t.korekcija_id
        and t.korekcija.scope in {'inventory_receipt', 'inventory_allocation'}), ZERO)


def restricted_receipt_units(receipts, ledger):
    ids = {t.pk for t in receipts}
    return -sum((t.promjena_rezervacije for t in ledger if t.izvorna_transakcija_id in ids
        and t.korekcija_id and t.korekcija.scope == 'inventory_allocation'), ZERO)


def known_inventory_correction(tx):
    if tx.korekcija_id and tx.korekcija.scope == 'inventory_patient_stock':
        from patients.patient_fridge_corrections import allocation_basis
        assigned = tx if tx.tip == 'ASSIGN_FREE_STOCK_TO_PATIENT' else tx.povezani_prometi.filter(
            tip='ASSIGN_FREE_STOCK_TO_PATIENT', korekcija=tx.korekcija).first()
        if not assigned or not assigned.rezervacija_id:
            return False
        linked, basis, _ = allocation_basis(assigned.rezervacija)
        return linked and basis is not None
    return bool(tx.korekcija_id and tx.korekcija.scope in {
        'inventory_receipt', 'inventory_receipt_date', 'inventory_allocation', 'inventory_issue', 'inventory_return'})


def reservation_start(reservation, data):
    # Recording a historical receipt today must not hide its explicitly linked
    # consumption before the reservation row's creation date.
    ids = {a.fizicka_transakcija_id for a in data.get('receipt_audits', [])
           if a.rezervacija_id == reservation.pk and a.fizicka_transakcija_id}
    return min([reservation.datum_rezervacije] + [t.datum for t in data['ledger'] if t.pk in ids])

def receipt_balance(receipts, ledger):
    """Include explicit receipt reversals written by migration provenance repair.

    They reference the original movement (not the cycle again). Never drop
    the original, double count the negative delta or allocate an unlinked entry.
    """
    total=ZERO; corrections=[]; valid=True
    for receipt in receipts:
        related=[t for t in ledger if t.referenca_tip=='ZalihaTransakcija'
                 and t.referenca_id==receipt.pk and t.tip=='KOREKCIJA']
        corrections.extend(related)
        valid=valid and all(t.lijek_id==receipt.lijek_id and (t.frizider_delta()<=0 or known_inventory_correction(t))
            and t.lokacija in {'','FRIZIDER'} for t in related)
        net=receipt.kolicina+sum((t.frizider_delta() for t in related),ZERO)
        valid=valid and ZERO<=net and (net<=receipt.kolicina or all(known_inventory_correction(t) for t in related))
        total+=net
    return total,corrections,valid


def receipt_proofs(data):
    """Reconcile the existing per-patient receipt snapshots with physical input.

    A cycle movement has no patient allocation itself. Only matching receipt
    snapshots for the ENTIRE cycle/SKU can prove that allocation. Reversed or
    ambiguous historical snapshots stay unknown; no proportional allocation.
    """
    quantity = lambda a: corrected_allocation(a, data['ledger'])
    groups=defaultdict(list)
    for r in data['requests']:
        groups[(r.komisijski_ciklus_id,r.lijek_id)].append(r)
    result={}
    claims=defaultdict(list)
    for a in data['receipt_audits']:
        if getattr(a,'fizicka_transakcija_id',None): claims[a.fizicka_transakcija_id].append(a)
    for (cycle,drug),items in groups.items():
        ids={r.pk for r in items}
        bulk=[t for t in data['ledger'] if cycle and t.referenca_tip=='KomisijskiCiklus'
              and t.referenca_id==cycle and t.lijek_id==drug and t.tip=='ZAPRIMANJE']
        direct=[t for t in data['ledger'] if t.referenca_tip=='Trebovanje'
                and t.referenca_id in ids and t.tip=='ZAPRIMANJE']
        audits=[a for a in data['receipt_audits'] if a.trebovanje_id in ids]
        requests={r.pk:r for r in items}
        audit_valid=all((a.pacijent_id,a.komisijski_ciklus_id)==
            (requests[a.trebovanje_id].pacijent_id,cycle) for a in audits)
        total,corrections,valid=receipt_balance(bulk+direct,data['ledger'])
        valid=valid and all(t.lijek_id==drug and t.lokacija in {'','FRIZIDER'}
            and t.frizider_delta()==t.kolicina and t.kolicina>=0 for t in bulk+direct)
        valid=valid and all(t.pacijent_id in {None,requests[t.referenca_id].pacijent_id}
            and t.komisija_id in {None,requests[t.referenca_id].komisija_id} for t in direct)
        # Aggregate equality alone cannot identify which historical receipt an
        # audit used. Accept legacy evidence only for ONE unreversed movement,
        # ONE snapshot per request, and the complete cycle/SKU conservation law.
        linked=[a for a in audits if getattr(a,'fizicka_transakcija_id',None)]
        reused=[]; bad_links=[]; explicit_valid=bool(linked) and len(linked)==len(audits)
        for tx in bulk+direct:
            entries=claims[tx.pk]
            net,_,net_valid=receipt_balance([tx],data['ledger'])
            if sum((quantity(a) for a in entries),ZERO)>net:
                reused.append(tx)
            identities=set()
            for a in entries:
                req=requests.get(a.trebovanje_id)
                reservation=next((v for v in data['reservations'] if v.pk==getattr(a,'rezervacija_id',None)),None)
                identity=(tx.pk,a.trebovanje_id)
                good=bool(req and (a.pacijent_id,a.komisijski_ciklus_id)==(req.pacijent_id,cycle)
                    and req.lijek_id==tx.lijek_id and identity not in identities
                    and (tx.referenca_tip!='Trebovanje' or tx.referenca_id==req.pk)
                    and getattr(tx,'komisijski_ciklus_id',None) in {None,cycle}
                    and (not getattr(a,'rezervacija_id',None) or reservation and
                         (reservation.pacijent_id,reservation.lijek_id,reservation.trebovanje_id)==
                         (req.pacijent_id,drug,req.pk)))
                if not good: bad_links.append(a)
                identities.add(identity)
            explicit_valid=explicit_valid and net_valid and bool(entries) and not bad_links and not reused and sum(
                (quantity(a) for a in entries),ZERO)+restricted_receipt_units([tx],data['ledger'])==net
        movement_ids={t.pk for t in bulk+direct}
        if any(a.fizicka_transakcija_id not in movement_ids for a in linked):
            bad_links.extend(a for a in linked if a.fizicka_transakcija_id not in movement_ids)
            explicit_valid=False
        legacy_unique=not linked and len(bulk+direct)==1 and not corrections and all(
            len([a for a in audits if a.trebovanje_id==r.pk])<=1 for r in items)
        all_claims=list({a.pk:a for a in [*audits,*[a for t in bulk+direct for a in claims[t.pk]]]}.values())
        bulk_proved=bool(bulk and audits and audit_valid and valid and (explicit_valid or legacy_unique) and
            sum((quantity(a) for a in audits),ZERO)+restricted_receipt_units(bulk+direct,data['ledger'])==total and
            all(sum((quantity(a) for a in audits if a.trebovanje_id==r.pk),ZERO)==r.zaprimljene_doze for r in items))
        for r in items:
            txs=[t for t in direct if t.referenca_id==r.pk]
            own=[a for a in audits if a.trebovanje_id==r.pk]
            amount,fixes,own_valid=receipt_balance(txs,data['ledger'])
            actual=(sum((quantity(a) for a in own),ZERO) if bulk_proved or explicit_valid
                    else amount if txs and not bulk and own_valid and valid else None)
            unique_own=(len(own)==1 and len(txs)==1 and not fixes and not linked) or explicit_valid
            result[r.pk]={'quantity':actual,'bulk_proved':bulk_proved,
                'cycle_received':total if (bulk or direct) and valid else None,
                'cycle_received_gross':sum((t.kolicina for t in bulk+direct),ZERO) if bulk or direct else None,
                'cycle_corrections':sum((t.frizider_delta() for t in corrections),ZERO) if bulk or direct else None,
                'has_reversal':bool(corrections),
                'has_receipt':bool(bulk or txs), 'has_bulk':bool(bulk),
                'ambiguous_history':bool(audits and not (explicit_valid or legacy_unique)),
                'reused':reused,'bad_links':bad_links,
                'sources':([*bulk,*direct,*corrections,*all_claims] if bulk else [*txs,*fixes,*all_claims]),
                'allocation_proved':actual is not None and bool(own) and audit_valid and not reused and not bad_links and
                    (bulk_proved or unique_own) and
                    sum((quantity(a) for a in own),ZERO)==actual==r.zaprimljene_doze}
    return result


def reservation_effects(reservation, data):
    """Explicit therapy snapshots only; never assign a patient's total use FIFO."""
    used=ZERO; refs=[]; complete=True
    starts = reservation_start(reservation, data)
    for t in data['therapies']:
        if (t.pacijent_id,t.lijek_id)!=(reservation.pacijent_id,reservation.lijek_id): continue
        if t.is_migration or t.datum<starts: continue
        state=t.workflow_snapshot or {}
        if not isinstance(state,dict): complete=False; continue
        if t.workflow_status=='PONISTENA' or t.ponistena_at or state.get('vrsta')=='KUCNA_PRIMJENA': continue
        if t.workflow_status!='POTVRDJENA': complete=False; continue
        if 'rezervacijske_promjene' not in state and 'fazne_rezervacijske_promjene' not in state:
            complete=False; continue
        try:
            for effect in state.get('rezervacijske_promjene',[])+state.get('fazne_rezervacijske_promjene',[]):
                if effect.get('rezervacija_id')==reservation.pk:
                    q=Decimal(str(effect['kolicina']))
                    if not q.is_finite() or q<0: complete=False; continue
                    used+=q; refs.append(t)
        except (ValueError,TypeError,KeyError,InvalidOperation): complete=False
    for oral in data['oral']:
        if (oral.pacijent_id, oral.lijek_id) != (reservation.pacijent_id, reservation.lijek_id) or oral.status == 'PONISTENO':
            continue
        effects = list(oral.razduzenja_rezervacija.all())
        if not effects:
            complete = False
        for effect in effects:
            if effect.rezervacija_id == reservation.pk:
                used += effect.kolicina
                refs.append(oral)
    for tx in data['ledger']:
        if tx.rezervacija_id == reservation.pk and tx.korekcija_id and tx.korekcija.scope == 'inventory_issue':
            used -= tx.promjena_rezervacije
            refs.append(tx)
    return used,refs,complete


def receipt_reservation_expectation(reservation,data):
    # Exact receipt/allocation FKs prove each shipment independently, even
    # when this row has no transfer and its request has several reservations.
    # Keep the unique legacy fallback for records without those explicit links.
    explicit_receipt = any(a.rezervacija_id == reservation.pk and a.fizicka_transakcija_id
        for a in data['receipt_audits'])
    if explicit_receipt or any(reservation.pk in {t.izvorna_rezervacija_id,t.odredisna_rezervacija_id} for t in data['transfers']):
        from .allocation_trace import transfer_reservation_expectation
        return transfer_reservation_expectation(reservation,data)
    proof=data['receipt_proofs'].get(reservation.trebovanje_id,{})
    sources=proof.get('sources',[])
    peers=[r for r in data['reservations'] if r.trebovanje_id==reservation.trebovanje_id]
    used,events,complete=reservation_effects(reservation,data)
    unsafe=any(c.pacijent_id==reservation.pacijent_id and c.scope=='stock' for c in data['corrections'])
    unsafe=unsafe or any(t.pacijent_id==reservation.pacijent_id and t.lijek_id==reservation.lijek_id
        and t.datum>=reservation.datum_rezervacije and t.tip in {'RELEASE_TO_FREE_STOCK','ASSIGN_FREE_STOCK_TO_PATIENT','KOREKCIJA'} and not known_inventory_correction(t) for t in data['ledger'])
    unsafe=unsafe or any(n.trebovanje_id==reservation.trebovanje_id and n.preostala_kolicina>0 for n in data['needs'])
    unsafe=unsafe or data['drugs'][reservation.lijek_id].jedinice_zalihe[0] not in {'pen','bočica','tableta','šprica','ampula'}
    if not proof.get('allocation_proved') or len(peers)!=1 or not complete or unsafe:
        return None,'ALLOCATION_HISTORY',[*sources,*events]
    if not reservation.aktivno and reservation.kolicina>0:
        return None,'ALLOCATION_HISTORY',[*sources,*events]
    return proof['quantity']-used,None,[*sources,*events]


def check_commission_links(run):
    data=run.inventory_records
    if data is None: raise ValueError('Inventory census required')
    area='commission_links'
    requests=data['requests']; commissions={c.pk:c for c in data['commissions']}
    groups=defaultdict(list); by_approval=defaultdict(list)
    for r in requests:
        groups[(r.komisijski_ciklus_id,r.lijek_id)].append(r)
        if r.komisija_id: by_approval[r.komisija_id].append(r)
    refs={}
    def proof(obj, values=None):
        key=(type(obj).__name__,obj.pk)
        if key not in refs or values is not None:
            if values is None and isinstance(obj,m.EvidencijaSaglasnostiZaprimanja):
                values={'received_quantity':obj.zaprimljena_kolicina,'event_date':obj.kreirano.date()}
            medicine_id=getattr(obj,'lijek_id',None)
            if isinstance(obj,m.EvidencijaSaglasnostiZaprimanja):
                medicine_id=next((r.lijek_id for r in requests if r.pk==obj.trebovanje_id),None)
            refs[key]=run.evidence_for(key[0],obj.pk,patient_id=getattr(obj,'pacijent_id',None),
                medicine_id=medicine_id,values=values or {})
        return refs[key]
    included=set(visible_commission_requests(m.Trebovanje.objects.all()).values_list('pk',flat=True))
    cycles={c.pk:c for c in run.scan_all(m.KomisijskiCiklus.objects.all(),'Ciklusi komisije',area=area)}
    scope=run.new_scope(area,'Trebovanje',len(requests),label='Zahtjev → odobrenje → stvarni ulaz')
    scope['loaded']=len(requests)
    for r in requests:
        run.checkpoint()
        ref=proof(r,{'total_quantity':r.odobrene_doze,'received_quantity':r.zaprimljene_doze,
                     'manual_exclusion':r.pk not in included,'included':r.pk in included})
        why=[]; limits=[]; related=[]
        c=commissions.get(r.komisija_id)
        if r.komisija_id:
            if not c or (c.pacijent_id,c.lijek_id)!=(r.pacijent_id,r.lijek_id): why.append('COMMISSION_LINK')
            elif r.odobrene_doze is not None and r.odobrene_doze!=c.broj_odobrenih_doza: why.append('COMMISSION_QUANTITY')
            if len(by_approval[r.komisija_id])>1: why.append('COMMISSION_DUPLICATE')
            if c: related.append(proof(c))
        if r.komisijski_ciklus_id and r.komisijski_ciklus_id not in cycles: why.append('COMMISSION_LINK')
        own_audits=[a for a in data['receipt_audits'] if a.trebovanje_id==r.pk]
        if any((a.pacijent_id,a.komisijski_ciklus_id)!=(r.pacijent_id,r.komisijski_ciklus_id) for a in own_audits):
            why.append('COMMISSION_LINK')
        if r.odobrene_doze is not None and r.zaprimljene_doze>r.odobrene_doze: why.append('COMMISSION_QUANTITY')
        # Same rule as the conditional unique constraint; two open different
        # cycles are legitimate and must not be flagged as duplicates.
        if r.komisijski_ciklus_id and r.status in {'U_PRIPREMI','NACRT','SPREMAN'} and sum(
            x.pacijent_id==r.pacijent_id and x.status in {'U_PRIPREMI','NACRT','SPREMAN'}
            for x in groups[(r.komisijski_ciklus_id,r.lijek_id)])>1:
            why.append('COMMISSION_DUPLICATE')
        txs=[t for t in data['ledger'] if t.referenca_tip=='Trebovanje' and t.referenca_id==r.pk and t.tip=='ZAPRIMANJE']
        bulk=[t for t in data['ledger'] if r.komisijski_ciklus_id and t.referenca_tip=='KomisijskiCiklus'
              and t.referenca_id==r.komisijski_ciklus_id and t.lijek_id==r.lijek_id and t.tip=='ZAPRIMANJE']
        if any(t.lijek_id!=r.lijek_id or t.pacijent_id not in {None,r.pacijent_id}
               or t.komisija_id not in {None,r.komisija_id} for t in txs): why.append('COMMISSION_LINK')
        actual,corrections,valid=receipt_balance(txs,data['ledger'])
        if not valid: why.append('COMMISSION_QUANTITY')
        expected=r.zaprimljene_doze if txs and not bulk else None
        if expected is not None and actual!=expected: why.append('COMMISSION_QUANTITY')
        if r.zaprimljene_doze and not txs and not bulk: limits.append('COMMISSION_HISTORY')
        receipt=data['receipt_proofs'][r.pk]
        if receipt['reused']: why.append('RECEIPT_REUSED')
        if receipt['bad_links']: why.append('COMMISSION_LINK')
        if bulk and receipt['bulk_proved']:
            actual=receipt['quantity']; expected=r.zaprimljene_doze
        elif bulk: limits.append('COMMISSION_CYCLE_ALLOCATION')
        if receipt['ambiguous_history'] and not receipt['allocation_proved']:
            limits.append('RECEIPT_HISTORY_AMBIGUOUS')
        amount=proof(r,{'expected_quantity':expected,'quantity':actual if txs else None,
            'difference':actual-expected if expected is not None else None,'received_quantity':r.zaprimljene_doze,
            'total_quantity':r.odobrene_doze,'included':r.pk in included,'manual_exclusion':r.pk not in included})
        # Quantities stay per patient/SKU/cycle, with actual net receipt distinct
        # from the request's mutable received counter.
        reservations=[x for x in data['reservations'] if x.trebovanje_id==r.pk]
        allocated=sum((x.kolicina for x in reservations if x.aktivno),ZERO)
        requested=r.broj_doza if r.pk in included and r.status!='OTKAZANO' else None
        values=run.evidence_index[amount]['values']
        values.update(requested_quantity=str(requested) if requested is not None else None,
            approved_quantity=str(r.odobrene_doze) if r.odobrene_doze is not None else None,
            physical_received=str(receipt['quantity']) if receipt['quantity'] is not None else None,
            allocated_quantity=str(allocated), cycle_id=r.komisijski_ciklus_id,
            quantity=str(receipt['quantity']) if receipt['quantity'] is not None else None)
        related += [proof(t,{'quantity':t.kolicina,'fridge_delta':t.frizider_delta(),'event_date':t.datum}) for t in txs+bulk+corrections]
        related += [proof(a) for a in receipt['sources'] if isinstance(a,m.EvidencijaSaglasnostiZaprimanja)]
        if r.komisijski_ciklus_id in cycles: related.append(proof(cycles[r.komisijski_ciklus_id],{'event_date':cycles[r.komisijski_ciklus_id].datum_komisije}))
        related += [proof(x,{'quantity':x.kolicina,'active':x.aktivno}) for x in reservations]
        run.add('COMMISSION_LINKS',area,'ISSUE' if why else 'UNKNOWN' if limits else 'OK',[amount,*related],
                reasons=why or limits or (['COMMISSION_EXCLUDED'] if r.pk not in included else ['RECEIPT_ALLOCATION_PROVED'] if receipt['bulk_proved'] else []))
        if limits:
            if why: run.add('COMMISSION_LINKS',area,'UNKNOWN',[amount,*related],reasons=limits)
            run.skip_record(scope,limits[0])
        else: scope['checked']+=1
        _check_allocation_and_progress(run,r,reservations,receipt,[amount,*related],proof,r.pk in included,cycles.get(r.komisijski_ciklus_id))
    # A bulk receipt can be proved at cycle/SKU level, without allocating its
    # amount arbitrarily to one of the patients in that cycle.
    for (cycle,drug),items in groups.items():
        run.checkpoint()
        active_by_patient=defaultdict(list)
        for r in items:
            if cycle and r.pk in included and r.status not in {'OTKAZANO','ODBIJENO'}:
                active_by_patient[r.pacijent_id].append(r)
        for repeated in active_by_patient.values():
            if len(repeated)>1:
                run.add('COMMISSION_LINKS',area,'REVIEW',[proof(r) for r in repeated],reasons=['COMMISSION_DUPLICATE'])
        bulk=[t for t in data['ledger'] if cycle and t.referenca_tip=='KomisijskiCiklus'
              and t.referenca_id==cycle and t.lijek_id==drug and t.tip=='ZAPRIMANJE']
        if not bulk: continue
        direct=[t for t in data['ledger'] if t.referenca_tip=='Trebovanje' and
                t.referenca_id in {r.pk for r in items} and t.lijek_id==drug and t.tip=='ZAPRIMANJE']
        expected=sum((r.zaprimljene_doze for r in items),ZERO)
        actual,corrections,valid=receipt_balance(bulk+direct,data['ledger'])
        ref=run.evidence_for('KomisijskiCiklus',cycle,medicine_id=drug,values={
            'expected_quantity':expected,'quantity':actual,'difference':actual-expected})
        run.add('COMMISSION_LINKS',area,'OK' if expected==actual and valid else 'ISSUE',
                [ref,*[proof(r) for r in items],*[proof(t,{'quantity':t.kolicina,'fridge_delta':t.frizider_delta(),'event_date':t.datum}) for t in bulk+direct+corrections]],
                reasons=[] if expected==actual and valid else ['COMMISSION_QUANTITY'])
    # All explicit consumption links are checked in both directions. Cancelled
    # actions restore their original effects; replacement actions stand alone.
    effects=defaultdict(list); uncertain=set()
    for t in data['therapies']:
        changes=(t.workflow_snapshot or {}).get('komisijske_promjene',[])
        for change in changes:
            cid=change.get('komisija_id'); c=commissions.get(cid)
            if not c or (c.pacijent_id,c.lijek_id)!=(t.pacijent_id,t.lijek_id):
                run.add('COMMISSION_LINKS',area,'ISSUE',[proof(t)],reasons=['COMMISSION_LINK'])
                uncertain.add(cid); continue
            effects[cid].append((ZERO if t.workflow_status=='PONISTENA' or t.ponistena_at else Decimal(str(change['kolicina'])),t))
    for i in data['oral']:
        if not i.komisija_id: continue
        c=commissions.get(i.komisija_id)
        if not c or (c.pacijent_id,c.lijek_id)!=(i.pacijent_id,i.lijek_id):
            run.add('COMMISSION_LINKS',area,'ISSUE',[proof(i)],reasons=['COMMISSION_LINK']); continue
        if not i.is_migration_snapshot:
            effects[c.pk].append((ZERO if i.status=='PONISTENO' else Decimal(i.kolicina_tableta),i))
    cscope=run.new_scope(area,'Komisija',len(commissions),label='Odobrenje: početak i izričito povezani učinci')
    cscope['loaded']=len(commissions)
    for c in commissions.values():
        run.checkpoint()
        # Migration rights are canonical snapshot rights, not reconstructed
        # from an assumed empty clinical history. Corrections need their own basis.
        opening=bool(by_approval[c.pk]) and not (c.napomena or '').startswith('Migracijski')
        unlinked=[t for t in data['therapies'] if t.pacijent_id==c.pacijent_id and t.lijek_id==c.lijek_id and not
            (t.workflow_snapshot or {}).get('komisijske_promjene') and (t.workflow_snapshot or {}).get('vrsta')!='KUCNA_PRIMJENA'
            ]
        corrections=[x for x in data['corrections'] if x.pacijent_id==c.pacijent_id]
        complete=opening and c.pk not in uncertain and not unlinked and not corrections
        expected=c.broj_odobrenih_doza-sum((q for q,obj in effects[c.pk]),ZERO) if complete else None
        ref=proof(c,{'expected_quantity':expected,'remaining_quantity':c.preostale_doze,
            'total_quantity':c.broj_odobrenih_doza,'difference':c.preostale_doze-expected if expected is not None else None})
        status='UNKNOWN' if expected is None else 'OK' if expected==c.preostale_doze else 'ISSUE'
        reasons=(['COMMISSION_HISTORY']+(['COMMISSION_OPENING_UNKNOWN'] if not opening else [])+
                 (['COMMISSION_EFFECTS_UNKNOWN'] if unlinked or corrections or c.pk in uncertain else [])) if status=='UNKNOWN' else ['COMMISSION_QUANTITY'] if status=='ISSUE' else []
        run.add('COMMISSION_REMAINING',area,status,[ref,*[proof(o) for q,o in effects[c.pk]],
            *[proof(o) for o in unlinked+corrections]],reasons=reasons)
        if status=='UNKNOWN': run.skip_record(cscope,'COMMISSION_HISTORY')
        else: cscope['checked']+=1
    _modern_links(run, data, proof)
    _canonical_waiting(run, data)
    _group_receipts(run, cycles, data)


def _group_receipts(run, cycles, data):
    """One cycle review containing requests; never one shipment per finding."""
    from django.urls import reverse
    for cid in sorted({f['cycle_id'] for f in run.findings if f.get('cycle_id')}):
        cycle=cycles[cid]
        findings=[f for f in run.findings if f.get('cycle_id')==cid]
        presentations=[]
        for did in sorted({d for f in findings for d in f['medicine_ids']}):
            requests=[r for r in data['requests'] if r.komisijski_ciklus_id==cid and r.lijek_id==did]
            receipt=data['receipt_proofs'][requests[0].pk]
            drug=data['drugs'][did]
            movements=[t for t in receipt['sources'] if isinstance(t,m.ZalihaTransakcija)]
            ref=run.evidence_for('KomisijskiCiklus',cid,medicine_id=did,values={
                'cycle_received_gross':receipt['cycle_received_gross'],
                'cycle_corrections':receipt['cycle_corrections'],
                'cycle_received':receipt['cycle_received'],'unit':drug.jedinice_zalihe[0],
                'receipt_state':'UNLINKED_BULK' if receipt['has_bulk'] and not receipt['bulk_proved']
                    else 'LINKED_RECEIPT' if receipt['has_receipt'] else 'NO_RECEIPT_RECORD'})
            source_refs=[run.evidence_for('ZalihaTransakcija',t.pk,medicine_id=did,
                values={'quantity':t.kolicina,'fridge_delta':t.frizider_delta(),'event_date':t.datum}) for t in movements]
            for f in findings:
                if did in f['medicine_ids']: f['evidence_ids']+= [ref,*source_refs]
            presentations.append({'medicine_id':did,'label':f'{drug.naziv} · {drug.strength}',
                'values':run.evidence_index[ref]['values'],'evidence_ids':[ref,*source_refs]})
        run.receipt_groups.append({'cycle_id':cid,'label':str(cycle),
            'url':reverse('zaprimanje_ciklusa',args=[cid]),
            'finding_ids':[f['id'] for f in findings],'presentations':presentations})


def _check_allocation_and_progress(run,r,reservations,receipt,refs,proof,included,cycle):
    data=run.inventory_records
    active=[x for x in reservations if x.aktivno and x.kolicina>0]
    if len(active)>1:
        run.add('ALLOCATION_DUPLICATE','stock','REVIEW',refs,reasons=['ALLOCATION_DUPLICATE'])
    allocated=sum((x.kolicina for x in active),ZERO)
    used=ZERO; events=[]
    for x in reservations:
        q,source,_=reservation_effects(x,data); used+=q; events+=source
    actual=receipt['quantity']
    # Known positive effects suffice to prove over-allocation, even if other
    # effects are missing, unless a transfer/correction may supply extra stock.
    extra=any(x.pk in {t.izvorna_rezervacija_id,t.odredisna_rezervacija_id} for x in reservations for t in data['transfers'])
    extra=extra or any(c.pacijent_id==r.pacijent_id and c.scope=='stock' for c in data['corrections'])
    extra=extra or any(t.pacijent_id==r.pacijent_id and t.lijek_id==r.lijek_id
        and t.tip in {'ASSIGN_FREE_STOCK_TO_PATIENT','RELEASE_TO_FREE_STOCK','KOREKCIJA'} and not known_inventory_correction(t) for t in data['ledger'])
    if reservations:
        values={'allocated_quantity':allocated,'linked_consumption':used,'physical_received':actual,
                'difference':allocated+used-actual if actual is not None and not extra else None}
        ref=run.evidence_for('Trebovanje',r.pk,patient_id=r.pacijent_id,medicine_id=r.lijek_id,values=values)
        status='UNKNOWN' if actual is None or extra else 'ISSUE' if allocated+used>actual else 'OK'
        run.add('ALLOCATION_RECEIPT','stock',status,[ref,*refs,*[proof(e) for e in events]],
            reasons=['ALLOCATION_OVER_RECEIPT'] if status=='ISSUE' else ['ALLOCATION_HISTORY'] if status=='UNKNOWN' else [])
    if not included or r.status in {'OTKAZANO','ODBIJENO'} or r.odobrene_doze is None: return
    remaining=r.odobrene_doze-actual if actual is not None else None
    if remaining is not None and remaining<=0: return
    since=r.komisija.datum_odobrenja if r.komisija_id else getattr(cycle,'datum_odobrenja',None)
    days=(run.today-since).days if since else None
    due=r.ocekivana_najranija_isporuka
    stale=bool((days is not None and days>=30) or (due and due<run.today))
    partial=actual is not None and ZERO<actual<r.odobrene_doze
    if not stale and not partial: return
    ref=run.evidence_for('Trebovanje',r.pk,patient_id=r.pacijent_id,medicine_id=r.lijek_id,values={
        'approved_quantity':r.odobrene_doze,'physical_received':actual,'approved_waiting_delivery':remaining,
        'age_days':days,'stale_threshold_days':30,'delivery_date':due,'delivery_estimated':True})
    uncertain=actual is None
    state=('UNLINKED_BULK' if receipt['has_bulk'] else 'UNRESOLVED_HISTORY' if receipt['has_receipt'] else 'NO_RECEIPT_RECORD') if uncertain else 'LINKED_RECEIPT'
    run.evidence_index[ref]['values'].update(receipt_state=state,
        cycle_received=str(receipt['cycle_received']) if receipt['cycle_received'] is not None else None,
        cycle_id=r.komisijski_ciklus_id, nonreceipt_confirmed=False)
    reasons=(['RECEIPT_STALE'] if stale else [])+(['RECEIPT_PARTIAL'] if partial else [])
    if receipt['has_reversal']: reasons.append('RECEIPT_REVERSAL_CONTEXT')
    if uncertain: reasons.append('RECEIPT_LINK_UNRESOLVED' if receipt['has_receipt'] else 'RECEIPT_NO_RECORD')
    run.add('RECEIPT_PROGRESS','commission_links','UNKNOWN' if uncertain else 'REVIEW' if stale else 'OK',[ref,*refs],
        reasons=reasons, limitation='Prag je signal za provjeru otpremnice. Nema tvrdnje da lijek nije stigao; zajednički prijem nije raspodijeljen pretpostavkom.')
    if cycle:
        run.findings[-1]['cycle_id']=cycle.pk


def _modern_links(run, data, proof):
    """Modern item/legacy receipt bridge: only a unique same-cycle identity."""
    area='commission_links'
    items=m.KomisijskaStavkaLijeka.objects.select_related('komisijski_zahtjev','lijek')
    included=set(visible_commission_requests(m.KomisijskiZahtjev.objects.all()).values_list('pk',flat=True))
    decisions={s.komisijski_zahtjev_id for s in run.scan_all(m.KomisijskaSaglasnost.objects.all(),
        'Postojeće odluke novih zahtjeva',area=area)}
    for item in run.scan_all(items,'Stavke novih zahtjeva i operativna evidencija',area=area,operation='reconcile'):
        request=item.komisijski_zahtjev
        ref=run.evidence_for('KomisijskaStavkaLijeka',item.pk,patient_id=request.pacijent_id,medicine_id=item.lijek_id,
            values={'total_quantity':item.odobrena_kolicina,'quantity':item.kolicina,'unit':item.jedinica,
                    'requested_quantity':item.kolicina if request.pk in included else None,
                    'approved_quantity':item.odobrena_kolicina,'physical_received':None,
                    'request_status':request.status,'included':request.pk in included,'manual_exclusion':request.pk not in included})
        if request.pk not in included:
            run.add('COMMISSION_LINKS',area,'OK',[ref,proof(request)],reasons=['COMMISSION_EXCLUDED'])
            continue
        matches=[r for r in data['requests'] if r.status!='OTKAZANO' and (r.pacijent_id,r.lijek_id,r.komisijski_ciklus_id)==
                 (request.pacijent_id,item.lijek_id,request.komisijski_ciklus_id)]
        # A draft/confirmed request is not an approval. Its unknown future
        # amounts remain null, while the stage itself can be verified.
        if item.odobrena_kolicina is None and request.status!='odluceno' and request.pk not in decisions and not any(r.odobrene_doze is not None for r in matches):
            run.add('COMMISSION_LINKS',area,'OK',[ref,proof(request)],reasons=['COMMISSION_NOT_DECIDED'])
            continue
        if len(matches)>1:
            run.add('COMMISSION_LINKS',area,'REVIEW',[ref],reasons=['COMMISSION_DUPLICATE'])
        elif matches and item.odobrena_kolicina is not None:
            r=matches[0]
            unit=item.lijek.jedinice_zalihe[0]
            factor=Decimal(1) if item.jedinica in {unit,'flakon' if unit=='bočica' else ''} else None
            if item.jedinica=='pakovanje':
                # Explicit registry data only; never brand/default package heuristics.
                size=item.lijek.broj_tableta_u_pakovanju if unit=='tableta' else item.lijek.package_size_in_doses
                if size and (unit=='tableta' or size>1) and unit in {'tableta','pen','bočica','šprica','ampula'}:
                    factor=Decimal(size)
            if factor is None:
                run.add('COMMISSION_LINKS',area,'UNKNOWN',[ref],reasons=['SOURCE_UNIT'])
                run.skip_record(run.scope[-1],'SOURCE_UNIT')
            elif r.odobrene_doze is not None:
                converted=item.odobrena_kolicina*factor
                conversion=run.evidence_for('Lijek',item.lijek_id,values={
                    'conversion_factor':factor,'converted_quantity':converted,'unit':unit})
                run.add('COMMISSION_LINKS',area,'OK' if converted==r.odobrene_doze else 'ISSUE',
                    [ref,conversion,proof(r)],reasons=[] if converted==r.odobrene_doze else ['COMMISSION_QUANTITY'])
            else:
                run.add('COMMISSION_LINKS',area,'UNKNOWN',[ref,proof(r)],reasons=['COMMISSION_HISTORY'])
                run.skip_record(run.scope[-1],'COMMISSION_HISTORY')
        elif matches:
            run.add('COMMISSION_LINKS',area,'UNKNOWN',[ref,proof(matches[0]),proof(request)],reasons=['COMMISSION_APPROVAL_MISSING'])
            run.skip_record(run.scope[-1],'COMMISSION_APPROVAL_MISSING')
        else:
            run.add('COMMISSION_LINKS',area,'UNKNOWN',[ref,proof(request)],reasons=['COMMISSION_BRIDGE_MISSING'])
            run.skip_record(run.scope[-1],'COMMISSION_BRIDGE_MISSING')


def _canonical_waiting(run,data):
    pairs={(x.pacijent_id,x.lijek_id) for x in data['commissions']+data['requests']}
    values=defaultdict(lambda:ZERO); unknown=set()
    scope=run.new_scope('commission_links','Pacijent',len(pairs),label='Kanonsko odobreno nezaprimljeno po prezentaciji')
    scope['loaded']=len(pairs)
    settings=m.PostavkeSistema.objects.filter(pk=1).first()
    if settings: set_cached('commission_settings',1,settings)
    for pid,did in sorted(pairs):
        run.checkpoint()
        drug=data['drugs'][did]
        if not settings:
            unknown.add(did); reason='SETTINGS_MISSING'
            ref=run.evidence_for('Lijek',did)
            run.add('COMMISSION_LINKS','commission_links','UNKNOWN',[ref],reasons=[reason])
            run.skip_record(scope,reason); continue
        patient=copy(data['patients'][pid]); patient._state=copy(patient._state)
        patient._state.fields_cache=patient._state.fields_cache.copy()
        patient.lijek=drug  # In-memory historical presentation only; never saved.
        coverage=patient_commission_coverage(patient, medicine_ids=(did,))
        values[did]+=coverage['approved_waiting_delivery']
        ref=run.evidence_for('Pacijent',pid,patient_id=pid,medicine_id=did,
            values={k:coverage[k] for k in ('approved_waiting_delivery','unused_approved','at_patient','reserved_in_fridge')})
        run.add('COMMISSION_LINKS','commission_links','OK',[ref])
        scope['checked']+=1
    for row in run.inventory['stocks']:
        value=None if row['drug_id'] in unknown else values[row['drug_id']]
        row['approved_waiting_delivery']=str(value) if value is not None else None
        for e in run.evidence:
            if e['kind']=='Lijek' and e['record_id']==row['drug_id'] and 'approved_waiting_delivery' in e['values']:
                e['values']['approved_waiting_delivery']=row['approved_waiting_delivery']
