"""Presentation of saved findings. No queries, inventory calculation or mutation."""
from decimal import Decimal, InvalidOperation

from .catalog import STATUS_LABELS


def amount(value):
    if value is None or value == '':
        return 'Nema podataka'
    try:
        number = Decimal(str(value))
        if not number.is_finite():
            return 'Nema podataka'
        if not number:
            return '0'
        text = format(number, 'f')
        return (text.rstrip('0').rstrip('.') if '.' in text else text).replace('.', ',')
    except (InvalidOperation, ValueError):
        return 'Nema podataka'


def inventory_display(run):
    """Group existing outcomes per SKU; unknown or unfinished checks never go green."""
    from .display import LABELS
    inventory = run.get('inventory') or {}
    findings = {f['id']: f for f in run['findings']}
    evidence = {e['id']: e for e in run['evidence']}
    summary = {'issue': 0, 'review': 0, 'unknown': 0, 'aligned': 0}
    rows = []
    incomplete = not inventory.get('complete') or any(
        f['area'] != 'technical' and f['code'] in {'CHECK_LIMIT', 'CHECK_FAILED'} for f in run['findings'])
    for stock in inventory.get('stocks', []):
        distribution = findings.get(stock['finding_id'], {})
        distribution_records = {(evidence[ref]['kind'], evidence[ref]['record_id'])
                                for ref in distribution.get('evidence_ids', []) if ref in evidence}
        finding_ids = {stock['finding_id'], *(r['finding_id'] for r in stock['details'])}
        for f in run['findings']:
            if stock['drug_id'] in f.get('medicine_ids', []):
                finding_ids.add(f['id'])
                continue
            if f['area'] != 'stock' or not f['code'].startswith('STOCK_'):
                continue
            if any(evidence.get(ref, {}).get('kind') == 'Zaliha'
                   and evidence[ref]['record_id'] == stock.get('stock_id')
                   and stock.get('stock_id') is not None for ref in f['evidence_ids']):
                finding_ids.add(f['id'])
            if any((evidence[ref]['kind'], evidence[ref]['record_id']) in distribution_records
                   for ref in f['evidence_ids'] if ref in evidence):
                finding_ids.add(f['id'])
        checks = [f for f in run['findings'] if f['id'] in finding_ids]
        statuses = {f['status'] for f in checks}
        balance = next((f for f in checks if f['code'] in {'STOCK_BALANCE', 'STOCK_HISTORY'}), None)
        has_issue = 'ISSUE' in statuses
        has_review = 'REVIEW' in statuses
        unknown = bool(incomplete or statuses & {'UNKNOWN', 'ERROR'} or balance is None)
        if has_issue:
            category, label = 'issue', 'Neslaganje'
        elif has_review:
            category, label = 'review', 'Za provjeru'
        elif unknown:
            category, label = 'unknown', 'Nedovoljno podataka'
        else:
            category, label = 'aligned', 'Usklađeno'
        summary['issue'] += int(has_issue)
        summary['review'] += int(has_review)
        summary['unknown'] += int(unknown)
        summary['aligned'] += int(not has_issue and not has_review and not unknown)
        values = next((evidence[ref]['values'] for ref in (balance or {}).get('evidence_ids', [])
                       if evidence.get(ref, {}).get('kind') == 'Zaliha' and 'expected_fridge' in evidence[ref]['values']), {})
        movements = [evidence[ref] for ref in dict.fromkeys(distribution.get('evidence_ids', []))
                     if evidence.get(ref, {}).get('kind') == 'ZalihaTransakcija']
        rows.append({**stock, 'category': category, 'status_label': label, 'incomplete':unknown, 'has_issue':has_issue, 'has_review':has_review,
            'quantity_trail':[{**step,'label':LABELS[step['key']],'quantity_display':amount(step['quantity']),
                'known_display':amount(step.get('known_subtotal'))} for step in stock.get('quantity_trail',[])],
            'finding_counts':{s:sum(f['status']==s for f in checks) for s in ('ISSUE','REVIEW','UNKNOWN','ERROR')},
            'quantities': {key: amount(stock.get(key)) for key in (
                'recorded_fridge', 'reserved', 'free_fridge', 'future_reserved', 'awaiting_coverage',
                'received_ledger_subtotal', 'issued_ledger_subtotal',
                'approved_waiting_delivery', 'at_patient', 'home_recorded_subtotal', 'reported_remaining',
                'reported_subtotal', 'physical_shortfall', 'difference')},
            'expected_fridge_display': amount(values.get('expected_fridge')),
            'ledger_difference_display': amount(values.get('difference')),
            'checks': checks,
            'details': [{**r, 'status_label': STATUS_LABELS.get(r['status'], 'Nema podataka'),
                         'expected_display':amount(r['expected']), 'recorded_display':amount(r['recorded']),
                         'difference_display':amount(r['difference'])} for r in stock['details']],
            'movements': [{'id':e['record_id'], **e['values'],
                           'quantity_display':amount(e['values'].get('quantity')),
                           'delta_display':amount(e['values'].get('fridge_delta')),
                           'url':e['url']} for e in movements]})
    return {'summary':summary, 'stocks':rows}
