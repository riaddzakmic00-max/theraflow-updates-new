"""Atomically record one real document and its explicitly reviewed decisions.

Printed numbers are labels. The durable document and item PKs establish actual
membership; existing decisions require their separate correction workflow.
"""
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from uuid import UUID, uuid4

from django.core import signing
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction

from patients import models as m
from patients.commission_exclusions import ensure_commission_inclusion
from patients.data_corrections import digest
from patients.transaction_locking import select_for_update_self
from patients.utils import upisi_log
from .commission_center_decisions import decision_revision, record_waiting_decision
from .commission_center_receiving import save_agreement_for_receiving
from .permissions import je_komisijski_tim

SALT = 'commission-shared-document-v1'
CEKA = m.KomisijskaDokumentStavka.Odluka.CEKA


def shared_document_revision(cycle):
    legacy = m.Trebovanje.objects.filter(komisijski_ciklus=cycle)
    return digest({
        'modern': decision_revision(cycle),
        'legacy': list(legacy.order_by('pk').values()),
        'commissions': list(m.Komisija.objects.filter(trebovanja__in=legacy)
                            .distinct().order_by('pk').values()),
        'memberships': list(m.KomisijskaDokumentStavka.objects.filter(
            dokument__komisijski_ciklus=cycle).order_by('pk').values()),
        'exclusions': list(m.KomisijskoIskljucenje.objects.filter(
            datum_komisije=cycle.datum_komisije,
            pacijent__komisijski_zahtjevi_faza1__komisijski_ciklus=cycle)
            .distinct().order_by('pk').values()),
    })


def shared_document_token(cycle, user):
    return signing.dumps({'cycle': cycle.pk, 'user': user.pk,
        'revision': shared_document_revision(cycle), 'operation': str(uuid4())}, salt=SALT)


def _identifier(value):
    text = str(value)
    if (isinstance(value, bool) or not text.isascii() or not text.isdecimal()
            or int(value) <= 0 or int(value) > 2147483647):
        raise ValidationError('Identitet zahtjeva ili stavke nije ispravan.')
    return int(value)


def _quantity(raw):
    try:
        result = Decimal(str(raw))
    except (InvalidOperation, ValueError, TypeError):
        raise ValidationError('Unesite stvarnu odobrenu količinu za svaku stavku.') from None
    if not result.is_finite() or result < 0 or result.as_tuple().exponent < -2:
        raise ValidationError('Odobrene količine moraju biti konačne, nenegativne, sa najviše dvije decimale.')
    return result


def _posted_rows(rows):
    if not isinstance(rows, (list, tuple)) or not rows:
        raise ValidationError('Označite najmanje jedan provjeren zahtjev.')
    normalized, ids = [], set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValidationError('Stavke zajedničkog dokumenta nisu ispravne.')
        request_id = _identifier(row.get('request_id'))
        if request_id in ids:
            raise ValidationError('Isti zahtjev ne može biti dva puta u dokumentu.')
        ids.add(request_id)
        decision = row.get('decision')
        if decision not in m.KomisijskaDokumentStavka.Odluka.values:
            raise ValidationError('Izaberite stvarnu odluku za svaki označeni zahtjev.')
        posted = row.get('approved_quantities', {})
        if not isinstance(posted, dict):
            raise ValidationError('Odobrene količine nisu ispravne.')
        quantities = {}
        for key, raw in posted.items():
            item_id = _identifier(key)
            if item_id in quantities:
                raise ValidationError('Ponovljen identitet stavke lijeka.')
            quantities[item_id] = None if raw is None or str(raw).strip() == '' else _quantity(raw)
        normalized.append({'request_id': request_id, 'decision': decision,
            'approved_quantities': quantities, 'note': str(row.get('note') or '').strip()})
    return sorted(normalized, key=lambda row: row['request_id'])


def _fresh_request(request, items, legacy):
    ensure_commission_inclusion(request.pacijent, request.komisijski_ciklus)
    if request.status in (m.KomisijskiZahtjev.Status.NACRT, m.KomisijskiZahtjev.Status.ODLUCENO):
        raise ValidationError('Dokument prima samo potvrđene zahtjeve koji čekaju stvarnu odluku.')
    if not items or len({item.lijek_id for item in items}) != len(items):
        raise ValidationError('Nedostaje lijek ili je isti proizvod ponovljen u zahtjevu. Potrebna je provjera.')
    if (m.KomisijskaSaglasnost.objects.filter(komisijski_zahtjev=request).exists()
            or any(item.odobrena_kolicina is not None for item in items)):
        raise ValidationError('Postojeća pojedinačna odluka se čuva. Koristite kontrolisanu ispravku.')
    for item in items:
        matches = [row for row in legacy if row.pacijent_id == request.pacijent_id and row.lijek_id == item.lijek_id]
        active = [row for row in matches if row.status != m.Trebovanje.STATUS_OTKAZANO]
        if len(active) > 1 or any(row.komisija_id or (row.odobrene_doze is not None and row.odobrene_doze != 0)
                or row.zaprimljene_doze > 0 or row.zaduzenje_kreirano
                or row.status in ('ODOBRENO', 'DJELOMICNO_ODOBRENO', 'CEKA_ISPORUKU', 'ZAPRIMLJENO', 'ODBIJENO')
                for row in matches):
            raise ValidationError('Zahtjev već ima povezanu odluku ili historiju zaprimanja. Potrebna je kontrolisana provjera i usklađivanje.')


def _checked_quantities(row, items):
    posted = row['approved_quantities']
    if set(posted) - {item.pk for item in items}:
        raise ValidationError('Količina pripada stavci iz drugog zahtjeva.')
    decision = row['decision']
    if decision == CEKA:
        if any(value is not None for value in posted.values()):
            raise ValidationError('Za odluku Čeka ostavite odobrene količine prazne.')
        return {item.pk: None for item in items}
    if decision == m.KomisijskaSaglasnost.Odluka.ODBIJENO:
        if any(value not in (None, Decimal('0')) for value in posted.values()):
            raise ValidationError('Odbijen zahtjev ne može imati pozitivnu odobrenu količinu.')
        return {item.pk: Decimal('0') for item in items}
    if any(item.pk not in posted or posted[item.pk] is None for item in items):
        raise ValidationError('Unesite stvarno odobrenu količinu za svaku stavku; tražena količina se ne preuzima automatski.')
    quantities = {item.pk: posted[item.pk] for item in items}
    if any(not item.kolicina.is_finite() or quantities[item.pk] > item.kolicina for item in items):
        raise ValidationError('Odobrena količina ne može biti veća od tražene količine.')
    if decision == m.KomisijskaSaglasnost.Odluka.ODOBRENO:
        if any(quantities[item.pk] != item.kolicina for item in items):
            raise ValidationError('Za Odobreno unesite punu traženu količinu ili izaberite Djelimično odobreno.')
    elif not any(quantities.values()) or all(quantities[item.pk] == item.kolicina for item in items):
        raise ValidationError('Djelimično odobrenje mora imati pozitivnu količinu i najmanje jednu umanjenu stavku.')
    return quantities


@transaction.atomic
def save_shared_commission_document(cycle, rows, *, user, number='', decision_date,
                                    note='', confirmed=False, token=''):
    if not je_komisijski_tim(user):
        raise PermissionDenied
    if confirmed is not True:
        raise ValidationError('Potvrdite da dokument i sve označene pojedinačne odluke odgovaraju stvarnoj odluci ZZO.')
    number, note = str(number or '').strip(), str(note or '').strip()
    if len(number) > 100:
        raise ValidationError('Broj zajedničkog dokumenta može imati najviše 100 znakova.')
    if not isinstance(decision_date, date) or isinstance(decision_date, datetime):
        raise ValidationError('Unesite ispravan datum dokumenta odluke.')
    posted = _posted_rows(rows)
    try:
        reviewed = signing.loads(token, salt=SALT, max_age=1800)
        operation = UUID(reviewed['operation'])
    except (signing.BadSignature, ValueError, TypeError, KeyError):
        raise ValidationError('Pregled dokumenta je istekao. Osvježite tabelu i ponovo provjerite stavke.') from None
    if reviewed.get('cycle') != cycle.pk or reviewed.get('user') != user.pk:
        raise ValidationError('Pregled dokumenta pripada drugom korisniku ili ciklusu.')
    content_hash = digest({'number': number, 'date': decision_date, 'note': note, 'rows': posted})
    current_cycle = m.KomisijskiCiklus.objects.select_for_update().get(pk=cycle.pk)
    existing = m.KomisijskiDokumentOdluke.objects.filter(operation_id=operation).first()
    if existing:
        if (existing.komisijski_ciklus_id != current_cycle.pk or existing.kreirao_id != user.pk
                or existing.content_hash != content_hash):
            raise ValidationError('Ova potvrda je već iskorištena za drugi sadržaj dokumenta. Ponovo otvorite pregled.')
        return existing
    if number and m.KomisijskiDokumentOdluke.objects.filter(komisijski_ciklus=current_cycle,
            broj_dokumenta__iexact=number, datum_dokumenta=decision_date).exists():
        raise ValidationError('Dokument sa ovim brojem i datumom je već evidentiran u ciklusu. Otvorite postojeći dokument; postojeće stavke se ne upisuju ponovo.')
    requests = list(m.KomisijskiZahtjev.objects.select_for_update().filter(
        komisijski_ciklus=current_cycle, pk__in=[row['request_id'] for row in posted]).order_by('pk'))
    if len(requests) != len(posted):
        raise ValidationError('Svi označeni zahtjevi moraju pripadati ovom ciklusu.')
    all_items = list(select_for_update_self(m.KomisijskaStavkaLijeka.objects.filter(
        komisijski_zahtjev__in=requests).select_related('lijek')).order_by('pk'))
    legacy = list(m.Trebovanje.objects.select_for_update().filter(
        komisijski_ciklus=current_cycle, pacijent_id__in=[req.pacijent_id for req in requests])
        .order_by('pk'))
    list(m.Komisija.objects.select_for_update().filter(pk__in=[row.komisija_id for row in legacy if row.komisija_id]).order_by('pk'))
    if reviewed.get('revision') != shared_document_revision(current_cycle):
        raise ValidationError('Zahtjevi, povezane odluke ili zaprimanja su promijenjeni. Ponovo pregledajte dokument.')
    checked = []
    for request, row in zip(requests, posted):
        items = [item for item in all_items if item.komisijski_zahtjev_id == request.pk]
        _fresh_request(request, items, legacy)
        checked.append((request, row, items, _checked_quantities(row, items)))
    document = m.KomisijskiDokumentOdluke(
        operation_id=operation, komisijski_ciklus=current_cycle, broj_dokumenta=number,
        datum_dokumenta=decision_date, napomena=note, kreirao=user, content_hash=content_hash)
    document.full_clean()
    document.save()
    for request, row, items, quantities in checked:
        if row['decision'] == CEKA:
            record_waiting_decision(request, user=user, note=row['note'] or note)
            agreement = None
        else:
            try:
                agreement, _, _ = save_agreement_for_receiving(commission_request=request,
                    agreement_number=number, agreement_date=decision_date, decision=row['decision'],
                    approved_quantities=quantities, note=row['note'] or note, user=user,
                    shared_document=document)
            except ValueError as exc:
                raise ValidationError(str(exc)) from exc
        for item in items:
            item.refresh_from_db()
            receiving = (m.Trebovanje.objects.filter(komisijski_ciklus=current_cycle,
                pacijent_id=request.pacijent_id, lijek_id=item.lijek_id)
                .exclude(status=m.Trebovanje.STATUS_OTKAZANO).first()) if agreement else None
            line = m.KomisijskaDokumentStavka(dokument=document, komisijski_zahtjev=request,
                stavka_lijeka=item, pacijent_id=request.pacijent_id, lijek_id=item.lijek_id,
                saglasnost=agreement, komisija_id=receiving.komisija_id if receiving else None,
                odluka=row['decision'], trazena_kolicina_snapshot=item.kolicina,
                odobrena_kolicina_snapshot=quantities[item.pk], jedinica_snapshot=item.jedinica)
            line.full_clean()
            line.save()
    upisi_log(user, 'Evidentiran zajednički dokument ZZO', objekat=document,
        opis=f'Dokument ID {document.pk}, broj {number or "nije unesen"}, datum {decision_date.isoformat()}; '
             + '; '.join(f'zahtjev {req.pk}: {row["decision"]}, stavke '
                         + ', '.join(f'{item.pk}={quantities[item.pk] if quantities[item.pk] is not None else "čeka"}'
                                     for item in items) for req, row, items, quantities in checked))
    return document
