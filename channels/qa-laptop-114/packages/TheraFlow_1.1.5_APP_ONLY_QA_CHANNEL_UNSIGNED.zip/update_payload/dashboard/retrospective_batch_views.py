from datetime import timedelta
from urllib.parse import urlencode
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.utils import timezone
from patients import models as m, retrospective_batches as batches, retrospective_events as events
from patients.retrospective_history import period_overview
from .retrospective_batch_forms import BatchRowForm, CheckpointForm, posted_rows



from .correction_center_views import render_in_center as render
def patient_flow(request,patient):
    events.authorize(request.user)
    from .retrospective_views import error_message
    url=reverse('ispravi_podatke_pacijenta',args=[patient.pk])
    args=request.POST if request.method=='POST' else request.GET
    draft_id=args.get('batch_id') or request.GET.get('batch_id')
    draft=get_object_or_404(m.RetrospectiveBatch,pk=draft_id,patient=patient) if draft_id else None
    reconstruction=bool(draft.reconstruction) if draft else args.get('reconstruction')=='september2026'
    checkpoint=draft.reconstruction if draft else {}
    if reconstruction and request.method=='POST' and args.get('action') not in ('batch-confirm','batch-reverse','batch-reversal-preview','batch-copy'):
        raw_id=args.get('checkpoint-count_id','')
        checkpoint={'count_id':int(raw_id) if raw_id.isdigit() else None,
            'evidence':args.get('checkpoint-evidence','')[:500],
            'verified':args.get('checkpoint-verified') in ('on','true','1')}
    today=timezone.localdate()
    start=args.get('period_start') or (str(draft.period_start) if draft else str(today-timedelta(days=30)))
    end=args.get('period_end') or (str(draft.period_end) if draft else str(today))
    if reconstruction:start,end='2026-09-01','2026-09-30'
    reason=args.get('reason',draft.reason if draft else '')
    rows=draft.rows if draft else []
    context=dict(patient_context=patient,workspace_url=url,draft=draft,start=start,end=end,reason=reason,
        reconstruction=reconstruction,checkpoint_form=CheckpointForm(initial=checkpoint,prefix='checkpoint'))
    action=args.get('action','')
    try:
        if request.method=='POST':
            if action in ('batch-confirm','batch-reverse'):
                events.require(args.get('confirmed')=='yes','Potvrdite da ste pregledali sve posljedice.')
                operation=batches.confirm if action=='batch-confirm' else batches.reverse
                saved,_=operation(args.get('token',''),request.user,patient)
                return redirect(url+'?'+urlencode({'intent':'missing','batch_id':saved.pk}))
            if action=='batch-reversal-preview':
                events.require(draft is not None,'Odaberite sačuvani unos.')
                context['reversal'],context['token']=batches.make_reversal_preview(draft,request.user,reason)
            elif action=='batch-copy':
                events.require(draft and draft.status=='REVERSED','Prvo pregledajte i potvrdite poništavanje originala.')
                new=batches.save_draft(patient=patient,user=request.user,start=draft.period_start,end=draft.period_end,
                    reason=reason,rows=draft.rows,correction_of=draft.pk,reconstruction=draft.reconstruction)
                return redirect(url+'?'+urlencode({'intent':'missing','batch_id':new.pk}))
            else:
                events.require(not draft or draft.status=='DRAFT','Potvrđeni unos se ne prepisuje.')
                rows=posted_rows(args)
                if action.startswith('batch-add-'):
                    kind=action.removeprefix('batch-add-');events.require(kind in events.TITLES,'Odaberite vrstu događaja.')
                    events.require(len(rows)<20,'Jedan unos može imati do 20 događaja.')
                    rows.append({'kind':kind,'patient_id':patient.pk,'medicine_id':patient.lijek_id,
                        'event_date':'','quantity':'','receipt_mode':'NEW'})
                if action.startswith('batch-remove-'):
                    index=int(action.removeprefix('batch-remove-'))
                    events.require(0<=index<len(rows),'Odaberite red koji uklanjate iz nacrta.')
                    rows.pop(index)
                draft=batches.save_draft(patient=patient,user=request.user,start=start,end=end,reason=reason,
                    rows=rows,draft_id=draft.pk if draft else None,revision=args.get('revision'),
                    reconstruction=checkpoint if reconstruction else None)
                context.update(draft=draft,saved_draft=True)
                if action=='batch-preview':
                    context['plan'],context['token']=batches.make_preview(draft,request.user)
        start_day,end_day=events.day(start),events.day(end)
        events.require(start_day<=end_day<=today,'Odaberite period koji završava najkasnije danas.')
        context['overview']=period_overview(patient,start_day,end_day)
    except Exception as exc:
        context['error']=error_message(exc)
    if draft and draft.status!='DRAFT':
        context['saved_events']=draft.events.select_related('patient','medicine','user').order_by('event_date','pk')
        context['plan']=draft.preview
        try:context['verification']=batches.verify_saved(draft)
        except Exception:
            context['verification']={'warnings':['Unos je sačuvan. Naknadno očitavanje trenutno nije dostupno; osvježite ovaj pregled. Ne unosite događaje ponovo.']}
    forms=[]
    for index,row in enumerate(rows):
        kind=row.get('kind')
        if kind not in events.TITLES:
            context['error']=f'Događaj {index+1}: odaberite podržanu vrstu događaja.'
            continue
        data={f'row-{index}-{key}':value for key,value in row.items()}
        data[f'row-{index}-patient_id']=(row.get('patient_id') or patient.pk) if reconstruction else patient.pk
        form=BatchRowForm(data,prefix=f'row-{index}',kind=kind,patient=patient,reconstruction=reconstruction)
        forms.append({'form':form,'title':events.TITLES[kind],'index':index,'number':index+1})
    context['row_forms']=forms
    context['row_count']=len(rows)
    ids={patient.lijek_id,*patient.promjene_terapije.values_list('stari_lijek_id',flat=True)}-{None}
    drugs=list(m.Lijek.objects.filter(pk__in=ids))
    context['can_therapy']=any(not d.oralna_terapija and not d.kucna_terapija for d in drugs)
    context['can_home']=any(d.kucna_terapija and not d.oralna_terapija for d in drugs)
    if reconstruction:context.update(can_therapy=True,can_home=False)
    context['recent_batches']=m.RetrospectiveBatch.objects.filter(patient=patient).select_related('user')[:20]
    return render(request,'dashboard/retrospective_batch.html',context)
