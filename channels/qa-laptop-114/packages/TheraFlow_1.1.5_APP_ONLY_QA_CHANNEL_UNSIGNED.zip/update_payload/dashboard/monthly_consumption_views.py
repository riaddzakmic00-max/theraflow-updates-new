from io import BytesIO
from xml.sax.saxutils import escape

from django import forms
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET

from patients.monthly_consumption import build_monthly_consumption, REPORT_TIME_ZONE
from .permissions import je_terapijski_tim

MONTHS = list(enumerate(("Januar", "Februar", "Mart", "April", "Maj", "Juni",
                        "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"), 1))


class MonthlyConsumptionForm(forms.Form):
    mjesec = forms.TypedChoiceField(label="Mjesec", choices=MONTHS, coerce=int)
    godina = forms.IntegerField(label="Godina", min_value=1900, max_value=9998,
                               widget=forms.NumberInput(attrs={"inputmode": "numeric"}))


def quantity_text(value):
    return format(value, "f").rstrip("0").rstrip(".").replace(".", ",") if "." in format(value, "f") else str(value)


def report_pdf(report):
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_RIGHT
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, LongTable, TableStyle
    from .pdf_overlay import register_pdf_fonts, PDF_FONT_FALLBACK, PDF_FONT_BOLD

    register_pdf_fonts()
    output = BytesIO()
    doc = SimpleDocTemplate(output, pagesize=landscape(A4), rightMargin=30, leftMargin=30,
                            topMargin=30, bottomMargin=35, title="Mjesečna potrošnja lijekova", author="TheraFlow")
    normal = ParagraphStyle("Monthly", fontName=PDF_FONT_FALLBACK, fontSize=10, leading=14, spaceAfter=6)
    heading = ParagraphStyle("MonthlyHeading", parent=normal, fontName=PDF_FONT_BOLD, fontSize=17, leading=22)
    small = ParagraphStyle("MonthlySmall", parent=normal, fontSize=9, leading=12)
    right = ParagraphStyle("MonthlyNumber", parent=normal, alignment=TA_RIGHT)

    def p(text, style=normal):
        return Paragraph(escape(str(text)), style)

    def table(data, widths):
        result = LongTable(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
        result.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eaf3f7")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LINEBELOW", (0, 0), (-1, 0), .7, colors.HexColor("#8babb9")),
            ("LINEBELOW", (0, 1), (-1, -1), .3, colors.HexColor("#d9e3e8")),
            ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
            ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ]))
        return result

    story = [p("Mjesečna potrošnja lijekova", heading),
             p(f"Period: {report['start']:%d/%m/%Y} – {report['end']:%d/%m/%Y}")]
    if report["current"]:
        story.append(p(f"Tekući mjesec — dosad evidentirana potrošnja, do {report['through']:%d/%m/%Y}."))
    if report["needs_review"]:
        story.append(p("Potrebna provjera: dio povrata nije raspoređen. Ukupno je iskazano bez tih povrata."))
    story += [p("Ukupno: ukupni izlaz lijekova za terapiju iz ambulantnih zaliha.", small),
              p("Nula znači da nema evidentiranog izlaza. Kućno izdavanje nije dokaz primjene; nepotpuna historija ne potvrđuje odsustvo potrošnje.", small),
              p(report["stock_note"], small), p(report["history_note"], small), p(report["return_note"], small)]
    story += [p(message, small) for message in report["warnings"]]
    data = [[p(text, small) for text in ("Lijek", "Jačina i oblik", "Jedinica", "Utrošeno u ambulanti", "Izdato za kući", "Ukupno", report["stock_header"])]]
    for row in report["rows"]:
        drug = row["drug"]
        data.append([p(drug.naziv), p(f"{drug.strength or drug.presentation_strength_label or 'Jačina nije evidentirana'} · {drug.pharmaceutical_form or drug.get_farmaceutski_oblik_display() or 'Oblik nije evidentiran'} · {drug.put_primjene}"),
                     p(row["unit"]), *[p(quantity_text(row[key]), right) for key in ("clinic", "home", "total")],
                     p(quantity_text(row["fridge"]["quantity"]), right) if row["fridge"]["quantity"] is not None else p("Nema dovoljno podataka", small)])
    if report["rows"]:
        story.append(table(data, [135, 202, 65, 99, 88, 67, 125]))
    else:
        story.append(p("Nema evidentirane potrošnje u odabranom mjesecu."))
    story.append(Spacer(1, 15))
    for row in report["rows"]:
        title = p(f"Detalji: {row['drug'].naziv} ({row['unit']})")
        title.keepWithNext = True
        story.append(title)
        stock_quantity = quantity_text(row["fridge"]["quantity"]) + " " + row["fridge_unit"] if row["fridge"]["quantity"] is not None else "Nema dovoljno podataka"
        stock_note = p(f"{report['stock_header']}: {stock_quantity}. {row['fridge']['reason']}", small)
        stock_note.keepWithNext = bool(row["details"])
        story.append(stock_note)
        if not row["details"]:
            story += [p("Nema evidentirane potrošnje u ovom mjesecu.", small), Spacer(1, 15)]
            continue
        detail = [[p(text, small) for text in ("Datum", "Pacijent", "Količina", "Vrsta evidencije", "Izvor")]]
        for item in row["details"]:
            detail.append([p(item["date"].strftime("%d/%m/%Y")), p(item["patient"] or "Nije evidentiran"),
                           p(quantity_text(item["quantity"]), right), p(item["label"]), p(item["reference"], small)])
        story += [table(detail, [85, 185, 76, 235, 200]), Spacer(1, 15)]
    if report["adjustments"]:
        story.append(p("Otpis, korekcije i neraspoređeni povrati — odvojeno od terapijske potrošnje"))
        data = [[p(text, small) for text in ("Datum", "Lijek", "Vrsta", "Promjena zalihe", "Jedinica")]]
        for item in report["adjustments"]:
            data.append([p(item["date"].strftime("%d/%m/%Y")), p(item["drug"].naziv), p(item["label"]),
                         p(quantity_text(item["quantity"]), right), p(item["unit"])])
        story.append(table(data, [85, 230, 255, 120, 91]))

    def footer(canvas, document):
        canvas.setFont(PDF_FONT_FALLBACK, 8)
        canvas.drawString(30, 18, f"TheraFlow · Generisano {timezone.localtime(report['generated_at']):%d/%m/%Y %H:%M}")
        canvas.drawRightString(811, 18, f"Stranica {document.page}")

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return output.getvalue()


@login_required
@never_cache
@require_GET
@timezone.override(REPORT_TIME_ZONE)
def monthly_consumption(request):
    if not je_terapijski_tim(request.user):
        raise PermissionDenied("Izvještaj je dostupan terapijskom timu.")
    today = timezone.localdate()
    form = MonthlyConsumptionForm(request.GET if request.GET else {"mjesec": today.month, "godina": today.year})
    report = None
    if form.is_valid():
        report = build_monthly_consumption(form.cleaned_data["godina"], form.cleaned_data["mjesec"], today=today)
        if request.GET.get("format") == "pdf":
            response = HttpResponse(report_pdf(report), content_type="application/pdf")
            response["Content-Disposition"] = f'attachment; filename="TheraFlow_potrosnja_{report["start"]:%Y-%m}.pdf"'
            return response
    return render(request, "dashboard/monthly_consumption.html", {"form": form, "report": report},
                  status=200 if report is not None else 400)
