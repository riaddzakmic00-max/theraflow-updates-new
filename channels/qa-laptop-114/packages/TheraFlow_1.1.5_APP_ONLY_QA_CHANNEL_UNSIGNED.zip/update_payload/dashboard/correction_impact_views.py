from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, render
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET

from patients import models as m
from patients.activity_review import read_projection
from .activity_review_views import _access as authorize
from patients.correction_impact import balance_explanation
from .balance_presentation import context as presentation_context


@login_required
@never_cache
@require_GET
def explain_balance(request, medicine_id):
    authorize(request)
    with read_projection():
        medicine = get_object_or_404(m.Lijek, pk=medicine_id)
        patient = get_object_or_404(m.Pacijent, pk=request.GET['patient']) if request.GET.get('patient') else None
        explanation = balance_explanation(medicine, patient)
        presentation = presentation_context(explanation, request)
        template = 'dashboard/_balance_explanation.html' if request.headers.get('X-TheraFlow-Explanation') else 'dashboard/balance_explanation.html'
        return render(request, template, {'explanation': explanation, 'balance': presentation})
