from django.shortcuts import render
from django.views.decorators.http import require_GET
from dashboard.diagnostics.views import admin_only
from dashboard.diagnostics.readonly import diagnostic_snapshot
from patients.pilot111_review import review_after_111


@admin_only
@require_GET
def review(request):
    with diagnostic_snapshot(seconds=60):
        report = review_after_111()
    return render(request, 'dashboard/diagnostics/pilot111_review.html', {'report':report})
