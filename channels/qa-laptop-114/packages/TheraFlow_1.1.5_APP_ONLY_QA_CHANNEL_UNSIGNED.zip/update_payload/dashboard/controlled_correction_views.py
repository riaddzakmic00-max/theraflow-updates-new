"""Explicit previews for administrative provenance and native corrections."""
import logging
from urllib.parse import urlencode

from django import forms
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.decorators import login_required
from django.db import DatabaseError
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from patients import models as m, commission_receipt_link as links, controlled_corrections as controlled
from patients.correction_center import authorize
from patients.correction_protocol import contention_message
from .correction_center_views import render_in_center
from .postgres_backup import BackupError

logger = logging.getLogger(__name__)


class ReversalForm(forms.Form):
    reason = forms.CharField(label='Razlog poništavanja', min_length=5, max_length=500,
        widget=forms.Textarea(attrs={'rows':3}))


@login_required
@require_http_methods(['GET', 'POST'])
def event_reversal(request, kind, object_id):
    from patients import retrospective_reversal as service
    from patients.activity_review import read_projection
    authorize(request.user)
    form = ReversalForm(request.POST if request.method=='POST' and request.POST.get('action')=='preview' else None)
    context = dict(title='Poništi događaj', form=form)
    try:
        if request.method=='POST' and request.POST.get('action')=='confirm':
            service.require(request.POST.get('confirmed')=='yes', 'Potvrdite pregled posljedica poništavanja.')
            audit, _ = service.confirm_event_reversal(request.POST.get('token',''), request.user, kind=kind, object_id=object_id)
            return redirect(reverse('event_reversal', args=[kind,object_id])+'?saved='+str(audit.pk))
        if form.is_bound and form.is_valid():
            context['preview'], context['token'] = service.make_event_reversal_preview(kind, object_id, form.cleaned_data['reason'], request.user)
    except ObjectDoesNotExist:
        raise Http404('Događaj nije pronađen.') from None
    except ValueError as exc:
        context['error']=str(exc)
    except DatabaseError as exc:
        logger.exception('Poništavanje nije potvrđeno; transakcija je vraćena.')
        context['error']=contention_message(exc) or 'Poništavanje nije sačuvano. Cijeli događaj je vraćen; ponovite pregled.'
    try:
        with read_projection():
            original = service.original_context(kind, object_id)
            original_label = {
                'Terapija': 'Stvarna terapija', 'RetrospectiveEvent': 'Naknadno evidentiran događaj',
                'PatientDataCorrection': 'Ispravka podataka', 'ReconciliationAction': 'Radnja usklađivanja',
                'IzdavanjeOralneTerapije': 'Oralno izdavanje',
            }.get(original['source'].__class__.__name__, 'Evidentiran događaj')
            context['original_label'] = f"{original_label} #{original['source'].pk}"
            context.update(original=original['source'], patient=original['patient'], medicine=original['medicine'],
                original_at=original['cutoff'], original_user=getattr(original['source'],'user',getattr(original['source'],'korisnik',None)),
                original_reason=getattr(original['source'],'note',getattr(original['source'],'razlog','')), current=service.current_values(original) if original['medicine'] else {},
                dependencies=service.dependent_events(original))
            if context.get('preview') and not context['preview']['allowed']:
                context['dependencies'] = context['preview']['dependencies'] or context['dependencies']
            context['saved']=m.PatientDataCorrection.objects.filter(posljedice__source='safe_event_reversal',
                posljedice__original_model=original['source'].__class__.__name__,posljedice__original_pk=original['source'].pk).first()
    except ObjectDoesNotExist:
        raise Http404('Događaj nije pronađen.') from None
    except ValueError as exc:
        context['error']=str(exc)
    return render_in_center(request, 'dashboard/event_reversal.html', context)


def recovery_context(patient=None, medicine=None, session=None):
    query = {}
    if patient: query['patient_id'] = patient.pk
    if medicine: query['medicine_id'] = medicine.pk
    if session: query['session_id'] = session.pk
    base = reverse('correction_center')
    normal = [dict(label='Provjeri stvarne događaje kroz Smart Reconciliation',
        url=base + '?' + urlencode(dict(section='smart', **({'cc_patient':patient.pk} if patient else {}),
                                       **({'cc_medicine':medicine.pk} if medicine else {})))),
              dict(label='Provjeri komisijski zahtjev i saglasnost', url=reverse('komisijski_centar'))]
    if patient:
        normal.append(dict(label='Provjeri terapijski plan / nalog ljekara', url=reverse('correction_plan', args=[patient.pk, 'dose'])))
    if medicine:
        normal.append(dict(label='Objasni fizičko stanje i zaduženja', url=reverse('explain_inventory_balance', args=[medicine.pk]) +
                          ('?' + urlencode({'patient':patient.pk}) if patient else '')))
    return dict(normal=normal, url=reverse('controlled_correction') + ('?' + urlencode(query) if query else ''))


class LinkForm(forms.Form):
    request_id = forms.ChoiceField(label='Komisijska stavka', widget=forms.RadioSelect)
    reason = forms.CharField(label='Razlog povezivanja', min_length=5, max_length=500, strip=True,
                             widget=forms.Textarea(attrs={'rows':2}))


@login_required
@require_http_methods(['GET', 'POST'])
def commission_link(request, receipt_id):
    authorize(request.user)
    receipt = get_object_or_404(m.UnlinkedStockReceipt.objects.select_related('medicine', 'movement', 'request'), pk=receipt_id)
    candidates = links.candidates(receipt) if not receipt.request_id else dict(items=[], incomplete=False)
    form = LinkForm(request.POST if request.method == 'POST' and request.POST.get('action') == 'preview' else None)
    form.fields['request_id'].choices = [(item['request'].pk,
        f'{item["request"].pacijent} · {item["cycle"] or "bez ciklusa"} · odobreno {item["request"].odobrene_doze} · '
        f'preostalo za provjeru {item["remaining"]} · saglasnost {item["agreement"] or "nije evidentirana"}')
        for item in candidates['items']]
    session_id = request.GET.get('session_id')
    context = dict(title='Poveži sa komisijom', actual_receipt=receipt, candidates=candidates,
                   form=form, medicine=receipt.medicine, linked=bool(receipt.request_id), handles_recovery=True)
    try:
        if request.method == 'POST':
            if request.POST.get('action') == 'preview' and form.is_valid():
                context['preview'], context['token'] = links.preview(receipt.pk, form.cleaned_data['request_id'],
                    form.cleaned_data['reason'], request.user, session_id=int(session_id) if session_id else None)
            elif request.POST.get('action') == 'confirm':
                links.require(request.POST.get('confirmed') == 'yes', 'Potvrdite pregled administrativne veze.')
                audit, _ = links.confirm(request.POST.get('token', ''), request.user, receipt_id=receipt.pk)
                return redirect(reverse('commission_receipt_link', args=[receipt.pk]) + '?saved=' + str(audit.pk))
    except (ValueError, m.ReconciliationSession.DoesNotExist) as exc:
        context['error'] = str(exc) or 'Proces više nije dostupan. Ponovo otvorite postupak.'
    except DatabaseError as exc:
        logger.exception('Komisijska veza nije potvrđena.')
        context['error'] = contention_message(exc) or 'Veza nije potvrđena. Ponovite pregled; stanje zalihe nije promijenjeno.'
    receipt.refresh_from_db()
    context['linked'] = bool(receipt.request_id)
    if request.GET.get('saved'):
        context['saved'] = get_object_or_404(m.PatientDataCorrection, pk=request.GET['saved'],
            scope='commission_link', korisnik=request.user, izvorna_transakcija_id=receipt.movement_id)
    context['recovery'] = recovery_context(medicine=receipt.medicine)
    return render_in_center(request, 'dashboard/commission_receipt_link.html', context)


class ControlledForm(forms.Form):
    problem = forms.ChoiceField(label='Šta blokira standardni workflow?', choices=controlled.PROBLEMS)
    explanation = forms.CharField(label='Zašto standardni workflow ne može završiti radnju?',
        min_length=5, max_length=1000, strip=True, widget=forms.Textarea(attrs={'rows':2}))
    medicine_id = forms.ModelChoiceField(label='Lijek / prezentacija', queryset=m.Lijek.objects.none())
    patient_id = forms.ModelChoiceField(label='Pacijent, kada je relevantan', required=False, queryset=m.Pacijent.objects.none())
    kind = forms.ChoiceField(label='Podržana korekcija', choices=[('physical', 'Fizički popis'),
        ('allocate', 'Dodijeli slobodnu dozu'), ('release', 'Oslobodi pogrešno zaduženje'), ('record', 'Ispravi konkretan zapis')])
    quantity = forms.DecimalField(label='Ispravna količina / količina dodjele ili oslobađanja', min_value=0, max_digits=8, decimal_places=2)
    reservation_id = forms.ModelChoiceField(label='Postojeće zaduženje za oslobađanje', required=False, queryset=m.PacijentRezervacija.objects.none())
    acknowledge_appointment = forms.BooleanField(label='Provjerio/la sam pokriće povezanog termina.', required=False)
    event_date = forms.DateField(label='Datum fizičkog popisa / dokumentovanog događaja', required=False, widget=forms.DateInput(attrs={'type':'date'}, format='%Y-%m-%d'))
    scope = forms.ChoiceField(label='Obuhvat fizičkog popisa', required=False, choices=[('TOTAL','Ukupno — serije nisu dokumentovane'), ('LOT','Konkretna serija i rok')])
    batch = forms.CharField(label='Serija / LOT za konkretni popis', required=False, max_length=100)
    expires = forms.DateField(label='Rok trajanja', required=False, widget=forms.DateInput(attrs={'type':'date'}, format='%Y-%m-%d'))
    record_target = forms.ChoiceField(label='Konkretan zapis za ispravku', required=False)
    approval = forms.ModelChoiceField(label='Postojeće odobrenje za ispravku pacijentove količine', required=False, queryset=m.Komisija.objects.none())
    source_movement = forms.ModelChoiceField(label='Dokumentovani prijem za ispravku pacijentove količine', required=False, queryset=m.ZalihaTransakcija.objects.none())
    reason = forms.CharField(label='Razlog korekcije', min_length=5, max_length=500, strip=True, widget=forms.Textarea(attrs={'rows':3}))

    def __init__(self, *args, medicine=None, patient=None, **kwargs):
        super().__init__(*args, **kwargs)
        from .stock_correction_forms import StockMedicineForm
        self.fields['medicine_id'].queryset = StockMedicineForm().fields['lijek'].queryset
        self.fields['patient_id'].queryset = m.Pacijent.objects.order_by('prezime', 'ime', 'pk')
        targets = [('', 'Odaberite dokumentovani zapis')]
        if medicine:
            reservations = m.PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True, kolicina__gt=0)
            claims = m.EvidencijaSaglasnostiZaprimanja.objects.filter(trebovanje__lijek=medicine)
            issues = m.KucnoIzdavanje.objects.filter(lijek=medicine)
            if patient:
                reservations = reservations.filter(pacijent=patient)
                claims = claims.filter(pacijent=patient)
                issues = issues.filter(pacijent=patient)
                targets.append((f'patient_stock:{patient.pk}', f'Ukupna količina u frižideru — {patient}'))
            self.fields['reservation_id'].queryset = reservations
            targets += [(f'receipt:{tx.pk}', f'Prijem {tx.datum:%d/%m/%Y} · {tx.kolicina} · {tx.serija or "bez serije"}')
                        for tx in m.ZalihaTransakcija.objects.filter(lijek=medicine, tip='ZAPRIMANJE').order_by('-datum', '-pk')[:100]]
            targets += [(f'allocation:{claim.pk}', f'Raspodjela {claim.zaprimljena_kolicina} · {claim.pacijent}')
                        for claim in claims.select_related('pacijent').order_by('-pk')[:100]]
            targets += [(f'issue:{issue.pk}', f'Kućno izdavanje {issue.datum:%d/%m/%Y} · {issue.pacijent}')
                        for issue in issues.select_related('pacijent').order_by('-pk')[:100]]
            self.fields['source_movement'].queryset = m.ZalihaTransakcija.objects.filter(lijek=medicine, tip='ZAPRIMANJE')
            if patient:
                self.fields['approval'].queryset = m.Komisija.objects.filter(pacijent=patient, lijek=medicine)
        self.fields['record_target'].choices = targets

    def raw(self, session_id=None):
        data = {key: value.pk if hasattr(value, 'pk') else value for key, value in self.cleaned_data.items()}
        if data.get('record_target'):
            kind, identifier = data['record_target'].split(':')
            data.update(target_kind=kind, target_id=int(identifier))
        if session_id: data['session_id'] = int(session_id)
        return data


@login_required
@require_http_methods(['GET', 'POST'])
def controlled_correction(request):
    authorize(request.user)
    identifiers = request.POST if request.method == 'POST' and request.POST.get('action') == 'preview' else request.GET
    medicine = get_object_or_404(m.Lijek, pk=identifiers['medicine_id']) if identifiers.get('medicine_id') else None
    patient = get_object_or_404(m.Pacijent, pk=identifiers['patient_id']) if identifiers.get('patient_id') else None
    form = ControlledForm(request.POST if request.method == 'POST' and request.POST.get('action') == 'preview' else None,
        medicine=medicine, patient=patient, initial=dict(medicine_id=medicine, patient_id=patient,
            event_date=timezone.localdate(), scope='TOTAL', problem=request.GET.get('problem', 'legacy'), kind=request.GET.get('kind', 'physical')))
    context = dict(form=form, medicine=medicine, patient=patient, recovery=recovery_context(patient, medicine), handles_recovery=True)
    context['correction_kind'] = form['kind'].value() or 'physical'
    try:
        if request.method == 'POST':
            if request.POST.get('action') == 'preview' and form.is_valid():
                context['controlled_preview'], context['token'] = controlled.preview(form.raw(request.GET.get('session_id')), request.user)
                context['preview'] = context['controlled_preview']['native']
            elif request.POST.get('action') == 'confirm':
                controlled.require(request.POST.get('confirmed') == 'yes' and request.POST.get('normal_reviewed') == 'yes',
                    'Potvrdite pregled posljedica i da standardni workflow ne može riješiti ovu razliku.')
                audit, _ = controlled.confirm(request.POST.get('token', ''), request.user)
                return redirect(reverse('controlled_correction') + '?saved=' + str(audit.pk))
    except (ValueError, m.ReconciliationSession.DoesNotExist) as exc:
        context['error'] = str(exc) or 'Proces više nije dostupan. Ponovo otvorite postupak.'
    except (DatabaseError, BackupError) as exc:
        logger.exception('Kontrolisana korekcija vraćena.')
        context['error'] = contention_message(exc) or 'Korekcija nije završena. Backup ili pristup bazi nije uspio; nema djelimičnog knjiženja.'
    if request.GET.get('saved'):
        receipt = get_object_or_404(m.PatientDataCorrection, pk=request.GET['saved'], korisnik=request.user)
        if not isinstance(receipt.posljedice, dict) or 'controlled' not in receipt.posljedice:
            raise Http404('Nije kontrolisana korekcija.')
        context['saved'] = receipt
        context['remaining'] = controlled.remaining_checks(receipt, request.user)
    return render_in_center(request, 'dashboard/controlled_correction.html', context)
