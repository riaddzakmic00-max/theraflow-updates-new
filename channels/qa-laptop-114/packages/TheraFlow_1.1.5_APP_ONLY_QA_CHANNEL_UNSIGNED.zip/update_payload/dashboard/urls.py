from django.urls import path
from . import views
from .patient_correction_views import correct_patient_data, print_patient_correction
from .stock_correction_views import correct_physical_stock
from . import inventory_correction_views as inventory_corrections
from .quick_change_views import quick_change
from .correction_views import correct_patient_profile
from .monthly_consumption_views import monthly_consumption
from .hyrimoz_nurse_views import hyrimoz_nurse_list
from .diagnostics import views as diagnostic_views
from . import retrospective_views
from . import correction_center_views as correction_center
from . import nurse_correction_views
from .ustekinumab_transition_views import transition as ustekinumab_iv_to_sc
from .correction_impact_views import explain_balance
from . import activity_review_views
from . import controlled_correction_views
from . import pilot111_review_views
from . import patient_allocation_views
from . import patient_action_views

urlpatterns = [
    path('komisijski-centar/fazni-zahtjev/<int:zahtjev_id>/potvrdi/', views.potvrdi_fazni_komisijski_zahtjev, name='potvrdi_fazni_komisijski_zahtjev'),
    path("komisijski-centar/nacrt/potvrdi/", views.potvrdi_komisijski_nacrt, name="potvrdi_komisijski_nacrt"),
    path('pacijent/<int:pacijent_id>/akcije/<str:action>/', patient_action_views.patient_action, name='patient_card_action'),
    path('pacijent/<int:pacijent_id>/zaduzenja/dodaj/', patient_allocation_views.add_allocation, name='patient_add_allocation'),
    path('dijagnostika/provjera-nakon-111/', pilot111_review_views.review, name='pilot111_review'),
    path('ispravke/dogadjaj/<str:kind>/<int:object_id>/ponisti/', controlled_correction_views.event_reversal, name='event_reversal'),
    path('ispravke/prijem/<int:receipt_id>/komisijska-veza/', controlled_correction_views.commission_link, name='commission_receipt_link'),
    path('ispravke/kontrolisana-korekcija/', controlled_correction_views.controlled_correction, name='controlled_correction'),
    path('pregled/potrebna-paznja/', activity_review_views.business_review, name='business_attention'),
    path('pregled/danas/', activity_review_views.business_review, {'mode': 'today'}, name='review_today'),
    path('pregled/period/', activity_review_views.business_review, {'mode': 'period'}, name='review_period'),
    path('pacijent/<int:patient_id>/vremenska-linija/', activity_review_views.patient_timeline, name='patient_timeline'),
    path('zalihe/<int:medicine_id>/objasnjenje/', explain_balance, name='explain_inventory_balance'),
    path('postavke/ispravke-i-naknadna-evidencija/', correction_center.index, name='correction_center'),
    path('ispravke/vodjeni-unos/<str:category>/', nurse_correction_views.workflow, name='nurse_correction'),
    path('postavke/ispravke-i-naknadna-evidencija/sacuvaj-unos/', correction_center.save_draft, name='correction_center_draft'),
    path('ispravke/zaduzenje/<int:pacijent_id>/<int:medicine_id>/', correction_center.allocation, name='correction_allocation'),
    path('ispravke/ponisti/<int:receipt_id>/', correction_center.reversal, name='correction_reversal'),
    path('ispravke/plan/<int:pacijent_id>/<str:kind>/', correction_center.plan_change, name='correction_plan'),
    path('pacijent/<int:pacijent_id>/protokol/ustekinumab/prelazak-sc/', ustekinumab_iv_to_sc, name='ustekinumab_iv_to_sc'),
    path('postavke/naknadna-evidencija/', retrospective_views.index, name='retrospective_events'),
    path('postavke/naknadna-evidencija/<int:event_id>/', retrospective_views.detail, name='retrospective_detail'),
    path('pacijent/<int:pacijent_id>/ispravi-podatke/dokument/', print_patient_correction, name='print_patient_correction'),
    path('postavke/kontrola-ispravke/', correction_center.index, name='correction_center_legacy'),
    path('zalihe/<int:medicine_id>/ispravke/', inventory_corrections.medicine_correction_history, name='medicine_corrections'),
    path('ispravke/promet/<str:kind>/<int:target_id>/', inventory_corrections.correct_inventory, name='correct_inventory'),
    path('ispravke/potvrda/<int:receipt_id>/', inventory_corrections.correction_receipt, name='inventory_correction_receipt'),
    path('ispravke/potvrda/<int:receipt_id>/pdf/', inventory_corrections.print_correction_receipt, name='print_inventory_correction'),
    path("zalihe/ispravi-fizicko-stanje/", correct_physical_stock, name="ispravi_fizicku_zalihu"),
    path('postavke/dijagnostika/', diagnostic_views.index, name='admin_diagnostics'),
    path('postavke/dijagnostika/pokreni/', diagnostic_views.start, name='admin_diagnostics_start'),
    path('postavke/dijagnostika/<uuid:run_id>/', diagnostic_views.result, name='admin_diagnostics_result'),
    path('postavke/dijagnostika/<uuid:run_id>/dokaz/<str:finding_id>/', diagnostic_views.evidence, name='admin_diagnostics_evidence'),
    path('postavke/dijagnostika/<uuid:run_id>/izvoz/', diagnostic_views.export_preview, name='admin_diagnostics_export'),
    path('postavke/dijagnostika/<uuid:run_id>/preuzmi/', diagnostic_views.download, name='admin_diagnostics_download'),
    path('postavke/dijagnostika/<uuid:run_id>/ai/<str:finding_id>/', diagnostic_views.ai_preview, name='admin_diagnostics_ai_preview'),
    path('postavke/dijagnostika/<uuid:run_id>/ai/<str:finding_id>/objasni/', diagnostic_views.explain, name='admin_diagnostics_explain'),
    path("izvjestaji/mjesecna-potrosnja/", monthly_consumption, name="mjesecna_potrosnja"),
    path("izvjestaji/hyrimoz-lista/", hyrimoz_nurse_list, name="hyrimoz_lista_sestra"),
    path("pacijent/<int:pacijent_id>/brze-izmjene/<str:kind>/", quick_change, name="brza_izmjena_pacijenta"),
    path("pacijent/<int:pacijent_id>/ispravi-podatke/", correct_patient_data, name="ispravi_podatke_pacijenta"),
    path("pacijent/<int:pacijent_id>/osnovni-podaci/", correct_patient_profile, name="patient_basic_data"),
    path(
        "setup-first-admin/",
        views.setup_first_admin,
        name="setup_first_admin"
    ),

    # Dashboard
    path("", views.dashboard, name="dashboard"),

    # Komisijski centar v1.5
    path(
        "komisijski-centar/",
        views.komisijski_centar,
        name="komisijski_centar"
    ),

    path(
        "komisijski-centar/za-komisiju/",
        views.za_komisiju,
        name="za_komisiju"
    ),
    path(
        "komisijski-centar/ciklus/<int:ciklus_id>/zahtjev/<int:zahtjev_id>/uredi/",
        views.komisijski_zahtjev_phase2_uredi,
        name="komisijski_zahtjev_phase2_uredi",
    ),
    path(
        "komisijski-centar/ciklus/<int:ciklus_id>/zahtjevi/generisi/",
        views.generisi_komisijske_zahtjeve_phase2,
        name="generisi_komisijske_zahtjeve_phase2",
    ),
    path(
        "komisijski-centar/ciklus/<int:ciklus_id>/zbirni-spisak/",
        views.zbirni_spisak_komisije_phase2,
        name="zbirni_spisak_komisije_phase2",
    ),
    path(
        "komisijski-centar/ciklus/<int:ciklus_id>/pdf/<str:generation_id>/<str:filename>/",
        views.komisijski_phase2_pdf,
        name="komisijski_phase2_pdf",
    ),
    path(
        "komisijski-centar/ciklus/<int:ciklus_id>/oznaci-odstampano/",
        views.oznaci_komisijski_ciklus_odstampan_phase2,
        name="oznaci_komisijski_ciklus_odstampan_phase2",
    ),
    path(
        "komisijski-centar/ciklus/<int:ciklus_id>/oznaci-poslano/",
        views.oznaci_komisijski_ciklus_poslan_phase2,
        name="oznaci_komisijski_ciklus_poslan_phase2",
    ),
    path(
        "komisijski-centar/ciklus/<int:ciklus_id>/zahtjev/<int:zahtjev_id>/saglasnost/",
        views.sacuvaj_komisijsku_saglasnost_phase3,
        name="sacuvaj_komisijsku_saglasnost_phase3",
    ),
    path('komisijski-centar/ciklus/<int:ciklus_id>/odobri-odabrane/',
         views.grupno_odobri_komisijske_zahtjeve, name='grupno_odobri_komisijske_zahtjeve'),
    path('komisijski-centar/ciklus/<int:ciklus_id>/zzo-odobrenje/',
         views.sacuvaj_zajednicko_odobrenje_zzo, name='sacuvaj_zajednicko_odobrenje_zzo'),

    path(
        "komisijski-centar/simulacija/",
        views.komisijska_simulacija,
        name="komisijska_simulacija"
    ),

    path(
    "komisijski-centar/odobrenje/",
    views.komisijsko_odobrenje,
    name="komisijsko_odobrenje"
),

    path(
        "komisijski-centar/zaprimanje/",
        views.komisijsko_zaprimanje,
        name="komisijsko_zaprimanje"
    ),

    path(
        "komisijski-centar/historija/",
        views.komisijska_historija,
        name="komisijska_historija"
    ),
    path(
        "komisijski-centar/vanredni/",
        views.vanredni_zahtjevi,
        name="vanredni_zahtjevi",
    ),
    path(
        "komisijski-centar/vanredni/<int:zahtjev_id>/",
        views.vanredni_zahtjev_detalj,
        name="vanredni_zahtjev_detalj",
    ),
    path(
        "pacijent/<int:pacijent_id>/vanredni-zahtjev/",
        views.pokreni_vanredni_zahtjev,
        name="pokreni_vanredni_zahtjev",
    ),

    # Stari link ostaje radi kompatibilnosti
    path(
        "alarm-centar/",
        views.komisijski_centar,
        name="alarm_centar"
    ),

    path(
        "komisijski-centar/pacijent/<int:pacijent_id>/iskljucenje/",
        views.sacuvaj_komisijsko_iskljucenje,
        name="sacuvaj_komisijsko_iskljucenje",
    ),

    # Kalendar
    path(
        "kalendar/",
        views.kalendar_terapija,
        name="kalendar_terapija"
    ),
    path(
        "komisijski-centar/pacijent/<int:pacijent_id>/rucni-unos/",
        views.sacuvaj_komisijski_rucni_unos,
        name="sacuvaj_komisijski_rucni_unos",
    ),

    path(
        "terapijski-centar/",
        views.kalendar_terapija,
        name="terapijski_centar"
    ),

    # Liste
    path(
        "pacijenti/",
        views.lista_pacijenata,
        name="lista_pacijenata"
    ),

    path(
        "terapije/",
        views.lista_terapija,
        name="lista_terapija"
    ),
    path(
        "finansije/",
        views.finansije_pregled,
        name="finansije_pregled",
    ),
    path(
        "finansije/<int:terapija_id>/predaj/",
        views.predaj_terapiju_finansijama,
        name="predaj_terapiju_finansijama",
    ),
    path(
        "finansije/<int:terapija_id>/dokument/",
        views.print_finansijski_dokument,
        name="print_finansijski_dokument",
    ),

    path(
        "komisije/",
        views.lista_komisija,
        name="lista_komisija"
    ),

    path(
        "zalihe/",
        views.lista_zaliha,
        name="lista_zaliha"
    ),
    path(
        "zalihe/<int:lijek_id>/dodijeli-slobodne-doze/",
        views.dodijeli_slobodne_doze,
        name="dodijeli_slobodne_doze",
    ),
    path(
        "zalihe/rezervacije/<int:rezervacija_id>/oslobodi/",
        views.oslobodi_nevazecu_rezervaciju,
        name="oslobodi_nevazecu_rezervaciju",
    ),
    path(
        "zalihe/<int:lijek_id>/oslobodi-nevazece-rezervacije/",
        views.oslobodi_nevazece_rezervacije_lijeka,
        name="oslobodi_nevazece_rezervacije_lijeka",
    ),

    # Dnevne liste
    path(
        "danas/",
        views.lista_danas,
        name="lista_danas"
    ),

    path(
        "sutra/",
        views.lista_sutra,
        name="lista_sutra"
    ),

    # Nabavka
    path(
        "plan-nabavke/",
        views.plan_nabavke,
        name="plan_nabavke"
    ),

    # Dokumenti
    path(
        "dokumenti/",
        views.dokumenti_centar,
        name="dokumenti_centar"
    ),

    path(
        "dokumenti/sabloni/",
        views.upload_sabloni,
        name="upload_sabloni"
    ),

    path(
        "dokumenti/novi/",
        views.novi_dokument,
        name="novi_dokument"
    ),

    path(
        "dokumenti/<int:id>/pregled/",
        views.dokument_pregled,
        name="dokument_pregled"
    ),

    path(
        "dokumenti/<int:id>/preuzmi/",
        views.dokument_preuzmi,
        name="dokument_preuzmi"
    ),

    path(
        "dokumenti/<int:id>/arhiviraj/",
        views.dokument_arhiviraj,
        name="dokument_arhiviraj"
    ),

    # Profil pacijenta
    path(
        "pacijent/<int:pacijent_id>/",
        views.profil_pacijenta,
        name="profil_pacijenta"
    ),
    path(
        "pacijent/<int:pacijent_id>/napomena/",
        views.dodaj_napomenu_pacijenta,
        name="dodaj_napomenu_pacijenta",
    ),
    path(
        "pacijent/<int:pacijent_id>/saglasnost/",
        views.evidentiraj_saglasnost_pacijenta,
        name="evidentiraj_saglasnost_pacijenta",
    ),
    path(
        "pacijent/<int:pacijent_id>/promijeni-terapiju/",
        views.promijeni_terapiju,
        name="promijeni_terapiju"
    ),
    path(
        "pacijent/<int:pacijent_id>/protokol/uredi/",
        views.uredi_individualni_protokol,
        name="uredi_individualni_protokol",
    ),
    path(
        "pacijent/<int:pacijent_id>/protokol/ustekinumab/postavi/",
        views.postavi_ustekinumab_protokol,
        name="postavi_ustekinumab_protokol",
    ),
    path(
        "pacijent/<int:pacijent_id>/protokol/ustekinumab/zakazi/",
        views.zakazi_ustekinumab_fazu,
        name="zakazi_ustekinumab_fazu",
    ),
    path(
        "pacijent/<int:pacijent_id>/protokol/ustekinumab/interval/",
        views.promijeni_ustekinumab_interval,
        name="promijeni_ustekinumab_interval",
    ),
    path(
        "pacijent/<int:pacijent_id>/protokol/ustekinumab/kucna-terapija/",
        views.prebaci_ustekinumab_na_kucnu_terapiju,
        name="prebaci_ustekinumab_na_kucnu_terapiju",
    ),
    path(
        "pacijent/<int:pacijent_id>/protokol/ustekinumab/ambulantna-primjena/",
        views.vrati_ustekinumab_na_ambulantnu_primjenu,
        name="vrati_ustekinumab_na_ambulantnu_primjenu",
    ),

    # Potvrda dolaska
    path(
        "potvrdi-dolazak/<int:termin_id>/",
        views.potvrdi_dolazak,
        name="potvrdi_dolazak"
    ),
    path(
        "terapija/<int:terapija_id>/zavrseno/",
        views.terapija_zavrsena,
        name="terapija_zavrsena",
    ),

    # PDF dokumenti
    path(
        "print/sljedeca-terapija/<int:pacijent_id>/",
        views.print_sljedeca_terapija,
        name="print_sljedeca_terapija"
    ),

    path(
        "print/karton/<int:pacijent_id>/",
        views.print_karton,
        name="print_karton"
    ),

    path(
        "print/komisija/<int:pacijent_id>/",
        views.print_komisija,
        name="print_komisija"
    ),

    path(
        "print/razduzivanje/<int:pacijent_id>/",
        views.print_razduzivanje,
        name="print_razduzivanje"
    ),

    path(
        "print/plan-nabavke/",
        views.print_plan_nabavke,
        name="print_plan_nabavke"
    ),

    path(
        "pacijenti/novi/",
        views.novi_pacijent,
        name="novi_pacijent"
    ),
    path("termin/<int:termin_id>/status/", views.promijeni_status_termina, name="promijeni_status_termina"),
    path("pacijent/<int:pacijent_id>/pauza-terapije/", views.upravljaj_pauzom_terapije, name="upravljaj_pauzom_terapije"),
    path("terapija/<int:terapija_id>/ponisti/", views.ponisti_terapiju, name="ponisti_terapiju"),
      path(
        "pacijenti/migracija/",
        views.migracija_pacijenta,
        name="migracija_pacijenta"
      ),
      path(
        "pacijenti/migracija/provjeri-jmbg/",
        views.provjeri_jmbg_migracija,
        name="provjeri_jmbg_migracija",
      ),
    path(
        "pacijenti/migracija/uskladi-zalihu/",
        views.uskladi_migracijsku_zalihu,
        name="uskladi_migracijsku_zalihu",
    ),
    path(
        "pacijenti/migracija/zavrsi/",
        views.zavrsi_migraciju,
        name="zavrsi_migraciju"
    ),

    path(
        "termini/novi/",
        views.novi_termin,
        name="novi_termin"
    ),

    path(
        "pacijent/<int:pacijent_id>/novi-termin/",
        views.novi_termin,
        name="novi_termin_pacijent"
    ),

    path(
        "pacijent/<int:pacijent_id>/generisi-komisiju/",
        views.generisi_komisiju,
        name="generisi_komisiju"
    ),

    path(
        "pacijent/<int:pacijent_id>/kreiraj-komisiju/",
        views.kreiraj_komisiju,
        name="kreiraj_komisiju"
    ),

    path(
        "pacijent/<int:pacijent_id>/deaktiviraj/",
        views.deaktiviraj_pacijenta,
        name="deaktiviraj_pacijenta"
    ),

    path(
        "pacijent/<int:pacijent_id>/aktiviraj/",
        views.aktiviraj_pacijenta,
        name="aktiviraj_pacijenta"
    ),

    path(
        "trebovanje/",
        views.kreiraj_trebovanje,
        name="kreiraj_trebovanje"
    ),

    path(
        "pacijent/<int:pacijent_id>/izdaj-kucnu-terapiju/",
        views.izdaj_kucnu_terapiju,
        name="izdaj_kucnu_terapiju"
    ),
    path("pacijent/<int:pacijent_id>/provjera-kucne-terapije/", views.provjera_kucne_terapije, name="provjera_kucne_terapije"),

    path(
        "izdaj-kucnu-terapiju/<int:pacijent_id>/",
        views.izdaj_kucnu_terapiju,
        name="izdaj_kucnu_terapiju_alt"
    ),

    path(
        "pacijent/<int:pacijent_id>/oralna-terapija/",
        views.oralna_terapija,
        name="oralna_terapija",
    ),

    path(
        "oralno-izdavanje/<int:izdavanje_id>/ponisti/",
        views.ponisti_oralno_izdavanje,
        name="ponisti_oralno_izdavanje",
    ),

    path(
        "kucno-izdavanje/<int:izdavanje_id>/razduzenje/",
        views.print_razduzenje_izdavanja,
        name="print_razduzenje_izdavanja"
    ),

    path(
        "pacijent/<int:pacijent_id>/odobrena-komisija/",
        views.unesi_odobrenu_komisiju,
        name="unesi_odobrenu_komisiju"
    ),

    path(
        "pretraga/",
        views.pretraga_pacijenata,
        name="pretraga_pacijenata"
    ),

    path(
        "ajax/pretraga-pacijenata/",
        views.ajax_pretraga_pacijenata,
        name="ajax_pretraga_pacijenata"
    ),

    path(
        "brzi-unos/",
        views.brzi_unos,
        name="brzi_unos"
    ),

    path(
        "izvjestaji/",
        views.izvjestaji,
        name="izvjestaji"
    ),

    path(
        "audit-log/",
        views.audit_log,
        name="audit_log"
    ),

    path(
        "backup-baze/",
        views.backup_baze,
        name="backup_baze"
    ),
    path(
        "backup-baze/<str:filename>/preuzmi/",
        views.preuzmi_backup,
        name="preuzmi_backup"
    ),

    path(
        "restore-backup/",
        views.restore_backup,
        name="restore_backup"
    ),

    path(
        "premjesti-doze/<int:pacijent_id>/",
        views.premjesti_doze,
        name="premjesti_doze"
    ),

    path(
        "pacijent/<int:pacijent_id>/novo-trebovanje/",
        views.novo_trebovanje,
        name="novo_trebovanje"
    ),

    path(
        "trebovanje/<int:trebovanje_id>/status/<str:status>/",
        views.promijeni_status_trebovanja,
        name="promijeni_status_trebovanja"
    ),

    path(
        "pacijent/<int:pacijent_id>/zahtjev-zavodu/",
        views.print_zahtjev_zavodu,
        name="print_zahtjev_zavodu"
    ),

    path(
        "trebovanje/<int:trebovanje_id>/zahtjev-zavodu/",
        views.print_zahtjev_zavodu_trebovanje,
        name="print_zahtjev_zavodu_trebovanje"
    ),

    path(
       "komisijski-centar/simulacija/pacijent/<int:pacijent_id>/sacuvaj/",
       views.sacuvaj_simulaciju_trebovanja,
       name="sacuvaj_simulaciju_trebovanja"
    ),

    path(
    "komisijski-centar/simulacija/sacuvaj/",
    views.sacuvaj_cijelu_simulaciju,
    name="sacuvaj_cijelu_simulaciju"
),

path(
    "pacijent/<int:pacijent_id>/dodaj-u-simulaciju/",
    views.dodaj_u_simulaciju,
    name="dodaj_u_simulaciju"
),

path(
    "postavke/",
    views.postavke,
    name="postavke"
),

path(
    "postavke/korisnici/",
    views.korisnici_pristup,
    name="korisnici_pristup"
),

path(
    "postavke/korisnici/dodaj/",
    views.dodaj_korisnika,
    name="dodaj_korisnika"
),

path(
    "postavke/korisnici/<int:user_id>/uredi/",
    views.uredi_korisnika,
    name="uredi_korisnika"
),

path(
    "postavke/korisnici/<int:user_id>/reset-lozinke/",
    views.resetuj_lozinku_korisnika,
    name="resetuj_lozinku_korisnika"
),

path(
    "postavke/korisnici/<int:user_id>/status/",
    views.promijeni_status_korisnika,
    name="promijeni_status_korisnika"
),

path(
    "postavke/korisnici/<int:user_id>/odjavi-sesije/",
    views.odjavi_sve_sesije_korisnika,
    name="odjavi_sve_sesije_korisnika"
),

path(
    "postavke/promijeni-lozinku/",
    views.promijeni_vlastitu_lozinku,
    name="promijeni_vlastitu_lozinku"
),

path(
    "postavke-sistema/",
    views.postavke_sistema,
    name="postavke_sistema"
),

path(
    "postavke-sistema/servisni-centar/",
    views.servisni_centar,
    name="servisni_centar"
),

path(
    "postavke-sistema/adaptivni-asistent/",
    views.adaptive_assistant_view,
    name="adaptive_assistant",
),

path(
    "postavke-sistema/adaptivni-asistent/izvoz/",
    views.adaptive_assistant_export,
    name="adaptive_assistant_export",
),

path(
    "postavke-sistema/pdf-obrasci/",
    views.postavke_pdf_obrazaca,
    name="postavke_pdf_obrazaca"
),

path(
    "postavke-sistema/pdf-koordinate/",
    views.pdf_koordinate,
    name="pdf_koordinate"
),

path(
    "pdf-koordinate/preview/<str:obrazac>/",
    views.pdf_koordinate_preview,
    name="pdf_koordinate_preview"
),

path(
    "postavke-sistema/reset-test-data/",
    views.reset_test_data_view,
    name="reset_test_data"
),

path(
    "postavke-sistema/reset-testnih-zaliha/",
    views.reset_test_inventory_view,
    name="reset_test_inventory"
),

path(
    "postavke-sistema/rekalkulisi-zalihe/",
    views.rekalkulisi_zalihe_view,
    name="rekalkulisi_zalihe"
),

path(
    "postavke-sistema/generisi-demo-podatke/",
    views.generisi_demo_podatke_view,
    name="generisi_demo_podatke"
),

path(
    "postavke-sistema/provjera-integriteta/",
    views.provjera_integriteta_baze,
    name="provjera_integriteta_baze"
),

path(
    "komisijski-centar/odobrenje/oznaci-predato/",
    views.oznaci_trebovanja_predato,
    name="oznaci_trebovanja_predato"
),

path(
    "komisijski-centar/odobrenje/print-odabrane/",
    views.print_odabrane_zahtjeve,
    name="print_odabrane_zahtjeve"
),

path(
    "komisijski-centar/zaprimanje/<int:ciklus_id>/",
    views.zaprimanje_ciklusa,
    name="zaprimanje_ciklusa"
),
    
]
