"""Shared appointment membership for the calendar and the tomorrow home card."""
from patients.models import Lijek, Pacijent, Termin
from patients.querysets import with_workflow_data
from patients.scheduling import is_allowed_therapy_date, is_demo_weekend_calendar_date
from patients.legacy_appointment_tags import tagged_video_demo_appointment_ids


def calendar_appointments(start, end, *, status="", home=False, legacy_ids=None):
    appointments = Termin.objects.filter(datum__gte=start, datum__lte=end)
    if status:
        appointments = appointments.filter(status=status)
    appointments = list(
        appointments.select_related("pacijent", "lijek")
        .exclude(lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA)
        .order_by("datum", "vrijeme")
    )
    patients = {
        patient.pk: patient
        for patient in with_workflow_data(Pacijent.objects.filter(
            pk__in={item.pacijent_id for item in appointments}
        ))
    }
    if legacy_ids is None:
        # Preserve existing calendar visibility of historical tagged records.
        # This read-only compatibility path creates no appointments or demo data.
        legacy_ids = tagged_video_demo_appointment_ids(start_date=start, end_date=end)
    result = []
    for appointment in appointments:
        if appointment.pacijent_id in patients:
            appointment.pacijent = patients[appointment.pacijent_id]
        patient = appointment.pacijent
        allowed_date = (
            is_allowed_therapy_date(appointment.datum, lijek=appointment.lijek,
                                    protokol=patient.aktivni_protokol())
            or is_demo_weekend_calendar_date(appointment.datum)
            or appointment.pk in legacy_ids
        )
        if not allowed_date:
            continue
        correct_mode = (patient.trenutni_korak_je_kucna_terapija()
                        if home else patient.trenutni_korak_je_ambulanta())
        if correct_mode:
            result.append(appointment)
    return result
