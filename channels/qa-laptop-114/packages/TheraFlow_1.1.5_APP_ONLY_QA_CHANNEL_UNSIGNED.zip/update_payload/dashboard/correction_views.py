import logging
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core import signing
from django.core.exceptions import ValidationError
from django.db import DatabaseError
from django.http import HttpResponseForbidden, Http404
from django.shortcuts import get_object_or_404, redirect
from .correction_center_views import render_in_center as render
from django.urls import reverse
from django.views.decorators.http import require_http_methods
from django.views.decorators.cache import never_cache

from patients.models import Pacijent, PatientDataCorrection
from patients.data_corrections import CorrectionBlocked, make_preview_token, apply_signed_correction
from patients import data_corrections as service
from .correction_forms import CorrectionForm, SCOPES, target_choices
from .permissions import je_admin

logger = logging.getLogger(__name__)


@login_required
@require_http_methods(["GET", "POST"])
def correct_patient_data(request, pacijent_id):
    if not je_admin(request.user):
        return HttpResponseForbidden("Ispravke podataka dostupne su samo TheraFlow administratoru.")
    patient = get_object_or_404(Pacijent, pk=pacijent_id)
    scope = request.GET.get("scope", "profile")
    if scope not in SCOPES:
        scope = "profile"
    if scope == "profile":
        return correct_patient_profile(request, pacijent_id)
    if scope == "stock":
        if request.method == "POST":
            messages.warning(request, "Fizička zaliha ima zaseban postupak. Ponovo pregledajte ispravku prije knjiženja.")
        return redirect(reverse("ispravi_fizicku_zalihu") + (f"?lijek={patient.lijek_id}" if patient.lijek_id else ""))
    target_id = request.GET.get("target", "")
    try:
        target_id = int(target_id) if target_id else None
    except ValueError:
        target_id = None
    options = target_choices(patient, scope)
    needs_target = scope in {"reservation", "approval", "therapy", "oral_issue"}
    selected = target_id in {pk for pk, label in options}
    form = CorrectionForm(request.POST if request.method == "POST" and request.POST.get("action") != "confirm" else None,
                          patient=patient, scope=scope, target_id=target_id)
    plan = token = None
    if request.method == "POST":
        try:
            if request.POST.get("action") == "confirm":
                require_confirmation = request.POST.get("confirmed") == "yes"
                if not require_confirmation:
                    raise CorrectionBlocked("Potvrdite da ste pregledali stare i nove vrijednosti.")
                receipt, created = apply_signed_correction(request.POST.get("preview_token", ""), patient, request.user)
                messages.success(request, f"Ispravka je spremljena. Evidencija #{receipt.pk}." if created else
                                 f"Ova ispravka je već spremljena (#{receipt.pk}); nije ponovljena.")
                return redirect("ispravi_podatke_pacijenta", pacijent_id=patient.pk)
            elif request.POST.get("action") == "preview" and form.is_valid():
                if needs_target and not selected:
                    raise CorrectionBlocked("Prvo odaberite konkretnu rezervaciju, odobrenje ili radnju iz ovog kartona.")
                plan, token = make_preview_token(patient, scope, form, request.user, target_id=target_id)
        except (CorrectionBlocked, ValueError, ValidationError) as exc:
            form.cleaned_data = getattr(form, "cleaned_data", {})
            form.add_error(None, " ".join(exc.messages) if isinstance(exc, ValidationError) else str(exc))
        except DatabaseError:
            logger.exception("Korekcija nije potvrđena; patient_id=%s", patient.pk)
            form.cleaned_data = getattr(form, "cleaned_data", {})
            form.add_error(None, "Baza je zauzeta ili veza nije dostupna. Osvježite karton i pokušajte ponovo. Ako je odgovor prekinut pri spremanju, ponovite istu potvrdu: zaštita od ponavljanja sprečava dvostruki upis.")
    return render(request, "dashboard/ispravi_podatke.html", {
        "pacijent": patient, "scope": scope, "scope_label": SCOPES[scope], "scopes": SCOPES.items(),
        "target_id": target_id, "target_options": options, "needs_target": needs_target,
        "target_selected": selected, "form": form, "preview": plan, "preview_token": token,
        "corrections": PatientDataCorrection.objects.filter(pacijent=patient).select_related("korisnik")[:20],
    })


@login_required
@never_cache
@require_http_methods(["GET", "POST"])
def correct_patient_profile(request, pacijent_id):
    """Expose the existing profile correction, with the same record and audit service."""
    if not request.user.is_active or not je_admin(request.user):
        return HttpResponseForbidden("Ispravke osnovnih podataka dostupne su samo TheraFlow administratoru.")
    patient = get_object_or_404(Pacijent, pk=pacijent_id)
    from .correction_center_views import center_url
    center_home = center_url(patient=patient, medicine=patient.lijek)
    action = request.POST.get('action', '') if request.method == 'POST' else ''
    submitted = request.POST if action == 'preview' else None
    form = CorrectionForm(submitted, patient=patient, scope='profile')
    plan = token = saved = None
    if request.method == 'POST':
        try:
            if action in ('confirm', 'edit'):
                token = request.POST.get('preview_token', '')
                payload = signing.loads(token, salt=service.SALT, max_age=None if action == 'confirm' else 1800)
                service.require(payload.get('scope') == 'profile' and payload.get('patient_id') == patient.pk
                    and payload.get('user_id') == request.user.pk, 'Pregled ne pripada ovoj ispravci ili kartonu.')
                form = CorrectionForm({**payload['fields'], 'razlog': payload['reason']}, patient=patient, scope='profile')
                if action == 'edit':
                    token = None
                else:
                    service.require(request.POST.get('confirmed') == 'yes', 'Potvrdite da ste pregledali stare i nove vrijednosti.')
                    from patients.patient_profile import identification_changes
                    identity = identification_changes(patient, payload['fields'])
                    # Use the signed fields, never an editable hidden list of sensitive changes.
                    if identity and request.POST.get('identification_confirmed') != 'yes':
                        if form.is_valid():
                            plan = service.preview(patient, 'profile', form.cleaned_data)
                        form.add_error(None, 'Potvrdite provjeru identifikacijskih podataka prema dokumentaciji.')
                    else:
                        receipt, created = apply_signed_correction(token, patient, request.user)
                        messages.success(request, 'Osnovni podaci su sačuvani.' if created else 'Ova ispravka je već sačuvana; upis nije ponovljen.')
                        return redirect(reverse('patient_basic_data', args=[patient.pk]) + '?saved=' + str(receipt.pk))
            elif action == 'preview' and form.is_valid():
                plan, token = make_preview_token(patient, 'profile', form, request.user)
        except (CorrectionBlocked, ValueError, ValidationError, signing.BadSignature, KeyError) as exc:
            plan = token = None
            message = ('Pregled nije valjan ili je istekao. Ponovo pregledajte ispravku.'
                       if isinstance(exc, (signing.BadSignature, KeyError)) else
                       ' '.join(exc.messages) if isinstance(exc, ValidationError) else str(exc))
            form.cleaned_data = getattr(form, 'cleaned_data', {})
            form.add_error(None, message)
        except DatabaseError:
            plan = token = None
            logger.exception('Profile correction database failure; patient_id=%s', patient.pk)
            form.cleaned_data = getattr(form, 'cleaned_data', {})
            form.add_error(None, 'Ispravka nije potvrđena. Provjerite historiju i ponovite isti pregled; ista potvrda ne pravi drugi upis.')
    if request.GET.get('saved'):
        try:
            saved = get_object_or_404(PatientDataCorrection, pk=int(request.GET['saved']), pacijent=patient, scope='profile')
        except ValueError:
            raise Http404 from None
    if hasattr(request, 'correction_center'):
        request.correction_center['nurse_workflow'] = True
    return render(request, 'dashboard/patient_basic_data.html', {
        'patient': patient, 'pacijent': patient, 'medicine': patient.lijek, 'category': 'profile',
        'title': 'Osnovni podaci pacijenta', 'form': form, 'preview': plan, 'preview_token': token,
        'saved': saved, 'center_home': center_home, 'sidebar_active_section': 'retrospective',
        'corrections': PatientDataCorrection.objects.filter(pacijent=patient, scope='profile').select_related('korisnik')[:20],
    })
