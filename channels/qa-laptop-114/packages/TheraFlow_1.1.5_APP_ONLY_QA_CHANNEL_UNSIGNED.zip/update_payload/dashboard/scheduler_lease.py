import json
import hmac
import os
import re
import subprocess
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path


class SchedulerLeaseBusy(RuntimeError):
    pass


_MICROSOFT_JSON_DATE = re.compile(r"^/Date\(([-+]?\d+)(?:[-+]\d{4})?\)/$")
_UTC_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


def normalize_process_creation_utc_epoch_ms(value):
    """Return an integer UTC epoch-ms identity or None, without locale parsing."""

    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value) if value.is_integer() else None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.astimezone()
        delta = value.astimezone(timezone.utc) - _UTC_EPOCH
        return (
            delta.days * 86_400_000
            + delta.seconds * 1_000
            + delta.microseconds // 1_000
        )
    text = str(value).strip()
    if not text:
        return None
    match = _MICROSOFT_JSON_DATE.fullmatch(text)
    if match:
        try:
            return int(match.group(1))
        except ValueError:
            return None
    if re.fullmatch(r"[-+]?\d+", text):
        try:
            return int(text)
        except ValueError:
            return None
    if text.endswith(("Z", "z")):
        text = f"{text[:-1]}+00:00"
    elif not re.search(r"[-+]\d{2}:\d{2}$", text):
        return None
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return normalize_process_creation_utc_epoch_ms(parsed)


def _epoch_ms_iso(value):
    return (_UTC_EPOCH + timedelta(milliseconds=int(value))).isoformat().replace(
        "+00:00", "Z"
    )


def _canonical_windows_path(value):
    value = os.path.expandvars(str(value or "").strip().strip('"'))
    if not value:
        return ""
    return os.path.normcase(os.path.normpath(os.path.abspath(value)))


def _inspect_current_windows_process():
    """Read the current process identity without WMI/CIM permissions."""

    import ctypes
    from ctypes import wintypes

    creation = wintypes.FILETIME()
    exit_time = wintypes.FILETIME()
    kernel = wintypes.FILETIME()
    user = wintypes.FILETIME()
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.GetProcessTimes.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(wintypes.FILETIME),
        ctypes.POINTER(wintypes.FILETIME),
        ctypes.POINTER(wintypes.FILETIME),
        ctypes.POINTER(wintypes.FILETIME),
    ]
    kernel32.GetProcessTimes.restype = wintypes.BOOL
    handle = kernel32.GetCurrentProcess()
    if not kernel32.GetProcessTimes(
        handle,
        ctypes.byref(creation),
        ctypes.byref(exit_time),
        ctypes.byref(kernel),
        ctypes.byref(user),
    ):
        return None
    filetime = (int(creation.dwHighDateTime) << 32) | int(creation.dwLowDateTime)
    # FILETIME is 100-ns ticks since 1601-01-01 UTC.
    epoch_ms = (filetime - 116444736000000000) // 10_000
    kernel32.GetCommandLineW.restype = wintypes.LPWSTR
    command_line = str(kernel32.GetCommandLineW() or "").strip()
    if epoch_ms <= 0 or not command_line:
        return None
    return {
        "pid": os.getpid(),
        "executable": sys.executable,
        "command_line": command_line,
        "created_at_utc_epoch_ms": epoch_ms,
        "created_at": _epoch_ms_iso(epoch_ms),
    }


def inspect_process(pid, run=subprocess.run):
    pid = int(pid)
    if pid <= 0:
        return None
    if os.name == "nt":
        script = (
            f"$p=Get-CimInstance Win32_Process -Filter \"ProcessId={pid}\" "
            "-ErrorAction SilentlyContinue; if($null -eq $p){exit 3}; "
            "$p | Select-Object ProcessId,ExecutablePath,CommandLine,CreationDate "
            "| ConvertTo-Json -Compress"
        )
        result = run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True,
            text=True,
            check=False,
            shell=False,
            timeout=15,
        )
        if result.returncode != 0:
            return _inspect_current_windows_process() if pid == os.getpid() else None
        try:
            value = json.loads(result.stdout)
        except (TypeError, ValueError):
            return _inspect_current_windows_process() if pid == os.getpid() else None
        return {
            "pid": int(value.get("ProcessId") or pid),
            "executable": str(value.get("ExecutablePath") or ""),
            "command_line": str(value.get("CommandLine") or ""),
            "created_at": str(value.get("CreationDate") or ""),
        }
    if pid != os.getpid():
        try:
            os.kill(pid, 0)
        except OSError:
            return None
    return {
        "pid": pid,
        "executable": sys.executable,
        "command_line": " ".join([sys.executable, *sys.argv]),
        "created_at": str(int(Path(f"/proc/{pid}").stat().st_ctime_ns)) if Path(f"/proc/{pid}").exists() else "portable-current-process",
    }


def scheduler_identity_matches(owner, actual, expected_executable):
    if not isinstance(owner, dict) or not isinstance(actual, dict):
        return False, "recorded PID does not exist"
    if int(owner.get("pid") or 0) != int(actual.get("pid") or -1):
        return False, "PID mismatch"
    recorded_created = owner.get("process_created_at_utc_epoch_ms")
    if recorded_created is None:
        recorded_created = owner.get("process_created_at")
    recorded_epoch_ms = normalize_process_creation_utc_epoch_ms(recorded_created)
    actual_epoch_ms = normalize_process_creation_utc_epoch_ms(
        actual.get("created_at_utc_epoch_ms", actual.get("created_at"))
    )
    if (
        recorded_epoch_ms is None
        or actual_epoch_ms is None
        or abs(recorded_epoch_ms - actual_epoch_ms) > 1
    ):
        return False, "process creation identity mismatch (possible PID reuse)"
    executable = _canonical_windows_path(actual.get("executable"))
    expected = _canonical_windows_path(expected_executable)
    if not executable or executable != expected:
        return False, "process executable is not canonical private Python"
    command = str(actual.get("command_line") or "").replace("/", "\\").lower()
    if "manage.py" not in command or "run_backup_scheduler" not in command:
        return False, "process command line is not the backup scheduler command"
    if not owner.get("instance_token"):
        return False, "recorded instance token is missing"
    return True, "full scheduler process identity matched"


class SchedulerProcessLease:
    def __init__(self, path, expected_executable=None, inspector=inspect_process):
        self.path = Path(path).resolve()
        self.expected_executable = str(expected_executable or sys.executable)
        self.inspector = inspector
        self.token = uuid.uuid4().hex
        self.acquired = False
        self.identity = None

    def _payload(self):
        identity = self.inspector(os.getpid())
        if not identity:
            raise RuntimeError("Trenutni scheduler process identity nije dostupna.")
        created_epoch_ms = normalize_process_creation_utc_epoch_ms(
            identity.get("created_at_utc_epoch_ms", identity.get("created_at"))
        )
        if created_epoch_ms is None:
            raise RuntimeError("Vrijeme kreiranja scheduler procesa nije validno.")
        identity = {
            **identity,
            "created_at_utc_epoch_ms": created_epoch_ms,
            "created_at_utc_iso": _epoch_ms_iso(created_epoch_ms),
        }
        return {
            "pid": os.getpid(),
            "instance_token": self.token,
            "process_created_at_utc_epoch_ms": created_epoch_ms,
            "process_created_at_utc_iso": identity["created_at_utc_iso"],
            "executable": str(identity.get("executable") or ""),
            "command_line": str(identity.get("command_line") or ""),
            "lease_created_at": datetime.now(timezone.utc).isoformat(),
            "format_version": 3,
        }, identity

    def _create(self, payload):
        descriptor = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())

    def acquire(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload, identity = self._payload()
        for _attempt in range(4):
            try:
                self._create(payload)
            except FileExistsError as exc:
                try:
                    owner = json.loads(self.path.read_text(encoding="utf-8"))
                except (OSError, ValueError, TypeError):
                    owner = {}
                actual = self.inspector(int(owner.get("pid") or 0))
                active, reason = scheduler_identity_matches(owner, actual, self.expected_executable)
                if active:
                    raise SchedulerLeaseBusy(reason) from exc
                quarantine = self.path.with_name(f"{self.path.name}.stale.{uuid.uuid4().hex}")
                try:
                    os.replace(self.path, quarantine)
                except FileNotFoundError:
                    continue
                quarantine.unlink(missing_ok=True)
                continue
            self.acquired = True
            self.identity = identity
            return identity
        raise SchedulerLeaseBusy("Scheduler lease se nije mogao atomski preuzeti.")

    def touch(self):
        if self.acquired and self.path.is_file():
            os.utime(self.path, None)

    def release(self):
        try:
            owner = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            owner = {}
        owner_token = str(owner.get("instance_token") or "")
        if self.acquired and owner_token and hmac.compare_digest(owner_token, self.token):
            self.path.unlink(missing_ok=True)
        self.acquired = False
