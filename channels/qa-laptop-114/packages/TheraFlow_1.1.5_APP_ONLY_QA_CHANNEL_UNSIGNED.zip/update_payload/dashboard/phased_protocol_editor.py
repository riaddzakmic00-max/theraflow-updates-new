"""Edit the authoritative phase prescription through the existing review gate."""
from django import forms
from django.core.exceptions import ValidationError
from django.db import transaction
from django.shortcuts import render, redirect
from django.urls import reverse
from django.http import Http404
from django.contrib import messages

from .forms import UstekinumabProtocolSetupForm
from .card_change_review import preview_card_change
from patients.phased_protocols import configure_ustekinumab_protocol, protocol_state_snapshot
from patients.phase_schedule import reconcile_phase_schedule


class PhasedPrescriptionForm(UstekinumabProtocolSetupForm):
    razlog_izmjene = forms.CharField(label='Razlog izmjene', widget=forms.Textarea(attrs={'rows': 3}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name in ('kreiraj_komisijski_prijedlog', 'komisijski_ciklus', 'vrsta_zahtjeva',
                     'ukljuci_prvu_sc', 'prethodni_lijek'):
            self.fields.pop(name)


def edit_phased_protocol(request, patient):
    state = patient.aktivni_fazni_protokol()
    focus = request.GET.get('focus') or request.POST.get('edit_focus')
    step = request.GET.get('protocol_step') or request.POST.get('protocol_step')
    if focus and focus not in ('dose','interval') or step and step not in ('iv','first_sc','maintenance'):
        raise Http404('Nepoznat korak protokola.')
    if focus:
        step = step or ('iv' if focus == 'dose' and state.faza == state.FAZA_CEKA_IV else 'maintenance')
        if step == 'maintenance' and (state.faza != state.FAZA_CEKA_IV or focus == 'dose'):
            url = reverse('brza_izmjena_pacijenta',args=[patient.pk,focus])
            return redirect(url+('?protocol_step=maintenance' if state.faza != state.FAZA_CEKA_IV else ''))
        if step == 'iv' and focus == 'interval':
            return redirect(reverse('uredi_individualni_protokol',args=[patient.pk])+'?focus=interval&protocol_step=maintenance')
    read_only = step == 'first_sc' or (step == 'iv' and state.faza != state.FAZA_CEKA_IV)
    form = PhasedPrescriptionForm(request.POST or None, patient=patient, state=state)
    focused_field = None
    if focus and not read_only:
        focused_field = 'pocetna_iv_doza_mg' if focus == 'dose' else 'interval_odrzavanja_sedmica'
        for name, field in form.fields.items():
            if name not in (focused_field,'razlog_izmjene'):
                field.disabled = True
                field.widget = forms.HiddenInput()
        form.fields[focused_field].widget.attrs['autofocus'] = True
    next_url = reverse('brza_izmjena_pacijenta',args=[patient.pk,focus or 'interval'])+'?protocol_step=maintenance'
    if read_only:
        return render(request,'dashboard/uredi_fazni_protokol.html',dict(pacijent=patient,form=form,
            focus=focus,step=step,read_only=True,phase_label=state.get_faza_display(),next_url=next_url))
    if request.method == 'POST' and form.is_valid():
        data = form.cleaned_data
        plan = dict(kind='phase_protocol', phase_schedule=True, reason=data['razlog_izmjene'],
            after={'doza_mg': str(data.get('pocetna_iv_doza_mg'))}, rows=[
                dict(label='Faza protokola', before=state.get_faza_display(), after=dict(state.FAZE)[data['faza']]),
                dict(label='Propisana IV doza (mg)', before=state.indukcijska_doza_mg, after=data.get('pocetna_iv_doza_mg')),
                dict(label='IV prezentacija', before=str(state.iv_lijek), after=str(data['iv_lijek'])),
                dict(label='SC prezentacija', before=str(state.sc_lijek), after=str(data['sc_lijek'])),
                dict(label='Interval održavanja', before=state.interval_odrzavanja_sedmica, after=data['interval_odrzavanja_sedmica'])],
            impacts=['Budući termini i komisijske potrebe koriste propisanu dozu i prezentaciju odgovarajuće faze.',
                     'Postojeće IV i SC rezervacije i historija ostaju sačuvani.'])
        try:
            review = preview_card_change(request, patient, plan)
            if review is not None:
                return review
            with transaction.atomic():
                previous = protocol_state_snapshot(state)
                state = configure_ustekinumab_protocol(patient=patient, iv_medicine=data['iv_lijek'],
                    sc_medicine=data['sc_lijek'], phase=data['faza'],
                    maintenance_interval=data['interval_odrzavanja_sedmica'], user=request.user,
                    prescribed_iv_dose_mg=data.get('pocetna_iv_doza_mg'),
                    last_actual_date=data.get('datum_zadnje_stvarne_doze'))
                reconcile_phase_schedule(state=state, previous=previous, user=request.user,
                    planned_date=data.get('planirani_datum'), planned_time=data.get('planirano_vrijeme'),
                    reason=data['razlog_izmjene'])
            messages.success(request, 'Fazni protokol pacijenta je sačuvan i auditiran.')
            return redirect('profil_pacijenta', pacijent_id=patient.pk)
        except (ValidationError, ValueError) as exc:
            form.add_error(None, exc)
    return render(request, 'dashboard/uredi_fazni_protokol.html', dict(pacijent=patient, form=form,
        focus=focus,step=step,phase_label=state.get_faza_display(),focused_field=focused_field))
