"""Presentation and optimistic concurrency guard for the existing receipt flow."""
import hashlib
import json
from decimal import Decimal
from uuid import UUID

from django.core import signing
from django.db.models import Q

from patients.models import ZalihaTransakcija, UnlinkedStockReceipt

UNALLOCATED_LIMITATION = (
    "Zaseban prijem neraspoređene pošiljke i njena naknadna raspodjela nisu "
    "podržani ovim komisijskim tokom. Dopunite saglasnost ili raspodjelu prije "
    "potvrde; ne umanjujte stvarno prebrojanu količinu da biste nastavili."
)


def receipt_product_name(medicine):
    """Short label retaining documented SKU strength and route/form."""
    import re
    brand = str(medicine.brand_name or medicine.naziv or '').strip()
    generic = str(medicine.genericki_naziv or '').strip()
    if generic:
        brand = re.sub(r'\s*\(' + re.escape(generic) + r'\)\s*', ' ', brand,
                       flags=re.IGNORECASE).strip()
    strength = str(medicine.strength or medicine.presentation_strength_label or '').strip()
    # Legacy names sometimes already contain the strength and route.
    # Retain them rather than duplicating the same recorded presentation.
    def normalized(value):
        return re.sub(r'\s+', '', value).casefold()
    parts = [brand]
    if strength and normalized(strength) not in normalized(brand):
        parts.append(strength)
    route = str(medicine.put_primjene or '').strip()
    label = ' '.join(parts)
    if route and not re.search(r'(?<!\w)' + re.escape(route) + r'(?!\w)', label, re.I):
        label += ' ' + route
    recorded_form = str(medicine.pharmaceutical_form or '').strip()
    is_tablet = (medicine.farmaceutski_oblik == medicine.OBLIK_TABLETA
                 or re.search(r'\btable(?:ta|te)\b', recorded_form, re.I))
    # Full pharmaceutical descriptions remain in Details. The documented route
    # and visible receiving unit distinguish IV/SC products in the main row.
    form = 'tablete' if is_tablet else recorded_form if not route else ''
    if form and normalized(form) not in normalized(label):
        label += ' — ' + form
    return label


def receipt_cycle_label(cycle):
    """Display a useful cycle name without changing its stored identity."""
    name = (cycle.naziv or '').strip()
    generated_name = False
    if name.upper().startswith('KC-'):
        try:
            UUID(name[3:])
        except ValueError:
            pass
        else:
            generated_name = True
    if name and not generated_name:
        return name
    day = cycle.datum_komisije or cycle.datum_predaje
    if day:
        kind = 'Vanredna' if cycle.tip_ciklusa == 'VANREDNI' else 'Redovna'
        return f'{kind} komisija · {day:%d/%m/%Y}'
    return f'Komisija #{cycle.pk}'


def receipt_revision(cycle):
    rows = list(cycle.trebovanja.order_by('pk').values(
        'id', 'pacijent_id', 'lijek_id', 'komisija_id', 'status',
        'broj_doza', 'odobrene_doze', 'zaprimljene_doze',
    ))
    from patients.commission_receiving import received_commission_quantity
    # A link can consume remaining physical capacity without changing a legacy
    # request counter. It must therefore invalidate an already opened form.
    links = list(UnlinkedStockReceipt.objects.filter(request__komisijski_ciklus=cycle)
                 .order_by('pk').values('id', 'request_id', 'movement_id', 'quantity'))
    linked_requests = {row['request_id'] for row in links}
    capacity = [(request.pk, received_commission_quantity(request)) for request in
                cycle.trebovanja.filter(pk__in=linked_requests).order_by('pk')]
    state = {'cycle': cycle.pk, 'status': cycle.status,
             'approval': cycle.datum_odobrenja, 'requests': rows,
             'administrative_links': links, 'received_capacity': capacity}
    state['receipts'] = list(ZalihaTransakcija.objects.filter(komisijski_ciklus=cycle)
        .order_by('pk').values('id', 'tip', 'kolicina', 'promjena_salda', 'shipment_reference',
                              'operation_id', 'serija', 'rok_trajanja', 'datum'))
    from patients.models import PatientDataCorrection
    state['receipt_metadata'] = list(PatientDataCorrection.objects.filter(
        scope='inventory_receipt_metadata', izvorna_transakcija__komisijski_ciklus=cycle)
        .order_by('pk').values('id', 'izvorna_transakcija_id', 'posljedice'))
    return hashlib.sha256(json.dumps(state, sort_keys=True, default=str).encode()).hexdigest()


def receipt_token(cycle):
    return signing.dumps({'cycle': cycle.pk, 'revision': receipt_revision(cycle)}, salt='shipment-receipt')


def validate_receipt_token(cycle, token):
    try:
        data = signing.loads(token or '', salt='shipment-receipt', max_age=86400)
    except signing.BadSignature as exc:
        raise ValueError('Obrazac je istekao ili nije potpun. Ponovo otvorite pošiljku prije potvrde.') from exc
    if data != {'cycle': cycle.pk, 'revision': receipt_revision(cycle)}:
        raise ValueError('Stanje pošiljke je promijenjeno ili je prijem već zaprimljen u ovom ciklusu. '
                         'Ništa nije ponovo zaprimljeno. Osvježite stranicu i provjerite ranije zaprimljeno.')


def receipt_document_exists(medicine, reference):
    """Global exact-SKU document guard, including older receiving registries.

    Explicit physical/unlinked document keys remain reserved in their preserved
    history. A reversed retrospective label is reusable only after all its
    concrete receipt sources were fully cancelled, never merely consumed.
    """
    from patients.models import RetrospectiveEvent
    from patients.inventory_corrections import receipt_quantity

    medicine_id = getattr(medicine, 'pk', medicine)
    reference = str(reference or '').strip()
    if medicine_id is None or not reference:
        return False
    if ZalihaTransakcija.objects.filter(lijek_id=medicine_id,
            tip=ZalihaTransakcija.TIP_ZAPRIMANJE, shipment_reference__iexact=reference).exists():
        return True
    if UnlinkedStockReceipt.objects.filter(medicine_id=medicine_id,
            delivery_reference__iexact=reference).exists():
        return True
    from patients.models import PatientDataCorrection
    audits = PatientDataCorrection.objects.filter(scope='inventory_receipt_metadata',
        posljedice__metadata_after__reference__iexact=reference).values_list(
            'izvorna_transakcija__lijek_id', 'posljedice')
    # JSON containment is unavailable on the supported SQLite test backend.
    # Membership is a saved, server-built list of concrete source SKU IDs.
    if any(source_medicine_id == medicine_id or medicine_id in
           (plan.get('document_medicine_ids') or []) for source_medicine_id, plan in audits):
        return True
    if RetrospectiveEvent.objects.filter(medicine_id=medicine_id, kind='receipt',
            delivery_reference__iexact=reference, reversed_at__isnull=True).exists():
        return True
    sources = list(ZalihaTransakcija.objects.filter(lijek_id=medicine_id,
        tip=ZalihaTransakcija.TIP_ZAPRIMANJE,
        retrospective_events__kind='receipt', retrospective_events__delivery_reference__iexact=reference,
        ).distinct().order_by('pk')[:201])
    if len(sources) > 200:
        # An incomplete cancellation proof must not advertise document reuse.
        return True
    return any(not quantity.is_finite() or quantity != 0
               for quantity in (receipt_quantity(source) for source in sources))


def shipment_metadata(post, medicine_ids, receipt_date):
    """Document identity is per physical delivery, separate from lot identity."""
    from datetime import date
    reference = ' '.join(post.get('shipment_reference', '').strip().upper().split())
    if len(reference) > 100:
        raise ValueError('Oznaka isporuke/otpremnice može imati najviše 100 znakova.')
    lots, series = {}, {}
    for medicine_id in medicine_ids:
        batch = post.get(f'serija_lijek_{medicine_id}', '').strip()
        raw = post.get(f'rok_lijek_{medicine_id}', '').strip()
        try:
            expiry = date.fromisoformat(raw) if raw else None
        except ValueError:
            raise ValueError('Unesite ispravan rok trajanja serije.') from None
        from django.utils import timezone
        if len(batch) > 100 or expiry and expiry < max(receipt_date, timezone.localdate()):
            raise ValueError('Provjerite seriju i rok: rok ne smije prethoditi fizičkom prijemu.')
        lots[str(medicine_id)] = {'batch': batch, 'expires': raw}
        rows = posted_lot_rows(post, medicine_id)
        if any(name.startswith(f'lot_quantity_{medicine_id}_') and
               (not name.removeprefix(f'lot_quantity_{medicine_id}_').isdigit() or
                len(name.removeprefix(f'lot_quantity_{medicine_id}_')) > 2 or
                int(name.removeprefix(f'lot_quantity_{medicine_id}_')) > 19) for name in post):
            raise ValueError('Najviše 20 serija može se zaprimiti jednom potvrdom.')
        if len(rows) > 1 or any(row['quantity'].strip() for row in rows):
            from patients.models import Lijek
            from patients.package_sizes import validate_package_multiple
            medicine = Lijek.objects.filter(pk=medicine_id).first()
            if medicine is None:
                raise ValueError('Odabrani lijek ne pripada ovoj komisiji.')
            parsed, identities = [], set()
            for row in rows:
                quantity = positive_quantity(row['quantity'], 'Količina serije')
                validate_package_multiple(quantity, medicine, label='Količina serije')
                try:
                    expires = date.fromisoformat(row['expires']) if row['expires'] else None
                except ValueError:
                    raise ValueError('Unesite ispravan rok trajanja svake serije.') from None
                if (len(row['batch']) > 100 or expires and
                    expires < max(receipt_date, timezone.localdate())):
                    raise ValueError('Provjerite seriju i rok: rok ne smije prethoditi fizičkom prijemu.')
                identity = (row['batch'], row['expires'])
                if identity in identities:
                    raise ValueError('Ista serija i rok su uneseni više puta. Objedinite količine te serije.')
                identities.add(identity)
                parsed.append({'quantity': str(quantity), 'batch': row['batch'], 'expires': row['expires']})
            counted = positive_quantity(post.get(f'zaprimljeno_lijek_{medicine_id}'), 'Stiglo sada')
            if sum((Decimal(row['quantity']) for row in parsed), Decimal(0)) != counted:
                raise ValueError('Zbir količina svih serija mora odgovarati ukupnoj količini „Stiglo sada“.')
            series[str(medicine_id)] = parsed
    result = {'reference': reference, 'date': receipt_date.isoformat(), 'lots': lots}
    if series:
        result['series'] = series
    free_exceptions = []
    for name, value in post.items():
        if not name.startswith('free_receipt_exception_') or not value:
            continue
        medicine_id = name.removeprefix('free_receipt_exception_')
        if (value != 'yes' or not medicine_id.isdigit()
                or int(medicine_id) not in medicine_ids):
            raise ValueError('Izuzetak fizičkog prijema ne pripada odabranoj pošiljci.')
        free_exceptions.append(medicine_id)
    if free_exceptions:
        # The chosen physical-only mode is part of the signed preview. Reasons
        # can be entered afterwards, without changing quantities or provenance.
        result['free_exceptions'] = sorted(set(free_exceptions), key=int)
    return result


def posted_lot_rows(post, medicine_id):
    """Retain the single-series fields and read additional documented series."""
    prefix = f'lot_quantity_{medicine_id}_'
    indexes = {0}
    for name in post:
        if name.startswith(prefix):
            suffix = name.removeprefix(prefix)
            if suffix.isdigit() and len(suffix) <= 2 and int(suffix) <= 19:
                indexes.add(int(suffix))
    return [{'index': index, 'quantity': str(post.get(prefix + str(index), '')),
             'batch': str(post.get(f'serija_lijek_{medicine_id}' + (f'_{index}' if index else ''), '')).strip(),
             'expires': str(post.get(f'rok_lijek_{medicine_id}' + (f'_{index}' if index else ''), '')).strip()}
            for index in sorted(indexes)]


def shipment_lots(metadata, medicine_id, quantity):
    rows = metadata.get('series', {}).get(str(medicine_id))
    return rows or [dict(metadata['lots'][str(medicine_id)], quantity=str(quantity))]


def apply_receipt_free_mode(proposal, metadata):
    """Sign an explicit all-free conflict review, without granting an approval."""
    for medicine_id in metadata.get('free_exceptions', []):
        group = proposal['medicines'].get(str(medicine_id))
        if not group or not group.get('physical_exception_required') or group.get('warning'):
            raise ValueError('Kontrolisani slobodni prijem nije dozvoljen za ovu stavku. Provjerite odobrenje i izvore.')
        group.update(allocated='0', remainder=group['arrived'], free_exception_selected=True)
        for request_id in group.get('request_ids', group.get('physical_exception_request_ids', [])):
            row = proposal['rows'].get(str(request_id))
            if row:
                row.update(proposed='0', lot_proposed={}, series=[])
    return proposal


def full_shipment_reference(movement):
    """Every series of one atomic receipt shares its operation/document identity."""
    from patients.inventory_corrections import receipt_metadata
    effective = receipt_metadata(movement)['reference']
    if effective:
        return effective
    if movement.shipment_reference or not movement.operation_id:
        return movement.shipment_reference
    return (ZalihaTransakcija.objects.filter(operation_id=movement.operation_id,
            lijek_id=movement.lijek_id, komisijski_ciklus_id=movement.komisijski_ciklus_id,
            tip='ZAPRIMANJE').exclude(shipment_reference='')
            .values_list('shipment_reference', flat=True).first() or '')


def physically_complete(cycle, requests=None):
    """Close physical delivery independently of how much was allocated to patients."""
    from patients.commission_exclusions import visible_commission_requests
    rows = list(requests if requests is not None else visible_commission_requests(
        cycle.trebovanja.all()).select_related('lijek'))
    products = {}
    for row in rows:
        if row.status not in ('ODBIJENO', 'OTKAZANO') and row.odobrene_doze is not None and row.odobrene_doze > 0:
            products.setdefault(row.lijek_id, []).append(row)
    if not products:
        return False
    for group in products.values():
        totals = receipt_totals(cycle, group[0].lijek, group)
        if totals['history_incomplete'] or totals['remaining_physical'] > 0:
            return False
    return True


def proposal_token(cycle, proposal, metadata):
    return signing.dumps({'cycle': cycle.pk, 'revision': receipt_revision(cycle),
        'proposal': proposal, 'metadata': metadata}, salt='receipt-proposal', compress=True)


def validate_proposal_token(cycle, token, proposal, metadata):
    try:
        data = signing.loads(token or '', salt='receipt-proposal', max_age=3600)
    except signing.BadSignature:
        raise ValueError('Prvo kliknite „Prikaži kome ide lijek“ i pregledajte prijedlog.') from None
    if data != {'cycle': cycle.pk, 'revision': receipt_revision(cycle),
                'proposal': proposal, 'metadata': metadata}:
        raise ValueError('Količina, isporuka, potrebe ili zalihe su promijenjene. Ponovo prikažite kome ide lijek prije potvrde.')


def positive_quantity(raw, label):
    try:
        value = Decimal(str(raw).replace(',', '.'))
    except (ArithmeticError, ValueError, TypeError):
        raise ValueError(f'{label}: unesite ispravnu količinu.')
    if not value.is_finite() or value <= 0:
        raise ValueError(f'{label}: količina mora biti veća od nule.')
    return value


def receipt_totals(cycle, medicine, requests):
    """Physical receipts from explicit sources, without grouping presentations.

    Legacy request counters remain visible; a disagreement is an explicit
    limitation, never silently treated as zero physical receipts.
    """
    ids = [r.pk for r in requests]
    transactions = ZalihaTransakcija.objects.filter(
        Q(komisijski_ciklus=cycle) |
        Q(referenca_tip='KomisijskiCiklus', referenca_id=cycle.pk) |
        Q(referenca_tip='Trebovanje', referenca_id__in=ids) |
        Q(unlinkedstockreceipt__request_id__in=ids),
        lijek=medicine, tip=ZalihaTransakcija.TIP_ZAPRIMANJE,
    ).distinct()
    from patients.inventory_corrections import receipt_quantity
    physical = sum((receipt_quantity(tx) for tx in transactions), Decimal('0'))
    allocated = sum((r.zaprimljene_doze or Decimal('0') for r in requests), Decimal('0'))
    expected = sum((r.odobrene_doze or Decimal('0') for r in requests
                    if r.status not in ('ODBIJENO', 'OTKAZANO')), Decimal('0'))
    return {'expected': expected, 'allocated_before': allocated, 'physical_before': physical,
            'history_incomplete': physical < allocated,
            'unallocated_before': max(physical - allocated, Decimal('0')),
            'remaining_physical': max(expected - max(physical, allocated), Decimal('0'))}
