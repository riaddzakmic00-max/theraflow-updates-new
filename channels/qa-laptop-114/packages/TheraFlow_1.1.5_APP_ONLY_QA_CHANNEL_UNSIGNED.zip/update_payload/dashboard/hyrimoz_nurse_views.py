from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET

from patients.hyrimoz_nurse_list import build_hyrimoz_nurse_list
from .permissions import je_terapijski_tim


@login_required
@never_cache
@require_GET
def hyrimoz_nurse_list(request):
    if not je_terapijski_tim(request.user):
        raise PermissionDenied("Lista je dostupna terapijskom timu.")
    report = build_hyrimoz_nurse_list()
    if request.GET.get("format") == "pdf":
        from .hyrimoz_nurse_pdf import render_hyrimoz_pdf
        response = HttpResponse(render_hyrimoz_pdf(report), content_type="application/pdf")
        response["Content-Disposition"] = 'inline; filename="TheraFlow_Hyrimoz_lista.pdf"'
        return response
    return render(request, "dashboard/hyrimoz_nurse_list.html", report)
