from __future__ import annotations

from collections import OrderedDict
from copy import deepcopy
from datetime import date
from decimal import Decimal
from html import escape
from pathlib import Path
import shutil
import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone
from PyPDF2 import PdfReader, PdfWriter
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import LongTable, Paragraph, SimpleDocTemplate, Spacer, TableStyle
from theraflow.pdf_templates import load_pdf_template

from patients.models import (
    KomisijskaSaglasnost,
    KomisijskaStavkaLijeka,
    KomisijskiCiklus,
    KomisijskiZahtjev,
    PostavkeSistema,
    PromjenaTerapije,
)
from patients.commission_request_types import (
    PURPOSE_REQUIRES_CONFIRMATION,
    canonical_from_legacy,
    configured_legacy_categories,
    document_package_for,
    request_document_snapshot,
)
from patients.transaction_locking import select_for_update_self
from patients.utils import upisi_log
from patients.medicine_document_metadata import (
    MedicineMetadataError, is_active_document, presentation_metadata, validate_metadata,
)

from .pdf_coordinates import get_pdf_coords, get_request_pdf_coords, get_commission_request_pdf_coords
from .commission_print_archive import (
    archive_file_metadata, resolve_archive_file, resolve_request_archive, write_request_archive,
)
from .pdf_overlay import (
    PDF_FONT_BOLD,
    PDF_FONT_FALLBACK,
    merge_pdf_overlay_page,
    register_pdf_fonts,
    commission_template_typography,
)


PRINT_SCHEMA_VERSION = "commission-phase2-v4"
OFFICIAL_PRINT_SCHEMAS = frozenset({"commission-phase2-v3", PRINT_SCHEMA_VERSION})

CATEGORY_SPECS = OrderedDict(
    (
        spec.legacy_request_type,
        {
            "short_label": spec.short_label,
            "label": spec.label,
            "heading": spec.heading,
            "filename": spec.filename,
            "package_key": spec.key,
            "template_name": spec.template_name,
        },
    )
    for spec in configured_legacy_categories()
)

# Redoslijed tražen za zbirni službeni spisak.
SUMMARY_CATEGORY_ORDER = (
    KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_PRODUZENJE,
    KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_NOVI,
    KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_ODJAVA,
    KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH,
    KomisijskiZahtjev.VrstaZahtjeva.HEPATITIS_B_PRODUZENJE,
)

UNIT_SHORT_LABELS = {
    KomisijskaStavkaLijeka.Jedinica.FLAKON: "flak.",
    KomisijskaStavkaLijeka.Jedinica.TABLETA: "tbl",
    KomisijskaStavkaLijeka.Jedinica.PEN: "pen",
    KomisijskaStavkaLijeka.Jedinica.PAKOVANJE: "pak.",
}

MONTH_NAMES_BS = (
    "",
    "januar",
    "februar",
    "mart",
    "april",
    "maj",
    "juni",
    "juli",
    "august",
    "septembar",
    "oktobar",
    "novembar",
    "decembar",
)

WORKFLOW_STATUS_LABELS = {
    "nacrt": "Nacrt",
    "spremno_za_stampu": "Spremno za štampu",
    "odstampano": "Odštampano",
    "poslano_komisiji": "Poslano komisiji",
    "ceka_saglasnosti": "Čeka saglasnosti",
    "djelimicno_zaprimljene_saglasnosti": (
        "Djelimično zaprimljene saglasnosti"
    ),
    "zavrseno": "Završeno",
}


def cycle_display_title(cycle):
    """Korisnički naslov ciklusa, odvojen od internog KOM identifikatora."""

    month = cycle.mjesec
    year = cycle.godina
    if cycle.datum_komisije:
        month = month or cycle.datum_komisije.month
        year = year or cycle.datum_komisije.year
    if month and year and 1 <= month <= 12:
        return f"Komisija – {MONTH_NAMES_BS[month]} {year}."
    return cycle.naziv


def cycle_workflow_status(cycle, requests=None):
    """Mapira legacy logističke statuse na novi komisijski UI bez izmjene baze."""

    requests = list(requests if requests is not None else cycle.zahtjevi_faza1.all())
    if not requests:
        return {"key": "nacrt", "label": WORKFLOW_STATUS_LABELS["nacrt"]}
    if cycle.status in WORKFLOW_STATUS_LABELS:
        return {"key": cycle.status, "label": WORKFLOW_STATUS_LABELS[cycle.status]}

    request_statuses = {item.status for item in requests}
    if request_statuses == {KomisijskiZahtjev.Status.ODLUCENO}:
        key = "zavrseno"
    elif KomisijskiZahtjev.Status.CEKA_SAGLASNOST in request_statuses:
        key = "ceka_saglasnosti"
    elif (
        KomisijskiZahtjev.Status.POSLAN in request_statuses
        or cycle.status == "PREDATO"
    ):
        key = "poslano_komisiji"
    else:
        # SIMULACIJA i fizički statusi ODOBRENO/ČEKA_ISPORUKU/ZAPRIMLJENO
        # ne smiju procuriti u status komisijskog dokumentacijskog workflowa.
        key = "nacrt"
    return {"key": key, "label": WORKFLOW_STATUS_LABELS[key]}


def request_unit_for_medicine(medicine):
    """Odredi jedinicu iz konfigurisanih jedinica lijeka, ne iz njegovog naziva."""

    unit_text = " ".join(
        (
            medicine.jedinica_terapije or "",
            medicine.jedinica_terapije_mnozina or "",
            medicine.jedinica_zalihe or "",
            medicine.jedinica_zalihe_mnozina or "",
        )
    ).lower()
    if "tablet" in unit_text:
        return KomisijskaStavkaLijeka.Jedinica.TABLETA
    if "pen" in unit_text:
        return KomisijskaStavkaLijeka.Jedinica.PEN
    if "boč" in unit_text or "boc" in unit_text or "flakon" in unit_text:
        return KomisijskaStavkaLijeka.Jedinica.FLAKON
    return KomisijskaStavkaLijeka.Jedinica.PAKOVANJE


def legacy_request_type_from_planning(planning):
    """Kompatibilni tip samo za stare klijente koji još ne šalju novo polje."""

    if planning and planning.get("novi_pacijent_workflow"):
        return KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_NOVI
    return KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_PRODUZENJE


def apply_manual_request_type_decision(
    commission_request,
    *,
    legacy_request_type,
    reason,
    user,
):
    """Apply an authorized correction and immediately refresh document needs."""

    valid_types = {value for value, _label in KomisijskiZahtjev.VrstaZahtjeva.choices}
    if legacy_request_type not in valid_types:
        raise ValidationError("Odaberite ispravnu vrstu komisijskog zahtjeva.")
    changed = legacy_request_type != commission_request.vrsta_zahtjeva
    reason = (reason or "").strip()
    if changed and not reason:
        raise ValidationError("Razlog izmjene vrste zahtjeva je obavezan.")
    program_type, purpose = canonical_from_legacy(legacy_request_type)
    package = document_package_for(program_type, purpose)
    if not package.configured:
        raise ValidationError("Nedostaje predložak dokumentacije za odabranu vrstu zahtjeva.")

    commission_request.vrsta_zahtjeva = legacy_request_type
    commission_request.program_type = program_type
    commission_request.request_purpose = purpose
    commission_request.final_user_decision = purpose
    commission_request.request_type_override_reason = reason if changed else (
        commission_request.request_type_override_reason
    )
    commission_request.request_type_finalized_by = user
    commission_request.request_type_finalized_at = timezone.now()
    if purpose == "SWITCH" and not commission_request.source_therapy_change_id:
        current_program_id = (
            commission_request.pacijent.terapijski_program_id
            or getattr(
                getattr(commission_request.pacijent, "lijek", None),
                "terapijski_program_id",
                None,
            )
        )
        if current_program_id:
            change = (
                PromjenaTerapije.objects.filter(
                    pacijent=commission_request.pacijent,
                    novi_lijek__terapijski_program_id=current_program_id,
                )
                .exclude(stari_lijek__terapijski_program_id=current_program_id)
                .order_by("-datum_odluke", "-pk")
                .first()
            )
            if change:
                commission_request.source_therapy_change = change
    snapshot = request_document_snapshot(program_type, purpose)
    commission_request.document_package_key = snapshot["package_key"]
    commission_request.document_requirements_snapshot = snapshot
    return changed


@transaction.atomic
def sync_commission_request_from_planning(
    *,
    cycle,
    patient,
    medicine,
    request_type,
    system_quantity,
    doctor_quantity,
    user=None,
    note="",
    classification=None,
    request_type_override_reason="",
):
    """Idempotentno prenesi finalnu ljekarsku odluku u Phase 2 zahtjev."""

    ensure_commission_inclusion(patient, cycle)
    valid_types = {value for value, _label in KomisijskiZahtjev.VrstaZahtjeva.choices}
    if request_type not in valid_types:
        raise ValidationError("Odaberite ispravnu vrstu komisijskog zahtjeva.")

    final_program_type, final_purpose = canonical_from_legacy(request_type)
    if not final_program_type or not final_purpose:
        raise ValidationError("Odabrana vrsta nema canonical konfiguraciju.")
    package = document_package_for(final_program_type, final_purpose)
    if not package.configured:
        raise ValidationError("Nedostaje predložak dokumentacije za odabranu vrstu zahtjeva.")

    suggested_purpose = final_purpose
    reason_code = "LEGACY_EXPLICIT_SELECTION"
    reason_text = "Vrsta je potvrđena kroz kompatibilni komisijski workflow."
    source_change_id = None
    if classification is not None:
        suggested_purpose = classification.request_purpose
        reason_code = classification.reason_code
        reason_text = classification.reason
        source_change_id = classification.source_therapy_change_id
        changed = (
            classification.requires_confirmation
            or classification.program_type != final_program_type
            or classification.request_purpose != final_purpose
        )
        if changed and not (request_type_override_reason or "").strip():
            raise ValidationError(
                "Razlog je obavezan kada korisnik potvrđuje ili mijenja vrstu zahtjeva."
            )

    system_quantity = Decimal(str(system_quantity or 0))
    doctor_quantity = Decimal(str(doctor_quantity or 0))
    if system_quantity < 0 or doctor_quantity < 0:
        raise ValidationError("Komisijske količine ne mogu biti negativne.")
    if (
        doctor_quantity == 0
        and request_type != KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_ODJAVA
    ):
        raise ValidationError("Količina 0 dozvoljena je samo za odjavu.")

    previous_medicine = None
    new_medicine = medicine
    old_remainder = None
    if request_type == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH:
        change_query = PromjenaTerapije.objects.filter(pacijent=patient)
        if source_change_id:
            change_query = change_query.filter(pk=source_change_id)
        change = (
            change_query
            .select_related("stari_lijek", "novi_lijek")
            .order_by("-datum_odluke", "-pk")
            .first()
        )
        if change is None:
            raise ValidationError(
                "Za switch zahtjev prvo evidentirajte prethodni i novi lijek "
                "kroz postojeću promjenu terapije."
            )
        previous_medicine = change.stari_lijek
        new_medicine = change.novi_lijek
        old_remainder = change.preostale_doze
        medicine = change.novi_lijek
        source_change_id = change.pk

    existing = KomisijskiZahtjev.objects.filter(
        komisijski_ciklus=cycle,
        pacijent=patient,
    ).first()
    if existing and existing.status in {
        KomisijskiZahtjev.Status.POSLAN,
        KomisijskiZahtjev.Status.CEKA_SAGLASNOST,
        KomisijskiZahtjev.Status.ODLUCENO,
    }:
        raise ValidationError(
            "Historijski/finalizirani komisijski zahtjev se ne može retroaktivno prekvalifikovati."
        )

    document_snapshot = request_document_snapshot(final_program_type, final_purpose)

    commission_request, created = KomisijskiZahtjev.objects.update_or_create(
        komisijski_ciklus=cycle,
        pacijent=patient,
        defaults={
            "vrsta_zahtjeva": request_type,
            "program_type": final_program_type,
            "request_purpose": final_purpose,
            "system_suggested_purpose": suggested_purpose,
            "classification_reason_code": reason_code,
            "classification_reason": reason_text,
            "source_therapy_change_id": source_change_id,
            "final_user_decision": final_purpose,
            "request_type_override_reason": (
                request_type_override_reason or ""
            ).strip(),
            "request_type_finalized_by": user,
            "request_type_finalized_at": timezone.now(),
            "document_package_key": document_snapshot["package_key"],
            "document_requirements_snapshot": document_snapshot,
            "status": KomisijskiZahtjev.Status.POTVRDJEN,
            "sistem_predlozio": system_quantity,
            "ljekar_trazi": doctor_quantity,
            "finalna_kolicina": doctor_quantity,
            "prethodni_lijek": previous_medicine,
            "novi_lijek": new_medicine,
            "preostala_kolicina_prethodnog_lijeka": old_remainder,
            "napomena": note,
            "razlog_odjave": (
                note
                if request_type == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_ODJAVA
                else ""
            ),
            "potvrdio_korisnik": user,
            "print_snapshot": {},
            "print_snapshot_at": None,
        },
    )

    # Trenutni planning red predstavlja jednu eksplicitnu stavku. Ponovna
    # potvrda zamjenjuje taj snapshot umjesto da akumulira duplikate.
    commission_request.stavke_lijeka.all().delete()
    KomisijskaStavkaLijeka.objects.create(
        komisijski_zahtjev=commission_request,
        lijek=medicine,
        genericki_naziv=medicine.generic_name,
        zasticeni_naziv=medicine.brand_name,
        jacina="",
        oblik=medicine.jedinice_terapije[0],
        kolicina=doctor_quantity,
        jedinica=request_unit_for_medicine(medicine),
        redoslijed=1,
    )

    upisi_log(
        user,
        (
            "Kreiran komisijski zahtjev iz planiranja"
            if created
            else "Ažuriran komisijski zahtjev iz planiranja"
        ),
        pacijent=patient,
        objekat=commission_request,
        opis=(
            f"{cycle.naziv}; {commission_request.get_vrsta_zahtjeva_display()}; "
            f"sistem svrha={suggested_purpose}; konačno svrha={final_purpose}; "
            f"razlog izmjene={request_type_override_reason or '-'}; "
            f"sistem {system_quantity}; ljekar {doctor_quantity}."
        ),
    )
    return commission_request, created


def normalize_agreement_quantities(commission_request, decision, quantities):
    """Validiraj i normalizuj odobrenje po svakoj stavci zahtjeva."""

    valid_decisions = {
        value for value, _label in KomisijskaSaglasnost.Odluka.choices
    }
    if decision not in valid_decisions:
        raise ValidationError("Odaberite odluku komisije.")

    items = list(commission_request.stavke_lijeka.order_by("redoslijed", "pk"))
    if not items:
        raise ValidationError("Zahtjev nema stavke lijeka za odobrenje.")

    normalized = {}
    for item in items:
        raw_value = quantities.get(item.pk, quantities.get(str(item.pk)))
        if decision == KomisijskaSaglasnost.Odluka.ODBIJENO:
            value = Decimal("0")
        elif decision == KomisijskaSaglasnost.Odluka.ODOBRENO:
            value = Decimal(str(item.kolicina))
        else:
            if raw_value in (None, ""):
                raise ValidationError(
                    "Unesite odobrenu količinu za svaku stavku lijeka."
                )
            try:
                value = Decimal(str(raw_value))
            except Exception as exc:
                raise ValidationError("Odobrena količina mora biti broj.") from exc

        requested = Decimal(str(item.kolicina))
        if not value.is_finite():
            raise ValidationError("Odobrena količina mora biti konačan broj.")
        if value < 0:
            raise ValidationError("Odobrena količina ne može biti negativna.")
        if value > requested:
            raise ValidationError(
                "Odobrena količina ne može biti veća od tražene količine."
            )
        normalized[item.pk] = value

    if (
        decision == KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO
        and all(
            normalized[item.pk] == Decimal(str(item.kolicina))
            for item in items
        )
    ):
        raise ValidationError(
            "Kod djelimičnog odobrenja najmanje jedna količina mora biti "
            "manja od tražene."
        )
    return normalized


def agreement_progress(cycle):
    eligible = visible_commission_requests(cycle.zahtjevi_faza1.all()).exclude(status=KomisijskiZahtjev.Status.NACRT)
    total = eligible.count()
    agreements = KomisijskaSaglasnost.objects.filter(
        komisijski_zahtjev__in=eligible
    )
    entered = agreements.count()
    approved = agreements.filter(
        odluka=KomisijskaSaglasnost.Odluka.ODOBRENO
    ).count()
    partial = agreements.filter(
        odluka=KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO
    ).count()
    rejected = agreements.filter(
        odluka=KomisijskaSaglasnost.Odluka.ODBIJENO
    ).count()
    if total and entered == total:
        status_key = "zavrseno"
        status_label = "Saglasnosti zaprimljene"
    elif entered:
        status_key = "djelimicno_zaprimljene_saglasnosti"
        status_label = "Djelimično zaprimljene saglasnosti"
    else:
        status_key = "ceka_saglasnosti"
        status_label = "Čeka saglasnosti"
    return {
        "total": total,
        "entered": entered,
        "waiting": max(total - entered, 0),
        "approved": approved,
        "partial": partial,
        "rejected": rejected,
        "status_key": status_key,
        "status_label": status_label,
    }


@transaction.atomic
def save_commission_agreement(
    *,
    commission_request,
    agreement_number,
    agreement_date,
    decision,
    approved_quantities,
    note="",
    user=None,
    shared_document=None,
):
    """Sačuvaj odluku bez ikakve promjene fizičkog ili terapijskog stanja."""

    ensure_commission_inclusion(commission_request.pacijent, commission_request.komisijski_ciklus)

    commission_request = (
        select_for_update_self(
            KomisijskiZahtjev.objects.select_related(
                "komisijski_ciklus", "pacijent"
            )
        )
        .get(pk=commission_request.pk)
    )
    items = list(
        commission_request.stavke_lijeka.select_for_update().order_by(
            "redoslijed", "pk"
        )
    )
    normalized = normalize_agreement_quantities(
        commission_request,
        decision,
        approved_quantities,
    )
    agreement_number = (agreement_number or "").strip() or None
    documented_blank = False
    if shared_document is not None:
        from patients.models import KomisijskiDokumentOdluke
        document = KomisijskiDokumentOdluke.objects.filter(
            pk=getattr(shared_document, 'pk', None),
            komisijski_ciklus_id=commission_request.komisijski_ciklus_id,
            kreirao_id=getattr(user, 'pk', None), datum_dokumenta=agreement_date,
        ).first()
        if not document or document.broj_dokumenta != (agreement_number or ''):
            raise ValidationError('Dokument odluke ne odgovara ovom ciklusu, korisniku, datumu ili broju.')
        documented_blank = not document.broj_dokumenta
    if decision in {
        KomisijskaSaglasnost.Odluka.ODOBRENO,
        KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
    } and not agreement_number and not documented_blank:
        raise ValidationError("Broj saglasnosti je obavezan za ovu odluku.")
    if not agreement_date:
        raise ValidationError("Datum saglasnosti je obavezan.")

    previous_agreement = getattr(commission_request, "saglasnost", None)
    previous = {
        "broj": previous_agreement.broj_saglasnosti if previous_agreement else None,
        "datum": (
            previous_agreement.datum_saglasnosti.isoformat()
            if previous_agreement else None
        ),
        "odluka": previous_agreement.odluka if previous_agreement else None,
        "napomena": previous_agreement.napomena if previous_agreement else "",
        "kolicine": {
            str(item.pk): (
                str(item.odobrena_kolicina)
                if item.odobrena_kolicina is not None else None
            )
            for item in items
        },
    }

    agreement, created = KomisijskaSaglasnost.objects.update_or_create(
        komisijski_zahtjev=commission_request,
        defaults={
            "broj_saglasnosti": agreement_number,
            "datum_saglasnosti": agreement_date,
            "odluka": decision,
            "napomena": note,
        },
    )
    for item in items:
        item.odobrena_kolicina = normalized[item.pk]
        item.save(update_fields=("odobrena_kolicina",))

    commission_request.status = KomisijskiZahtjev.Status.ODLUCENO
    commission_request.save(update_fields=("status",))

    progress = agreement_progress(commission_request.komisijski_ciklus)
    cycle = commission_request.komisijski_ciklus
    if cycle.status != progress["status_key"]:
        cycle.status = progress["status_key"]
        cycle.save(update_fields=("status", "updated_at"))

    current = {
        "broj": agreement.broj_saglasnosti,
        "datum": agreement.datum_saglasnosti.isoformat(),
        "odluka": agreement.odluka,
        "napomena": agreement.napomena,
        "kolicine": {
            str(item.pk): str(normalized[item.pk]) for item in items
        },
    }
    upisi_log(
        user,
        (
            "Unesena komisijska saglasnost"
            if created
            else "Izmijenjena komisijska saglasnost"
        ),
        pacijent=commission_request.pacijent,
        objekat=agreement,
        opis=f"Prije: {previous}; poslije: {current}.",
    )
    return agreement, created, progress


def format_quantity(value):
    if value is None:
        return "-"
    number = Decimal(str(value))
    if number == number.to_integral_value():
        return str(int(number))
    return format(number.normalize(), "f")


from patients.commission_exclusions import visible_commission_requests, ensure_commission_inclusion


def cycle_requests(cycle):
    return list(
        visible_commission_requests(KomisijskiZahtjev.objects.filter(komisijski_ciklus=cycle))
        .select_related(
            "pacijent",
            "pacijent__lijek",
            "prethodni_lijek",
            "novi_lijek",
        )
        .prefetch_related("stavke_lijeka", "stavke_lijeka__lijek")
        .order_by("pacijent__prezime", "pacijent__ime", "id")
    )


def _medicine_name(medicine):
    if not medicine:
        return ""
    return medicine.zasticeno_ime or medicine.naziv


def _medicine_generic_name(medicine):
    if not medicine:
        return ""
    return medicine.genericki_naziv or medicine.naziv


def request_items(request):
    return list(request.stavke_lijeka.all())


def requested_quantity(request):
    if request.finalna_kolicina is not None:
        return request.finalna_kolicina
    if request.ljekar_trazi is not None:
        return request.ljekar_trazi
    items = request_items(request)
    if items:
        return sum((item.kolicina for item in items), Decimal("0"))
    return None


def request_medicine(request):
    items = request_items(request)
    if items:
        return items[0].lijek
    return request.novi_lijek or request.pacijent.lijek


def _item_line(item, *, summary=False):
    quantity = format_quantity(item.kolicina)
    unit = UNIT_SHORT_LABELS.get(item.jedinica, item.jedinica)
    if item.jacina:
        separator = " - " if summary else " × "
        return f"{quantity} {unit}{separator}{item.jacina}"
    return f"{quantity} {unit}"


def request_row(request):
    items = request_items(request)
    medicine = request_medicine(request)
    medicine_label = _medicine_name(medicine) or "Nije određen"
    if request.vrsta_zahtjeva == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH:
        old_name = _medicine_name(request.prethodni_lijek) or "Nije određen"
        new_name = _medicine_name(request.novi_lijek) or medicine_label
        medicine_label = f"{old_name} → {new_name}"

    item_lines = [_item_line(item) for item in items]
    if not item_lines and requested_quantity(request) is not None:
        item_lines = [format_quantity(requested_quantity(request))]

    return {
        "request": request,
        "medicine_label": medicine_label,
        "item_lines": item_lines,
        "system_quantity": format_quantity(request.sistem_predlozio),
        "doctor_quantity": format_quantity(request.ljekar_trazi),
        "final_quantity": format_quantity(requested_quantity(request)),
    }


def grouped_cycle_requests(cycle, selected_category=None):
    requests = cycle_requests(cycle)
    grouped = {key: [] for key in CATEGORY_SPECS}
    for item in requests:
        if item.vrsta_zahtjeva in grouped:
            grouped[item.vrsta_zahtjeva].append(item)

    if selected_category not in CATEGORY_SPECS:
        selected_category = next(
            (key for key, values in grouped.items() if values),
            next(iter(CATEGORY_SPECS)),
        )

    categories = []
    for key, spec in CATEGORY_SPECS.items():
        categories.append(
            {
                "key": key,
                **spec,
                "count": len(grouped[key]),
                "active": key == selected_category,
            }
        )
    return {
        "requests": requests,
        "grouped": grouped,
        "categories": categories,
        "selected_category": selected_category,
        "selected_rows": [request_row(item) for item in grouped[selected_category]],
    }


def validate_request_for_print(request):
    if not is_active_document(request):
        return [] if resolve_request_archive(request) else [
            "Historijski zahtjev nema dostupnu originalnu kopiju; dokument se ne izrađuje ponovo."]
    errors = []
    try:
        ensure_commission_inclusion(request.pacijent, request.komisijski_ciklus)
    except ValidationError as exc:
        errors.extend(exc.messages)
    patient = request.pacijent
    items = request_items(request)
    quantity = requested_quantity(request)
    medicine = request_medicine(request)
    if is_active_document(request):
        for product in [item.lijek for item in items] or [medicine]:
            try:
                presentation_metadata(product)
            except MedicineMetadataError as exc:
                errors.append(exc.user_message)
    package = document_package_for(request.program_type, request.request_purpose)

    if not package.configured:
        errors.append("nedostaje predložak dokumentacije za canonical vrstu zahtjeva")
    elif package.legacy_request_type != request.vrsta_zahtjeva:
        errors.append("vrsta zahtjeva i paket dokumentacije nisu usklađeni")

    if not (patient.ime or "").strip():
        errors.append("nedostaje ime")
    if not (patient.prezime or "").strip():
        errors.append("nedostaje prezime")
    if not (patient.jmbg or "").strip():
        errors.append("nedostaje JMBG")
    if not ((patient.mkb_sifra or "").strip() or (patient.dijagnoza or "").strip()):
        errors.append("nedostaje dijagnoza / MKB")
    if not medicine:
        errors.append("nije određen lijek")
    if quantity is None:
        errors.append("nije određena količina")
    elif (
        request.vrsta_zahtjeva
        != KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_ODJAVA
        and Decimal(str(quantity)) <= 0
    ):
        errors.append("tražena količina mora biti veća od 0")
    if len(items) > 3:
        errors.append("službeni obrazac podržava najviše 3 stavke lijeka")
    if request.vrsta_zahtjeva == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH:
        if not request.prethodni_lijek_id:
            errors.append("switch nema prethodni lijek")
        if not request.novi_lijek_id:
            errors.append("switch nema novi lijek")
    return errors


def cycle_print_scope(cycle):
    requests = cycle_requests(cycle)
    active = [item for item in requests if is_active_document(item)]
    return active or [item for item in requests if resolve_request_archive(item)]


def cycle_summary_available(cycle):
    requests = cycle_print_scope(cycle)
    return bool(requests) and (any(is_active_document(item) for item in requests)
                              or _archived_cycle_documents(requests)['path'] is not None)


def validate_cycle_for_print(cycle, requests=None):
    errors = []
    for request in (cycle_print_scope(cycle) if requests is None else requests):
        messages = validate_request_for_print(request)
        if messages:
            errors.append(
                {
                    "request": request,
                    "patient": f"{request.pacijent.ime} {request.pacijent.prezime}".strip()
                    or f"Zahtjev #{request.pk}",
                    "messages": messages,
                    "message": ", ".join(messages),
                }
            )
    return errors


def _settings_snapshot():
    try:
        system = PostavkeSistema.objects.filter(pk=1).first()
    except Exception:
        system = None
    return {
        "institution": (
            (system.zdravstvena_ustanova if system else "")
            or getattr(settings, "PDF_ZDRAVSTVENA_USTANOVA", "")
            or "JU Opća bolnica prim.dr. Abdulah Nakaš"
        ),
        "specialist": (
            (system.podnosilac_zahtjeva if system else "")
            or getattr(settings, "PDF_SPECIJALISTA", "")
            or ""
        ),
        "chair": (system.default_predsjednik_konzilija if system else "") or "",
        "member_1": (system.default_clan_konzilija_1 if system else "") or "",
        "member_2": (system.default_clan_konzilija_2 if system else "") or "",
    }


def capture_print_snapshot(request, *, captured_at=None):
    if request.print_snapshot:
        if not is_active_document(request):
            return request.print_snapshot
        # Refresh only document metadata in active snapshots. Patient details,
        # quantities, units and existing item rows remain untouched.
        from patients.models import Lijek
        payload = deepcopy(request.print_snapshot)
        products = Lijek.objects.in_bulk(item.get("medicine_id") for item in payload["items"])
        for item in payload["items"]:
            product = products.get(item.get("medicine_id"))
            if product is None:
                validate_metadata(item.get("brand_name") or "Neodređen lijek", {})
            item.update(presentation_metadata(product))
        payload["schema_version"] = PRINT_SCHEMA_VERSION
        if payload != request.print_snapshot:
            request.print_snapshot = payload
            request.save(update_fields=("print_snapshot",))
        return payload

    if not is_active_document(request):
        raise MedicineMetadataError("Historijski zahtjev nema sačuvan snimak za štampu. Otvorite izvorni arhivirani dokument.")

    captured_at = captured_at or timezone.now()
    patient = request.pacijent
    items = request_items(request)
    if not items:
        medicine = request_medicine(request)
        quantity = requested_quantity(request)
        items_payload = [
            {
                "medicine_id": getattr(medicine, "pk", None),
                "generic_name": _medicine_generic_name(medicine),
                "brand_name": _medicine_name(medicine),
                **presentation_metadata(medicine),
                "quantity": format_quantity(quantity),
                "unit": "",
                "order": 1,
            }
        ]
    else:
        items_payload = [
            {
                "medicine_id": item.lijek_id,
                "generic_name": item.genericki_naziv or _medicine_generic_name(item.lijek),
                "brand_name": item.zasticeni_naziv or _medicine_name(item.lijek),
                **presentation_metadata(item.lijek),
                "quantity": format_quantity(item.kolicina),
                "unit": UNIT_SHORT_LABELS.get(item.jedinica, item.jedinica),
                "order": item.redoslijed,
            }
            for item in items
        ]

    payload = {
        "schema_version": PRINT_SCHEMA_VERSION,
        "captured_at": captured_at.isoformat(),
        "request_id": request.pk,
        "cycle_id": request.komisijski_ciklus_id,
        "category": request.vrsta_zahtjeva,
        "program_type": request.program_type,
        "request_purpose": request.request_purpose,
        "system_suggested_purpose": request.system_suggested_purpose,
        "classification_reason_code": request.classification_reason_code,
        "classification_reason": request.classification_reason,
        "source_therapy_change_id": request.source_therapy_change_id,
        "final_user_decision": request.final_user_decision,
        "document_package": request.document_requirements_snapshot,
        "patient": {
            "id": patient.pk,
            "first_name": patient.ime,
            "last_name": patient.prezime,
            "jmbg": patient.jmbg,
            "sex": patient.spol,
            "birth_date": patient.datum_rodenja.isoformat() if patient.datum_rodenja else "",
            "address": patient.adresa,
            "canton": patient.kanton,
            "mkb": patient.mkb_sifra,
            "diagnosis": patient.dijagnoza,
        },
        "previous_medicine": _medicine_name(request.prethodni_lijek),
        "new_medicine": _medicine_name(request.novi_lijek),
        "old_medicine_remaining": format_quantity(
            request.preostala_kolicina_prethodnog_lijeka
        ),
        "deregistration_reason": request.razlog_odjave,
        "note": request.napomena,
        "requested_quantity": format_quantity(requested_quantity(request)),
        "items": items_payload,
        "form": _settings_snapshot(),
    }
    request.print_snapshot = payload
    request.print_snapshot_at = captured_at
    request.save(update_fields=("print_snapshot", "print_snapshot_at"))
    return payload


def clear_print_snapshot(request):
    request.print_snapshot = {}
    request.print_snapshot_at = None


def _official_form_values(snapshot, generated_at):
    patient = snapshot["patient"]
    form = snapshot["form"]
    items = snapshot["items"]
    category = snapshot["category"]
    old_name = snapshot.get("previous_medicine", "")
    new_name = snapshot.get("new_medicine", "")

    if category == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH:
        header = f"PROMJENA: {old_name} -> {new_name}"
    elif category == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_ODJAVA:
        header = f"ODJAVA: {items[0]['brand_name'] if items else new_name}"
    else:
        header = ", ".join(
            dict.fromkeys(item.get("brand_name", "") for item in items if item.get("brand_name"))
        )

    values = {
        "lijek_header": header,
        "ustanova": form.get("institution", ""),
        "ustanova_linija": "",
        "ljekar": form.get("specialist", ""),
        "datum": (date.fromisoformat(snapshot["captured_at"][:10])
                  if snapshot.get("captured_at") else generated_at.date()).strftime("%d/%m/%Y"),
        "jmbg": patient.get("jmbg", ""),
        "ime_prezime": (
            f"{patient.get('last_name', '').upper()} {patient.get('first_name', '').upper()}"
        ).strip(),
        "spol": patient.get("sex", ""),
        "datum_rodjenja": (
            date.fromisoformat(patient["birth_date"]).strftime("%d/%m/%Y")
            if patient.get("birth_date") else ""
        ),
        "adresa": patient.get("address", ""),
        "kanton": patient.get("canton", ""),
        "mkb_sifra": patient.get("mkb", ""),
        "dijagnoza": patient.get("diagnosis", ""),
        "hitnost_normalno": "X",
        "doza": "",
        "predsjednik_konzilija": form.get("chair", ""),
        "clan_konzilija_1": form.get("member_1", ""),
        "clan_konzilija_2": form.get("member_2", ""),
        "napomena": "",
    }

    for index in range(1, 4):
        suffix = "" if index == 1 else f"_{index}"
        item = items[index - 1] if index <= len(items) else {}
        values[f"lijek_genericki{suffix}"] = item.get("generic_name", "")
        values[f"lijek{suffix}"] = item.get("brand_name", "")
        values[f"atc{suffix}"] = item.get("atc_code", "")
        values[f"oblik{suffix}"] = item.get("form", "")
        values[f"jacina{suffix}"] = item.get("strength", "")
        quantity = item.get("quantity", "")
        unit = item.get("unit", "")
        values[f"broj_trazenih_doza{suffix}"] = f"{quantity} {unit}".strip()
    return values


def render_category_pdf(snapshots, output_path, *, generated_at=None):
    for snapshot in snapshots:
        if snapshot.get("schema_version") in OFFICIAL_PRINT_SCHEMAS:
            if len(snapshot["items"]) > 3:
                raise MedicineMetadataError("Službeni obrazac podržava najviše 3 stavke lijeka.")
            for item in snapshot["items"]:
                validate_metadata(item.get("brand_name", "Neodređen lijek"), {
                    "atc_code": item.get("atc_code"), "pharmaceutical_form": item.get("form"),
                    "strength": item.get("strength"),
                })
    generated_at = generated_at or timezone.now()
    template_name = (snapshots[0].get("document_package") or {}).get(
        "template_name"
    )
    load_pdf_template(template_name)

    writer = PdfWriter()
    for snapshot in snapshots:
        coords = (get_request_pdf_coords() if snapshot.get("schema_version") in OFFICIAL_PRINT_SCHEMAS
                  else get_pdf_coords("zahtjev_zavod"))
        page = load_pdf_template(template_name).pages[0]
        if snapshot.get('schema_version') == PRINT_SCHEMA_VERSION:
            coords = get_commission_request_pdf_coords()
            page = commission_template_typography(page)
        merge_pdf_overlay_page(
            page,
            coords,
            _official_form_values(snapshot, generated_at),
            debug=getattr(settings, "PDF_DEBUG", False),
        )
        # Each request owns a fresh template/overlay reader. PyPDF2 keys its
        # clone cache by reader id, which Python may reuse after collection.
        # Start a new mapping per page; already copied pages remain intact.
        writer.reset_translation()
        writer.add_page(page)
    with Path(output_path).open("wb") as stream:
        writer.write(stream)
    return Path(output_path)


def _summary_item_lines(snapshot):
    return [
        " ".join(
            part
            for part in (
                item.get("quantity", ""),
                item.get("unit", ""),
                f"- {item.get('strength', '')}" if item.get("strength") else "",
            )
            if part
        )
        for item in snapshot["items"]
    ]


def _summary_therapy(snapshot):
    if snapshot["category"] == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH:
        return f"{snapshot.get('previous_medicine', '')} -> {snapshot.get('new_medicine', '')}"
    names = []
    for item in snapshot["items"]:
        brand = item.get("brand_name", "")
        generic = item.get("generic_name", "")
        label = brand
        if generic and generic.casefold() != brand.casefold():
            label = f"{brand} ({generic})"
        if label and label not in names:
            names.append(label)
    return "\n".join(names)


def render_summary_pdf(cycle, snapshots, output_path, *, generated_at=None):
    generated_at = generated_at or timezone.now()
    register_pdf_fonts()
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "CommissionTitle",
        parent=styles["Title"],
        fontName=PDF_FONT_BOLD,
        fontSize=16,
        leading=20,
        alignment=TA_CENTER,
        spaceAfter=4 * mm,
    )
    meta_style = ParagraphStyle(
        "CommissionMeta",
        parent=styles["Normal"],
        fontName=PDF_FONT_FALLBACK,
        fontSize=8,
        leading=11,
        alignment=TA_CENTER,
        textColor=colors.HexColor("#4b5563"),
        spaceAfter=5 * mm,
    )
    heading_style = ParagraphStyle(
        "CommissionHeading",
        parent=styles["Heading2"],
        fontName=PDF_FONT_BOLD,
        fontSize=11,
        leading=14,
        textColor=colors.HexColor("#17365d"),
        spaceBefore=3 * mm,
        spaceAfter=2 * mm,
    )
    cell_style = ParagraphStyle(
        "CommissionCell",
        parent=styles["Normal"],
        fontName=PDF_FONT_FALLBACK,
        fontSize=7.5,
        leading=10,
        alignment=TA_LEFT,
    )
    cell_bold = ParagraphStyle(
        "CommissionCellBold",
        parent=cell_style,
        fontName=PDF_FONT_BOLD,
    )

    page_size = landscape(A4)
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=page_size,
        leftMargin=12 * mm,
        rightMargin=12 * mm,
        topMargin=14 * mm,
        bottomMargin=14 * mm,
        title=f"Zbirni spisak - {cycle.naziv}",
        author="TheraFlow",
    )
    story = [
        Paragraph(f"ZBIRNI SPISAK KOMISIJE<br/>{escape(cycle.naziv.upper())}", title_style),
        Paragraph(
            f"Generisano: {generated_at.strftime('%d/%m/%Y %H:%M')} | "
            f"Verzija: {PRINT_SCHEMA_VERSION}",
            meta_style,
        ),
    ]

    grouped = {key: [] for key in CATEGORY_SPECS}
    for snapshot in snapshots:
        grouped[snapshot["category"]].append(snapshot)

    for category in SUMMARY_CATEGORY_ORDER:
        spec = CATEGORY_SPECS[category]
        story.append(Paragraph(spec["heading"], heading_style))
        rows = [
            [
                Paragraph("R.br.", cell_bold),
                Paragraph("Ime i prezime", cell_bold),
                Paragraph("JMBG", cell_bold),
                Paragraph("Terapija", cell_bold),
                Paragraph("Tražena količina", cell_bold),
                Paragraph("MKB", cell_bold),
            ]
        ]
        for number, snapshot in enumerate(grouped[category], start=1):
            patient = snapshot["patient"]
            rows.append(
                [
                    Paragraph(str(number), cell_style),
                    Paragraph(
                        escape(
                            f"{patient.get('first_name', '')} {patient.get('last_name', '')}".strip()
                        ),
                        cell_style,
                    ),
                    Paragraph(escape(patient.get("jmbg", "")), cell_style),
                    Paragraph(escape(_summary_therapy(snapshot)).replace("\n", "<br/>"), cell_style),
                    Paragraph(
                        "<br/>".join(escape(line) for line in _summary_item_lines(snapshot)),
                        cell_style,
                    ),
                    Paragraph(
                        escape(patient.get("mkb", "") or patient.get("diagnosis", "")),
                        cell_style,
                    ),
                ]
            )
        if len(rows) == 1:
            rows.append(
                [
                    Paragraph("-", cell_style),
                    Paragraph("Nema zahtjeva u ovoj kategoriji.", cell_style),
                    "",
                    "",
                    "",
                    "",
                ]
            )
        table = LongTable(
            rows,
            colWidths=(12 * mm, 42 * mm, 34 * mm, 58 * mm, 48 * mm, 32 * mm),
            repeatRows=1,
            hAlign="LEFT",
        )
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dbe7f4")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#17365d")),
                    ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#64748b")),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 4),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ("SPAN", (1, 1), (-1, 1)) if len(rows) == 2 and not grouped[category] else ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ]
            )
        )
        story.extend((table, Spacer(1, 3 * mm)))

    def page_footer(canvas, document):
        canvas.saveState()
        canvas.setFont(PDF_FONT_FALLBACK, 7)
        canvas.setFillColor(colors.HexColor("#64748b"))
        canvas.drawRightString(
            page_size[0] - 12 * mm,
            7 * mm,
            f"Stranica {document.page}",
        )
        canvas.restoreState()

    doc.build(story, onFirstPage=page_footer, onLaterPages=page_footer)
    return Path(output_path)


def _generation_directory(cycle, generation_id):
    path = (
        Path(settings.MEDIA_ROOT)
        / "generated"
        / "commission_phase2"
        / f"cycle_{cycle.pk}"
        / generation_id
    )
    if not path.resolve().is_relative_to(Path(settings.MEDIA_ROOT).resolve()):
        raise OSError('Document directory escaped the configured media root')
    path.mkdir(parents=True, exist_ok=False)
    return path


def _capture_cycle_snapshots(requests, generated_at):
    # A stale draft can reference a presentation no longer in its live items.
    # Validate the actual snapshot sources too, before creating any files, and
    # roll back earlier snapshot refreshes if any later request is incomplete.
    snapshots = []
    try:
        with transaction.atomic():
            for item in requests:
                snapshots.append(capture_print_snapshot(item, captured_at=generated_at))
    except MedicineMetadataError as exc:
        return [], [{"request": item, "patient": str(item.pacijent),
                     "messages": exc.messages, "message": exc.user_message}]
    return snapshots, []


def _missing_archive_result(requests):
    errors = validate_cycle_for_print(None, requests)
    if not errors:
        errors = [{"request": None, "patient": "", "messages": [
            "Historijski zbirni spisak nema sačuvanu originalnu kopiju."],
            "message": "Historijski zbirni spisak nema sačuvanu originalnu kopiju."}]
    return {"errors": errors, "files": [], "path": None, "generation_id": ""}


def _archived_cycle_documents(requests):
    """Return verified original bytes; do not capture, render, save or audit."""
    files, seen = [], set()
    for request in requests:
        archive = request.print_snapshot['document_archive']
        proof = archive.get('category_file', {})
        path = resolve_archive_file(request, proof)
        if path is None:
            proof, path = archive, resolve_request_archive(request)
        if path is None or str(path) in seen:
            continue
        seen.add(str(path))
        category = request.print_snapshot.get('category', request.vrsta_zahtjeva)
        spec = CATEGORY_SPECS[category]
        files.append(dict(category=category, label=spec['label'],
            filename=proof['filename'], count=proof.get('count', 1), path=str(path),
            generation_id=archive['generation_id']))
    ids = sorted(request.pk for request in requests)
    summary, summary_generation = None, ''
    for request in requests:
        archive = request.print_snapshot['document_archive']
        proof = archive.get('summary_file', {})
        if isinstance(proof, dict) and proof.get('request_ids') == ids:
            summary = resolve_archive_file(request, proof)
            if summary:
                summary_generation = archive['generation_id']
                break
    return dict(errors=[], files=files, path=summary,
        generation_id=files[0]['generation_id'] if files else summary_generation,
        generated_at=requests[0].print_snapshot_at or timezone.now(), archived=True)


def _generate_cycle_documents(cycle, user, *, summary=False):
    directory = None
    try:
        with transaction.atomic():
            cycle = select_for_update_self(KomisijskiCiklus.objects.filter(pk=cycle.pk)).get()
            # All print/finalization operations take the same cycle -> requests lock order.
            list(select_for_update_self(KomisijskiZahtjev.objects.filter(
                komisijski_ciklus=cycle)).order_by('pk'))
            requests = cycle_requests(cycle)
            active = [item for item in requests if is_active_document(item)]
            if not active:
                archived = [item for item in requests if resolve_request_archive(item)]
                if not archived:
                    return _missing_archive_result(requests)
                result = _archived_cycle_documents(archived)
                if summary and result['path'] is None:
                    return _missing_archive_result([])
                return result
            errors = validate_cycle_for_print(cycle, active)
            if errors:
                return {"errors": errors, "files": [], "path": None, "generation_id": ""}
            generated_at = timezone.now()
            generation_id = f"{generated_at:%Y%m%dT%H%M%S}-{uuid.uuid4().hex[:8]}"
            for name in {CATEGORY_SPECS[r.vrsta_zahtjeva]["template_name"] for r in active}:
                load_pdf_template(name)
            snapshots, errors = _capture_cycle_snapshots(active, generated_at)
            if errors:
                return {"errors": errors, "files": [], "path": None, "generation_id": ""}
            for name in {s.get("document_package", {}).get("template_name") for s in snapshots}:
                load_pdf_template(name)
            directory = _generation_directory(cycle, generation_id)
            grouped = {key: [] for key in CATEGORY_SPECS}
            for item in snapshots:
                grouped[item['category']].append(item)
            output_summary = directory / 'Zbirni_spisak_komisije.pdf'
            render_summary_pdf(cycle, snapshots, output_summary, generated_at=generated_at)
            summary_proof = archive_file_metadata(output_summary,
                request_ids=sorted(item.pk for item in active))
            by_id = {item.pk: item for item in active}
            files = []
            for category, spec in CATEGORY_SPECS.items():
                category_snapshots = grouped[category]
                if not category_snapshots:
                    continue
                output = directory / spec['filename']
                render_category_pdf(category_snapshots, output, generated_at=generated_at)
                category_proof = archive_file_metadata(output, count=len(category_snapshots))
                pdf = PdfReader(output)
                if len(pdf.pages) != len(category_snapshots):
                    raise ValueError('Generated category does not contain one page per request')
                for snapshot, page in zip(category_snapshots, pdf.pages):
                    request = by_id[snapshot['request_id']]
                    proof = write_request_archive(request, page, directory, generation_id)
                    proof.update(category_file=category_proof, summary_file=summary_proof)
                    request.print_snapshot = dict(snapshot, document_archive=proof)
                    request.save(update_fields=('print_snapshot',))
                files.append(dict(category=category, label=spec['label'], filename=spec['filename'],
                    count=len(category_snapshots), path=str(output), generation_id=generation_id))
            upisi_log(user, 'Generisan zbirni spisak komisije' if summary else
                'Generisani komisijski zahtjevi za štampu', objekat=cycle,
                opis=f'Generacija {generation_id}; verzija {PRINT_SCHEMA_VERSION}; '
                     f'{len(active)} zahtjeva; originalni PDF dokumenti sačuvani.')
            return dict(errors=[], files=files, path=output_summary, generation_id=generation_id,
                generated_at=generated_at, archived=False)
    except Exception:
        # Only this unique failed attempt is removable. Previous originals stay intact.
        if directory is not None:
            expected = (Path(settings.MEDIA_ROOT) / 'generated' / 'commission_phase2'
                        / f'cycle_{cycle.pk}' / directory.name).resolve()
            if directory.resolve() == expected and directory.resolve().is_relative_to(Path(settings.MEDIA_ROOT).resolve()):
                shutil.rmtree(directory)
        raise


def generate_cycle_category_pdfs(cycle, user):
    return _generate_cycle_documents(cycle, user)


def generate_cycle_summary_pdf(cycle, user):
    return _generate_cycle_documents(cycle, user, summary=True)


def ensure_cycle_print_archives(cycle, user, *, generation_result=None):
    """Validate drafts before finalization, persisting missing originals first."""
    active = [item for item in cycle_requests(cycle) if is_active_document(item)]
    errors = validate_cycle_for_print(cycle, active)
    if errors or not active:
        return errors or _missing_archive_result([])['errors']
    ids = sorted(item.pk for item in active)
    generations = set()
    complete = True
    for item in active:
        archive = item.print_snapshot.get('document_archive', {}) if isinstance(item.print_snapshot, dict) else {}
        summary = archive.get('summary_file') if isinstance(archive, dict) else None
        if not resolve_request_archive(item) or not isinstance(summary, dict) or summary.get('request_ids') != ids or not resolve_archive_file(item, summary):
            complete = False
            break
        generations.add(archive['generation_id'])
    if complete and len(generations) == 1:
        return []
    result = generate_cycle_category_pdfs(cycle, user)
    if generation_result is not None:
        generation_result.update(result)
    return result['errors']


def cleanup_generated_attempt(cycle, result):
    """Rollback only a newly-created generation when its outer finalization fails."""
    import re
    generation = result.get('generation_id', '')
    if result.get('archived') is not False or not re.fullmatch(r'[A-Za-z0-9_-]+', generation):
        return
    root = Path(settings.MEDIA_ROOT).resolve()
    directory = root / 'generated' / 'commission_phase2' / f'cycle_{cycle.pk}' / generation
    if directory.resolve().is_relative_to(root) and directory.is_dir():
        shutil.rmtree(directory)


def resolve_generated_file(cycle_id, generation_id, filename):
    import re
    if not re.fullmatch(r'[A-Za-z0-9_-]+', generation_id):
        return None
    allowed = {spec["filename"] for spec in CATEGORY_SPECS.values()}
    if re.fullmatch(r'zahtjev_[0-9]+\.pdf', filename):
        request = KomisijskiZahtjev.objects.filter(pk=int(filename[8:-4]),
            komisijski_ciklus_id=cycle_id).first()
        from .commission_print_archive import request_archive_metadata
        if request and request_archive_metadata(request).get('generation_id') == generation_id:
            return resolve_request_archive(request)
        return None
    if filename not in allowed:
        return None
    for request in KomisijskiZahtjev.objects.filter(komisijski_ciklus_id=cycle_id):
        snapshot = request.print_snapshot
        archive = snapshot.get('document_archive') if isinstance(snapshot, dict) else None
        if not isinstance(archive, dict) or archive.get('generation_id') != generation_id:
            continue
        proof = archive.get('category_file')
        if isinstance(proof, dict) and proof.get('filename') == filename:
            path = resolve_archive_file(request, proof)
            if path:
                return path
    return None
