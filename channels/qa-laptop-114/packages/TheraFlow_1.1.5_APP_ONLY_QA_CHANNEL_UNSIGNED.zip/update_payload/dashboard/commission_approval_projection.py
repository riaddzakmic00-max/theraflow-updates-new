"""Read-only approval display over exact modern or legacy decision identities.

Nothing here synchronizes historical rows or manufactures patient rights.
Legacy quantities and physical delivery are shown with their actual origin.
"""
from collections import Counter
from decimal import Decimal
from types import SimpleNamespace

from patients.models import KomisijskaSaglasnost, Trebovanje, EvidencijaSaglasnostiZaprimanja, PacijentRezervacija
from patients.receipt_approval import request_receipt_approval


STATUSES = {
    'ceka': ('Čeka odluku', 'warning'),
    'odobreno': ('Odobreno', 'success'),
    'djelimicno_odobreno': ('Djelimično odobreno', 'warning'),
    'odbijeno': ('Odbijeno', 'danger'),
    'provjera': ('Potrebna provjera', 'warning'),
}


def _quantity(value):
    if value is None:
        return None
    try:
        number = Decimal(str(value))
        return number if number.is_finite() and number >= 0 else None
    except (ArithmeticError, TypeError, ValueError):
        return None


def _legacy_item(legacy, item):
    from .receipt_display import receipt_totals
    basis = request_receipt_approval(legacy)
    actual = _quantity(basis['actual_approved'])
    received = _quantity(basis['physically_received'])
    allocated = _quantity(basis['previously_allocated'])
    warnings = [basis['warning']] if basis.get('warning') else []
    scope = 'REQUEST'
    # One presentation can have a free cycle receipt even when allocation is
    # refused. Attribute that delivery only to a sole visible request; it is
    # still explicitly group stock, never a patient allocation or a K right.
    peers = list(legacy.komisijski_ciklus.trebovanja.filter(lijek_id=legacy.lijek_id)
                 .exclude(status__in=('OTKAZANO', 'ODBIJENO')).select_related('lijek')) if legacy.komisijski_ciklus_id else []
    if len(peers) == 1 and peers[0].pk == legacy.pk:
        totals = receipt_totals(legacy.komisijski_ciklus, legacy.lijek, peers)
        if received is None or totals['physical_before'] > received:
            received = totals['physical_before']
            scope = 'CYCLE_MEDICINE'
            if basis['blocked']:
                warnings.append('Fizički prijem pripada ciklusu i proizvodu; ne daje novo pravo niti zaduženje ovom pacijentu.')
    return {'item': item, 'legacy_request': legacy, 'legacy_request_id': legacy.pk,
        'actual_approved': actual, 'received': received, 'allocated': allocated,
        'remaining_delivery': max(Decimal(0), actual - received) if actual is not None and received is not None else None,
        'remaining_allocation': max(Decimal(0), actual - allocated) if actual is not None and allocated is not None else None,
        'approval_identity': basis['approval_identity'], 'approval_source': basis['approval_source'],
        'source': basis['approval_source'], 'approval_number': basis['approval_number'],
        'approval_date': basis['approval_date'], 'physical_source_scope': scope,
        'blocked': basis['blocked'], 'warnings': warnings, 'approval_basis': basis,
        'document_id': basis.get('document_id'), 'document_number': basis.get('document_number', ''),
        'document_line_id': basis.get('document_line_id'),
        'physically_received': received, 'previously_allocated': allocated}


def _unknown_item(item, *, warning='', legacy=None):
    return {'item': item, 'legacy_request': legacy, 'legacy_request_id': getattr(legacy, 'pk', None),
        'actual_approved': None, 'received': None, 'allocated': None,
        'remaining_delivery': None, 'remaining_allocation': None,
        'approval_identity': '', 'approval_source': 'MISSING', 'source': 'MISSING',
        'approval_number': '', 'approval_date': '', 'physical_source_scope': 'UNKNOWN',
        'blocked': bool(warning), 'warnings': [warning] if warning else [], 'approval_basis': None,
        'physically_received': None, 'previously_allocated': None}


def _result(request, items, *, decision=None, legacy_only=False):
    warnings = list(dict.fromkeys(warning for row in items for warning in row['warnings']))
    known_legacy = any(row['approval_source'] == 'LEGACY_COMMISSION' for row in items)
    conflict = any(row['blocked'] for row in items)
    actual = [row['actual_approved'] for row in items]
    if conflict or not items:
        key = 'provjera'
    elif decision and decision.odluka == KomisijskaSaglasnost.Odluka.ODBIJENO:
        key = 'odbijeno'
    elif any(value is None for value in actual):
        key = 'ceka'
    elif decision and decision.odluka == KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO:
        key = 'djelimicno_odobreno'
    elif all(value == 0 for value in actual):
        key = 'odbijeno'
    elif any(value < _quantity(row['item'].kolicina) for row, value in zip(items, actual)
             if _quantity(row['item'].kolicina) is not None):
        key = 'djelimicno_odobreno'
    else:
        key = 'odobreno'
    label, tone = STATUSES[key]
    source = ('Komisijska odluka' if decision else 'Ranije odobrenje' if known_legacy
              else 'Ranija evidencija' if legacy_only else 'Čeka unos odluke')
    return {'request': request, 'items': items, 'status_key': key, 'status_label': label,
        'status_tone': tone, 'tone': tone, 'editable': not decision and not known_legacy and not conflict and not legacy_only,
        'source_label': source, 'warnings': warnings, 'modern_decision': decision,
        'known_legacy': known_legacy, 'has_decision': bool(decision or known_legacy),
        'legacy_only': legacy_only}


def request_approval_projection(request):
    """Project one modern request; absence of Sag is not proof of pending."""
    decision = getattr(request, 'saglasnost', None)
    rows = []
    for item in request.stavke_lijeka.all():
        candidates = list(Trebovanje.objects.filter(komisijski_ciklus_id=request.komisijski_ciklus_id,
            pacijent_id=request.pacijent_id, lijek_id=item.lijek_id).exclude(status='OTKAZANO')
            .select_related('pacijent', 'lijek', 'komisija', 'komisijski_ciklus').order_by('pk'))
        if len(candidates) > 1:
            row = _unknown_item(item, warning='Više ranijih trebovanja za isti proizvod i pacijenta. Provjerite identitet odluke.')
        elif candidates and candidates[0].komisija_id:
            row = _legacy_item(candidates[0], item)
        elif decision and _quantity(item.odobrena_kolicina) == 0:
            legacy = candidates[0] if candidates else None
            has_previous = bool(legacy and (legacy.zaprimljene_doze > 0
                or EvidencijaSaglasnostiZaprimanja.objects.filter(trebovanje=legacy).exists()
                or PacijentRezervacija.objects.filter(trebovanje=legacy, kolicina__gt=0).exists()))
            row = _unknown_item(item, warning=('Stavka bez prava ima raniji prijem ili raspodjelu. Potrebna je provjera izvora.'
                                               if has_previous else ''), legacy=legacy)
            row.update(actual_approved=Decimal(0), received=Decimal(0), allocated=Decimal(0),
                remaining_delivery=Decimal(0), remaining_allocation=Decimal(0),
                approval_identity=f'KomisijskaSaglasnost:{decision.pk}:stavka:{item.pk}',
                approval_source='MODERN_AGREEMENT', source='MODERN_AGREEMENT',
                approval_number=decision.broj_saglasnosti or '', approval_date=decision.datum_saglasnosti.isoformat())
        elif decision and candidates:
            row = _legacy_item(candidates[0], item)
        elif decision:
            row = _unknown_item(item, warning='Odluka nema jednoznačno povezano trebovanje za prikaz ranijih prijema i raspodjela.')
            row.update(actual_approved=_quantity(item.odobrena_kolicina),
                approval_identity=f'KomisijskaSaglasnost:{decision.pk}:stavka:{item.pk}',
                approval_source='MODERN_AGREEMENT', source='MODERN_AGREEMENT',
                approval_number=decision.broj_saglasnosti or '', approval_date=decision.datum_saglasnosti.isoformat())
        else:
            legacy = candidates[0] if candidates else None
            legacy_fact = bool(legacy and (legacy.status in ('ODOBRENO', 'CEKA_ISPORUKU',
                'DJELOMICNO_ODOBRENO', 'ZAPRIMLJENO', 'ODBIJENO') or legacy.zaprimljene_doze > 0))
            row = _unknown_item(item, legacy=legacy, warning=(
                'Postoji ranija evidencija odobrenja ili prijema bez jednoznačno povezane odluke. Potrebna je provjera.'
                if legacy_fact else ''))
        if (not decision and row['actual_approved'] is not None
                and item.odobrena_kolicina is not None
                and _quantity(item.odobrena_kolicina) != row['actual_approved']):
            row['blocked'] = True
            row['warnings'].append('Ranije stvarno odobrenje i količina u novijoj evidenciji nisu usklađeni. Potrebna je provjera.')
        rows.append(row)
    return _result(request, rows, decision=decision)


def legacy_request_approval_projection(legacy):
    """Read-only row for legacy requests absent from the modern item list."""
    item = SimpleNamespace(pk=legacy.pk, id=legacy.pk, lijek=legacy.lijek, lijek_id=legacy.lijek_id,
        kolicina=legacy.broj_doza, odobrena_kolicina=legacy.odobrene_doze,
        jedinica=legacy.lijek.jedinice_zalihe[0], legacy=True)
    return _result(legacy, [_legacy_item(legacy, item)], legacy_only=True)


def approval_projection_progress(projections):
    rows = list(projections)
    counts = Counter(row['status_key'] for row in rows)
    return {'total': len(rows), 'entered': sum(row['has_decision'] for row in rows),
        'waiting': counts['ceka'], 'approved': counts['odobreno'],
        'partial': counts['djelimicno_odobreno'], 'rejected': counts['odbijeno'],
        'review': counts['provjera'], 'status_counts': dict(counts)}
