"""Reviewed clinical transition; reuses the existing phased protocol."""
from datetime import timedelta
from django import forms
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.exceptions import ValidationError
from django.db import DatabaseError
from django.shortcuts import get_object_or_404, redirect
from .correction_center_views import render_in_center as render
from django.urls import reverse
from patients import models as m
from patients.correction_protocol import contention_message
from patients import ustekinumab_transition as service
from patients.medication_groups import medicine_presentation_key, medicine_group_key
from patients.medicine_registry import active_therapy_medicines
from .permissions import je_doktor_ili_admin



from .correction_center_views import render_in_center as render
class TherapyChoice(forms.ModelChoiceField):
    def label_from_instance(self,t):
        return f'{t.datum:%d.%m.%Y.} · {t.lijek} · {t.kolicina:g} bočice — potvrđena primjena'


class AppointmentChoice(forms.ModelMultipleChoiceField):
    def label_from_instance(self,t):
        return f'{t.datum:%d.%m.%Y.} u {t.vrijeme:%H:%M} · {t.lijek} · {t.kolicina_po_terapiji} jedinica'


class TransitionForm(forms.Form):
    therapy = TherapyChoice(label='Provedena IV indukcija — stvarni datum',queryset=m.Terapija.objects.none())
    sc = forms.ModelChoiceField(label='SC prezentacija iz kataloga',queryset=m.Lijek.objects.none(),empty_label='Odaberite SC proizvod')
    dose_mg = forms.ChoiceField(label='Potvrđena SC doza',choices=[('','Odaberite dozu'),('90','90 mg SC — 1 SC jedinica')])
    interval = forms.TypedChoiceField(label='Interval SC održavanja prema planu ljekara',coerce=int,
        choices=[('','Odaberite interval'),(8,'8 sedmica'),(12,'12 sedmica')])
    date = forms.DateField(label='Potvrđeni datum prve SC doze',widget=forms.DateInput(format='%Y-%m-%d',attrs={'type':'date'}))
    time = forms.TimeField(label='Vrijeme SC termina',widget=forms.TimeInput(attrs={'type':'time'}),initial='09:00')
    date_reason = forms.CharField(label='Obrazloženje drugačijeg datuma prema planu ljekara',required=False,max_length=500,
        help_text='Obavezno ako datum odstupa od stvarne IV primjene + 8 sedmica.')
    replace = AppointmentChoice(label='Budući IV termini koje zamjenjujem',required=False,
        queryset=m.Termin.objects.none(),widget=forms.CheckboxSelectMultiple)
    iv_reservations = forms.ChoiceField(label='IV zaduženja za zamijenjene termine',required=False,
        choices=[('','Odaberite ako postoje IV zaduženja'),('keep','Zadrži IV količinu pacijentu, bez veze s otkazanim terminom'),
                 ('release','Oslobodi navedena IV zaduženja u zajedničku zalihu — fizički broj ostaje isti')])
    sc_reservation = forms.ModelChoiceField(label='Poveži postojeće SC zaduženje',
        required=False,queryset=m.PacijentRezervacija.objects.none(),empty_label='Bez nove dodjele SC zalihe')
    reason = forms.CharField(label='Potvrđeni plan ljekara / razlog prelaska',min_length=5,max_length=1000,widget=forms.Textarea(attrs={'rows':3}))

    def __init__(self,*args,patient,guided=False,**kwargs):
        super().__init__(*args,**kwargs)
        if guided:
            from patients.nurse_corrections import REASONS
            self.fields['reason_code'] = forms.ChoiceField(label='Razlog ispravke', choices=[('', 'Odaberite razlog')]+REASONS)
        events=service.recognized_inductions(patient)
        self.fields['therapy'].queryset=m.Terapija.objects.filter(pk__in=[t.pk for t in events]).select_related('lijek').order_by('-datum','-pk')
        sc_ids=[x.pk for x in active_therapy_medicines() if medicine_presentation_key(x)=='ustekinumab:SC:90']
        self.fields['sc'].queryset=m.Lijek.objects.filter(pk__in=sc_ids)
        future=service.future_iv_appointments(patient,events[-1].datum) if events else m.Termin.objects.none()
        self.fields['replace'].queryset=m.Termin.objects.filter(pk__in=[x.pk for x in future if medicine_group_key(x.lijek)=='ustekinumab'])
        self.fields['sc_reservation'].queryset=m.PacijentRezervacija.objects.filter(pacijent=patient,
            lijek_id__in=sc_ids,aktivno=True,kolicina__gte=1).select_related('lijek','termin')
        if events and not self.is_bound:
            self.initial.update(therapy=events[0].pk,date=events[0].datum+timedelta(weeks=8))

    def payload(self):
        c=self.cleaned_data
        reason = c['reason']
        if c.get('reason_code'):
            from patients.nurse_corrections import REASONS
            reason = dict(REASONS)[c['reason_code']]+': '+reason
        return dict(therapy_id=c['therapy'].pk,sc_id=c['sc'].pk,dose_mg=c['dose_mg'],interval=c['interval'],
            date=c['date'].isoformat(),time=c['time'].isoformat(),date_reason=c['date_reason'],
            replace_ids=[x.pk for x in c['replace']],iv_reservations=c['iv_reservations'],
            sc_reservation_id=c['sc_reservation'].pk if c['sc_reservation'] else None,reason=reason)


@login_required
@user_passes_test(je_doktor_ili_admin)
def transition(request,pacijent_id):
    patient=get_object_or_404(m.Pacijent,pk=pacijent_id)
    if hasattr(request, 'correction_center'):
        return guided_transition(request, patient)
    form=TransitionForm(request.POST or None,patient=patient,guided=hasattr(request,'correction_center'));plan=token=None
    if request.method=='POST':
        try:
            if request.POST.get('action')=='confirm':
                appointment,created=service.commit(patient,request.POST.get('token',''),request.user)
                messages.success(request,f'SC plan je sačuvan. Termin: {appointment.datum:%d.%m.%Y.}. IV primjena i fizička zaliha nisu ponovo knjižene.' if created else 'SC plan je već sačuvan; nije nastao duplikat.')
                return redirect(reverse('profil_pacijenta',args=[patient.pk]))
            if request.POST.get('action') != 'edit' and form.is_valid():plan,token=service.preview(patient,form.payload(),request.user)
        except (ValueError,ValidationError) as exc:
            form.add_error(None,'; '.join(exc.messages) if isinstance(exc,ValidationError) else str(exc))
        except DatabaseError as exc:
            form.add_error(None,contention_message(exc) or 'Podaci su trenutno zaključani ili promijenjeni. Ponovite pregled; zahtjev se ne knjiži djelimično.')
    return render(request,'dashboard/ustekinumab_transition.html',dict(pacijent=patient,form=form,plan=plan,token=token))


def guided_transition(request, patient):
    from django.core import signing
    from patients import nurse_corrections as coordinator
    from patients.guided_reconciliation import recovery
    medicine = patient.lijek
    form = TransitionForm(request.POST or None, patient=patient, guided=True)
    context = dict(pacijent=patient, patient=patient, medicine=medicine, form=form, plan=None, token=None)
    try:
        command = request.POST.get('action')
        if request.method == 'POST' and command in ('confirm','recommend','choose'):
            payload = signing.loads(request.POST.get('token',''), salt=coordinator.SALT)
            medicine = get_object_or_404(m.Lijek, pk=payload['medicine'])
            context['medicine'] = medicine
            if command == 'confirm':
                coordinator.require_reviewed_selection(request.POST, request.POST['token'])
                coordinator.require(request.POST.get('confirmed') == 'yes', 'Potvrdite pregled izmjena.')
                receipt, _ = coordinator.confirm(request.POST['token'], request.user, category='transition',
                    patient_id=patient.pk, medicine_id=medicine.pk, acknowledge=request.POST.get('acknowledge')=='yes')
                context.update(saved=receipt, plan=receipt.posljedice, guided_impact=receipt.posljedice['guided_impact'], completion_message='SC plan je sačuvan.')
            else:
                plan, token = coordinator.revise_preview(request.POST['token'], request.user, category='transition',
                    patient_id=patient.pk, medicine_id=medicine.pk, apply_recommended=command=='recommend',
                    selected=request.POST.getlist('guided_actions'), rejection_reason=request.POST.get('rejection_reason',''))
                context.update(plan=plan, token=token, guided_impact=plan['guided_impact'])
        elif request.method == 'POST' and command != 'edit' and form.is_valid():
            plan, token = coordinator.preview('transition', patient, medicine, form.payload(), request.user)
            context.update(plan=plan, token=token, guided_impact=plan['guided_impact'])
    except (ValueError, ValidationError, signing.BadSignature) as exc:
        context['error'] = '; '.join(exc.messages) if isinstance(exc, ValidationError) else str(exc)
    except DatabaseError as exc:
        context['error'] = contention_message(exc) or 'Radnja nije sačuvana. Provjerite dostupnost baze i ponovite pregled.'
    if context.get('error') or form.errors and not context['plan']:
        context['guided_recovery'] = recovery('transition', patient, medicine, context.get('error') or form.errors.as_text())
    return render(request, 'dashboard/ustekinumab_transition.html', context)
