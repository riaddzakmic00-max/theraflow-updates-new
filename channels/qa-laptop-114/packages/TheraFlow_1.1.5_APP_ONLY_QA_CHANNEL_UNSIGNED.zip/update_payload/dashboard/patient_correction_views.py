import logging
from urllib.parse import urlencode
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core import signing
from django.core.exceptions import ValidationError, PermissionDenied
from django.db import DatabaseError
from django.db.models import Q
from django.http import Http404, HttpResponse, FileResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods
from patients import models as m, patient_correction_workspace as service
from patients.data_corrections import CorrectionBlocked
from patients.correction_protocol import contention_message
from .patient_correction_forms import correction_form
from .permissions import je_admin

from .correction_center_views import render_in_center as render

logger = logging.getLogger(__name__)


def saved_correction(signed, patient, medicine_id=None):
    try:
        data = signing.loads(signed, salt=service.SALT+'.saved')
        if data['patient'] != patient.pk or medicine_id and data['medicine'] != medicine_id:
            raise signing.BadSignature
        model = {'inventory': m.PatientDataCorrection, 'legacy': m.PatientDataCorrection,
            'physical': m.PhysicalStockCorrection, 'quick': m.BrzaIzmjenaPacijenta}[data['backend']]
        receipt = get_object_or_404(model, pk=data['receipt'])
        return receipt, data
    except (signing.BadSignature, KeyError):
        raise Http404('Potvrda ne pripada ovom kartonu.')


@login_required
@never_cache
@require_http_methods(['GET'])
def print_patient_correction(request, pacijent_id):
    from types import SimpleNamespace
    from .inventory_correction_views import render_receipt_pdf
    service.authorize(request.user)
    patient = get_object_or_404(m.Pacijent, pk=pacijent_id)
    receipt, data = saved_correction(request.GET.get('saved', ''), patient)
    plan = service.audit_plan(receipt, data['backend'])
    plan.setdefault('title', 'Sačuvana ispravka podataka')
    if data.get('medicine'):
        medicine = get_object_or_404(m.Lijek, pk=data['medicine'])
        plan.setdefault('medicine', service.medicine_label(medicine))
    else:
        plan.setdefault('medicine', 'Prezentacija nije zabilježena u ovoj ranijoj ispravci')
    printable = SimpleNamespace(pk=receipt.pk, posljedice=plan, razlog=receipt.razlog,
        korisnik=receipt.korisnik, kreirano=receipt.kreirano,
        datum_dogadjaja=getattr(receipt, 'datum_dogadjaja', None) or plan.get('event_date') or receipt.kreirano.date())
    try:
        stream = render_receipt_pdf(printable)
    except Exception:
        logger.exception('Saved patient correction PDF failure; receipt=%s', receipt.pk)
        return HttpResponse('Ispravka je već sačuvana. Štampa trenutno nije dostupna; ponovite samo štampu iz historije. Promet se neće ponoviti.',status=503)
    return FileResponse(stream, content_type='application/pdf', filename=f'ispravka-kartona-{receipt.pk}.pdf')


@login_required
@never_cache
@require_http_methods(['GET', 'POST'])
def correct_patient_data(request, pacijent_id):
    service.authorize(request.user)
    patient = get_object_or_404(m.Pacijent, pk=pacijent_id)
    if request.method == 'GET' and not (set(request.GET)-{'cc_to','cc_patient','cc_medicine','cc_resume'}) and je_admin(request.user):
        from .correction_center_views import center_url
        return redirect(center_url(patient=patient))
    requested = request.POST if request.method == 'POST' else request.GET
    if ((requested.get('kind') or request.GET.get('kind') or request.GET.get('scope')) == 'profile'
            and not (requested.get('reverse_of') or request.GET.get('reverse_of'))):
        from .correction_views import correct_patient_profile
        return correct_patient_profile(request, pacijent_id)
    medicines = service.medicines(patient)
    if not medicines:
        from .correction_views import correct_patient_data as old_view
        return old_view(request, pacijent_id)
    args = request.POST if request.method == 'POST' else request.GET
    medicine_id = args.get('medicine') or request.GET.get('medicine') or patient.lijek_id or medicines[0].pk
    medicine = next((x for x in medicines if str(x.pk) == str(medicine_id)), None)
    if medicine is None:
        raise Http404('Prezentacija ne pripada ovom kartonu.')
    intent = args.get('intent') or request.GET.get('intent')
    explicit = any(args.get(key) or request.GET.get(key) for key in ('kind', 'scope', 'source', 'target', 'done', 'action'))
    if not intent and not explicit:
        return render(request, 'dashboard/patient_correction_workspace.html', {
            'pacijent': patient, 'medicine': medicine, 'medicine_label': service.medicine_label(medicine),
            'start': True, 'intents': service.INTENTS, 'sidebar_active_section': 'patients'})
    intent = intent or ('count' if args.get('kind') == 'stock' else 'mistake')
    if intent not in service.INTENTS:
        raise Http404
    if intent == 'missing':
        from . import retrospective_views
        event_id = args.get('event_id') or request.GET.get('event_id')
        if event_id:
            return retrospective_views.detail(request, event_id, patient_context=patient)
        return retrospective_views.index(request, patient_context=patient, medicine_context=medicine)
    kind = args.get('kind') or request.GET.get('kind') or request.GET.get('scope') or 'receipt'
    if intent == 'count' and not args.get('kind'):
        kind = 'patient_stock'
    if (kind == 'receipt' and je_admin(request.user)
            and not any(args.get(key) or request.GET.get(key) for key in ('kind', 'scope', 'source', 'target'))
            and not service.source_options(patient, medicine, 'receipt')):
        kind = 'patient_stock'
    if kind == 'reservation':
        # Historical links must no longer silently alter the global stock.
        kind = 'allocation'
    if kind not in service.TYPES:
        raise Http404
    service.authorize(request.user, kind)
    supported = service.supported_kinds(patient, medicine, request.user, intent)
    if kind not in {key for key, _ in supported} and kind not in {'stock'}:
        raise Http404('Ova vrsta ispravke nije primjenjiva za odabranu terapiju.')
    options = service.source_options(patient, medicine, kind)
    raw_target = args.get('source') or request.GET.get('source') or request.GET.get('target')
    if request.GET.get('scope') == 'reservation' and request.GET.get('target') and not args.get('source'):
        claims = m.EvidencijaSaglasnostiZaprimanja.objects.filter(pacijent=patient,
            rezervacija_id=request.GET['target'] if request.GET['target'].isdecimal() else -1,
            trebovanje__lijek=medicine)
        raw_target = claims.first().pk if claims.count() == 1 else '-1'
    target_id = int(raw_target) if raw_target and str(raw_target).isdecimal() else None
    invalid_source = bool(raw_target) and (target_id is None or target_id not in {pk for pk, _ in options})
    if invalid_source:
        target_id = None
    if target_id is None and len(options) == 1 and not invalid_source:
        target_id = options[0][0]
    needs_source = kind in {'receipt', 'allocation', 'issue', 'return', 'receipt_date', 'approval', 'therapy', 'oral_issue', 'transfer'}
    ready = not needs_source or target_id is not None
    action = args.get('action')
    form = correction_form(patient=patient, medicine=medicine, kind=kind, target_id=target_id,
        data=request.POST if action == 'preview' and ready else None)
    reverse_of = args.get('reverse_of') or request.GET.get('reverse_of')
    previous_count = args.get('previous_count') or request.GET.get('previous_count')
    previous_transfer = args.get('previous_transfer') or request.GET.get('previous_transfer')
    if previous_transfer:
        if kind != 'transfer' or not str(previous_transfer).isdecimal():
            raise Http404
        transfer = get_object_or_404(m.BrzaIzmjenaPacijenta, pk=previous_transfer, primalac=patient, lijek=medicine)
        if target_id != transfer.odredisna_rezervacija_id:
            raise Http404
        form.initial['recipient'] = transfer.pacijent_id
        form.initial['quantity'] = transfer.odredisna_rezervacija.kolicina
    if previous_count:
        if kind != 'stock' or not str(previous_count).isdecimal():
            raise Http404
        count = get_object_or_404(m.PhysicalStockCorrection, pk=previous_count, lijek=medicine)
        form.initial['quantity'] = count.prethodna_kolicina
        form.initial['event_date'] = count.pregled.get('event_date')
    previous = None
    if reverse_of:
        if not str(reverse_of).isdecimal():
            raise Http404
        previous = get_object_or_404(m.PatientDataCorrection, pk=reverse_of, pacijent=patient)
        context = service.reversal_context(previous, patient)
        if not context or (context['kind'], context.get('source'), context['medicine']) != (kind, target_id, medicine.pk):
            raise Http404
        if 'quantity' in form.fields:
            form.initial['quantity'] = context['quantity']
        if 'event_date' in form.fields and kind == 'receipt_date':
            form.initial['event_date'] = context['quantity']
        form.initial['reason'] = 'Povrat prethodne ispravke nakon nove provjere: '
        if kind == 'patient_stock':
            for name in list(form.fields):
                if name not in {'quantity', 'reason', 'expected_stock'}:
                    form.fields.pop(name)
    plan = token = None
    error = 'Odabrani izvor ne pripada ovoj terapiji i kartonu. Odaberite događaj ispod.' if invalid_source else ''
    if request.method == 'POST':
        try:
            if action == 'confirm':
                if request.POST.get('confirmed') != 'yes':
                    raise CorrectionBlocked('Potvrdite da ste pregledali stare i nove vrijednosti.')
                signed=signing.loads(request.POST.get('preview_token',''),salt=service.SALT)
                if signed['backend']=='physical' and request.POST.get('causes_reviewed')!='yes':
                    raise CorrectionBlocked('Provjerite moguće uzroke i potvrdite da razliku nije moguće objasniti stvarnim događajem.')
                receipt, created, done = service.confirm(request.POST.get('preview_token', ''), patient, request.user)
                messages.success(request, 'Ispravka je spremljena. Rezultat se ponovo provjerava iz baze.' if created
                    else 'Ova ispravka je već spremljena; promet nije ponovljen.')
                confirmed_context = signing.loads(done, salt=service.SALT+'.saved')
                return redirect(reverse('ispravi_podatke_pacijenta', args=[patient.pk])+'?'+urlencode({
                    'medicine': confirmed_context['medicine'], 'kind': confirmed_context['kind'], 'done': done, 'intent': intent}))
            if action == 'preview':
                if not ready or invalid_source:
                    raise CorrectionBlocked('Potreban podatak: odaberite događaj koji ispravljate. Datum, količina i saglasnost prikazani su na ovom ekranu.')
                if form.is_valid():
                    plan, token = service.build_plan(patient, medicine, kind, target_id, form, request.user,
                        reverse_of=previous.pk if previous else None, previous_count=previous_count,
                        previous_transfer=previous_transfer)
        except (CorrectionBlocked, ValueError, ValidationError) as exc:
            error = ' '.join(exc.messages) if isinstance(exc, ValidationError) else str(exc)
        except DatabaseError as exc:
            logger.exception('Patient correction workspace database failure; patient=%s', patient.pk)
            error = contention_message(exc) or 'Baza je zauzeta ili nedostupna. Ponovite pregled. Ponavljanje iste potvrde ne knjiži promjenu dva puta.'
        except Exception:
            logger.exception('Patient correction failed; patient=%s', patient.pk)
            error = 'Postupak nije završen. Povezane promjene nisu sačuvane djelimično. Provjerite historiju; ponovljena ista potvrda neće napraviti dodatno knjiženje.'
    saved = None
    if request.GET.get('done'):
        receipt, data = saved_correction(request.GET['done'], patient, medicine.pk)
        saved = {'receipt': receipt, 'backend': data['backend'], 'plan': service.audit_plan(receipt, data['backend']),
                 'print_url': reverse('print_patient_correction',args=[patient.pk])+'?'+urlencode({'saved':request.GET['done']})}
        try:
            saved['verification'] = service.verify_saved(patient, medicine, receipt, data['backend'])
        except Exception:
            logger.exception('Correction saved; post-save verification unavailable; receipt=%s', receipt.pk)
            saved['verification'] = {'warnings': ['Naknadna provjera trenutno nije dostupna. Ispravka je sačuvana; ponovo učitajte ovaj pregled, nemojte ponavljati unos.']}
    corrections = list(m.PatientDataCorrection.objects.filter(Q(pacijent=patient) | Q(prometi__pacijent=patient)).distinct().select_related('korisnik', 'ponistava')[:20])
    for receipt in corrections:
        backend = 'inventory' if receipt.scope.startswith('inventory_') else 'legacy'
        receipt.display_plan = service.audit_plan(receipt, backend)
        signed = signing.dumps({'patient':patient.pk,'medicine':receipt.display_plan.get('medicine_id'),
            'backend':backend,'receipt':receipt.pk},salt=service.SALT+'.saved',compress=True)
        receipt.print_url = reverse('print_patient_correction',args=[patient.pk])+'?'+urlencode({'saved':signed})
        context = service.reversal_context(receipt, patient)
        if context:
            receipt.reversal_url = reverse('ispravi_podatke_pacijenta',args=[patient.pk])+'?'+urlencode({
                key: value for key, value in {**context, 'reverse_of': receipt.pk}.items() if key != 'quantity'})
    kinds = supported
    availability_error = ''
    if kind in {'therapy', 'oral_issue'} and target_id:
        try:
            service.legacy.preview(patient, kind, {'razlog': 'Provjera podrške postojećeg servisa'}, target_id=target_id)
        except (CorrectionBlocked, ValueError, ValidationError) as exc:
            availability_error = str(exc)
    current = None
    if 'quantity' in form.fields:
        current = form.fields['quantity'].initial
    from patients.correction_impact import possible_stock_causes
    causes=possible_stock_causes(medicine) if kind=='stock' and plan else None
    return render(request, 'dashboard/patient_correction_workspace.html', {
        'pacijent': patient, 'medicine': medicine, 'medicine_label': service.medicine_label(medicine), 'unit': medicine.jedinice_zalihe[0],
        'availability_error': availability_error,
        'medicines': [(x.pk, service.medicine_label(x)) for x in medicines], 'kind': kind, 'kind_label': service.TYPES[kind],
        'kinds': kinds, 'source_options': options, 'target_id': target_id, 'ready': ready,
        'needs_source': needs_source, 'form': form, 'preview': plan, 'preview_token': token,
        'stock_causes':causes,
        'workspace_error': error, 'overview': service.overview(patient, medicine), 'saved': saved,
        'current_quantity': current, 'corrections': corrections,
        'previous': previous,
        'previous_count': previous_count,
        'previous_transfer': previous_transfer,
        'intent': intent, 'intent_label': service.INTENTS[intent],
        'calculation': service.calculation_details(patient, medicine),
        'physical_history': m.PhysicalStockCorrection.objects.filter(lijek=medicine).select_related('korisnik')[:10],
        'transfer_history': m.BrzaIzmjenaPacijenta.objects.filter(Q(pacijent=patient) | Q(primalac=patient), vrsta='transfer').select_related('primalac', 'pacijent')[:10],
        'sidebar_active_section': 'patients',
    })
