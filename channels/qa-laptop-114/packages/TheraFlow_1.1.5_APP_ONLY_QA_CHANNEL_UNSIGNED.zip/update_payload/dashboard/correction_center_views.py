"""One administrative entry point; delegated tools retain their original services."""
import json
import time
import uuid
from html import escape
from html.parser import HTMLParser
from urllib.parse import urlencode, urlsplit, parse_qsl

from django import forms
from django.db import DatabaseError
from django.utils import timezone
from patients.correction_protocol import contention_message
from django.contrib.auth.decorators import login_required
from django.http import Http404, JsonResponse
from django.shortcuts import render as django_render, redirect, get_object_or_404
from django.urls import resolve, reverse, Resolver404
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods
from patients import models as m, correction_center as service
from .retrospective_forms import NamedChoice

ACTIONS = [
    ('profile','Osnovni podaci pacijenta','Ime, prezime, identifikacija, kontakt i dijagnoza u postojećem kartonu.'),
    ('events','Naknadno evidentiraj događaj','Stvarna primjena, kućno izdavanje ili komisijsko zaprimanje; stvarni datum ostaje odvojen od vremena unosa.'),
    ('physical','Ispravi fizičko stanje frižidera','Prebrojana količina za sve pacijente. Ne mijenja zaduženja, primjene ni komisijsko pravo.'),
    ('reservation','Ispravi zaduženje pacijenta','Dodijeli slobodne doze, prenesi zaduženje ili oslobodi pogrešno dodijeljenu količinu.'),
    ('plan','Ispravi terapijski plan','Nalog ljekara: interval, doza, pauza, promjena lijeka ili IV → SC. Bez nove primjene.'),
    ('history','Historija ispravki','Ko, kada, zašto, prije i poslije. Poništavanje je nova korekcija, bez brisanja historije.'),
]
ALLOWED = {'ispravi_podatke_pacijenta','ispravi_fizicku_zalihu','brza_izmjena_pacijenta',
    'retrospective_events','retrospective_detail','ustekinumab_iv_to_sc','correct_inventory',
    'inventory_correction_receipt','medicine_corrections','correction_allocation','correction_reversal',
    'correction_plan','commission_receipt_link','controlled_correction','nurse_correction','patient_basic_data'}
META = {'cc_to','cc_patient','cc_medicine','cc_resume'}


def target(url):
    parsed=urlsplit(url)
    if parsed.scheme or parsed.netloc or not parsed.path.startswith('/') or parsed.path.startswith('//'):
        raise Http404('Nepoznata radnja centra.')
    try:match=resolve(parsed.path)
    except Resolver404:raise Http404('Nepoznata radnja centra.') from None
    if match.url_name not in ALLOWED:raise Http404('Ova radnja ne pripada centru ispravki.')
    return match


def center_url(url='', patient=None, medicine=None, resume=None):
    args={}
    if url:
        target(url)
        parsed=urlsplit(url);args=dict(parse_qsl(parsed.query));args['cc_to']=parsed.path
    if patient:args['cc_patient']=getattr(patient,'pk',patient)
    if medicine:args['cc_medicine']=getattr(medicine,'pk',medicine)
    if resume:args['cc_resume']=resume
    return reverse('correction_center')+('?' + urlencode(args) if args else '')


def links(patient,medicine):
    pid=patient.pk if patient else None;mid=medicine.pk if medicine else None
    def link(label,url):return {'label':label,'url':center_url(url,pid,mid)}
    result={key:[] for key,_,_ in ACTIONS}
    if patient:
        result['profile']=[link('Osnovni podaci pacijenta',reverse('patient_basic_data',args=[pid]))]
    result['physical']=[link('Prebrojano fizičko stanje',reverse('ispravi_fizicku_zalihu')+(f'?lijek={mid}' if mid else ''))]
    if patient and (mid or patient.lijek_id):
        workspace=reverse('ispravi_podatke_pacijenta',args=[pid])
        result['events']=[link('Primijenjena terapija',reverse('retrospective_events')+f'?entry_mode=explicit_effects&kind=therapy&patient_id={pid}&medicine_id={mid or ""}'),
            link('Zaprimanje lijeka s komisije',workspace+'?intent=missing&event_kind=receipt&flow=detailed'),
            link('Period i više povezanih događaja',workspace+'?intent=missing&flow=detailed')]
        if medicine and medicine.kucna_terapija and not medicine.oralna_terapija:
            result['events'].insert(1,link('Izdavanje kućne terapije',workspace+'?intent=missing&event_kind=home&flow=detailed'))
        if medicine and medicine.oralna_terapija:result['events']=result['events'][1:]
        result['reservation']=[link('Dodijeli slobodne doze',reverse('correction_allocation',args=[pid,mid or patient.lijek_id])+ '?kind=allocate'),
            link('Oslobodi pogrešno zaduženje',reverse('correction_allocation',args=[pid,mid or patient.lijek_id])+'?kind=release'),
            link('Prenesi zaduženje drugom pacijentu',reverse('brza_izmjena_pacijenta',args=[pid,'transfer'])),
            link('Ispravi pacijentovu količinu / konkretan zapis',workspace+'?intent=mistake&kind=patient_stock')]
        result['plan']=[link('Interval',reverse('brza_izmjena_pacijenta',args=[pid,'interval'])),
            link('Doza',reverse('brza_izmjena_pacijenta',args=[pid,'dose'])),
            link('Privremeni prekid / nastavak',reverse('correction_plan',args=[pid,'pause'])),
            link('Promjena lijeka prema odluci ljekara',reverse('correction_plan',args=[pid,'medicine']))]
        if medicine and medicine.genericki_naziv.lower()=='ustekinumab':
            result['plan'].append(link('Prelazak ustekinumaba IV → SC',reverse('ustekinumab_iv_to_sc',args=[pid])))
    else:
        result['events']=[link('Zaprimanje lijeka s komisije',reverse('retrospective_events')+'?kind=receipt&flow=detailed')]
    return result


def _context(request,patient=None,medicine=None):
    return {'patient':patient,'medicine':medicine,'home':center_url(patient=patient,medicine=medicine),
        'draft_url':reverse('correction_center_draft'),'tools':links(patient,medicine),
        'resume':request.GET.get('cc_resume',''), 'restore':None}


@login_required
@never_cache
@require_http_methods(['GET','POST'])
def index(request):
    if request.GET.get('section') == 'attention':
        from .activity_review_views import business_review
        return business_review(request, mode='attention')
    from .permissions import je_admin
    from patients.smart_reconciliation import authorize
    authorize(request.user)
    administrative = je_admin(request.user)
    delegated = request.GET.get('cc_to')
    guided = delegated and target(delegated).url_name == 'nurse_correction'
    if not administrative and ((delegated and not guided) or request.GET.get('section','') not in ('', 'smart', 'absence', 'corrections', 'events')):
        service.authorize(request.user)
    patient=get_object_or_404(m.Pacijent,pk=request.GET['cc_patient']) if request.GET.get('cc_patient','').isdigit() else None
    medicine=get_object_or_404(m.Lijek,pk=request.GET['cc_medicine']) if request.GET.get('cc_medicine','').isdigit() else patient.lijek if patient else None
    request.correction_center=_context(request,patient,medicine)
    if request.method=='POST' and request.POST.get('action') in ('preview','load_links','refresh'):
        request.correction_center['submitted']={key:request.POST.getlist(key) for key in request.POST
            if key not in {'action','csrfmiddlewaretoken','token','preview_token','request_token','confirmed'} and not key.startswith('cc_')}
    if request.GET.get('cc_restore'):
        drafts=_drafts(request)
        draft=drafts.get(request.GET['cc_restore'])
        if not draft:raise Http404('Sačuvani unos je istekao ili ne pripada ovoj prijavi.')
        if request.GET.get('cc_to')!=draft['target']:raise Http404
        request.correction_center['restore']=draft['values']
    if request.GET.get('cc_to'):
        match=target(request.GET['cc_to'])
        # Explicit context does not change a delegated service's patient identity.
        match_patient=match.kwargs.get('pacijent_id')
        if patient and match_patient and patient.pk!=match_patient:raise Http404
        if match.url_name=='retrospective_events' and patient:
            response=match.func(request,patient_context=patient,medicine_context=medicine)
        else:response=match.func(request,*match.args,**match.kwargs)
        if response.status_code in (301,302,303):
            location=response.get('Location','')
            try:response['Location']=center_url(location,patient,medicine,request.GET.get('cc_resume'))
            except Http404:
                # Successful actions returning to a card stay in the center history.
                if patient and urlsplit(location).path==reverse('profil_pacijenta',args=[patient.pk]):
                    response['Location']=center_url(patient=patient,medicine=medicine)+'&section=history'
        elif response.get('Content-Type','').startswith('text/html'):
            response.content=centralize(response.content.decode(response.charset),request).encode(response.charset)
        return response
    if request.GET.get('section') == 'smart':
        from .smart_reconciliation_views import index as smart_index
        return smart_index(request)
    if request.GET.get('section') == 'absence':
        from .absence_reconciliation_views import index as absence_index
        return absence_index(request)
    section=request.GET.get('section','')
    context={'actions':ACTIONS,'section':section,'administrator':administrative,'patients':m.Pacijent.objects.order_by('prezime','ime'),
        'medicines':m.Lijek.objects.order_by('naziv'),'tools':request.correction_center['tools'],'sidebar_active_section':'retrospective'}
    from .nurse_correction_views import CORRECTIONS, EVENTS
    event = request.GET.get('event', '')
    if event and event not in {item[0] for item in EVENTS}:raise Http404
    def guided_url(category):
        if patient and category in ('dose','interval') and patient.aktivni_fazni_protokol():
            return reverse('brza_izmjena_pacijenta',args=[patient.pk,category])
        url = reverse('nurse_correction', args=[category])
        if category == 'appointment' and patient:
            from patients.appointment_reschedule import scheduled
            appointment = scheduled(patient).first()
            if appointment:
                return center_url(url+'?'+urlencode({'appointment_id': appointment.pk}), patient, appointment.lijek)
        return center_url(url, patient, medicine)
    context['correction_choices'] = [dict(key=key, title=title, icon=icon, description=description, url=guided_url(key))
        for key,title,icon,description in CORRECTIONS if administrative or key in ('dose','interval','appointment')]
    if administrative and patient:
        context['correction_choices'].insert(0, dict(key='profile', title='Osnovni podaci pacijenta',
            icon='person-vcard', description='Ispravite ime, prezime, JMBG, datum rođenja, kontakt i ostale osnovne podatke.',
            url=center_url(reverse('patient_basic_data',args=[patient.pk]), patient, medicine)))
    context['event_choices'] = [dict(key=key, title=title, icon=icon, description=description,
        url=center_url(patient=patient,medicine=medicine)+('&' if patient or medicine else '?')+urlencode(dict(section='events',event=key)))
        for key,title,icon,description in EVENTS]
    if patient and medicine and request.GET.get('from_card') == '1':
        context['card_preflight'] = service.state(patient,medicine)
    from .balance_presentation import ISSUES
    balance_issue = request.GET.get('balance_issue', '')
    if balance_issue in ISSUES and medicine:
        title, detail = ISSUES[balance_issue]
        context['balance_issue'] = dict(title=title, detail=detail,
            sources=center_url(reverse('medicine_corrections', args=[medicine.pk]), patient, medicine) if administrative
                else reverse('medicine_corrections', args=[medicine.pk]),
            physical=guided_url('physical') if administrative and balance_issue == 'physical' else '')
        from patients.inventory import _physical_medicine_ids
        context['balance_issue']['receipts'] = [
            dict(id=pk, url=center_url(reverse('inventory_correction_receipt', args=[pk]), patient, medicine)
                if administrative else reverse('inventory_correction_receipt', args=[pk]))
            for pk in m.PatientDataCorrection.objects.filter(scope='inventory_allocation',
                prometi__lijek_id__in=_physical_medicine_ids(medicine)).values_list('pk', flat=True).distinct()
        ]
    context['selected_event'] = event
    context['selected_event_label'] = dict((item[0],item[1]) for item in EVENTS).get(event, '')
    if section == 'events' and event and medicine and (patient or event == 'receipt'):
        return redirect(guided_url(event))
    if patient and patient.lijek_id:
        try:
            from patients.quick_changes import current_regimen
            context['regimen'] = current_regimen(patient)
        except forms.ValidationError:
            from patients.phased_protocols import current_phase_details
            phase=patient.aktivni_fazni_protokol()
            if phase:
                details=current_phase_details(phase)
                if medicine and medicine.pk==details['medicine'].pk:
                    context['regimen']=dict(doza_mg=details['dose_mg'],interval_sedmica=details['interval_weeks'])
    if section=='history':
        context['history']=history(patient,medicine,user=request.user)
        if request.GET.get('cc_resume'):
            for item in context['history']:
                if item['url']:item['url']+='&'+urlencode({'cc_resume':request.GET['cc_resume']})
    return render_in_center(request,'dashboard/correction_hub.html',context)


def _drafts(request):
    return {k:v for k,v in request.session.get('correction_center_drafts',{}).items()
            if v['user']==request.user.pk and v['at']>time.time()-43200}


@login_required
@require_http_methods(['POST'])
def save_draft(request):
    service.authorize(request.user)
    if len(request.body)>60000:return JsonResponse({'error':'Unos je prevelik.'},status=400)
    try:
        data=json.loads(request.body);current=data['current'];destination=data['destination']
        for url in (current,destination):
            parsed=urlsplit(url)
            if parsed.scheme or parsed.netloc or parsed.path!=reverse('correction_center'):raise ValueError
        query=dict(parse_qsl(urlsplit(current).query));path=query['cc_to'];target(path)
        next_query=dict(parse_qsl(urlsplit(destination).query))
        if next_query.get('cc_to'):target(next_query['cc_to'])
        elif next_query.get('section')!='history':raise ValueError
        values=data['values']
        if not isinstance(values,dict) or len(values)>200:raise ValueError
        # Preview/confirmation capabilities are deliberately never resumed.
        excluded={'action','confirmed','csrfmiddlewaretoken','token','preview_token','request_token','password'}
        values={k:v for k,v in values.items() if k not in excluded and not k.startswith('cc_')
                and isinstance(v,list) and all(isinstance(x,str) and len(x)<=3000 for x in v)}
        drafts=_drafts(request)
        while len(drafts)>=10:del drafts[min(drafts,key=lambda k:drafts[k]['at'])]
        identity=uuid.uuid4().hex
        drafts[identity]={'at':time.time(),'user':request.user.pk,'target':path,'query':query,'values':values}
        request.session['correction_center_drafts']=drafts
        next_query['cc_resume']=identity
        return JsonResponse({'url':reverse('correction_center')+'?'+urlencode(next_query)})
    except (ValueError,TypeError,KeyError,Http404):return JsonResponse({'error':'Unos nije sačuvan. Ostanite na obrascu i ponovite pokušaj.'},status=400)


def render_in_center(request,template,context=None,**kwargs):
    request.correction_preview_response = True
    context=context or {}
    if template == 'dashboard/ustekinumab_transition.html' and hasattr(request,'correction_center'):
        patient = context['pacijent']
        request.correction_center['nurse_workflow'] = True
        context.update(patient=patient, medicine=patient.lijek, category='route', title='Put primjene IV / SC',
            sidebar_active_section='retrospective', original_fields=[(key,value) for key in request.POST
                for value in request.POST.getlist(key) if key not in ('csrfmiddlewaretoken','action','token','confirmed','acknowledge','guided_actions','guided_choices','rejection_reason')])
        context['center_home'] = center_url(patient=patient, medicine=patient.lijek)
        if context.get('plan'):
            plan=context['plan']
            context['preview']=dict(plan, reason=plan['data']['reason'], rows=[
                dict(label='Ranija IV primjena',before=f"{plan['iv_name']} · {plan['actual_date']}",after=f"{plan['iv_name']} · {plan['actual_date']}"),
                dict(label='Terapijski plan',before=plan['iv_name'],after=f"{plan['sc_name']} · {plan['dose_mg']} mg"),
                dict(label='Sljedeći termin',before='Dosadašnji IV termini',after=plan['date']),
                dict(label='Interval',before='Dosadašnji nalog',after=f"{plan['interval']} sedmica"),
                dict(label='Fizička SC zaliha',before=plan['sc_stock'],after=plan['sc_stock']),
                dict(label='IV zaduženja',before='Dosadašnja zaduženja',after='Prema izabranom postupku')])
            if plan.get('guided_impact'):
                context['guided_impact'] = plan['guided_impact']
                context['review_rows'] = plan['guided_impact']['final_preview']
        template = 'dashboard/nurse_correction_form.html'
    from .permissions import je_admin
    context['administrator'] = je_admin(request.user)
    if context.get('error') or context.get('form') and context['form'].errors:
        from .controlled_correction_views import recovery_context
        patient = context.get('pacijent') or context.get('patient')
        session = context.get('session')
        if patient is None and session and session.patient_id:
            patient = session.patient
        medicine = context.get('medicine')
        if not isinstance(medicine, m.Lijek):
            medicine = session.medicine if session and session.medicine_id else patient.lijek if patient else None
        context['blocked_recovery'] = recovery_context(patient, medicine, session)
    plan=context.get('preview') or context.get('plan')
    if plan and isinstance(plan,dict) and plan.get('scope') != 'profile' and not context.get('receipt') and not context.get('saved'):
        from patients.correction_impact import impact_analysis
        patient=context.get('pacijent') or context.get('patient')
        medicine=context.get('medicine')
        if not isinstance(medicine,m.Lijek):
            medicine=patient.lijek if patient else None
        context['correction_impact']=impact_analysis(patient,medicine,plan,request.user)
    if hasattr(request,'correction_center'):
        cc=request.correction_center
        if isinstance(context.get('medicine'),m.Lijek):
            cc['medicine']=context['medicine']
            cc['home']=center_url(patient=cc['patient'],medicine=cc['medicine'])
            cc['tools']=links(cc['patient'],cc['medicine'])
        plan=context.get('preview')
        if plan and 'total_after' in plan and cc.get('medicine') and 'rows' not in plan:
            from copy import deepcopy
            from decimal import Decimal
            from patients.inventory import _physical_medicine_ids
            from patients.inventory_corrections import restricted_allocation_quantity
            before=service.state(cc['patient'],cc['medicine']);after=deepcopy(before)
            after['physical']=str(Decimal(str(before['physical']))+Decimal(str(plan['delta'])))
            after['free']=str(max(Decimal(0),Decimal(after['physical'])-Decimal(str(before['reserved']))-restricted_allocation_quantity(_physical_medicine_ids(cc['medicine']))))
            context['center_rows']=service.rows(before,after)
        cc['step']=4 if context.get('saved') or context.get('receipt') else 3 if context.get('preview') or context.get('plan') or context.get('reversal') else 2
        if cc['resume']:
            draft=_drafts(request).get(cc['resume'])
            if draft:
                query={**draft['query'],'cc_restore':cc['resume']}
                cc['return_url']=reverse('correction_center')+'?'+urlencode(query)
        request.correction_center=cc
    return django_render(request,template,context,**kwargs)


def centralize(html,request):
    """Translate only allowlisted tool links/forms. Never proxy arbitrary URLs."""
    cc=request.correction_center
    current=request.GET['cc_to']
    metadata={key:request.GET[key] for key in META if request.GET.get(key)}
    def url(value):
        if not value or value.startswith('#'):return value
        parsed=urlsplit(value)
        if parsed.scheme or parsed.netloc:return value
        if not parsed.path:value=current+value
        try:return center_url(value,cc['patient'],cc['medicine'],cc['resume'])
        except Http404:return value
    class Transformer(HTMLParser):
        def __init__(self):super().__init__(convert_charrefs=False);self.out=[]
        def handle_starttag(self,tag,attrs):
            attrs=dict(attrs);extra=''
            if tag=='a' and attrs.get('href'):attrs['href']=url(attrs['href'])
            if tag=='form':
                action=attrs.get('action','')
                mapped=url(action) if action else reverse('correction_center')+'?'+request.GET.urlencode()
                if not action or mapped!=action or urlsplit(action).path==reverse('correction_center'):
                    attrs['action']=mapped
                    if attrs.get('method','get').lower()=='get':
                        extra=''.join(f'<input type="hidden" name="{escape(k)}" value="{escape(v,quote=True)}">' for k,v in metadata.items())
            self.out.append('<'+tag+''.join(' '+k+('="'+escape(v,quote=True)+'"' if v is not None else '') for k,v in attrs.items())+'>'+extra)
        def handle_startendtag(self,tag,attrs):self.handle_starttag(tag,attrs)
        def handle_endtag(self,tag):self.out.append('</'+tag+'>')
        def handle_data(self,data):self.out.append(data)
        def handle_entityref(self,name):self.out.append('&'+name+';')
        def handle_charref(self,name):self.out.append('&#'+name+';')
        def handle_comment(self,data):self.out.append('<!--'+data+'-->')
        def handle_decl(self,data):self.out.append('<!'+data+'>')
    parser=Transformer();parser.feed(html);return ''.join(parser.out)


class AllocationForm(forms.Form):
    quantity=forms.IntegerField(label='Količina (pojedinačne jedinice)',min_value=1,max_value=999999)
    reason=forms.CharField(label='Razlog ispravke',min_length=5,max_length=500,widget=forms.Textarea(attrs={'rows':3}))
    def __init__(self,*args,patient,medicine,kind,**kwargs):
        super().__init__(*args,**kwargs)
        if kind=='release':
            from patients.correction_impact import ASSIGNMENT_REASONS
            self.fields['reason_code']=forms.ChoiceField(label='Zašto se zaduženje mijenja?',
                choices=[('', 'Odaberite šta se stvarno dogodilo'),*ASSIGNMENT_REASONS])
            self.fields['reservation_id']=NamedChoice(label='Konkretno zaduženje / rezervacija',queryset=m.PacijentRezervacija.objects.filter(
                pacijent=patient,lijek=medicine,aktivno=True,kolicina__gt=0).select_related('termin'))
            self.fields['acknowledge_appointment']=forms.BooleanField(required=False,
                label='Pregledao/la sam vezu s terminom: oslobođene jedinice više ne pokrivaju taj termin; datum se ne mijenja.')


@login_required
@never_cache
@require_http_methods(['GET','POST'])
def allocation(request,pacijent_id,medicine_id):
    service.authorize(request.user)
    patient=get_object_or_404(m.Pacijent,pk=pacijent_id);medicine=get_object_or_404(m.Lijek,pk=medicine_id)
    kind=request.GET.get('kind','allocate')
    if kind not in ('allocate','release'):raise Http404
    form=AllocationForm(request.POST if request.method=='POST' and request.POST.get('action')!='confirm' else None,
        patient=patient,medicine=medicine,kind=kind)
    if request.method=='GET':form.initial.update({k:request.GET[k] for k in ('quantity','reservation_id') if request.GET.get(k)})
    context={'form':form,'title':'Dodijeli slobodne doze' if kind=='allocate' else 'Oslobodi pogrešno zaduženje',
        'pacijent':patient,'medicine':medicine,'current':service.rows(service.state(patient,medicine),service.state(patient,medicine))}
    try:
        if request.method=='POST':
            if request.POST.get('action')=='confirm':
                service.require(request.POST.get('confirmed')=='yes','Potvrdite pregled posljedica.')
                receipt,_=service.confirm(request.POST.get('token',''),request.user,patient_id=patient.pk,medicine_id=medicine.pk)
                context.update(receipt=receipt,preview=receipt.posljedice)
            elif form.is_valid():
                raw={**form.cleaned_data,'kind':kind}
                if raw.get('reservation_id'):raw['reservation_id']=raw['reservation_id'].pk
                if raw.get('reason_code') in ('applied','transfer'):
                    if raw['reason_code']=='applied':
                        from patients.therapy_history import actually_administered_therapy_query
                        therapy=actually_administered_therapy_query(m.Terapija.objects.filter(
                            pacijent=patient,lijek=medicine)).order_by('-datum','-pk').first()
                        context['guided_notice']='Nije pronađena terapija koja objašnjava ovu potrošnju. Evidentirajte stvarnu primjenu uz provjeru datuma, naloga i zalihe.'
                        if therapy:
                            context['guided_notice']='Postoji stvarna primjena '+therapy.datum.strftime('%d.%m.%Y')+'. Provjerite njenu potrošnju; ona nije dokaz da je odabrano zaduženje potrošeno. Novo oslobađanje nije izvršeno.'
                        pending=m.Termin.objects.filter(pacijent=patient,
                            lijek_id__in=medicine.equivalent_ids(),datum__lte=timezone.localdate(),
                            status__in=[m.Termin.STATUS_PLANIRANA,m.Termin.STATUS_ODGODJENA]).order_by('datum','pk').first()
                        if pending:
                            # The existing Smart path matches the real appointment,
                            # previews every domain consequence and confirms it through
                            # the canonical retrospective/arrival service.
                            context['guided_url']=reverse('correction_center')+'?'+urlencode(dict(
                                section='smart',cc_patient=patient.pk,cc_medicine=medicine.pk,
                                start=str(pending.datum),end=str(timezone.localdate()),reason=raw['reason']))
                        else:
                            context['guided_url']=reverse('retrospective_events')+'?'+urlencode(dict(
                                entry_mode='explicit_effects',kind='therapy',patient_id=patient.pk,medicine_id=medicine.pk))
                        context['guided_label']='Evidentiraj / provjeri stvarnu primjenu'
                    else:
                        context.update(guided_notice='Prijenos traži primaoca i zasebnu provjeru prije/poslije. Fizičko stanje ostaje isto.',
                            guided_url=reverse('brza_izmjena_pacijenta',args=[patient.pk,'transfer'])+'?'+urlencode({'rezervacija':raw['reservation_id']}),
                            guided_label='Odaberi primaoca i pregledaj prijenos')
                else:
                    context['preview'],context['token']=service.make_preview(patient,medicine,raw,request.user)
    except (ValueError,forms.ValidationError) as exc:context['error']=str(exc)
    except DatabaseError as exc:
        context['error']=contention_message(exc)
        if not context['error']:raise
    return render_in_center(request,'dashboard/correction_action.html',context)


def history(patient,medicine,*,user=None):
    result=[]
    from django.db.models import Q
    sessions=m.ReconciliationSession.objects.filter(workflow='absence').select_related('user')
    if user:sessions=sessions.filter(user=user)
    if medicine:sessions=sessions.filter(Q(medicine=medicine)|Q(actions__event__medicine=medicine)|Q(actions__unlinked_receipt__medicine=medicine))
    for item in sessions.distinct()[:50]:
        if patient and item.patient_id != patient.pk and not any(r.get('patient_id') == patient.pk for r in item.findings + item.receipt_findings):continue
        result.append(dict(at=item.created_at,user=item.user,reason=item.reason,date=item.period_start,
            identity='period #'+str(item.pk),title=f'Usklađivanje {item.period_start:%d.%m.}–{item.period_end:%d.%m.%Y.}',
            rows=[dict(label='Status postupka',before='Nacrt',after=item.workflow_status_label),
                  dict(label='Povezani događaji i kontrole',before='0',after=str(item.actions.count()))],
            url=reverse('correction_center')+'?'+urlencode({'section':'absence','session':item.pk}),link_label='Pregledaj cijeli postupak usklađivanja'))
    query=m.PatientDataCorrection.objects.select_related('pacijent','korisnik')
    if patient:query=query.filter(pacijent=patient)
    for item in query[:100]:
        plan=item.posljedice if isinstance(item.posljedice,dict) else {}
        if medicine and plan.get('medicine_id') not in (None,medicine.pk):continue
        if plan.get('controlled') or item.scope == 'commission_link':
            url = (reverse('controlled_correction')+'?saved='+str(item.pk) if plan.get('controlled') else
                   reverse('commission_receipt_link', args=[plan['receipt_id']])+'?saved='+str(item.pk))
            result.append(dict(at=item.kreirano,user=item.korisnik,reason=item.razlog,date=item.datum_dogadjaja,
                identity=str(item.operation_id),rows=plan.get('rows',[]),title=plan.get('title','Kontrolisana korekcija'),
                url=center_url(url,patient,medicine),link_label='Pregledaj potvrdu i povezani audit'))
            continue
        url=reverse('correction_reversal',args=[item.pk]) if item.scope=='center_allocation' else ''
        if item.scope=='center_plan' and plan.get('kind'):
            url=reverse('correction_plan',args=[item.pacijent_id,plan['kind']])+'?'+urlencode({'previous_plan':item.pk})
        if not url and item.pacijent_id:
            from patients.patient_correction_workspace import reversal_context
            ctx=reversal_context(item,item.pacijent)
            if ctx:url=reverse('ispravi_podatke_pacijenta',args=[item.pacijent_id])+'?'+urlencode({**ctx,'reverse_of':item.pk})
            elif item.scope == 'profile':
                url=reverse('patient_basic_data',args=[item.pacijent_id])+'?'+urlencode({'saved':item.pk})
        result.append(dict(at=item.kreirano,user=item.korisnik,reason=item.razlog,date=item.datum_dogadjaja,
            identity=str(item.operation_id),rows=plan.get('rows',[]),title=plan.get('title') or ('Osnovni podaci pacijenta' if item.scope == 'profile' else item.scope),
            url=center_url(url,patient,medicine) if url else '',parent=item.ponistava_id,
            link_label='Poništi ispravku' if item.scope=='center_allocation' else 'Pregledaj povezanu ispravku'))
    counts=m.PhysicalStockCorrection.objects.select_related('korisnik','lijek')
    if medicine:counts=counts.filter(lijek=medicine)
    for item in counts[:50]:
        url=reverse('ispravi_fizicku_zalihu')+'?'+urlencode({'lijek':item.lijek_id,'previous_count':item.pk})
        result.append(dict(at=item.kreirano,user=item.korisnik,reason=item.razlog,date=item.pregled.get('event_date'),
            identity=str(item.operation_id),title='Fizičko brojanje: '+str(item.lijek),
            rows=[dict(label='Fizička količina',before=item.prethodna_kolicina,after=item.nova_kolicina)],url=center_url(url,patient,medicine)))
    quick=m.BrzaIzmjenaPacijenta.objects.select_related('korisnik','pacijent','primalac')
    if patient:
        from django.db.models import Q
        quick=quick.filter(Q(pacijent=patient)|Q(primalac=patient))
    if medicine:quick=quick.filter(lijek=medicine)
    for item in quick[:80]:
        if item.vrsta=='transfer':
            url=reverse('ispravi_podatke_pacijenta',args=[item.primalac_id])+'?'+urlencode(dict(kind='transfer',medicine=item.lijek_id,
                source=item.odredisna_rezervacija_id,previous_transfer=item.pk))
            owner=item.primalac
        else:
            url=reverse('brza_izmjena_pacijenta',args=[item.pacijent_id,item.vrsta])+'?'+urlencode({'previous_change':item.pk})
            owner=item.pacijent
        result.append(dict(at=item.kreirano,user=item.korisnik,reason=item.razlog,date=item.vrijedi_od,
            identity=str(item.operation_id),title=item.get_vrsta_display(),rows=item.poslije.get('rows',[]),url=center_url(url,owner,item.lijek_id)))
    events=m.RetrospectiveEvent.objects.select_related('user','patient','medicine')
    if patient:events=events.filter(patient=patient)
    if medicine:events=events.filter(medicine=medicine)
    for item in events[:100]:
        result.append(dict(at=item.created_at,user=item.user,reason=item.note,
            date=item.event_date,identity=str(item.operation_id),title=item.get_kind_display(),
            rows=item.effects.get('preview',{}).get('rows',[]),url=center_url(reverse('retrospective_detail',args=[item.pk]),patient,medicine)))
    # Earlier allocations used the same stock ledger before the center existed.
    # Keep those visible without manufacturing a new historical audit receipt.
    movements=m.ZalihaTransakcija.objects.filter(tip=m.ZalihaTransakcija.TIP_DODJELA_SLOBODNE_ZALIHE,
        korekcija__isnull=True).select_related('pacijent','lijek','korisnik','rezervacija')
    if patient:movements=movements.filter(pacijent=patient)
    if medicine:movements=movements.filter(lijek=medicine)
    for item in movements.order_by('-pk')[:80]:
        url=''
        if item.pacijent_id and item.rezervacija_id:
            url=reverse('correction_allocation',args=[item.pacijent_id,item.lijek_id])+'?'+urlencode({
                'kind':'release','reservation_id':item.rezervacija_id,'quantity':str(item.kolicina)})
        result.append(dict(at=item.kreirano,user=item.korisnik,reason=item.napomena,date=item.datum,
            identity='promet #'+str(item.pk),title='Ranija dodjela slobodnih doza: '+str(item.lijek),
            rows=[dict(label='Dodjela / rezervacija #'+str(item.rezervacija_id),before='Promjena fizičke zalihe: 0',after=str(item.kolicina))],
            url=center_url(url,item.pacijent,item.lijek) if url else ''))
    transitions=m.Terapija.objects.exclude(workflow_snapshot__sc_transition__isnull=True).select_related('pacijent','lijek')
    if patient:transitions=transitions.filter(pacijent=patient)
    for therapy in transitions.order_by('-pk')[:50]:
        audit=(therapy.workflow_snapshot or {}).get('sc_transition')
        if not audit:continue
        from django.utils.dateparse import parse_datetime
        from django.contrib.auth import get_user_model
        plan=audit['preview']
        if medicine and medicine.pk not in (therapy.lijek_id,plan['data'].get('sc_id')):continue
        result.append(dict(at=parse_datetime(audit['created_at']),user=get_user_model().objects.filter(pk=audit['user_id']).first(),
            reason=plan['data']['reason'],date=plan['date'],identity=audit['operation_id'],title='Prelazak IV → SC',
            rows=[dict(label='Potvrđena IV primjena',before=str(therapy.datum),after='Sačuvana; bez nove potrošnje'),
                dict(label='Plan terapije',before=plan['iv_name'],after=plan['sc_name']+' · '+str(plan['date']))],
            url=center_url(patient=therapy.pacijent)+'&section=corrections',link_label='Nova ispravka uz očuvanje IV primjene'))
    import re
    unique={}
    medicine_ids={int(match) for item in result for row in item['rows']
        for key in ('before','after') for match in re.findall(r'\bLijek: (\d+)\b',str(row.get(key,'')))}
    medicine_names={pk:str(value) for pk,value in m.Lijek.objects.in_bulk(medicine_ids).items()}
    def readable(value):
        if not isinstance(value,str):return value
        value=re.sub(r'\bZapis: \d+,?\s*','',value)
        value=re.sub(r'\bLijek: (\d+)\b',lambda match:'Lijek: '+medicine_names.get(int(match[1]),'Ranija prezentacija'),value)
        value=re.sub(r'\s*#\d+','',value)
        return re.sub(r'\b(\d{4})-(\d{2})-(\d{2})\b',lambda match:f'{match[3]}/{match[2]}/{match[1]}',value)
    for item in sorted(result,key=lambda x:x['at'],reverse=True):
        identity=item['identity']
        if identity in unique:
            if not unique[identity].get('url') and item.get('url'):
                unique[identity].update(url=item['url'],link_label='Pregledaj povezanu evidenciju')
            continue
        # Keep native audit data intact; present dates and human labels in the UI.
        if '_' in item['title']:
            item['title']={'card_plan_review':'Promjena terapijskog plana','center_plan':'Terapijski plan',
                'center_allocation':'Zaduženje pacijenta'}.get(item['title'],'Ispravka podataka')
        item['rows']=[dict(row,label=readable(row['label']),before=readable(row.get('before','')),
            after=readable(row.get('after',''))) for row in item['rows']]
        unique[identity]=item
    return list(unique.values())[:150]


@login_required
@never_cache
@require_http_methods(['GET','POST'])
def reversal(request,receipt_id):
    service.authorize(request.user)
    original=get_object_or_404(m.PatientDataCorrection,pk=receipt_id,scope='center_allocation')
    return redirect('event_reversal',kind='correction',object_id=original.pk)


def plan_change(request,pacijent_id,kind):
    from .correction_plan_views import change
    return change(request,pacijent_id,kind)
