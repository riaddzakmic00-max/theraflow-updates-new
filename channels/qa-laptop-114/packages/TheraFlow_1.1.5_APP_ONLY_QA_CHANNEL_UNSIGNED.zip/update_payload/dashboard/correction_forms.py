"""Patient-scoped fields. Product metadata remains owned by the medicine catalog."""
from decimal import Decimal
from django import forms
from django.core.exceptions import ValidationError
from django.db.models import Q
from patients import models as m
from patients.patient_profile import PROFILE_FIELDS, PROFILE_LABELS, validate_profile_data

SCOPES = {
    "profile": "Osnovni podaci pacijenta",
    "medicine": "Lijek i prezentacija",
    "regimen": "Doza, interval i budući termini",
    "migration": "Datumi migracijskog unosa",
    "stock": "Fizička zaliha u frižideru",
    "reservation": "Rezervisana količina za pacijenta",
    "home": "Migracijska količina kod pacijenta",
    "approval": "Postojeće komisijsko odobrenje",
    "therapy": "Poništavanje terapije ili kućnog izdavanja",
    "oral_issue": "Poništavanje oralnog izdavanja",
}


def target_choices(patient, scope):
    if scope == "reservation":
        return [(r.pk, f"{r.lijek.naziv} · rezervacija #{r.pk} · {r.kolicina:g} {r.lijek.jedinica_zalihe}")
                for r in m.PacijentRezervacija.objects.filter(pacijent=patient).filter(Q(aktivno=True) | Q(migracijski_snapshot__isnull=False, potrosena_at__isnull=True)).select_related("lijek")]
    if scope == "approval":
        return [(c.pk, f"{c.lijek.naziv} · {c.datum_odobrenja:%d/%m/%Y} · broj {c.broj_saglasnosti or 'nije unesen'} · odobrenje #{c.pk}")
                for c in m.Komisija.objects.filter(pacijent=patient).exclude(status="PONISTENA").select_related("lijek").order_by("-datum_odobrenja", "-pk")]
    if scope == "therapy":
        return [(t.pk, f"{t.datum:%d/%m/%Y} · {t.lijek.naziv} · {t.kolicina:g} · radnja #{t.pk}")
                for t in m.Terapija.objects.filter(pacijent=patient, workflow_status="POTVRDJENA").select_related("lijek").order_by("-datum", "-pk")]
    if scope == "oral_issue":
        return [(i.pk, f"{i.datum_izdavanja:%d/%m/%Y} · {i.lijek.naziv} · {i.kolicina_tableta} tableta · izdavanje #{i.pk}")
                for i in m.IzdavanjeOralneTerapije.objects.filter(pacijent=patient, status="AKTIVNO").select_related("lijek").order_by("-datum_izdavanja", "-pk")]
    return []


class CorrectionForm(forms.Form):
    razlog = forms.CharField(label="Kratak razlog ispravke", min_length=5, max_length=500,
                            widget=forms.Textarea(attrs={"rows": 2}), strip=True)

    def __init__(self, *args, patient, scope, target_id=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.patient, self.scope, self.target_id = patient, scope, target_id
        fields = {}
        date_field = lambda label, **kw: forms.DateField(label=label, widget=forms.DateInput(format="%Y-%m-%d", attrs={"type": "date"}), **kw)
        quantity = lambda label, **kw: forms.DecimalField(label=label, max_digits=8, decimal_places=2, min_value=0, **kw)
        snap = m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient).first()
        if scope == "profile":
            for name in PROFILE_FIELDS:
                field = patient._meta.get_field(name).formfield()
                if name == "datum_rodenja":
                    field = date_field("Datum rođenja", required=False)
                field.label = PROFILE_LABELS[name]
                field.initial = getattr(patient, name)
                if name == "jmbg":
                    field.widget.attrs.update(inputmode="numeric", autocomplete="off", maxlength=13)
                    field.help_text = "Prepišite svih 13 cifara iz dokumenta. Nepoznati JMBG ostavite prazan; ne unosi se zamjenski broj."
                if name == "datum_rodenja":
                    field.help_text = "Provjerava se podudaranje s upisanim JMBG-om. Datum se ne popunjava automatski."
                fields[name] = field
        elif scope == "medicine":
            class MedicineChoice(forms.ModelChoiceField):
                def label_from_instance(self, obj):
                    return " · ".join(filter(None, [obj.naziv, obj.pharmaceutical_form, obj.strength, obj.put_primjene]))
            fields["lijek"] = MedicineChoice(queryset=m.Lijek.objects.filter(aktivan=True).order_by("naziv"),
                label="Lijek / oblik / jačina — konkretna prezentacija", initial=patient.lijek_id)
        elif scope == "regimen":
            if patient.lijek and patient.lijek.oralna_terapija:
                regimen = m.OralniTerapijskiRezim.objects.filter(pacijent=patient, aktivan=True).order_by("-datum_od", "-pk").first()
                fields["tableta_po_uzimanju"] = quantity("Tableta po uzimanju", initial=getattr(regimen, "tableta_po_uzimanju", None))
                fields["uzimanja_dnevno"] = forms.IntegerField(label="Uzimanja dnevno", min_value=1, max_value=24, initial=getattr(regimen, "uzimanja_dnevno", None))
                fields["datum_od"] = date_field("Ispravljeni datum početka postojećeg režima", initial=getattr(regimen, "datum_od", None))
            else:
                fields["kolicina_po_terapiji"] = quantity("Fizička količina po primjeni", initial=patient.doza_po_aplikaciji(),
                    help_text=f"Jedinica: {patient.lijek.jedinica_zalihe if patient.lijek else 'nije određen lijek'}. Ovo nije broj pakovanja.")
                fields["doza_mg"] = quantity("Propisana doza u mg", required=False,
                    help_text="Samo ako je određena u dokumentaciji. Ne izvodi se iz fizičke količine pakovanja.")
                fields["interval_sedmica"] = forms.IntegerField(label="Interval u sedmicama", min_value=1, max_value=52, initial=patient.efektivni_interval_sedmica())
                fields["sljedeci_datum"] = date_field("Ispravljeni prvi budući datum", required=False,
                    help_text="Prazno: proračun iz posljednje poznate primjene i intervala. Kućni datumi ostaju procjena, bez ambulantnog termina.")
                if patient.trenutni_korak_je_kucna_terapija() and not patient.aktivni_fazni_protokol():
                    fields["sljedeci_datum"].disabled = True
                    fields["sljedeci_datum"].help_text = "Kućni raspored se računa iz podataka o primjeni/izjavi pacijenta i intervala. Za novi poznati datum koristite Provjeri kućnu terapiju."
        elif scope == "migration":
            fields["datum_posljednje_terapije"] = date_field("Posljednja primjena iz migracijske dokumentacije", required=False, initial=getattr(snap, "datum_posljednje_terapije", None),
                help_text="Datum izdavanja nije datum primjene. Nepoznat datum ostavite prazan.")
            fields["sljedeca_terapija"] = date_field("Informativni naredni datum iz migracije", required=False, initial=getattr(snap, "sljedeca_terapija", None))
        elif scope == "reservation":
            reservation = m.PacijentRezervacija.objects.filter(pacijent=patient, pk=target_id).select_related("lijek").first()
            fields["kolicina"] = quantity("Ispravljena rezervisana količina za ovog pacijenta", initial=getattr(reservation, "kolicina", None),
                help_text=f"Jedinica: {reservation.lijek.jedinica_zalihe if reservation else 'odaberite rezervaciju'}. Ispravlja i povezani migracijski unos kada postoji.")
        elif scope == "home":
            fields["kod_pacijenta"] = quantity("Ispravljena poznata migracijska količina kod pacijenta", initial=getattr(snap, "kod_pacijenta", None),
                help_text="Za novu izjavu pacijenta koristite Provjeri kućnu terapiju. Nepoznata količina nije nula.")
        elif scope == "approval":
            commission = m.Komisija.objects.filter(pacijent=patient, pk=target_id).first()
            from patients.treatment_review_approval import approval_document_values
            number = approval_document_values(commission)["broj_saglasnosti"] if commission else ""
            fields["broj_saglasnosti"] = forms.CharField(label="Broj saglasnosti", required=False, max_length=100, initial=number)
            fields["datum_odobrenja"] = date_field("Datum odobrenja (nije U upotrebi od)", initial=getattr(commission, "datum_odobrenja", None))
            fields["broj_odobrenih_doza"] = quantity("Ukupna odobrena količina", initial=getattr(commission, "broj_odobrenih_doza", None))
        self.fields = {**fields, **self.fields}
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "form-control")

    def clean(self):
        data = super().clean()
        if self.scope == "profile" and not self.errors:
            validate_profile_data(self.patient, data)
            candidate = m.Pacijent.objects.get(pk=self.patient.pk)
            for name, value in data.items():
                if name != "razlog":
                    setattr(candidate, name, value or None if name == "jmbg" else value)
            candidate.validate_unique()
        return data
