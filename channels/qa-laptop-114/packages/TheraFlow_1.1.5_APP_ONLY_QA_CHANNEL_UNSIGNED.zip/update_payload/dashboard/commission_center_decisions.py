"""Explicit nurse actions using the existing per-request decision writer."""
from datetime import date
from django.core import signing
from django.core.exceptions import ValidationError, PermissionDenied
from django.db import transaction
from patients import models as m
from patients.data_corrections import digest
from patients.utils import upisi_log
from .permissions import je_komisijski_tim

SALT = 'commission-full-decisions-v1'


def decision_revision(cycle):
    return digest({
        'requests': list(cycle.zahtjevi_faza1.order_by('pk').values()),
        'items': list(m.KomisijskaStavkaLijeka.objects.filter(
            komisijski_zahtjev__komisijski_ciklus=cycle).order_by('pk').values()),
        'decisions': list(m.KomisijskaSaglasnost.objects.filter(
            komisijski_zahtjev__komisijski_ciklus=cycle).order_by('pk').values()),
    })


def batch_decision_token(cycle, user):
    return signing.dumps({'cycle': cycle.pk, 'user': user.pk, 'revision': decision_revision(cycle)}, salt=SALT)


@transaction.atomic
def record_waiting_decision(commission_request, *, user, note=''):
    if not je_komisijski_tim(user):
        raise PermissionDenied
    m.KomisijskiCiklus.objects.select_for_update().get(pk=commission_request.komisijski_ciklus_id)
    current = m.KomisijskiZahtjev.objects.select_for_update().get(pk=commission_request.pk)
    from patients.commission_exclusions import ensure_commission_inclusion
    ensure_commission_inclusion(current.pacijent, current.komisijski_ciklus)
    if current.status == m.KomisijskiZahtjev.Status.NACRT:
        raise ValidationError('Prvo potvrdite zahtjev.')
    if m.KomisijskaSaglasnost.objects.filter(komisijski_zahtjev=current).exists():
        raise ValidationError('Već evidentirana odluka se čuva. Koristite kontrolisanu ispravku.')
    before = current.status
    current.status = m.KomisijskiZahtjev.Status.CEKA_SAGLASNOST
    current.save(update_fields=['status'])
    upisi_log(user, 'Čeka komisijsku saglasnost', pacijent=current.pacijent, objekat=current,
              opis=f'Prije: {before}; poslije: {current.status}. Razlog/napomena: {note.strip() or "Čeka stvarnu odluku komisije"}.')


@transaction.atomic
def approve_selected_decisions(cycle, request_ids, *, user, number, decision_date, note='', confirmed=False, token=''):
    from .commission_center_receiving import save_agreement_for_receiving
    if not je_komisijski_tim(user):
        raise PermissionDenied
    if not confirmed:
        raise ValidationError('Potvrdite da stvarna odluka odobrava sve označene zahtjeve u cijelosti.')
    try:
        ids = {int(value) for value in request_ids}
    except (ValueError, TypeError):
        raise ValidationError('Izbor zahtjeva nije ispravan.') from None
    if not ids:
        raise ValidationError('Označite najmanje jedan zahtjev.')
    if not number.strip() or len(number.strip()) > 100:
        raise ValidationError('Unesite broj stvarnog zajedničkog dokumenta odluke (najviše 100 znakova).')
    if not isinstance(decision_date, date):
        raise ValidationError('Unesite datum odluke.')
    current_cycle = m.KomisijskiCiklus.objects.select_for_update().get(pk=cycle.pk)
    try:
        reviewed = signing.loads(token, salt=SALT, max_age=1800)
    except signing.BadSignature:
        raise ValidationError('Pregled odluka je istekao. Osvježite tabelu prije grupnog unosa.') from None
    if reviewed != {'cycle': cycle.pk, 'user': user.pk, 'revision': decision_revision(current_cycle)}:
        raise ValidationError('Zahtjevi ili odluke su promijenjeni. Ponovo pregledajte grupni unos.')
    requests = list(m.KomisijskiZahtjev.objects.select_for_update().filter(
        komisijski_ciklus=current_cycle, pk__in=ids).order_by('pk'))
    if len(requests) != len(ids):
        raise ValidationError('Svi označeni zahtjevi moraju pripadati ovom ciklusu.')
    if any(row.status == m.KomisijskiZahtjev.Status.NACRT or hasattr(row, 'saglasnost') for row in requests):
        raise ValidationError('Grupni unos je dostupan za potvrđene zahtjeve koji čekaju odluku. Postojeću odluku ispravite pojedinačno.')
    for row in requests:
        save_agreement_for_receiving(commission_request=row, agreement_number=number.strip(),
            agreement_date=decision_date, decision=m.KomisijskaSaglasnost.Odluka.ODOBRENO,
            approved_quantities={}, note=note, user=user)
    return len(requests)
