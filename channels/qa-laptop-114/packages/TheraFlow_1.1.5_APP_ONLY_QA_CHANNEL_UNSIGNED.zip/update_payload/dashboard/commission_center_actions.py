"""Database-backed action queues shared by the four commission screens."""
from collections import defaultdict
from django.db.models import Q
from django.urls import reverse
from patients import models as m
from patients.commission_exclusions import visible_commission_requests


def receiving_cycles():
    from .receipt_display import receipt_totals
    candidates = (m.KomisijskiCiklus.objects.filter(trebovanja__odobrene_doze__gt=0)
                  .distinct().prefetch_related('trebovanja__lijek')
                  .order_by('-datum_komisije', '-pk'))
    pending = []
    for cycle in candidates:
        groups = defaultdict(list)
        for row in cycle.trebovanja.all():
            if row.status not in ('ODBIJENO', 'OTKAZANO') and row.odobrene_doze:
                groups[row.lijek_id].append(row)
        if any((totals := receipt_totals(cycle, rows[0].lijek, rows))['remaining_physical'] > 0
               or totals['history_incomplete'] for rows in groups.values()):
            pending.append(cycle)
    return pending


def commission_actions(request):
    match = getattr(request, 'resolver_match', None)
    if not request.user.is_authenticated or not match or match.url_name not in {
        'komisijski_centar', 'alarm_centar', 'komisijsko_odobrenje', 'komisijsko_zaprimanje',
        'zaprimanje_ciklusa', 'komisijska_historija', 'sacuvaj_komisijsku_saglasnost_phase3',
        'grupno_odobri_komisijske_zahtjeve', 'sacuvaj_zajednicko_odobrenje_zzo',
    }:
        return {}
    from patients.commission_planning import commission_planning_rows
    from .commission_center_review import annotate_rows
    rows = annotate_rows(commission_planning_rows(), request.user)
    reviews = [row for row in rows if row['cc_status_label'] == 'Potrebna provjera']
    from .commission_approval_projection import request_approval_projection
    decisions = visible_commission_requests(m.KomisijskiZahtjev.objects.exclude(
        status=m.KomisijskiZahtjev.Status.NACRT)).select_related(
            'pacijent', 'komisijski_ciklus', 'saglasnost').prefetch_related('stavke_lijeka__lijek')
    waiting_count = sum(request_approval_projection(row)['status_key'] == 'ceka' for row in decisions)
    center = reverse('komisijski_centar')
    return {'cc_actions': {
        'review_count': len(reviews),
        'review_url': f'{center}?filter=pregled&review_all=1',
        'decisions_count': waiting_count,
        'decisions_url': f'{center}?view=saglasnosti&status=ceka&pending_all=1',
        'shipments_count': len(receiving_cycles()),
        'shipments_url': reverse('komisijsko_zaprimanje'),
    }}


def history_details(cycles):
    from .receipt_display import full_shipment_reference
    from patients.inventory_corrections import allocation_quantity, annotate_receipt_metadata
    from patients.receipt_approval import request_receipt_approval
    from .commission_approval_projection import request_approval_projection
    result = []
    for cycle in cycles:
        requests = list(cycle.zahtjevi_faza1.all())
        for request in requests:
            request.approval_projection = request_approval_projection(request)
        documents = list(m.KomisijskiDokumentOdluke.objects.filter(komisijski_ciklus=cycle)
                         .prefetch_related('stavke__pacijent', 'stavke__lijek').order_by('pk'))
        legacy = list(cycle.trebovanja.select_related('pacijent', 'lijek', 'komisija'))
        for request in legacy:
            request.receipt_approval = request_receipt_approval(request)
        legacy_ids = [row.pk for row in legacy]
        commission_ids = {row.komisija_id for row in legacy if row.komisija_id}
        associated = m.ZalihaTransakcija.objects.filter(
            Q(komisijski_ciklus=cycle) | Q(referenca_tip='KomisijskiCiklus', referenca_id=cycle.pk) |
            Q(referenca_tip='Trebovanje', referenca_id__in=legacy_ids) |
            Q(unlinkedstockreceipt__request_id__in=legacy_ids)).distinct()
        source_ids = list(associated.values_list('pk', flat=True))
        receipts = list(m.ZalihaTransakcija.objects.filter(
            Q(pk__in=source_ids) | Q(izvorna_transakcija_id__in=source_ids) |
            Q(referenca_tip='ZalihaTransakcija', referenca_id__in=source_ids))
            .select_related('lijek', 'korisnik').order_by('-datum', '-pk'))
        for movement in receipts:
            annotate_receipt_metadata(movement)
            movement.full_shipment_reference = full_shipment_reference(movement)
            if not movement.full_shipment_reference:
                movement.full_shipment_reference = (m.UnlinkedStockReceipt.objects.filter(movement=movement)
                    .values_list('delivery_reference', flat=True).first() or '')
            movement.history_allocations = [dict(patient=evidence.trebovanje.pacijent,
                original=evidence.zaprimljena_kolicina, current=allocation_quantity(evidence))
                for evidence in m.EvidencijaSaglasnostiZaprimanja.objects.filter(fizicka_transakcija=movement)
                .select_related('trebovanje__pacijent')]
        scopes = [('KomisijskiCiklus', [cycle.pk]),
                  ('KomisijskiDokumentOdluke', [document.pk for document in documents]),
                  ('KomisijskiZahtjev', [row.pk for row in requests]),
                  ('KomisijskaSaglasnost', [row.saglasnost.pk for row in requests if hasattr(row, 'saglasnost')]),
                  ('Trebovanje', [row.pk for row in legacy]),
                  ('Komisija', commission_ids),
                  ('PacijentZaduzenje', list(m.PacijentZaduzenje.objects.filter(
                      komisija_id__in=commission_ids).values_list('pk', flat=True))),
                  ('PacijentSaglasnost', list(m.PacijentSaglasnost.objects.filter(
                      Q(izvorni_ciklus=cycle) | Q(izvorno_trebovanje_id__in=legacy_ids) |
                      Q(izvorna_komisija_id__in=commission_ids) |
                      Q(zaprimanja__komisijski_ciklus=cycle) |
                      Q(zaprimanja__trebovanje_id__in=legacy_ids)
                  ).values_list('pk', flat=True).distinct())),
                  ('ZalihaTransakcija', [row.pk for row in receipts]),
                  ('PatientDataCorrection', list(m.PatientDataCorrection.objects.filter(
                      Q(izvorna_transakcija_id__in=[row.pk for row in receipts]) |
                      Q(pk__in=[row.korekcija_id for row in receipts if row.korekcija_id])
                  ).values_list('pk', flat=True))),
                  ('PacijentRezervacija', list(m.PacijentRezervacija.objects.filter(
                      trebovanje_id__in=legacy_ids).values_list('pk', flat=True))),
                  ('KomisijskoIskljucenje', list(m.KomisijskoIskljucenje.objects.filter(
                      datum_komisije=cycle.datum_komisije,
                      pacijent_id__in={row.pacijent_id for row in requests} | {row.pacijent_id for row in legacy}
                  ).values_list('pk', flat=True))) ]
        query = Q(pk__in=[])
        for model_name, ids in scopes:
            query |= Q(objekat_tip=model_name, objekat_id__in=ids)
        logs = m.AktivnostLog.objects.filter(query).select_related('korisnik').order_by('-datum_vrijeme', '-pk')
        result.append({'cycle': cycle, 'requests': requests, 'legacy_requests': legacy,
                       'receipts': receipts, 'logs': logs, 'shared_documents': documents})
    return result
