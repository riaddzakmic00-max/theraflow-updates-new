"""Read-only approval workspace: one actual ZZO document, explicit patient rows."""
from collections import Counter
from decimal import Decimal, InvalidOperation

from django.urls import reverse
from django.db.models import Count

from patients import models as m
from patients.package_sizes import procurement_breakdown
from .commission_phase2 import CATEGORY_SPECS, cycle_display_title, visible_commission_requests
from .permissions import je_komisijski_tim


STATUS_FILTERS = (
    ('sve', 'Sve'), ('ceka', 'Čeka odluku'), ('odobreno', 'Odobreno'),
    ('djelimicno_odobreno', 'Djelimično odobreno'), ('odbijeno', 'Odbijeno'),
    ('provjera', 'Potrebna provjera'),
)


def quantity_display(value, medicine):
    if value is None:
        return 'Nije evidentirano'
    try:
        number = Decimal(str(value))
        if not number.is_finite():
            return 'Za provjeru'
        return procurement_breakdown(number, medicine)['display_text']
    except (InvalidOperation, ValueError, TypeError):
        return 'Za provjeru'


def shared_document_post_rows(data, requests):
    """Pass only exact selected requests and their item IDs to the locked writer."""
    selected = data.getlist('request_ids')
    if len(selected) != len(set(selected)):
        from django.core.exceptions import ValidationError
        raise ValidationError('Isti zahtjev je označen više puta.')
    indexed = {str(row.pk): row for row in requests}
    result = []
    for request_id in selected:
        row = indexed.get(request_id)
        if row is None:
            from django.core.exceptions import ValidationError
            raise ValidationError('Označeni zahtjev ne pripada odabranoj komisiji.')
        result.append({'request_id': row.pk,
                       'decision': data.get(f'decision_{row.pk}', ''),
                       'approved_quantities': {
                           item.pk: data.get(f'approved_{item.pk}', '')
                           for item in row.stavke_lijeka.all()},
                       'note': ''})
    return result


def _decision_document_ids(row, basis, lines):
    """Display exact document membership, including rejected/pending items.

    This is documentary evidence only. It never supplies an approval quantity
    or receiving permission when the canonical approval projection is blocked.
    """
    identities = set()
    decision = basis.get('modern_decision')
    for item_basis in basis['items']:
        if item_basis.get('document_id'):
            identities.add(item_basis['document_id'])
            continue
        if basis.get('legacy_only'):
            continue
        item = item_basis['item']
        for line in lines:
            if (line.stavka_lijeka_id != item.pk or line.komisijski_zahtjev_id != row.pk
                    or line.pacijent_id != row.pacijent_id or line.lijek_id != item.lijek_id
                    or line.dokument.komisijski_ciklus_id != row.komisijski_ciklus_id
                    or line.trazena_kolicina_snapshot != item.kolicina
                    or line.jedinica_snapshot != item.jedinica):
                continue
            if decision is None:
                valid = (line.odluka == 'ceka' and line.saglasnost_id is None
                         and line.komisija_id is None and line.odobrena_kolicina_snapshot is None
                         and item.odobrena_kolicina is None)
            else:
                # Positive quantities already have the stronger receipt proof.
                # This branch is for a zero/rejected item with no receiving row.
                valid = (item.odobrena_kolicina == 0 and line.odobrena_kolicina_snapshot == 0
                         and line.saglasnost_id == decision.pk and line.odluka == decision.odluka
                         and line.dokument.broj_dokumenta == (decision.broj_saglasnosti or '').strip()
                         and line.dokument.datum_dokumenta == decision.datum_saglasnosti)
                if valid and line.komisija_id:
                    legacy = item_basis.get('legacy_request')
                    valid = (legacy is not None and legacy.komisija_id == line.komisija_id
                             and line.komisija.pacijent_id == row.pacijent_id
                             and line.komisija.lijek_id == item.lijek_id
                             and line.komisija.broj_odobrenih_doza == 0
                             and line.komisija.datum_odobrenja == line.dokument.datum_dokumenta
                             and (line.komisija.broj_saglasnosti or '').strip() == line.dokument.broj_dokumenta)
            if valid:
                identities.add(line.dokument_id)
    return sorted(identities)


def shared_approval_context(request, *, cycle_id=None, errors=None, bound_form=None,
                            select_default_cycle=True, requested_plan_date=None):
    from .commission_approval_projection import request_approval_projection, legacy_request_approval_projection
    from .commission_center_decisions import batch_decision_token
    from .shared_commission_document import shared_document_token

    cycles = list(m.KomisijskiCiklus.objects.annotate(
        phase3_request_count=Count('zahtjevi_faza1', distinct=True)
    ).order_by('-godina', '-mjesec', '-datum_komisije', '-pk'))
    selected_id = cycle_id or request.GET.get('cycle') or request.POST.get('cycle')
    unassigned = selected_id == 'unassigned'
    selected_cycle = next((cycle for cycle in cycles if str(cycle.pk) == str(selected_id)), None)
    if selected_id and selected_cycle is None and not unassigned:
        from django.http import Http404
        raise Http404('Odabrana komisija ne postoji.')
    if select_default_cycle and not unassigned:
        selected_cycle = selected_cycle or next((cycle for cycle in cycles if cycle.phase3_request_count),
                                                cycles[0] if cycles else None)
    is_bound = request.method == 'POST' and bool(errors)
    data = request.POST if is_bound else None
    form = {'number': data.get('agreement_number', '') if data is not None else '',
            'date': data.get('agreement_date', '') if data is not None else '',
            'note': data.get('note', '') if data is not None else '',
            'confirmed': bool(data is not None and data.get('confirmed') == 'yes'),
            'errors': list(errors or [])}
    if bound_form is not None:
        form['errors'].extend(str(message) for messages in bound_form.errors.values() for message in messages)
    context = {'commission_center_tab': 'saglasnosti', 'phase3_cycles': cycles,
               'phase3_cycle': selected_cycle, 'phase3_shared_rows': [], 'phase3_rows': [],
               'phase3_unassigned': unassigned, 'phase3_requested_plan_date': requested_plan_date,
               'phase3_has_unassigned': visible_commission_requests(m.Trebovanje.objects.filter(
                   komisijski_ciklus__isnull=True).exclude(status='OTKAZANO')).exists(),
               'phase3_has_editable': False,
               'phase3_shared_documents': [], 'phase3_shared_form': form,
               'phase3_can_manage': je_komisijski_tim(request.user),
               'phase3_selected_status': 'sve', 'phase3_selected_category': 'sve',
               'phase3_status_filters': [], 'phase3_category_filters': [], 'phase2_total': 0,
               'phase3_progress': {'total': 0, 'entered': 0, 'waiting': 0, 'approved': 0,
                                   'partial': 0, 'rejected': 0, 'review': 0,
                                   'status_label': 'Čeka odluku'}}
    if selected_cycle is None and not unassigned:
        return context
    all_pending = request.GET.get('pending_all') == '1' and not unassigned
    requests = visible_commission_requests(m.KomisijskiZahtjev.objects.exclude(
        status=m.KomisijskiZahtjev.Status.NACRT))
    if unassigned:
        requests = requests.none()
    elif not all_pending:
        requests = requests.filter(komisijski_ciklus=selected_cycle)
    requests = list(requests.select_related('pacijent', 'saglasnost', 'komisijski_ciklus')
                    .prefetch_related('stavke_lijeka__lijek').order_by('pacijent__prezime', 'pacijent__ime', 'pk'))
    projected = [(row, request_approval_projection(row)) for row in requests]
    if not all_pending:
        modern_pairs = {(row.pacijent_id, item.lijek_id) for row in requests
                        for item in row.stavke_lijeka.all()}
        legacy_source = (m.Trebovanje.objects.filter(komisijski_ciklus__isnull=True)
                         if unassigned else selected_cycle.trebovanja.all())
        legacy_rows = visible_commission_requests(legacy_source.exclude(status='OTKAZANO'))
        for legacy in legacy_rows.select_related('pacijent', 'lijek', 'komisija', 'komisijski_ciklus'):
            if (legacy.pacijent_id, legacy.lijek_id) not in modern_pairs:
                projected.append((legacy, legacy_request_approval_projection(legacy)))
    if all_pending:
        projected = [(row, basis) for row, basis in projected if basis['status_key'] == 'ceka']
    document_lines = {}
    for line in m.KomisijskaDokumentStavka.objects.filter(
            komisijski_zahtjev_id__in=[row.pk for row, basis in projected if not basis.get('legacy_only')]
            ).select_related('dokument', 'komisija').order_by('pk'):
        document_lines.setdefault(line.komisijski_zahtjev_id, []).append(line)
    counts = Counter(basis['status_key'] for _, basis in projected)
    total = len(projected)
    waiting = counts['ceka']
    review = counts['provjera']
    entered = sum(basis['has_decision'] for _, basis in projected)
    progress = dict(total=total, entered=entered, waiting=waiting, review=review,
                    approved=counts['odobreno'], partial=counts['djelimicno_odobreno'],
                    rejected=counts['odbijeno'],
                    status_label='Potrebna provjera' if review else
                    'Odluke evidentirane' if entered == total and total else 'Čeka odluku')
    status_filter = request.GET.get('status') or request.POST.get('return_status') or 'sve'
    if status_filter not in dict(STATUS_FILTERS):
        status_filter = 'sve'
    category_filter = request.GET.get('category') or request.POST.get('return_category') or 'sve'
    if category_filter != 'sve' and category_filter not in CATEGORY_SPECS:
        category_filter = 'sve'
    selected_ids = set(data.getlist('request_ids')) if data is not None else set()
    rows = []
    for row, basis in projected:
        if status_filter != 'sve' and basis['status_key'] != status_filter:
            continue
        if category_filter != 'sve' and getattr(row, 'vrsta_zahtjeva', '') != category_filter:
            continue
        item_rows = []
        for item_basis in basis['items']:
            item = item_basis['item']
            item_rows.append({'id': item.pk, 'medicine_label': str(getattr(item, 'zasticeni_naziv', '') or item.lijek),
                              'presentation_label': ' · '.join(filter(None, (
                                  getattr(item, 'jacina', ''), getattr(item, 'oblik', '')))),
                              'requested_display': quantity_display(item.kolicina, item.lijek),
                              'requested_value': str(item.kolicina),
                              'unit_label': procurement_breakdown(item.kolicina, item.lijek)['unit_label'],
                              'approved_value': data.get(f'approved_{item.pk}', '') if data is not None else '',
                              'approved_display': quantity_display(item_basis['actual_approved'], item.lijek),
                              'received_display': quantity_display(item_basis['received'], item.lijek),
                              'allocated_display': quantity_display(item_basis['allocated'], item.lijek),
                              'remaining_delivery_display': quantity_display(item_basis['remaining_delivery'], item.lijek),
                              'remaining_allocation_display': quantity_display(item_basis['remaining_allocation'], item.lijek),
                              'approval_identity': item_basis.get('approval_identity', ''), 'errors': []})
        row_id = f'legacy-{row.pk}' if basis.get('legacy_only') else row.pk
        document_ids = _decision_document_ids(row, basis, document_lines.get(row.pk, []))
        numbers = list(dict.fromkeys(item_basis.get('approval_number', '')
                                     for item_basis in basis['items'] if item_basis.get('approval_number')))
        dates = list(dict.fromkeys(item_basis.get('approval_date', '')
                                   for item_basis in basis['items'] if item_basis.get('approval_date')))
        formatted_dates = []
        for value in dates:
            try:
                from datetime import date
                formatted_dates.append(date.fromisoformat(value).strftime('%d/%m/%Y'))
            except (ValueError, TypeError):
                formatted_dates.append(str(value))
        rows.append({'request': row, 'request_id': row_id,
                     'patient_label': f'{row.pacijent.ime} {row.pacijent.prezime}',
                     'patient_url': reverse('profil_pacijenta', args=[row.pacijent_id]),
                     'request_type_label': getattr(row, 'canonical_request_type_label', 'Ranije trebovanje'),
                     'editable': basis['editable'] and not all_pending,
                     'selected': str(row.pk) in selected_ids,
                     'decision_value': data.get(f'decision_{row.pk}', 'ceka') if data is not None else 'ceka',
                     'decision_label': basis['status_label'], 'status_label': basis['status_label'],
                     'decision_number': ', '.join(numbers), 'decision_date_display': ', '.join(formatted_dates),
                     'decision_document_id': document_ids[0] if len(document_ids) == 1 else None,
                     'decision_document_ids': document_ids,
                     'cycle_date_display': row.komisijski_ciklus.datum_komisije.strftime('%d/%m/%Y')
                         if row.komisijski_ciklus_id and row.komisijski_ciklus.datum_komisije else 'Nije evidentiran',
                     'status_tone': basis['status_tone'], 'source_label': basis['source_label'],
                     'warnings': basis['warnings'], 'items': item_rows, 'errors': [],
                     'detail_url': (reverse('komisijski_centar') +
                                    f'?view=saglasnosti&cycle={row.komisijski_ciklus_id}'
                                    if all_pending else reverse('profil_pacijenta', args=[row.pacijent_id])),
                     'detail_label': 'Otvori komisiju' if all_pending else 'Otvori karton za provjeru'})
    documents = list(m.KomisijskiDokumentOdluke.objects.filter(komisijski_ciklus=selected_cycle)
                     .prefetch_related('stavke__pacijent', 'stavke__lijek').order_by('-pk')) if selected_cycle else []
    document_rows = []
    for document in documents:
        members = list(document.stavke.all())
        document_rows.append({'id': document.pk, 'number': document.broj_dokumenta,
                              'label': document.display_label,
                              'number_display': document.external_number_display,
                              'date': document.datum_dokumenta, 'member_count': len(members),
                              'entered_count': sum(line.odluka != 'ceka' for line in members),
                              'pending_count': sum(line.odluka == 'ceka' for line in members),
                              'rows': members})
    categories = Counter(getattr(row, 'vrsta_zahtjeva', '') for row, _ in projected)
    context.update(phase3_shared_rows=rows, phase3_rows=rows, phase3_progress=progress,
                   phase3_has_editable=any(row['editable'] for row in rows),
                   phase3_status_filters=[{'key': key, 'label': label,
                       'count': total if key == 'sve' else counts[key], 'active': key == status_filter}
                       for key, label in STATUS_FILTERS],
                   phase3_category_filters=[{'key': 'sve', 'label': 'Sve vrste', 'count': total,
                                              'active': category_filter == 'sve'},
                       *[{'key': key, 'label': spec['short_label'], 'count': categories[key],
                           'active': category_filter == key} for key, spec in CATEGORY_SPECS.items()]],
                   phase3_shared_documents=document_rows,
                   phase3_selected_status=status_filter, phase3_selected_category=category_filter,
                   phase3_cycle_title=('Bez dodijeljenog ciklusa' if unassigned else
                       'Sve odluke koje čekaju unos' if all_pending else cycle_display_title(selected_cycle)),
                   phase3_all_pending=all_pending, phase3_cycle_internal_id=selected_cycle.naziv if selected_cycle else '',
                   phase2_total=total,
                   phase3_shared_token=shared_document_token(selected_cycle, request.user) if selected_cycle else '',
                   phase3_batch_token=batch_decision_token(selected_cycle, request.user) if selected_cycle else '')
    return context
