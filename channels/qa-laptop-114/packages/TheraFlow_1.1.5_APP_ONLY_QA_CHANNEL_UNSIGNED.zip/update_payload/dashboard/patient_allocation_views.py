"""A small patient-scoped UI over the existing free-stock allocation service."""
import logging
from uuid import uuid4

from django import forms
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core import signing
from django.core.exceptions import PermissionDenied
from django.db import DatabaseError
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods

from patients import models as m
from patients.inventory import assign_free_stock_to_patient, free_stock_quantity, free_stock_source_rows
from patients.patient_allocations import compatible_presentations
from patients.home_therapy import format_stock_quantity
from .permissions import je_sestra_ili_admin

logger = logging.getLogger(__name__)
SALT = 'theraflow.patient-allocation.v1'


class PresentationChoice(forms.ModelChoiceField):
    def label_from_instance(self, medicine):
        return medicine.prikaz_naziv


class PatientAllocationForm(forms.Form):
    medicine = PresentationChoice(label='Lijek / prezentacija', queryset=m.Lijek.objects.none(), empty_label=None)
    quantity = forms.IntegerField(label='Količina za zaduženje', min_value=1, max_value=999999,
        widget=forms.NumberInput(attrs={'min': 1, 'step': 1, 'inputmode': 'numeric'}))
    note = forms.CharField(label='Napomena (nije obavezna)', required=False, max_length=500,
        widget=forms.Textarea(attrs={'rows': 2}))

    def __init__(self, *args, medicines, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['medicine'].queryset = medicines


@login_required
@never_cache
@require_http_methods(['GET', 'POST'])
def add_allocation(request, pacijent_id):
    if not request.user.is_active or not je_sestra_ili_admin(request.user):
        raise PermissionDenied('Dodjela zaduženja zahtijeva ovlast terapijskog tima.')
    patient = get_object_or_404(m.Pacijent, pk=pacijent_id)
    back = reverse('profil_pacijenta', args=[patient.pk]) + '?tab=komisije#patient-allocations'
    medicines = compatible_presentations(patient)
    error, identity = '', None
    if request.method == 'POST':
        token = request.POST.get('request_token', '')
        try:
            identity = signing.loads(token, salt=SALT, max_age=86400)
            if (identity['user'], identity['patient']) != (request.user.pk, patient.pk):
                raise ValueError('Zahtjev ne pripada ovom pacijentu i korisniku.')
            # A successful operation remains replayable after a therapy change.
            # The service validates the original product, amount and user before
            # returning its saved reservation; this does not authorize a new one.
            saved_products = m.ZalihaTransakcija.objects.filter(operation_id=identity['operation'],
                pacijent=patient, korisnik=request.user,
                tip=m.ZalihaTransakcija.TIP_DODJELA_SLOBODNE_ZALIHE).values_list('lijek_id', flat=True)
            medicines = m.Lijek.objects.filter(pk__in=set(medicines.values_list('pk', flat=True)) | set(saved_products))
        except (signing.BadSignature, KeyError, TypeError, ValueError):
            error = 'Zahtjev dodjele nije ispravan. Ponovo otvorite obrazac.'
            identity = None
    else:
        token = signing.dumps(dict(user=request.user.pk, patient=patient.pk, operation=str(uuid4())), salt=SALT)

    initial = {'medicine': request.GET.get('medicine') or patient.lijek_id}
    form = PatientAllocationForm(request.POST if request.method == 'POST' else None,
        medicines=medicines, initial=initial)
    if request.method == 'POST' and not error and form.is_valid():
        medicine = form.cleaned_data['medicine']
        try:
            assign_free_stock_to_patient(pacijent=patient, lijek=medicine,
                quantity=form.cleaned_data['quantity'], user=request.user,
                reason=form.cleaned_data['note'], operation_id=identity['operation'])
        except ValueError as exc:
            error = str(exc)
            if error.startswith('Dostupno je'):
                error = 'Nema dovoljno slobodne fizičke zalihe za ovu prezentaciju. ' + error
        except DatabaseError:
            logger.exception('Patient allocation database failure')
            error = 'Zaduženje nije dodano. Ponovo pregledajte slobodnu zalihu.'
        except Exception:
            logger.exception('Patient allocation failed')
            error = 'Zaduženje nije dodano. Pokušajte ponovo.'
        else:
            messages.success(request, f'Dodijeljeno je {format_stock_quantity(medicine, form.cleaned_data["quantity"])}: {medicine.prikaz_naziv}.')
            return redirect(back)

    presentations = []
    for medicine in medicines:
        free = free_stock_quantity(medicine)
        sources = free_stock_source_rows(medicine)
        presentations.append(dict(id=medicine.pk, route=medicine.put_primjene,
            free=str(free), has_free=free > 0, free_label=format_stock_quantity(medicine, free),
            sources=[dict(label=row['event'], quantity=format_stock_quantity(medicine, row['quantity']),
                          known=bool(row['transaction'])) for row in sources]))
    selected = next((row for row in presentations if str(row['id']) == str(form['medicine'].value())),
                    presentations[0] if presentations else None)
    return render(request, 'dashboard/patient_add_allocation.html', dict(
        patient=patient, form=form, error=error, presentations=presentations,
        selected=selected, request_token=token, back=back))
