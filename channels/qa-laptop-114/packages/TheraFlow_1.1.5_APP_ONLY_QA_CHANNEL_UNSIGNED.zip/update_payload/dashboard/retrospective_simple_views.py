"""Minimal September entry over the existing signed retrospective protocol."""
from django import forms
from decimal import Decimal
from django.shortcuts import redirect, render
from django.urls import reverse
from patients import models as m, retrospective_events as events, retrospective_pending as pending
from .retrospective_forms import NamedChoice
from patients import retrospective_accounting as accounting



from .correction_center_views import render_in_center as render
class LinkChoice(NamedChoice):
    def label_from_instance(self,obj):
        if isinstance(obj,m.PacijentRezervacija):
            return f'#{obj.pk} · {obj.lijek} · {obj.kolicina} · rezervisano {obj.datum_rezervacije:%d.%m.%Y.}' + (f' · termin {obj.termin.datum:%d.%m.%Y.}' if obj.termin_id else ' · bez termina')
        if isinstance(obj,m.Komisija):
            return f'#{obj.pk} · {obj.lijek} · {obj.broj_saglasnosti or "bez broja"} · od {obj.datum_odobrenja:%d.%m.%Y.} · preostalo {obj.preostale_doze}'
        return f'#{obj.pk} · {obj.lijek} · {obj.datum:%d.%m.%Y.} · {obj.kolicina} · serija {obj.serija or "nije poznata"} · rok {obj.rok_trajanja or "nije poznat"}'


class SimpleEventForm(forms.Form):
    kind = forms.ChoiceField(choices=list(pending.TITLES.items()),widget=forms.HiddenInput)
    event_date = forms.DateField(label='Stvarni datum događaja',widget=forms.DateInput(
        attrs={'type':'date','min':'2026-09-01','max':'2026-09-30'},format='%Y-%m-%d'))
    patient_id = NamedChoice(label='Pacijent',queryset=m.Pacijent.objects.all().order_by('prezime','ime'))
    medicine_id = NamedChoice(label='Lijek',queryset=m.Lijek.objects.all().order_by('naziv'))
    quantity = forms.DecimalField(label='Količina u jedinicama odabranog lijeka',min_value=Decimal('.01'),
        max_value=Decimal('999999.99'),max_digits=8,decimal_places=2)
    note = forms.CharField(label='Napomena i razlog naknadnog unosa',min_length=5,max_length=2000,
        widget=forms.Textarea(attrs={'rows':3}))
    batch = forms.CharField(label='Serija — samo ako je poznata',required=False,max_length=100)
    expires = forms.DateField(label='Rok — samo ako je poznat',required=False,
        widget=forms.DateInput(attrs={'type':'date'},format='%Y-%m-%d'))
    accounting_choice=forms.ChoiceField(label='Šta treba uskladiti ovom evidencijom?',
        choices=[('','— Odaberite —')]+accounting.CHOICES,help_text=' '.join(accounting.EXPLANATIONS))
    skip_reason=forms.CharField(label='Razlog preskakanja umanjenja i izvor provjere',required=False,max_length=1000,
        widget=forms.Textarea(attrs={'rows':2}),help_text='Obavezno za sve opcije osim umanjenja obje evidencije. Navedite raniju korekciju, popis ili drugi provjerljiv podatak.')
    reservation_id=LinkChoice(label='Konkretna rezervacija za razduženje',required=False,queryset=m.PacijentRezervacija.objects.none(),
        help_text='Birajte samo uz razduženje pacijenta. Rezervacija za drugi ili budući termin ne može se koristiti.')
    approval_action=forms.ChoiceField(label='Učinak na komisijsko odobrenje',choices=[('','— Odaberite —')]+accounting.APPROVAL_CHOICES)
    commission_id=LinkChoice(label='Povezano odobrenje',required=False,queryset=m.Komisija.objects.none())
    source_id=LinkChoice(label='Postojeći prijem — ako je poznat',required=False,queryset=m.ZalihaTransakcija.objects.none())
    link_reason=forms.CharField(label='Provjera povezanih evidencija',min_length=5,max_length=1000,
        widget=forms.Textarea(attrs={'rows':2}),help_text='Navedite zašto odabrana rezervacija pripada ovoj primjeni, dokaz već uračunatog odobrenja ili šta još treba razjasniti. Ne mijenja se budući termin.')

    def __init__(self,*args,patient=None,mode=pending.MODE,**kwargs):
        super().__init__(*args,**kwargs)
        self.mode=mode
        if mode==pending.EXPLICIT_MODE:
            from django.utils import timezone
            self.fields['event_date'].widget.attrs={'type':'date','max':str(timezone.localdate())}
        if patient:
            self.fields['patient_id'].queryset=m.Pacijent.objects.filter(pk=patient.pk)
            self.fields['patient_id'].initial=patient
        selected=self.data.get('medicine_id') if self.is_bound else self.initial.get('medicine_id')
        medicine=m.Lijek.objects.filter(pk=selected).first() if str(selected or '').isdigit() else None
        if medicine:self.fields['quantity'].label=f'Količina — {medicine.jedinice_zalihe[0]}'
        kind=self.data.get('kind') if self.is_bound else self.initial.get('kind','therapy')
        extra=('accounting_choice','skip_reason','reservation_id','approval_action','commission_id','source_id','link_reason')
        if kind!='therapy':
            for key in extra:self.fields.pop(key)
        else:
            pid=patient.pk if patient else (self.data.get('patient_id') if self.is_bound else self.initial.get('patient_id'))
            if str(pid or '').isdigit():
                self.fields['reservation_id'].queryset=m.PacijentRezervacija.objects.filter(pacijent_id=pid,aktivno=True,kolicina__gt=0).select_related('lijek','termin')
                self.fields['commission_id'].queryset=m.Komisija.objects.filter(pacijent_id=pid).select_related('lijek')
                from django.db.models import Q
                self.fields['source_id'].queryset=m.ZalihaTransakcija.objects.filter(Q(pacijent_id=pid)|Q(pacijent__isnull=True),tip='ZAPRIMANJE').select_related('lijek')

    def event_data(self):
        result={**self.cleaned_data,'entry_mode':self.mode}
        for key in ('patient_id','medicine_id'):result[key]=result[key].pk
        for key in ('reservation_id','commission_id','source_id'):
            if key in result:result[key]=result[key].pk if result[key] else None
        result['event_date']=str(result['event_date'])
        result['expires']=str(result.get('expires') or '')
        return result


def simple_entry(request,patient=None):
    from .retrospective_views import error_message
    events.authorize(request.user)
    args=request.POST if request.method=='POST' else request.GET
    mode=args.get('entry_mode',pending.MODE)
    kind=args.get('kind','therapy');events.require(kind in pending.TITLES,'Odaberite vrstu događaja.')
    initial={'kind':kind,'patient_id':patient.pk if patient else args.get('patient_id'),
        'medicine_id':patient.lijek_id if patient else args.get('medicine_id')}
    form=SimpleEventForm(request.POST if request.method=='POST' else None,initial=initial,patient=patient,mode=mode)
    context={'entry_mode':mode,'form':form,'kind':kind,'title':pending.TITLES[kind],'patient_context':patient,
        'detailed_url':(reverse('ispravi_podatke_pacijenta',args=[patient.pk])+'?intent=missing&flow=detailed')
        if patient else reverse('retrospective_events')+'?flow=detailed'}
    if args.get('review_medicine'):
        medicine=events.chosen(m.Lijek,args.get('review_medicine'),'lijek')
        context['review']=pending.count_review(medicine)
    try:
        if request.method=='POST':
            if args.get('action')=='confirm':
                events.require(args.get('confirmed')=='yes','Potvrdite da ste pregledali odabrani učinak i vrijednosti prije/poslije.')
                payload=events._payload(args.get('token',''),request.user,'create')
                events.require(payload['data'].get('entry_mode')==mode,'Potvrda ne pripada ovom unosu.')
                if patient:events.require(payload['data']['patient_id']==patient.pk,'Potvrda ne pripada ovom kartonu.')
                event,_=events.confirm(args['token'],request.user)
                return redirect('retrospective_detail',event_id=event.pk)
            if args.get('action')!='load_links' and form.is_valid():
                context['plan'],context['token']=events.make_preview(form.event_data(),request.user)
    except Exception as exc:
        context['error']=error_message(exc)
    context['recent']=m.RetrospectiveEvent.objects.filter(effects__entry_mode__in=(pending.MODE,pending.EXPLICIT_MODE)).select_related('patient','medicine','user')
    if patient:context['recent']=context['recent'].filter(patient=patient)
    context['recent']=context['recent'][:50]
    return render(request,'dashboard/retrospective_simple.html',context)
