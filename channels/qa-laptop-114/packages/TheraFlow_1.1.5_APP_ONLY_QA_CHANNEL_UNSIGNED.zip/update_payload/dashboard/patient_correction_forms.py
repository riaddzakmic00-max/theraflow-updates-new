import json

from django import forms
from django.utils import timezone
from patients import models as m, inventory_corrections as inventory
from patients.stock_lots import lot_balances
from patients.patient_correction_workspace import LEGACY_TYPES
from .correction_forms import CorrectionForm


def correction_form(*, patient, medicine, kind, target_id, data=None):
    if kind in LEGACY_TYPES:
        form = CorrectionForm(data, patient=patient, scope=kind, target_id=target_id)
        if kind in {'therapy', 'oral_issue'}:
            form.fields['not_occurred'] = forms.BooleanField(label='Provjereno: ova radnja nije stvarno izvršena; ispravlja se pogrešan zapis, a ne vraća primijenjen ili predat lijek.')
        return form
    return PatientInventoryForm(data, patient=patient, medicine=medicine, kind=kind, target_id=target_id)


class PatientInventoryForm(forms.Form):
    def __init__(self, *args, patient, medicine, kind, target_id, **kwargs):
        super().__init__(*args, **kwargs)
        quantity = None
        if kind == 'patient_stock':
            from patients.patient_fridge_corrections import reserved
            quantity = reserved(patient, medicine)
        elif target_id and kind in {'receipt', 'allocation'}:
            claim = m.EvidencijaSaglasnostiZaprimanja.objects.get(pk=target_id, pacijent=patient)
            quantity = inventory.allocation_quantity(claim)
        elif target_id and kind == 'issue':
            quantity = m.KucnoIzdavanje.objects.get(pk=target_id, pacijent=patient).efektivna_kolicina
        if kind != 'receipt_date':
            self.fields['quantity'] = forms.DecimalField(label=f'Tačno — {medicine.jedinice_zalihe[0]}',
                min_value=0, max_digits=8, decimal_places=0, initial=quantity,
                widget=forms.NumberInput(attrs={'step': 1, 'min': 0}))
        if kind == 'patient_stock':
            from patients.patient_fridge_corrections import sources, approvals
            self.fields['quantity'].label = f'Nova količina za ovog pacijenta u frižideru — {medicine.jedinice_zalihe[0]}'
            self.fields['source_mode'] = forms.ChoiceField(label='Je li dodatna količina već uračunata u ukupnu zalihu ambulante?', choices=[
                ('', 'Odaberite nakon provjere'), ('EXISTING', 'Da — dodijeli iz postojeće zalihe, bez povećavanja ukupne količine'),
                ('UNRECORDED', 'Ne — fizički postoji, ali nije evidentirana u ukupnoj zalihi')])
            options = [(str(tx.pk), f'{tx.datum:%d.%m.%Y.} · slobodno iz izvora {n:g} · serija {tx.serija or "nije dokumentovana"} · {tx.get_tip_display()} · {tx.napomena}') for tx, n in sources(medicine)]
            self.fields['source_movement'] = forms.ChoiceField(label='Izvor postojeće bočice (samo za već evidentiranu zalihu)',
                required=False, choices=[('', 'Jedini dokazani izvor bira se automatski')]+options,
                initial=options[0][0] if len(options) == 1 else None)
            self.fields['approval'] = forms.ChoiceField(label='Komisijsko odobrenje za ovu dodjelu', required=False,
                choices=[('', 'Automatski ako postoji jedno važeće odobrenje')]+[(str(c.pk),
                    f'{c.broj_saglasnosti} · {c.datum_odobrenja:%d.%m.%Y.} · preostalo {c.preostale_doze:g}') for c in approvals(patient, medicine)])
            self.fields['counted_total'] = forms.DecimalField(label='Prebrojana ukupna zaliha ambulante (samo za neevidentiranu količinu)',
                required=False, min_value=0, max_digits=8, decimal_places=0)
            self.fields['actual_count'] = forms.BooleanField(required=False,
                label='Dodatna količina je stvarno prebrojana i nije ranije evidentirana u ukupnoj zalihi.')
            self.fields['batch'] = forms.CharField(label='Serija neevidentirane količine (ako je poznata)', required=False, max_length=100)
            self.fields['expires'] = forms.DateField(label='Rok neevidentirane količine (ako je poznat)', required=False,
                widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
        if kind == 'issue':
            self.fields['actual_handover'] = forms.BooleanField(label='Provjerena je stvarna predaja: razlika je pogrešan unos. Umanjene jedinice nikada nisu predate pacijentu.')
        if kind == 'receipt' and target_id:
            claim = m.EvidencijaSaglasnostiZaprimanja.objects.get(pk=target_id, pacijent=patient)
            for item in claim.fizicka_transakcija.raspodjele_prijema.exclude(pk=target_id).select_related('pacijent'):
                self.fields['allocation_'+str(item.pk)] = forms.DecimalField(
                    label=f'Isti prijem — količina za {item.pacijent}', min_value=0, max_digits=8,
                    decimal_places=0, initial=inventory.allocation_quantity(item),
                    help_text='Pregled i jedna potvrda obuhvataju sve navedene pacijente; njihova prava ostaju zasebna.')
        if kind in {'receipt', 'issue'}:
            from patients.patient_correction_workspace import source_options
            others = [(str(pk), label) for pk, label in source_options(patient, medicine, kind) if pk != target_id]
            if others:
                self.fields['duplicate_id'] = forms.ChoiceField(label='Drugi zapis koji ostaje sačuvan', required=False,
                    choices=[('', 'Ovo nije poništenje duplikata')]+others)
                self.fields['duplicate_confirmed'] = forms.BooleanField(required=False,
                    label='Dokazano je da oba zapisa predstavljaju isti stvarni događaj. Dokaz je opisan u razlogu; količina duplikata je 0.')
        if kind in {'stock', 'return', 'writeoff', 'receipt_date'}:
            initial = timezone.localdate()
            if kind == 'receipt_date' and target_id:
                initial = inventory.receipt_date(m.EvidencijaSaglasnostiZaprimanja.objects.get(pk=target_id).fizicka_transakcija)
            self.fields['event_date'] = forms.DateField(label='Datum stvarnog događaja', initial=initial,
                widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
        if kind == 'stock':
            lots = list(lot_balances(medicine).items())
            choices = [(json.dumps([batch, str(expiry) if expiry else ''], ensure_ascii=False),
                f'{batch} · rok {expiry or "nije dokumentovan"} · evidentirano {amount:g} {medicine.jedinice_zalihe[0]}')
                for (batch, expiry), amount in lots if batch]
            if choices:
                self.fields['lot'] = forms.ChoiceField(label='Koja je serija prebrojana?', choices=[('', 'Odaberite seriju')] + choices,
                    initial=choices[0][0] if len(choices) == 1 else None)
            self.fields['cause'] = forms.ChoiceField(label='Uzrok razlike', choices=[
                ('COUNT_UNKNOWN', 'Razlika pri popisu — uzrok za provjeru'), ('INITIAL_ERROR', 'Pogrešno početno stanje')])
        if kind == 'writeoff':
            self.fields['batch'] = forms.CharField(label='Serija', required=False, max_length=100)
            self.fields['expires'] = forms.DateField(label='Rok trajanja', required=False,
                widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
        if kind == 'return':
            self.fields['actual_return'] = forms.BooleanField(label='Pacijent je stvarno vratio ove jedinice. Preuzimaju se u karantin, bez odobravanja ponovne upotrebe.')
        if kind == 'transfer':
            self.fields['recipient'] = forms.ModelChoiceField(label='Pacijent koji preuzima zaduženje',
                queryset=m.Pacijent.objects.filter(aktivan=True, lijek=medicine).exclude(pk=patient.pk).order_by('prezime', 'ime'))
            self.fields['recipient_approval'] = forms.ChoiceField(label='Odobrenje primaoca, ako ih ima više', required=False,
                choices=[('', 'Automatski ako postoji samo jedno odgovarajuće odobrenje')])
            raw = self.data.get('recipient') if self.is_bound else None
            if raw and str(raw).isdecimal():
                self.fields['recipient_approval'].choices += [(str(c.pk), f'{c.pacijent} · {c.broj_saglasnosti} · {c.datum_odobrenja:%d.%m.%Y.} · preostalo {c.preostale_doze:g}')
                    for c in m.Komisija.objects.filter(pacijent_id=raw, lijek=medicine).select_related('pacijent') if c.je_vazeca()]
        self.fields['reason'] = forms.CharField(label='Razlog ispravke', min_length=5, max_length=500,
            widget=forms.Textarea(attrs={'rows': 2}))
        self.fields['expected_stock'] = forms.DecimalField(label='Očekivana ukupna zaliha ambulante (opciona provjera)',
            required=False, min_value=0, max_digits=8, decimal_places=0,
            help_text='Nije novi promet. Ako unesete vrijednost, mora odgovarati automatski izračunatoj posljedici.')
