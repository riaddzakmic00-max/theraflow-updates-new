"""Patient-card entry points delegate to the existing reviewed business services."""
from urllib.parse import urlencode
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.http import Http404
from django.urls import reverse
from django.views.decorators.http import require_GET
from patients import models as m
from patients.quick_changes import authorize
from .correction_center_views import center_url


def protocol_navigation(patient, kind):
    if kind not in ('interval', 'dose'):
        return None
    phase = patient.aktivni_fazni_protokol()
    editor = reverse('uredi_individualni_protokol', args=[patient.pk])
    label = 'Uredi interval ovog koraka protokola' if kind == 'interval' else 'Uredi dozu ovog koraka protokola'
    if not phase:
        from patients.individual_protocols import get_current_step
        step = get_current_step(patient)
        if not step or step.faza == step.FAZA_ODRZAVANJE:
            return None
        return dict(current=step.get_faza_display(), explanation='Indukcija ima zasebne korake. Otvorite konkretni nalog umjesto promjene cijelog protokola.',
            choices=[dict(title=str(step), label=label, url=editor+'?'+urlencode({'focus':kind,'step_id':step.pk})+'#protocol-editor')])
    current = phase.get_faza_display()
    choices = []
    if phase.faza == phase.FAZA_CEKA_IV and kind == 'dose':
        choices.append(dict(title='IV indukcija', label=label, url=editor+'?focus=dose&protocol_step=iv#phase-focus'))
    else:
        if phase.faza == phase.FAZA_CEKA_IV:
            choices.append(dict(title='SC održavanje', label=label,
                url=editor+'?focus=interval&protocol_step=maintenance#phase-focus'))
        else:
            choices.append(dict(title='SC održavanje', label=label,
                url=reverse('brza_izmjena_pacijenta',args=[patient.pk,kind])+'?protocol_step=maintenance'))
    explanation = 'Odabrani korak se uređuje uz pregled posljedica i nalog ljekara.'
    if phase.faza == phase.FAZA_CEKA_PRVU_SC:
        explanation = ('Prva SC doza je zaseban potvrđeni prelazni korak: 90 mg, 8 sedmica nakon stvarne IV primjene. '
            'Nalog održavanja ne mijenja prvu SC dozu ni njen termin i aktivira se u fazi održavanja.')
        choices.insert(0, dict(title='Prva SC doza / prelazni korak', label='Pregledaj ovaj korak protokola',
            url=reverse('patient_card_action',args=[patient.pk,'phase_step'])+'?focus='+kind+'#phase-focus'))
    elif phase.faza == phase.FAZA_CEKA_IV and kind == 'interval':
        explanation = 'IV indukcija je jednokratna. Interval se uređuje za SC održavanje; prelaz na prvu SC dozu ostaje zaseban korak.'
    return dict(current=current, explanation=explanation, choices=choices)


@login_required
@require_GET
def patient_action(request, pacijent_id, action):
    authorize(request.user)
    patient = get_object_or_404(m.Pacijent.objects.select_related('lijek'), pk=pacijent_id)
    medicine = patient.lijek
    if request.GET.get('medicine'):
        from patients.patient_correction_workspace import medicines
        medicine = next((item for item in medicines(patient) if str(item.pk)==request.GET['medicine']), None)
        if medicine is None:
            raise Http404('Prezentacija ne pripada ovom kartonu.')
    if action == 'phase_step':
        kind=request.GET.get('focus','interval')
        if kind not in ('dose','interval'):
            raise Http404('Nepoznata fazna radnja.')
        phase=patient.aktivni_fazni_protokol()
        if not phase or phase.faza != phase.FAZA_CEKA_PRVU_SC:
            return redirect(reverse('brza_izmjena_pacijenta',args=[patient.pk,kind]))
        return render(request,'dashboard/uredi_fazni_protokol.html',dict(pacijent=patient,
            focus=kind,step='first_sc',read_only=True,phase_label=phase.get_faza_display(),
            next_url=reverse('brza_izmjena_pacijenta',args=[patient.pk,kind])+'?protocol_step=maintenance'))
    if action in ('interval','dose'):
        return redirect(reverse('brza_izmjena_pacijenta',args=[patient.pk,action]))
    if action == 'appointment':
        from patients.appointment_reschedule import scheduled
        appointment = scheduled(patient).first()
        if appointment:
            url=reverse('nurse_correction',args=['appointment'])+'?'+urlencode({'appointment_id':appointment.pk})
            return redirect(center_url(url,patient,appointment.lijek))
        return render(request,'dashboard/patient_action_next.html',dict(patient=patient,
            title='Promijeni zakazani termin', explanation='Pacijent nema postojeći planirani termin. Prvo potvrdite ili zakažite odgovarajući korak terapijskog plana.',
            next_url=reverse('novi_termin_pacijent',args=[patient.pk]),next_label='Zakaži novi termin ovog pacijenta'))
    if action in ('corrections','events'):
        url=center_url(patient=patient,medicine=medicine)
        return redirect(url+('&' if '?' in url else '?')+urlencode({'section':action,'from_card':'1'}))
    if action == 'allocate':
        return redirect(reverse('patient_add_allocation',args=[patient.pk]) + ('?'+urlencode({'medicine':medicine.pk}) if medicine else ''))
    if action == 'reservation':
        if not request.GET.get('medicine'):
            from patients.patient_allocations import allocation_rows
            rows = allocation_rows(patient)
            if len(rows) > 1:
                choices = [dict(title=row['medicine'].prikaz_naziv, quantity=row['quantity'], route=row['route'],
                    url=center_url(reverse('nurse_correction',args=['reservation']),patient,row['medicine'])) for row in rows]
                return render(request,'dashboard/patient_action_next.html',dict(patient=patient,
                    title='Ispravi zaduženje', explanation='Odaberite zasebnu prezentaciju. IV i SC zaduženja mogu postojati istovremeno.',choices=choices))
        if not medicine:
            return redirect(reverse('uredi_individualni_protokol',args=[patient.pk]))
        return redirect(center_url(reverse('nurse_correction',args=['reservation']),patient,medicine))
    raise Http404('Nepoznata akcija kartona.')
