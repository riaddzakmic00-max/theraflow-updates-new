from datetime import date
from io import BytesIO
import logging

from django import forms
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import DatabaseError
from django.http import FileResponse, HttpResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods

from patients import models as m
from patients import inventory_corrections as service
from .permissions import je_admin, je_sestra_ili_admin, je_terapijski_tim

from .correction_center_views import render_in_center as render

logger = logging.getLogger(__name__)


class InventoryCorrectionForm(forms.Form):
    def __init__(self, *args, kind, target, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['event_date'] = forms.DateField(label='Datum stvarnog događaja',
            initial=service.receipt_date(target) if kind in {'receipt', 'receipt_date', 'receipt_metadata'} else getattr(target, 'datum', timezone.localdate()),
            disabled=kind == 'receipt_metadata',
            widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
        if kind not in {'receipt_date', 'receipt_metadata'}:
            current = (service.receipt_quantity(target) if kind == 'receipt' else
                       target.efektivna_kolicina if kind == 'issue' else None)
            self.fields['quantity'] = forms.DecimalField(label='Nova ispravna količina' if kind in {'receipt', 'issue'} else 'Količina stvarnog događaja',
                min_value=0, max_digits=8, decimal_places=0, initial=current,
                help_text='Pojedinačne jedinice lijeka. Stvarna količina se ne zaokružuje na pakovanje.')
        if kind == 'receipt':
            claims = list(target.raspodjele_prijema.select_related('pacijent'))
            from .receipt_display import full_shipment_reference
            if len(claims) > 1 or full_shipment_reference(target) or service.has_commission_receipt_identity(target):
                for claim in claims:
                    self.fields[f'allocation_{claim.pk}'] = forms.DecimalField(
                        label=f'{claim.pacijent} — ispravna količina prijema, raspodjela #{claim.pk}',
                        min_value=0, max_digits=8, decimal_places=0, initial=service.allocation_quantity(claim))
        if kind == 'receipt_metadata':
            metadata = service.receipt_metadata(target)
            self.fields['shipment_reference'] = forms.CharField(label='Otpremnica', max_length=100,
                required=False, initial=metadata['reference'], disabled=bool(metadata['reference']))
            self.fields['batch'] = forms.CharField(label='Serija', max_length=100,
                required=False, initial=metadata['batch'], disabled=bool(metadata['batch']))
            self.fields['expires'] = forms.DateField(label='Rok trajanja', required=False,
                initial=metadata['expires'] or None, disabled=bool(metadata['expires']),
                widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
                help_text='Unesite stvarno dokumentovani datum. Dopuna ne potvrđuje upotrebljivost niti mijenja serije zalihe.')
        if kind == 'issue':
            self.fields['actual_handover'] = forms.BooleanField(label='Provjerio/la sam stvarnu predaju: razlika je pogrešan unos; jedinice koje umanjujem nikad nisu predate pacijentu. Stvaran povrat unosim zasebno.')
        if kind in {'receipt', 'issue'}:
            self.fields['duplicate_id'] = forms.IntegerField(label='Samo za duplikat: ID drugog zapisa koji ostaje', min_value=1, required=False)
            self.fields['duplicate_confirmed'] = forms.BooleanField(label='Imam dokaz da oba zapisa predstavljaju isti stvarni događaj; razlog ispod opisuje taj dokaz.', required=False)
        if kind in {'return', 'writeoff'}:
            self.fields['batch'] = forms.CharField(label='Serija', required=kind == 'return', max_length=100,
                initial=getattr(target, 'serija', ''), help_text='Prazno kod otpisa znači nedokumentovana serija, ne bilo koja serija.')
        if kind == 'writeoff':
            self.fields['expires'] = forms.DateField(label='Rok trajanja te serije', required=False,
                widget=forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'))
        if kind == 'return':
            self.fields['actual_return'] = forms.BooleanField(label='Pacijent je stvarno vratio navedene jedinice. Preuzimaju se u karantin, bez odobravanja ponovne upotrebe.')
        self.fields['reason'] = forms.CharField(label='Razlog / dokaz ispravke', min_length=5, max_length=500,
            widget=forms.Textarea(attrs={'rows': 3}))

    def service_data(self):
        data = dict(self.cleaned_data)
        data['allocations'] = {key.removeprefix('allocation_'): str(value)
                               for key, value in data.items() if key.startswith('allocation_')}
        return data


@login_required
@never_cache
@require_http_methods(['GET', 'POST'])
def correct_inventory(request, kind, target_id):
    service.authorize(request.user, kind)
    try:
        target, medicine = service.target_context(kind, target_id)
    except service.CorrectionBlocked as exc:
        raise Http404(str(exc)) from exc
    initial = {}
    reverse_of = request.GET.get('reverse_of')
    previous = None
    if reverse_of:
        if not reverse_of.isdecimal():
            raise Http404
        previous = get_object_or_404(m.PatientDataCorrection, pk=reverse_of, scope='inventory_'+kind)
        if previous.posljedice.get('target_id') != target_id:
            raise Http404
        initial = {'quantity': previous.posljedice.get('before'),
                   'reason': f'Nova provjera povrata ispravke #{previous.pk}: '}
    action = request.POST.get('action')
    form = InventoryCorrectionForm(request.POST if action == 'preview' else None,
                                   kind=kind, target=target, initial=initial)
    plan = token = None
    if request.method == 'POST':
        try:
            if action == 'confirm':
                if request.POST.get('confirmed') != 'yes':
                    raise service.CorrectionBlocked('Potvrdite pregled konkretnih povezanih promjena.')
                receipt, _ = service.confirm(request.POST.get('token', ''), request.user, kind=kind, target_id=target_id)
                return redirect('inventory_correction_receipt', receipt_id=receipt.pk)
            if action == 'preview' and form.is_valid():
                data = form.service_data()
                if previous:
                    data['reverse_of'] = previous.pk
                plan, token = service.make_preview(kind, target_id, data, request.user)
        except (service.CorrectionBlocked, ValidationError, ValueError) as exc:
            form.cleaned_data = getattr(form, 'cleaned_data', {})
            form.add_error(None, ' '.join(exc.messages) if isinstance(exc, ValidationError) else str(exc))
        except DatabaseError:
            logger.exception('Inventory correction database failure')
            form.cleaned_data = getattr(form, 'cleaned_data', {})
            form.add_error(None, 'Baza je zauzeta ili nedostupna. Ponovite pregled; ponavljanje iste potvrde ne knjiži drugi put.')
    metadata = service.receipt_metadata(target) if kind == 'receipt_metadata' else None
    return render(request, 'dashboard/inventory_correction.html', {'kind': kind, 'title': service.KINDS[kind],
        'target': target, 'medicine': medicine, 'form': form, 'preview': plan, 'preview_token': token,
        'previous': previous, 'metadata': metadata,
        'batch': metadata['batch'] if metadata else getattr(target, 'serija', ''),
        'expires': (date.fromisoformat(metadata['expires']) if metadata and metadata['expires'] else
                    getattr(target, 'rok_trajanja', None))})


def permitted_receipt(receipt_id, user):
    receipt = get_object_or_404(m.PatientDataCorrection.objects.select_related('korisnik', 'pacijent'), pk=receipt_id)
    if not receipt.scope.startswith('inventory_'):
        raise Http404
    if not (user.is_active and je_terapijski_tim(user)):
        raise PermissionDenied
    return receipt


@login_required
@never_cache
@require_http_methods(['GET'])
def correction_receipt(request, receipt_id):
    receipt = permitted_receipt(receipt_id, request.user)
    plan = receipt.posljedice
    return render(request, 'dashboard/inventory_correction_receipt.html', {'receipt': receipt, 'plan': plan,
        'can_reverse': je_sestra_ili_admin(request.user) and plan['kind'] in {'receipt', 'issue', 'receipt_date'}})


def render_receipt_pdf(receipt):
    from html import escape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from .pdf_overlay import register_pdf_fonts
    # A correction receipt is composed from the saved audit, never from a new POST.
    register_pdf_fonts()
    styles = getSampleStyleSheet()
    for name in ('Normal', 'Title', 'Heading2'):
        styles[name].fontName = 'DejaVuSans'
    p = lambda text: Paragraph(escape(str(text)), styles['Normal'])
    plan = receipt.posljedice
    stream = BytesIO()
    story = [Paragraph(f'Ispravka #{receipt.pk}', styles['Title']), p(plan['title']),
        p(plan['medicine']), p(f"Korisnik: {receipt.korisnik} · Sačuvano: {timezone.localtime(receipt.kreirano):%d.%m.%Y. %H:%M}"),
        p(f"Datum stvarnog događaja: {receipt.datum_dogadjaja}"), p(f'Razlog: {receipt.razlog}'), Spacer(1, 12)]
    rows = [[p('Podatak'), p('Prije'), p('Poslije')]]
    rows += [[p(row['label']), p(row['before']), p(row['after'])] for row in plan['rows']]
    table = Table(rows, colWidths=[255, 115, 115], repeatRows=1)
    table.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), .4, colors.grey), ('VALIGN', (0, 0), (-1, -1), 'TOP')]))
    story.append(table)
    story += [Spacer(1, 12)] + [p(text) for text in plan['impacts'] + plan['warnings']]
    SimpleDocTemplate(stream, title=f'TheraFlow ispravka {receipt.pk}').build(story)
    stream.seek(0)
    return stream


@login_required
@never_cache
@require_http_methods(['GET'])
def print_correction_receipt(request, receipt_id):
    receipt = permitted_receipt(receipt_id, request.user)
    try:
        stream = render_receipt_pdf(receipt)
    except Exception:
        logger.exception('Correction receipt PDF failed; saved correction=%s', receipt.pk)
        return HttpResponse('Ispravka je već sačuvana. Štampa trenutno nije dostupna; ponovite samo štampu iz historije, bez ponovnog knjiženja.', status=503)
    return FileResponse(stream, content_type='application/pdf', filename=f'ispravka-{receipt.pk}.pdf')


@login_required
@never_cache
@require_http_methods(['GET'])
def correction_center(request):
    if not (request.user.is_active and je_admin(request.user)):
        raise PermissionDenied('Kontrola i ispravke dostupne su administratoru.')
    return render(request, 'dashboard/correction_center.html', {
        'corrections': m.PatientDataCorrection.objects.filter(scope__startswith='inventory_').select_related('korisnik')[:50],
        'physical': m.PhysicalStockCorrection.objects.select_related('lijek', 'korisnik')[:30],
        'patients': m.PatientDataCorrection.objects.exclude(scope__startswith='inventory_').select_related('pacijent', 'korisnik')[:30],
        'diagnostics_enabled': getattr(settings, 'ADMIN_DIAGNOSTICS_ENABLED', True)})


@login_required
@never_cache
@require_http_methods(['GET'])
def medicine_correction_history(request, medicine_id):
    if not (request.user.is_active and je_terapijski_tim(request.user)):
        raise PermissionDenied
    medicine = get_object_or_404(m.Lijek, pk=medicine_id)
    from patients.stock_lots import lot_balances
    movements = list(m.ZalihaTransakcija.objects.filter(lijek=medicine, tip='ZAPRIMANJE')
        .select_related('pacijent').order_by('-datum', '-pk')[:100])
    for tx in movements:
        tx.effective_quantity, tx.effective_date = service.receipt_quantity(tx), service.receipt_date(tx)
        service.annotate_receipt_metadata(tx)
    return render(request, 'dashboard/medicine_corrections.html', {
        'medicine': medicine, 'lots': [{'batch': batch, 'expires': expiry, 'quantity': qty}
            for (batch, expiry), qty in lot_balances(medicine).items()],
        'movements': movements,
        'can_correct': je_sestra_ili_admin(request.user),
        'issues': m.KucnoIzdavanje.objects.filter(lijek=medicine).select_related('pacijent').order_by('-datum', '-pk')[:100]})
