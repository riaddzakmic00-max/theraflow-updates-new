import logging
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import DatabaseError
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.http import Http404
from urllib.parse import urlencode
from django.views.decorators.http import require_http_methods
from patients import retrospective_events as events
from patients.models import RetrospectiveEvent
from .retrospective_forms import EventForm, LotFormSet

from .correction_center_views import render_in_center as render

logger = logging.getLogger(__name__)


def error_message(exc):
    if isinstance(exc, ValidationError):return ' '.join(exc.messages)
    if isinstance(exc, (events.CorrectionBlocked, ValueError)):return str(exc)
    logger.exception('Naknadni unos nije završen; transakcija je vraćena.')
    return ('Postupak nije završen. Povezane promjene nisu sačuvane djelimično. '
            'Provjerite dostupnost baze i sigurnosne kopije pa ponovite pregled. '
            'Ako je veza prekinuta nakon potvrde, provjerite historiju ili ponovite istu potvrdu; unos se neće udvostručiti.')


@login_required
@require_http_methods(['GET','POST'])
def index(request, patient_context=None, medicine_context=None):
    events.authorize(request.user)
    args = request.POST if request.method == 'POST' else request.GET
    detailed = args.get('flow') == 'detailed' or args.get('batch_id') or args.get('action','').startswith('batch-')
    if args.get('entry_mode') in ('september_pending', 'explicit_effects') or (not detailed and
            (args.get('reconstruction') == 'september2026' or
             not args.get('batch_patient') and not (args.get('kind') or args.get('event_kind')))):
        from .retrospective_simple_views import simple_entry
        return simple_entry(request,patient_context)
    kind = request.POST.get('kind') or request.GET.get('event_kind' if patient_context else 'kind')
    if patient_context and not kind:
        from .retrospective_batch_views import patient_flow
        return patient_flow(request,patient_context)
    if not patient_context and request.GET.get('batch_patient'):
        from patients.models import Pacijent
        patient=get_object_or_404(Pacijent,pk=request.GET['batch_patient'])
        return redirect(reverse('ispravi_podatke_pacijenta',args=[patient.pk])+'?intent=missing')
    context = {'kinds':RetrospectiveEvent.KINDS,'step':1,'recent':RetrospectiveEvent.objects.select_related('patient','medicine','user')[:25]}
    if not patient_context and not kind:
        from patients.models import Pacijent
        context['batch_patients']=Pacijent.objects.filter(lijek__isnull=False).order_by('prezime','ime')
    if patient_context:
        home = medicine_context.kucna_terapija and not medicine_context.oralna_terapija
        allowed = {'receipt', 'home' if home else 'therapy'}
        if medicine_context.oralna_terapija:
            allowed = {'receipt'}
        if kind and kind not in allowed:
            raise Http404('Ovaj događaj nije primjenjiv za odabranu terapiju.')
        context.update(patient_context=patient_context,
            workspace_url=reverse('ispravi_podatke_pacijenta',args=[patient_context.pk]),
            kinds=[x for x in RetrospectiveEvent.KINDS if x[0] in allowed],
            recent=RetrospectiveEvent.objects.filter(patient=patient_context).select_related('patient','medicine','user')[:25])
    if kind not in events.TITLES:return render(request,'dashboard/retrospective_events.html',context)
    form = EventForm(request.POST if request.method=='POST' else None,kind=kind,initial=request.GET.dict(),
        patient_context=patient_context, medicine_context=medicine_context)
    lots = LotFormSet(request.POST if request.method=='POST' else None,prefix='lots') if kind=='receipt' else None
    context.update(form=form,lots=lots,kind=kind,title=events.TITLES[kind],step=2)
    if request.method=='POST':
        try:
            if request.POST.get('action')=='refresh':
                return render(request,'dashboard/retrospective_events.html',context)
            if request.POST.get('action')=='confirm':
                events.require(request.POST.get('confirmed')=='yes','Potvrdite da ste pregledali posljedice naknadnog unosa.')
                if patient_context:
                    payload = events._payload(request.POST.get('token',''), request.user, 'create')
                    events.require(payload['data']['patient_id'] == patient_context.pk, 'Potvrda ne pripada ovom kartonu.')
                event,_ = events.confirm(request.POST.get('token',''),request.user)
                if patient_context:
                    return redirect(context['workspace_url']+'?'+urlencode({'intent':'missing','event_id':event.pk}))
                return redirect('retrospective_detail',event_id=event.pk)
            if form.is_valid() and (lots is None or lots.is_valid()):
                data = form.event_data()
                if lots is not None:data['lots'] = [d for d in lots.cleaned_data if d and not d.get('DELETE')]
                plan,token = events.make_preview(data,request.user)
                context.update(plan=plan,token=token,step=3)
        except Exception as exc:
            context['error'] = error_message(exc)
    return render(request,'dashboard/retrospective_events.html',context)


@login_required
@require_http_methods(['GET','POST'])
def detail(request,event_id,patient_context=None):
    events.authorize(request.user)
    event = get_object_or_404(RetrospectiveEvent.objects.select_related('patient','medicine','user','reversed_by'),pk=event_id)
    if patient_context and event.patient_id != patient_context.pk:
        raise Http404
    context = {'event':event,'step':4,'plan':event.effects.get('preview')}
    if patient_context:
        context.update(patient_context=patient_context,
            workspace_url=reverse('ispravi_podatke_pacijenta',args=[patient_context.pk]))
    if request.method=='POST':
        return redirect('event_reversal',kind='retrospective',object_id=event.pk)
    return render(request,'dashboard/retrospective_detail.html',context)
