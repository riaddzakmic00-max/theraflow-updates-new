from django.db import connection, DatabaseError
from django.http import HttpResponse


class MaintenanceMiddleware:
    """UI gate; database triggers also cover GET side effects and all workers."""
    def __init__(self, get_response):
        self.get_response = get_response

    @staticmethod
    def unavailable():
        response = HttpResponse('TheraFlow se ažurira. Unos je privremeno zaustavljen do provjere aplikacije ili završenog povrata.', status=503, content_type='text/plain; charset=utf-8')
        response['Retry-After'] = '30'
        return response

    def process_exception(self, request, exception):
        # A request can pass middleware before the barrier commits and write
        # afterward. Database enforcement still wins; return 503, not HTTP 500.
        cause = getattr(exception, '__cause__', None)
        if isinstance(exception, DatabaseError) and getattr(cause, 'pgcode', None) == '55000':
            return self.unavailable()
        return None

    def __call__(self, request):
        # Update control plane and read-only service health must remain reachable.
        if request.path in ('/updates/status/', '/updates/install/', '/updates/rollback/') or request.path.startswith(('/health/', '/static/')):
            return self.get_response(request)
        if request.method in ('GET', 'HEAD') and request.path == '/postavke-sistema/':
            return self.get_response(request)
        try:
            with connection.cursor() as cur:
                cur.execute("SELECT to_regclass('tf_update_control.barrier')")
                exists = cur.fetchone()[0]
                active = False
                if exists:
                    cur.execute('SELECT active FROM tf_update_control.barrier')
                    state = cur.fetchone()
                    active = bool(state and state[0])
        except DatabaseError:
            active = True  # Schema switch/DB failure is not permission to write.
        if active:
            return self.unavailable()
        return self.get_response(request)
