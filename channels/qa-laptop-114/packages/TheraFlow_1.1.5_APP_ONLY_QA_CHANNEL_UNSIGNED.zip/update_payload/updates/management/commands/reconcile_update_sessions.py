from django.core.management.base import BaseCommand, CommandError

from updates.models import UpdateSession
from updates.services.crash_recovery import reconcile_active_sessions


class Command(BaseCommand):
    help = "Transakcijski rekoncilira aktivne durable update sesije."

    def add_arguments(self, parser):
        parser.add_argument(
            "--post-health",
            action="store_true",
            help=(
                "Dozvoli usku verifikaciju legacy update_completed kontradikcije "
                "tek nakon što su health-check i sva četiri servisa potvrđeni."
            ),
        )

    def handle(self, *args, **options):
        before = UpdateSession.objects.filter(is_active=True).count()
        results = reconcile_active_sessions(
            allow_completed_repair=bool(options.get("post_health"))
        )
        failed = UpdateSession.objects.filter(
            pk__in=[session_id for session_id, _state in results],
            status=UpdateSession.UPDATER_SERVICE_FAILED,
            is_active=False,
        ).count()
        remaining = UpdateSession.objects.filter(is_active=True).count()
        unresolved_completed = UpdateSession.objects.filter(
            is_active=True,
            status=UpdateSession.UPDATE_COMPLETED,
        ).count()
        if options.get("post_health") and unresolved_completed:
            raise CommandError(
                "POST_HEALTH_UPDATE_FINALIZATION_FAILED "
                f"unresolved_completed={unresolved_completed}"
            )
        self.stdout.write(
            self.style.SUCCESS(
                "UPDATE_SESSION_RECONCILIATION_PASS "
                f"examined={before} terminalized_preapply={failed} active_remaining={remaining}"
            )
        )
