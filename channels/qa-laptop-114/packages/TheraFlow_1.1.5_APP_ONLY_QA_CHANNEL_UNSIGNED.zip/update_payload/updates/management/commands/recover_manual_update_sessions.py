from django.core.management.base import BaseCommand, CommandError

from updates.models import UpdateSession
from updates.services.crash_recovery import recover_manual_file_rollbacks
from updates.updater.state_writer import safe_message, trace_update_step


class Command(BaseCommand):
    help = (
        "Dovršava samo dokazano sigurne file-only manual recovery sesije nakon "
        "in-place repaira."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--maintenance-window",
            action="store_true",
            help=(
                "Terminalizuje dokazani rollback dok su aplikacijski servisi "
                "zaustavljeni; installer zatim pokreće finalni service/health gate."
            ),
        )

    def handle(self, *args, **options):
        before = UpdateSession.objects.filter(
            is_active=True,
            status=UpdateSession.MANUAL_RECOVERY_REQUIRED,
        ).count()
        try:
            results = recover_manual_file_rollbacks(
                maintenance_window=bool(options.get("maintenance_window")),
            )
        except Exception as exc:
            code = getattr(exc, "code", None) or "manual_update_recovery_failed"
            failed_step = getattr(exc, "failed_step", None) or "rollback_recovery"
            trace_update_step(
                "rollback_recovery_command",
                "FAIL",
                function_name=(
                    "updates.management.commands.recover_manual_update_sessions.handle"
                ),
                exception=exc,
                message=f"error_code={code} failed_step={failed_step}",
            )
            raise CommandError(
                "MANUAL_UPDATE_RECOVERY_FAIL "
                f"exception_type={type(exc).__name__} "
                f"error_code={code} failed_step={failed_step} "
                f"safe_message={safe_message(exc)} traceback_logged=true"
            ) from exc
        remaining = UpdateSession.objects.filter(
            is_active=True,
            status=UpdateSession.MANUAL_RECOVERY_REQUIRED,
        ).count()
        if remaining:
            raise CommandError(
                "MANUAL_UPDATE_RECOVERY_INCOMPLETE "
                f"examined={before} recovered={len(results)} remaining={remaining}"
            )
        self.stdout.write(
            self.style.SUCCESS(
                "MANUAL_UPDATE_RECOVERY_PASS "
                f"examined={before} recovered={len(results)} remaining=0"
            )
        )
