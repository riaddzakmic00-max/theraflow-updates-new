"""Read-only business projections over existing facts, never a second ledger.

No correction helpers or write services belong here. The bounded timeline uses
bulk joins; issues describe evidence requiring review, never a clinical decision.
"""
from contextlib import contextmanager
from datetime import datetime, time
from decimal import Decimal

from django.db import connection, transaction
from django.db.models import Case, DateField, Exists, F, OuterRef, Q, Subquery, Sum, Value, When
from django.db.models.fields.json import KeyTextTransform
from django.db.models.functions import Cast, Coalesce, NullIf, TruncDate
from django.urls import reverse
from django.utils import timezone

from . import models as m
from .commission_exclusions import visible_commission_requests
from .data_corrections import serial
from .monthly_consumption import source_kind
from .therapy_history import actually_administered_therapy_query, is_actually_administered_therapy
from .therapy_timeline import EVENT_PRESENTATION, _event_type

LEVELS = {'red': 'Potrebno riješiti', 'amber': 'Potrebno provjeriti', 'green': 'Uredno'}
FINISHED = ('completed', 'aligned', 'cancelled')


@contextmanager
def read_projection():
    """Consistent read-only PG snapshot; nesting never enters correction locks.

An existing transaction owns its isolation level. In that case these pure read
queries run in it without SET TRANSACTION, row locks or a write-lock fallback.
"""
    if connection.vendor == 'postgresql' and not connection.in_atomic_block:
        with transaction.atomic():
            with connection.cursor() as cursor:
                cursor.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY')
            yield
    else:
        yield


def _at(value):
    if isinstance(value, datetime):
        return value if timezone.is_aware(value) else timezone.make_aware(value)
    return timezone.make_aware(datetime.combine(value, time.min))


def patient_url(patient_id):
    return reverse('profil_pacijenta', args=[patient_id]) + '?tab=terapije'


def session_url(session):
    section = 'absence' if session.workflow == 'absence' else 'smart'
    return reverse('correction_center') + f'?section={section}&session={session.pk}'


def quick_change_display(quick):
    """Display only named clinical facts; keep internal snapshots out of the UI."""
    if quick.poslije.get('rows'):
        return display_changes(quick.poslije['rows'])
    result = []
    for key, label in [('doza_mg', 'Doza (mg)'), ('broj_jedinica', 'Količina'),
                       ('interval_sedmica', 'Interval (sedmica)')]:
        after = quick.promjena_rezima.get(key)
        if after is not None:
            before = (quick.prije.get('regimen') or quick.prije).get(key)
            result.append(dict(label=label, before=before if before is not None else 'Pogledajte izvorni nalog', after=after))
    return result


def display_changes(value):
    rows = value.get('rows', []) if isinstance(value, dict) else value
    return [row for row in rows if isinstance(row, dict) and all(k in row for k in ('label', 'before', 'after'))]


def status_events():
    """Business date of a status event, not the date a late entry was typed."""
    def dated(lookup):
        return Cast(NullIf(KeyTextTransform.from_lookup(lookup), Value('')), DateField())
    fallback = TruncDate('datum_vrijeme')
    old_date = Coalesce(dated('prethodno_stanje__datum'), dated('prethodno_stanje__termini__0__datum'), fallback)
    return m.TerapijaStatusHistorija.objects.annotate(business_date=Case(
        When(Q(novo_stanje__tip_dogadjaja__in=['NIJE_DOSAO', 'TERMIN_ODGODJEN']) | Q(novi_status__in=[m.Termin.STATUS_NIJE_DOSAO, m.Termin.STATUS_ODGODJENA]), then=old_date),
        When(novo_stanje__tip_dogadjaja='TERAPIJA_PAUSIRANA', then=Coalesce(dated('novo_stanje__datum_pocetka'), fallback)),
        When(novo_stanje__tip_dogadjaja='TERAPIJA_NASTAVLJENA', then=Coalesce(dated('novo_stanje__datum_nastavka'), fallback)),
        default=fallback, output_field=DateField()))


SOURCES = {'Terapija': 'Evidencija terapije', 'TerapijaStatusHistorija': 'Historija statusa',
    'KucnoIzdavanje': 'Kućno izdavanje', 'IzdavanjeOralneTerapije': 'Oralno izdavanje',
    'KucnaTerapijaPodatak': 'Podatak kućne terapije', 'Komisija': 'Komisijsko odobrenje',
    'Trebovanje': 'Komisijski zahtjev', 'ZalihaTransakcija': 'Promet zalihe',
    'PacijentRezervacija': 'Rezervacija', 'BrzaIzmjenaPacijenta': 'Odluka o terapiji / zaduženju',
    'PromjenaTerapije': 'Odluka o terapiji', 'PatientDataCorrection': 'Ispravka podataka',
    'RetrospectiveEvent': 'Naknadna evidencija', 'ReconciliationAction': 'Pametno usklađivanje',
    'AktivnostLog': 'Historija aktivnosti', 'KomisijskiZahtjev': 'Komisijski zahtjev',
    'PacijentZaduzenje': 'Zaduženje kućne terapije'}


def _event(obj, at, category, title, *, medicine=None, user=None, detail='', recorded=None, source=None):
    native_source = SOURCES[obj.__class__.__name__]
    reversal_kind = {'Terapija':'therapy', 'RetrospectiveEvent':'retrospective', 'PatientDataCorrection':'correction', 'ReconciliationAction':'smart'}.get(obj.__class__.__name__)
    already_reversed=bool(getattr(obj,'reversed_at',None) or getattr(obj,'workflow_status','')=='PONISTENA' or isinstance(obj,m.PatientDataCorrection) and obj.posljedice.get('source')=='safe_event_reversal')
    return dict(reversal_url=reverse('event_reversal', args=[reversal_kind,obj.pk]) if reversal_kind and not already_reversed else '', identity=f'{obj._meta.model_name}-{obj.pk}', at=_at(at) if at else timezone.make_aware(datetime(1900, 1, 1)), unknown_date=at is None,
                category=category, title=title, medicine=medicine,
                route=medicine.put_primjene if medicine else '',
                user=str(user) if user else 'Nije evidentirano', detail=detail,
                recorded=recorded, source=source or native_source,
                audit=[f'{native_source} #{obj.pk}'], links=[], level='green')


def patient_timeline(patient_id, *, start=None, end=None, limit=200):
    """Newest business dates first, audit recording time separately labelled.

Each source is bounded independently before the final merge. More data is
explicitly reported; users narrow dates instead of mistaking a slice for all
history. An administration is represented once even with status/late/session
audit records. Native audit references remain attached to that one event.
"""
    items, represented, by_therapy, by_issue, by_history, by_correction, by_quick = [], {}, {}, {}, {}, {}, {}
    incomplete = False

    def rows(model, date_field, related=(), predicate=None, **filters):
        nonlocal incomplete
        qs = model.objects.filter(**filters).select_related(*related)
        if model == m.PatientDataCorrection:
            qs = qs.annotate(business_date=Coalesce('datum_dogadjaja', TruncDate('kreirano')))
            date_field = 'business_date'
        elif model == m.KucnaTerapijaPodatak:
            qs = qs.annotate(business_date=Coalesce('datum_izdavanja', 'datum_primjene', TruncDate('kreirano')))
            date_field = 'business_date'
        if predicate is not None: qs = qs.filter(predicate)
        if start: qs = qs.filter(**{date_field + '__gte': start})
        if end: qs = qs.filter(**{date_field + '__lte': end})
        values = list(qs.order_by('-' + date_field, '-pk')[:limit + 1])
        incomplete |= len(values) > limit
        return values[:limit]

    def add(obj, item):
        items.append(item)
        represented[(obj.__class__.__name__, obj.pk)] = item
        return item

    for t in rows(m.Terapija, 'datum', ('lijek', 'evidentirao', 'ponistio'), pacijent_id=patient_id):
        if is_actually_administered_therapy(t):
            item = add(t, _event(t, t.datum, 'therapy', 'Stvarna primjena', medicine=t.lijek,
                user=t.evidentirao, detail=f'Količina: {t.kolicina}; doza: {t.doza_mg if t.doza_mg is not None else "nije evidentirana"} mg; faza: {t.faza_terapije_prikaz or "nije evidentirana"}.',
                source='Historijska primjena' if t.is_migration else 'Evidencija terapije'))
            by_therapy[t.pk] = item
        elif t.tip_evidencije == m.Terapija.TIP_KUCNA_TERAPIJA:
            by_therapy[t.pk] = add(t, _event(t, t.datum, 'home', 'Kućno izdavanje', medicine=t.lijek,
                user=t.evidentirao, detail=f'Količina: {t.kolicina}. Izdavanje nije dokaz stvarne primjene.'))
        if t.ponistena_at:
            if t.pk not in by_therapy and t.tip_evidencije == m.Terapija.TIP_AMBULANTA:
                by_therapy[t.pk] = add(t, _event(t,t.datum,'therapy','Originalna primjena (poništena)', medicine=t.lijek,
                    user=t.evidentirao, detail='Izvorna evidencija ostaje sačuvana; poništena primjena se ne računa u stvarne terapije.'))
            add(t, _event(t, t.ponistena_at, 'reversal', 'Poništena terapija', medicine=t.lijek,
                user=t.ponistio, detail=t.razlog_ponistavanja))

    histories = status_events().filter(pacijent_id=patient_id)
    if start: histories = histories.filter(business_date__gte=start)
    if end: histories = histories.filter(business_date__lte=end)
    histories = list(histories.select_related('korisnik', 'termin__lijek', 'terapija__lijek').order_by('-business_date', '-pk')[:limit + 1])
    incomplete |= len(histories) > limit
    for h in histories[:limit]:
        kind = _event_type(h)
        existing = by_therapy.get(h.terapija_id)
        if existing and kind in (m.TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_EVIDENTIRANA,
                                m.Terapija.STATUS_POTVRDJENA, m.TerapijaStatusHistorija.DOGADJAJ_KUCNO_IZDAVANJE):
            existing['audit'].append(f'Statusni događaj #{h.pk}')
            if existing['user'] == 'Nije evidentirano' and h.korisnik_id: existing['user'] = str(h.korisnik)
            by_history[h.pk] = existing
            continue
        medicine = h.termin.lijek if h.termin_id else h.terapija.lijek if h.terapija_id else None
        label = EVENT_PRESENTATION.get(kind, (h.get_novi_status_display() if hasattr(h, 'get_novi_status_display') else h.novi_status.replace('_', ' '),))[0].capitalize()
        item = add(h, _event(h, h.business_date, 'no_show' if kind == 'NIJE_DOSAO' else 'postponement' if kind == 'TERMIN_ODGODJEN' else 'status',
            label, medicine=medicine, user=h.korisnik, detail=h.razlog, recorded=h.datum_vrijeme))
        by_history[h.pk] = item

    for issue in rows(m.KucnoIzdavanje, 'datum', ('lijek', 'korisnik_koji_je_izdao'), pacijent_id=patient_id):
        item = by_therapy.get(issue.terapija_id)
        if item:
            item['audit'].append(f'Kućno izdavanje #{issue.pk}')
        else:
            item = add(issue, _event(issue, issue.datum, 'home', 'Kućno izdavanje', medicine=issue.lijek,
                user=issue.korisnik_koji_je_izdao, recorded=issue.kreirano,
                detail=f'Količina: {issue.kolicina}; serija: {issue.serija or "nije evidentirana"}. Izdavanje nije dokaz primjene.'))
        by_issue[issue.pk] = item
    for issue in rows(m.IzdavanjeOralneTerapije, 'datum_izdavanja', ('lijek', 'korisnik_koji_je_izdao'), pacijent_id=patient_id):
        add(issue, _event(issue, issue.datum_izdavanja, 'home', 'Oralna terapija izdana', medicine=issue.lijek,
            user=issue.korisnik_koji_je_izdao, recorded=issue.kreirano,
            detail=f'{issue.kolicina_tableta} tableta; {issue.get_status_display()}. Izdavanje nije dokaz primjene.'))
    for record in rows(m.KucnaTerapijaPodatak, 'kreirano__date', ('lijek', 'korisnik'), pacijent_id=patient_id):
        add(record, _event(record, record.datum_izdavanja or record.datum_primjene or record.kreirano,
            'home_report', record.get_vrsta_display(), medicine=record.lijek, user=record.korisnik,
            recorded=record.kreirano, detail=record.napomena + ' Izjava pacijenta nije ambulantna primjena.'))
    for approval in rows(m.Komisija, 'datum_odobrenja', ('lijek',), pacijent_id=patient_id):
        add(approval, _event(approval, approval.datum_odobrenja, 'approval', 'Odobrenje terapije',
            medicine=approval.lijek, detail=f'Odobreno: {approval.broj_odobrenih_doza}; saglasnost: {approval.broj_saglasnosti or "nije evidentirana"}; {approval.get_status_display()}.'))
    for req in rows(m.Trebovanje, 'datum_kreiranja', ('lijek', 'kreirao', 'komisijski_ciklus'), pacijent_id=patient_id):
        add(req, _event(req, req.datum_kreiranja, 'commission', 'Komisijski zahtjev', medicine=req.lijek,
            user=req.kreirao, detail=f'{req.get_status_display()}; {req.komisijski_ciklus or "bez ciklusa"}; traženo {req.broj_doza}.'))
    for req in rows(m.KomisijskiZahtjev, 'datum_kreiranja__date', ('potvrdio_korisnik', 'komisijski_ciklus'), pacijent_id=patient_id):
        add(req, _event(req, req.datum_kreiranja, 'commission', 'Komisijski zahtjev / odluka',
            user=req.potvrdio_korisnik, detail=f'{req.komisijski_ciklus}; {req.get_status_display()}. {req.napomena}'))

    # Shared physical receipts can be linked through patient distributions even
    # when the central movement deliberately has no patient FK.
    distribution_ids = m.EvidencijaSaglasnostiZaprimanja.objects.filter(pacijent_id=patient_id).values('fizicka_transakcija_id')
    movement_qs = m.ZalihaTransakcija.objects.filter(Q(pacijent_id=patient_id) | Q(pk__in=distribution_ids))
    if start: movement_qs = movement_qs.filter(datum__gte=start)
    if end: movement_qs = movement_qs.filter(datum__lte=end)
    movements = list(movement_qs.select_related('lijek', 'korisnik').order_by('-datum', '-pk')[:limit + 1])
    incomplete |= len(movements) > limit
    for tx in movements[:limit]:
        if tx.tip in ('AMBULANTNA_POTROSNJA', 'KUCNO_IZDAVANJE', 'ORALNO_IZDAVANJE'):
            # Consumption is a consequence, never another administration.
            item = by_therapy.get(tx.referenca_id) if tx.referenca_tip == 'Terapija' else by_issue.get(tx.referenca_id) if tx.referenca_tip == 'KucnoIzdavanje' else represented.get((tx.referenca_tip, tx.referenca_id))
            if item: item['audit'].append(f'Promet zalihe #{tx.pk}')
            continue
        category = 'receipt' if tx.tip == 'ZAPRIMANJE' else 'allocation' if tx.tip in ('ASSIGN_FREE_STOCK_TO_PATIENT', 'RELEASE_TO_FREE_STOCK') else 'stock'
        add(tx, _event(tx, tx.datum, category, tx.get_tip_display(), medicine=tx.lijek, user=tx.korisnik,
            recorded=tx.kreirano, detail=f'Količina: {tx.kolicina}; fizička promjena: {tx.frizider_delta()}; serija: {tx.serija or "nije evidentirana"}. {tx.napomena}'))
    for reservation in rows(m.PacijentRezervacija, 'datum_rezervacije', ('lijek',), pacijent_id=patient_id):
        add(reservation, _event(reservation, reservation.datum_rezervacije, 'allocation', 'Rezervacija / zaduženje', medicine=reservation.lijek,
            detail=f'Količina sada: {reservation.kolicina}; {"aktivno" if reservation.aktivno else "razriješeno"}. {reservation.napomena}'))
    for debt in rows(m.PacijentZaduzenje, 'datum_zaduzenja', ('lijek',), pacijent_id=patient_id):
        add(debt, _event(debt, debt.datum_zaduzenja, 'allocation', 'Zaduženje kućne terapije', medicine=debt.lijek,
            detail=f'Preostalo sada: {debt.preostalo}; {"aktivno" if debt.aktivno else "razriješeno"}. Ovo nije dokaz primjene.'))
    for quick in rows(m.BrzaIzmjenaPacijenta, 'vrijedi_od', ('lijek', 'korisnik'),
                      predicate=Q(pacijent_id=patient_id) | Q(primalac_id=patient_id)):
        # Both sides of a transfer belong to the patient history.
        if patient_id not in (quick.pacijent_id, quick.primalac_id): continue
        item = add(quick, _event(quick, quick.vrijedi_od, quick.vrsta, quick.get_vrsta_display(), medicine=quick.lijek,
            user=quick.korisnik, recorded=quick.kreirano, detail=quick.razlog))
        item['changes'] = quick_change_display(quick)
        by_quick[quick.pk] = item
    for change in rows(m.PromjenaTerapije, 'datum_odluke', ('stari_lijek', 'novi_lijek', 'izvrsio'), pacijent_id=patient_id):
        add(change, _event(change, change.datum_odluke, 'phase', 'Promjena terapije / faze', medicine=change.novi_lijek,
            user=change.izvrsio, detail=f'{change.stari_lijek} ({change.stari_lijek.put_primjene}) → {change.novi_lijek} ({change.novi_lijek.put_primjene}). {change.napomena}'))
    for correction in rows(m.PatientDataCorrection, 'datum_dogadjaja', ('korisnik',), pacijent_id=patient_id):
        administrative = isinstance(correction.posljedice, dict) and correction.posljedice.get('controlled')
        is_reversal = isinstance(correction.posljedice, dict) and correction.posljedice.get('source')=='safe_event_reversal'
        label = ('Poništen događaj' if is_reversal else 'Komisijska veza potvrđena' if correction.scope == 'commission_link' else
                 'Kontrolisana administratorska korekcija' if administrative else
                 'Poništavanje ispravke' if correction.ponistava_id else 'Ručna ispravka')
        item = add(correction, _event(correction, correction.datum_dogadjaja or correction.kreirano, 'correction',
            label, user=correction.korisnik,
            recorded=correction.kreirano, detail=correction.razlog))
        item['changes'] = display_changes(correction.posljedice)
        if is_reversal:
            item['links'].append(('Otvori originalni događaj', reverse('event_reversal', args=[correction.posljedice['original_kind'], correction.posljedice['original_id']])))
            item['audit'].append('Uloga: '+correction.posljedice['actor_role'])
        by_correction[correction.pk] = item
    for late in rows(m.RetrospectiveEvent, 'event_date', ('medicine', 'user', 'reversed_by'), patient_id=patient_id):
        item = by_therapy.get(late.therapy_id) or by_issue.get(late.issue_id)
        if item:
            item['audit'].append(f'Naknadni događaj #{late.pk}')
            item['recorded'], item['user'], item['source'] = late.created_at, str(late.user), 'Naknadna evidencija'
        else:
            item = add(late, _event(late, late.event_date, late.kind, late.get_kind_display(), medicine=late.medicine,
                user=late.user, recorded=late.created_at, detail=late.note))
        item['late_id'] = late.pk
        if late.reversed_at:
            add(late, _event(late, late.reversed_at, 'reversal', 'Poništen naknadni događaj', medicine=late.medicine,
                user=late.reversed_by, detail=late.reversal_reason))
    late_items = {item['late_id']: item for item in items if item.get('late_id')}
    action_scope = Q(session__patient_id=patient_id) | Q(appointment__pacijent_id=patient_id) | Q(event__patient_id=patient_id) | Q(data_correction__pacijent_id=patient_id) | Q(quick_change__pacijent_id=patient_id) | Q(request__pacijent_id=patient_id)
    actions = m.ReconciliationAction.objects.filter(action_scope).select_related('session', 'user').prefetch_related('status_history').order_by('-created_at', '-pk')[:limit + 1]
    actions = list(actions); incomplete |= len(actions) > limit
    for action in actions[:limit]:
        existing = late_items.get(action.event_id) or by_correction.get(action.data_correction_id) or by_quick.get(action.quick_change_id)
        if not existing:
            existing = next((by_history[h.pk] for h in action.status_history.all() if h.pk in by_history), None)
        if existing:
            existing['audit'].extend([f'Usklađivanje #{action.session_id}', f'Radnja #{action.pk}'])
            existing['session'] = action.session
        elif (not start or action.created_at.date() >= start) and (not end or action.created_at.date() <= end):
            existing = add(action, _event(action, action.created_at, 'reconciliation', 'Pametno usklađivanje', user=action.user,
                detail=f'{action.session.period_start:%d/%m/%Y} – {action.session.period_end:%d/%m/%Y}; {action.session.workflow_status_label}.'))
            existing['session'] = action.session
    # Native activity logs enrich their source events instead of copying them.
    for log in rows(m.AktivnostLog, 'datum_vrijeme__date', ('korisnik',), pacijent_id=patient_id):
        existing = represented.get((log.objekat_tip, log.objekat_id))
        if existing:
            existing['audit'].append(f'Audit #{log.pk}')
            if existing['user'] == 'Nije evidentirano' and log.korisnik_id: existing['user'] = str(log.korisnik)
        elif 'SC plan' in log.akcija or 'faza' in log.akcija.casefold():
            add(log, _event(log, log.datum_vrijeme, 'phase', log.akcija, user=log.korisnik, detail=log.opis))
    items.sort(key=lambda item: (item['at'], item['identity']), reverse=True)
    return dict(items=items[:limit], incomplete=incomplete or len(items) > limit)


def attention_items(start, end, *, admin=False, user=None, limit=500, include_open_sessions=False):
    """Current unresolved evidence in a period; correlated queries avoid N+1."""
    issues, incomplete = [], False
    def add(key, title, detail, url, level='amber'):
        issues.append(dict(key=key, title=title, detail=detail, url=url, level=level, status=LEVELS[level]))
    def take(qs):
        nonlocal incomplete
        result = list(qs[:limit + 1]); incomplete |= len(result) > limit
        return result[:limit]
    actual = actually_administered_therapy_query(m.Terapija.objects.filter(pacijent_id=OuterRef('pacijent_id'), lijek_id=OuterRef('lijek_id'), datum=OuterRef('datum')))
    terms = m.Termin.objects.filter(datum__range=(start, end)).annotate(has_actual=Exists(actual))
    terms = terms.filter(Q(status=m.Termin.STATUS_PLANIRANA) | Q(status=m.Termin.STATUS_POTVRDJENA, has_actual=False)).select_related('pacijent', 'lijek').order_by('datum', 'pk')
    for term in take(terms):
        add(f'term-{term.pk}', 'Termin zahtijeva provjeru',
            f'{term.pacijent} · {term.lijek} ({term.lijek.put_primjene}) · {term.datum:%d/%m/%Y} · ' + ('postoji primjena, status termina nije razriješen' if term.has_actual else term.get_status_display()),
            patient_url(term.pacijent_id), 'red' if term.status == m.Termin.STATUS_POTVRDJENA else 'amber')
    reservations = m.PacijentRezervacija.objects.filter(aktivno=True, kolicina__gt=0,
        termin__status__in=[m.Termin.STATUS_POTVRDJENA, m.Termin.STATUS_OTKAZANA, m.Termin.STATUS_PAUSIRANA],
        termin__datum__range=(start, end)).select_related('pacijent', 'lijek').order_by('pk')
    for r in take(reservations):
        add(f'reservation-{r.pk}', 'Zaduženje zahtijeva provjeru', f'{r.pacijent} · {r.lijek} · aktivno {r.kolicina}. Provjerite događaj prije oslobađanja.',
            (reverse('correction_allocation', args=[r.pacijent_id, r.lijek_id]) if admin else patient_url(r.pacijent_id)))
    consumption = m.ZalihaTransakcija.objects.filter(referenca_tip='Terapija', referenca_id=OuterRef('pk'),
        tip=m.ZalihaTransakcija.TIP_AMBULANTNA_POTROSNJA)
    therapies = actually_administered_therapy_query(m.Terapija.objects.filter(datum__range=(start, end), is_migration=False))
    consumed = consumption.order_by().values('referenca_id').annotate(total=Sum('kolicina')).values('total')
    for t in take(therapies.annotate(consumed_quantity=Subquery(consumed)).select_related('pacijent', 'lijek').order_by('pk')):
        if source_kind(t) != 'clinic':
            continue  # Native rule: home doses were debited at dispensing.
        if t.workflow_snapshot.get('inventory_effect') is not None and Decimal(str(t.workflow_snapshot['inventory_effect'])) == 0 and not t.workflow_snapshot.get('retrospective_pending'):
            continue  # Explicit historical application with no operational debit.
        expected = abs(Decimal(str(t.workflow_snapshot['inventory_effect']))) if t.workflow_snapshot.get('inventory_effect') is not None and not t.workflow_snapshot.get('retrospective_pending') else t.kolicina
        if t.consumed_quantity == expected: continue
        add(f'consumption-{t.pk}', 'Primjena bez povezane potrošnje' if t.consumed_quantity is None else 'Potrošnja primjene zahtijeva provjeru', f'{t.pacijent} · {t.lijek} · {t.datum:%d/%m/%Y}. Evidentirano utrošeno {t.consumed_quantity or 0}; očekivano prema događaju {expected}.', patient_url(t.pacijent_id), 'red')
    requests = visible_commission_requests(m.Trebovanje.objects.filter(
        odobrene_doze__gt=F('zaprimljene_doze'),
        status__in=['ODOBRENO', 'CEKA_ISPORUKU', 'DJELOMICNO_ODOBRENO', 'ZAPRIMLJENO'],
    ).filter(Q(komisija__datum_odobrenja__lte=end) | Q(komisijski_ciklus__datum_odobrenja__lte=end)))
    linked_receipt = m.UnlinkedStockReceipt.objects.filter(request_id=OuterRef('pk')).order_by('pk').values('pk')[:1]
    for req in take(requests.select_related('pacijent', 'lijek').annotate(administrative_receipt=Subquery(linked_receipt)).order_by('pk')):
        if req.administrative_receipt:
            add(f'receipt-{req.pk}', 'Povezani prijem — potrebna administrativna provjera',
                f'{req.pacijent} · {req.lijek}. Stvarni prijem je već evidentiran. Komisijski brojači ostaju sačuvani; ne zaprimajte istu isporuku ponovo.',
                reverse('commission_receipt_link', args=[req.administrative_receipt]) if admin else reverse('lista_zaliha'))
        else:
            add(f'receipt-{req.pk}', 'Zaprimanje zahtijeva provjeru', f'{req.pacijent} · {req.lijek} · zaprimljeno {req.zaprimljene_doze}/{req.odobrene_doze}.', reverse('zaprimanje_ciklusa', args=[req.komisijski_ciklus_id]) if req.komisijski_ciklus_id else reverse('komisijsko_zaprimanje'))
    for receipt in take(m.UnlinkedStockReceipt.objects.filter(event_date__range=(start, end), request__isnull=True).select_related('medicine').order_by('pk')):
        add(f'unlinked-{receipt.pk}', 'Prijem bez komisijske veze', f'{receipt.medicine} · {receipt.event_date:%d/%m/%Y} · +{receipt.quantity}. Komisijsko pravo nije dodano.',
            reverse('commission_receipt_link', args=[receipt.pk]) if admin else reverse('lista_zaliha'))
    session_scope = Q(period_start__lte=end, period_end__gte=start)
    if include_open_sessions: session_scope |= ~Q(status__in=FINISHED)
    sessions = m.ReconciliationSession.objects.filter(session_scope).exclude(status='cancelled')
    if user is not None: sessions = sessions.filter(user=user)
    sessions = take(sessions.select_related('patient', 'medicine').order_by('-created_at', '-pk'))
    for s in sessions:
        if s.status not in FINISHED:
            add(f'session-{s.pk}', 'Nedovršeno pametno usklađivanje', f'{s.period_start:%d/%m/%Y} – {s.period_end:%d/%m/%Y} · {s.workflow_status_label} · korak {s.current_step}.',
                session_url(s) if admin else patient_url(s.patient_id) if s.patient_id else reverse('dashboard'))
    # Reuse the existing physical-count domain projection with bulk-loaded
    # native facts, including its freshness and event-explanation rules.
    counts = [(s, int(mid), obs) for s in sessions for mid, obs in s.physical_counts.items()]
    stocks = {row.lijek_id: row for row in m.Zaliha.objects.filter(lijek_id__in={mid for _, mid, _ in counts}).select_related('lijek')} if counts else {}
    count_cards = physical_observations(counts, stocks) if counts else {}
    for s, mid, obs in counts:
        stock = stocks.get(mid); expected = stock.u_frizideru if stock else Decimal(0)
        card = count_cards[(s.pk, mid)]
        if not card['aligned']:
            add(f'physical-{s.pk}-{mid}', 'Fizički popis treba ponovo provjeriti' if card['stale'] else 'Razlika fizičkog popisa', f'{stock.lijek if stock else "Lijek"}: prebrojano {obs["counted"]}, sada očekivano {expected}. Otvorite postupak radi provjere.', session_url(s) if admin else reverse('lista_zaliha'), 'amber' if card['stale'] else 'red')
    # Conflicts only from a stored, explicit next-date proposal. We do not infer
    # a clinical interval from today's patient settings or move any appointment.
    proposals = []
    for s in sessions:
        plan = s.preview.get('plan', {})
        if plan.get('next') and plan.get('data', {}).get('patient_id'):
            proposals.append((s, plan))
    for a in take(m.ReconciliationAction.objects.filter(session_id__in=[s.pk for s in sessions]).select_related('session').order_by('-created_at', '-pk')):
        if a.summary.get('next') and a.summary.get('data', {}).get('patient_id'):
            proposals.append((a.session, a.summary))
    patient_ids = {row['data']['patient_id'] for _, row in proposals}
    future = list(m.Termin.objects.filter(pacijent_id__in=patient_ids,
        datum__gt=end, status__in=[m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA]).values('pacijent_id', 'lijek_id', 'datum')) if proposals else []
    seen = set()
    for s, row in proposals:
        data, expected = row['data'], row['next']['expected']
        key = (s.pk, data['patient_id'])
        if key in seen: continue
        seen.add(key)
        dates = [t['datum'].isoformat() for t in future if t['pacijent_id'] == data['patient_id'] and t['lijek_id'] == data['medicine_id']]
        if dates and expected not in dates:
            add(f'future-{s.pk}-{data["patient_id"]}', 'Postojeći termin se razlikuje od očekivanog datuma', f'Postojeći: {", ".join(dates)}; očekivano prema pregledanom nalogu: {expected}. Potreban novi pregled.', session_url(s) if admin else patient_url(data['patient_id']))
    issues.sort(key=lambda item: (item['level'] != 'red', item['key']))
    return dict(items=issues[:limit], incomplete=incomplete or len(issues) > limit)


def physical_observations(counts, stocks):
    """Bulk adapter to count_card(), without reimplementing its business rules."""
    from collections import defaultdict
    from .absence_reconciliation import count_card
    ledgers, allowed = defaultdict(list), defaultdict(set)
    mid_set = {mid for _, mid, _ in counts}
    for tx in m.ZalihaTransakcija.objects.filter(lijek_id__in=mid_set).order_by('pk').values():
        ledgers[tx['lijek_id']].append(tx)
    actions = list(m.ReconciliationAction.objects.filter(session_id__in={s.pk for s, _, _ in counts})
                   .select_related('unlinked_receipt').values('session_id', 'event_id', 'unlinked_receipt__movement_id', 'physical_correction_id'))
    event_sessions = {a['event_id']: a['session_id'] for a in actions if a['event_id']}
    correction_sessions = {a['physical_correction_id']: a['session_id'] for a in actions if a['physical_correction_id']}
    for a in actions:
        if a['unlinked_receipt__movement_id']: allowed[a['session_id']].add(a['unlinked_receipt__movement_id'])
    for event_id, txid in m.RetrospectiveEvent.movements.through.objects.filter(retrospectiveevent_id__in=event_sessions).values_list('retrospectiveevent_id', 'zalihatransakcija_id'):
        allowed[event_sessions[event_id]].add(txid)
    for rows in ledgers.values():
        for tx in rows:
            if tx['referenca_tip'] == 'PhysicalStockCorrection' and tx['referenca_id'] in correction_sessions:
                allowed[correction_sessions[tx['referenca_id']]].add(tx['id'])
    medicines = {row.pk: row for row in m.Lijek.objects.filter(pk__in=mid_set - stocks.keys())}
    result = {}
    for s, mid, _ in counts:
        stock = stocks.get(mid)
        medicine = stock.lijek if stock else medicines[mid]
        state = serial(dict(expected=stock.u_frizideru if stock else 0, ledger=ledgers[mid]))
        result[(s.pk, mid)] = count_card(s, medicine, state=state, allowed_movements=allowed[s.pk])
    return result


def period_summary(start, end):
    """Counts of native business events, not counts of their duplicated audits."""
    statuses = status_events().filter(business_date__range=(start, end))
    quick = m.BrzaIzmjenaPacijenta.objects.filter(vrijedi_od__range=(start, end))
    return [
        ('Stvarne primjene', actually_administered_therapy_query(m.Terapija.objects.filter(datum__range=(start, end))).count()),
        ('Nedolasci', statuses.filter(Q(novo_stanje__tip_dogadjaja='NIJE_DOSAO') | Q(novi_status=m.Termin.STATUS_NIJE_DOSAO)).count()),
        ('Odgode', statuses.filter(Q(novo_stanje__tip_dogadjaja='TERMIN_ODGODJEN') | Q(novi_status=m.Termin.STATUS_ODGODJENA)).count()),
        ('Zaprimanja', m.ZalihaTransakcija.objects.filter(datum__range=(start, end), tip=m.ZalihaTransakcija.TIP_ZAPRIMANJE).count()),
        ('Kućna izdavanja', m.Terapija.objects.filter(datum__range=(start, end), tip_evidencije=m.Terapija.TIP_KUCNA_TERAPIJA, workflow_status=m.Terapija.STATUS_POTVRDJENA).count() + m.KucnoIzdavanje.objects.filter(datum__range=(start, end), terapija__isnull=True).count() + m.IzdavanjeOralneTerapije.objects.filter(datum_izdavanja__range=(start, end), status=m.IzdavanjeOralneTerapije.STATUS_AKTIVNO).count()),
        ('Promjene doze', quick.filter(vrsta='dose').count()),
        ('Promjene intervala', quick.filter(vrsta='interval').count()),
        ('Promjene IV / SC i terapije', m.PromjenaTerapije.objects.filter(datum_odluke__range=(start, end)).count() + m.AktivnostLog.objects.filter(datum_vrijeme__date__range=(start, end), akcija='Potvrđen SC plan iz stvarne IV primjene').count()),
        ('Ručne ispravke', m.PatientDataCorrection.objects.filter(kreirano__date__range=(start, end)).count() + m.PhysicalStockCorrection.objects.filter(kreirano__date__range=(start, end)).count()),
        ('Radnje pametnog usklađivanja', m.ReconciliationAction.objects.filter(created_at__date__range=(start, end)).count()),
    ]


def today_summary(day):
    terms = m.Termin.objects.filter(datum=day)
    return [('Planirani termini', terms.count()), ('Stvarne primjene', actually_administered_therapy_query(m.Terapija.objects.filter(datum=day)).count()),
            ('Nedolasci', terms.filter(status=m.Termin.STATUS_NIJE_DOSAO).count()),
            ('Odgođeni termini', status_events().filter(business_date=day, novi_status=m.Termin.STATUS_ODGODJENA).count()),
            ('Nerazriješeni planirani termini', terms.filter(status=m.Termin.STATUS_PLANIRANA).count())]
