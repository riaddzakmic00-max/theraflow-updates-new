from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('patients', '0115_protocol_medicine_identity')]
    operations = [migrations.AddField(
        model_name='zalihatransakcija', name='shipment_reference',
        field=models.CharField(blank=True, max_length=100,
            help_text='Jedinstvena oznaka isporuke/otpremnice za ovaj ciklus i proizvod.')),
        migrations.AddConstraint(model_name='zalihatransakcija',
            constraint=models.UniqueConstraint(
                fields=['komisijski_ciklus', 'lijek', 'shipment_reference'],
                condition=models.Q(tip='ZAPRIMANJE', komisijski_ciklus__isnull=False)
                    & ~models.Q(shipment_reference=''),
                name='unique_commission_shipment_product'))]
