from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('patients', '0111_retrospective_event')]
    operations = [migrations.AddField(
        model_name='retrospectivebatch', name='reconstruction',
        field=models.JSONField(default=dict, blank=True))]
