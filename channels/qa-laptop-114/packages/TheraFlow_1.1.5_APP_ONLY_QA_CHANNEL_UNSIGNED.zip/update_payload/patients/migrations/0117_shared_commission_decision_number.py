"""A real decision document may cover more than one independent request."""
from django.db import migrations, models
from django.db.models import Count


def check_reverse_numbers(apps, schema_editor):
    agreements = apps.get_model('patients', 'KomisijskaSaglasnost')
    duplicates = (agreements.objects.using(schema_editor.connection.alias)
                  .exclude(broj_saglasnosti__isnull=True)
                  .values('broj_saglasnosti').annotate(total=Count('pk'))
                  .filter(total__gt=1))
    if duplicates.exists():
        raise RuntimeError('Povratak na jedinstven broj saglasnosti nije moguć uz zajedničke odluke. '
                           'Sačuvajte novu bazu i vratite provjerenu rezervnu kopiju prije migracije; '
                           'ne brišite i ne preimenujte stvarne saglasnosti.')


class Migration(migrations.Migration):
    dependencies = [('patients', '0116_receipt_shipment_reference')]
    operations = [
        migrations.AlterField(model_name='komisijskasaglasnost', name='broj_saglasnosti',
                              field=models.CharField(blank=True, db_index=True, max_length=100, null=True)),
        migrations.RunPython(migrations.RunPython.noop, check_reverse_numbers),
    ]
