from django.db import migrations, models
import django.db.models.deletion


def bind_known_orders(apps, schema_editor):
    Order = apps.get_model("patients", "IndividualniProtokolPacijenta")
    for order in Order.objects.using(schema_editor.connection.alias).exclude(standardni_protokol=None).select_related("standardni_protokol").iterator():
        Order.objects.using(schema_editor.connection.alias).filter(pk=order.pk).update(lijek_id=order.standardni_protokol.lijek_id)
    # Unbound legacy orders stay unbound: a patient's current drug is not proof.


class Migration(migrations.Migration):
    dependencies = [("patients", "0114_absence_reconciliation")]
    operations = [
        migrations.AddField(model_name="promjenaterapije", name="prethodni_zapisi", field=models.JSONField(default=dict, blank=True)),
        migrations.AddField(model_name="pacijent", name="protokol_za_potvrdu", field=models.BooleanField(default=False)),
        migrations.AddField(model_name="individualniprotokolpacijenta", name="lijek", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="individualni_protokoli", to="patients.lijek")),
        migrations.RunPython(bind_known_orders, migrations.RunPython.noop),
    ]
