from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0098_lock_canonical_hyrimoz_packaging"),
    ]

    operations = [
        migrations.AlterField(
            model_name="terapija",
            name="faza_terapije",
            field=models.CharField(blank=True, max_length=50),
        ),
    ]
