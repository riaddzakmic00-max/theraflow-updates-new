import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('patients', '0112_retrospective_checkpoint'), migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(name='ReconciliationSession', fields=[
            ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('period_start', models.DateField()), ('period_end', models.DateField()),
            ('reason', models.CharField(max_length=500)),
            ('status', models.CharField(choices=[('draft', 'U pripremi'), ('previewed', 'Pregledano'),
                ('partially_applied', 'Djelimično primijenjeno'), ('completed', 'Završeno'), ('cancelled', 'Otkazano')], default='draft', max_length=20)),
            ('revision', models.PositiveIntegerField(default=1)),
            ('findings', models.JSONField(default=list)), ('preview', models.JSONField(default=dict)),
            ('preview_fingerprint', models.CharField(blank=True, max_length=64)),
            ('user', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to=settings.AUTH_USER_MODEL)),
            ('patient', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to='patients.pacijent')),
            ('medicine', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to='patients.lijek')),
        ], options={'ordering': ['-created_at', '-pk'], 'constraints': [models.CheckConstraint(
            condition=models.Q(period_end__gte=models.F('period_start')), name='reconciliation_valid_period')]}),
        migrations.CreateModel(name='ReconciliationAction', fields=[
            ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
            ('operation_id', models.UUIDField(editable=False, unique=True)),
            ('decision', models.CharField(max_length=12)), ('created_at', models.DateTimeField(auto_now_add=True)),
            ('summary', models.JSONField(default=dict)),
            ('session', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='actions', to='patients.reconciliationsession')),
            ('appointment', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to='patients.termin')),
            ('user', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to=settings.AUTH_USER_MODEL)),
            ('event', models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to='patients.retrospectiveevent')),
            ('status_history', models.ManyToManyField(blank=True, to='patients.terapijastatushistorija')),
        ], options={'constraints': [models.UniqueConstraint(fields=['session', 'appointment'], name='reconciliation_once_per_item')]}),
    ]
