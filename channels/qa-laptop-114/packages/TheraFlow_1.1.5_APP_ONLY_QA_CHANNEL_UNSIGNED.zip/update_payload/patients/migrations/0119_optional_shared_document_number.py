from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('patients', '0118_shared_commission_document')]

    # Only form/model validation metadata changes; no historical value is
    # replaced, no document number is invented, and no approval is backfilled.
    operations = [
        migrations.AlterField(
            model_name='komisijskidokumentodluke', name='broj_dokumenta',
            field=models.CharField(blank=True, db_index=True, max_length=100)),
        migrations.AlterField(
            model_name='pacijentsaglasnost', name='broj_saglasnosti',
            field=models.CharField(blank=True, db_index=True, max_length=100)),
        migrations.AlterField(
            model_name='evidencijasaglasnostizaprimanja', name='broj_saglasnosti_snapshot',
            field=models.CharField(blank=True, max_length=100)),
    ]
