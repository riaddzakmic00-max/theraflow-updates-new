"""Update existing presentation IDs only; frozen, repeatable administrative seed."""
from decimal import Decimal

from django.db import migrations, models


# Exact presentation aliases only. Never infer a presentation from its INN/ATC.
PRESENTATIONS = (
    (("Remsima", "Remsima 100 mg"), "100", "IV", "L04AB02",
     "prašak za koncentrat za rastvor za infuziju", "100 mg"),
    (("Entyvio", "Entyvio 300 mg"), "300", "IV", "L04AA33",
     "prašak za koncentrat za rastvor za infuziju", "300 mg"),
    # Migration 0098's canonical Adalimumab presentation is named Hyrimoz.
    # Keep the requested 40 mg description; do not infer a volume.
    (("Adalimumab", "Adalimumab 40 mg", "Hyrimoz", "Hyrimoz 40 mg"), "40", "SC", "L04AB04",
     "rastvor za injekciju", "40 mg"),
    (("Yesintek 130 mg IV", "Stelara 130 mg IV"), "130", "IV", "L04AC05",
     "koncentrat za rastvor za infuziju", "130 mg/26 mL"),
    (("Yesintek 90 mg/1 mL SC", "Yesintek 90 mg SC"), "90", "SC", "L04AC05",
     "rastvor za injekciju u napunjenoj štrcaljki", "90 mg/1 mL"),
    (("Xeljanz 5 mg", "Xeljanz"), "5", "PO", "L04AF01",
     "filmom obložena tableta", "5 mg"),
    (("Tenofovir 245 mg", "Tenofovir"), "245", "PO", "J05AF07",
     "filmom obložena tableta", "245 mg"),
    (("Entecavir 0,5 mg", "Entecavir 0.5 mg", "Entecavir"), "0.5", "PO", "J05AF10",
     "filmom obložena tableta", "0,5 mg"),
)


def populate_existing_presentations(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    registry = Lijek.objects.using(schema_editor.connection.alias)
    specs = {name.casefold(): spec for spec in PRESENTATIONS for name in spec[0]}
    for medicine in registry.all().iterator():
        spec = specs.get(medicine.naziv.strip().casefold())
        if not spec:
            continue
        if medicine.naziv.strip().casefold().startswith("hyrimoz"):
            if (medicine.genericki_naziv or "").strip().casefold() != "adalimumab":
                continue
        _, mg, route, atc, form, strength = spec
        # Inconsistent/other presentations require administrative review.
        if medicine.jacina_mg is not None and medicine.jacina_mg != Decimal(mg):
            continue
        if medicine.put_primjene and medicine.put_primjene != route:
            continue
        for field, value in {"atc_code": atc, "pharmaceutical_form": form,
                             "strength": strength}.items():
            old = getattr(medicine, field)
            if not (old or "").strip():
                # Conditional column-only updates preserve concurrent/admin edits,
                # PK/FK links and avoid model save/signals/protocol side effects.
                registry.filter(pk=medicine.pk, **{field: old}).update(**{field: value})


class Migration(migrations.Migration):
    dependencies = [("patients", "0099_alter_terapija_faza_terapije")]
    operations = [
        migrations.AddField(model_name="lijek", name="atc_code", field=models.CharField(
            "ATC", max_length=16, blank=True, default="",
            help_text="Administrativno izmjenjiv ATC prezentacije. Xeljanz: WHO L04AF01; stari ALMBiH registar L04AA29.")),
        migrations.AddField(model_name="lijek", name="pharmaceutical_form", field=models.CharField(
            "Oblik za službeni zahtjev", max_length=255, blank=True, default="",
            help_text="Puni farmaceutski oblik konkretne prezentacije lijeka.")),
        migrations.AddField(model_name="lijek", name="strength", field=models.CharField(
            "Jačina za službeni zahtjev", max_length=100, blank=True, default="",
            help_text="Službeni opis jačine prezentacije, uključujući volumen samo kada je poznat.")),
        migrations.RunPython(populate_existing_presentations, migrations.RunPython.noop),
    ]
