from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('patients', '0119_optional_shared_document_number')]

    # Unknown external labels remain empty; UUID/movement identity still makes
    # every physical receipt distinct. Nonempty labels keep their unique guard.
    operations = [
        migrations.RemoveConstraint(model_name='unlinkedstockreceipt', name='unlinked_unique_delivery'),
        migrations.AlterField(model_name='unlinkedstockreceipt', name='delivery_reference',
            field=models.CharField(blank=True, max_length=120)),
        migrations.AddConstraint(model_name='unlinkedstockreceipt', constraint=models.UniqueConstraint(
            fields=['medicine', 'delivery_reference'], condition=~models.Q(delivery_reference=''),
            name='unlinked_unique_delivery')),
    ]
