"""Only new oral issues record the reservation they actually consumed."""
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [("patients", "0106_inventory_provenance")]
    operations = [migrations.CreateModel(
        name="OralnoRazduzenjeRezervacije",
        fields=[
            ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("kolicina", models.DecimalField(decimal_places=2, max_digits=8)),
            ("izdavanje", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,
                related_name="razduzenja_rezervacija", to="patients.izdavanjeoralneterapije")),
            ("rezervacija", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,
                related_name="oralna_razduzenja", to="patients.pacijentrezervacija")),
        ],
        options={"constraints": [
            models.CheckConstraint(condition=models.Q(kolicina__gt=0), name="oral_reservation_debit_gt0"),
            models.UniqueConstraint(fields=("izdavanje", "rezervacija"), name="oral_issue_reservation_once"),
        ]},
    )]
