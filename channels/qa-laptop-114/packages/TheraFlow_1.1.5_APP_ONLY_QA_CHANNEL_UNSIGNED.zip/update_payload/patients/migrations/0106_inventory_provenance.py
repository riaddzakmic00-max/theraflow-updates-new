"""New actions only. No data backfill or inferred historical allocation."""
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [('patients','0105_fridge_balance_history')]
    operations = [
        migrations.AddField(model_name='zalihatransakcija', name='operation_id',
            field=models.UUIDField(blank=True, db_index=True, editable=False, null=True)),
        migrations.AddField(model_name='zalihatransakcija', name='jedinica_snapshot',
            field=models.CharField(blank=True, editable=False, max_length=30)),
        migrations.AddField(model_name='zalihatransakcija', name='komisijski_ciklus',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT,
                related_name='fizicki_prometi', to='patients.komisijskiciklus')),
        migrations.AddField(model_name='zalihatransakcija', name='izvorna_transakcija',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT,
                related_name='povezani_prometi', to='patients.zalihatransakcija')),
        migrations.AddField(model_name='evidencijasaglasnostizaprimanja', name='fizicka_transakcija',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT,
                related_name='raspodjele_prijema', to='patients.zalihatransakcija')),
        migrations.AddField(model_name='evidencijasaglasnostizaprimanja', name='rezervacija',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT,
                related_name='izvori_prijema', to='patients.pacijentrezervacija')),
        migrations.AddConstraint(model_name='evidencijasaglasnostizaprimanja',
            constraint=models.UniqueConstraint(fields=('fizicka_transakcija','trebovanje'),
                condition=models.Q(fizicka_transakcija__isnull=False), name='receipt_one_request_per_input')),
    ]
