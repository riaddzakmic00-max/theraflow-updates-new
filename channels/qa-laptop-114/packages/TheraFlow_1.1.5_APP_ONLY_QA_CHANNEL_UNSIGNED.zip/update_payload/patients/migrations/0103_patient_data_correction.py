import uuid
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0102_home_therapy_evidence"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [migrations.CreateModel(
        name="PatientDataCorrection",
        fields=[
            ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("operation_id", models.UUIDField(default=uuid.uuid4, unique=True, editable=False)),
            ("scope", models.CharField(max_length=30)),
            ("razlog", models.CharField(max_length=500)),
            ("prije", models.JSONField(default=dict)),
            ("poslije", models.JSONField(default=dict)),
            ("posljedice", models.JSONField(default=list)),
            ("backup", models.JSONField(default=dict)),
            ("kreirano", models.DateTimeField(auto_now_add=True)),
            ("pacijent", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="ispravke_podataka", to="patients.pacijent")),
            ("korisnik", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to=settings.AUTH_USER_MODEL)),
        ],
        options={"ordering": ["-kreirano", "-pk"], "verbose_name": "Ispravka podataka pacijenta"},
    )]
