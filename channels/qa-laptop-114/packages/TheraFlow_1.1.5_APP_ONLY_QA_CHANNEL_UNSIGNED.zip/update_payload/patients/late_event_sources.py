"""Read-only identity and dated sources for an explicitly selected event SKU."""
from types import SimpleNamespace
from copy import copy
from decimal import Decimal, InvalidOperation
import re
from django.db.models import Q
from . import models as m
from .data_corrections import require


def event_patient(patient, medicine):
    """A selected event context must not overwrite today's cached FK either."""
    result = copy(patient)
    result._state = copy(patient._state)
    result._state.fields_cache = patient._state.fields_cache.copy()
    result.lijek = medicine
    return result


def event_route(medicine):
    route = (medicine.put_primjene or '').strip().upper()
    if route in dict(m.Lijek.PUTEVI_PRIMJENE):
        return route
    if medicine.oralna_terapija and medicine.farmaceutski_oblik == m.Lijek.OBLIK_TABLETA:
        return m.Lijek.PUT_PO
    # A legacy SKU may lack route metadata. Only one compatible catalogue
    # representation can prove it; neither the patient nor the brand name alone
    # determines route. Keep the selected SKU and its physical ledger intact.
    from .medicine_registry import patient_product_for_selection
    context = SimpleNamespace(trenutni_proizvod=medicine, terapijski_program_id=medicine.terapijski_program_id)
    routes = {candidate.put_primjene for candidate in m.Lijek.objects.filter(
        terapijski_program_id=medicine.terapijski_program_id, aktivan=True,
        put_primjene__in=dict(m.Lijek.PUTEVI_PRIMJENE))
        if medicine.terapijski_program_id and patient_product_for_selection(context, candidate)}
    require(len(routes) == 1, 'Put primjene ove prezentacije nije jednoznačno evidentiran. Odaberite dokumentovanu IV, SC ili oralnu prezentaciju; podatak se neće nagađati.')
    return routes.pop()


def historical_reservations(patient, medicine, when):
    if not patient or not medicine or not when:
        return m.PacijentRezervacija.objects.none()
    candidates = m.PacijentRezervacija.objects.filter(pacijent=patient, lijek=medicine,
        aktivno=True, kolicina__gt=0).filter(
        Q(termin__datum=when) | Q(termin__isnull=True, datum_rezervacije__lte=when)
    ).filter(Q(komisija__isnull=True) | Q(komisija__datum_odobrenja__lte=when)).select_related('lijek', 'termin', 'komisija')
    from .inventory_corrections import receipt_date
    ids = [item.pk for item in candidates if not any(
        source.fizicka_transakcija_id and receipt_date(source.fizicka_transakcija) > when
        for source in item.izvori_prijema.select_related('fizicka_transakcija'))]
    return candidates.filter(pk__in=ids).order_by('termin_id', 'datum_rezervacije', 'pk')


def compatible_source_ids(medicine):
    """Coverage pool without mixing IV/SC, strengths or physical units.

    Legacy generic groups are wider than presentation identity. Debit the
    selected ledger only, while protecting compatible catalogue aliases too.
    Unknown metadata is treated conservatively; it never proves a new source.
    """
    def strength(product):
        value = product.jacina_mg
        if value is None:
            match = re.fullmatch(r'(\d+(?:[.,]\d+)?)\s*mg', (product.strength or '').strip(), re.I)
            value = match[1].replace(',', '.') if match else None
        try:
            return Decimal(str(value)) if value is not None else None
        except InvalidOperation:
            return None
    route = event_route(medicine)
    ids = [medicine.pk]
    for candidate in m.Lijek.objects.filter(pk__in=medicine.equivalent_ids()).exclude(pk=medicine.pk):
        if candidate.put_primjene and candidate.put_primjene != route:
            continue
        if (strength(candidate) == strength(medicine)
                and candidate.nacin_primjene == medicine.nacin_primjene
                and candidate.farmaceutski_oblik == medicine.farmaceutski_oblik
                and candidate.jedinice_zalihe[0] == medicine.jedinice_zalihe[0]):
            ids.append(candidate.pk)
    return ids


def protected_future_rows(patient, when):
    return [dict(label=f'Buduća rezervacija {r.termin.datum:%d.%m.%Y.} — {r.lijek}',
        before=str(r.kolicina), after=str(r.kolicina), unit=r.lijek.jedinice_zalihe[0])
        for r in m.PacijentRezervacija.objects.filter(pacijent=patient, aktivno=True,
            kolicina__gt=0, termin__datum__gt=when).select_related('termin', 'lijek').order_by('termin__datum', 'pk')]
