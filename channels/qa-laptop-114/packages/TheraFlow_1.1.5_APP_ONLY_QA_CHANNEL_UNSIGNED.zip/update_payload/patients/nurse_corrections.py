"""Guided UI adapters over the existing correction and retrospective services.

Only the explicit balance correction may leave allocations above physical stock.
Normal receiving, dispensing and clinical authorization retain their own rules.
"""
from copy import deepcopy
from decimal import Decimal
from uuid import uuid4

from django.core import signing
from django.db.models import Sum
from django.utils import timezone

from . import models as m
from .correction_protocol import correction_transaction
from .data_corrections import (require, serial, digest, captured_rows, differences,
                              backup_before_correction)

SALT = 'theraflow.nurse-workflow.v1'
REASONS = [('mistake', 'Pogrešno evidentirano'), ('missing', 'Stvarna primjena nije bila evidentirana'),
           ('quantity', 'Pogrešna količina'), ('count', 'Korekcija stvarnog stanja'), ('other', 'Drugo')]


def authorize(user, category):
    if category == 'transition':
        from .ustekinumab_transition import authorize as transition
        return transition(user)
    from .correction_center import authorize as administrative
    from .quick_changes import authorize as clinical
    (clinical if category in ('dose', 'interval', 'appointment') else administrative)(user)


def amounts(patient, medicine):
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    reservations = m.PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True)
    total = lambda qs: qs.aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
    return dict(physical=stock.u_frizideru if stock else Decimal(0),
                patient=total(reservations.filter(pacijent=patient)) if patient else Decimal(0),
                reserved=total(reservations))


def latest_application(patient, medicine):
    from .therapy_history import actually_administered_therapy_query
    return actually_administered_therapy_query(m.Terapija.objects.filter(pacijent=patient,
        lijek_id__in=medicine.equivalent_ids())).order_by('-datum', '-pk').first()


def balance_plan(patient, medicine, raw):
    from .physical_stock_corrections import preview as physical_preview
    from .stock_lots import lot_balances
    before = amounts(patient, medicine); after = deepcopy(before)
    updates = []
    if raw.get('change_patient'):
        require(patient is not None, 'Za promjenu zaduženja odaberite pacijenta.')
        quantity = Decimal(raw['patient_quantity'])
        delta = quantity - before['patient']
        reservations = list(m.PacijentRezervacija.objects.filter(pacijent=patient, lijek=medicine,
            aktivno=True, potrosena_at__isnull=True).order_by('datum_rezervacije', 'pk'))
        # The user corrects the displayed total. Every affected original row is
        # preserved, including its source and appointment links, in the audit.
        remaining = -delta
        if delta < 0:
            for reservation in reservations:
                reduction = min(remaining, reservation.kolicina)
                if reduction:
                    updates.append(dict(id=reservation.pk, before=reservation.kolicina,
                                        after=reservation.kolicina-reduction))
                    remaining -= reduction
            require(remaining == 0, 'Zaduženje je već potrošeno. Ponovo učitajte podatke.')
        elif delta > 0:
            # No commission, receipt or lot provenance is fabricated. A verified
            # correction is distinct from an ordinary allocation of free stock.
            updates.append(dict(id=None, before=0, after=delta))
        after['patient'] = quantity; after['reserved'] += delta
    physical = None
    if raw.get('change_physical'):
        quantity = Decimal(raw['physical_quantity'])
        if quantity != before['physical']:
            batch, expiry = '', None
            scope = 'TOTAL'
            if raw.get('lot'):
                import json
                from django.utils.dateparse import parse_date
                batch, expiry = json.loads(raw['lot']); expiry = parse_date(expiry) if expiry else None
                scope = 'LOT'
                require((batch, expiry) in lot_balances(medicine), 'Odabrana serija više nije dostupna.')
                quantity = lot_balances(medicine)[(batch, expiry)] + quantity - before['physical']
            physical = physical_preview(dict(lijek=medicine, kolicina=quantity, razlog=raw['reason'],
                obuhvat=scope, serija=batch, rok_trajanja=expiry,
                datum_dogadjaja=timezone.localdate(), razlog_kod='COUNT_UNKNOWN'))
            after['physical'] = physical['total_after']
    require(updates or physical, 'Nema izmijenjenih vrijednosti. Odaberite podatak i unesite novo stanje.')
    warnings = []
    if after['reserved'] > after['physical']:
        warnings.append('Nakon ove izmjene ukupno zaduženje pacijenata bit će veće od fizičke zalihe. '
                        'Ispravku možete izvršiti; preostalo neslaganje ostaje vidljivo u historiji.')
    if raw.get('change_patient') and any(r.get('id') is None for r in updates):
        warnings.append('Povezanost dodatne količine s prijemom i odobrenjem ostaje za provjeru.')
    if physical:
        warnings.extend(w for w in physical['warnings'] if 'rezervisane količine' not in w)
    return serial(dict(title='Pregled izmjene', before=before, after=after, updates=updates,
        physical=physical, warnings=list(dict.fromkeys(warnings)), rows=[
            dict(label='Zaduženje pacijenta', before=before['patient'], after=after['patient'], unit=medicine.jedinice_zalihe[0]),
            dict(label='Fizička zaliha', before=before['physical'], after=after['physical'], unit=medicine.jedinice_zalihe[0]),
            dict(label='Terapijski plan', before='Trenutni plan', after='Trenutni plan')]))


def plan(category, patient, medicine, raw, user):
    authorize(user, category)
    from . import retrospective_events as events
    if category in ('reservation', 'physical'):
        result = balance_plan(patient, medicine, raw)
    elif category in ('dose', 'interval'):
        from .quick_changes import preview
        result = preview(patient, category, raw, user)
    elif category == 'appointment':
        from .appointment_reschedule import analyze
        result = analyze(patient, medicine, raw)
    elif category == 'last_date':
        therapy = latest_application(patient, medicine)
        when = events.day(raw['event_date'])
        require(when <= timezone.localdate(), 'Posljednja terapija ne može biti u budućnosti.')
        if therapy:
            require(when != therapy.datum, 'Datum nije promijenjen.')
            require(not m.Terapija.objects.filter(pacijent=patient, lijek_id__in=medicine.equivalent_ids(), datum=when,
                workflow_status='POTVRDJENA').exclude(pk=therapy.pk).exists(), 'Za ovaj datum već postoji terapija. Pregledajte historiju.')
            from .retrospective_history import product_at
            require(product_at(patient, medicine, when) is not None, 'Lijek ne odgovara terapiji na ispravljeni datum.')
            result = dict(title='Datum posljednje terapije', therapy_id=therapy.pk, warnings=[], rows=[
                dict(label='Datum posljednje terapije', before=therapy.datum.strftime('%d.%m.%Y.'), after=when.strftime('%d.%m.%Y.')),
                dict(label='Zaliha, zaduženje i doza', before='Trenutno stanje', after='Trenutno stanje')])
        else:
            snapshot = m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient).first()
            require(snapshot is not None, 'Nema ranije primjene za ispravku. Koristite Terapija je primijenjena za stvarni događaj koji još nije evidentiran.')
            from dashboard.correction_forms import CorrectionForm
            from .data_corrections import preview
            legacy = dict(datum_posljednje_terapije=raw['event_date'], sljedeca_terapija=snapshot.sljedeca_terapija or '', razlog=raw['razlog'])
            form = CorrectionForm(legacy, patient=patient, scope='migration')
            require(form.is_valid(), form.errors.as_text())
            result = preview(patient, 'migration', form.cleaned_data)
            result['legacy_raw'] = serial(legacy)
    elif category in ('medicine', 'route', 'plan', 'change'):
        from dashboard.correction_plan_views import preview
        result = preview(patient, 'medicine', raw, user, historical=category=='change', guided=True)
    elif category == 'transition':
        from .ustekinumab_transition import plan as transition_plan
        result = transition_plan(patient, raw, user)
        result.update(title='Prelazak iz IV indukcije na SC', rows=[
            dict(label='Novi SC plan', before='IV indukcija', after=result['sc_name']+' · 90 mg · 1 SC jedinica'),
            dict(label='SC termin', before='Dosadašnji raspored', after=result['date'])])
    elif category in ('therapy', 'home'):
        result = events.preview(raw, user)
        if category == 'therapy':
            from .retrospective_schedule import next_date_plan
            # Use the historical product and protocol, not today's different
            # medication. This is also used by the existing retrospective path.
            from .retrospective_history import patient_at
            from .late_event_sources import event_patient
            historical = event_patient(patient, medicine) if patient.lijek_id != medicine.pk or patient.aktivni_fazni_protokol() else patient_at(patient, events.day(raw['event_date']))
            historical.lijek = medicine
            schedule = (dict(due=None,appointments=[],schedule=False) if medicine.oralna_terapija or patient.lijek_id != medicine.pk or patient.aktivni_fazni_protokol() else
                next_date_plan(historical, events.day(raw['event_date'])))
            schedule['schedule'] = bool(schedule['due'] and not schedule['appointments'] and
                schedule['due'] >= timezone.localdate() and patient.lijek_id == medicine.pk and
                historical.trenutni_korak_je_ambulanta() and not patient.na_aktivnoj_pauzi())
            result['schedule'] = serial(schedule)
            result['warnings'] = [warning for warning in result.get('warnings', [])
                if 'ovaj unos ne kreira niti pomjera buduće termine' not in warning]
            if patient.lijek_id != medicine.pk:
                result['schedule']['schedule_current_medicine'] = False
                result.setdefault('warnings', []).append('Ovo je ranija terapija. Budući termini prate trenutno aktivni lijek i ostaju sačuvani.')
            # The native preview shares its rows with the accounting evidence.
            # Add schedule presentation without changing that verified evidence.
            result['rows'] = deepcopy(result['rows'])
            result['rows'].append(dict(label='Sljedeći termin', before='Dosadašnji raspored',
                after='Postojeći raspored ostaje bez promjene.' if not schedule['due'] else
                ('Postojeći termini ostaju; izračunati datum ' if schedule['appointments'] else
                       'Izračunati datum u prošlosti: ' if schedule['due'] < timezone.localdate() else
                       'Izračunati datum ranije terapije: ' if patient.lijek_id != medicine.pk else
                       'Automatski se zakazuje ' if schedule['schedule'] else 'Prema postojećem planu: ') + schedule['due'].strftime('%d.%m.%Y.')))
    elif category == 'receipt':
        when = events.day(raw['event_date']); quantity = events.amount(raw['quantity'])
        require(when <= timezone.localdate(), 'Datum zaprimanja ne može biti u budućnosti.')
        expiry = events.day(raw.get('expires'), optional=True)
        require(not expiry or raw.get('batch') and expiry >= when, 'Provjerite seriju i rok trajanja.')
        from .absence_reconciliation import duplicate_receipts
        require(not duplicate_receipts(dict(raw, medicine_id=medicine.pk)),
                'Moguće je da je ovaj prijem već evidentiran. Pregledajte historiju prijema prije novog unosa.')
        if raw.get('request_id'):
            request = m.Trebovanje.objects.get(pk=raw['request_id'])
            require(request.lijek_id == medicine.pk, 'Komisijska stavka pripada drugom lijeku.')
            event_raw = dict(raw, kind='receipt', medicine_id=medicine.pk,
                cycle_id=request.komisijski_ciklus_id, delivery_reference=raw.get('delivery_reference') or str(uuid4()),
                lots=[dict(quantity=quantity, batch=raw.get('batch', ''), expires=expiry)])
            # Generated reference is fixed in the signed data for retry safety.
            raw['delivery_reference'] = event_raw['delivery_reference']
            result = events.preview(event_raw, user)
            result['event_raw'] = serial(event_raw)
        else:
            before = amounts(patient, medicine)
            result = dict(title='Lijek je zaprimljen', warnings=[], rows=[
                dict(label='Fizička zaliha', before=before['physical'], after=before['physical']+quantity, unit=medicine.jedinice_zalihe[0]),
                dict(label='Zaduženje pacijenta', before=before['patient'], after=before['patient'], unit=medicine.jedinice_zalihe[0]),
                dict(label='Terapijski plan', before='Trenutni plan', after='Trenutni plan')])
    elif category == 'deferred':
        appointment = m.Termin.objects.get(pk=raw['appointment_id'], pacijent=patient)
        require(appointment.datum <= timezone.localdate(), 'Odaberite termin koji je već nastao.')
        require(appointment.status == m.Termin.STATUS_PLANIRANA, 'Termin je već razriješen. Ponovo učitajte podatke.')
        from .smart_reconciliation import actual_therapies
        require(not actual_therapies(appointment).exists(), 'Za ovaj termin već postoji primjena; pregledajte historiju.')
        before = amounts(patient, medicine)
        from django.db import transaction
        from .therapy_workflow import mark_no_show, postpone_therapy
        with transaction.atomic():
            if raw['decision'] == 'postpone':
                changed = postpone_therapy(termin=appointment,reason=raw['note'],user=user,
                    new_date=events.day(raw.get('new_date'),optional=True))
            else:
                changed = mark_no_show(termin=appointment,reason=raw['note'],user=user)
            after = amounts(patient, medicine)
            new_status = changed.get_status_display()
            transaction.set_rollback(True)
        result = dict(title='Terapija nije primijenjena / odgođena', warnings=[], rows=[
            dict(label='Termin '+appointment.datum.strftime('%d.%m.%Y.'), before=appointment.get_status_display(),
                 after=new_status),
            dict(label='Fizička zaliha',before=before['physical'],after=after['physical'],unit=medicine.jedinice_zalihe[0]),
            dict(label='Zaduženje pacijenta',before=before['patient'],after=after['patient'],unit=medicine.jedinice_zalihe[0])])
        if before['patient'] != after['patient']:
            result['warnings'].append('Postojeći postupak ažuriranja termina usklađuje zaduženje s količinom za jednu narednu terapiju. Pregledajte prikazano novo zaduženje.')
        if raw.get('new_date'):
            from .scheduling import validate_therapy_date
            validate_therapy_date(events.day(raw['new_date']), lijek=appointment.lijek)
            result['rows'].append(dict(label='Novi termin', before='Nije zakazan', after=raw['new_date']))
    elif category == 'other':
        require(events.day(raw['event_date']) <= timezone.localdate(), 'Događaj ne može biti u budućnosti.')
        result = dict(title='Drugi događaj', warnings=[], rows=[
            dict(label='Historija pacijenta', before='Dosadašnji zapisi', after=raw['description']),
            dict(label='Zaliha, zaduženje i terapijski plan', before='Trenutno stanje', after='Trenutno stanje')])
    else:
        raise ValueError('Nepoznata radnja.')
    result.setdefault('title', {'dose':'Doza i terapija', 'interval':'Interval terapije'}.get(category, 'Pregled izmjene'))
    result.setdefault('warnings', [])
    result.update(category=category, patient_id=patient.pk if patient else None, medicine_id=medicine.pk,
                  reason=raw.get('reason') or raw.get('razlog') or raw.get('note') or raw.get('napomena', ''))
    return serial(result)


def _guided_projection(category, patient, medicine, raw, result, user):
    from .guided_reconciliation import project
    result['guided_impact'] = project(category, patient, medicine, result, raw, user,
        lambda: _apply(category, patient, medicine, raw, result, user, str(uuid4()), {'simulation':True}))
    if category == 'transition' and any(a['kind'] == 'allocate' for a in result['guided_impact']['selected_actions']):
        result['warnings'] = [
            'Pregled uključuje odabranu dodjelu SC zaduženja iz slobodne fizičke zalihe. Fizička količina i IV zaduženja ostaju prema prikazanom pregledu.'
            if warning.startswith('SC termin se zakazuje bez nove dodjele') else warning
            for warning in result.get('warnings', [])]


def preview(category, patient, medicine, raw, user):
    # Some existing plan adapters use savepoint simulations; use their shared
    # correction transaction rather than a PostgreSQL READ ONLY transaction.
    with correction_transaction():
        raw = serial(raw)
        fingerprint = digest(captured_rows())
        result = plan(category, patient, medicine, raw, user)
        if category == 'appointment' and not result['can_confirm']:
            return result, None
        _guided_projection(category, patient, medicine, raw, result, user)
        require(fingerprint == digest(captured_rows()), 'Podaci su promijenjeni tokom pregleda. Ponovite pregled.')
        token = signing.dumps(dict(operation=str(uuid4()), user=user.pk, category=category,
            patient=patient.pk if patient else None, medicine=medicine.pk, raw=raw,
            fingerprint=fingerprint, selected_actions=[a['id'] for a in result.get('guided_impact', {}).get('selected_actions', [])]), salt=SALT, compress=True)
        return result, token


def revise_preview(token, user, *, category, patient_id, medicine_id, apply_recommended=False,
                   selected=None, rejection_reason=''):
    authorize(user, category)
    payload = signing.loads(token, salt=SALT, max_age=1800)
    require((payload['user'], payload['category'], payload['patient'], payload['medicine']) ==
            (user.pk, category, patient_id, medicine_id), 'Pregled ne pripada ovoj radnji i pacijentu.')
    with correction_transaction():
        require(payload['fingerprint'] == digest(captured_rows()), 'Podaci su promijenjeni nakon pregleda. Ponovo pregledajte izmjenu.')
        raw = dict(payload['raw'], apply_recommended=bool(apply_recommended),
                   guided_actions=selected or [], rejection_reason=rejection_reason[:500])
        return preview(category, m.Pacijent.objects.get(pk=patient_id) if patient_id else None,
                       m.Lijek.objects.get(pk=medicine_id), raw, user)


def require_reviewed_selection(post, token):
    if post.get('guided_choices') == 'yes':
        payload = signing.loads(token, salt=SALT)
        require(set(post.getlist('guided_actions')) == set(payload.get('selected_actions') or []),
                'Izbor preporuka je promijenjen. Kliknite Pregledaj odabrane izmjene prije potvrde.')


def confirm(token, user, *, category, patient_id, medicine_id, acknowledge=False):
    authorize(user, category)
    try:
        payload = signing.loads(token, salt=SALT)
    except signing.BadSignature:
        raise ValueError('Pregled nije važeći. Ponovo pregledajte izmjenu.') from None
    require((payload['user'], payload['category'], payload['patient'], payload['medicine']) ==
            (user.pk, category, patient_id, medicine_id), 'Potvrda ne pripada ovoj radnji i pacijentu.')
    with correction_transaction():
        saved = m.PatientDataCorrection.objects.filter(operation_id=payload['operation'], korisnik=user).first()
        if saved:
            return saved, False
        signing.loads(token, salt=SALT, max_age=1800)
        require(payload['fingerprint'] == digest(captured_rows()), 'Podaci su promijenjeni nakon pregleda. Ponovo pregledajte izmjenu.')
        patient = m.Pacijent.objects.get(pk=patient_id) if patient_id else None
        medicine = m.Lijek.objects.get(pk=medicine_id); raw = payload['raw']
        result = plan(category, patient, medicine, raw, user)
        require(category != 'appointment' or result['can_confirm'], 'Termin nije prihvatljiv. Ponovo pregledajte sigurne korake.')
        from . import guided_reconciliation as guided
        _guided_projection(category, patient, medicine, raw, result, user)
        require(not result.get('warnings') or acknowledge, 'Potvrdite da želite izvršiti izmjenu uz prikazano upozorenje.')
        result['warning_acknowledged'] = bool(acknowledge and result.get('warnings'))
        try:
            backup = backup_before_correction(payload['operation'])
        except Exception as exc:
            raise ValueError('Sigurnosna kopija nije potvrđena. Izmjena nije sačuvana; provjerite kopiju u postavkama pa ponovite pregled.') from exc
        before = captured_rows()
        _apply(category, patient, medicine, raw, result, user, payload['operation'], backup)
        graph = result.get('guided_impact')
        if graph:
            guided.apply_actions(graph['selected_actions'], patient, user, payload['operation'], result['reason'])
            require(guided.state(patient, medicine) == graph['expected_state'],
                    'Rezultat se razlikuje od pregleda. Sve promjene su vraćene; ponovo pregledajte podatke.')
            graph['post_save'] = guided.inspect(category, patient, medicine, result, raw)
            graph['post_save']['status'] = ('Sve povezane evidencije su usklađene.' if not graph['post_save']['unresolved_items'] else
                f'Ostale su {len(graph["post_save"]["unresolved_items"])} stavke koje zahtijevaju pažnju.')
        old, new = differences(before, captured_rows())
        receipt = m.PatientDataCorrection.objects.create(operation_id=payload['operation'], korisnik=user,
            pacijent=patient, scope='guided_'+category, razlog=result['reason'][:500],
            datum_dogadjaja=raw.get('new_date') if category == 'appointment' else
                raw.get('event_date') or raw.get('vrijedi_od') or raw.get('datum_pocetka_nove_terapije') or timezone.localdate(),
            prije=old, poslije=new, posljedice=result, backup=backup)
        m.ZalihaTransakcija.objects.filter(operation_id=payload['operation'], korekcija__isnull=True).update(korekcija=receipt)
        from .utils import upisi_log
        upisi_log(user, result['title'], pacijent=patient, objekat=receipt, opis=result['reason'])
        return receipt, True


def _apply(category, patient, medicine, raw, result, user, operation, backup):
    from . import retrospective_events as events
    if category in ('reservation', 'physical'):
        if result['physical']:
            from .physical_stock_corrections import apply_plan
            physical = dict(result['physical'])
            for key in ('before','after','delta','total_before','total_after','reserved','group_before','group_reserved'):
                physical[key] = Decimal(str(physical[key]))
            apply_plan(physical, user, operation, backup)
        for update in result['updates']:
            if update['id']:
                reservation = m.PacijentRezervacija.objects.get(pk=update['id'], pacijent=patient, lijek=medicine)
                reservation.kolicina = update['after']; reservation.aktivno = Decimal(update['after']) > 0
                reservation.save(update_fields=['kolicina', 'aktivno'])
            else:
                reservation = m.PacijentRezervacija.objects.create(pacijent=patient, lijek=medicine,
                    kolicina=update['after'], napomena=raw['reason'])
            delta = Decimal(str(update['after']))-Decimal(str(update['before']))
            m.ZalihaTransakcija.objects.create(lijek=medicine, pacijent=patient, rezervacija=reservation,
                tip='KOREKCIJA', kolicina=abs(delta), promjena_salda=0, promjena_rezervacije=delta,
                korisnik=user, datum=timezone.localdate(), operation_id=operation, napomena=raw['reason'])
        actual = amounts(patient, medicine)
        require(all(actual[key] == Decimal(str(value)) for key, value in result['after'].items()),
                'Provjera izmjene nije uspjela. Sve promjene su vraćene.')
    elif category in ('dose', 'interval'):
        from .quick_changes import make_preview, confirm
        _, token = make_preview(patient, category, raw, user)
        confirm(token, patient, user, sync_appointments=False)
    elif category == 'appointment':
        from .appointment_reschedule import apply_reviewed
        apply_reviewed(result, patient, user, result['reason'])
    elif category == 'last_date':
        if result.get('therapy_id'):
            therapy = m.Terapija.objects.get(pk=result['therapy_id'], pacijent=patient)
            therapy.workflow_snapshot = dict(therapy.workflow_snapshot, date_before_correction=str(therapy.datum))
            therapy.datum = raw['event_date']
            therapy.save(update_fields=['datum','workflow_snapshot'])
        else:
            from dashboard.correction_forms import CorrectionForm
            from .data_corrections import make_preview_token, apply_signed_correction, _apply_plan
            form = CorrectionForm(result['legacy_raw'], patient=patient, scope='migration')
            require(form.is_valid(), form.errors.as_text())
            if backup.get('simulation'):
                # Same native domain adapter, under the caller's rollback-only
                # savepoint. Backup and immutable receipts belong to real save.
                _apply_plan(patient, result, form.cleaned_data, user)
            else:
                _, token = make_preview_token(patient, 'migration', form, user)
                apply_signed_correction(token, patient, user)
    elif category in ('medicine', 'route', 'plan', 'change'):
        from dashboard.correction_plan_views import form_for, apply_plan
        form = form_for(patient, 'medicine', raw)
        form.guided_workflow = True
        require(form.is_valid(), form.errors.as_text())
        apply_plan(patient, 'medicine', form, user, historical=category=='change')
    elif category == 'transition':
        from .ustekinumab_transition import apply_reviewed_plan
        apply_reviewed_plan(patient, result, user, operation, backup)
    elif category in ('therapy', 'home'):
        events.apply_plan(result, user, operation, backup)
        if category == 'therapy':
            schedule = result['schedule']
            if schedule['schedule']:
                from .therapy_workflow import schedule_therapy_appointment
                from datetime import time
                # Only the currently active medication can create a new future
                # appointment; an old therapy never replaces a newer plan.
                if patient.lijek_id == medicine.pk:
                    schedule_therapy_appointment(pacijent=patient, lijek=medicine, datum=events.day(schedule['due']),
                        vrijeme=time(8), user=user, reason=raw['note'])
    elif category == 'receipt':
        if result.get('event_raw'):
            event_plan = events.preview(result['event_raw'], user)
            events.apply_plan(event_plan, user, operation, backup)
        else:
            from dashboard.views import promijeni_zalihu
            from .inventory_trace import stock_action
            from .physical_stock_corrections import _preserve_ledger_baseline
            stock = m.Zaliha.objects.filter(lijek=medicine).first()
            if stock:
                _preserve_ledger_baseline(stock, user)
            with stock_action(operation_id=operation):
                _, movement = promijeni_zalihu(lijek=medicine, kolicina=raw['quantity'], frizider_delta=raw['quantity'],
                    korisnik=user, akcija='Naknadno zaprimanje', opis=raw['note'], datum=events.day(raw['event_date']),
                    vrati_transakciju=True, tip_transakcije='ZAPRIMANJE', serija=raw.get('batch', ''),
                    rok_trajanja=events.day(raw.get('expires'), optional=True))
            receipt = m.UnlinkedStockReceipt.objects.create(operation_id=operation, user=user, medicine=medicine,
                event_date=raw['event_date'], quantity=raw['quantity'], batch=raw.get('batch', ''), expires=raw.get('expires') or None,
                note=raw['note'], delivery_reference=raw.get('delivery_reference') or str(operation), movement=movement, backup=backup)
            movement.referenca_tip = 'UnlinkedStockReceipt'; movement.referenca_id = receipt.pk
            movement.save(update_fields=['referenca_tip', 'referenca_id'])
    elif category == 'deferred':
        from .therapy_workflow import mark_no_show, postpone_therapy
        appointment = m.Termin.objects.get(pk=raw['appointment_id'], pacijent=patient)
        if raw['decision'] == 'postpone':
            postpone_therapy(termin=appointment, reason=raw['note'], user=user,
                            new_date=events.day(raw.get('new_date'), optional=True))
        else:
            mark_no_show(termin=appointment, reason=raw['note'], user=user)
    # Other events deliberately add only the dated audit receipt.
