"""Five explicitly synthetic development cases. No diagnostic rules are changed.

The reset is restricted to a named local synthetic PostgreSQL database. It
clears an explicit, FK-closed operational table set in one transaction, never
CASCADEs into configuration, and checks preserved data before committing.
"""
import hashlib
import json
from datetime import date, datetime, time
from decimal import Decimal
from pathlib import Path

from django.apps import apps
from django.conf import settings
from django.contrib.admin.models import LogEntry
from django.core.serializers.json import DjangoJSONEncoder
from django.db import connection, transaction
from django.utils import timezone

from . import models as m
from .fridge_history import remember_fridge_checkpoint
from .inventory_trace import link_receipt_evidence, stock_action

MARKER = 'TEST_DIAGNOSTICS_FIVE_V1'
DECISION = date(2026, 9, 16)
KEEP = set('TerapijskiProgram Lijek TerapijskaFaza TerapijskiProtokol TerapijskiKorakProtokola '
    'StandardniOralniRezim DokumentSablon KorisnickiPristup Ljekar PostavkeSistema '
    'LogistickePostavkeLijeka'.split())
REMOVE = set('Pacijent Komisija PacijentZaduzenje KucnoIzdavanje PromjenaTerapije Termin Terapija '
    'PauzaTerapije TerapijaStatusHistorija Zaliha MigracijskiSnapshotPacijenta KucnaTerapijaPodatak '
    'MigracijskoPocetnoStanjeZalihe HistorijskoStanjeFrizidera ZalihaTransakcija PotrebaFizickogPokrica '
    'PacijentRezervacija DokumentPacijenta IndividualniProtokolPacijenta IndividualniKorakProtokola '
    'IzmjenaIndividualnogProtokola AktivnostLog KomisijskoIskljucenje KomisijskiRucniUnos Trebovanje '
    'KomisijskiCiklus PacijentSaglasnost EvidencijaSaglasnostiZaprimanja KomisijskiZahtjev '
    'KomisijskaStavkaLijeka KomisijskaSaglasnost FazniProtokolPacijenta AdaptiveDecisionRecord '
    'OralniTerapijskiRezim IzdavanjeOralneTerapije OperationalOutcome AdaptiveInsight '
    'PatientDataCorrection BrzaIzmjenaPacijenta OralnoRazduzenjeRezervacije '
    'PhysicalStockCorrection ReconciliationAction ReconciliationSession '
    'RetrospectiveBatch RetrospectiveEvent UnlinkedStockReceipt '
    # These document/evidence rows belong to the operational commission cycle.
    # Their protected FKs must be inside the reviewed TRUNCATE closure too.
    'KomisijskiDokumentOdluke KomisijskaDokumentStavka'.split())
CASES = (
    ('T01', 'Lejla', 'Pen', date(1990,1,1), 'Ž', 'K50.9', 'Hyrimoz', 8, 8, date(2026,9,14), date(2026,9,28)),
    ('T02', 'Mirza', 'Pen', date(1985,2,2), 'M', 'K50.9', 'Hyrimoz', 4, 4, date(2026,9,17), date(2026,10,1)),
    ('T03', 'Ena', 'Infuzija', date(1988,3,3), 'Ž', 'K51.9', 'Entyvio', 3, 0, date(2026,8,5), date(2026,9,30)),
    ('T04', 'Emir', 'Infuzija', date(1980,4,4), 'M', 'K50.9', 'Remsima', 8, 4, date(2026,8,6), date(2026,10,1)),
    ('T05', 'Sara', 'Tablete', date(1992,5,5), 'Ž', 'K51.9', 'Xeljanz 5 mg', 224, 224, None, None),
)


def safe_target(expected_name):
    db = connection.settings_dict
    name = str(db['NAME'])
    if (settings.PRODUCTION_MODE or not settings.DEBUG or len(settings.DATABASES) != 1
            or settings.DATABASE_ROUTERS or db['ENGINE'] != 'django.db.backends.postgresql'
            or db['HOST'] not in {'127.0.0.1', 'localhost', '::1'}
            or name != expected_name or not name.startswith(('theraflow_synthetic_', 'test_theraflow_synthetic_'))
            or Path(settings.ENV_FILE).resolve() != (Path(settings.BASE_DIR)/'.env').resolve()):
        raise ValueError('Dozvoljena je samo imenovana lokalna sintetička razvojna baza; originalna/ambulantna baza je zabranjena.')
    with connection.cursor() as c:
        c.execute('SELECT current_database(), inet_server_addr()::text, inet_server_port()')
        actual, address, port = c.fetchone()
    if actual != name or address not in {'127.0.0.1/32','::1/128'} or str(port) != str(db['PORT']):
        raise ValueError('Stvarni server nije potvrđeni lokalni razvojni cilj.')
    return {'name':actual, 'host':address, 'port':port}


def model_sets():
    models = list(apps.get_app_config('patients').get_models())
    if {x.__name__ for x in models} != KEEP | REMOVE:
        raise ValueError('Modeli su promijenjeni: ručno pregledati opseg čišćenja prije zamjene.')
    # Admin audit can retain old patient names in object_repr/change_message.
    # It is operational history, not an account or application setting.
    removing = [x for x in models if x.__name__ in REMOVE] + [LogEntry]
    # New audit wrappers have automatic M2M tables with incoming FKs too.
    # Include only through tables owned by the explicitly reviewed REMOVE set.
    removing += [field.remote_field.through for model in list(removing)
                 for field in model._meta.local_many_to_many
                 if field.remote_field.through._meta.auto_created]
    preserving = [x for x in apps.get_models(include_auto_created=True) if x not in removing]
    return removing, preserving


def fingerprint(models):
    return {model._meta.label:{'count':model.objects.count(), 'sha256':hashlib.sha256(json.dumps(
        list(model.objects.order_by('pk').values()), sort_keys=True, cls=DjangoJSONEncoder).encode()).hexdigest()}
        for model in models}


def fixture_digest():
    removing, _ = model_sets()
    return hashlib.sha256(json.dumps(fingerprint([x for x in removing if x != m.AktivnostLog]),
        sort_keys=True).encode()).hexdigest()


def configuration():
    result = {}
    for name in {row[6] for row in CASES}:
        drug = m.Lijek.objects.get(naziv=name)
        if name == 'Xeljanz 5 mg':
            oral = m.StandardniOralniRezim.objects.get(lijek=drug, aktivan=True)
            if drug.jedinice_zalihe[0] != 'tableta':
                raise ValueError('Xeljanz nema eksplicitnu jedinicu tableta.')
            result[name] = (drug, None, None, oral)
            continue
        protocol = m.TerapijskiProtokol.objects.get(lijek=drug, aktivan=True)
        step = m.TerapijskiKorakProtokola.objects.get(protokol=protocol, faza='ODRZAVANJE', aktivan=True)
        if not step.broj_jedinica or step.broj_jedinica != protocol.doza_po_aplikaciji:
            raise ValueError('Testni protokol nema jednoznačnu količinu održavanja.')
        if (step.interval_sedmica or protocol.interval_odrzavanja_sedmica) != (2 if name == 'Hyrimoz' else 8):
            raise ValueError('Postojeći protokol ne odgovara traženom testnom intervalu.')
        if drug.jedinice_zalihe[0] != ('pen' if name == 'Hyrimoz' else 'bočica'):
            raise ValueError('Prezentacija lijeka ne odgovara testnom skupu.')
        result[name] = (drug, protocol, step, None)
    return result


def clear_operational_tables(removing):
    """PostgreSQL atomically handles cycles; NEVER use TRUNCATE CASCADE."""
    tables = {x._meta.db_table for x in removing}
    with connection.cursor() as c:
        c.execute("SELECT child.relname,parent.relname FROM pg_constraint con "
            "JOIN pg_class child ON child.oid=con.conrelid "
            "JOIN pg_class parent ON parent.oid=con.confrelid WHERE con.contype='f'")
        incoming = [(child,parent) for child,parent in c.fetchall() if parent in tables and child not in tables]
        if incoming:
            raise ValueError(f'Neobuhvaćene vanjske veze: {incoming}')
        c.execute('TRUNCATE '+', '.join(connection.ops.quote_name(t) for t in sorted(tables)))
    if any(model.objects.exists() for model in removing):
        raise ValueError('Operativno čišćenje nije potpuno.')


def create_cases(config, received_on):
    if received_on < DECISION or received_on > timezone.localdate():
        raise ValueError('Datum testnog prijema mora biti od odluke do dana kreiranja.')
    cycle = m.KomisijskiCiklus.objects.create(naziv=MARKER, datum_komisije=DECISION,
        datum_odobrenja=DECISION, status='DJELOMICNO_ZAPRIMLJENO')
    for drug, _, _, _ in config.values():
        m.Zaliha.objects.create(lijek=drug, u_frizideru=0, kod_pacijenata=0)
        opening = m.MigracijskoPocetnoStanjeZalihe.objects.create(lijek=drug, kolicina=0)
        # This is a known empty synthetic ledger, not a guessed historical zero.
        stamp = timezone.make_aware(datetime.combine(received_on, time.min))
        m.MigracijskoPocetnoStanjeZalihe.objects.filter(pk=opening.pk).update(izmijenjeno=stamp)
        opening.refresh_from_db(); remember_fridge_checkpoint(opening)
    for code, first, last, born, sex, diagnosis, name, approved, received, previous, planned in CASES:
        drug, protocol, step, oral = config[name]
        qty = step.broj_jedinica if step else None
        patient = m.Pacijent.objects.create(ime=f'{code} TEST {first}', prezime=last,
            broj_kartona=f'TEST-{code}', jmbg=None, datum_rodenja=born, spol=sex,
            dijagnoza='Crohnova bolest' if diagnosis=='K50.9' else 'Ulcerozni kolitis',
            mkb_sifra=diagnosis, lijek=drug, terapijski_program=drug.terapijski_program,
            terapijski_protokol=protocol, predlozeni_oralni_rezim=oral,
            pocetna_faza_terapije=oral.faza if oral else 'ODRZAVANJE',
            interval_sedmica=2 if name=='Hyrimoz' else 8,
            kolicina_po_terapiji=qty, aktivan=True)
        if previous:
            # Only the supplied historical application/date. No fabricated issue,
            # old approval, physical receipt or patient's remaining home balance.
            m.Terapija.objects.create(pacijent=patient, lijek=drug, datum=previous,
                terapijski_korak=step, kolicina=qty, doza_mg=step.doza_mg,
                faza_terapije='ODRZAVANJE', interval_sedmica=patient.interval_sedmica,
                is_migration=True, workflow_snapshot={'synthetic_dataset':MARKER,
                    'vrsta':'HISTORIJSKI_DATUM', 'napomena':'TEST: datum iz specifikacije; raniji promet nije rekonstruisan.'})
            m.Termin.objects.create(pacijent=patient, lijek=drug, datum=planned,
                vrijeme=time(9), kolicina_po_terapiji=qty, status='ZAKAZAN')
        if oral:
            m.OralniTerapijskiRezim.objects.create(pacijent=patient, lijek=drug, standardni_rezim=oral,
                tableta_po_uzimanju=oral.tableta_po_uzimanju, uzimanja_dnevno=oral.uzimanja_dnevno,
                datum_od=DECISION, faza=oral.faza, napomena_ljekara='TEST: postojeći testni režim; nije klinička preporuka.')
        number = f'TEST-20260916-{code}'
        approval = m.Komisija.objects.create(pacijent=patient, lijek=drug, datum_odobrenja=DECISION,
            broj_saglasnosti=number, broj_odobrenih_doza=approved, preostale_doze=approved, status='ODOBRENA')
        request = m.Trebovanje.objects.create(pacijent=patient, lijek=drug, komisija=approval,
            komisijski_ciklus=cycle, protokol=protocol, faza_terapije=oral.faza if oral else 'ODRZAVANJE',
            broj_doza=approved, odobrene_doze=approved, zaprimljene_doze=received,
            sistemski_prijedlog=approved, zaduzenje_kreirano=bool(received),
            status='ZAPRIMLJENO' if received==approved else 'CEKA_ISPORUKU' if received else 'ODOBRENO',
            napomena=f'{MARKER}: namjerni testni prijem {received}; nije dokument stvarne isporuke.')
        modern = m.KomisijskiZahtjev.objects.create(pacijent=patient, komisijski_ciklus=cycle,
            vrsta_zahtjeva='bioloska_produzenje', status='odluceno', sistem_predlozio=approved,
            ljekar_trazi=approved, finalna_kolicina=approved, napomena=MARKER)
        m.KomisijskaStavkaLijeka.objects.create(komisijski_zahtjev=modern, lijek=drug,
            kolicina=approved, odobrena_kolicina=approved,
            jedinica='flakon' if drug.jedinice_zalihe[0]=='bočica' else drug.jedinice_zalihe[0])
        agreement = m.PacijentSaglasnost.objects.create(pacijent=patient, broj_saglasnosti=number,
            vazi_od=DECISION, izvorni_ciklus=cycle, izvorno_trebovanje=request, izvorna_komisija=approval)
        if received:
            stock = m.Zaliha.objects.get(lijek=drug)
            stock.u_frizideru += Decimal(received); stock.save()
            with stock_action(cycle_id=cycle.pk):
                movement = m.ZalihaTransakcija.objects.create(lijek=drug, pacijent=patient,
                    komisija=approval, tip='ZAPRIMANJE', kolicina=received, datum=received_on,
                    referenca_tip='Trebovanje', referenca_id=request.pk, lokacija='FRIZIDER',
                    rezervisana_pacijentu=True, napomena=MARKER)
                reservation = m.PacijentRezervacija.objects.create(pacijent=patient, lijek=drug,
                    komisija=approval, trebovanje=request, kolicina=received, napomena=MARKER)
                audit = m.EvidencijaSaglasnostiZaprimanja.objects.create(saglasnost=agreement,
                    pacijent=patient, trebovanje=request, komisijski_ciklus=cycle,
                    broj_saglasnosti_snapshot=number, zaprimljena_kolicina=received)
                link_receipt_evidence(audit, movement, reservation)
    return cycle


@transaction.atomic
def seed(*, expected_name, replace=False, received_on=None):
    target = safe_target(expected_name)
    with connection.cursor() as c:
        c.execute('SELECT pg_advisory_xact_lock(20260925, 5)')
    removing, preserving = model_sets()
    config = configuration()  # Fail before any deletion if protocol inputs are absent.
    marker = m.AktivnostLog.objects.filter(akcija=MARKER).first()
    if marker and not replace:
        if json.loads(marker.opis)['digest'] != fixture_digest():
            raise ValueError('TEST skup je izmijenjen; običan ponovni poziv ga ne prepisuje. Koristite eksplicitnu zamjenu s novim backupom.')
        return {'created':False, 'unchanged':True, 'target':target, 'patients':m.Pacijent.objects.count()}
    if not replace and any(model.objects.exists() for model in removing):
        raise ValueError('Baza sadrži operativne podatke. Potrebna je eksplicitna zamjena i provjeren backup.')
    before = {x.__name__:x.objects.count() for x in removing}
    preserved = fingerprint(preserving)
    if replace:
        clear_operational_tables(removing)
    create_cases(config, received_on or timezone.localdate())
    m.AktivnostLog.objects.create(akcija=MARKER, opis=json.dumps({'digest':fixture_digest(),
        'decision':DECISION.isoformat(),'historical_applications':'supplied dates only; no invented receipts'}))
    if preserved != fingerprint(preserving):
        raise ValueError('Korisnici, katalog ili postavke su promijenjeni; cijela zamjena je vraćena.')
    return {'created':True,'target':target,'preserved_equal':True,'before':before,
        'after':{x.__name__:x.objects.count() for x in removing}}
