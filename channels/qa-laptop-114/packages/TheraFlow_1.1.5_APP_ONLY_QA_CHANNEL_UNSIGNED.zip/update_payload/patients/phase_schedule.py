"""Audited future booking reconciliation; never rewrite past administrations."""
from collections import Counter
from datetime import timedelta
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone
from . import models as m
from .phased_protocols import current_phase_details, ensure_phase_reservation
from .therapy_workflow import schedule_therapy_appointment, record_status_history


@transaction.atomic
def reconcile_phase_schedule(*, state, previous, user, planned_date=None, planned_time=None, reason):
    m.Pacijent.objects.select_for_update().get(pk=state.pacijent_id)
    details = current_phase_details(state)
    if details.get('dose_error'):
        raise ValidationError(details['dose_error'])
    pending = list(m.Termin.objects.select_for_update().filter(pacijent_id=state.pacijent_id,
        status=m.Termin.STATUS_PLANIRANA, datum__gte=timezone.localdate()).order_by('datum','vrijeme','pk'))
    keys = Counter((a.lijek_id, a.datum) for a in pending)
    if any(count > 1 for count in keys.values()):
        raise ValidationError('Potrebna provjera nakon 1.1.1: dupli budući termini. Razriješite ih uz audit prije izmjene protokola.')
    # Changing presentations preserves the old reservation, even when linked to
    # a now-cancelled booking. It must be reviewed/released explicitly.
    old_ids = {previous['iv_lijek_id'], previous['sc_lijek_id']}
    current_bookings = [app for app in pending if app.lijek_id == details['medicine'].pk]
    # A changed maintenance interval or clinical anchor must also move the
    # future plan. Repeated saves of the same prescription keep its dates.
    anchor_changed = any(previous.get(key) != getattr(state, key).isoformat()
        for key in ('sljedeci_datum',) if getattr(state, key) is not None)
    redate = bool(planned_date or (state.sljedeci_datum and (
        previous.get('faza') != state.faza or
        previous.get('interval_odrzavanja_sedmica') != state.interval_odrzavanja_sedmica or anchor_changed)))
    next_date = planned_date or state.sljedeci_datum
    replacements = {}
    if redate:
        from .scheduling import adjust_to_allowed_therapy_date, validate_new_active_appointment_date
        validate_new_active_appointment_date(next_date)
        if not details['interval_weeks'] and len(current_bookings) > 1:
            raise ValidationError('Više budućih IV indukcija zahtijeva ručnu provjeru prije pomjeranja termina.')
        for index, app in enumerate(current_bookings):
            next_date = adjust_to_allowed_therapy_date(next_date,
                lijek=details['medicine'], protokol=state.pacijent.aktivni_protokol()).datum
            replacements[app.pk] = next_date
            if index + 1 < len(current_bookings):
                if state.faza == state.FAZA_ODRZAVANJE:
                    from .regimen_changes import next_regimen_date
                    _, next_date = next_regimen_date(state.pacijent, next_date,
                        current_phase_details(state, next_date)['interval_weeks'])
                else:
                    next_date += timedelta(weeks=details['interval_weeks'])
    proposed = []
    for app in pending:
        if app.lijek_id not in old_ids:
            raise ValidationError('Budući termin koristi drugu terapiju; potrebna je ručna provjera.')
        if app.lijek_id != details['medicine'].pk:
            app.status = m.Termin.STATUS_OTKAZANA
            app.save(update_fields=['status'])
            record_status_history(pacijent=state.pacijent, termin=app, user=user,
                previous_status=m.Termin.STATUS_PLANIRANA, new_status=app.status,
                reason=reason, previous_state={'lijek_id':app.lijek_id},
                new_state={'lijek_id':app.lijek_id}, event_type=m.TerapijaStatusHistorija.DOGADJAJ_TERMIN_OTKAZAN)
        else:
            before = {'quantity': str(app.kolicina_po_terapiji), 'date':str(app.datum), 'time':str(app.vrijeme)}
            app.datum = replacements.get(app.pk, app.datum)
            app.kolicina_po_terapiji = current_phase_details(state, app.datum)['units']
            if app == current_bookings[0] and planned_time is not None:
                app.vrijeme = planned_time
            if before['date'] != str(app.datum):
                from .appointment_reschedule import daily_capacity_issues
                issues, _ = daily_capacity_issues(app, app.datum,
                    excluded=[item.pk for item in pending], proposed=proposed)
                if issues:
                    raise ValidationError(" ".join(issues))
            proposed.append({'new_date': str(app.datum), 'new_time': app.vrijeme.isoformat()})
            after = {'quantity':str(app.kolicina_po_terapiji), 'date':str(app.datum), 'time':str(app.vrijeme)}
            if before == after:
                continue
            app.save(update_fields=['kolicina_po_terapiji', 'datum', 'vrijeme'])
            record_status_history(pacijent=state.pacijent, termin=app, user=user,
                previous_status=app.status, new_status=app.status, reason=reason,
                previous_state=before, new_state=after,
                event_type=m.TerapijaStatusHistorija.DOGADJAJ_TERMIN_PROMIJENJEN)
    replacement_date = planned_date or (state.sljedeci_datum if pending and redate else None)
    if replacement_date and not current_bookings:
        from .scheduling import adjust_to_allowed_therapy_date
        replacement_date = adjust_to_allowed_therapy_date(replacement_date,
            lijek=details['medicine'], protokol=state.pacijent.aktivni_protokol()).datum
        app, _ = schedule_therapy_appointment(pacijent=state.pacijent, lijek=details['medicine'],
            datum=replacement_date, vrijeme=planned_time or (pending[0].vrijeme if pending else None), user=user, reason=reason,
            kolicina_po_terapiji=current_phase_details(state, replacement_date)['units'])
        if planned_date:
            ensure_phase_reservation(state=state, appointment=app, user=user)
    from .commission_planning import recalculate_patient_commission_drafts
    recalculate_patient_commission_drafts(state.pacijent, user=user, reason=reason)
