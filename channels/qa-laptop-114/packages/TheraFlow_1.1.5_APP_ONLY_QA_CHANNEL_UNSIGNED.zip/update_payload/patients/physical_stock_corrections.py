"""Correct a medicine's actual fridge total without changing patient allocations."""
from decimal import Decimal
import uuid

from django.core import signing
from django.db import connection, transaction
from django.db.models import Sum
from django.utils import timezone

from . import models as m
from .data_corrections import (CorrectionBlocked, backup_before_correction, captured_rows,
                              differences, digest, require, serial)
from .request_cache import begin_request_cache, end_request_cache

SALT = "theraflow.physical-stock-correction.v1"


def _administrator(user):
    from dashboard.permissions import je_admin
    require(user.is_authenticated and user.is_active and je_admin(user),
            "Fizičku zalihu može ispraviti samo TheraFlow administrator.")


def stock_summary(medicine):
    from .medication_groups import strict_equivalent_medicine_ids
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    quantity = stock.u_frizideru if stock else Decimal("0")
    ids = strict_equivalent_medicine_ids(medicine)
    reserved = m.PacijentRezervacija.objects.filter(lijek_id__in=ids, aktivno=True, kolicina__gt=0)
    return {
        "medicine_id": medicine.pk, "medicine": str(medicine), "unit": medicine.jedinice_zalihe[0],
        "stock_id": stock.pk if stock else None, "before": quantity,
        "reserved": reserved.filter(lijek=medicine).aggregate(n=Sum("kolicina"))["n"] or Decimal("0"),
        "group_reserved": reserved.aggregate(n=Sum("kolicina"))["n"] or Decimal("0"),
        "group_before": m.Zaliha.objects.filter(lijek_id__in=ids).aggregate(n=Sum("u_frizideru"))["n"] or Decimal("0"),
    }


def preview(cleaned):
    from .inventory import izracunaj_frizider_iz_transakcija
    medicine, new = cleaned["lijek"], cleaned["kolicina"]
    reason = cleaned["razlog"].strip()
    require(5 <= len(reason) <= 500, "Unesite razlog korekcije (5–500 znakova).")
    require(new.is_finite() and 0 <= new <= Decimal("999999.99") and new == new.to_integral_value(),
            "Unesite nenegativan cijeli broj pojedinačnih jedinica lijeka.")
    plan = stock_summary(medicine)
    if cleaned.get('previous_correction_id'):
        previous = m.PhysicalStockCorrection.objects.filter(pk=cleaned['previous_correction_id'], lijek=medicine).first()
        require(previous is not None, 'Prethodna korekcija ne pripada ovom lijeku.')
        movements = m.ZalihaTransakcija.objects.filter(lijek=medicine,
            referenca_tip='PhysicalStockCorrection', referenca_id=previous.pk)
        require(movements.count() == 1, 'Prethodnom brojanju nedostaje jednoznačan fizički promet.')
        require(not m.ZalihaTransakcija.objects.filter(lijek=medicine, pk__gt=movements.get().pk).exists(),
                'Poslije ove korekcije postoje novi prometi ili dodjele. Razjasnite kasnije događaje; novo današnje brojanje ostaje zaseban postupak.')
        plan['previous_correction_id'] = previous.pk
    from .stock_lots import coverage_preview, lot_balances
    lots = lot_balances(medicine)
    scope = cleaned.get('obuhvat') or 'TOTAL'
    batch, expiry = (cleaned.get('serija') or '').strip(), cleaned.get('rok_trajanja')
    event_date = cleaned.get('datum_dogadjaja') or timezone.localdate()
    cause = cleaned.get('razlog_kod') or 'COUNT_UNKNOWN'
    require(event_date <= timezone.localdate(), 'Datum fizičkog brojanja ne može biti u budućnosti.')
    require(cause != 'RECEIPT_ERROR', 'Poznat uzrok je pogrešno zaprimanje. Otvorite Ispravi podatak uz konkretan prijem; tako se provjeravaju njegove raspodjele i kasnija potrošnja.')
    total_before = plan['before']
    if scope == 'LOT':
        require(bool(batch), 'Za konkretnu seriju unesite oznaku sa pakovanja.')
        require((batch, expiry) in lots, 'Serija i rok nisu dokumentovani u prometu. Najprije provjerite izvorni prijem; sistem ne pretpostavlja seriju.')
        plan['before'] = lots[(batch, expiry)]
        require(plan['before'] >= 0, 'Prometi serije nisu usklađeni. Potrebna je provjera izvornog prijema i izdavanja.')
    else:
        require(not batch and not expiry, 'Odaberite obuhvat konkretne serije za upis serije/roka.')
        require(not any(key[0] and value for key, value in lots.items()),
                'Postoje dokumentovane serije. Odaberite konkretnu seriju i rok kako razlika ne bi bila proizvoljno raspoređena.')
    require(new != plan["before"], "Nova količina jednaka je trenutnom stanju; nema korekcije za knjiženje.")
    delta = new - plan["before"]
    plan.update(after=new, delta=delta, delta_display=f"{delta:+g}", reason=reason, warnings=[])
    plan.update(scope=scope, batch=batch, expires=str(expiry or ''), event_date=str(event_date),
                cause=cause, total_before=total_before, total_after=total_before+delta)
    plan['cause_label'] = ('Razlika pri popisu — uzrok za provjeru' if cause == 'COUNT_UNKNOWN'
                           else 'Ispravka pogrešnog početnog stanja')
    require(plan['total_after'] >= 0, 'Dokumentovane serije nisu usklađene s ukupnim saldom. Prvo razjasnite porijeklo i potrošnju; korekcija ne smije stvoriti negativno stanje.')
    plan['coverage'] = coverage_preview(medicine, total_before, plan['total_after'])
    if plan['total_after'] < plan["reserved"]:
        plan["warnings"].append(
            f"Neslaganje: nova fizička zaliha {plan['total_after']:g} manja je od rezervisane količine {plan['reserved']:g} "
            f"za {plan['reserved'] - plan['total_after']:g} {plan['unit']}. Korekcija je dozvoljena; rezervacije ostaju neizmijenjene i zahtijevaju zasebnu provjeru.")
    group_after = plan["group_before"] + delta
    if group_after < plan["group_reserved"] and plan["group_reserved"] != plan["reserved"]:
        plan["warnings"].append(
            f"U grupi ekvivalentnih prezentacija ostaje {group_after:g}, a rezervisano je {plan['group_reserved']:g}. "
            "Neslaganje se evidentira bez automatske preraspodjele rezervacija.")
    if izracunaj_frizider_iz_transakcija(medicine) != total_before:
        plan["warnings"].append("Prometi i trenutno evidentirano stanje se razlikuju. Ispravka će sačuvati prethodne zapise i evidentirati novi kontrolni saldo.")
    return plan


def make_preview_token(form, user):
    _administrator(user)
    fingerprint = digest(captured_rows())
    plan = preview(form.cleaned_data)
    require(fingerprint == digest(captured_rows()), "Podaci su se promijenili tokom pregleda. Ponovo pregledajte ispravku.")
    payload = {"operation_id": str(uuid.uuid4()), "user_id": user.pk,
               "medicine_id": plan["medicine_id"], "quantity": str(plan["after"]),
               "reason": plan["reason"], "fingerprint": fingerprint,
               "context": serial({key: value for key, value in form.cleaned_data.items()
                                  if key in {'obuhvat', 'serija', 'rok_trajanja', 'datum_dogadjaja', 'razlog_kod', 'previous_correction_id'}})}
    return plan, signing.dumps(payload, salt=SALT, compress=True)


def _preserve_ledger_baseline(stock, user):
    """Keep historical checkpoints, then anchor a legacy unbalanced ledger today."""
    from .fridge_history import remember_fridge_checkpoint
    from .inventory import izracunaj_frizider_iz_transakcija
    initial = m.MigracijskoPocetnoStanjeZalihe.objects.filter(lijek=stock.lijek).first()
    if initial:
        remember_fridge_checkpoint(initial)
    if izracunaj_frizider_iz_transakcija(stock.lijek) == stock.u_frizideru:
        return
    last_id = m.ZalihaTransakcija.objects.filter(lijek=stock.lijek).order_by("-pk").values_list("pk", flat=True).first()
    if initial is None:
        initial = m.MigracijskoPocetnoStanjeZalihe.objects.create(lijek=stock.lijek, kolicina=stock.u_frizideru,
            ledger_checkpoint_id=last_id, kreirao=user, izmijenio=user)
    else:
        initial.kolicina, initial.ledger_checkpoint_id, initial.izmijenio = stock.u_frizideru, last_id, user
        initial.save(update_fields=["kolicina", "ledger_checkpoint_id", "izmijenio", "izmijenjeno"])
    remember_fridge_checkpoint(initial)


def apply_signed_correction(token, user):
    from dashboard.stock_correction_forms import PhysicalStockCorrectionForm
    from .inventory import izracunaj_frizider_iz_transakcija
    from .inventory_trace import stock_action
    from .utils import upisi_log
    _administrator(user)
    try:
        payload = signing.loads(token, salt=SALT)
    except signing.BadSignature:
        raise CorrectionBlocked("Pregled je istekao ili nije valjan. Ponovo pregledajte ispravku.") from None
    require(payload["user_id"] == user.pk, "Pregled pripada drugom korisniku.")
    cache = begin_request_cache(enabled=False)
    try:
        with transaction.atomic():
            # Same backup/write serialization used by existing administrator corrections.
            from .correction_protocol import lock_correction_tables
            lock_correction_tables()
            medicine = m.Lijek.objects.select_for_update().filter(pk=payload["medicine_id"]).first()
            require(medicine is not None, "Odabrani lijek više nije dostupan. Ponovo pregledajte ispravku.")
            existing = m.PhysicalStockCorrection.objects.filter(operation_id=payload["operation_id"]).first()
            if existing:
                require(existing.korisnik_id == user.pk and existing.lijek_id == medicine.pk, "Pregled pripada drugoj ispravci.")
                return existing, False
            try:
                signing.loads(token, salt=SALT, max_age=1800)
            except signing.BadSignature:
                raise CorrectionBlocked('Pregled je istekao. Ponovo pregledajte ispravku.') from None
            before = captured_rows()
            require(digest(before) == payload["fingerprint"], "Podaci su se promijenili nakon pregleda. Ništa nije upisano. Ponovo pregledajte ispravku.")
            form = PhysicalStockCorrectionForm({**payload.get('context', {}), "lijek": medicine.pk, "kolicina": payload["quantity"], "razlog": payload["reason"]})
            require(form.is_valid(), "Podaci više nisu valjani. Ponovo pregledajte ispravku.")
            form.cleaned_data['previous_correction_id'] = payload.get('context', {}).get('previous_correction_id')
            plan = preview(form.cleaned_data)
            try:
                backup = backup_before_correction(payload["operation_id"])
            except Exception as exc:
                raise CorrectionBlocked("Backup prije korekcije nije napravljen i verificiran. Ništa nije promijenjeno; provjerite backup u Postavkama sistema.") from exc
            return apply_plan(plan, user, payload["operation_id"], backup)
    finally:
        end_request_cache(cache)


@transaction.atomic
def apply_plan(plan, user, operation_id, backup):
    """Shared count write path; caller supplies validated preview and event lock."""
    from .inventory import izracunaj_frizider_iz_transakcija
    from .inventory_trace import stock_action
    from .utils import upisi_log
    _administrator(user)
    medicine = m.Lijek.objects.select_for_update().get(pk=plan["medicine_id"])
    before = captured_rows()
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    if stock is None:
        # This privileged correction can initialise an unrecorded physical count
        # even when legacy reservations already exceed it. Ordinary save guards stay intact.
        stock = m.Zaliha(lijek=medicine, u_frizideru=0, ukupno=0)
        m.Zaliha.objects.bulk_create([stock])
    _preserve_ledger_baseline(stock, user)
    # The explicit admin count is the only exception to the normal reservation
    # guard. Never call allocation/reconciliation hooks or change patient balances.
    m.Zaliha.objects.filter(pk=stock.pk).update(u_frizideru=plan["total_after"], ukupno=plan["total_after"])
    with stock_action(operation_id=operation_id):
        movement = m.ZalihaTransakcija.objects.create(lijek=medicine, tip="KOREKCIJA",
            kolicina=plan["delta"], promjena_salda=plan["delta"], lokacija="FRIZIDER", korisnik=user,
            datum=timezone.localdate(), napomena=plan["reason"], referenca_tip="PhysicalStockCorrection",
            serija=plan['batch'], rok_trajanja=plan['expires'] or None, razlog_kod=plan['cause'])
    require(izracunaj_frizider_iz_transakcija(medicine) == plan["total_after"], "Prometi ne odgovaraju novom fizičkom saldu. Korekcija je poništena.")
    changes, _ = differences(before, captured_rows())
    allowed = {"patients_zaliha", "patients_zalihatransakcija", "patients_migracijskopocetnostanjezalihe", "patients_historijskostanjefrizidera"}
    require(set(changes) <= allowed, "Neočekivana promjena pacijentovih podataka. Cijela korekcija je poništena.")
    from dashboard.permissions import korisnik_uloga
    audit_plan=dict(plan, actor_role=korisnik_uloga(user), source='physical_stock_correction')
    receipt = m.PhysicalStockCorrection.objects.create(operation_id=operation_id, lijek=medicine,
        korisnik=user, prethodna_kolicina=plan["before"], nova_kolicina=plan["after"], razlika=plan["delta"],
        razlog=plan["reason"], pregled=serial(audit_plan), backup=backup)
    movement.referenca_id = receipt.pk
    movement.save(update_fields=["referenca_id"])
    upisi_log(user, "Ispravka fizičke zalihe", objekat=receipt,
        opis=f"{medicine}: {plan['before']:g} → {plan['after']:g} ({plan['delta']:+g}); {plan['reason']}")
    return receipt, True
