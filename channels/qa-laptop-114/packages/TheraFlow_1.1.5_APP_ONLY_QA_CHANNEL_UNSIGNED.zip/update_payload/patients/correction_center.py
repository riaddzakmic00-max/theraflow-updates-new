"""Administrative orchestration over existing reservations and stock movements.

PatientDataCorrection is the existing audit receipt; this is not another ledger.
All amounts come from the inventory service and changes use its allocation path.
"""
from copy import deepcopy
from decimal import Decimal
from uuid import uuid4

from django.core import signing
from django.db.models import Sum
from django.utils import timezone

from . import models as m
from .correction_protocol import correction_transaction, correction_read_snapshot
from .data_corrections import (require, serial, captured_rows, digest, differences,
                               backup_before_correction)

SALT = 'theraflow.correction-center.reservation.v1'


def authorize(user):
    from dashboard.permissions import je_admin
    from django.core.exceptions import PermissionDenied
    if not (user.is_authenticated and user.is_active and je_admin(user)):
        raise PermissionDenied('Centar ispravki dostupan je administratoru.')


def state(patient, medicine):
    from .inventory import free_stock_quantity
    from .inventory import _physical_medicine_ids
    medicine_ids = _physical_medicine_ids(medicine)
    stocks = m.Zaliha.objects.filter(lijek_id__in=medicine_ids)
    reservations = m.PacijentRezervacija.objects.filter(lijek_id__in=medicine_ids, aktivno=True)
    own = reservations.filter(pacijent=patient) if patient else reservations.none()
    approvals = m.Komisija.objects.filter(pacijent=patient, lijek=medicine).order_by('pk') if patient else m.Komisija.objects.none()
    appointments = m.Termin.objects.filter(pacijent=patient, datum__gte=timezone.localdate(),
        status=m.Termin.STATUS_PLANIRANA).order_by('datum', 'vrijeme', 'pk') if patient else m.Termin.objects.none()
    total = lambda qs, field: qs.aggregate(n=Sum(field))['n'] or Decimal(0)
    return serial(dict(physical=total(stocks, 'u_frizideru'),
        free=free_stock_quantity(medicine), reserved=total(reservations, 'kolicina'),
        patient=total(own, 'kolicina'),
        home=total(m.PacijentZaduzenje.objects.filter(pacijent=patient, lijek=medicine, aktivno=True), 'preostalo') if patient else None,
        approvals=[dict(id=a.pk, approved=a.broj_odobrenih_doza, remaining=a.preostale_doze, status=a.status) for a in approvals],
        appointments=[dict(id=t.pk, date=t.datum, medicine=t.lijek_id, quantity=t.kolicina_po_terapiji) for t in appointments],
        therapies=m.Terapija.objects.filter(pacijent=patient, lijek=medicine, workflow_status='POTVRDJENA').count() if patient else None))


def rows(before, after):
    labels = {'physical':'Ukupna fizička zaliha', 'free':'Slobodna fizička zaliha',
        'reserved':'Ukupno rezervisano u ambulanti', 'patient':'Pacijentovo zaduženje u frižideru',
        'home':'Evidentirana kućna količina', 'approvals':'Komisijska odobrenja',
        'appointments':'Budući termini', 'therapies':'Broj potvrđenih primjena'}
    def display(value):
        if isinstance(value, list):
            names={'id':'Zapis','approved':'Odobreno','remaining':'Preostalo','status':'Status',
                   'date':'Datum','medicine':'Lijek','quantity':'Količina'}
            return '; '.join(', '.join(f'{names.get(k,k)}: {v}' for k,v in item.items()) for item in value) or 'Nema zapisa'
        return 'Nije primjenjivo' if value is None else str(value)
    return [dict(label=label, before=display(before[key]), after=display(after[key]),
                 unchanged=before[key]==after[key]) for key,label in labels.items()]


def allocation_plan(patient, medicine, raw, user):
    authorize(user)
    from .inventory import eligible_free_stock_recipients
    require(raw.get('kind','allocate')=='release' or eligible_free_stock_recipients(medicine).filter(pk=patient.pk).exists(),
        'Pacijent nema odgovarajući lijek / oblik. Provjerite odluku ljekara u Ispravi terapijski plan; IV i SC nisu zamjenjivi.')
    try:
        quantity = Decimal(str(raw.get('quantity', '')))
    except Exception:
        quantity = Decimal(-1)
    require(quantity.is_finite() and 0 < quantity <= 999999 and quantity == quantity.to_integral_value(),
        'Unesite pozitivnu cijelu količinu pojedinačnih jedinica lijeka.')
    reason = str(raw.get('reason','')).strip()
    require(5 <= len(reason) <= 500, 'Unesite razlog ispravke (5–500 znakova).')
    previous=None
    if raw.get('reverse_of'):
        previous=m.PatientDataCorrection.objects.filter(pk=raw['reverse_of'],scope='center_allocation',pacijent=patient).first()
        require(previous is not None and previous.posljedice.get('medicine_id')==medicine.pk,'Ispravka ne pripada ovom kartonu i lijeku.')
        require(not previous.naknadne_ispravke.exists(),'Ova ispravka već ima povezano poništavanje. Otvorite posljednju korekciju u historiji.')
        original=previous.posljedice
        require(quantity==Decimal(original['quantity']), 'Poništavanje mora odgovarati originalnoj količini.')
        last=m.ZalihaTransakcija.objects.filter(korekcija=previous).order_by('-pk').first()
        require(last is not None,'Nedostaje povezani promet. Otvorite historiju zaduženja i unesite zasebnu provjerenu ispravku količine.')
        later=m.ZalihaTransakcija.objects.filter(rezervacija_id=original['reservation_id'],pk__gt=last.pk).first()
        require(later is None,f'Kasniji promet #{later.pk if later else ""} koristi istu rezervaciju. Najprije pregledajte i ispravite taj događaj u historiji; original se ne briše.')
        require(raw.get('kind')==('release' if original['kind']=='allocate' else 'allocate'), 'Smjer poništavanja ne odgovara originalu.')
    kind = raw.get('kind', 'allocate')
    require(kind in {'allocate','release'}, 'Odaberite dodjelu ili oslobađanje pogrešnog zaduženja.')
    reason_code=raw.get('reason_code')
    if reason_code:
        require(kind!='release' or reason_code in ('free','mistake','other'),
            'Stvarna primjena i prijenos koriste svoj poslovni događaj; zaduženje se ne oslobađa kao obična ispravka.')
        from .correction_impact import ASSIGNMENT_REASONS
        require(reason_code in dict(ASSIGNMENT_REASONS),'Odaberite važeći razlog promjene zaduženja.')
        reason=(dict(ASSIGNMENT_REASONS)[reason_code]+': '+reason)[:500]
    before = state(patient, medicine); after = deepcopy(before)
    reservation = None
    if kind == 'allocate':
        require(quantity <= Decimal(str(before['free'])),
            f"Traženo {quantity:g}; stvarno slobodno {before['free']}; fizički {before['physical']}; rezervisano {before['reserved']}. "
            'Provjerite fizičko brojanje ili konkretno zaduženje u ovom centru, zatim se vratite na sačuvani unos.')
        delta = quantity
    else:
        reservation = m.PacijentRezervacija.objects.filter(pk=raw.get('reservation_id'),
            pacijent=patient, lijek=medicine, aktivno=True, kolicina__gt=0).first()
        require(reservation is not None, 'Odaberite konkretno postojeće zaduženje koje ispravljate.')
        require(reservation.kolicina >= quantity,
            f'Rezervacija #{reservation.pk} ima {reservation.kolicina:g}; traženo oslobađanje {quantity:g}. Pregledajte njene kasnije primjene u Historiji ispravki.')
        require(not reservation.termin_id or raw.get('acknowledge_appointment') is True,
            f'Rezervacija #{reservation.pk} je vezana za termin #{reservation.termin_id}. Potvrdite da pregledate gubitak njegovog pokrića; termin se ne otkazuje.')
        delta = -quantity
    for key in ('reserved','patient'):
        after[key] = str(Decimal(str(before[key])) + delta)
    # Use the canonical free amount, including restricted stock. Never a new ledger.
    from .inventory import _physical_medicine_ids
    from .inventory_corrections import restricted_allocation_quantity
    after['free'] = str(max(Decimal(0), Decimal(str(before['physical'])) - Decimal(after['reserved']) - restricted_allocation_quantity(_physical_medicine_ids(medicine))))
    warnings = ['Porijeklo nije utvrđeno za nedokumentovani dio. Ne izmišljaju se serija, rok, prijem ni komisijsko pravo.']
    if Decimal(after['reserved']) > Decimal(str(before['physical'])):
        warnings.append('Postoji fizički manjak; ova ispravka zaduženja ga ne prikriva niti mijenja odobrenje.')
    return serial(dict(kind=kind, patient_id=patient.pk, medicine_id=medicine.pk, quantity=quantity,
        reason=reason, reservation_id=reservation.pk if reservation else None,
        reason_code=reason_code,
        reverse_of=previous.pk if previous else None,
        restore_reservation_id=previous.posljedice['reservation_id'] if previous and kind=='allocate' else None,
        acknowledge_appointment=raw.get('acknowledge_appointment') is True,
        title='Dodijeli slobodne doze' if kind=='allocate' else 'Oslobodi pogrešno zaduženje',
        before=before, after=after, rows=rows(before,after), warnings=warnings,
        impacts=['Ne mijenjaju se fizička zaliha, kućna terapija, primjene, komisijsko pravo i datumi termina.']))


def make_preview(patient, medicine, raw, user):
    with correction_read_snapshot():
        patient = m.Pacijent.objects.get(pk=patient.pk)
        medicine = m.Lijek.objects.get(pk=medicine.pk)
        plan = allocation_plan(patient, medicine, raw, user)
        return plan, signing.dumps(dict(operation=str(uuid4()), user=user.pk,
            patient=patient.pk, medicine=medicine.pk, raw=serial(raw), fingerprint=digest(captured_rows())), salt=SALT, compress=True)


def confirm(token, user, *, patient_id=None, medicine_id=None, reverse_of=None):
    authorize(user)
    try:
        payload=signing.loads(token, salt=SALT)
    except signing.BadSignature:
        raise ValueError('Pregled nije važeći; ponovo pregledajte sačuvani unos.') from None
    require(payload['user']==user.pk, 'Potvrda pripada drugom korisniku.')
    require(patient_id is None or payload['patient']==patient_id, 'Potvrda pripada drugom pacijentu.')
    require(medicine_id is None or payload['medicine']==medicine_id, 'Potvrda pripada drugom lijeku.')
    require(reverse_of is None or payload['raw'].get('reverse_of')==reverse_of, 'Potvrda pripada drugoj korekciji.')
    with correction_transaction():
        existing=m.PatientDataCorrection.objects.filter(operation_id=payload['operation']).first()
        if existing:return existing,False
        try:signing.loads(token, salt=SALT, max_age=1800)
        except signing.BadSignature:raise ValueError('Pregled je istekao. Ponovo pregledajte sačuvani unos.') from None
        require(payload['fingerprint']==digest(captured_rows()), 'Stanje se promijenilo nakon pregleda. Ponovo pregledajte sačuvani unos; ništa nije knjiženo.')
        patient=m.Pacijent.objects.get(pk=payload['patient']);medicine=m.Lijek.objects.get(pk=payload['medicine'])
        plan=allocation_plan(patient,medicine,payload['raw'],user)
        before=captured_rows()
        try:backup=backup_before_correction(payload['operation'])
        except Exception as exc:
            raise ValueError('Backup nije napravljen i verificiran; ništa nije knjiženo. Otvorite Backup u aplikaciji, provjerite slobodan prostor i napravite ručni backup, zatim ponovite pregled ovog unosa.') from exc
        return apply_allocation_plan(plan, user, payload['operation'], backup)


def apply_allocation_plan(plan, user, operation_id, backup):
    """Canonical allocation mutation shared with guided period orchestration."""
    authorize(user)
    patient = m.Pacijent.objects.get(pk=plan["patient_id"])
    medicine = m.Lijek.objects.get(pk=plan["medicine_id"])
    payload = {"operation": operation_id}
    before = captured_rows()
    if plan.get('restore_reservation_id'):
        reservation=m.PacijentRezervacija.objects.get(pk=plan['restore_reservation_id'])
        require(reservation.potrosena_at is None,'Rezervacija je kasnije potrošena. Pregledajte povezanu primjenu prije poništavanja.')
        reservation.kolicina+=Decimal(plan['quantity']);reservation.aktivno=True
        reservation.save(update_fields=['kolicina','aktivno'])
        m.ZalihaTransakcija.objects.create(lijek=medicine,pacijent=patient,rezervacija=reservation,
            tip=m.ZalihaTransakcija.TIP_DODJELA_SLOBODNE_ZALIHE,kolicina=plan['quantity'],
            promjena_salda=0,promjena_rezervacije=plan['quantity'],datum=timezone.localdate(),
            korisnik=user,operation_id=payload['operation'],napomena=plan['reason'],
            referenca_tip='PatientDataCorrection',referenca_id=plan['reverse_of'])
    elif plan['kind']=='allocate':
        from .inventory import assign_free_stock_to_patient
        reservation=assign_free_stock_to_patient(pacijent=patient,lijek=medicine,
            quantity=plan['quantity'],user=user,reason=plan['reason'],operation_id=payload['operation'])
    else:
        reservation=m.PacijentRezervacija.objects.get(pk=plan['reservation_id'])
        reservation.kolicina-=Decimal(plan['quantity'])
        reservation.aktivno=reservation.kolicina>0
        reservation.save(update_fields=['kolicina','aktivno'])
        m.ZalihaTransakcija.objects.create(lijek=medicine,pacijent=patient,rezervacija=reservation,
            tip=m.ZalihaTransakcija.TIP_OSLOBADJANJE_U_SLOBODNU_ZALIHU,
            kolicina=plan['quantity'],promjena_salda=0,promjena_rezervacije=-Decimal(plan['quantity']),
            datum=timezone.localdate(),korisnik=user,operation_id=payload['operation'],
            referenca_tip='PatientDataCorrection',napomena=plan['reason']+'; sačuvana veza s izvornom rezervacijom.')
    after=captured_rows();old,new=differences(before,after)
    fresh=state(patient,medicine)
    require(all((Decimal(str(fresh[key]))==Decimal(str(plan['after'][key])))
                if key in {'physical','free','reserved','patient'} else fresh[key]==plan['after'][key]
                for key in fresh),
        'Naknadna provjera nije usklađena; cijela korekcija je vraćena, bez djelimičnog knjiženja.')
    plan['reservation_id']=reservation.pk
    receipt=m.PatientDataCorrection.objects.create(operation_id=payload['operation'],pacijent=patient,
        korisnik=user,scope='center_allocation',razlog=plan['reason'],datum_dogadjaja=timezone.localdate(),
        prije=old,poslije=new,posljedice=plan,backup=backup,ponistava_id=plan.get('reverse_of'))
    m.ZalihaTransakcija.objects.filter(operation_id=payload['operation']).update(korekcija=receipt)
    from .utils import upisi_log
    upisi_log(user,plan['title'],pacijent=patient,objekat=receipt,opis=plan['reason'])
    return receipt,True
