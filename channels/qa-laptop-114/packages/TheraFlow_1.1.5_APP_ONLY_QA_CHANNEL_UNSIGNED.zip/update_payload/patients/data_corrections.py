"""Administrative corrections: read-only preview, signed consent, backup, atomic audit.

Clinical changes and corrections are separate workflows. Allocation corrections
operate on a selected reservation. Independent physical stock counts live in
physical_stock_corrections.py.
"""
from datetime import date, timedelta, time
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import uuid

from django.conf import settings
from django.core import signing
from django.core.exceptions import ValidationError
from django.db import connection, transaction
from django.db.models import Sum, Q
from django.utils import timezone

from . import models as m
from .request_cache import begin_request_cache, end_request_cache, invalidate_after_write
from .patient_profile import PROFILE_FIELDS, PROFILE_LABELS, identification_changes

SALT = "theraflow.patient-correction.v1"


class CorrectionBlocked(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise CorrectionBlocked(message)


def serial(value):
    return json.loads(json.dumps(value, default=str, ensure_ascii=False))


def digest(value):
    return hashlib.sha256(json.dumps(serial(value), sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def captured_rows():
    """Stable full-row comparison catches concurrent changes and preserves history."""
    tables = sorted(t for t in connection.introspection.table_names()
                    if t.startswith(("patients_", "dashboard_")))
    result = {}
    with connection.cursor() as cursor:
        for table in tables:
            if connection.vendor == "postgresql":
                cursor.execute("SELECT to_jsonb(t)::text FROM " + connection.ops.quote_name(table) + " t")
                rows = [json.loads(row[0]) for row in cursor.fetchall()]
            else:
                cursor.execute("SELECT * FROM " + connection.ops.quote_name(table))
                names = [c[0] for c in cursor.description]
                rows = [serial(dict(zip(names, row))) for row in cursor.fetchall()]
            result[table] = {str(row["id"]): row for row in rows}
    return result


def differences(before, after):
    old, new = {}, {}
    for table, rows in before.items():
        for key in sorted(set(rows) | set(after[table])):
            left, right = rows.get(key), after[table].get(key)
            require(right is not None, "Ispravka je pokušala obrisati postojeći zapis. Operacija je poništena.")
            if left != right:
                old.setdefault(table, {})[key] = left
                new.setdefault(table, {})[key] = right
    return old, new


def backup_before_correction(operation_id):
    from dashboard.postgres_backup import (create_postgres_backup_at, validate_postgres_backup,
        executable_path, run_command, postgres_settings)
    require(connection.vendor == "postgresql", "Ispravke zahtijevaju PostgreSQL backup. Obratite se održavanju instalacije.")
    folder = Path(settings.THERAFLOW_BACKUP_DIR) / "corrections" / str(operation_id)
    folder.mkdir(parents=True, exist_ok=False)
    path = folder / "prije-ispravke.backup"
    create_postgres_backup_at(path)
    require(validate_postgres_backup(path), "Backup nije verificiran. Podaci nisu promijenjeni.")
    run_command([executable_path("pg_restore"), "--no-owner", "--no-privileges", "--file", os.devnull,
                 str(path)], postgres_settings(), timeout=300)
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    path.with_suffix(".backup.sha256").write_text(f"{checksum}  {path.name}\n", encoding="ascii")
    return {"path": str(path), "sha256": checksum, "size": path.stat().st_size,
            "verified": "pg_restore list and complete archive decoding"}


def target(model, patient, target_id):
    obj = model.objects.filter(pacijent=patient, pk=target_id).first()
    require(obj is not None, "Odaberite konkretan zapis iz ovog kartona. Zapis drugog pacijenta nije dozvoljen.")
    return obj


def migration(patient):
    snap = m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient).first()
    require(snap is not None, "Karton nema migracijski unos. Za postojeću terapiju ili izdavanje odaberite povezanu radnju; za novo izdavanje koristite Izdaj terapiju.")
    return snap


def amount(value):
    return Decimal(str(value))


def value_label(value):
    if value is None or value == "":
        return "Nije upisano"
    if isinstance(value, date):
        return value.strftime("%d/%m/%Y")
    return str(value)


def preview(patient, scope, cleaned, *, target_id=None):
    """Validate consequences without allocating IDs or writing any table."""
    from .inventory import inventory_position, izracunaj_frizider_iz_transakcija
    data = dict(cleaned)
    reason = str(data.pop("razlog", "")).strip()
    require(5 <= len(reason) <= 500, "Unesite kratak razlog ispravke (5–500 znakova).")
    plan = {"scope": scope, "patient_id": patient.pk, "target_id": target_id,
            "reason": reason, "data": serial({k: v.pk if isinstance(v, m.Lijek) else v for k, v in data.items()}),
            "rows": [], "impacts": []}
    def row(label, old, new):
        if old != new:
            plan["rows"].append({"label": label, "before": value_label(old), "after": value_label(new)})
    snap = m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient).first()
    if scope == "profile":
        require(set(data) <= set(PROFILE_FIELDS), "Osnovni podaci ne mogu mijenjati terapiju ili povezane evidencije.")
        plan["title"] = "Osnovni podaci pacijenta"
        plan["identification_fields"] = identification_changes(patient, data)
        for name, value in data.items():
            row(PROFILE_LABELS[name], getattr(patient, name) or None, value or None)
        plan["impacts"].append("Ispravlja se postojeći karton. Novi prikazi i dokumenti koriste ažurne podatke pacijenta; ranije spremljeni dokumenti i historija ostaju sačuvani.")
    elif scope == "medicine":
        medicine = data["lijek"]
        row("Lijek / prezentacija", patient.lijek, medicine)
        require(not (m.Terapija.objects.filter(pacijent=patient).exists()
            or m.Komisija.objects.filter(pacijent=patient).exists()
            or m.PacijentRezervacija.objects.filter(pacijent=patient).exists()
            or m.PacijentZaduzenje.objects.filter(pacijent=patient).exists()
            or m.Termin.objects.filter(pacijent=patient).exists()
            or m.IzdavanjeOralneTerapije.objects.filter(pacijent=patient).exists()
            or m.KucnaTerapijaPodatak.objects.filter(pacijent=patient).exists()
            or m.FazniProtokolPacijenta.objects.filter(pacijent=patient).exists()
            or m.IndividualniProtokolPacijenta.objects.filter(pacijent=patient).exists()),
            "Postoje povezane terapije, odobrenja, zalihe ili protokol. Njihov lijek se ne može preimenovati iz kartona. Pogrešnu radnju prvo kontrolisano poništite; za novu terapiju koristite Promijeni terapiju s datumom odluke.")
        require(not snap or (snap.fizicki_u_frizideru == 0 and snap.kod_pacijenta == 0 and snap.broj_odobrenih_doza == 0),
                "Migracija već sadrži količine. Ispravite njihove povezane radnje prije promjene prezentacije.")
        from .medication_groups import maintenance_interval_weeks
        interval = patient.interval_sedmica if patient.pocetna_faza_terapije == patient.FAZA_INDIVIDUALNI else maintenance_interval_weeks(medicine, patient.interval_sedmica)
        row("Interval prema odabranoj prezentaciji", patient.interval_sedmica, interval)
        row("Terapijski protokol", patient.terapijski_protokol, medicine.aktivni_protokol())
        plan["impacts"].append("Ispravlja se pogrešno odabrana prezentacija u kartonu bez povezanih radnji. Oblik, jačina, program i protokol preuzimaju se iz kataloga lijeka; prikazan je i njegov osnovni interval. Zatim provjerite propisani režim u Doza, interval i budući termini.")
    elif scope == "migration":
        snap = migration(patient)
        require(not patient.lijek.oralna_terapija, "Oralna migracija koristi datum izdavanja. Ispravite odgovarajuće oralno izdavanje, ne datum primjene.")
        require(not m.Terapija.objects.filter(pacijent=patient, is_migration=True).exists(),
                "Postoji zasebna historijska terapija. Ne smiju nastati dva različita datuma iste primjene. Otvorite Historiju i provjerite povezanu radnju prije ispravke.")
        if data["datum_posljednje_terapije"]:
            require(data["datum_posljednje_terapije"] <= timezone.localdate(), "Posljednja primjena ne može biti u budućnosti.")
        if data["datum_posljednje_terapije"] and data["sljedeca_terapija"]:
            require(data["sljedeca_terapija"] > data["datum_posljednje_terapije"], "Naredni datum mora biti poslije posljednje primjene.")
        row("Posljednja primjena iz migracije", snap.datum_posljednje_terapije, data["datum_posljednje_terapije"])
        row("Informativni naredni datum", snap.sljedeca_terapija, data["sljedeca_terapija"])
        plan["impacts"].append("Ispravljaju se migracijski datumi. Ne nastaje potvrđena terapija, izdavanje ili dolazak. Datum odobrenja se ne mijenja.")
        require(not patient.aktivni_fazni_protokol(), "Fazni protokol ima vlastiti potvrđeni vremenski oslonac. Ispravite datum kroz Postavke faznog protokola kako karton i faza ne bi prikazivali različite datume.")
    elif scope == "reservation":
        reservation = target(m.PacijentRezervacija, patient, target_id)
        require((reservation.aktivno or reservation.kolicina == 0) and reservation.potrosena_at is None, "Rezervacija je već potrošena ili zatvorena. Otvorite i poništite pogrešnu povezanu terapiju/izdavanje.")
        medicine = reservation.lijek
        stock = m.Zaliha.objects.filter(lijek=medicine).first()
        require(stock is not None, "Nedostaje fizički saldo lijeka. Otvorite Zalihe → Početno stanje radi provjere.")
        new = data["kolicina"]
        require(new == new.to_integral_value(), "Fizička količina mora biti cijeli broj pojedinačnih jedinica lijeka.")
        if reservation.migracijski_snapshot_id:
            source = reservation.migracijski_snapshot
            require(source.pacijent_id == patient.pk and source.lijek_id == medicine.pk,
                    "Migracijska veza ne odgovara pacijentu i lijeku. Potrebna je provjera izvora u Zalihama.")
            require(source.fizicki_u_frizideru == reservation.kolicina,
                    "Migracijski unos i trenutna rezervacija se razlikuju nakon drugih radnji. Provjerite izdavanja i migracijsko porijeklo u Zalihama prije korekcije.")
            require(new + (source.kod_pacijenta or 0) <= source.preostalo_po_komisiji,
                    "Fizička količina bi prešla evidentirano odobrenje. Odobrenje se ispravlja zasebno na osnovu saglasnosti ili se nova isporuka evidentira u Komisijskom centru.")
        require(not m.PotrebaFizickogPokrica.objects.filter(lijek=medicine, status=m.PotrebaFizickogPokrica.STATUS_CEKA, preostala_kolicina__gt=0).exists(),
                "Za lijek postoje količine koje čekaju fizičko pokriće. Zaprimanje/dodjelu evidentirajte u Zalihama ili Komisijskom centru; ova ispravka ne smije preraspodijeliti druge pacijente.")
        delta = new - reservation.kolicina
        require(stock.u_frizideru + delta >= 0, "Ispravka bi napravila negativnu fizičku zalihu.")
        position = inventory_position(medicine, include_planned_need=False)
        require(stock.u_frizideru + delta >= amount(m.PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True).aggregate(n=Sum("kolicina"))["n"] or 0) + delta,
                "Saldo je već manji od rezervacija. Najprije provjerite fizičko stanje i porijeklo u Zalihama.")
        plan.update(delta=str(delta), medicine_id=medicine.pk, stock_id=stock.pk)
        row("Količina za pacijenta u frižideru", reservation.kolicina, new)
        if reservation.migracijski_snapshot_id:
            row("Povezani početni migracijski unos", reservation.migracijski_snapshot.fizicki_u_frizideru, new)
        row("Ukupno fizički — grupa lijeka", position["total_physical"], position["total_physical"] + delta)
        row("Ukupno rezervisano — grupa lijeka", position["reserved_in_fridge"], position["reserved_in_fridge"] + delta)
        plan["impacts"].append(f"Fizička korekcija {delta:+g} {medicine.jedinica_zalihe}. Ova rezervacija ostaje {new:g}; druge rezervacije, odobrenja i izvršene terapije ostaju iste. Ovo nije izdavanje, povrat ni nova isporuka.")
    elif scope == "home":
        snap = migration(patient)
        require(snap.kod_pacijenta is not None, "Količina je nepoznata. Koristite Provjeri kućnu terapiju i unesite izjavu s datumom provjere; nepoznato se ne pretvara u nulu.")
        require(not snap.lijek.oralna_terapija, "Oralne tablete su vezane za izdavanje i režim. Pogrešno izdavanje kontrolisano poništite u Oralnoj terapiji.")
        assignment = m.PacijentZaduzenje.objects.filter(migracijski_snapshot=snap).first()
        require(assignment is not None and assignment.pacijent_id == patient.pk and assignment.lijek_id == snap.lijek_id,
                "Nema jednoznačno povezanog migracijskog zaduženja. Novu izjavu unesite kroz Provjeri kućnu terapiju.")
        require(assignment.preostalo == snap.kod_pacijenta and assignment.ukupno_zaduzeno == snap.kod_pacijenta,
                "Migracijsko zaduženje je već korišteno. Ispravite povezano izdavanje/primjenu kroz kontrolisano poništavanje ili unesite novu izjavu pacijenta.")
        require(not m.Terapija.objects.filter(pacijent=patient, workflow_status="POTVRDJENA", is_migration=False).exists(),
                "Nakon migracije postoje operativne radnje. Koristite kontrolisanu ispravku te radnje ili novu izjavu pacijenta.")
        new = data["kod_pacijenta"]
        require(new == new.to_integral_value(), "Unesite cijeli broj pojedinačnih jedinica lijeka.")
        require(new + snap.fizicki_u_frizideru <= snap.preostalo_po_komisiji, "Količina bi prešla migracijsko pravo. Provjerite odobrenje zasebno.")
        plan.update(assignment_id=assignment.pk, medicine_id=snap.lijek_id, delta=str(new - snap.kod_pacijenta))
        row("Migracijska količina kod pacijenta", snap.kod_pacijenta, new)
        plan["impacts"].append("Ispravlja se samo pogrešan početni unos i njegovo zaduženje. Nema povrata u frižider, nove primjene ni promjene komisijskog odobrenja.")
    elif scope == "approval":
        commission = target(m.Komisija, patient, target_id)
        from .treatment_review_approval import approval_document_values
        from .commission_receiving import validate_agreement_number, agreement_number_conflicts
        old_number = approval_document_values(commission)["broj_saglasnosti"]
        if data["broj_saglasnosti"]:
            validate_agreement_number(data["broj_saglasnosti"])
            require(not agreement_number_conflicts(data["broj_saglasnosti"], patient=patient), "Broj saglasnosti već pripada drugom pacijentu. Provjerite dokument i izabrani karton.")
        require(commission.status not in {"PONISTENA", "ZAMIJENJENA"}, "Odobrenje je poništeno ili zamijenjeno. Otvorite pripadajući komisijski zahtjev i ispravite povezanu radnju.")
        from .package_sizes import validate_package_multiple
        validate_package_multiple(data["broj_odobrenih_doza"], commission.lijek, label="Odobrena količina")
        used = commission.broj_odobrenih_doza - commission.preostale_doze
        require(used >= 0, "Odobrenje ima neusklađene odobrene i preostale količine. Provjerite povezane radnje u Komisijskom centru.")
        require(data["broj_odobrenih_doza"] >= used, f"Već je administrativno iskorišteno {used:g}. Prvo poništite pogrešnu terapiju/izdavanje; iskorištena količina se ovdje ne briše.")
        linked_requests = list(m.Trebovanje.objects.filter(komisija=commission))
        if linked_requests and data["broj_odobrenih_doza"] != commission.broj_odobrenih_doza:
            plan.setdefault('warnings', []).append('Odobreni zahtjevi i njihovi prijemi ostaju sačuvani. '
                'Ispravljeno pravo treba uporediti s već odobrenim zahtjevima; ova ispravka ih ne odobrava ponovo.')
            for req in linked_requests:
                row(f'Već zaprimljeno po zahtjevu od {req.datum_kreiranja:%d.%m.%Y.}' if hasattr(req, 'datum_kreiranja') else 'Već zaprimljeno po povezanom zahtjevu', req.zaprimljene_doze, req.zaprimljene_doze)
        linked_snap_ids = set(m.PacijentRezervacija.objects.filter(komisija=commission, migracijski_snapshot__isnull=False).values_list("migracijski_snapshot_id", flat=True))
        linked_snap_ids.update(m.PacijentZaduzenje.objects.filter(komisija=commission, migracijski_snapshot__isnull=False).values_list("migracijski_snapshot_id", flat=True))
        require(len(linked_snap_ids) <= 1, "Odobrenje ima više migracijskih izvora. Provjerite veze u Komisijskom centru.")
        plan["snapshot_id"] = next(iter(linked_snap_ids), None)
        if plan["snapshot_id"]:
            source = m.MigracijskiSnapshotPacijenta.objects.get(pk=plan["snapshot_id"])
            require(source.pacijent_id == patient.pk and source.broj_odobrenih_doza == commission.broj_odobrenih_doza,
                    "Migracija i odobrenje imaju različite količine. Potrebna je provjera izvornog odobrenja.")
            if data["broj_odobrenih_doza"] < source.broj_iskoristenih_doza + source.fizicki_u_frizideru + (source.kod_pacijenta or 0):
                plan.setdefault('warnings', []).append('Ispravljeno pravo je manje od evidentiranih količina. '
                    'Administrativni nesklad ostaje vidljiv; fizička zaliha, zaduženja i primjene se ne mijenjaju.')
        row("Broj saglasnosti odabranog odobrenja", old_number, data["broj_saglasnosti"])
        row("Datum odobrenja", commission.datum_odobrenja, data["datum_odobrenja"])
        row("Ukupno odobreno", commission.broj_odobrenih_doza, data["broj_odobrenih_doza"])
        row("Preostalo pravo", commission.preostale_doze, data["broj_odobrenih_doza"] - used)
        plan["commission_status"] = commission.status
        if commission.status == "POTROSENA" and data["broj_odobrenih_doza"] > used:
            plan["commission_status"] = "AKTIVNA"
        elif commission.status in m.Komisija.VAZECI_STATUSI and data["broj_odobrenih_doza"] == used:
            plan["commission_status"] = "POTROSENA"
        if plan["commission_status"] != commission.status:
            row("Status odabranog odobrenja", commission.status, plan["commission_status"])
        plan["impacts"].append(f"Mijenja se samo odobrenje #{commission.pk}. Iskorišteno {used:g} ostaje isto. Fizičke zalihe i stari PDF-ovi se ne mijenjaju; novi PDF koristi ispravljene podatke ovog odobrenja. Datum upisa i U upotrebi od nisu datum odobrenja.")
        plan["used"] = str(used)
        reserved = m.PacijentRezervacija.objects.filter(komisija=commission, aktivno=True).aggregate(n=Sum('kolicina'))['n'] or 0
        if reserved > data['broj_odobrenih_doza']-used:
            plan.setdefault('warnings', []).append(f'Rezervisano je {reserved:g}, a ispravljeno preostalo pravo je {data["broj_odobrenih_doza"]-used:g}. Rezervacije ostaju sačuvane; potrebna je provjera pokrića.')
        if old_number and not data["broj_saglasnosti"]:
            plan["impacts"].append("Broj saglasnosti će biti uklonjen. Novo generisanje razduženja biće blokirano dok se ne upiše tačan broj.")
    elif scope == "regimen":
        _regimen_preview(patient, data, plan, row)
    elif scope in {"therapy", "oral_issue"}:
        _void_preview(patient, scope, target_id, plan, row)
        from .retrospective_reversal import original_context, dependent_events, UNSAFE
        dependencies=dependent_events(original_context('therapy' if scope=='therapy' else 'oral',target_id))
        require(not dependencies, UNSAFE+' '+ '; '.join(item['label'] for item in dependencies))
    else:
        raise CorrectionBlocked("Nepoznata vrsta ispravke.")
    require(plan["rows"], "Nema izmijenjenih vrijednosti. Podaci nisu spremljeni.")
    return plan


def _regimen_preview(patient, data, plan, row):
    require(patient.lijek is not None, "Prvo odaberite prezentaciju lijeka.")
    if patient.lijek.oralna_terapija:
        regimen = m.OralniTerapijskiRezim.objects.filter(pacijent=patient, aktivan=True).order_by("-datum_od", "-pk").first()
        require(regimen is not None, "Nema potvrđenog oralnog režima. Otvorite Oralna terapija → Potvrdi režim.")
        require(not m.IzdavanjeOralneTerapije.objects.filter(rezim=regimen).exists(),
                "Po ovom režimu već postoje izdavanja. Za pogrešan unos prvo poništite/ispravite izdavanje; za novu dozu potvrdite novi režim od izabranog datuma u Oralnoj terapiji.")
        require(data["tableta_po_uzimanju"] > 0 and data["uzimanja_dnevno"] > 0, "Broj tableta po uzimanju i broj uzimanja moraju biti veći od nule.")
        plan["regimen_id"] = regimen.pk
        for name, label in [("tableta_po_uzimanju", "Tableta po uzimanju"), ("uzimanja_dnevno", "Uzimanja dnevno"), ("datum_od", "Početak postojećeg režima")]:
            row(label, getattr(regimen, name), data[name])
        plan["impacts"].append("Ispravlja se postojeći režim bez izdatih lijekova. Nove potrebe koriste ispravljenu dnevnu količinu. Ne nastaju ambulantni termini.")
        return
    require(data["kolicina_po_terapiji"] > 0, "Količina po terapiji mora biti veća od nule.")
    require(data["kolicina_po_terapiji"] == data["kolicina_po_terapiji"].to_integral_value(), "Fizička količina injekcijske terapije mora biti cijeli broj pojedinačnih jedinica.")
    state = patient.aktivni_fazni_protokol()
    if state:
        from .phased_protocols import current_phase_details
        current = current_phase_details(state)
        require(state.faza == state.FAZA_ODRZAVANJE and data["kolicina_po_terapiji"] == current["units"] and not data.get("doza_mg"),
                "Doza ili datum indukcijskog/faznog režima uređuje se kroz Postavke faznog protokola. Ovdje je dozvoljena ispravka intervala SC održavanja bez promjene propisane doze.")
        require(data["interval_sedmica"] in (8, 12), "Ovaj fazni protokol podržava interval 8 ili 12 sedmica. Otvorite Postavke protokola za druge odluke.")
        plan["phase_id"] = state.pk
    else:
        require(patient.pocetna_faza_terapije != patient.FAZA_INDUKCIJA,
                "Indukcija ima više različitih koraka. Otvorite Individualni protokol i ispravite konkretan korak; jednim intervalom se ne smije prepisati indukcija.")
    row("Fizička količina po primjeni", patient.doza_po_aplikaciji(), data["kolicina_po_terapiji"])
    row("Interval u sedmicama", patient.efektivni_interval_sedmica(), data["interval_sedmica"])
    step = patient.trenutni_korak_terapije()
    if data.get("doza_mg") is not None:
        require(data["doza_mg"] > 0, "Propisana doza mora biti veća od nule.")
        row("Propisana doza mg", getattr(step, "doza_mg", None), data["doza_mg"])
    from .scheduling import adjust_to_allowed_therapy_date
    future = list(m.Termin.objects.filter(pacijent=patient, lijek=patient.lijek,
                  status=m.Termin.STATUS_PLANIRANA, datum__gte=timezone.localdate()).order_by("datum", "vrijeme", "pk"))
    require(len(future) <= 100, "Postoji više od 100 termina. Provjerite raspored prije grupnog proračuna.")
    last = patient.posljednja_stvarno_primljena_terapija()
    snap = m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient).first()
    anchor = last.datum if last else getattr(snap, "datum_posljednje_terapije", None)
    next_date = data.get("sljedeci_datum") or (anchor + timedelta(weeks=data["interval_sedmica"]) if anchor else None)
    if future:
        require(next_date is not None and next_date >= timezone.localdate(),
                "Za siguran proračun postojećih termina unesite potvrđeni prvi budući datum. Prošli ili nepoznati datum se ne pretvara u propušten dolazak.")
    if data.get("sljedeci_datum"):
        require(data["sljedeci_datum"] >= timezone.localdate(), "Prvi budući datum ne može biti u prošlosti.")
        row("Prvi budući datum", future[0].datum if future else None, next_date)
    require(not (patient.trenutni_korak_je_kucna_terapija() and future),
            "Kućna terapija ima postojeće ambulantne termine. Najprije ih pregledajte kroz Kalendar; procjena kućne primjene ne smije ih pretvoriti u obavljene ili propuštene dolaske.")
    appointments = []
    for index, appointment in enumerate(future):
        proposed = adjust_to_allowed_therapy_date(next_date + timedelta(weeks=index * data["interval_sedmica"]), lijek=patient.lijek,
                                                 protokol=patient.aktivni_protokol()).datum
        appointments.append({"id": appointment.pk, "before": appointment.datum.isoformat(), "after": proposed.isoformat()})
    plan["appointments"] = appointments
    plan["next_date"] = next_date.isoformat() if next_date else None
    if not future and data.get("sljedeci_datum") and patient.trenutni_korak_je_ambulanta():
        proposed = adjust_to_allowed_therapy_date(next_date, lijek=patient.lijek, protokol=patient.aktivni_protokol()).datum
        plan["new_appointment"] = proposed.isoformat()
        plan["impacts"].append(f"Na izričito unesen datum zakazuje se prvi novi ambulantni termin {proposed:%d/%m/%Y} u 08:00. Ostali novi termini se ovim postupkom ne kreiraju.")
    _validate_regimen_appointment_dates(patient, appointments, plan.get("new_appointment"))
    plan["impacts"].append(f"Preračunava se doza za buduće potrebe i {len(appointments)} planiranih termina. Izvršene terapije, stvarne zalihe i odobrene komisijske količine ostaju iste. Kućne primjene ostaju procjena.")


def _void_preview(patient, scope, target_id, plan, row):
    if scope == "therapy":
        therapy = target(m.Terapija, patient, target_id)
        from .therapy_correction_snapshot import verified_therapy_snapshot
        try:
            snapshot = verified_therapy_snapshot(therapy)
        except ValueError as exc:
            raise CorrectionBlocked(str(exc)) from exc
        require(therapy.workflow_status == "POTVRDJENA" and not therapy.ponistena_at,
                "Ova radnja je već poništena. Za tačne podatke evidentirajte novu radnju.")
        require("zaliha_kolicina" in snapshot and (snapshot.get("termin_id") or snapshot.get("vrsta") == "KUCNO_IZDAVANJE"),
                "Radnja nema pouzdan zapis svojih učinaka. Ne može se automatski poništiti bez rekonstrukcije izvora. Otvorite Historiju i povezane dokumente radi provjere; fizičku inventurnu grešku ispravite zasebno u Zalihama.")
        require(not m.Terapija.objects.filter(pacijent=patient, workflow_status="POTVRDJENA").filter(
            Q(datum__gt=therapy.datum) | Q(datum=therapy.datum, pk__gt=therapy.pk)).exists(),
            "Poslije ove radnje postoje druge potvrđene terapije/izdavanja. Ispravke treba provesti obrnutim redoslijedom nakon provjere historije; stariji snapshot ne smije poništiti novije stanje.")
        for item in snapshot.get("komisijske_promjene", []):
            commission = target(m.Komisija, patient, item["komisija_id"])
            row(f"Preostalo pravo odobrenja #{commission.pk}", commission.preostale_doze, commission.preostale_doze + amount(item["kolicina"]))
        quantity = amount(snapshot["zaliha_kolicina"])
        stock = m.Zaliha.objects.filter(lijek=therapy.lijek).first()
        require(stock is not None, "Nedostaje saldo za povezanu radnju. Provjerite porijeklo u Zalihama.")
        if snapshot.get("vrsta") != "KUCNA_PRIMJENA":
            row("Fizički u frižideru", stock.u_frizideru, stock.u_frizideru + quantity)
        if snapshot.get("vrsta") == "KUCNO_IZDAVANJE":
            item = snapshot.get("zaduzenje_izdavanje")
            require(item is not None, "Kućno izdavanje nema povezano zaduženje. Potrebna je provjera porijekla.")
            assignment = target(m.PacijentZaduzenje, patient, item["zaduzenje_id"])
            require(assignment.preostalo >= amount(item["kolicina"]), "Izdavanje je već korišteno; prvo kontrolisano ispravite kasnije radnje. Preostala količina se ne smije tiho svesti na nulu.")
            row("Preostalo u pripadajućem zaduženju", assignment.preostalo, assignment.preostalo - amount(item["kolicina"]))
        row("Status radnje", "Potvrđena", "Poništena uz očuvan original")
        plan["impacts"].append(f"Kanonsko poništavanje vraća samo učinke radnje #{therapy.pk} ({quantity:g} jedinica) prema njenom zapisu: pripadajuće pravo, rezervacije i zaduženja. Zaliha se vraća na odgovarajuću lokaciju. Originalni dokument ostaje sačuvan. Zatim evidentirajte tačnu radnju kroz redovno izdavanje/primjenu.")
    else:
        issue = target(m.IzdavanjeOralneTerapije, patient, target_id)
        require(issue.status == "AKTIVNO", "Oralno izdavanje je već poništeno.")
        require(not m.IzdavanjeOralneTerapije.objects.filter(pacijent=patient, lijek=issue.lijek, status='AKTIVNO').filter(
            Q(datum_izdavanja__gt=issue.datum_izdavanja) | Q(datum_izdavanja=issue.datum_izdavanja, pk__gt=issue.pk)).exists(),
            'Poslije ovog oralnog izdavanja postoje druga izdavanja. Razjasnite kasnije događaje prije poništavanja.')
        row("Status oralnog izdavanja", "Aktivno", "Poništeno uz očuvan original")
        plan["impacts"].append("Migracijski zapis se isključuje iz procjene, bez povrata fizičke zalihe ili prava." if issue.is_migration_snapshot else
            f"U frižider se vraća {issue.kolicina_tableta:g} tableta i pripadajuće komisijsko pravo. Pokrivenost se preračunava. Originalni dokument i zapis ostaju sačuvani.")
        if not issue.is_migration_snapshot:
            stock = m.Zaliha.objects.filter(lijek=issue.lijek).first()
            require(stock is not None, 'Nedostaje fizička evidencija oralnog lijeka.')
            row('Zajednička zaliha ambulante', stock.u_frizideru, stock.u_frizideru+issue.kolicina_tableta)


def make_preview_token(patient, scope, form, user, *, target_id=None):
    cache = begin_request_cache(enabled=False)
    try:
        fingerprint = digest(captured_rows())
        plan = preview(patient, scope, form.cleaned_data, target_id=target_id)
        require(fingerprint == digest(captured_rows()), 'Podaci su se promijenili tokom pregleda. Ponovite pregled.')
        payload = {"operation_id": str(uuid.uuid4()), "user_id": user.pk, "patient_id": patient.pk,
                   "scope": scope, "target_id": target_id, "fields": plan["data"], "reason": plan["reason"],
                   "fingerprint": fingerprint}
        return plan, signing.dumps(payload, salt=SALT, compress=True)
    finally:
        end_request_cache(cache)


def apply_signed_correction(token, patient, user):
    from dashboard.permissions import je_admin
    from dashboard.correction_forms import CorrectionForm
    require(user.is_authenticated and user.is_active and je_admin(user), "Ispravke su dostupne samo TheraFlow administratoru.")
    try:
        payload = signing.loads(token, salt=SALT)
    except signing.BadSignature:
        raise CorrectionBlocked("Pregled je istekao ili nije valjan. Ponovo prikažite stare i nove vrijednosti prije spremanja.") from None
    require(payload["user_id"] == user.pk and payload["patient_id"] == patient.pk, "Pregled pripada drugom korisniku ili kartonu.")
    require(payload["scope"] != "stock", "Stari pregled fizičke zalihe više nije važeći. Otvorite zasebnu ispravku fizičke zalihe i ponovite pregled.")
    caller_patient = patient
    cache = begin_request_cache(enabled=False)
    try:
        with transaction.atomic():
            from .correction_protocol import lock_correction_tables
            lock_correction_tables()
            patient = m.Pacijent.objects.select_for_update().get(pk=patient.pk)
            existing = m.PatientDataCorrection.objects.filter(operation_id=payload["operation_id"]).first()
            if existing:
                return existing, False
            try:
                signing.loads(token, salt=SALT, max_age=1800)
            except signing.BadSignature:
                raise CorrectionBlocked('Pregled je istekao. Ponovo pregledajte ispravku.') from None
            before = captured_rows()
            require(digest(before) == payload["fingerprint"], "Podaci su se promijenili nakon pregleda. Ništa nije upisano. Ponovo otvorite pregled da vidite tačne posljedice.")
            form = CorrectionForm(data={**payload["fields"], "razlog": payload["reason"]}, patient=patient,
                                  scope=payload["scope"], target_id=payload["target_id"])
            require(form.is_valid(), "Podaci više nisu valjani. Ponovo otvorite ispravku.")
            plan = preview(patient, payload["scope"], form.cleaned_data, target_id=payload["target_id"])
            try:
                backup = backup_before_correction(payload["operation_id"])
            except Exception as exc:
                if isinstance(exc, CorrectionBlocked):
                    raise
                raise CorrectionBlocked("Servis nije uspio napraviti i verificirati backup. Podaci nisu promijenjeni. Provjerite status backupa u Postavkama sistema; nije potrebna Windows administratorska prijava korisnika.") from exc
            from .inventory_trace import stock_action
            cycle_id = None
            if plan['scope']=='reservation':
                reservation = target(m.PacijentRezervacija, patient, plan['target_id'])
                if reservation.trebovanje_id:
                    cycle_id = reservation.trebovanje.komisijski_ciklus_id
            with stock_action(operation_id=payload['operation_id'], cycle_id=cycle_id):
                _apply_plan(patient, plan, form.cleaned_data, user)
            after = captured_rows()
            old, new = differences(before, after)
            # These are immutable under ordinary data/stock/regimen corrections.
            protected = {"patients_terapija", "patients_kucnoizdavanje", "patients_izdavanjeoralneterapije", "patients_dokumentpacijenta", "patients_evidencijasaglasnostizaprimanja"}
            require(not {"patients_dokumentpacijenta", "patients_kucnoizdavanje", "patients_evidencijasaglasnostizaprimanja"}.intersection(old),
                    "Originalni dokument ili izdavanje se ne smiju prepisati. Operacija je poništena.")
            if plan["scope"] not in {"therapy", "oral_issue"}:
                require(not protected.intersection(old), "Neočekivana promjena izvršene terapije, izdavanja ili dokumenta. Cijela ispravka je poništena.")
            if plan["scope"] != "approval" and plan["scope"] not in {"therapy", "oral_issue"}:
                require(before.get("patients_komisija") == after.get("patients_komisija"), "Fizička/terapijska korekcija ne smije promijeniti komisijsko odobrenje. Cijela operacija je poništena.")
            if plan["scope"] == "profile":
                require(set(old) <= {"patients_pacijent"}
                        and set(old.get("patients_pacijent", {})) == {str(patient.pk)},
                        "Ispravka osnovnih podataka pokušala je promijeniti povezanu evidenciju. Cijela operacija je poništena.")
                changed = {key for key, value in old["patients_pacijent"][str(patient.pk)].items()
                           if value != new["patients_pacijent"][str(patient.pk)][key]}
                require(changed <= set(PROFILE_FIELDS), "Ispravka osnovnih podataka ne smije mijenjati terapijski plan.")
            receipt = m.PatientDataCorrection.objects.create(operation_id=payload["operation_id"], pacijent=patient,
                korisnik=user, scope=plan["scope"], razlog=plan["reason"], prije=old, poslije=new,
                posljedice=serial({"title": plan.get("title", plan["scope"]), "rows": plan["rows"], "impacts": plan["impacts"],
                    "identification_fields": plan.get("identification_fields", []),
                    "warnings": plan.get('warnings', []), "appointments": plan.get("appointments", [])}), backup=backup)
            from .utils import upisi_log
            upisi_log(user, "Ispravka podataka pacijenta", pacijent=patient, objekat=receipt,
                      opis=f"{plan['reason']}\n" + json.dumps(receipt.posljedice, ensure_ascii=False))
            if plan["scope"] == "profile":
                caller_patient.refresh_from_db()
            return receipt, True
    finally:
        end_request_cache(cache)
        invalidate_after_write()


def _apply_plan(patient, plan, data, user):
    from .utils import upisi_log
    scope, reason = plan["scope"], plan["reason"]
    if scope == "profile":
        fields = {k: v for k, v in data.items() if k != "razlog"}
        if "jmbg" in fields:
            fields["jmbg"] = fields["jmbg"] or None
        # Do not invoke the patient's save hook, which normalizes therapy intervals.
        m.Pacijent.objects.filter(pk=patient.pk).update(**fields)
    elif scope == "medicine":
        from .medicine_registry import ensure_program_for_product
        medicine = data["lijek"]
        has_evidence = any(model.objects.filter(pacijent=patient).exists() for model in
            (m.Terapija, m.Komisija, m.PacijentRezervacija, m.PacijentZaduzenje, m.Termin,
             m.FazniProtokolPacijenta, m.IndividualniProtokolPacijenta))
        require(not patient.lijek_id or medicine.pk in patient.lijek.equivalent_ids() or not has_evidence,
                "Za promjenu biološkog lijeka koristite Promijeni terapiju i potvrdite novi protokol. Za neusklađenu evidentiranu promjenu koristite kontrolisanu ispravku veza.")
        program = ensure_program_for_product(medicine)
        patient.lijek = medicine
        patient.terapijski_program = program
        patient.terapijski_protokol = medicine.aktivni_protokol()
        patient.save(update_fields=["lijek", "terapijski_program", "terapijski_protokol"])
    elif scope == "migration":
        m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient).update(
            datum_posljednje_terapije=data["datum_posljednje_terapije"], sljedeca_terapija=data["sljedeca_terapija"])
    elif scope == "reservation":
        from .migration_service import set_migration_reservation, uskladi_pocetno_stanje_zalihe
        from .inventory import izracunaj_frizider_iz_transakcija
        reservation = target(m.PacijentRezervacija, patient, plan["target_id"])
        stock = m.Zaliha.objects.get(pk=plan["stock_id"])
        new_stock = stock.u_frizideru + amount(plan["delta"])
        # Increasing stock first allows allocation; decreasing allocation first avoids over-reservation.
        if amount(plan["delta"]) > 0:
            uskladi_pocetno_stanje_zalihe(lijek=reservation.lijek, kolicina=new_stock, user=user)
        if reservation.migracijski_snapshot_id:
            set_migration_reservation(snapshot=reservation.migracijski_snapshot, kolicina=data["kolicina"], user=user)
        else:
            reservation.kolicina = data["kolicina"]
            reservation.aktivno = data["kolicina"] > 0
            reservation.save(update_fields=["kolicina", "aktivno"])
        if amount(plan["delta"]) < 0:
            uskladi_pocetno_stanje_zalihe(lijek=reservation.lijek, kolicina=new_stock, user=user)
        require(izracunaj_frizider_iz_transakcija(reservation.lijek) == new_stock, "Evidencija transakcija ne odgovara korigovanom saldu. Operacija je poništena.")
        require(m.PacijentRezervacija.objects.get(pk=reservation.pk).kolicina == data["kolicina"], "Rezervacija nije usklađena. Operacija je poništena.")
    elif scope == "home":
        snap = migration(patient)
        assignment = target(m.PacijentZaduzenje, patient, plan["assignment_id"])
        assignment.preostalo = assignment.ukupno_zaduzeno = data["kod_pacijenta"]
        assignment.aktivno = data["kod_pacijenta"] > 0
        assignment.save(update_fields=["preostalo", "ukupno_zaduzeno", "aktivno"])
        snap.kod_pacijenta = data["kod_pacijenta"]
        snap.save(update_fields=["kod_pacijenta"])
        stock, _ = m.Zaliha.objects.get_or_create(lijek=snap.lijek)
        stock.kod_pacijenata = m.PacijentZaduzenje.objects.filter(lijek=snap.lijek, aktivno=True).aggregate(n=Sum("preostalo"))["n"] or 0
        stock.save(update_fields=["kod_pacijenata"])
        m.ZalihaTransakcija.objects.create(lijek=snap.lijek, pacijent=patient, tip="KOREKCIJA",
            kolicina=amount(plan["delta"]), promjena_salda=0, lokacija="KOD_PACIJENTA", korisnik=user,
            referenca_tip="MigracijskiSnapshotPacijenta", referenca_id=snap.pk, napomena=reason)
    elif scope == "approval":
        commission = target(m.Komisija, patient, plan["target_id"])
        from .treatment_review_approval import approval_document_values
        old_number = approval_document_values(commission)["broj_saglasnosti"]
        commission.broj_saglasnosti = data["broj_saglasnosti"]
        commission.datum_odobrenja = data["datum_odobrenja"]
        commission.broj_odobrenih_doza = data["broj_odobrenih_doza"]
        commission.preostale_doze = data["broj_odobrenih_doza"] - amount(plan["used"])
        commission.status = plan["commission_status"]
        commission.save(update_fields=["broj_saglasnosti", "datum_odobrenja", "broj_odobrenih_doza", "preostale_doze", "status"])
        from .commission_planning import recalculate_patient_commission_drafts
        recalculate_patient_commission_drafts(patient, user=user, reason=reason)
        if plan["snapshot_id"]:
            m.MigracijskiSnapshotPacijenta.objects.filter(pk=plan["snapshot_id"]).update(broj_odobrenih_doza=data["broj_odobrenih_doza"])
        if old_number != data["broj_saglasnosti"]:
            previous = m.PacijentSaglasnost.objects.filter(pacijent=patient, izvorna_komisija=commission).order_by("-izmijenjeno", "-pk").first()
            current = previous.trenutno_vazeca if previous else not m.PacijentSaglasnost.objects.filter(pacijent=patient, trenutno_vazeca=True).exists()
            if previous and previous.trenutno_vazeca:
                previous.trenutno_vazeca = False
                previous.save(update_fields=["trenutno_vazeca", "izmijenjeno"])
            m.PacijentSaglasnost.objects.create(pacijent=patient, izvorna_komisija=commission,
                broj_saglasnosti=data["broj_saglasnosti"], vazi_od=previous.vazi_od if previous else timezone.localdate(),
                trenutno_vazeca=current, izmijenio=user)
    elif scope == "regimen":
        _apply_regimen(patient, plan, data, user)
    elif scope == "therapy":
        from .therapy_workflow import void_therapy
        void_therapy(terapija=target(m.Terapija, patient, plan["target_id"]), reason=reason, user=user)
    elif scope == "oral_issue":
        from .oral_therapy import void_oral_issuance
        void_oral_issuance(issue=target(m.IzdavanjeOralneTerapije, patient, plan["target_id"]), reason=reason, user=user)


def _validate_regimen_appointment_dates(patient, changes, new_appointment=None):
    """Validate the staged patient/day plan across all product presentations."""
    from .appointment_reschedule import daily_capacity_issues
    appointments = [(target(m.Termin, patient, item["id"]), date.fromisoformat(item["after"]))
                    for item in changes]
    excluded = [appointment.pk for appointment, _ in appointments]
    if new_appointment:
        appointments.append((m.Termin(pacijent=patient, lijek=patient.lijek, vrijeme=time(8)),
                             date.fromisoformat(new_appointment)))
    for appointment, when in appointments:
        proposed = [dict(new_date=str(other_date), new_time=other.vrijeme.isoformat())
                    for other, other_date in appointments if other is not appointment]
        issues, _ = daily_capacity_issues(appointment, when, excluded=excluded, proposed=proposed)
        require(not issues, " ".join(issues))


def _apply_regimen(patient, plan, data, user):
    if plan.get("regimen_id"):
        regimen = target(m.OralniTerapijskiRezim, patient, plan["regimen_id"])
        regimen.tableta_po_uzimanju = data["tableta_po_uzimanju"]
        regimen.uzimanja_dnevno = data["uzimanja_dnevno"]
        regimen.datum_od = data["datum_od"]
        regimen.standardni_rezim = None
        regimen.napomena_ljekara = (regimen.napomena_ljekara + "\nIspravka: " + plan["reason"]).strip()
        regimen.save(update_fields=["tableta_po_uzimanju", "uzimanja_dnevno", "datum_od", "standardni_rezim", "napomena_ljekara", "izmijenjeno"])
        return
    # Revalidate before changing the order or its appointments. The reviewed
    # correction caller holds the table and patient locks for the whole apply.
    _validate_regimen_appointment_dates(patient, plan["appointments"], plan.get("new_appointment"))
    if plan.get("phase_id"):
        from .phased_protocols import change_maintenance_interval
        state = m.FazniProtokolPacijenta.objects.get(pk=plan["phase_id"])
        change_maintenance_interval(state=state, interval_weeks=data["interval_sedmica"], user=user, reason=plan["reason"])
        if plan.get("next_date"):
            state.refresh_from_db()
            state.sljedeci_datum = date.fromisoformat(plan["next_date"])
            state.save(update_fields=["sljedeci_datum", "izmijenjeno"])
    else:
        from .individual_protocols import create_migrated_individual_protocol
        protocol = m.IndividualniProtokolPacijenta.objects.filter(pacijent=patient).first()
        if protocol is None:
            protocol = create_migrated_individual_protocol(patient, naziv="Potvrđeni individualni režim",
                interval_sedmica=data["interval_sedmica"], broj_jedinica=data["kolicina_po_terapiji"], razlog=plan["reason"], user=user)
        protocol.aktivan = True
        protocol.interval_odrzavanja_sedmica = data["interval_sedmica"]
        protocol.doza_po_aplikaciji = data["kolicina_po_terapiji"]
        protocol.razlog_posljednje_izmjene = plan["reason"]
        protocol.izmijenio = user
        protocol.save(update_fields=["aktivan", "interval_odrzavanja_sedmica", "doza_po_aplikaciji", "razlog_posljednje_izmjene", "izmijenio", "datum_izmjene"])
        steps = list(protocol.koraci.filter(faza="ODRZAVANJE"))
        require(len(steps) == 1, "Individualni protokol nema jednoznačan korak održavanja. Ispravite ga u editoru protokola.")
        step = steps[0]
        step.broj_jedinica = data["kolicina_po_terapiji"]
        step.interval_sedmica = data["interval_sedmica"]
        if data.get("doza_mg") is not None:
            step.doza_mg = data["doza_mg"]
        step.save(update_fields=["broj_jedinica", "interval_sedmica", "doza_mg"])
        patient.pocetna_faza_terapije = patient.FAZA_INDIVIDUALNI
        patient.kolicina_po_terapiji = data["kolicina_po_terapiji"]
        patient.interval_sedmica = data["interval_sedmica"]
        patient.save(update_fields=["pocetna_faza_terapije", "kolicina_po_terapiji", "interval_sedmica"])
    from .therapy_workflow import record_status_history
    for item in plan["appointments"]:
        appointment = target(m.Termin, patient, item["id"])
        appointment.datum = date.fromisoformat(item["after"])
        appointment.kolicina_po_terapiji = data["kolicina_po_terapiji"]
        appointment.full_clean()
        appointment.save(update_fields=["datum", "kolicina_po_terapiji"])
        record_status_history(pacijent=patient, termin=appointment, new_status=appointment.status,
            previous_status=appointment.status, reason=plan["reason"], user=user,
            previous_state={"datum": item["before"]}, new_state={"datum": item["after"], "kolicina": str(data["kolicina_po_terapiji"])})
    m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient).update(interval_sedmica=data["interval_sedmica"])
    if plan.get("new_appointment"):
        from .therapy_workflow import schedule_therapy_appointment
        patient.refresh_from_db()
        schedule_therapy_appointment(pacijent=patient, lijek=patient.lijek, datum=date.fromisoformat(plan["new_appointment"]),
            vrijeme=time(8), user=user, reason=plan["reason"], kolicina_po_terapiji=data["kolicina_po_terapiji"])
