"""Central switch for the administrative renewal review before submission.

This never renews an agreement, grants approval or changes its validity dates.
All medicine, quantity, inclusion and stock controls remain at their owners.
"""
from django.core.exceptions import ValidationError
from .models import PostavkeSistema


def renewal_workflow_enabled():
    return bool(PostavkeSistema.objects.order_by("pk").values_list("obavezno_produzenje_saglasnosti", flat=True).first())


def require_renewal_review(requests, *, confirmed=False):
    if not renewal_workflow_enabled():
        return
    from .commission_request_types import classify_commission_request, PURPOSE_CONTINUATION
    continuations = [request for request in requests if (
        getattr(request, "request_purpose", None) or classify_commission_request(request.pacijent).request_purpose
    ) == PURPOSE_CONTINUATION]
    if continuations and not confirmed:
        raise ValidationError("Uključen je obavezan korak produženja: pregledajte zahtjeve za produženje i potvrdite pregled prije slanja. Postavka se mijenja u Postavke sistema.")
