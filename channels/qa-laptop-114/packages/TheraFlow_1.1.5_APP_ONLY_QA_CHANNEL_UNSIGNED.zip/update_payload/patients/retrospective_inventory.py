"""Validate late physical movements against documented history, never inferred opening stock."""
from datetime import timedelta
from decimal import Decimal
from django.utils import timezone
from . import models as m
from .data_corrections import require
from .fridge_history import fridge_balances_at, REPORT_ZONE
from .inventory import izracunaj_frizider_iz_transakcija
from .stock_lots import lot_balances


from .retrospective_reconciliation import dated_movements


def check_history(medicine, when, delta, *, batch='', expires=None, check_lots=True):
    today = timezone.localdate(timezone=REPORT_ZONE)
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    current = stock.u_frizideru if stock else Decimal(0)
    require(izracunaj_frizider_iz_transakcija(medicine) == current,
            'Današnje stanje i evidentirani promet se razlikuju. Najprije provjerite postojeću evidenciju zalihe.')
    require(current+delta >= 0, f'Nema dovoljno fizičke zalihe za {medicine}: stanje {current:g}, potrebno {-delta:g}.')
    if when < today:
        checkpoints = list(m.HistorijskoStanjeFrizidera.objects.filter(pocetno_stanje__lijek=medicine))
        require(not any(timezone.localdate(x.stanje_at, REPORT_ZONE) > when for x in checkpoints),
                'Nakon datuma događaja postoji potvrđeni popis zalihe. Nije poznato uključuje li već ovaj događaj; naknadni promet nije upisan. Potrebna je provjera izvornog popisa.')
        if delta < 0:
            prior = fridge_balances_at(when-timedelta(days=1)).get(medicine.pk, {})
            require(prior.get('quantity') is not None,
                    'Nema pouzdanog historijskog stanja prije datuma događaja. Današnja zaliha nije dokaz ranije raspoložive količine. '+prior.get('reason',''))
            dates = sorted({when, today, *m.ZalihaTransakcija.objects.filter(
                lijek=medicine, datum__gte=when, datum__lte=today).values_list('datum',flat=True)})
            # The existing helper checks every recorded movement. Test the inserted
            # debit after the existing events of its date and at every later date.
            for day in dates:
                balance = fridge_balances_at(day).get(medicine.pk, {})
                require(balance.get('quantity') is not None,
                        'Historija zalihe nije pouzdana na '+day.strftime('%d.%m.%Y.')+' '+balance.get('reason',''))
                require(balance['quantity']+delta >= 0,
                        f'Naknadni događaj {when:%d.%m.%Y.} zahtijeva {-delta:g} {medicine}; '
                        f'na {day:%d.%m.%Y.} evidentirano je samo {balance["quantity"]:g}. Nastala bi negativna historijska zaliha.')
            # End-of-day totals alone must not hide a shortage between later receipts.
            opening = fridge_balances_at(when).get(medicine.pk)['quantity']+delta
            for tx,change in dated_movements(m.ZalihaTransakcija.objects.filter(lijek=medicine,datum__gt=when,datum__lte=today)):
                opening += change
                require(opening >= 0, f'Naknadni događaj bi napravio negativno stanje kod prometa #{tx.pk} ({tx.datum:%d.%m.%Y.}).')
    if delta < 0 and check_lots:
        lots = lot_balances(medicine)
        if any(k[0] and v > 0 for k,v in lots.items()):
            require(bool(batch), 'Zaliha ima dokumentovane serije. Odaberite stvarnu seriju i rok primijenjenog ili izdatog lijeka.')
        if batch:
            require(lots.get((batch,expires),Decimal(0)) >= -delta,
                    'Nema dovoljno jedinica odabrane serije i roka; ne može se koristiti druga serija.')
            if when < today:
                balance = Decimal(0)
                for tx,change in dated_movements(m.ZalihaTransakcija.objects.filter(lijek=medicine,serija=batch,rok_trajanja=expires)):
                    if tx.datum <= when:balance += change
                require(balance+delta >= 0, 'Odabrana serija nije imala dovoljno evidentiranih jedinica na datum događaja.')
                balance += delta
                for tx,change in dated_movements(m.ZalihaTransakcija.objects.filter(lijek=medicine,serija=batch,rok_trajanja=expires,datum__gt=when)):
                    balance += change
                    require(balance >= 0, f'Naknadni događaj bi napravio negativnu količinu serije na {tx.datum:%d.%m.%Y.}.')
    require(not expires or batch and expires >= when, 'Rok zahtijeva seriju i ne smije prethoditi stvarnom događaju.')
    return current
