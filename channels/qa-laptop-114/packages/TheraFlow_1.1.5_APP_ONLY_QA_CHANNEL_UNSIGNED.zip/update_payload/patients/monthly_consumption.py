"""Read-only therapeutic outflow report; never infer consumption from a plan.

The stock ledger is authoritative where present. Linked clinical records supply
the event date. A legacy issue/application without a ledger entry is included
only when its kind and actual quantity are recorded unambiguously. Reversals
are signed events on the return date, not deletion of last month's outflow.
"""
from calendar import monthrange
from datetime import date
from decimal import Decimal
from zoneinfo import ZoneInfo

from django.db.models import Q
from django.utils import timezone

from .models import IzdavanjeOralneTerapije, KucnoIzdavanje, Terapija, ZalihaTransakcija, PromjenaTerapije, Lijek

ZERO = Decimal("0")
REPORT_TIME_ZONE = ZoneInfo("Europe/Sarajevo")
OUTFLOW = {
    ZalihaTransakcija.TIP_AMBULANTNA_POTROSNJA: "clinic",
    ZalihaTransakcija.TIP_KUCNO_IZDAVANJE: "home",
    ZalihaTransakcija.TIP_ORALNO_IZDAVANJE: "home",
}
MODELS = {"Terapija": Terapija, "KucnoIzdavanje": KucnoIzdavanje,
          "IzdavanjeOralneTerapije": IzdavanjeOralneTerapije}
REVERSALS = {"Poništena terapija": "Terapija",
             "Poništeno oralno izdavanje": "IzdavanjeOralneTerapije"}
HISTORY_NOTE = (
    "Izvještaj obuhvata samo evidentiranu potrošnju. Migracijski početni saldi "
    "i podatak o posljednjoj terapiji nisu potpuna historija potrošnje."
)
RETURN_NOTE = (
    "Povrati i poništavanja umanjuju izlaz na datum povrata, koji može biti u "
    "drugom mjesecu od primjene ili izdavanja. Negativan iznos označava povrat."
)


def source_date(source):
    return source.datum_izdavanja if isinstance(source, IzdavanjeOralneTerapije) else source.datum


def source_kind(source):
    if isinstance(source, IzdavanjeOralneTerapije) and source.is_migration_snapshot:
        return None  # remaining-stock snapshots are not documented dispensing
    if isinstance(source, (KucnoIzdavanje, IzdavanjeOralneTerapije)):
        return "home"
    snapshot = source.workflow_snapshot or {}
    if source.is_migration:
        return None  # last-therapy anchors do not establish actual dispensed units
    if snapshot.get("vrsta") == "KUCNA_PRIMJENA":
        return None  # already counted when dispensed, even if a legacy ledger exists
    if source.tip_evidencije == Terapija.TIP_KUCNA_TERAPIJA:
        return "home"
    if snapshot.get("vrsta") == "AMBULANTNA_PRIMJENA":
        return "clinic"
    if source.lijek.kucna_terapija or source.lijek.oralna_terapija:
        return None  # cannot determine location from the old default type alone
    return "clinic"


def is_cancelled(source):
    if isinstance(source, Terapija):
        return source.workflow_status == Terapija.STATUS_PONISTENA or bool(source.ponistena_at)
    if isinstance(source, KucnoIzdavanje):
        return bool(source.terapija_id and is_cancelled(source.terapija))
    return source.status == IzdavanjeOralneTerapije.STATUS_PONISTENO


def build_monthly_consumption(year, month, *, today=None):
    today = today or timezone.localdate(timezone=REPORT_TIME_ZONE)
    start, end = date(year, month, 1), date(year, month, monthrange(year, month)[1])
    # A current/future month may not include future-dated records as completed work.
    through = min(end, today)
    sources, monthly = {}, {}
    for name, model in MODELS.items():
        field = "datum_izdavanja" if name == "IzdavanjeOralneTerapije" else "datum"
        qs = model.objects.filter(**{field + "__range": (start, through)}).select_related("lijek", "pacijent")
        if name == "KucnoIzdavanje":
            qs = qs.select_related("terapija")
        monthly[name] = list(qs)
        sources[name] = {obj.pk: obj for obj in monthly[name]}

    relevant = Q(datum__range=(start, through))
    for name, objects in sources.items():
        relevant |= Q(referenca_tip=name, referenca_id__in=list(objects))
    relevant |= Q(referenca_tip="Terapija", referenca_id__in=[obj.terapija_id for obj in monthly["KucnoIzdavanje"]])
    types = [*OUTFLOW, ZalihaTransakcija.TIP_POVRAT,
             ZalihaTransakcija.TIP_OTPIS, ZalihaTransakcija.TIP_KOREKCIJA]
    transactions = list(ZalihaTransakcija.objects.filter(relevant, tip__in=types)
                        .select_related("lijek", "pacijent", "korekcija", "izvorna_transakcija").order_by("datum", "pk"))
    for name, model in MODELS.items():
        ids = {tx.referenca_id for tx in transactions
               if REVERSALS.get(tx.referenca_tip, tx.referenca_tip) == name}
        qs = model.objects.filter(pk__in=ids - sources[name].keys()).select_related("lijek", "pacijent")
        if name == "KucnoIzdavanje":
            qs = qs.select_related("terapija")
        sources[name].update({obj.pk: obj for obj in qs})

    linked = {(tx.referenca_tip, tx.referenca_id) for tx in transactions if tx.tip in OUTFLOW}
    source_ledger_query = Q(pk__in=[])
    for name, objects in sources.items():
        source_ledger_query |= Q(referenca_tip=name, referenca_id__in=list(objects))
    source_ledger = {(kind, pk): OUTFLOW[tip] for kind, pk, tip in
        ZalihaTransakcija.objects.filter(source_ledger_query, tip__in=OUTFLOW)
        .values_list("referenca_tip", "referenca_id", "tip")}
    # A dispensing has both a clinical and an issue record: they are one event.
    home_by_therapy = {obj.terapija_id: obj for obj in KucnoIzdavanje.objects
                      .filter(terapija_id__in=sources["Terapija"]).select_related("terapija", "lijek", "pacijent")}
    home_by_therapy.update({obj.terapija_id: obj for obj in monthly["KucnoIzdavanje"] if obj.terapija_id})
    home_ids = set(home_by_therapy)
    cancelled_returns = set(ZalihaTransakcija.objects.filter(tip=ZalihaTransakcija.TIP_POVRAT,
                            referenca_tip__in=REVERSALS).values_list("referenca_tip", "referenca_id"))
    returned_transactions = ZalihaTransakcija.objects.filter(pk__in=[tx.referenca_id for tx in transactions
        if tx.tip == ZalihaTransakcija.TIP_POVRAT and tx.referenca_tip == "ZalihaTransakcija"]).in_bulk()
    returned_changes = PromjenaTerapije.objects.filter(pk__in=[tx.referenca_id for tx in transactions
        if tx.tip == ZalihaTransakcija.TIP_POVRAT and tx.referenca_tip == "PromjenaTerapije"]).in_bulk()
    rows, adjustments, warnings = {}, [], set()
    unallocated_returns = 0

    def return_kind(obj):
        if isinstance(obj, Terapija) and (obj.workflow_snapshot or {}).get("vrsta") == "KUCNA_PRIMJENA":
            return None
        if isinstance(obj, Terapija) and obj.pk in home_by_therapy:
            return "home"
        return source_ledger.get((type(obj).__name__, obj.pk)) or source_kind(obj)

    def has_cancellation_return(obj):
        key = ("Poništeno oralno izdavanje", obj.pk) if isinstance(obj, IzdavanjeOralneTerapije) else (
            "Poništena terapija", obj.terapija_id if isinstance(obj, KucnoIzdavanje) else obj.pk)
        return key in cancelled_returns

    def add(drug, patient, when, quantity, kind, label, reference, *, legacy=False, oral=False):
        if not start <= when <= through:
            return
        unit = "tablete" if oral else drug.jedinice_zalihe[1]
        key = (drug.pk, unit)
        row = rows.setdefault(key, {"drug": drug, "unit": unit, "clinic": ZERO, "home": ZERO,
                                   "total": ZERO, "details": []})
        row[kind] += quantity
        row["total"] += quantity
        row["details"].append({"date": when, "patient": patient, "quantity": quantity,
                               "label": label, "reference": reference, "legacy": legacy})
        if unit in {"doze", "jedinice", ""}:
            warnings.add(f"{drug.naziv}: jedinica zalihe nije precizno evidentirana; provjerite podatke lijeka.")
        if legacy:
            warnings.add("Dio historijske evidencije nema povezano kretanje zalihe; uključen je samo jednom, prema zapisanom događaju.")

    for tx in transactions:
        source = sources.get(REVERSALS.get(tx.referenca_tip, tx.referenca_tip), {}).get(tx.referenca_id)
        reference = f"Kretanje #{tx.pk}"
        if tx.korekcija_id and tx.korekcija.scope == 'inventory_issue':
            add(tx.lijek, tx.pacijent, tx.datum, -tx.frizider_delta(), 'home',
                f'Ispravka kućnog izdavanja #{tx.korekcija_id}', reference)
            continue
        if tx.korekcija_id and tx.korekcija.scope == 'inventory_return':
            add(tx.lijek, tx.pacijent, tx.datum, -tx.kolicina, 'home',
                'Stvaran povrat u karantin — nije raspoloživa zaliha', reference)
            continue
        if tx.tip in (ZalihaTransakcija.TIP_OTPIS, ZalihaTransakcija.TIP_KOREKCIJA):
            if start <= tx.datum <= through:
                adjustments.append({"drug": tx.lijek, "date": tx.datum, "patient": tx.pacijent,
                    "label": tx.get_tip_display(), "quantity": tx.frizider_delta(),
                    "unit": tx.lijek.jedinice_zalihe[1], "reference": reference})
            continue
        if tx.tip == ZalihaTransakcija.TIP_POVRAT:
            original = returned_transactions.get(tx.referenca_id) if tx.referenca_tip == "ZalihaTransakcija" else None
            change = returned_changes.get(tx.referenca_id) if tx.referenca_tip == "PromjenaTerapije" else None
            if source:
                kind = return_kind(source) if source.lijek_id == tx.lijek_id and source.pacijent_id == tx.pacijent_id else None
            elif original and original.lijek_id == tx.lijek_id and original.pacijent_id == tx.pacijent_id:
                kind = OUTFLOW.get(original.tip)
            elif change and change.stari_lijek_id == tx.lijek_id and change.pacijent_id == tx.pacijent_id:
                kind = "home"  # this workflow only returns previously dispensed home stock
            else:
                # A generic return has no structured link identifying clinic/home.
                # Keep it visible, never guess based on a medicine's current route.
                kind = None
            if kind:
                add(tx.lijek, tx.pacijent, tx.datum, -tx.kolicina, kind,
                    "Povrat / poništavanje — " + ("ambulanta" if kind == "clinic" else "izdavanje za kući"),
                    reference, oral=isinstance(source, IzdavanjeOralneTerapije) or bool(original and original.tip == ZalihaTransakcija.TIP_ORALNO_IZDAVANJE))
            elif start <= tx.datum <= through:
                unallocated_returns += 1
                adjustments.append({"drug": tx.lijek, "date": tx.datum, "patient": tx.pacijent,
                    "label": "Povrat bez pouzdane veze s izlazom", "quantity": tx.frizider_delta(),
                    "unit": tx.lijek.jedinice_zalihe[1], "reference": reference})
                warnings.add("Postoji neraspoređen povrat. Prikazan je odvojeno i nije oduzet od terapijskog izlaza; potrebno je provjeriti njegov izvor.")
            continue
        kind = OUTFLOW[tx.tip]
        if isinstance(source, Terapija) and (source.workflow_snapshot or {}).get("vrsta") == "KUCNA_PRIMJENA":
            continue
        if kind == "home" and isinstance(source, Terapija) and source.pk in home_by_therapy:
            source = home_by_therapy[source.pk]
            linked.add(("KucnoIzdavanje", source.pk))
        if source and is_cancelled(source):
            if not has_cancellation_return(source):
                warnings.add("Poništen zapis bez povezanog povrata isključen je iz potrošnje; provjerite historijsku evidenciju.")
                continue
        add(tx.lijek, tx.pacijent, source_date(source) if source else tx.datum,
            tx.kolicina, kind, "Primjena u ambulanti" if kind == "clinic" else "Izdavanje za kući",
            reference, oral=tx.tip == ZalihaTransakcija.TIP_ORALNO_IZDAVANJE)

    for name, objects in monthly.items():
        for obj in objects:
            if (name, obj.pk) in linked or (is_cancelled(obj) and not has_cancellation_return(obj)):
                continue
            if name == "Terapija" and obj.pk in home_ids:
                continue
            if name == "KucnoIzdavanje" and ("Terapija", obj.terapija_id) in linked:
                continue
            kind = source_kind(obj)
            if not kind:
                continue
            quantity = Decimal(obj.kolicina_tableta) if name == "IzdavanjeOralneTerapije" else obj.kolicina
            if quantity <= 0:
                warnings.add("Zapis bez pozitivne stvarno evidentirane količine nije uključen u potrošnju.")
                continue
            add(obj.lijek, obj.pacijent, source_date(obj), quantity, kind,
                "Primjena u ambulanti" if kind == "clinic" else "Izdavanje za kući",
                f"{name} #{obj.pk}", legacy=True, oral=name == "IzdavanjeOralneTerapije")

    from .fridge_history import fridge_balances_at
    current = (year, month) == (today.year, today.month)
    balances = fridge_balances_at(through, current=current) if start <= today else {}
    # Catalog medicines without movements still belong here; zero means no
    # recorded outflow, never proof of complete history or of zero stock.
    represented = {row["drug"].pk for row in rows.values()}
    catalog = Q(pk__in=balances.keys()) | Q(aktivan=True) if start <= today else Q(pk__in=[])
    for drug in Lijek.objects.filter(catalog).exclude(pk__in=represented):
        unit = drug.jedinice_zalihe[1]
        rows[(drug.pk, unit)] = {"drug": drug, "unit": unit, "clinic": ZERO, "home": ZERO,
                                  "total": ZERO, "details": []}
    ordered = sorted(rows.values(), key=lambda row: (row["drug"].naziv.casefold(), row["unit"]))
    for index, row in enumerate(ordered, 1):
        row["anchor"] = f"lijek-{index}"
        row["details"].sort(key=lambda item: (item["date"], item["reference"]))
        row["fridge"] = balances.get(row["drug"].pk, {"quantity": None,
            "reason": "Nema pouzdanog fizičkog stanja za ovaj datum."})
        if row["unit"] != row["drug"].jedinice_zalihe[1]:
            row["fridge"] = {"quantity": None, "reason": "Jedinica evidencije razlikuje se od jedinice zalihe; potrebna je provjera."}
        row["fridge_unit"] = row["drug"].jedinica_zalihe_u_recenici(row["fridge"]["quantity"])
    stock_header = f"Stanje na {today:%d/%m/%Y}" if current else f"Stanje u frižideru na {end:%d/%m/%Y}"
    return {"start": start, "end": end, "through": through, "current": current,
            "stock_header": stock_header,
            "stock_note": "Stanje frižidera uključuje rezervisane i zadužene količine koje su još u ambulanti. Lijek izdat za kući nije uključen.",
            "rows": ordered, "adjustments": adjustments, "warnings": sorted(warnings),
            "needs_review": bool(unallocated_returns),
            "history_note": HISTORY_NOTE, "return_note": RETURN_NOTE, "generated_at": timezone.now()}
