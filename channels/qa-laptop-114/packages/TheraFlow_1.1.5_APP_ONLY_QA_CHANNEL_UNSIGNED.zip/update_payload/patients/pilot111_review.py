"""Read-only evidence for manual review. No inference of doses or old balances."""
from decimal import Decimal, InvalidOperation
from django.db.models import Count
from django.utils import timezone
from . import models as m
from .medication_groups import medicine_presentation_key
from .phased_protocols import current_phase_details


def review_after_111(*, today=None):
    today = today or timezone.localdate()
    findings = []

    def add(model, pk, patient_id, code, reason):
        findings.append(dict(model=model, record_id=pk, patient_id=patient_id, code=code, reason=reason))

    for state in m.FazniProtokolPacijenta.objects.filter(aktivan=True).select_related(
            'pacijent', 'iv_lijek', 'sc_lijek', 'trenutna_faza'):
        details = current_phase_details(state)
        if details.get('dose_error'):
            add('FazniProtokolPacijenta', state.pk, state.pacijent_id, 'IV_DOSE_MISSING', details['dose_error'])
        elif state.faza == state.FAZA_CEKA_IV and Decimal(str(state.indukcijski_broj_jedinica or 0)) != details['units']:
            add('FazniProtokolPacijenta', state.pk, state.pacijent_id, 'IV_UNITS_STALE', 'Broj IV bočica u starom snapshotu ne odgovara propisanoj mg dozi.')
        if state.pacijent.lijek_id != details['medicine'].pk:
            add('FazniProtokolPacijenta', state.pk, state.pacijent_id, 'ACTIVE_PRESENTATION_MISMATCH', 'Aktivna prezentacija pacijenta ne odgovara trenutnoj fazi.')
        if not state.trenutna_faza_id or state.trenutna_faza.kljuc != state.faza or state.trenutna_faza.program_id != state.terapijski_program_id or state.pacijent.terapijski_program_id != state.terapijski_program_id:
            add('FazniProtokolPacijenta', state.pk, state.pacijent_id, 'ACTIVE_PHASE_MISMATCH', 'Faza, program pacijenta i fazni zapis nisu usklađeni.')
        if state.iv_lijek.put_primjene != 'IV' or state.sc_lijek.put_primjene != 'SC':
            add('FazniProtokolPacijenta', state.pk, state.pacijent_id, 'PHASE_ROUTE_MISMATCH', 'IV/SC prezentacije faznog protokola imaju pogrešan put primjene.')
        if m.IndividualniProtokolPacijenta.objects.filter(pacijent_id=state.pacijent_id, aktivan=True).exists():
            add('FazniProtokolPacijenta', state.pk, state.pacijent_id, 'DUAL_PROTOCOL_SOURCE', 'Istovremeno aktivni individualni i fazni nalog: provjerite odluku i audit. To samo po sebi ne dokazuje parcijalni save.')
        for app in m.Termin.objects.filter(pacijent_id=state.pacijent_id, status='ZAKAZAN', datum__gte=today):
            if medicine_presentation_key(app.lijek) != medicine_presentation_key(details['medicine']):
                add('Termin', app.pk, app.pacijent_id, 'APPOINTMENT_PHASE_MISMATCH', 'Budući termin koristi prezentaciju iz druge faze.')
    for group in m.Termin.objects.filter(status='ZAKAZAN', datum__gte=today).values(
            'pacijent_id','lijek_id','datum','vrijeme').annotate(total=Count('pk')).filter(total__gt=1):
        for app in m.Termin.objects.filter(pacijent_id=group['pacijent_id'], lijek_id=group['lijek_id'],
                datum=group['datum'], vrijeme=group['vrijeme'], status='ZAKAZAN'):
            add('Termin', app.pk, app.pacijent_id, 'APPOINTMENT_DUPLICATE', 'Više planiranih termina za istog pacijenta, prezentaciju, datum i vrijeme. Uzrok zahtijeva provjeru audit/server loga.')
    for step in m.IndividualniKorakProtokola.objects.filter(protokol__aktivan=True, doza_mg__lte=0).select_related('protokol'):
        add('IndividualniKorakProtokola', step.pk, step.protokol.pacijent_id, 'PROTOCOL_DOSE_ZERO', 'Doza aktivnog individualnog koraka je nula.')
    for therapy in m.Terapija.objects.filter(lijek__put_primjene='IV', doza_mg=0, kolicina__gt=0):
        add('Terapija', therapy.pk, therapy.pacijent_id, 'HISTORICAL_IV_DOSE_ZERO', 'Historijska IV primjena ima količinu, ali mg doza je nula. Sačuvati historiju i provjeriti izvorni nalog.')
    for reservation in m.PacijentRezervacija.objects.filter(aktivno=True, termin__isnull=False).select_related('lijek','termin__lijek'):
        if medicine_presentation_key(reservation.lijek) != medicine_presentation_key(reservation.termin.lijek):
            add('PacijentRezervacija', reservation.pk, reservation.pacijent_id, 'RESERVATION_PRESENTATION_MISMATCH', 'Prezentacija rezervacije i vezanog termina se razlikuju; moguće prepisivanje mora se potvrditi auditom.')
    return dict(title='Potrebna provjera nakon 1.1.1', read_only=True, findings=findings,
        record_count=len({(f['model'],f['record_id']) for f in findings}),
        patient_count=len({f['patient_id'] for f in findings}),
        limitations=['Presjek ne može dokazati parcijalni HTTP 500 niti ranije prepisanu rezervaciju bez ranijeg snapshota i server/audit logova.',
                     'Nijedan zapis nije automatski ispravljen.'])


def review_export(report):
    """Opaque export evidence stays separate from identifiable database rows."""
    evidence = {e['id']: e for e in report.get('evidence', [])}
    results = []
    seen = set()
    for finding in report.get('findings', []):
        codes = {finding.get('code')} | set(finding.get('reason_codes') or [])
        if 'APPOINTMENT_DUPLICATE' in codes:
            for eid in finding.get('evidence_ids', []):
                ev = evidence.get(eid, {})
                if ev.get('type') == 'Termin':
                    key = (ev.get('record', eid), 'APPOINTMENT_DUPLICATE')
                    if key not in seen:
                        seen.add(key); results.append(dict(record=key[0], code=key[1], evidence_id=eid))
    for ev in evidence.values():
        values = ev.get('values', {})
        if 'dose_mg' not in values:
            continue
        try:
            mg = Decimal(str(values['dose_mg']))
            quantity = Decimal(str(values.get('quantity', 0)))
        except (InvalidOperation, ValueError, TypeError):
            continue
        if mg.is_finite() and quantity.is_finite() and mg == 0 and quantity > 0:
            code = 'EXPORTED_IV_DOSE_ZERO' if values.get('route') == 'IV' else 'EXPORTED_DOSE_ZERO'
            key = (ev.get('record', ev['id']), code)
            if key not in seen:
                seen.add(key)
                results.append(dict(record=key[0], code=code, evidence_id=ev['id'],
                    reason='Količina je pozitivna, a doza u mg je nula. Izvoz bez puta primjene ne dokazuje IV prezentaciju niti određeni lijek.'))
    return dict(application_version=report.get('application_version'), findings=results,
        record_count=len({f['record'] for f in results}),
        limitations=['Anonimizirani izvoz ne sadrži cijeli protokol ili sve izvorne identifikatore; nije kompletan pregled ambulantne baze.'])
