"""Late-event orchestration using the normal domain services and correction protocol."""
from datetime import date, time
from decimal import Decimal, InvalidOperation
import uuid
from django.core import signing
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone
from dashboard.permissions import je_admin
from . import models as m
from .correction_protocol import correction_transaction
from .data_corrections import (CorrectionBlocked, require, serial, digest, captured_rows,
                               differences, backup_before_correction)
from .request_cache import begin_request_cache, end_request_cache
from .retrospective_inventory import check_history
from .retrospective_schedule import next_date_plan
from .medicine_registry import patient_product_for_selection
from .retrospective_history import patient_at, validate_pause

SALT = 'theraflow.retrospective-event.v1'
TITLES = dict(m.RetrospectiveEvent.KINDS)


def authorize(user):
    if not user or not user.is_active or not je_admin(user):
        raise PermissionDenied('Naknadnu evidenciju može koristiti samo administrator.')


def amount(value):
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise CorrectionBlocked('Unesite ispravnu količinu.') from None
    require(result.is_finite() and 0 < result <= Decimal('999999.99')
            and result == result.quantize(Decimal('.01')), 'Količina mora biti pozitivna, s najviše dvije decimale.')
    return result


def day(value, *, optional=False):
    if optional and not value:return None
    try:return date.fromisoformat(str(value))
    except (TypeError, ValueError):raise CorrectionBlocked('Unesite ispravan datum.') from None


def chosen(model, pk, label):
    try:obj = model.objects.filter(pk=int(pk)).first()
    except (ValueError, TypeError):obj = None
    require(obj is not None, 'Odaberite '+label+'.')
    return obj


def matching_appointments(patient, medicine, when):
    """One date/product rule shared by the form, preview and confirmation."""
    if not patient or not medicine or not when:
        return m.Termin.objects.none()
    return m.Termin.objects.filter(
        pacijent=patient, lijek=medicine, datum=when,
        status=m.Termin.STATUS_PLANIRANA,
    ).select_related('lijek').order_by('vrijeme', 'pk')


def normalize(data):
    from . import retrospective_pending as pending
    if data.get('entry_mode') in (pending.MODE, pending.EXPLICIT_MODE):
        return pending.normalize(data)
    if data.get('kind') == 'home':
        medicine = chosen(m.Lijek, data.get('medicine_id'), 'lijek')
        if medicine.oralna_terapija:
            from .retrospective_oral import normalize as oral_normalize
            return oral_normalize(data)
    kind = data.get('kind');require(kind in TITLES, 'Odaberite podržanu vrstu događaja.')
    event_date = day(data.get('event_date'))
    require(event_date <= timezone.localdate(), 'Datum događaja ne može biti u budućnosti.')
    medicine = chosen(m.Lijek, data.get('medicine_id'), 'lijek')
    quantity = amount(data.get('quantity'))
    note = str(data.get('note','')).strip()
    require(5 <= len(note) <= 2000, 'Navedite razlog i izvor naknadnog unosa (5–2000 znakova).')
    cleaned = dict(kind=kind, event_date=str(event_date), medicine_id=medicine.pk,
        quantity=str(quantity), note=note, batch=str(data.get('batch','')).strip(),
        expires=str(day(data.get('expires'),optional=True) or ''),
        separate_event=data.get('separate_event') is True,
        history_confirmed=data.get('history_confirmed') is True)
    require(len(cleaned['batch']) <= 100, 'Serija može imati najviše 100 znakova.')
    if kind == 'receipt':
        request = chosen(m.Trebovanje, data.get('request_id'), 'odobrenu komisijsku stavku')
        require(request.komisijski_ciklus_id and request.lijek_id == medicine.pk,
                'Stavka ne pripada odabranom lijeku ili nema komisijski ciklus.')
        require(not data.get('cycle_id') or int(data['cycle_id']) == request.komisijski_ciklus_id,
                'Stavka ne pripada odabranom komisijskom ciklusu.')
        cleaned.update(request_id=request.pk, cycle_id=request.komisijski_ciklus_id, patient_id=request.pacijent_id)
        reference = str(data.get('delivery_reference','')).strip().casefold()
        require(2 <= len(reference) <= 120, 'Unesite broj otpremnice ili jasnu oznaku ove zasebne isporuke (2–120 znakova).')
        cleaned['delivery_reference'] = reference
        lots = data.get('lots') or [{'quantity':str(quantity),'batch':cleaned['batch'],'expires':cleaned['expires']}]
        require(isinstance(lots,list) and 1 <= len(lots) <= 20, 'Unesite jednu do dvadeset serija isporuke.')
        cleaned['lots'] = []
        seen = set()
        for lot in lots:
            batch = str(lot.get('batch','')).strip();expires = day(lot.get('expires'),optional=True)
            require(len(batch) <= 100 and (batch,str(expires)) not in seen, 'Svaku seriju i rok unesite samo u jednom redu.')
            require(not expires or batch and expires >= event_date, 'Rok serije ne smije prethoditi stvarnom prijemu.')
            seen.add((batch,str(expires)))
            cleaned['lots'].append(dict(quantity=str(amount(lot.get('quantity'))),batch=batch,expires=str(expires or '')))
        require(sum((Decimal(l['quantity']) for l in cleaned['lots']),Decimal(0)) == quantity,
                'Zbir količina po serijama mora biti jednak ukupnoj količini prijema.')
    else:
        patient = patient_at(chosen(m.Pacijent,data.get('patient_id'),'pacijenta'), event_date)
        if kind == 'therapy':
            # Preserve the selected representation in the signed preview/audit,
            # but book only against the patient's actual current product.
            selected = chosen(m.Lijek, data.get('selected_medicine_id') or medicine.pk, 'lijek')
            medicine = patient_product_for_selection(patient, selected)
            compatible = medicine is not None
        else:
            compatible = patient.lijek_id == medicine.pk
        require(compatible, 'Odabrani lijek ne odgovara dokazanoj terapiji pacijenta na datum događaja. Provjerite historiju promjene lijeka i prezentaciju.')
        require(not patient._retrospective_changes or cleaned['history_confirmed'] and len(note) >= 5,
            'Predložen je proizvod i protokol iz historijske promjene terapije. Potvrdite provjeru izvornog naloga i unesite izvor u napomenu.')
        cleaned['patient_id'] = patient.pk
        if kind == 'therapy':
            cleaned.update(medicine_id=medicine.pk, selected_medicine_id=selected.pk)
            cleaned['appointment_id'] = int(data['appointment_id']) if data.get('appointment_id') else None
            cleaned['source_appointment_id'] = int(data['source_appointment_id']) if data.get('source_appointment_id') else None
            cleaned['dose_mg'] = str(amount(data['dose_mg'])) if data.get('dose_mg') else ''
        else:
            cleaned['commission_id'] = chosen(m.Komisija,data.get('commission_id'),'odobrenje pacijenta').pk
    return cleaned


def preview(data, user, *, reconciled_count_id=None, guided_session=None):
    from . import retrospective_pending as pending
    if data.get('entry_mode') in (pending.MODE, pending.EXPLICIT_MODE):
        return pending.preview(data,user)
    data = normalize(data)
    if data.get('oral_backend'):
        from .retrospective_oral import preview as oral_preview
        return oral_preview(data, user)
    if guided_session is None:
        authorize(user)
    else:
        from .smart_reconciliation import authorize_event
        authorize_event(user, guided_session, data)
    pending.guard_normal_entry(data)
    kind = data['kind'];patient = m.Pacijent.objects.get(pk=data['patient_id'])
    medicine = m.Lijek.objects.get(pk=data['medicine_id']);when = day(data['event_date']);quantity = amount(data['quantity'])
    patient = patient_at(patient, when)
    if kind in ('therapy','home'):
        from .retrospective_reconciliation import unresolved_counts
        from .september_reconstruction import selected_count_id
        pending=[c for c in unresolved_counts(medicine,when) if c.pk != selected_count_id()]
        require(not pending or reconciled_count_id in {c.pk for c in pending},
            'Postoji raniji popis s nerazjašnjenim manjkom nakon datuma događaja. U povezanom unosu odaberite '
            'konkretno brojanje i dokaz veze prije knjiženja; zaliha se ne smije umanjiti drugi put.')
    before = check_history(medicine,when,quantity if kind=='receipt' else -quantity,
        batch=data['batch'],expires=day(data['expires'],optional=True))
    plan = {'data':data,'kind':kind,'title':TITLES[kind],'patient':str(patient),'medicine':str(medicine),
            'event_date':str(when),'event_date_label':when.strftime('%d/%m/%Y'),
            'quantity':str(quantity),'unit':medicine.jedinica_zalihe_za_kolicinu(quantity),
            'rows':[], 'warnings':[], 'appointment_options':[]}
    def row(label,a,b):plan['rows'].append({'label':label,'before':str(a),'after':str(b)})
    if kind in ('therapy', 'home'):
        validate_pause(patient, when)
        plan['historical_changes'] = patient._retrospective_changes
        plan['warnings'].append('Proizvod, protokol i datum provjereni su prema sačuvanoj historiji. Serija i izvor se ne dopunjavaju nagađanjem.')
    if kind == 'therapy' and data['selected_medicine_id'] != medicine.pk:
        selected = m.Lijek.objects.get(pk=data['selected_medicine_id'])
        plan['warnings'].append(
            f'Odabir „{selected}“ pripada istoj terapiji. Primjena i potrošnja bit će '
            f'evidentirane na proizvodu pacijenta važećem na datum događaja „{medicine}“.')
    row('Fizička zaliha u ambulanti',before,before+(quantity if kind=='receipt' else -quantity))
    if kind == 'therapy':
        from .therapy_history import actually_administered_therapy_query
        require(not medicine.oralna_terapija and not patient.trenutni_korak_je_kucna_terapija(),
                'Odabrana terapija ne pripada ambulantnoj primjeni. Izdavanje nije primjena kod kuće.')
        duplicate = actually_administered_therapy_query(m.Terapija.objects.filter(
            pacijent=patient,lijek_id__in=medicine.equivalent_ids(),datum=when)).exists()
        require(not duplicate, f'Za ovog pacijenta je {medicine.naziv} terapija {when:%d.%m.%Y.} već evidentirana.')
        require(not patient.aktivni_fazni_protokol(),
                'Aktivan fazni protokol zahtijeva provjeru ranije faze prije naknadne primjene. Trenutna faza se ne smije automatski vratiti u prošlost.')
        choices = list(matching_appointments(patient, medicine, when))
        if data.get('source_appointment_id'):
            source = m.Termin.objects.filter(pk=data['source_appointment_id'], pacijent=patient,
                lijek=medicine, status__in=[m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA]).first()
            require(source is not None, 'Izvorni termin ne odgovara pacijentu i historijskom lijeku ili je već razriješen.')
            require(data['appointment_id'] in (None, source.pk), 'Odaberite jednoznačan izvorni termin.')
            choices = [source]
            data['appointment_id'] = source.pk
        plan['appointment_options'] = [{'id':t.pk,'label':f'{t.datum:%d.%m.%Y.} {t.vrijeme:%H:%M}'} for t in choices]
        if data['appointment_id']:
            require(any(t.pk == data['appointment_id'] for t in choices), 'Odabrani termin ne pripada pacijentu, lijeku i datumu ili više nije nepotvrđen.')
        elif len(choices)==1:
            data['appointment_id'] = choices[0].pk
            plan['warnings'].append('Događaj će biti povezan s postojećim nepotvrđenim terminom '+plan['appointment_options'][0]['label']+'.')
        elif len(choices)>1:
            raise CorrectionBlocked('Za taj datum postoji više nepotvrđenih termina. Odaberite konkretan termin u obrascu.')
        approvals = patient.vazece_komisije(lijek=medicine).filter(datum_odobrenja__lte=when)
        require(sum((a.preostale_doze for a in approvals),Decimal(0)) >= quantity,
                'Nema dovoljno važećeg prava iz odobrenja koje je postojalo na datum primjene.')
        remaining = sum((a.preostale_doze for a in approvals),Decimal(0))
        row('Preostalo pravo odobrenja',remaining,remaining-quantity)
        schedule = next_date_plan(patient,when,exclude_appointment=data['appointment_id'])
        plan['warnings'] += schedule['warnings'];plan['next_date'] = str(schedule['due'])
        previous_due = patient.sljedeca_terapija()
        row('Sljedeći izračunati datum',previous_due.strftime('%d/%m/%Y') if previous_due else 'Nije utvrđen',schedule['due'].strftime('%d/%m/%Y'))
        from .individual_protocols import get_interval_weeks
        from .individual_protocols import get_current_step
        step=get_current_step(patient,when)
        if step:
            row('Protokol važeći na datum događaja',patient.terapijski_protokol or patient.aktivni_protokol(),
                patient.terapijski_protokol or patient.aktivni_protokol())
            row('Doza u mg (nalog → evidentirana primjena)',step.doza_mg,data['dose_mg'] or step.doza_mg)
            require(not data['dose_mg'] or not step.doza_mg or Decimal(data['dose_mg'])==step.doza_mg or len(data['note'])>=5,
                'Primijenjena doza se razlikuje od sačuvanog naloga. U napomeni navedite provjeren razlog i izvor stvarne doze.')
        from .retrospective_schedule import application_number_at
        data['interval'] = get_interval_weeks(patient,when,after_application=True,
            application_number=application_number_at(patient,when)) or patient.interval_sedmica
    elif kind == 'home':
        require(medicine.kucna_terapija and not medicine.oralna_terapija,
                'Odabrani lijek ne koristi ovaj tok kućnog izdavanja. Oralno izdavanje koristi zaseban postojeći postupak.')
        require(not patient.aktivni_fazni_protokol(), 'Naknadno izdavanje uz fazni protokol zahtijeva provjeru historijske faze; današnja faza se ne preslikava u prošlost.')
        commission = m.Komisija.objects.get(pk=data['commission_id'])
        require(commission.pacijent_id==patient.pk and commission.lijek_id in medicine.physical_equivalent_ids()
                and commission.datum_odobrenja <= when and commission.je_vazeca() and commission.preostale_doze >= quantity,
                'Odobrenje ne odgovara pacijentu, lijeku, datumu izdavanja ili raspoloživom pravu.')
        from .package_sizes import validate_package_multiple, package_size_for
        if medicine.izdavanje_cijelih_pakovanja:validate_package_multiple(quantity,medicine,label='Kućno izdavanje')
        require(quantity == quantity.to_integral_value(), 'Kućno izdavanje koristi cijele pojedinačne jedinice lijeka.')
        duplicates = m.KucnoIzdavanje.objects.filter(pacijent=patient,lijek=medicine,datum=when,
            kolicina=quantity,serija=data['batch'],terapija__workflow_status=m.Terapija.STATUS_POTVRDJENA)
        if duplicates.exists():
            require(data['separate_event'] and len(data['note'])>=5,
                    'Postoji izdavanje istog pacijenta, lijeka, datuma i količine. Ako je ovo druga stvarna predaja, označite zaseban događaj i opišite razliku.')
            plan['warnings'].append('Potvrđujete drugu stvarnu predaju uz postojeće izdavanje. Raniji zapis ostaje sačuvan.')
        plan['warnings'].append(f'Jedno pakovanje sadrži {package_size_for(medicine)} pojedinačnih jedinica prema katalogu. Datum primjene kod kuće neće biti upisan.')
        at_home = patient.zaduzeno_lijekova(lijek=medicine)
        row('Količina kod pacijenta',at_home,at_home+quantity)
        row('Preostalo pravo odobrenja',commission.preostale_doze,commission.preostale_doze-quantity)
    else:
        request = m.Trebovanje.objects.select_related('komisijski_ciklus','komisija').get(pk=data['request_id'])
        from .commission_receiving import received_commission_quantity
        received = received_commission_quantity(request)
        cycle = request.komisijski_ciklus
        require(cycle.status in ('ODOBRENO','CEKA_ISPORUKU','DJELOMICNO_ZAPRIMLJENO')
                and request.status in ('ODOBRENO','CEKA_ISPORUKU'), 'Stavka nije otvorena za prijem odobrenog lijeka.')
        require(request.odobrene_doze is not None and request.komisija_id,
                'Nedostaje konkretno evidentirano odobrenje stavke. Prijem ne smije sam izmisliti odobrenje.')
        require(request.komisija.datum_odobrenja <= when, 'Prijem ne može prethoditi povezanom odobrenju.')
        require(not m.RetrospectiveEvent.objects.filter(kind='receipt',request=request,
            delivery_reference=data['delivery_reference'],reversed_at__isnull=True).exists(),
            'Ova isporuka za odabranu komisijsku stavku već je naknadno evidentirana.')
        require(received+quantity <= request.odobrene_doze, 'Prijem prelazi preostalu nezaprimljenu odobrenu količinu.')
        from .package_sizes import validate_package_multiple
        for lot in data['lots']:validate_package_multiple(Decimal(lot['quantity']),medicine,label='Zaprimljena serija')
        from .commission_receiving import patient_agreement_suggestion
        agreement = request.komisija.broj_saglasnosti or patient_agreement_suggestion(patient).number
        require(bool(agreement), 'Nedostaje broj saglasnosti povezanog odobrenja. Najprije provjerite komisijsku stavku.')
        data['agreement'] = agreement;data['approval_date'] = str(cycle.datum_odobrenja or request.komisija.datum_odobrenja)
        prior = list(request.evidencije_saglasnosti.all()) if hasattr(request,'evidencije_saglasnosti') else list(m.EvidencijaSaglasnostiZaprimanja.objects.filter(trebovanje=request))
        if prior:
            plan['warnings'].append(f'Ova stavka ima {len(prior)} ranijih prijema. Nova isporuka: {data["delivery_reference"]}. Raniji prijemi ostaju sačuvani.')
        row('Zaprimljeno na komisijskoj stavci',received,received+quantity)
        row('Preostalo za prijem',request.odobrene_doze-received,request.odobrene_doze-received-quantity)
        plan['approved'] = str(request.odobrene_doze)
    if kind in ('therapy','home'):
        from .inventory_corrections import receipt_date
        from .september_reconstruction import eligible_reservations
        reservations = m.PacijentRezervacija.objects.filter(pacijent=patient,
            lijek_id__in=medicine.equivalent_ids(),aktivno=True,kolicina__gt=0).select_related('komisija')
        if kind == 'home':
            from .late_event_sources import historical_reservations
            reservations = historical_reservations(patient, medicine, when)
        for reservation in eligible_reservations(reservations):
            require(not reservation.komisija_id or reservation.komisija.datum_odobrenja <= when,
                    'Aktivna rezervacija pripada kasnijem odobrenju. Najprije razjasnite izvor količine korištene na stvarni datum.')
            require(not any(a.fizicka_transakcija_id and receipt_date(a.fizicka_transakcija)>when
                for a in reservation.izvori_prijema.select_related('fizicka_transakcija')),
                'Pacijentova rezervacija sadrži kasniji prijem. Najprije treba dokazati izvor ranije korištenih jedinica.')
        from .monthly_consumption import build_monthly_consumption
        report = build_monthly_consumption(when.year,when.month)
        monthly = next((r['total'] for r in report['rows'] if r['drug'].pk==medicine.pk),Decimal(0))
        row(f'Mjesečna potrošnja {when:%m.%Y.}',monthly,monthly+quantity)
        from .inventory import inventory_position_for_patient
        reserved = inventory_position_for_patient(patient)['reserved_in_fridge']
        historic_reserved = sum((r.kolicina for r in reservations), Decimal(0)) if kind == 'home' else reserved
        row('Rezervisano za pacijenta u ambulanti',reserved,max(Decimal(0),reserved-min(quantity, historic_reserved)))
        if kind == 'home':
            from .late_event_sources import protected_future_rows
            plan['rows'].extend(protected_future_rows(patient, when))
            from .home_therapy import issue_home_therapy
            with transaction.atomic():
                issue_home_therapy(patient=patient, commission=commission, quantity=quantity, issued_on=when,
                    idempotency_key=uuid.uuid4(), batch=data['batch'], expires_on=day(data['expires'], optional=True),
                    note=data['note'], user=user, retrospective=True, guided_session=guided_session)
                transaction.set_rollback(True)
    return serial(plan)


@transaction.atomic
def make_preview(data,user):
    cache = begin_request_cache(enabled=False)
    try:
        before = digest(captured_rows());plan = preview(data,user)
        require(before==digest(captured_rows()), 'Podaci su se promijenili tokom pregleda. Ponovite pregled.')
        payload = {'operation_id':str(uuid.uuid4()),'user_id':user.pk,'action':'create','data':plan['data'],'fingerprint':before}
        return plan, signing.dumps(payload,salt=SALT,compress=True)
    finally:end_request_cache(cache)


def _payload(token,user,action):
    authorize(user)
    try:payload = signing.loads(token,salt=SALT)
    except signing.BadSignature:raise CorrectionBlocked('Potvrda nije važeća. Ponovite pregled.') from None
    require(payload.get('user_id')==user.pk and payload.get('action')==action, 'Potvrda ne pripada ovom korisniku i postupku.')
    return payload


def _fresh(token,payload):
    try:signing.loads(token,salt=SALT,max_age=1800)
    except signing.BadSignature:raise CorrectionBlocked('Pregled je istekao. Ponovite pregled.') from None
    require(digest(captured_rows())==payload['fingerprint'], 'Podaci su se promijenili nakon pregleda. Ništa nije upisano; ponovite pregled.')


def confirm(token,user):
    payload = _payload(token,user,'create')
    with correction_transaction():
        existing = m.RetrospectiveEvent.objects.filter(operation_id=payload['operation_id']).first()
        if existing:return existing,False
        _fresh(token,payload);plan = preview(payload['data'],user);data = plan['data']
        backup = backup_before_correction(payload['operation_id'])
        return apply_plan(plan, user, payload['operation_id'], backup), True


def apply_plan(plan, user, operation_id, backup, *, stock_count_audit=None, guided_session=None):
    """Shared write path for one event and for an atomic chronological batch."""
    from . import retrospective_pending as pending
    if plan['data'].get('entry_mode') in (pending.MODE, pending.EXPLICIT_MODE):
        return pending.apply_plan(plan,user,operation_id,backup)
    if plan['data'].get('oral_backend'):
        from .retrospective_oral import apply as apply_oral
        return apply_oral(plan, user, operation_id, backup)
    if guided_session is None:
        authorize(user)
    else:
        from .smart_reconciliation import authorize_event
        authorize_event(user, guided_session, plan['data'])
    with transaction.atomic():
        data = plan['data']; payload = {'operation_id': operation_id}
        before = captured_rows()
        patient = m.Pacijent.objects.get(pk=data['patient_id']);medicine = m.Lijek.objects.get(pk=data['medicine_id'])
        quantity = Decimal(data['quantity']);when = day(data['event_date']);kind = data['kind']
        movement_ids = set(m.ZalihaTransakcija.objects.values_list('pk',flat=True))
        therapy = issue = request = None;appointment_before = None
        if kind == 'therapy':
            from .services import confirm_therapy_arrival
            from .appointment_plan import appointment_plan, plan_token
            if data['appointment_id']:
                appointment = m.Termin.objects.get(pk=data['appointment_id'])
                appointment_before = serial(m.Termin.objects.filter(pk=appointment.pk).values().get())
            else:
                appointment = m.Termin.objects.create(pacijent=patient,lijek=medicine,datum=when,
                    vrijeme=time(9),kolicina_po_terapiji=quantity,status=m.Termin.STATUS_PLANIRANA)
            ap = appointment_plan(appointment,fresh=True,retrospective=True,historical_date=when)
            therapy = confirm_therapy_arrival(termin=appointment,primljene_doze=quantity,
                interval_sedmica=data['interval'],korisnik=user,retrospective=True,batch=data['batch'],
                stock_count_audit=stock_count_audit,
                expires_on=day(data['expires'],optional=True),
                doza_mg=Decimal(data['dose_mg']) if data['dose_mg'] else None,
                administration_date=when,
                guided_session=guided_session,
                expected_plan_token=plan_token(appointment,user,ap))
        elif kind == 'home':
            from .home_therapy import issue_home_therapy
            issue,_ = issue_home_therapy(patient=patient,commission=m.Komisija.objects.get(pk=data['commission_id']),
                quantity=quantity,issued_on=when,idempotency_key=payload['operation_id'],batch=data['batch'],
                expires_on=day(data['expires'],optional=True),note=data['note'],user=user,retrospective=True,
                stock_count_audit=stock_count_audit,guided_session=guided_session)
            therapy = issue.terapija
        else:
            from dashboard.views import _zaprimi_odabrana_trebovanja_ciklusa
            request = m.Trebovanje.objects.get(pk=data['request_id'])
            approved_before = request.odobrene_doze
            for lot in data['lots']:
                _zaprimi_odabrana_trebovanja_ciklusa(ciklus=request.komisijski_ciklus,trebovanja=[request],
                    doze_po_trebovanju={request.pk:Decimal(lot['quantity'])},
                    zaprimljeno_po_lijeku={medicine.pk:Decimal(lot['quantity'])},
                    datum_odobrenja=day(data['approval_date']),brojevi_saglasnosti={request.pk:data['agreement']},
                    korisnik=user,datum_prijema=when,lot_by_medicine={medicine.pk:lot},
                    audit_action='Naknadno zaprimanje iz komisije', retrospective=True)
            request.refresh_from_db();require(request.odobrene_doze==approved_before,'Odobrena količina ne smije se mijenjati prijemom.')
        from .commission_planning import recalculate_patient_commission_drafts
        recalculate_patient_commission_drafts(patient,user=user,reason='Naknadna evidencija stvarnog događaja.')
        from .inventory import izracunaj_frizider_iz_transakcija
        require(izracunaj_frizider_iz_transakcija(medicine)==m.Zaliha.objects.get(lijek=medicine).u_frizideru,
                'Kontrola povezanog prometa nije prošla. Cijeli unos je poništen.')
        if therapy:
            from .retrospective_reversal import appointment_evidence, therapy_reversal_evidence
            therapy.refresh_from_db()
            therapy.workflow_snapshot['reversal_appointments']=appointment_evidence(patient.pk)
            therapy.workflow_snapshot['reversal_evidence']=therapy_reversal_evidence(therapy)
            therapy.save(update_fields=['workflow_snapshot'])
        old,new = differences(before,captured_rows())
        next_id = (therapy.workflow_snapshot or {}).get('sljedeci_termin_id') if therapy else None
        next_before = m.Termin.objects.filter(pk=next_id).values().first() if next_id else None
        event = m.RetrospectiveEvent.objects.create(operation_id=payload['operation_id'],kind=kind,event_date=when,
            user=user,patient=patient,medicine=medicine,quantity=quantity,note=data['note'],therapy=therapy,issue=issue,
            request=request,delivery_reference=data.get('delivery_reference',''),backup=backup,
            effects=serial({'preview':plan,'before':old,'after':new,'appointment_before':appointment_before,'generated_next':next_before}))
        event.movements.set(m.ZalihaTransakcija.objects.exclude(pk__in=movement_ids))
        from .utils import upisi_log
        upisi_log(user,'Naknadna evidencija',pacijent=patient,objekat=event,
            opis=f'{TITLES[kind]}: {when:%d.%m.%Y.}; {medicine}; {quantity:g}. Naknadno evidentirao {user.get_username()}, '
                 f'{timezone.localtime(event.created_at):%d.%m.%Y. u %H:%M}. {data["note"]}')
        return event


def reversal_preview(event,user,reason, *, allow_reconciliation=False):
    require(allow_reconciliation or not m.ReconciliationAction.objects.filter(event=event).exists(),
            'Događaj pripada pametnom usklađivanju. Poništavanje ovog procesa nije dostupno u FAZI 2; potrebna je ručna provjera svih povezanih posljedica.')
    from . import retrospective_pending as pending
    if pending.is_pending(event):
        return pending.reversal_preview(event,user,reason)
    authorize(user);require(not event.reversed_at,'Naknadni unos je već poništen.')
    reason = str(reason).strip();require(5 <= len(reason) <= 500,'Unesite razlog poništavanja (5–500 znakova).')
    rows = []
    if event.effects.get('oral_issue_id'):
        from .data_corrections import _void_preview
        _void_preview(event.patient, 'oral_issue', event.effects['oral_issue_id'], {'impacts': []},
            lambda label, a, b: rows.append(dict(label=label, before=str(a), after=str(b))))
        issue = m.IzdavanjeOralneTerapije.objects.get(pk=event.effects['oral_issue_id'])
        if issue.komisija_id:
            rows.append(dict(label='Komisijsko pravo', before=str(issue.komisija.preostale_doze),
                after=str(issue.komisija.preostale_doze + issue.kolicina_tableta)))
    elif event.therapy_id:
        from .data_corrections import _void_preview
        plan = {'impacts':[]}
        _void_preview(event.patient,'therapy',event.therapy_id,plan,
            lambda label,a,b:rows.append({'label':label,'before':str(a),'after':str(b)}))
        for change in (event.therapy.workflow_snapshot or {}).get('rezervacijske_promjene',[]):
            reservation = m.PacijentRezervacija.objects.get(pk=change['rezervacija_id'])
            rows.append({'label':'Rezervisano za pacijenta u ambulanti',
                'before':str(reservation.kolicina),'after':str(reservation.kolicina+Decimal(change['kolicina']))})
        generated = event.effects.get('generated_next')
        if generated:
            current = m.Termin.objects.filter(pk=generated['id']).values().first()
            require(serial(current)==generated,'Naredni termin je u međuvremenu izmijenjen. Poništavanje ga ne smije tiho otkazati; najprije provjerite taj termin.')
    else:
        from .inventory_corrections import preview as correction_preview
        from .retrospective_reversal import metadata_restorations
        metadata_restorations(event)
        # The existing correction appends a debit today; it does not erase the
        # historical receipt before an administration retained in that month.
        check_history(event.medicine,timezone.localdate(),-event.quantity,check_lots=False)
        for movement in event.movements.filter(tip=m.ZalihaTransakcija.TIP_ZAPRIMANJE):
            check_history(event.medicine,timezone.localdate(),-movement.kolicina,batch=movement.serija,
                expires=movement.rok_trajanja,check_lots=False)
            if movement.serija:
                from .stock_lots import lot_balances
                require(lot_balances(event.medicine).get((movement.serija,movement.rok_trajanja),Decimal(0))>=movement.kolicina,
                    'Nema dovoljno preostalih jedinica izvorne serije za povrat prijema.')
            p = correction_preview('receipt',movement.pk,receipt_reversal_data(event,movement,reason),user)
            rows.extend(p['rows'])
    if event.stock_correction_id:
        stock=m.Zaliha.objects.get(lijek=event.medicine)
        rows.append({'label':f'Povrat razjašnjenja popisa #{event.stock_correction_id} — ukupna zaliha ostaje ista',
            'before':str(stock.u_frizideru+event.quantity),'after':str(stock.u_frizideru)})
        rows.append({'label':'Ponovo nerazjašnjeni dio izvornog manjka',
            'before':'0','after':str(event.quantity)})
    return {'event_id':event.pk,'title':'Poništi naknadni unos','reason':reason,'rows':rows,
            'warnings':['Originalni događaj i audit ostaju sačuvani. Dodaje se kontrolisano poništavanje i povezani promet.',
                'Povrat se knjiži današnjim datumom. Izvorni promet ostaje u mjesecu događaja, a poništavanje je odvojeno vidljivo u današnjem obračunu.']}


def receipt_reversal_data(event,movement,reason):
    return {'quantity':'0','event_date':str(event.event_date),'reason':reason,
        'allocations':{str(claim.pk):'0' for claim in movement.raspodjele_prijema.all()}}


@transaction.atomic
def make_reversal_preview(event,user,reason):
    require(not event.batch_id, 'Događaj pripada povezanom unosu. Otvorite ispravku cijelog unosa.')
    cache = begin_request_cache(enabled=False)
    try:
        before = digest(captured_rows());plan = reversal_preview(event,user,reason)
        require(before==digest(captured_rows()),'Podaci su se promijenili tokom pregleda.')
        return plan,signing.dumps({'action':'reverse','event_id':event.pk,'user_id':user.pk,
            'reason':plan['reason'],'fingerprint':before,'operation_id':str(uuid.uuid4())},salt=SALT,compress=True)
    finally:end_request_cache(cache)


def reverse(token,user):
    payload = _payload(token,user,'reverse')
    with correction_transaction():
        event = m.RetrospectiveEvent.objects.select_for_update().get(pk=payload['event_id'])
        if event.reversed_at:return event,False
        require(not event.batch_id, 'Događaj pripada povezanom unosu. Otvorite ispravku cijelog unosa.')
        _fresh(token,payload);plan = reversal_preview(event,user,payload['reason'])
        backup = backup_before_correction(payload['operation_id'])
        return apply_reversal(event,user,plan,backup),True


@transaction.atomic
def apply_reversal(event,user,plan,backup):
    from . import retrospective_pending as pending
    if pending.is_pending(event):
        return pending.apply_reversal(event,user,plan,backup)
    authorize(user)
    before = captured_rows()
    if event.effects.get('oral_issue_id'):
        from .oral_therapy import void_oral_issuance
        reversal_preview(event, user, plan['reason'], allow_reconciliation=True)
        void_oral_issuance(issue=m.IzdavanjeOralneTerapije.objects.get(pk=event.effects['oral_issue_id']),
            reason=plan['reason'], user=user)
    elif event.therapy_id:
        from .therapy_workflow import void_therapy, record_status_history
        void_therapy(terapija=event.therapy,reason=plan['reason'],user=user,retrospective_reversal=True)
        original = event.effects.get('appointment_before')
        if original:
            appointment = m.Termin.objects.get(pk=original['id'])
            appointment.status = original['status'];appointment.save(update_fields=['status'])
            record_status_history(pacijent=event.patient,termin=appointment,
                previous_status=m.Termin.STATUS_PONISTENA,new_status=appointment.status,
                reason='Poništen naknadni unos; vraćen raniji nepotvrđeni termin.',user=user)
    else:
        from .inventory_corrections import preview as correction_preview, apply_plan as correction_apply
        from .retrospective_reversal import metadata_restorations, restore_receipt_metadata
        restorations = metadata_restorations(event)
        for movement in event.movements.filter(tip=m.ZalihaTransakcija.TIP_ZAPRIMANJE):
            correction_plan = correction_preview('receipt',movement.pk,
                receipt_reversal_data(event,movement,plan['reason']),user)
            correction_apply(correction_plan,user,uuid.uuid4(),backup)
        restore_receipt_metadata(event,restorations)
    from .retrospective_reconciliation import reverse_link
    reverse_link(event,plan['reason'],user,backup)
    from .commission_planning import recalculate_patient_commission_drafts
    recalculate_patient_commission_drafts(event.patient,user=user,reason='Poništen naknadni unos.')
    old,new = differences(before,captured_rows())
    event.reversed_at=timezone.now();event.reversed_by=user;event.reversal_reason=plan['reason']
    event.reversal_effects=serial({'before':old,'after':new,'backup':backup,'preview':plan})
    event.save(update_fields=['reversed_at','reversed_by','reversal_reason','reversal_effects'])
    from .utils import upisi_log
    upisi_log(user,'Naknadni unos poništen',pacijent=event.patient,objekat=event,opis=plan['reason'])
    return event
