from django.core.cache import cache

from dashboard.permissions import je_koordinator, korisnik_uloga
from .commission_service import patients_for_next_commission
from .models import KomisijskiCiklus, Pacijent, PostavkeSistema


def alarm_context(request):
    if getattr(request, 'correction_preview_response', False):
        # Sidebar badges may use their existing cache, but this request must
        # never run a global clinical/commission calculation. Business preview
        # quantities continue to come directly from the canonical services.
        return {'broj_alarma': 0, 'sidebar_commission_count': cache.get(
            'theraflow:sidebar:commission-count:v1', 0), 'sidebar_receipt_count': 0}
    url_name = getattr(getattr(request, 'resolver_match', None), 'url_name', '') or ''
    if url_name.startswith(('admin_diagnostics', 'retrospective_')) or url_name in {'ispravi_fizicku_zalihu', 'ispravi_podatke_pacijenta',
            'correction_center', 'medicine_corrections', 'correct_inventory', 'inventory_correction_receipt', 'print_inventory_correction', 'print_patient_correction', 'explain_inventory_balance'}:
        # Diagnostics must not invoke sidebar helpers that can initialise or
        # recompute business state outside its protected read-only snapshot.
        return {'broj_alarma': 0, 'sidebar_commission_count': 0, 'sidebar_receipt_count': 0}
    # Sidebar badge je isti za sve korisnike i smije kratko kasniti. Skupi
    # kanonski obraÄŤun se zato ne ponavlja na svakoj renderovanoj stranici.
    cache_key = "theraflow:sidebar:commission-count:v1"
    komisije_uskoro = cache.get(cache_key)
    if komisije_uskoro is None:
        # Na velikoj bazi globalni sidebar ne smije blokirati obiÄŤan request.
        # TaÄŤan broj se osvjeĹľava kada Dashboard/Komisijski centar izvrĹˇi
        # kanonski obraÄŤun. Za manje ambulantne skupove hladni obraÄŤun je brz.
        if Pacijent.objects.filter(aktivan=True, lijek__isnull=False).count() <= 500:
            komisije_uskoro = len(patients_for_next_commission())
            cache.set(cache_key, komisije_uskoro, 30)
        else:
            komisije_uskoro = 0

    zaprimanja_u_toku = KomisijskiCiklus.objects.filter(
        status__in=("ODOBRENO", "CEKA_ISPORUKU", "DJELOMICNO_ZAPRIMLJENO"),
    ).count()

    # ``broj_alarma`` nije prikazan u globalnom layoutu; kritiÄŤne zalihe se
    # raÄŤunaju samo na ekranima koji ih zaista prikazuju.
    broj_alarma = komisije_uskoro

    return {
        "broj_alarma": broj_alarma,
        "sidebar_commission_count": komisije_uskoro,
        "sidebar_receipt_count": zaprimanja_u_toku,
    }


def sidebar_user_context(request):
    from django.conf import settings
    from .commission_renewal import renewal_workflow_enabled
    role = korisnik_uloga(request.user)
    is_admin = bool(
        getattr(request.user, "is_authenticated", False)
        and (getattr(request.user, "is_superuser", False) or role == "Admin")
    )
    is_coordinator = bool(
        getattr(request.user, "is_authenticated", False)
        and je_koordinator(request.user)
    )
    migration_locked = True
    if is_admin or is_coordinator:
        stored_value = PostavkeSistema.objects.order_by("pk").values_list(
            "migracija_zakljucana",
            flat=True,
        ).first()
        migration_locked = bool(stored_value) if stored_value is not None else False

    url_name = getattr(getattr(request, "resolver_match", None), "url_name", "") or ""
    receipt_views = {"komisijsko_zaprimanje", "zaprimanje_ciklusa"}
    settings_views = {
        "postavke", "korisnici_pristup", "dodaj_korisnika", "uredi_korisnika",
        "resetuj_lozinku_korisnika", "promijeni_status_korisnika",
        "odjavi_sve_sesije_korisnika", "promijeni_vlastitu_lozinku",
        "postavke_sistema", "servisni_centar", "postavke_pdf_obrazaca",
        "pdf_koordinate", "reset_test_data", "reset_test_inventory",
        "rekalkulisi_zalihe", "generisi_demo_podatke", "provjera_integriteta_baze",
    }
    backup_views = {"backup_baze", "restore_backup"}
    therapy_views = {
        "kalendar_terapija", "terapijski_centar", "potvrdi_dolazak",
        "terapija_zavrsena", "novi_termin", "novi_termin_pacijent",
    }
    patient_views = {
        "lista_pacijenata", "profil_pacijenta", "novi_pacijent",
        "promijeni_terapiju", "uredi_individualni_protokol",
    }

    if url_name.startswith('retrospective_'):
        active_section = 'retrospective'
    elif url_name.startswith('admin_diagnostics') or url_name == 'correction_center':
        active_section = 'settings'
    elif url_name == "dashboard":
        active_section = "home"
    elif url_name in receipt_views:
        active_section = "receiving"
    elif "komisij" in url_name:
        active_section = "commission"
    elif url_name in therapy_views:
        active_section = "therapy"
    elif url_name in patient_views:
        active_section = "patients"
    elif url_name in {"lista_zaliha", "ispravi_fizicku_zalihu", 'medicine_corrections', 'correct_inventory', 'inventory_correction_receipt'}:
        active_section = "inventory"
    elif url_name in {"izvjestaji", "mjesecna_potrosnja"}:
        active_section = "reports"
    elif "dokument" in url_name or url_name == "upload_sabloni":
        active_section = "documents"
    elif url_name in backup_views:
        active_section = "backup"
    elif url_name in settings_views or url_name in {"migracija_pacijenta", "zavrsi_migraciju"}:
        active_section = "settings"
    else:
        active_section = ""

    return {
        "sidebar_user_role": role,
        "renewal_workflow_enabled": renewal_workflow_enabled(),
        "sidebar_active_section": active_section,
        "sidebar_is_admin": is_admin,
        "can_correct_inventory": request.user.is_authenticated and request.user.is_active and (
            is_admin or is_coordinator or request.user.groups.filter(name="Sestra").exists()),
        "admin_diagnostics_enabled": getattr(settings, 'ADMIN_DIAGNOSTICS_ENABLED', True),
        "sidebar_is_coordinator": is_coordinator,
        "sidebar_migration_locked": migration_locked,
    }
