"""Shared serialization for previews and correction commits; no second stock ledger."""
from contextlib import contextmanager

from django.db import connection, transaction

from .request_cache import begin_request_cache, end_request_cache

BUSY = 'Podaci se trenutno mijenjaju u drugom postupku. Pokušajte ponovo.'


def contention_message(exc):
    cause = getattr(exc, '__cause__', None)
    return BUSY if getattr(cause, 'pgcode', None) in {'40P01', '55P03', '57014'} else None


@contextmanager
def correction_read_snapshot():
    """Coherent, read-only preview without blocking ordinary domain writes.

    Savepoint-based simulations must still use correction_transaction. Nested
    callers retain that existing protection: PostgreSQL cannot change isolation
    after the enclosing transaction has already queried the database.
    """
    if connection.vendor != 'postgresql' or connection.in_atomic_block:
        with correction_transaction():
            yield
        return
    token = begin_request_cache(enabled=False)
    try:
        with transaction.atomic():
            with connection.cursor() as cursor:
                cursor.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY')
                cursor.execute("SET LOCAL lock_timeout = '5s'")
            yield
    finally:
        end_request_cache(token)


def lock_correction_tables():
    """Ordinary writers take conflicting row-exclusive locks on these same tables."""
    if connection.vendor == 'postgresql':
        tables = sorted(t for t in connection.introspection.table_names()
                        if t.startswith(('patients_', 'dashboard_')))
        with connection.cursor() as cursor:
            cursor.execute("SET LOCAL lock_timeout = '5s'")
            cursor.execute('LOCK TABLE ' + ', '.join(connection.ops.quote_name(t) for t in tables)
                           + ' IN SHARE ROW EXCLUSIVE MODE')


@contextmanager
def correction_transaction():
    token = begin_request_cache(enabled=False)
    try:
        with transaction.atomic():
            lock_correction_tables()
            yield
    finally:
        end_request_cache(token)
