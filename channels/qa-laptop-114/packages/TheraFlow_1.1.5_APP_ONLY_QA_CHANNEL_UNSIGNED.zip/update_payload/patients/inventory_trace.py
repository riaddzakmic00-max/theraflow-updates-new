"""Provenance of NEW stock actions; never backfill or infer historical links."""
from contextlib import contextmanager
from contextvars import ContextVar
from decimal import Decimal
from uuid import uuid4

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Sum

_action = ContextVar('inventory_source_action', default=None)


def explicit_receipt_basis(reservation):
    """Return (has explicit evidence, allocated quantity or unknown).

    Read-only guard for a new transfer: mixed request/cycle receipts may back
    one reservation. Validate each finite physical budget through existing FKs;
    never select a representative receipt by its date, amount, or list order.
    An invalid explicit claim must not fall back to a legacy budget heuristic.
    This proves the origin, not subsequent consumption or current balance.
    """
    from .models import EvidencijaSaglasnostiZaprimanja, ZalihaTransakcija
    from .inventory_corrections import allocation_quantity, receipt_quantity
    from .patient_fridge_corrections import allocation_basis
    linked, quantity, _ = allocation_basis(reservation)
    if linked:
        return linked, quantity
    if not reservation.trebovanje_id:
        return False, None
    request = reservation.trebovanje
    audits = list(EvidencijaSaglasnostiZaprimanja.objects.filter(trebovanje=request)
        .select_related('fizicka_transakcija','rezervacija'))
    linked = any(a.fizicka_transakcija_id or a.rezervacija_id for a in audits)
    if not linked:
        return False, None
    unknown = (True, None)
    if (request.pacijent_id,request.lijek_id)!=(reservation.pacijent_id,reservation.lijek_id):
        return unknown
    if any(not a.fizicka_transakcija_id or not a.rezervacija_id for a in audits):
        return unknown
    if sum((allocation_quantity(a) for a in audits),Decimal(0))!=request.zaprimljene_doze:
        return unknown
    for audit in audits:
        tx = audit.fizicka_transakcija
        if (tx.tip!='ZAPRIMANJE' or tx.frizider_delta()!=tx.kolicina
                or tx.lijek_id!=request.lijek_id or tx.lokacija not in {'','FRIZIDER'}
                or tx.komisijski_ciklus_id!=request.komisijski_ciklus_id
                or tx.jedinica_snapshot!=reservation.lijek.jedinice_zalihe[0]
                or (tx.referenca_tip,tx.referenca_id) not in {
                    ('Trebovanje',request.pk),('KomisijskiCiklus',request.komisijski_ciklus_id)}):
            return unknown
        # A corrected historical receipt needs its own reconciliation. It is
        # not evidence of a new uncorrected allocation for this action guard.
        if ZalihaTransakcija.objects.filter(izvorna_transakcija=tx).exclude(korekcija__scope__in=['inventory_receipt', 'inventory_receipt_date', 'inventory_allocation']).exists() or ZalihaTransakcija.objects.filter(
                referenca_tip='ZalihaTransakcija',referenca_id=tx.pk,tip='KOREKCIJA').exclude(korekcija__scope__in=['inventory_receipt', 'inventory_receipt_date', 'inventory_allocation']).exists():
            return unknown
        claims = list(EvidencijaSaglasnostiZaprimanja.objects.filter(fizicka_transakcija=tx)
            .select_related('trebovanje','rezervacija'))
        if sum((allocation_quantity(a) for a in claims),Decimal(0))>receipt_quantity(tx):
            return unknown
        seen = set()
        for claim in claims:
            r,v=claim.trebovanje,claim.rezervacija
            if (not v or claim.zaprimljena_kolicina<=0 or r.pk in seen
                    or (claim.pacijent_id,claim.komisijski_ciklus_id)!=(r.pacijent_id,r.komisijski_ciklus_id)
                    or (v.pacijent_id,v.lijek_id,v.trebovanje_id)!=(r.pacijent_id,r.lijek_id,r.pk)
                    or r.lijek_id!=tx.lijek_id or r.komisijski_ciklus_id!=tx.komisijski_ciklus_id
                    or tx.referenca_tip=='Trebovanje' and tx.referenca_id!=r.pk):
                return unknown
            seen.add(r.pk)
    quantity = sum((allocation_quantity(a) for a in audits if a.rezervacija_id==reservation.pk),Decimal(0))
    return True, quantity


@contextmanager
def stock_action(*, operation_id=None, cycle_id=None):
    token = _action.set({'operation_id':operation_id or uuid4(), 'cycle_id':cycle_id})
    try:
        yield
    finally:
        _action.reset(token)


def stamp_new_movement(row):
    """Called only for a new row, inside its ordinary business transaction."""
    from .models import Trebovanje, ZalihaTransakcija, KomisijskiCiklus
    if row.tip == 'POVRAT' and row.referenca_tip in {'Poništena terapija', 'Poništeno oralno izdavanje'}:
        from .models import KucnoIzdavanje
        source_kind, source_id = 'IzdavanjeOralneTerapije', row.referenca_id
        if row.referenca_tip == 'Poništena terapija':
            issue = KucnoIzdavanje.objects.filter(terapija_id=row.referenca_id).first()
            source_kind, source_id = ('KucnoIzdavanje', issue.pk) if issue else ('Terapija', row.referenca_id)
        original = list(ZalihaTransakcija.objects.filter(lijek_id=row.lijek_id,
            referenca_tip=source_kind, referenca_id=source_id,
            tip__in=['KUCNO_IZDAVANJE','AMBULANTNA_POTROSNJA','ORALNO_IZDAVANJE']))
        if len(original) == 1:
            row.serija, row.rok_trajanja = original[0].serija, original[0].rok_trajanja
            row.izvorna_transakcija_id = original[0].pk
    if row.tip in {'KUCNO_IZDAVANJE', 'AMBULANTNA_POTROSNJA', 'ORALNO_IZDAVANJE'}:
        from .models import KucnoIzdavanje, Terapija, IzdavanjeOralneTerapije
        model = {'KucnoIzdavanje': KucnoIzdavanje, 'Terapija': Terapija,
                 'IzdavanjeOralneTerapije': IzdavanjeOralneTerapije}.get(row.referenca_tip)
        issue = model.objects.filter(pk=row.referenca_id, lijek_id=row.lijek_id,
            pacijent_id=row.pacijent_id).first() if model else None
        if isinstance(issue, Terapija) and (issue.workflow_snapshot or {}).get('retrospective_accounting'):
            # Actual date and today's debit were checked together by the signed
            # retrospective service. Do not treat a zero debit as a second issue,
            # or compare a September lot's expiry with today's posting date.
            snap=issue.workflow_snapshot
            if row.kolicina != issue.kolicina or row.frizider_delta() != Decimal(snap['inventory_effect']):
                raise ValidationError('Promet ne odgovara pregledanom učinku naknadne primjene.')
            issue=None
        if issue:
            row.serija, row.rok_trajanja = issue.serija, getattr(issue, 'rok_trajanja', row.rok_trajanja)
            from .stock_lots import lot_balances
            lots = lot_balances(row.lijek)
            matches = [key for key in lots if key[0] and key[0] == row.serija and lots[key] > 0]
            if row.serija and row.rok_trajanja is None and matches:
                if len(matches) != 1:
                    raise ValidationError('Ista serija ima više rokova. Razjasnite rok prije izdavanja; nije izabran proizvoljan izvor.')
                row.rok_trajanja = matches[0][1]
            key = (row.serija, row.rok_trajanja)
            if row.rok_trajanja and row.rok_trajanja < row.datum:
                raise ValidationError('Dokumentovani rok serije prethodi izdavanju ili primjeni. Provjerite datum i seriju.')
            if row.serija and key in lots and lots[key] < row.kolicina:
                raise ValidationError('Dokumentovana serija nema dovoljno jedinica za izdavanje. Provjerite seriju i izvor; cijelo izdavanje je poništeno.')
            # Ordinary callers debit the aggregate before inserting this movement.
            # Unknown source can consume only the independently unknown remainder.
            if key not in lots or not row.serija:
                if any(k[0] for k in lots) and lots.get(('', None), 0) < 0:
                    raise ValidationError('Serija izdavanja ne odgovara dokumentovanoj zalihi. Navedite tačnu seriju; cijela radnja je poništena.')
    context = _action.get()
    if not context and row.tip not in {'ZAPRIMANJE','KOREKCIJA'}:
        return
    row.operation_id = row.operation_id or (context or {}).get('operation_id') or uuid4()
    row.jedinica_snapshot = row.jedinica_snapshot or row.lijek.jedinice_zalihe[0]
    cycle_id = (context or {}).get('cycle_id')
    if row.referenca_tip == 'KomisijskiCiklus':
        cycle_id = KomisijskiCiklus.objects.filter(pk=row.referenca_id).values_list('pk',flat=True).first()
    elif row.referenca_tip == 'Trebovanje':
        cycle_id = Trebovanje.objects.filter(pk=row.referenca_id).values_list('komisijski_ciklus_id',flat=True).first()
    elif row.referenca_tip == 'ZalihaTransakcija':
        original = ZalihaTransakcija.objects.filter(pk=row.referenca_id).first()
        if original:
            row.izvorna_transakcija_id = row.izvorna_transakcija_id or original.pk
            cycle_id = cycle_id or original.komisijski_ciklus_id
    row.komisijski_ciklus_id = row.komisijski_ciklus_id or cycle_id


@transaction.atomic
def link_receipt_evidence(evidence, movement, reservation):
    """Bind the new immutable receipt snapshot to a finite physical budget."""
    from .models import ZalihaTransakcija, EvidencijaSaglasnostiZaprimanja
    if reservation is None:
        raise ValidationError('Ranije potrebe za fizičkim pokrićem mijenjaju odabranu raspodjelu. '
            'Prijem nije sačuvan. Provjerite pacijente i rezervacije u Zalihama prije potvrde.')
    if movement is None:
        raise ValidationError('Prijem nema fizički ulaz i rezervaciju; cijela radnja je poništena.')
    tx = ZalihaTransakcija.objects.select_for_update().get(pk=movement.pk)
    req = evidence.trebovanje
    if (tx.tip!='ZAPRIMANJE' or tx.lijek_id!=req.lijek_id
            or tx.komisijski_ciklus_id!=evidence.komisijski_ciklus_id
            or tx.jedinica_snapshot!=req.lijek.jedinice_zalihe[0]
            or (reservation.pacijent_id,reservation.lijek_id,reservation.trebovanje_id)!=
               (req.pacijent_id,req.lijek_id,req.pk)):
        raise ValidationError('Ulaz, ciklus, prezentacija i rezervacija ne pripadaju istom prijemu.')
    if (tx.referenca_tip,tx.referenca_id) not in {
            ('Trebovanje',req.pk),('KomisijskiCiklus',req.komisijski_ciklus_id)}:
        raise ValidationError('Fizički ulaz nema izvorni zahtjev ili ciklus ovog prijema.')
    others=EvidencijaSaglasnostiZaprimanja.objects.filter(fizicka_transakcija=tx).exclude(pk=evidence.pk)
    if others.filter(trebovanje=req).exists():
        raise ValidationError('Ovaj fizički prijem već je povezan s ovim zahtjevom.')
    used=others.aggregate(n=Sum('zaprimljena_kolicina'))['n'] or Decimal('0')
    corrections=ZalihaTransakcija.objects.filter(referenca_tip='ZalihaTransakcija',referenca_id=tx.pk,tip='KOREKCIJA')
    net=tx.frizider_delta()+sum((c.frizider_delta() for c in corrections),Decimal('0'))
    if used+evidence.zaprimljena_kolicina>net:
        raise ValidationError('Raspodjela bi ponovo potrošila isti fizički prijem; ništa nije sačuvano.')
    evidence.fizicka_transakcija=tx
    evidence.rezervacija=reservation
    evidence.save(update_fields=['fizicka_transakcija','rezervacija'])
