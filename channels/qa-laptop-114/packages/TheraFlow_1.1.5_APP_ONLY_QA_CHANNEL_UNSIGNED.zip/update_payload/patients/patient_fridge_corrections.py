"""Patient fridge corrections over the canonical stock/reservation ledger.

Called by inventory_corrections under its signed preview, backup and table locks.
An inventory count is evidence of stock, not automatically a patient allocation.
"""
from datetime import date
from decimal import Decimal

from django.db.models import Sum
from django.utils import timezone

from . import models as m
from .data_corrections import require

ZERO = Decimal(0)
SCOPE = 'inventory_patient_stock'


def reserved(patient, medicine):
    return m.PacijentRezervacija.objects.filter(pacijent=patient, lijek=medicine,
        aktivno=True).aggregate(n=Sum('kolicina'))['n'] or ZERO


def approvals(patient, medicine):
    return [c for c in m.Komisija.objects.filter(pacijent=patient, lijek=medicine,
        datum_odobrenja__lte=timezone.localdate()).order_by('pk') if c.je_vazeca()]


def source_budget(tx):
    """A finite, explicitly documented unassigned input; never infer legacy origin."""
    if tx.lokacija not in ('', 'FRIZIDER') or tx.pacijent_id or tx.rezervacija_id or tx.rezervisana_pacijentu:
        return ZERO
    amount = tx.frizider_delta()
    if amount <= 0:
        return ZERO
    if tx.tip == 'KOREKCIJA' and tx.referenca_tip == 'PhysicalStockCorrection':
        count = m.PhysicalStockCorrection.objects.filter(pk=tx.referenca_id, lijek_id=tx.lijek_id).first()
        if not count or count.nova_kolicina-count.prethodna_kolicina != amount:
            return ZERO
        if m.ZalihaTransakcija.objects.filter(lijek_id=tx.lijek_id,
                referenca_tip='PhysicalStockCorrection', referenca_id=count.pk).count() != 1:
            return ZERO
    elif tx.tip != 'ZAPRIMANJE' or tx.referenca_tip or tx.raspodjele_prijema.exists():
        return ZERO
    if tx.rok_trajanja and tx.rok_trajanja < timezone.localdate():
        return ZERO
    assigned = ZERO
    for later in m.ZalihaTransakcija.objects.filter(lijek_id=tx.lijek_id, pk__gt=tx.pk):
        if later.izvorna_transakcija_id == tx.pk and later.tip == 'ASSIGN_FREE_STOCK_TO_PATIENT':
            assigned += later.kolicina
        elif (later.izvorna_transakcija_id == tx.pk and later.korekcija_id
              and later.korekcija.scope == SCOPE and later.korekcija.posljedice.get('revision')):
            assigned += later.promjena_rezervacije
        elif later.frizider_delta() < 0:
            # Without a persisted source link a later loss could have consumed
            # this input. Do not select it merely because total stock is positive.
            if later.izvorna_transakcija_id == tx.pk:
                assigned -= later.frizider_delta()
            else:
                return ZERO
        elif later.tip in ('ASSIGN_FREE_STOCK_TO_PATIENT',) and not later.izvorna_transakcija_id:
            return ZERO
    return max(ZERO, amount-assigned)


def sources(medicine):
    return [(tx, amount) for tx in m.ZalihaTransakcija.objects.filter(lijek=medicine,
        tip__in=['KOREKCIJA', 'ZAPRIMANJE']).order_by('pk') if (amount := source_budget(tx)) > 0]


def plan_correction(plan, patient, medicine, data, stock):
    from .inventory_corrections import units, restricted_allocation_quantity, _row
    require(patient.aktivan and patient.lijek_id == medicine.pk,
            'Dodjela pripada aktivnom pacijentu i njegovoj tačnoj prezentaciji lijeka.')
    if data.get('reverse_of'):
        return plan_revision(plan, patient, medicine, data, stock)
    before, after = reserved(patient, medicine), units(data.get('quantity'))
    delta = after-before
    require(delta > 0, 'Za dodavanje nedostajuće pacijentove količine unesite veću količinu. Za smanjenje odaberite dokazanu raspodjelu ili stvarni otpis u ovom obrascu; potrošnja se ne briše.')
    mode = data.get('source_mode')
    require(mode in {'EXISTING', 'UNRECORDED'}, 'Potvrdite je li ova količina već uračunata u ukupnu zalihu ambulante.')
    candidates = approvals(patient, medicine)
    chosen = data.get('approval')
    approval = next((c for c in candidates if str(c.pk) == str(chosen)), None) if chosen else (candidates[0] if len(candidates) == 1 else None)
    require(approval is not None, 'Odaberite važeće komisijsko odobrenje ovog pacijenta i lijeka.')
    allocated = m.PacijentRezervacija.objects.filter(komisija=approval, aktivno=True).aggregate(n=Sum('kolicina'))['n'] or ZERO
    require(allocated+delta <= approval.preostale_doze, 'Nova dodjela prelazi preostalo odobreno pravo pacijenta.')
    total_reserved = m.PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True).aggregate(n=Sum('kolicina'))['n'] or ZERO
    free = stock.u_frizideru-total_reserved-restricted_allocation_quantity([medicine.pk])
    require(free >= 0, 'Postojeći saldo ne pokriva rezervacije. Razjasnite manjak prije nove dodjele.')
    plan.update(before=before, after=after, delta=delta, patient_id=patient.pk,
        approval_id=approval.pk, source_mode=mode, new_reservation_delta=delta)
    if mode == 'EXISTING':
        available = sources(medicine)
        chosen = data.get('source_movement')
        source = next(((tx, n) for tx, n in available if str(tx.pk) == str(chosen)), None) if chosen else (available[0] if len(available) == 1 else None)
        require(source is not None, 'Odaberite dokumentovani slobodni izvor. Sam ukupan saldo ne dokazuje porijeklo bočice.')
        tx, amount = source
        require(delta <= min(amount, free), 'Izvor nema toliko slobodnih jedinica; provjerite postojeće rezervacije i dodjele.')
        plan.update(original_movement_id=tx.pk, batch=tx.serija, expires=str(tx.rok_trajanja or ''))
        plan['impacts'].append('Povezuje se već evidentirana fizička količina. Ukupna zaliha ambulante se ne povećava.')
    else:
        require(data.get('actual_count') is True, 'Potvrdite da je dodatna količina stvarno prebrojana i ranije neevidentirana.')
        require(data.get('counted_total') is not None and units(data['counted_total']) == stock.u_frizideru+delta,
            'Prebrojana ukupna zaliha mora biti dosadašnja zaliha plus dodatna količina. Ako je bočica već uračunata, odaberite postojeću zalihu; ne dodajte je ponovo.')
        expiry = date.fromisoformat(str(data['expires'])) if data.get('expires') else None
        require(not expiry or expiry >= timezone.localdate(), 'Istekla količina nije raspoloživa za terapiju.')
        plan.update(stock_delta=delta, batch=str(data.get('batch', '')).strip(), expires=str(expiry or ''))
        plan['impacts'].append('Jednom korekcijom dodaje se stvarno prebrojana neevidentirana količina i rezerviše za ovog pacijenta.')
    _row(plan, 'Količina za ovog pacijenta u frižideru', before, after)
    _row(plan, f'Odobrenje {approval.broj_saglasnosti} — preostalo pravo', approval.preostale_doze, approval.preostale_doze)
    plan['impacts'].append('Nema kućnog izdavanja ni primjene. Komisijski dokumenti i zaprimljene količine službenih zahtjeva se ne prepisuju; pokriće i nacrti se preračunavaju iz povezane rezervacije.')


def apply_correction(plan, receipt, user):
    if plan.get('revision'):
        return apply_revision(plan, receipt, user)
    from .inventory import reserve_physical_stock, izracunaj_frizider_iz_transakcija
    patient = m.Pacijent.objects.get(pk=plan['patient_id'])
    medicine = m.Lijek.objects.get(pk=plan['medicine_id'])
    stock = m.Zaliha.objects.get(lijek=medicine)
    common = dict(lijek=medicine, pacijent=patient, komisija_id=plan['approval_id'],
        datum=plan['event_date'], korisnik=user, korekcija=receipt, operation_id=receipt.operation_id,
        serija=plan['batch'], rok_trajanja=plan['expires'] or None, lokacija='FRIZIDER', napomena=plan['reason'])
    if plan['stock_delta']:
        source = m.ZalihaTransakcija.objects.create(**common, tip='KOREKCIJA',
            kolicina=plan['delta'], promjena_salda=plan['delta'], referenca_tip='PatientDataCorrection', referenca_id=receipt.pk)
        stock.u_frizideru += plan['delta']
        stock.save(update_fields=['u_frizideru', 'ukupno'])
    else:
        source = m.ZalihaTransakcija.objects.get(pk=plan['original_movement_id'])
    allocated = reserve_physical_stock(pacijent=patient, lijek=medicine, quantity=plan['delta'],
        komisija=m.Komisija.objects.get(pk=plan['approval_id']), user=user, note=plan['reason'])
    require(allocated['allocated'] == plan['delta'] and allocated['waiting'] == 0,
        'Cijela dodjela nije moguća. Ništa nije sačuvano; ponovite pregled.')
    reservation = allocated['reservation']
    m.ZalihaTransakcija.objects.create(**common, tip='ASSIGN_FREE_STOCK_TO_PATIENT',
        kolicina=plan['delta'], promjena_salda=0, promjena_rezervacije=plan['delta'],
        rezervacija=reservation, izvorna_transakcija=source, referenca_tip='ZalihaTransakcija', referenca_id=source.pk)
    # Only the patient's same-product, same-approval pending quantities can be
    # satisfied. Original requests remain immutable evidence of actual delivery.
    remaining = plan['delta']
    for need in m.PotrebaFizickogPokrica.objects.filter(pacijent=patient, lijek=medicine,
            komisija_id=plan['approval_id'], status=m.PotrebaFizickogPokrica.STATUS_CEKA).order_by('prioritet_datum', 'pk'):
        covered = min(remaining, need.preostala_kolicina)
        if not covered:
            continue
        need.preostala_kolicina -= covered
        remaining -= covered
        if need.preostala_kolicina == 0:
            need.status = m.PotrebaFizickogPokrica.STATUS_POKRIVENA
        need.save(update_fields=['preostala_kolicina', 'status', 'izmijenjeno'])
    require(reserved(patient, medicine) == plan['after'] and
        izracunaj_frizider_iz_transakcija(medicine) == stock.u_frizideru,
        'Kontrola povezane zalihe nije prošla. Cijela ispravka je poništena.')
    from .commission_planning import recalculate_patient_commission_drafts
    recalculate_patient_commission_drafts(patient, user=user, reason=f'Ispravka #{receipt.pk}: {plan["reason"]}')


def allocation_basis(reservation):
    """Proof through actual movement, reservation, correction and physical source IDs."""
    rows = list(m.ZalihaTransakcija.objects.filter(rezervacija=reservation,
        korekcija__scope=SCOPE, tip='ASSIGN_FREE_STOCK_TO_PATIENT').select_related('korekcija', 'izvorna_transakcija'))
    if not rows:
        return False, None, None
    total = ZERO
    for row in rows:
        source, audit = row.izvorna_transakcija, row.korekcija
        if (not source or row.pacijent_id != reservation.pacijent_id or row.lijek_id != reservation.lijek_id
                or audit.pacijent_id != reservation.pacijent_id or source.lijek_id != row.lijek_id
                or row.komisija_id != reservation.komisija_id or row.promjena_rezervacije != row.kolicina
                or (row.referenca_tip, row.referenca_id) != ('ZalihaTransakcija', source.pk)
                or row.kolicina <= 0 or row.frizider_delta() != 0 or source.frizider_delta() <= 0
                or (row.serija, row.rok_trajanja) != (source.serija, source.rok_trajanja)
                or row.kolicina != Decimal(str(audit.posljedice.get('delta', -1)))
                or audit.posljedice.get('approval_id') != reservation.komisija_id):
            return True, None, None
        plan = audit.posljedice
        if plan.get('source_mode') == 'EXISTING':
            if plan.get('original_movement_id') != source.pk or source.pacijent_id or source.rezervacija_id:
                return True, None, None
        elif plan.get('source_mode') == 'UNRECORDED':
            if source.korekcija_id != audit.pk or source.pacijent_id != reservation.pacijent_id:
                return True, None, None
        else:
            return True, None, None
        revisions = list(m.ZalihaTransakcija.objects.filter(korekcija__scope=SCOPE,
            korekcija__posljedice__assignment_id=row.pk).select_related('korekcija'))
        adjustment = physical_adjustment = ZERO
        for revision in revisions:
            detail = revision.korekcija.posljedice
            if (not detail.get('revision') or revision.rezervacija_id != reservation.pk
                    or revision.izvorna_transakcija_id != source.pk
                    or revision.promjena_rezervacije != Decimal(detail['delta'])
                    or revision.frizider_delta() != Decimal(detail['stock_delta'])):
                return True, None, None
            adjustment += revision.promjena_rezervacije
            physical_adjustment += revision.frizider_delta()
        assigned = source.povezani_prometi.filter(tip='ASSIGN_FREE_STOCK_TO_PATIENT').aggregate(n=Sum('kolicina'))['n'] or ZERO
        source_revisions = list(source.povezani_prometi.filter(korekcija__scope=SCOPE,
            korekcija__posljedice__revision=True))
        all_assigned_adjustments = sum((x.promjena_rezervacije for x in source_revisions), ZERO)
        all_physical_adjustments = sum((x.frizider_delta() for x in source_revisions), ZERO)
        if assigned + all_assigned_adjustments > source.frizider_delta() + all_physical_adjustments:
            return True, None, None
        if row.kolicina + adjustment < 0:
            return True, None, None
        total += row.kolicina + adjustment
    return True, total, rows[0]


def plan_revision(plan, patient, medicine, data, stock):
    """Correct the documented assignment/count, preserving the original receipt."""
    from .inventory_corrections import units, _row, reservation_consumption, restricted_allocation_quantity
    previous = m.PatientDataCorrection.objects.get(pk=data['reverse_of'], pacijent=patient, scope=SCOPE)
    assignment_id = previous.posljedice.get('assignment_id')
    if assignment_id:
        assignment = m.ZalihaTransakcija.objects.get(pk=assignment_id, korekcija__scope=SCOPE)
    else:
        assignments = previous.prometi.filter(tip='ASSIGN_FREE_STOCK_TO_PATIENT')
        require(assignments.count() == 1, 'Korekcija nema jednoznačno povezanu dodjelu.')
        assignment = assignments.get()
    root = assignment.korekcija
    latest = m.PatientDataCorrection.objects.filter(scope=SCOPE,
        posljedice__assignment_id=assignment.pk).order_by('-pk').first() or root
    require(latest.pk == previous.pk, 'Ova korekcija je već ispravljena. Otvorite posljednju povezanu korekciju u historiji.')
    reservation, source = assignment.rezervacija, assignment.izvorna_transakcija
    require(reservation and source and reservation.pacijent_id == patient.pk and reservation.lijek_id == medicine.pk,
            'Dodjela nema dokazanu vezu s ovim pacijentom i proizvodom.')
    linked, basis, _ = allocation_basis(reservation)
    consumed, events = reservation_consumption(reservation)
    require(linked and basis is not None and consumed == 0 and reservation.kolicina == basis,
            'Korekcija ima kasniju potrošnju ili neusaglašene izvore. Najprije razjasnite povezano izdavanje ili primjenu.')
    require(not m.BrzaIzmjenaPacijenta.objects.filter(izvorna_rezervacija=reservation).exists(),
            'Korekcija ima kasniji prijenos drugom pacijentu. Najprije razjasnite taj prijenos.')
    # Do not reinterpret a physical count across intervening outflows/counts.
    allowed = {assignment.pk} | set(m.ZalihaTransakcija.objects.filter(
        korekcija__scope=SCOPE, korekcija__posljedice__assignment_id=assignment.pk).values_list('pk', flat=True))
    require(not any(tx.pk not in allowed and tx.frizider_delta() != 0
        for tx in m.ZalihaTransakcija.objects.filter(lijek=medicine, pk__gt=assignment.pk)),
        'Poslije ove korekcije postoje novi fizički prometi. Njihov izvor treba razjasniti prije izmjene ranijeg brojanja.')
    before, after = reserved(patient, medicine), units(data.get('quantity'))
    delta = after-before
    require(delta != 0 and reservation.kolicina+delta >= 0, 'Unesite različitu količinu unutar ove povezane dodjele.')
    own_adjustments = m.ZalihaTransakcija.objects.filter(korekcija__scope=SCOPE,
        korekcija__posljedice__assignment_id=assignment.pk).aggregate(n=Sum('promjena_rezervacije'))['n'] or ZERO
    require(assignment.kolicina + own_adjustments + delta >= 0,
        'Smanjenje prelazi količinu ove korekcije. Druge povezane dodjele ostaju sačuvane; odaberite odgovarajući zapis.')
    approval = reservation.komisija
    require(approval is not None, 'Dodjeli nedostaje povezano odobrenje.')
    if delta > 0:
        allocated = m.PacijentRezervacija.objects.filter(komisija=approval, aktivno=True).aggregate(n=Sum('kolicina'))['n'] or ZERO
        require(approval.je_vazeca() and allocated+delta <= approval.preostale_doze,
                'Nova dodjela prelazi vlastito važeće pravo pacijenta. Pravo se ne povećava korekcijom.')
    mode = root.posljedice['source_mode']
    stock_delta = delta if mode == 'UNRECORDED' else ZERO
    if mode == 'EXISTING' and delta > 0:
        total = m.PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True).aggregate(n=Sum('kolicina'))['n'] or ZERO
        free = stock.u_frizideru-total-restricted_allocation_quantity([medicine.pk])
        require(delta <= min(free, source_budget(source)), 'Izvor više nema dovoljno slobodnih jedinica.')
    plan.update(revision=True, assignment_id=assignment.pk, reservation_id=reservation.pk,
        root_correction_id=root.pk, original_movement_id=source.pk, before=before, after=after,
        delta=delta, stock_delta=stock_delta, source_mode=mode, patient_id=patient.pk,
        approval_id=approval.pk, batch=assignment.serija, expires=str(assignment.rok_trajanja or ''),
        reservations=[{'id': reservation.pk, 'delta': delta, 'after': reservation.kolicina+delta}],
        events=events)
    _row(plan, 'Količina za ovog pacijenta u frižideru', before, after)
    _row(plan, 'Odobreno pravo — ostaje isto', approval.preostale_doze, approval.preostale_doze)
    plan['impacts'].append('Ispravlja se ranija povezana dodjela uz očuvanje originala. '
        + ('Ukupna fizička zaliha ostaje ista.' if mode == 'EXISTING' else 'Povezani fizički višak se koriguje za istu razliku.'))


def apply_revision(plan, receipt, user):
    from .inventory import izracunaj_frizider_iz_transakcija
    reservation = m.PacijentRezervacija.objects.get(pk=plan['reservation_id'])
    reservation.kolicina += plan['delta']
    reservation.aktivno = reservation.kolicina > 0
    reservation.save(update_fields=['kolicina', 'aktivno'])
    stock = m.Zaliha.objects.get(lijek_id=plan['medicine_id'])
    stock.u_frizideru += plan['stock_delta']
    stock.save(update_fields=['u_frizideru', 'ukupno'])
    m.ZalihaTransakcija.objects.create(lijek_id=plan['medicine_id'], pacijent_id=plan['patient_id'],
        komisija_id=plan['approval_id'], rezervacija=reservation, korekcija=receipt,
        operation_id=receipt.operation_id, datum=plan['event_date'], tip='KOREKCIJA',
        kolicina=plan['delta'], promjena_salda=plan['stock_delta'], promjena_rezervacije=plan['delta'],
        izvorna_transakcija_id=plan['original_movement_id'], referenca_tip='ZalihaTransakcija',
        referenca_id=plan['original_movement_id'], lokacija='FRIZIDER', korisnik=user,
        serija=plan['batch'], rok_trajanja=plan['expires'] or None, napomena=plan['reason'])
    # Re-open only needs originally covered by this correction, never invent a new request.
    root = m.PatientDataCorrection.objects.get(pk=plan['root_correction_id'])
    remaining = -plan['delta']
    for key, old in root.prije.get('patients_potrebafizickogpokrica', {}).items():
        new = root.poslije['patients_potrebafizickogpokrica'][key]
        if remaining <= 0 or old is None:
            continue
        need = m.PotrebaFizickogPokrica.objects.get(pk=key)
        amount = min(remaining, Decimal(old['preostala_kolicina'])-Decimal(new['preostala_kolicina']),
                     need.trazena_kolicina-need.preostala_kolicina)
        if amount > 0:
            need.preostala_kolicina += amount
            need.status = need.STATUS_CEKA
            need.save(update_fields=['preostala_kolicina', 'status', 'izmijenjeno'])
            remaining -= amount
    if plan['delta'] > 0:
        remaining = plan['delta']
        for need in m.PotrebaFizickogPokrica.objects.filter(pacijent_id=plan['patient_id'],
                lijek_id=plan['medicine_id'], komisija_id=plan['approval_id'],
                status=m.PotrebaFizickogPokrica.STATUS_CEKA).order_by('prioritet_datum', 'pk'):
            amount = min(remaining, need.preostala_kolicina)
            if amount <= 0:
                continue
            need.preostala_kolicina -= amount
            remaining -= amount
            if need.preostala_kolicina == 0:
                need.status = need.STATUS_POKRIVENA
            need.save(update_fields=['preostala_kolicina', 'status', 'izmijenjeno'])
    require(reserved(reservation.pacijent, reservation.lijek) == plan['after']
        and izracunaj_frizider_iz_transakcija(reservation.lijek) == stock.u_frizideru,
        'Kontrola povezane korekcije nije prošla. Ništa nije sačuvano.')
    from .commission_planning import recalculate_patient_commission_drafts
    recalculate_patient_commission_drafts(reservation.pacijent, user=user,
        reason=f'Ispravka prethodne korekcije #{receipt.pk}: {plan["reason"]}')
