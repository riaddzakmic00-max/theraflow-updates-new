"""Read-only explanations over existing inventory and correction previews.

This module never applies a change or resolves a clinical order. Preview rows
belong to the underlying service; suggestions require a separate confirmation.
"""
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal
from urllib.parse import urlencode

from django.urls import reverse
from django.utils import timezone
from django.utils.dateparse import parse_date

from . import models as m
from .inventory import (inventory_position, patient_reservation_breakdown,
                        _physical_medicine_ids, izracunaj_frizider_iz_transakcija)

ASSIGNMENT_REASONS = (
    ('applied', 'Doza je primijenjena pacijentu'),
    ('free', 'Doza je vraćena u slobodnu zalihu'),
    ('transfer', 'Doza je prenesena drugom pacijentu'),
    ('mistake', 'Zaduženje je bilo greškom evidentirano'),
    ('other', 'Drugi razlog'),
)


def balance_explanation(medicine, patient=None):
    """Canonical amounts plus their source records, scoped to one presentation."""
    ids = _physical_medicine_ids(medicine)
    position = inventory_position(medicine, include_planned_need=False)
    sources, movement_groups = [], defaultdict(Decimal)
    ledger = Decimal(0)
    for med in m.Lijek.objects.filter(pk__in=ids):
        initial = m.MigracijskoPocetnoStanjeZalihe.objects.filter(lijek=med).first()
        sources.append(dict(label=str(med), quantity=initial.kolicina if initial else 0,
                            checkpoint=initial.ledger_checkpoint_id if initial else None))
        ledger += izracunaj_frizider_iz_transakcija(med)
        movements = m.ZalihaTransakcija.objects.filter(lijek=med)
        if initial:
            movements = movements.filter(pk__gt=initial.ledger_checkpoint_id or 0)
        for movement in movements.iterator():
            # Use the ledger's own delta semantics, including location and voids.
            movement_groups[movement.get_tip_display()] += movement.frizider_delta()
    own = patient_reservation_breakdown(patient, medicine_ids=ids) if patient else None
    approvals = list(m.Komisija.objects.filter(pacijent=patient, lijek_id__in=ids)
                     .order_by('pk')) if patient else []
    from .commission_service import patient_commission_coverage
    coverage=patient_commission_coverage(patient,medicine_ids=ids) if patient else None
    clinical_coverage=patient_commission_coverage(patient) if patient else None
    snapshot=m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient, lijek_id__in=ids).first() if patient else None
    movements = list(m.ZalihaTransakcija.objects.filter(lijek_id__in=ids)
                     .select_related('pacijent').order_by('-datum', '-pk')[:101])
    return dict(medicine=medicine, patient=patient, position=position, ledger=ledger,
                ledger_matches=ledger == position['in_fridge'], sources=sources,
                movement_groups=[dict(label=k, delta=v) for k, v in movement_groups.items()],
                movements=movements[:100], movements_truncated=len(movements) > 100,
                reservations=own['items'] if own else list(
                    m.PacijentRezervacija.objects.filter(lijek_id__in=ids, aktivno=True,
                        kolicina__gt=0).select_related('pacijent')[:101]),
                patient_reserved=own['total_effective'] if own else None,
                approvals=approvals,coverage=coverage,clinical_coverage=clinical_coverage,snapshot=snapshot)


def possible_stock_causes(medicine, patient=None, *, start=None, end=None):
    """Candidates, never diagnoses; no session or correction is written."""
    from .smart_reconciliation import scan
    end = end or timezone.localdate()
    start = start or end - timedelta(days=29)
    incomplete = False
    try:
        findings = scan(start, end, patient=patient, medicine=medicine)
    except ValueError as exc:
        findings = []
        incomplete = True
        scan_warning = str(exc)
    ids = _physical_medicine_ids(medicine)
    unresolved = [f for f in findings if f.get('id') and not f.get('actual_ids')]
    query = {'section': 'smart', 'cc_medicine': medicine.pk}
    if patient:
        query['cc_patient'] = patient.pk
    candidates = [dict(label='Moguća neevidentirana terapija', detail=f"{f['patient']} · {f['date_label']}",
                       url=reverse('correction_center')+'?'+urlencode(query)) for f in unresolved[:20]]
    if medicine.kucna_terapija or medicine.oralna_terapija:
        if medicine.oralna_terapija:
            home_url=reverse('oralna_terapija',args=[patient.pk]) if patient else reverse('correction_center')+'?'+urlencode({'cc_medicine':medicine.pk,'section':'events'})
        else:
            home_url=reverse('retrospective_events')+'?'+urlencode({'kind':'home','medicine_id':medicine.pk,
                **({'patient_id':patient.pk} if patient else {})})
        candidates.append(dict(label='Moguće neevidentirano kućno izdavanje',
            detail='Provjerite stvarnu predaju i ostatak kod pacijenta; izdavanje nije primjena.',
            url=home_url))
    requests = m.Trebovanje.objects.filter(lijek_id__in=ids,odobrene_doze__gt=0).exclude(status='ZAPRIMLJENO')
    if patient:
        requests = requests.filter(pacijent=patient)
    for request in requests.select_related('pacijent').order_by('-pk')[:20]:
        candidates.append(dict(label='Moguće neevidentirano zaprimanje',
            detail=f'{request.pacijent} · provjerite odobrenje i stvarni datum prijema.',
            url=reverse('komisijski_centar')))
    reservations = m.PacijentRezervacija.objects.filter(lijek_id__in=ids, aktivno=True, kolicina__gt=0)
    if patient:
        reservations = reservations.filter(pacijent=patient)
    truncated_sources=requests.count()>20 or reservations.count()>20
    for reservation in reservations.select_related('pacijent','termin')[:20]:
        candidates.append(dict(label='Aktivno zaduženje / rezervacija za provjeru',
            detail=f'{reservation.pacijent} · {reservation.kolicina:g}; zaduženje je dio frižidera.',
            url=reverse('correction_allocation',args=[reservation.pacijent_id,reservation.lijek_id])+'?kind=release'))
    candidates.append(dict(label='Otpis, oštećenje ili ranija korekcija',
        detail='Provjerite postojeće prijeme i promet prije fizičke korekcije.',
        url=reverse('medicine_corrections',args=[medicine.pk])))
    return dict(candidates=candidates, start=start, end=end,
                incomplete=incomplete or len(unresolved) > 20 or truncated_sources,
                warning=scan_warning if incomplete else '')


def impact_analysis(patient, medicine, plan, user=None):
    automatic = [f"{row.get('label') or row.get('plan', {}).get('title') or row.get('medicine', 'Događaj')}: {row.get('before', '—')} → {row.get('after', '—')}"
                 for row in plan.get('rows', []) if row.get('before') != row.get('after')]
    if not automatic and 'total_after' in plan:
        automatic.append(f"Fizičko stanje: {plan['total_before']} → {plan['total_after']}")
    decisions, checks, actions = [], [], []
    checks.extend(str(w) for w in plan.get('warnings', []))
    checks.extend(str(w) for w in plan.get('impacts', []))
    if not medicine:
        return dict(automatic=automatic, decisions=decisions, checks=checks, actions=actions)
    position = inventory_position(medicine, include_planned_need=False)
    if position['physical_reservation_shortfall']:
        decisions.append(f"Fizički manjak prema zaduženjima: {position['physical_reservation_shortfall']:g}.")
    if not patient:
        return dict(automatic=automatic, decisions=decisions, checks=checks, actions=actions)
    own = patient_reservation_breakdown(patient, medicine_ids=_physical_medicine_ids(medicine))['total_effective']
    future = list(m.Termin.objects.filter(pacijent=patient, datum__gte=timezone.localdate(),
        status__in=[m.Termin.STATUS_PLANIRANA,m.Termin.STATUS_ODGODJENA])
        .select_related('lijek').order_by('datum','pk'))
    proposed = plan.get('after') if isinstance(plan.get('after'), dict) else {}
    data = plan.get('data') or {}
    units = proposed.get('broj_jedinica')
    if units is not None:
        quantity = Decimal(str(units))
        checks.append(f'Naredna primjena prema unesenom nalogu zahtijeva {quantity:g} jedinica. '
                      f'Rezervisano: {own:g}. Slobodna zaliha: {position["freely_available"]:g}.')
        shortage = max(Decimal(0), quantity-own)
        if shortage:
            decisions.append(f'Nedostaje zaduženje za narednu primjenu: {shortage:g} jedinica.')
            # Eligibility and capacity are validated by the existing allocation service.
            from dashboard.permissions import je_admin
            if user and je_admin(user):
                from .correction_center import allocation_plan
                try:
                    allocation_plan(patient,medicine,dict(kind='allocate',quantity=str(shortage),
                        reason='Dodatna dodjela prema potvrđenom nalogu ljekara.'),user)
                except ValueError as exc:
                    checks.append(str(exc))
                else:
                    actions.append(dict(label=f'Dodijeli još {shortage:g} slobodnih jedinica',
                        url=reverse('correction_allocation',args=[patient.pk,medicine.pk])+'?'+urlencode({'quantity':str(shortage)})))
        checks.append('Kliničku dozu potvrđuje korisnik prema nalogu ljekara; dodatna dodjela ima zaseban pregled i potvrdu.')
    next_date = parse_date(str(plan.get('next_date') or plan.get('expected_date') or ''))
    last_date = parse_date(str(data.get('datum_posljednje_terapije') or ''))
    if last_date:
        from .retrospective_history import proven_therapy_context
        from .retrospective_schedule import next_date_plan
        try:
            historical, _ = proven_therapy_context(m.Termin(pacijent=patient,lijek=medicine,datum=last_date),last_date)
            next_date = next_date_plan(historical,last_date)['due']
            checks.append(f'Očekivani naredni datum prema dokazanom nalogu: {next_date:%d.%m.%Y.}')
        except ValueError:
            decisions.append('Potrebna provjera terapijskog plana / naloga ljekara. Historijski interval ili faza nisu dokazani.')
        checks.extend(['Provjerite da li postoji stvarna primjena i odgovarajuća potrošnja lijeka.',
                       f'Pacijentovo aktivno zaduženje u frižideru: {own:g}. Ispravka datuma nije nova potrošnja.'])
    for appointment in future:
        if next_date and appointment.datum != next_date:
            decisions.append(f'Postojeći termin se razlikuje od očekivanog datuma. '
                f'Postojeći termin: {appointment.datum:%d.%m.%Y.}; očekivano: {next_date:%d.%m.%Y.}')
    sc_change = bool(plan.get('sc_name')) or plan.get('kind') == 'medicine' or plan.get('scope') == 'medicine'
    if plan.get('phase_schedule'):
        automatic.append('Preračun doze budućih termina trenutne prezentacije; termini stare faze se otkazuju uz audit, bez brisanja rezervacija ili historije.')
        checks.append('IV i SC zaduženja ostaju odvojena. Dodatno zaduženje zahtijeva zasebnu dodjelu.')
    elif sc_change or patient.aktivni_fazni_protokol():
        for appointment in future:
            if appointment.lijek and appointment.lijek.put_primjene == 'IV':
                decisions.append(f'Provjerite budući IV termin {appointment.datum:%d.%m.%Y.} uz SC / novi plan. '
                                 'Termin se mijenja samo kroz zasebno potvrđenu odluku.')
        checks.append('IV i SC zaduženja provjeravaju se odvojeno. Kućno izdavanje se ne pretpostavlja.')
    return dict(automatic=automatic, decisions=decisions, checks=list(dict.fromkeys(checks)), actions=actions)
