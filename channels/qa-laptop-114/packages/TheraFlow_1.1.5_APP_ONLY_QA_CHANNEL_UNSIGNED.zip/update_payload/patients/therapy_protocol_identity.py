"""Read-only identity of the current treatment course; never infer it from stock."""
from .request_cache import get_or_set


def current_course_change(patient):
    if not patient.pk or not patient.lijek_id:
        return None
    from .models import PromjenaTerapije
    def load():
        loaded = getattr(patient, '_workflow_course_changes', None)
        when = getattr(patient, '_retrospective_date', None)
        latest = next((c for c in loaded if not when or c.datum_pocetka_nove_terapije <= when), None) if loaded is not None else None
        if loaded is None:
            query = PromjenaTerapije.objects.filter(pacijent_id=patient.pk)
            if when:
                query = query.filter(datum_pocetka_nove_terapije__lte=when)
            latest = query.order_by("-datum_pocetka_nove_terapije", "-pk").first()
        return latest if latest and latest.novi_lijek_id in patient.lijek.equivalent_ids() else None
    return get_or_set("therapy_course_change", (patient.pk, patient.lijek_id, str(getattr(patient, '_retrospective_date', None))), load)


def current_course_start(patient):
    change = current_course_change(patient)
    return change.datum_pocetka_nove_terapije if change else None


def individual_matches(patient, protocol):
    if not protocol or not patient.lijek_id:
        return False
    owner = protocol.lijek_id or (
        protocol.standardni_protokol.lijek_id if protocol.standardni_protokol_id else None)
    return owner in patient.lijek.equivalent_ids() if owner else False
