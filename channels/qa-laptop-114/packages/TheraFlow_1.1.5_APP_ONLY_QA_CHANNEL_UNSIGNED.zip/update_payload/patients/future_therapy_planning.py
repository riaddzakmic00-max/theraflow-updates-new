"""Read-only planiranje budućih terapija.

Ovaj modul ne kreira termine i ne mijenja historijske terapije. Njegov rezultat
je projekcija koju budući potrošači mogu koristiti tek nakon zasebne integracije.
"""

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from typing import Iterable, Mapping

from django.db.models import Prefetch
from django.utils import timezone

from .individual_protocols import get_effective_protocol, get_step_for_application_number
from .phased_protocols import phased_planning_configuration
from .scheduling import (
    adjust_to_allowed_therapy_date,
    is_allowed_therapy_date,
)
from .models import (
    IndividualniKorakProtokola,
    Komisija,
    KomisijskiZahtjev,
    MigracijskiSnapshotPacijenta,
    Pacijent,
    PacijentRezervacija,
    PacijentZaduzenje,
    PauzaTerapije,
    PotrebaFizickogPokrica,
    Terapija,
    TerapijskiKorakProtokola,
    Termin,
    Trebovanje,
)
from .therapy_history import actually_administered_therapy_query


DEFAULT_HORIZON_DAYS = 365
ACTIVE_APPOINTMENT_STATUSES = (Termin.STATUS_PLANIRANA,)


@dataclass(frozen=True, order=True)
class IntervalChange:
    """Promjena intervala koja važi za terapije od navedenog datuma."""

    effective_from: date
    interval_weeks: int

    def __post_init__(self):
        if not 1 <= int(self.interval_weeks) <= 52:
            raise ValueError("Interval terapije mora biti između 1 i 52 sedmice.")


@dataclass(frozen=True)
class FutureTherapy:
    pacijent: Pacijent
    lijek: object
    datum_terapije: date
    kolicina_lijeka: Decimal
    vrsta_protokola: str
    interval_sedmica: int
    termin_postoji: bool
    razlog_izracuna: str
    termin_id: int | None = None
    faza_terapije: str = ""


def _generate_phased_future_therapies(
    pacijent,
    configuration,
    *,
    start_date,
    target_date,
):
    """Projektuj datirane fazne primjene bez upisa ili promjene faze."""

    if not configuration.planning_possible:
        return []
    state = configuration.state
    from .regimen_changes import regimen_quantity, next_regimen_date
    if configuration.relative_initial_projection:
        # Početna IV indukcija nema klinički datum prije fizičkog zaprimanja.
        return []
    if not state.sljedeci_datum:
        return []

    appointments = _existing_appointments(pacijent, start_date, target_date)
    appointments_by_date = {}
    for appointment in appointments:
        appointments_by_date.setdefault(appointment.datum, appointment)

    results = []
    therapy_date = state.sljedeci_datum
    if state.faza == state.FAZA_ODRZAVANJE and state.datum_posljednje_primjene:
        therapy_date = next_regimen_date(pacijent, state.datum_posljednje_primjene,
            state.interval_odrzavanja_sedmica)[1]
    first_application = True
    appointment_index = 0
    while therapy_date <= target_date and len(results) < 1000:
        # Booked appointments stay authoritative even if the new order would
        # suggest another date. No appointment row is moved or recreated here.
        existing = appointments[appointment_index] if appointment_index < len(appointments) else None
        if existing:
            therapy_date = existing.datum
            appointment_index += 1
        if therapy_date >= start_date:
            results.append(FutureTherapy(
                pacijent=pacijent,
                lijek=configuration.medicine,
                datum_terapije=therapy_date,
                kolicina_lijeka=regimen_quantity(pacijent, therapy_date, configuration.units),
                vrsta_protokola=f"fazni:{state.protokol_kljuc}",
                interval_sedmica=int(configuration.interval_weeks or 0),
                termin_postoji=existing is not None,
                razlog_izracuna=(
                    "Već zakazani termin ima prednost nad faznom projekcijom."
                    if existing
                    else "Datum je izveden iz autoritativnog stanja faznog protokola."
                ),
                termin_id=existing.pk if existing else None,
                faza_terapije=configuration.phase_label,
            ))
        interval = (
            state.interval_odrzavanja_sedmica
            if first_application and state.faza == state.FAZA_CEKA_PRVU_SC
            else configuration.interval_weeks
        )
        interval = int(interval or 0)
        if interval <= 0:
            break
        interval, therapy_date = next_regimen_date(pacijent, therapy_date, interval)
        first_application = False
    return results


def _normalise_interval_changes(changes: Iterable | None) -> tuple[IntervalChange, ...]:
    normalised = []
    for change in changes or ():
        if isinstance(change, IntervalChange):
            item = change
        elif isinstance(change, Mapping):
            item = IntervalChange(
                effective_from=change["effective_from"],
                interval_weeks=change["interval_weeks"],
            )
        else:
            effective_from, interval_weeks = change
            item = IntervalChange(effective_from=effective_from, interval_weeks=interval_weeks)
        normalised.append(item)
    return tuple(sorted(normalised, key=lambda item: item.effective_from))


def _latest_actual_therapy(pacijent):
    return pacijent.posljednja_stvarno_primljena_terapija()


def _historical_application_count(pacijent) -> int:
    from .therapy_history import (
        actually_administered_therapy_query,
        is_actually_administered_therapy,
    )

    from .therapy_protocol_identity import current_course_change
    course = current_course_change(pacijent)
    start = course.datum_pocetka_nove_terapije if course else None
    previous_ids = set(course.prethodni_zapisi.get('therapy_ids', [])) if course else set()
    prefetched = getattr(pacijent, "_planning_therapies", None)
    if prefetched is None:
        prefetched = getattr(pacijent, "_workflow_therapies", None)
    if prefetched is not None:
        equivalent_ids = set(pacijent.lijek.equivalent_ids()) if pacijent.lijek_id else set()
        # Jedna klinička aplikacija se vodi količinom na Terapija zapisu.
        # Dva historijska zapisa istog lijeka i datuma zato ne smiju pomjeriti
        # protokol za dva koraka (npr. nakon korekcije/duplog importa).
        return len({
            item.datum
            for item in prefetched
            if (
                (not equivalent_ids or item.lijek_id in equivalent_ids)
                and (not start or item.datum >= start) and item.pk not in previous_ids
                and is_actually_administered_therapy(item)
            )
        })
    queryset = actually_administered_therapy_query(
        Terapija.objects.filter(pacijent=pacijent)
    )
    if pacijent.lijek_id:
        queryset = queryset.filter(lijek_id__in=pacijent.lijek.equivalent_ids())
    if start:
        queryset = queryset.filter(datum__gte=start).exclude(pk__in=previous_ids)
    return queryset.values("datum").distinct().count()


def _migration_anchor(pacijent):
    try:
        snapshot = pacijent.migracijski_snapshot
    except MigracijskiSnapshotPacijenta.DoesNotExist:
        return None
    if snapshot.lijek_id != pacijent.lijek_id:
        return None
    from .therapy_protocol_identity import current_course_start
    start = current_course_start(pacijent)
    if start and snapshot.datum_posljednje_terapije < start:
        return None
    return snapshot.datum_posljednje_terapije


def _existing_appointments(pacijent, start_date, target_date):
    prefetched = getattr(pacijent, "_planning_appointments", None)
    if prefetched is None:
        prefetched = getattr(pacijent, "_workflow_appointments", None)
    if prefetched is not None:
        appointments = prefetched
    else:
        appointments = list(
            Termin.objects.filter(
                pacijent=pacijent,
                status__in=ACTIVE_APPOINTMENT_STATUSES,
                datum__gte=start_date,
                datum__lte=target_date,
            ).select_related("lijek").order_by("datum", "vrijeme", "id")
        )
    equivalent_ids = set(pacijent.lijek.equivalent_ids()) if pacijent.lijek_id else set()
    return [
        appointment
        for appointment in appointments
        if start_date <= appointment.datum <= target_date
        and (not equivalent_ids or appointment.lijek_id in equivalent_ids)
    ]


def _base_interval_for_application(pacijent, application_number, on=None) -> int:
    if on is not None:
        step = get_step_for_application_number(pacijent, application_number, on)
        if step and step.faza == TerapijskiKorakProtokola.FAZA_ODRZAVANJE:
            return int(step.interval_sedmica or pacijent.interval_sedmica or 8)
    interval = pacijent._sedmice_do_koraka_iz_prethodnog(application_number)
    if interval is None or interval <= 0:
        protocol = get_effective_protocol(pacijent)
        maintenance = protocol.korak_odrzavanja() if protocol else None
        interval = (
            maintenance.interval_sedmica
            if maintenance and maintenance.interval_sedmica
            else protocol.interval_odrzavanja_sedmica if protocol else None
        ) or pacijent.interval_sedmica or 8
    return int(interval)


def _interval_and_date(anchor, pacijent, application_number, changes):
    interval = _base_interval_for_application(pacijent, application_number, anchor)
    candidate = anchor + timedelta(weeks=interval)
    applicable = [change for change in changes if change.effective_from <= candidate]
    if applicable:
        change = applicable[-1]
        interval = int(change.interval_weeks)
        # Promjena ne smije retroaktivno proizvesti termin prije datuma od
        # kojeg je ljekar odredio novi režim.
        candidate = max(
            anchor + timedelta(weeks=interval),
            change.effective_from,
        )
    return interval, candidate


def _step_details(pacijent, application_number):
    explicit_quantity = getattr(pacijent, "kolicina_po_terapiji", None)
    from .individual_protocols import uses_prescribed_vial_quantity
    protocol = get_effective_protocol(pacijent)
    if protocol and (protocol.is_individual or uses_prescribed_vial_quantity(pacijent)):
        explicit_quantity = None
    step = get_step_for_application_number(pacijent, application_number)
    if step:
        return (
            Decimal(str(explicit_quantity or step.broj_jedinica or 0)),
            step.get_faza_display(),
        )
    protocol = get_effective_protocol(pacijent)
    quantity = Decimal(str(
        explicit_quantity
        or (protocol.doza_po_aplikaciji if protocol else 0)
    ))
    return quantity, "Održavanje"


def generate_future_therapies(
    pacijent,
    *,
    target_date=None,
    start_date=None,
    interval_changes=None,
):
    """Vrati buduće terapije pacijenta bez ikakvog upisa u bazu.

    Postojeći planirani ili odgođeni termin ima prednost nad izračunatim
    datumom. Nakon njega naredni interval počinje od stvarnog datuma termina.
    """

    start_date = start_date or timezone.localdate()
    target_date = target_date or (start_date + timedelta(days=DEFAULT_HORIZON_DAYS))
    if target_date < start_date:
        raise ValueError("Ciljni datum ne može biti prije početnog datuma.")
    if not pacijent.aktivan or not pacijent.lijek_id:
        return []
    from .home_therapy_evidence import home_evidence

    evidence = home_evidence(pacijent, today=start_date)
    if evidence and evidence.needs_review:
        return []
    active_pauses = getattr(pacijent, "_planning_pauses", None)
    if active_pauses is None:
        active_pauses = list(pacijent.pauze_terapije.filter(aktivna=True)[:1])
    if active_pauses:
        return []

    phased_configuration = phased_planning_configuration(pacijent)
    if phased_configuration is not None:
        return _generate_phased_future_therapies(
            pacijent,
            phased_configuration,
            start_date=start_date,
            target_date=target_date,
        )

    protocol = get_effective_protocol(pacijent)
    if not protocol:
        return []
    from .regimen_changes import changes_for, regimen_quantity
    dated_changes = [IntervalChange(change.vrijedi_od, int(change.promjena_rezima["interval_sedmica"]))
        for change in changes_for(pacijent) if "interval_sedmica" in change.promjena_rezima]
    changes = _normalise_interval_changes([*dated_changes, *(interval_changes or ())])
    appointments = _existing_appointments(pacijent, start_date, target_date)
    # Više aktivnih termina istog datuma ne smije proizvesti duplu terapiju.
    appointments_by_date = {}
    for appointment in appointments:
        appointments_by_date.setdefault(appointment.datum, appointment)
    # Ručno zakazan aktivni termin je stvaran klinički datum čak i kada više
    # ne odgovara trenutnim pravilima za automatsko zakazivanje. Pravila
    # dozvoljenih dana primjenjuju se samo na nove projekcije ispod.
    appointments = list(appointments_by_date.values())

    latest = _latest_actual_therapy(pacijent)
    application_number = _historical_application_count(pacijent) + 1
    anchor = latest.datum if latest else _migration_anchor(pacijent)
    if evidence:
        anchor = evidence.last_application
    if anchor:
        appointments = [appointment for appointment in appointments if appointment.datum > anchor]
    # Datum kreiranja pacijenta nije klinički datum. Bez stvarno primljene
    # terapije, migracijskog datuma ili aktivnog termina terapijski ciklus još
    # nije počeo i servis ne smije projektovati prvu terapiju od ``start_date``.
    if anchor is None and not appointments:
        return []
    anchor_reason = (
        "Procjena sistema prema izjavi pacijenta; nije evidentirana primjena."
        if evidence else
        "Posljednja stvarno primljena terapija je polazna tačka."
        if latest
        else "Migracijski snapshot posljednje terapije je polazna tačka."
        if anchor
        else "Prvi zakazani termin je polazna tačka terapijskog ciklusa."
    )
    results = []
    appointment_index = 0

    while len(results) < 1000:
        existing = appointments[appointment_index] if appointment_index < len(appointments) else None
        if existing:
            therapy_date = existing.datum
            interval = (
                max((therapy_date - anchor).days // 7, 1)
                if anchor
                else _base_interval_for_application(pacijent, application_number)
            )
            reason = (
                "Odgođeni termin je autoritativni datum i nova polazna tačka."
                if existing.status == Termin.STATUS_ODGODJENA
                else "Već zakazani termin ima prednost nad projekcijom."
            )
            appointment_index += 1
        elif anchor is None:
            therapy_date = start_date
            interval = _base_interval_for_application(pacijent, application_number)
            reason = anchor_reason
        else:
            interval, therapy_date = _interval_and_date(
                anchor, pacijent, application_number, changes
            )
            reason = (
                "Datum je izračunat iz prethodne terapije i promjene intervala."
                if any(change.effective_from <= therapy_date for change in changes)
                else f"Datum je izračunat iz prethodne terapije u intervalu od {interval} sedmica."
            )

        # Kućna terapija je kontinuirani protokolarni režim koji pacijent
        # primjenjuje kod kuće; njene projekcijske datume ne pomjeramo na
        # ambulantne radne dane. Time isti interval ostaje source of truth i
        # za home coverage projekciju i za timeline. Stvarni ručno zakazani
        # termin, ako postoji, i dalje ima prednost iz grane iznad.
        if existing is None and not pacijent.trenutni_korak_je_kucna_terapija():
            scheduled = adjust_to_allowed_therapy_date(
                therapy_date,
                lijek=pacijent.lijek,
                protokol=pacijent.aktivni_protokol(),
            )
            therapy_date = scheduled.datum
            if scheduled.prilagodjen:
                reason = f"{reason} {scheduled.razlog}"

        if therapy_date > target_date:
            break
        if therapy_date < start_date:
            anchor = therapy_date
            application_number += 1
            continue

        quantity, phase = _step_details(pacijent, application_number)
        if (
            existing is not None
            and existing.kolicina_po_terapiji is not None
            and existing.kolicina_po_terapiji > 0
        ):
            quantity = Decimal(str(existing.kolicina_po_terapiji))
        quantity = regimen_quantity(pacijent, therapy_date, quantity)
        if existing is not None:
            from .appointment_plan import appointment_plan
            existing.pacijent = pacijent
            dated_plan = appointment_plan(existing)
            # An unresolved exception must not understate procurement needs.
            quantity = max(dated_plan['quantity'], dated_plan['regimen_quantity']) if dated_plan['conflict'] else dated_plan['quantity']
        results.append(FutureTherapy(
            pacijent=pacijent,
            lijek=pacijent.lijek,
            datum_terapije=therapy_date,
            kolicina_lijeka=quantity,
            vrsta_protokola=protocol.source,
            interval_sedmica=interval,
            termin_postoji=existing is not None,
            razlog_izracuna=reason,
            termin_id=existing.id if existing else None,
            faza_terapije=phase,
        ))
        anchor = therapy_date
        application_number += 1

    return results


def is_new_patient_before_first_therapy(pacijent):
    """Pacijent bez kliničkog sidra kojem terapijski ciklus još nije počeo."""

    from .home_therapy_evidence import home_evidence

    if home_evidence(pacijent) is not None:
        return False
    if _latest_actual_therapy(pacijent) is not None:
        return False
    if _migration_anchor(pacijent) is not None:
        return False
    appointments = getattr(pacijent, "_planning_appointments", None)
    if appointments is None:
        appointments = getattr(pacijent, "_workflow_appointments", None)
    if appointments is not None:
        return not bool(appointments)
    return not Termin.objects.filter(
        pacijent=pacijent,
        status__in=ACTIVE_APPOINTMENT_STATUSES,
    ).exists()


def generate_new_patient_relative_projection(
    pacijent,
    *,
    start_date=None,
    target_date=None,
):
    """Read-only potreba od relativnog dana 0, bez kreiranja termina.

    Datumi služe isključivo za ograničenje planskog horizonta. Pozivaoci ih ne
    smiju predstavljati kao zakazane terapije.
    """

    start_date = start_date or timezone.localdate()
    target_date = target_date or (start_date + timedelta(days=DEFAULT_HORIZON_DAYS))
    if not is_new_patient_before_first_therapy(pacijent):
        return []
    phased_configuration = phased_planning_configuration(pacijent)
    if phased_configuration is not None:
        if (
            not phased_configuration.planning_possible
            or not phased_configuration.relative_initial_projection
        ):
            return []
        return [FutureTherapy(
            pacijent=pacijent,
            lijek=phased_configuration.medicine,
            datum_terapije=start_date,
            kolicina_lijeka=phased_configuration.units,
            vrsta_protokola=(
                f"fazni:{phased_configuration.state.protokol_kljuc}"
            ),
            interval_sedmica=0,
            termin_postoji=False,
            razlog_izracuna=(
                "Relativna početna projekcija iz ljekarski propisane IV doze; "
                "datum prve terapije još nije zakazan."
            ),
            faza_terapije=phased_configuration.phase_label,
        )]
    protocol = get_effective_protocol(pacijent)
    if not protocol:
        return []

    results = []
    explicit_quantity = getattr(pacijent, "kolicina_po_terapiji", None)
    induction = sorted(
        protocol.indukcijski_koraci(),
        key=lambda step: (
            step.sedmica_od_pocetka if step.sedmica_od_pocetka is not None else 0,
            step.redoslijed,
        ),
    )
    for step in induction:
        week = int(step.sedmica_od_pocetka or 0)
        projected_date = start_date + timedelta(weeks=week)
        if projected_date > target_date:
            continue
        results.append(FutureTherapy(
            pacijent=pacijent,
            lijek=pacijent.lijek,
            datum_terapije=projected_date,
            kolicina_lijeka=Decimal(str(
                explicit_quantity or step.broj_jedinica or 0
            )),
            vrsta_protokola=protocol.source,
            interval_sedmica=0 if week == 0 else week,
            termin_postoji=False,
            razlog_izracuna=(
                f"Relativna indukcijska projekcija: sedmica {week} od budućeg dana 0."
            ),
            faza_terapije="Indukcija",
        ))

    maintenance = protocol.korak_odrzavanja()
    if maintenance and maintenance.interval_sedmica:
        interval = int(maintenance.interval_sedmica)
        first_week = maintenance.sedmica_od_pocetka
        if first_week is None:
            first_week = (
                int(induction[-1].sedmica_od_pocetka or 0) + interval
                if induction else 0
            )
        week = int(first_week)
        while start_date + timedelta(weeks=week) <= target_date:
            projected_date = start_date + timedelta(weeks=week)
            if not any(item.datum_terapije == projected_date for item in results):
                results.append(FutureTherapy(
                    pacijent=pacijent,
                    lijek=pacijent.lijek,
                    datum_terapije=projected_date,
                    kolicina_lijeka=Decimal(str(
                        explicit_quantity or maintenance.broj_jedinica or 0
                    )),
                    vrsta_protokola=protocol.source,
                    interval_sedmica=interval,
                    termin_postoji=False,
                    razlog_izracuna=(
                        f"Relativna projekcija održavanja: sedmica {week} "
                        "od budućeg dana 0."
                    ),
                    faza_terapije="Održavanje",
                ))
            week += interval

    return sorted(results, key=lambda item: item.datum_terapije)


def active_patients_for_planning():
    """QuerySet pripremljen za grupno planiranje bez N+1 upita."""

    from .models import KucnaTerapijaPodatak, KucnoIzdavanje, BrzaIzmjenaPacijenta, TerapijaStatusHistorija, PromjenaTerapije
    return Pacijent.objects.filter(aktivan=True, lijek__isnull=False).select_related(
        "lijek",
        "lijek__terapijski_program",
        "terapijski_program",
        "lijek__logisticke_postavke",
        "terapijski_protokol",
        "individualni_protokol",
        "individualni_protokol__standardni_protokol",
        "migracijski_snapshot",
        "fazni_protokol",
        "fazni_protokol__terapijski_program",
        "fazni_protokol__trenutna_faza",
        "fazni_protokol__iv_lijek",
        "fazni_protokol__sc_lijek",
        "fazni_protokol__pocetni_komisijski_zahtjev",
    ).prefetch_related(
        Prefetch('promjene_terapije', queryset=PromjenaTerapije.objects.order_by('-datum_pocetka_nove_terapije', '-pk'), to_attr='_workflow_course_changes'),
        Prefetch('brze_izmjene', queryset=BrzaIzmjenaPacijenta.objects.filter(
            vrsta__in=['interval', 'dose']).order_by('vrijedi_od', 'kreirano', 'pk'),
            to_attr='_workflow_regimen_changes'),
        Prefetch('podaci_kucne_terapije',
            queryset=KucnaTerapijaPodatak.objects.order_by('-kreirano', '-pk'),
            to_attr='_workflow_home_records'),
        Prefetch('kucna_izdavanja',
            queryset=KucnoIzdavanje.objects.exclude(terapija__workflow_status='PONISTENA')
                .select_related('terapija', 'lijek').order_by('-datum', '-pk'),
            to_attr='_workflow_home_issues'),
        Prefetch('terapija_set',
            queryset=Terapija.objects.exclude(workflow_status='PONISTENA').order_by('-datum', '-pk'),
            to_attr='_workflow_therapies'),
        Prefetch(
            "terapijski_protokol__koraci",
            queryset=TerapijskiKorakProtokola.objects.filter(aktivan=True).order_by(
                "faza", "redoslijed", "sedmica_od_pocetka", "id"
            ),
            to_attr="_workflow_steps",
        ),
        Prefetch(
            "individualni_protokol__koraci",
            queryset=IndividualniKorakProtokola.objects.order_by(
                "faza", "redoslijed", "sedmica_od_pocetka", "id"
            ),
            to_attr="_workflow_steps",
        ),
        Prefetch(
            "terapija_set",
            queryset=actually_administered_therapy_query(
                Terapija.objects.all()
            ).order_by("-datum", "-id"),
            to_attr="_planning_therapies",
        ),
        Prefetch(
            "termin_set",
            queryset=Termin.objects.filter(status__in=ACTIVE_APPOINTMENT_STATUSES).select_related(
                "lijek"
            ).prefetch_related(Prefetch('historija_statusa',
                queryset=TerapijaStatusHistorija.objects.filter(
                    novo_stanje__plan_source__isnull=False).order_by('-pk'),
                to_attr='_workflow_plan_decisions')).order_by("datum", "vrijeme", "id"),
            to_attr="_planning_appointments",
        ),
        Prefetch(
            "pauze_terapije",
            queryset=PauzaTerapije.objects.filter(aktivna=True),
            to_attr="_planning_pauses",
        ),
        Prefetch(
            "potrebe_fizickog_pokrica",
            queryset=PotrebaFizickogPokrica.objects.filter(
                status=PotrebaFizickogPokrica.STATUS_CEKA,
                preostala_kolicina__gt=0,
            ),
            to_attr="_workflow_physical_needs",
        ),
        Prefetch(
            "komisija_set",
            queryset=Komisija.objects.filter(
                status__in=Komisija.VAZECI_STATUSI,
                preostale_doze__gt=0,
            ).order_by("datum_odobrenja", "id"),
            to_attr="_workflow_commissions",
        ),
        Prefetch(
            "pacijentzaduzenje_set",
            queryset=PacijentZaduzenje.objects.filter(
                aktivno=True,
                preostalo__gt=0,
            ).select_related("komisija").order_by("id"),
            to_attr="_workflow_assignments",
        ),
        Prefetch(
            "rezervacije_lijeka",
            queryset=PacijentRezervacija.objects.filter(
                aktivno=True,
                kolicina__gt=0,
            ).select_related("komisija", "trebovanje").order_by(
                "datum_rezervacije", "id"
            ),
            to_attr="_workflow_reservations",
        ),
        Prefetch(
            "trebovanje_set",
            queryset=Trebovanje.objects.filter(
                status__in=(
                    "U_PRIPREMI",
                    "PREDATO",
                    "ODOBRENO",
                    "ZAPRIMLJENO",
                    "ODBIJENO",
                )
            ).select_related(
                "komisijski_ciklus",
                "komisija",
            ).order_by("datum_kreiranja", "id"),
            to_attr="_workflow_requests",
        ),
        Prefetch(
            "komisijski_zahtjevi_faza1",
            queryset=KomisijskiZahtjev.objects.select_related(
                "komisijski_ciklus",
                "saglasnost",
            ).prefetch_related("stavke_lijeka").order_by("-pk"),
            to_attr="_planning_phase2_requests",
        ),
    )


def generate_for_active_patients(
    *, target_date=None, start_date=None, interval_changes_by_patient=None
):
    """Grupno generiši projekcije za sve aktivne pacijente."""

    changes_by_patient = interval_changes_by_patient or {}
    projections = []
    for pacijent in active_patients_for_planning():
        projections.extend(generate_future_therapies(
            pacijent,
            target_date=target_date,
            start_date=start_date,
            interval_changes=changes_by_patient.get(pacijent.pk),
        ))
    return projections
