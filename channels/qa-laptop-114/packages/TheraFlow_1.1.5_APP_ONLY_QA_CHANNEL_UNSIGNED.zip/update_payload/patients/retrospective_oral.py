"""Historical UI adapter to the ordinary oral dispensing business service."""
from decimal import Decimal
from uuid import uuid4

from django.db import transaction
from django.utils import timezone

from . import models as m
from .data_corrections import captured_rows, differences, require, serial


def normalize(raw):
    from .retrospective_events import amount, chosen, day
    from .oral_regimen_dates import regimen_is_confirmed, regimen_on
    patient = chosen(m.Pacijent, raw.get('patient_id'), 'pacijenta')
    medicine = chosen(m.Lijek, raw.get('medicine_id'), 'oralnu prezentaciju')
    when = day(raw.get('event_date'))
    require(when <= timezone.localdate(), 'Datum stvarnog izdavanja ne može biti u budućnosti.')
    require(medicine.oralna_terapija and medicine.farmaceutski_oblik == m.Lijek.OBLIK_TABLETA,
            'Odaberite oralnu prezentaciju u tabletama.')
    quantity = amount(raw.get('quantity'))
    require(quantity == quantity.to_integral_value(), 'Unesite cijeli broj tableta.')
    note = str(raw.get('note', '')).strip()
    require(5 <= len(note) <= 2000, 'Navedite razlog i izvor naknadnog unosa (5–2000 znakova).')
    from .late_event_sources import event_patient
    historical = event_patient(patient, medicine)
    regimen = regimen_on(historical, when)
    require(regimen_is_confirmed(regimen),
            'Nema potvrđenog oralnog režima za odabrani lijek na stvarni datum izdavanja. Provjerite nalog ljekara.')
    source = raw.get('approval_source') or (f"komisija:{raw['commission_id']}" if raw.get('commission_id') else '')
    require(source, 'Odaberite postojeće odobrenje za oralno izdavanje.')
    batch = str(raw.get('batch', '')).strip()
    expiry = day(raw.get('expires'), optional=True)
    require(len(batch) <= 100, 'Serija može imati najviše 100 znakova.')
    require(not expiry or batch and expiry >= when, 'Rok serije ne smije prethoditi stvarnom izdavanju.')
    return dict(kind='home', oral_backend=True, patient_id=patient.pk, medicine_id=medicine.pk,
                event_date=str(when), quantity=str(quantity), actual_route='PO', note=note,
                regimen_id=regimen.pk, approval_source=source, batch=batch, expires=str(expiry or ''))


def guard_duplicate(data):
    require(not m.IzdavanjeOralneTerapije.objects.filter(pacijent_id=data['patient_id'],
        lijek_id=data['medicine_id'], datum_izdavanja=data['event_date'],
        kolicina_tableta=Decimal(data['quantity']), status=m.IzdavanjeOralneTerapije.STATUS_AKTIVNO).exists(),
        'Ovo oralno izdavanje već je evidentirano. Pregledajte historiju prije novog unosa.')


def dispense(data, user, operation):
    from .oral_therapy import issue_oral_therapy
    from .retrospective_events import day
    return issue_oral_therapy(patient=m.Pacijent.objects.get(pk=data['patient_id']),
        regimen=m.OralniTerapijskiRezim.objects.get(pk=data['regimen_id']),
        approval_source=data['approval_source'], quantity=Decimal(data['quantity']),
        issued_on=day(data['event_date']), idempotency_key=operation, batch=data['batch'],
        expires_on=day(data['expires'], optional=True), note=data['note'], early_issue_reason=data['note'],
        user=user, retrospective=True)[0]


def balances(data):
    from .nurse_corrections import amounts
    from .oral_therapy import _resolve_approval_locked
    patient = m.Pacijent.objects.get(pk=data['patient_id'])
    medicine = m.Lijek.objects.get(pk=data['medicine_id'])
    result = amounts(patient, medicine)
    result['approval'] = _resolve_approval_locked(source=data['approval_source'], patient=patient,
                                                medicine=medicine)['remaining']
    return result


def preview(raw, user):
    from .retrospective_events import authorize, day
    from .late_event_sources import protected_future_rows
    authorize(user)
    data = normalize(raw)
    guard_duplicate(data)
    patient = m.Pacijent.objects.get(pk=data['patient_id'])
    medicine = m.Lijek.objects.get(pk=data['medicine_id'])
    # Execute the very same business service in a rollback-only savepoint.
    # This checks approvals, stock and reservations without duplicating rules.
    with transaction.atomic():
        before = balances(data)
        with transaction.atomic():
            issue = dispense(data, user, uuid4())
            from .nurse_corrections import amounts
            after = amounts(patient, medicine)
            after['approval'] = before['approval'] - issue.kolicina_tableta
            transaction.set_rollback(True)
    protected = protected_future_rows(patient, day(data['event_date']))
    rows = [dict(label=label, before=str(before[key]), after=str(after[key]), unit='tableta')
            for label, key in [('Fizička zaliha', 'physical'), ('Zaduženje pacijenta', 'patient'),
                               ('Komisijsko pravo', 'approval')]]
    rows.extend(protected)
    rows.insert(0, dict(label='Historijsko oralno izdavanje', before='Nije evidentirano',
        after=f'{medicine} · Oralno · {data["quantity"]} tableta · {day(data["event_date"]):%d.%m.%Y.}'))
    return serial(dict(data=data, kind='home', title='Kućna terapija je izdata', patient=str(patient),
        medicine=str(medicine), event_date=data['event_date'], quantity=data['quantity'], unit='tableta',
        rows=rows, warnings=[], oral_effect=dict(before=before, after=after), protected_reservations=protected))


@transaction.atomic
def apply(plan, user, operation, backup):
    from .retrospective_events import authorize, day
    from .utils import upisi_log
    authorize(user)
    data = normalize(plan['data'])
    guard_duplicate(data)
    before = captured_rows()
    issue = dispense(data, user, operation)
    old, new = differences(before, captured_rows())
    event = m.RetrospectiveEvent.objects.create(operation_id=operation, kind='home',
        event_date=day(data['event_date']), user=user, patient=issue.pacijent, medicine=issue.lijek,
        quantity=issue.kolicina_tableta, note=data['note'], backup=backup,
        effects=serial(dict(preview=plan, before=old, after=new, oral_issue_id=issue.pk,
            actual_route='PO', approval_source=data['approval_source'], regimen_id=issue.rezim_id)))
    event.movements.set(m.ZalihaTransakcija.objects.filter(operation_id=operation,
        referenca_tip='IzdavanjeOralneTerapije', referenca_id=issue.pk))
    upisi_log(user, 'Naknadna evidencija', pacijent=issue.pacijent, objekat=event,
        opis=f"Stvarno izdavanje {data['event_date']}; {issue.lijek}; PO; {issue.kolicina_tableta} tableta. "
             f"Učinak: redovno oralno izdavanje; {plan['oral_effect']}. Razlog: {data['note']}")
    return event
