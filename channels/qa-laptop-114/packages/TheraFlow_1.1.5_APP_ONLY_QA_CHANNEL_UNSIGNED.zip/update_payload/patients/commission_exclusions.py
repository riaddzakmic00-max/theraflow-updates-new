"""Manual opt-out of one dated regular commission; no clinical side effects."""
from datetime import date
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Exists, OuterRef
from django.utils import timezone

from .models import KomisijskiCiklus, KomisijskoIskljucenje, KomisijskiRucniUnos, Pacijent


def planning_commission_date(row):
    window = row.get("planirati_za_komisiju") or row.get("preporuceni_komisijski_ciklus")
    return getattr(window, "datum_komisije", None) or row.get("naredna_administrativna_komisija")


def visible_commission_requests(queryset):
    """Same predicate for request lists, totals and printable documents.

    Only dated regular commissions match. An extraordinary request or a
    different commission never inherits the decision.
    """
    decisions = KomisijskoIskljucenje.objects.filter(
        pacijent_id=OuterRef("pacijent_id"),
        datum_komisije=OuterRef("komisijski_ciklus__datum_komisije"),
        iskljucen=True,
    )
    return queryset.alias(_manually_excluded=Exists(decisions)).exclude(
        _manually_excluded=True,
        komisijski_ciklus__tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI,
    )


def ensure_commission_inclusion(patient, cycle):
    if (cycle and cycle.tip_ciklusa == KomisijskiCiklus.TIP_REDOVNI
            and KomisijskoIskljucenje.objects.filter(
                pacijent=patient, datum_komisije=cycle.datum_komisije, iskljucen=True,
            ).exists()):
        raise ValidationError(
            f"{patient}: Ne trebuje se — ručno za komisiju {cycle.datum_komisije:%d/%m/%Y}. "
            "Prvo odaberite Uključi u trebovanje."
        )


def apply_manual_commission_exclusions(rows):
    decisions = {
        (item.pacijent_id, item.datum_komisije): item
        for item in KomisijskoIskljucenje.objects.filter(
            pacijent_id__in=[row['pacijent'].pk for row in rows], iskljucen=True,
        ).select_related('korisnik')
    }
    for row in rows:
        day = planning_commission_date(row)
        decision = decisions.get((row['pacijent'].pk, day))
        row.update(datum_rucne_odluke_komisije=day, rucno_iskljucen=bool(decision),
                   komisijsko_iskljucenje=decision)
        if not decision:
            continue
        row.update(
            ukljucen_u_nacrt=False, included_in_draft=False,
            ljekar_trazi=Decimal('0'), final_procurement_units=Decimal('0'),
            za_novu_komisiju=Decimal('0'), kolicina_za_komisiju=Decimal('0'),
            nova_komisija_potrebna=False, komisijska_akcija_aktivna=False,
            kategorija='ukljuciti', za_pregled=False,
            status_oznaka='Ne trebuje se — ručno',
        )
    return rows


@transaction.atomic
def save_commission_exclusion(*, patient, selected_date, excluded, reason='', user=None):
    from .commission_planning import commission_planning_row_for_patient
    from .utils import upisi_log
    from .models import KomisijskiZahtjev, Trebovanje

    # Serialize two decisions for the same patient, including first insertion.
    patient = Pacijent.objects.select_for_update().get(pk=patient.pk)
    if not patient.aktivan:
        raise ValidationError('Ručna odluka je dostupna samo za aktivnog pacijenta.')
    if excluded and not reason.strip():
        raise ValidationError('Unesite razlog odluke da se lijek ne trebuje za ovu komisiju.')
    row = commission_planning_row_for_patient(patient)
    try:
        day = date.fromisoformat(str(selected_date))
    except ValueError as exc:
        raise ValidationError('Nedostaje ispravan datum odabrane komisije. Osvježite pripremu.') from exc
    if not row or planning_commission_date(row) != day:
        raise ValidationError('Planirana komisija se promijenila. Osvježite pripremu i odaberite odgovarajući ciklus.')

    cycles = KomisijskiCiklus.objects.filter(datum_komisije=day, tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI)
    scope = dict(pacijent=patient, komisijski_ciklus__in=cycles)
    if (KomisijskiZahtjev.objects.filter(**scope).exclude(status__in=['nacrt', 'potvrdjen']).exists()
            or Trebovanje.objects.filter(**scope).exclude(status__in=['U_PRIPREMI', 'NACRT', 'SPREMAN', 'OTKAZANO']).exists()
            or cycles.exclude(status__in=['SIMULACIJA', 'nacrt', 'spremno_za_stampu', 'odstampano']).filter(
                zahtjevi_faza1__pacijent=patient).exists()):
        raise ValidationError('Za ovu komisiju zahtjev je već poslan ili obrađen. Ručna odluka je dostupna u pripremi nove komisije.')
    previous_record = KomisijskoIskljucenje.objects.filter(pacijent=patient, datum_komisije=day).first()
    previous = ({'iskljucen': previous_record.iskljucen, 'razlog': previous_record.razlog}
                if previous_record else None)
    record, created = KomisijskoIskljucenje.objects.get_or_create(
        pacijent=patient, datum_komisije=day,
        defaults={'iskljucen': excluded, 'razlog': reason.strip(), 'korisnik': user},
    )
    if not created and record.iskljucen == excluded:
        return record  # Repeated POST preserves original actor/time.
    if not created:
        record.iskljucen = excluded
        record.razlog = reason.strip()
        record.korisnik = user
        record.izmijenjeno = timezone.now()
        record.save(update_fields=['iskljucen', 'razlog', 'korisnik', 'izmijenjeno'])
    if not excluded:
        KomisijskiRucniUnos.objects.filter(
            pacijent=patient, lijek=patient.lijek, aktivan_nacrt=True,
        ).update(aktivan_nacrt=False)
        fresh = commission_planning_row_for_patient(patient)
        if fresh.get("home_evidence") and fresh["home_evidence"].needs_review:
            upisi_log(user, 'Uključen u trebovanje', pacijent=patient, objekat=record,
                      opis=f'Komisija {day:%d/%m/%Y}. Potrebna provjera kućne terapije; postojeće količine nacrta su sačuvane.')
            return record
        quantity = fresh['sistem_predlaze']
        # Refresh only this commission's editable single-presentation drafts.
        # Multi-presentation requests still go through the normal review.
        for draft in KomisijskiZahtjev.objects.select_for_update().filter(**scope, status__in=['nacrt', 'potvrdjen']):
            if draft.vrsta_zahtjeva == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_ODJAVA:
                continue
            items = list(draft.stavke_lijeka.all())
            if len(items) == 1 and items[0].lijek_id == patient.lijek_id:
                draft.sistem_predlozio = draft.ljekar_trazi = draft.finalna_kolicina = quantity
                draft.print_snapshot = {}
                draft.print_snapshot_at = None
                draft.save(update_fields=['sistem_predlozio', 'ljekar_trazi', 'finalna_kolicina', 'print_snapshot', 'print_snapshot_at'])
                items[0].kolicina = quantity
                items[0].save(update_fields=['kolicina'])
        Trebovanje.objects.filter(**scope, lijek=patient.lijek,
            status__in=['U_PRIPREMI', 'NACRT', 'SPREMAN']).update(
                broj_doza=quantity, sistemski_prijedlog=quantity)
        KomisijskiRucniUnos.objects.filter(pacijent=patient, lijek=patient.lijek,
            komisijski_ciklus__in=cycles).update(
                rucni_override=False, sistemski_prijedlog=quantity, ljekar_trazi=quantity)
    upisi_log(user, 'Ne trebuje se — ručno' if excluded else 'Uključen u trebovanje',
              pacijent=patient, objekat=record,
              opis=f'Komisija {day:%d/%m/%Y}. Prije: {previous}; poslije: '
                   f'iskljucen={record.iskljucen}, razlog={record.razlog or "Vraćeno u automatski prijedlog"}.')
    return record
