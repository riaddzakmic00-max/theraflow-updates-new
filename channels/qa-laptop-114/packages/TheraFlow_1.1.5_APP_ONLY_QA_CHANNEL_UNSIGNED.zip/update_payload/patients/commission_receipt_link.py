"""Administrative provenance for an already posted receipt, never receiving.

The existing receipt.request FK is the link and PatientDataCorrection is its
audit. No commission receiving/allocation hook is called by this module.
"""
from uuid import uuid4
from datetime import date

from django.core import signing
from django.db import connection, transaction
from django.db.models import Sum

from . import models as m
from .activity_review import read_projection
from .correction_center import authorize
from .data_corrections import CorrectionBlocked, digest, require, serial
from .request_cache import begin_request_cache, end_request_cache
from dashboard.permissions import korisnik_uloga

SALT = 'theraflow.administrative-receipt-link.v1'
STALE = 'Podaci su promijenjeni nakon pregleda. Ponovo pokrenite provjeru.'


def candidates(receipt):
    """Exact presentation only; chronology and capacity are evidence, not proof.

    An existing distribution restricts the patient. Lack of a distribution
    must not invent a recipient; the user still selects the request explicitly.
    """
    from .commission_exclusions import visible_commission_requests
    from .inventory_corrections import receipt_quantity
    if receipt_quantity(receipt.movement) != receipt.quantity:
        return dict(items=[], incomplete=False, warning='Izvorni prijem ima ispravku količine. '
            'Najprije provjerite izvornu transakciju i njen audit; komisijska količina se ne pretpostavlja.')
    qs = visible_commission_requests(m.Trebovanje.objects.filter(
        lijek_id=receipt.medicine_id, odobrene_doze__gte=receipt.quantity,
        status__in=('ODOBRENO', 'DJELOMICNO_ODOBRENO', 'CEKA_ISPORUKU', 'ZAPRIMLJENO'),
    ))
    patients = set(m.EvidencijaSaglasnostiZaprimanja.objects.filter(
        fizicka_transakcija_id=receipt.movement_id).values_list('pacijent_id', flat=True))
    if receipt.movement.pacijent_id:
        patients.add(receipt.movement.pacijent_id)
    if patients:
        qs = qs.filter(pacijent_id__in=patients)
    result = []
    # A bounded display never silently treats its first row as unique.
    requests = list(qs.select_related('pacijent', 'lijek', 'komisija', 'komisijski_ciklus')
                    .annotate(linked_quantity=Sum('unlinkedstockreceipt__quantity'))
                    .order_by('-komisijski_ciklus__godina', '-komisijski_ciklus__mjesec', '-pk')[:201])
    for request in requests:
        approval = request.komisija
        cycle = request.komisijski_ciklus
        if receipt.backup.get('approval_conflicts'):
            # The physical-only exception did not settle this discrepancy.
            # Linking its source must wait for an independently valid decision.
            from .receipt_approval import request_receipt_approval
            basis = request_receipt_approval(request)
            if (basis.get('blocked') or not basis.get('approval_date')
                    or date.fromisoformat(basis['approval_date']) > receipt.event_date):
                continue
        if approval and (approval.lijek_id != receipt.medicine_id or
                         approval.pacijent_id != request.pacijent_id or
                         approval.datum_odobrenja > receipt.event_date):
            continue
        if cycle and cycle.datum_odobrenja and cycle.datum_odobrenja > receipt.event_date:
            continue
        if cycle and not approval and not cycle.datum_odobrenja and (cycle.godina, cycle.mjesec) > (receipt.event_date.year, receipt.event_date.month):
            continue
        from .commission_receiving import received_commission_quantity
        received = received_commission_quantity(request) if request.linked_quantity else request.zaprimljene_doze
        remaining = request.odobrene_doze - received
        if remaining < receipt.quantity:
            continue
        result.append(dict(request=request, remaining=remaining,
            agreement=approval.broj_saglasnosti if approval else '',
            warning='Nema povezanog odobrenja; veza ne stvara komisijsko pravo.' if not approval else '',
            cycle=cycle, quantity_match=remaining == receipt.quantity))
    return dict(items=result[:200], incomplete=len(requests) > 200, warning='')


def context(receipt_id):
    return m.UnlinkedStockReceipt.objects.select_related('medicine', 'movement', 'request').get(pk=receipt_id)


def snapshot(receipt, request):
    """Only the provenance and its evidence, no global 59-table snapshot."""
    def values(qs):
        return list(qs.order_by('pk').values())
    return serial(dict(
        receipt=values(m.UnlinkedStockReceipt.objects.filter(pk=receipt.pk)),
        request=values(m.Trebovanje.objects.filter(pk=request.pk)),
        movement=values(m.ZalihaTransakcija.objects.filter(pk=receipt.movement_id)),
        distributions=values(m.EvidencijaSaglasnostiZaprimanja.objects.filter(fizicka_transakcija_id=receipt.movement_id)),
        links=values(m.UnlinkedStockReceipt.objects.filter(request=request)),
        approval=values(m.Komisija.objects.filter(pk=request.komisija_id)),
        cycle=values(m.KomisijskiCiklus.objects.filter(pk=request.komisijski_ciklus_id)),
        medicine=values(m.Lijek.objects.filter(pk=receipt.medicine_id)),
    ))


def session_context(session_id, user, receipt):
    if not session_id:
        return None
    session = m.ReconciliationSession.objects.get(pk=session_id)
    require(session.user_id == user.pk, 'Proces pripada drugom korisniku.')
    require(session.status not in ('cancelled', 'aligned', 'completed'), 'Proces je završen; otvorite novi postupak.')
    require(not session.medicine_id or receipt.medicine_id in session.medicine.equivalent_ids(),
            'Prijem nije dio odabranog lijeka u procesu.')
    require(session.period_start <= receipt.event_date <= session.period_end, 'Prijem nije dio perioda procesa.')
    return session


def preview(receipt_id, request_id, reason, user, *, session_id=None):
    authorize(user)
    reason = str(reason).strip()
    require(5 <= len(reason) <= 500, 'Unesite razlog povezivanja (5–500 znakova).')
    with read_projection():
        receipt = context(receipt_id)
        require(receipt.request_id is None, 'Ovaj prijem već ima komisijsku vezu; povezivanje se ne ponavlja.')
        match = next((item for item in candidates(receipt)['items'] if item['request'].pk == int(request_id)), None)
        require(match is not None, 'Odabrana stavka nije odgovarajući kandidat. Pregledajte prijem i komisijsko odobrenje.')
        request = match['request']
        session = session_context(session_id, user, receipt)
        require(not session or not session.patient_id or session.patient_id == request.pacijent_id,
                'Stavka pripada drugom pacijentu procesa.')
        plan = serial(dict(title='Poveži sa komisijom', receipt_id=receipt.pk,
            request_id=request.pk, medicine=str(receipt.medicine), patient=str(request.pacijent),
            patient_id=request.pacijent_id, event_date=receipt.event_date, quantity=receipt.quantity,
            cycle=str(request.komisijski_ciklus or 'Nije evidentiran'), reason=reason,
            rows=[dict(label=label, before='bez promjene', after='bez promjene') for label in
                  ('Fizičko stanje', 'Komisijsko pravo', 'Pacijentovo zaduženje')],
            warnings=['Dodaje se samo komisijska veza.',
                'Komisijska zaprimljena količina i status zahtjeva ostaju sačuvani. Veza ne potvrđuje raspodjelu pacijentu.'],
            source='commission_receipt_link', session_id=session_id))
        token = signing.dumps(dict(operation=str(uuid4()), user=user.pk, receipt=receipt.pk,
            request=request.pk, reason=reason, session=session_id,
            fingerprint=digest(snapshot(receipt, request))), salt=SALT, compress=True)
        return plan, token


def confirm(token, user, *, receipt_id):
    authorize(user)
    try:
        payload = signing.loads(token, salt=SALT)
    except signing.BadSignature:
        raise CorrectionBlocked('Pregled nije važeći. Ponovite povezivanje.') from None
    require(payload['user'] == user.pk and payload['receipt'] == receipt_id, 'Potvrda ne pripada ovom prijemu i korisniku.')
    cache = begin_request_cache(enabled=False)
    try:
        with transaction.atomic():
            if connection.vendor == 'postgresql':
                with connection.cursor() as cursor:
                    cursor.execute("SET LOCAL lock_timeout = '5s'")
                    # Acquire the same compatible locks these INSERT/UPDATEs
                    # would take anyway, BEFORE row locks. Legacy corrections
                    # guard tables in alphabetical order starting at the audit
                    # table; late lock promotion could otherwise deadlock with
                    # one of those corrections updating this receipt's source.
                    writes = [m.AktivnostLog, m.PatientDataCorrection, m.UnlinkedStockReceipt]
                    if payload['session']:
                        writes += [m.ReconciliationAction, m.ReconciliationSession]
                    cursor.execute('LOCK TABLE ' + ', '.join(connection.ops.quote_name(model._meta.db_table)
                        for model in sorted(writes, key=lambda model: model._meta.db_table)) + ' IN ROW EXCLUSIVE MODE')
            # Match ordinary receiving's cycle -> request order. PK-only queries
            # avoid DISTINCT/outer joins; FK parents use NO KEY UPDATE so audits
            # and unrelated deliveries need not lock their shared patient row.
            request = m.Trebovanje.objects.filter(pk=payload['request']).first()
            require(request is not None, STALE)
            if request.komisijski_ciklus_id:
                m.KomisijskiCiklus.objects.select_for_update(no_key=True).get(pk=request.komisijski_ciklus_id)
            request = m.Trebovanje.objects.select_for_update(no_key=True).get(pk=request.pk)
            receipt = m.UnlinkedStockReceipt.objects.select_for_update().get(pk=receipt_id)
            existing = m.PatientDataCorrection.objects.filter(operation_id=payload['operation'], scope='commission_link').first()
            if existing:
                require(existing.korisnik_id == user.pk and existing.posljedice['receipt_id'] == receipt_id, STALE)
                return existing, False
            try:
                signing.loads(token, salt=SALT, max_age=1800)
            except signing.BadSignature:
                raise CorrectionBlocked('Pregled je istekao. Ponovite povezivanje.') from None
            m.ZalihaTransakcija.objects.select_for_update(no_key=True).get(pk=receipt.movement_id)
            if request.komisija_id:
                m.Komisija.objects.select_for_update(no_key=True).get(pk=request.komisija_id)
            require(receipt.request_id is None and digest(snapshot(receipt, request)) == payload['fingerprint'], STALE)
            session = session_context(payload['session'], user, receipt)
            if session:
                session = m.ReconciliationSession.objects.select_for_update(no_key=True).get(pk=session.pk)
                require(not session.patient_id or session.patient_id == request.pacijent_id, 'Stavka pripada drugom pacijentu procesa.')
            require(any(i['request'].pk == request.pk for i in candidates(context(receipt_id))['items']), STALE)
            before = dict(receipt_id=receipt.pk, request_id=None, status='Komisijska veza nije pronađena')
            m.UnlinkedStockReceipt.objects.filter(pk=receipt.pk).update(request_id=request.pk)
            after = dict(receipt_id=receipt.pk, request_id=request.pk, status='Komisijska veza potvrđena')
            receipt_audit = m.PatientDataCorrection.objects.create(operation_id=payload['operation'],
                pacijent_id=request.pacijent_id, korisnik=user, scope='commission_link',
                razlog=payload['reason'],
                izvorna_transakcija_id=receipt.movement_id, prije=before, poslije=after,
                posljedice=dict(title='Naknadna komisijska veza', decision='Komisijska veza potvrđena',
                    medicine=str(receipt.medicine), patient=str(request.pacijent), reason=payload['reason'],
                    receipt_id=receipt.pk, request_id=request.pk,
                    event_date=str(receipt.event_date),
                    medicine_id=receipt.medicine_id, actor_role=korisnik_uloga(user), source='commission_receipt_link', session_id=payload['session'],
                    rows=[dict(label='Komisijska veza', before='Nije pronađena', after=f'Stavka #{request.pk}')],
                    unchanged=['Fizičko stanje', 'Komisijsko pravo', 'Pacijentovo zaduženje']))
            if session:
                m.ReconciliationAction.objects.create(operation_id=payload['operation'], session=session,
                    user=user, decision='commission_link', request=request, data_correction=receipt_audit,
                    summary=receipt_audit.posljedice)
                session.revision += 1
                session.save(update_fields=['revision', 'updated_at'])
            from .utils import upisi_log
            upisi_log(user, 'Naknadno povezivanje prijema sa komisijom', pacijent=request.pacijent,
                objekat=receipt_audit, opis=f'Prijem #{receipt.pk} → komisijska stavka #{request.pk}. '
                f'{payload["reason"]} Fizičko stanje, pravo i zaduženje: bez promjene.')
            return receipt_audit, True
    finally:
        end_request_cache(cache)
