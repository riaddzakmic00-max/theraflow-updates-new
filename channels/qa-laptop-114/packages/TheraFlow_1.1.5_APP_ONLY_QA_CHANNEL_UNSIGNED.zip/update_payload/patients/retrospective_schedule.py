"""Chronological next-date policy; never rewrite an existing appointment."""
from datetime import timedelta
from django.utils import timezone
from . import models as m
from .individual_protocols import get_interval_weeks
from .scheduling import adjust_to_allowed_therapy_date
from .therapy_history import actually_administered_therapy_query


def application_number_at(patient, day):
    return actually_administered_therapy_query(m.Terapija.objects.filter(
        pacijent=patient,lijek_id__in=patient.lijek.equivalent_ids(),datum__lt=day)).count()+1


def next_date_plan(patient, event_date, *, exclude_appointment=None):
    last = actually_administered_therapy_query(m.Terapija.objects.filter(
        pacijent=patient, lijek_id__in=patient.lijek.equivalent_ids())).order_by('-datum', '-pk').first()
    reference = max(event_date, last.datum) if last else event_date
    actual = actually_administered_therapy_query(m.Terapija.objects.filter(
        pacijent=patient,lijek_id__in=patient.lijek.equivalent_ids(),datum__lte=reference))
    # Count the proposed entry once both before and after its insertion.
    ordinal = actual.count() + (0 if actual.filter(datum=event_date).exists() else 1)
    interval = get_interval_weeks(patient, reference, after_application=True,
                                  application_number=ordinal) or patient.interval_sedmica
    if not interval:
        raise ValueError('Nedostaje potvrđen interval za izračun sljedeće terapije.')
    due = adjust_to_allowed_therapy_date(reference+timedelta(weeks=interval),
        lijek=patient.lijek, protokol=patient.aktivni_protokol()).datum
    appointments = list(m.Termin.objects.filter(pacijent=patient,
        status__in=[m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA], datum__gt=reference)
        .exclude(pk=exclude_appointment).order_by('datum', 'vrijeme', 'pk'))
    warnings = []
    if appointments:
        warnings.append('Već postoje zakazani termini: '+', '.join(x.datum.strftime('%d.%m.%Y.') for x in appointments)
                        +'. Ostaju sačuvani. Izračunati naredni datum je '+due.strftime('%d.%m.%Y.')+'.')
    if due < timezone.localdate():
        warnings.append('Izračunati naredni datum je u prošlosti. Nije izmišljena naredna primjena niti automatski zakazan prošli termin.')
    warnings.append('Naredni datum je prijedlog za zasebnu provjeru rasporeda; ovaj unos ne kreira niti pomjera buduće termine.')
    return {'reference':reference, 'due':due, 'interval':interval, 'warnings':warnings,
            'schedule':False, 'appointments':[x.pk for x in appointments]}
