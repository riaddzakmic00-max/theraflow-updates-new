# Pet TEST kartona za razvojnu dijagnostiku

Samo razvojni skup; terapijske vrijednosti nisu kliničke preporuke. Koristi
postojeći katalog i testne protokole. JMBG, adrese i telefoni su prazni.
Svi kartoni imaju TEST u imenu i oznake TEST-T01 do TEST-T05.

## Pokretanje i ponavljanje

`Start-SyntheticDevelopment.ps1` pokreće lokalni PostgreSQL na 127.0.0.1:55440
i Django na 127.0.0.1:8000. Ne mijenja podatke. Koristi razvojnu `.env`
ovog projekta; nije skripta za ambulantnu instalaciju.

```powershell
.\.venv\Scripts\python.exe manage.py seed_diagnostic_cases --database-name theraflow_synthetic_diagnostics
```

Običan ponovni poziv provjerava otisak i ne kreira nove redove. Ako je TEST
skup u međuvremenu korišten/promijenjen, komanda odbija prepisivanje. Za
namjerni povratak na početnih pet slučajeva:

```powershell
.\.venv\Scripts\python.exe manage.py seed_diagnostic_cases --database-name theraflow_synthetic_diagnostics --replace --backup-dir output/synthetic-reset-backups --received-on 2026-09-25
```

`--replace` pravi novu punu PostgreSQL kopiju i provjerava njen sadržaj
prije atomske zamjene. Ne prepisuje postojeće kopije. Novi/nepoznati modeli
ili vanjske FK veze prekidaju postupak. Nema `TRUNCATE CASCADE`, mijenjanja
PROTECT pravila, brisanja datoteka ili promjena kataloga/korisnika/postavki.
Čisti 39 operativnih patients tabela i Django admin dnevnik, koji može
zadržati imena prethodnih pacijenata. Korisnički računi i ovlasti ostaju isti.
Greška u kreiranju vraća sve operativne tabele. Originalna baza naziva
`theraflow`, produkcijske postavke, udaljeni hostovi i više DB aliasa su zabranjeni.

Komanda kreira četiri poznata nulta početna stanja praznog sintetičkog
skladišta, četiri fizička ulaza, četiri rezervacije i pet odobrenja/zahtjeva.
Svaki ulaz ima zasebnu vezu s pacijentom, ciklusom, evidencijom i rezervacijom.
T03 nema ulaz niti rezervaciju; T04 ima 4 od 8 odobrenih bočica.
Sva četiri fizička prijema početnog skupa datirana su 25.09.2026;
odluka komisije je 16.09.2026.

Zadnje navedene primjene su historijski TEST zapisi (`is_migration=True`),
bez izmišljenih ranijih prijema, izdavanja ili komisijskih potrošnji. Četiri
naredna termina su planovi. T05 ima oralni režim i nema termin. Faza i dnevni
režim T05 preuzeti su iz postojećeg standardnog testnog režima. Remsima
koristi 4 bočice iz protokola; nedostajuća doza u mg ostaje NULL.
Postojeći standardni oralni režim ima fazu INDUKCIJA; ista faza se prenosi
na karton, režim i testni komisijski zahtjev, bez izmjene kataloga.

Zbog tih granica dijagnostika može dati UNKNOWN uz ispravan fizički saldo.
Nulta brojka prijema T03 u kontrolisanoj specifikaciji nije dokaz otpremnice
za generički dijagnostički engine; on čuva nepoznat fizički prijem kada nema
izvornog zapisa. Pravila se ne prilagođavaju fixtureu.

## Izolovani testovi

`patients.test_synthetic_diagnostics` pokriva privatnost, identitet pet
kartona, izvor protokola, odsutni/djelimični prijem, zajednički lijek,
stvarni receipt POST/replay/rollback, kućno izdavanje, prijenos, nulto ručno
isključenje, zaštite resetovanja i read-only dijagnostiku. Izmijenjena i
neispravna stanja postoje samo u testnoj bazi. Dodatni postojeći receipt i
diagnostic provenance testovi provjeravaju stari ValidationError i nepotpunu
historiju. Kataloški fixture sadrži 38 zapisa bez pacijenata.

## Kopija i povratak na prethodni razvoj

Prvobitna baza **127.0.0.1:5432/theraflow nije obrisana niti izmijenjena**.
Aktiviran je zaseban server i baza jer nije bilo moguće dokazati da
zaštićena konfiguracija lokalne instalacije ne dijeli prvobitnu bazu.

Puna arhivska kopija:
`output/synthetic-diagnostics-20260925/before-synthetic.full.dump`.
Uspješno je obnovljena u novu izolovanu bazu prije čišćenja; svih 61
modelskih tabela podudara se s originalom. Dokazi, SHA-256, prethodna
razvojna `.env` i rezultati su u istom direktoriju. `.env` kopija sadrži
lokalne pristupne postavke; ne uključivati je u paket ili izvoz.

Za povratak prethodnom razvoju zaustaviti samo razvojni `manage.py runserver`
ovog projekta, vratiti sačuvani `development.env.before` na projektnu `.env`
i pokrenuti obični `manage.py runserver`. To ponovo bira sačuvanu bazu na
5432; nije potreban restore preko postojeće baze. Ako su kasnije mijenjane
druge `.env` postavke, vratiti samo pet DB ključeva iz sačuvane kopije.

Za nezavisnu provjeru/arhivski restore koristiti NOVO ime lokalne baze,
nikada prepisivanje originalne baze:

```powershell
& 'C:/Program Files/PostgreSQL/18/bin/createdb.exe' -h 127.0.0.1 -p 55440 -U theraflow_synthetic theraflow_archive_check
& 'C:/Program Files/PostgreSQL/18/bin/pg_restore.exe' -h 127.0.0.1 -p 55440 -U theraflow_synthetic --no-owner --no-acl --exit-on-error -d theraflow_archive_check output/synthetic-diagnostics-20260925/before-synthetic.full.dump
```

PostgreSQL na 55440 ima podatke u `.local/synthetic-diagnostics/postgres`.
Potrebno ga je pokrenuti navedenom razvojnom skriptom nakon restarta
računara. Nije instaliran Windows servis ili ambulantni paket.
