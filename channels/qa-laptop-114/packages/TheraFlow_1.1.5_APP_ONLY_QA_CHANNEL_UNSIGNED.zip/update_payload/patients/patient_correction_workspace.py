"""Patient context for the existing correction services; no second balance engine."""
from decimal import Decimal
from types import SimpleNamespace

from django.core import signing
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Sum, Q
from django.utils import timezone

from . import models as m, inventory_corrections as inventory, data_corrections as legacy
from . import physical_stock_corrections as physical, quick_changes as quick
from .data_corrections import require, CorrectionBlocked, serial

SALT = 'theraflow.patient-workspace.v1'
TYPES = {
    'patient_stock': 'Količina za ovog pacijenta u frižideru',
    'receipt': 'Pogrešno zaprimljena količina',
    'allocation': 'Pogrešna raspodjela — lijek je stvarno u ambulanti',
    'issue': 'Pogrešno evidentirano kućno izdavanje',
    'stock': 'Ukupna zaliha ambulante',
    'approval': 'Komisijsko odobrenje prema dokumentu',
    'transfer': 'Prijenos zaduženja drugom pacijentu',
    'therapy': 'Pogrešno evidentirana primjena — kontrolisano poništavanje',
    'oral_issue': 'Oralno izdavanje — kontrolisano poništavanje',
    'receipt_date': 'Datum zaprimanja',
    'return': 'Stvarni povrat pacijenta u karantin',
    'writeoff': 'Stvarni otpis / oštećenje u ambulanti',
    'profile': 'Lični podaci i dijagnoza',
    'regimen': 'Doza, interval i budući termini',
    'migration': 'Datumi početnog unosa',
    'home': 'Dokazano pogrešan početni unos kućne količine',
    'medicine': 'Pogrešno odabrana prezentacija u novom kartonu',
}
ADMIN_TYPES = {'patient_stock', 'stock', 'approval', 'therapy', 'oral_issue', 'return', 'writeoff',
               'profile', 'regimen', 'migration', 'home', 'medicine'}
LEGACY_TYPES = {'approval', 'therapy', 'oral_issue', 'profile', 'regimen', 'migration', 'home', 'medicine'}
INTENTS = {
    'mistake': 'Pogrešno sam unio podatak',
    'missing': 'Nisam evidentirao događaj',
    'count': 'Prebrojano stanje se razlikuje',
}


def supported_kinds(patient, medicine, user, intent='mistake'):
    """Offer existing services appropriate to this product, never a new ledger."""
    home = medicine.kucna_terapija and not medicine.oralna_terapija
    excluded = set()
    if not home:
        excluded.update({'home', 'issue', 'return'})
    if not medicine.oralna_terapija:
        excluded.add('oral_issue')
    if home or medicine.oralna_terapija:
        excluded.add('therapy')
    if intent == 'count':
        excluded.update(set(TYPES) - {'patient_stock', 'stock', 'writeoff'})
    elif intent == 'mistake':
        excluded.add('stock')
    result = []
    for key, label in TYPES.items():
        if key in excluded:
            continue
        try:
            authorize(user, key)
        except PermissionDenied:
            continue
        result.append((key, label))
    return result


def authorize(user, kind=None):
    if kind=='transfer':
        from dashboard.permissions import authorize_transfer
        authorize_transfer(user)
    from dashboard.permissions import je_admin, je_sestra_ili_admin, je_terapijski_tim
    allowed = je_admin(user) if kind in ADMIN_TYPES else (
        je_terapijski_tim(user) if kind in {None, 'transfer'} else je_sestra_ili_admin(user))
    if not (user.is_authenticated and user.is_active and allowed) or kind and kind not in TYPES:
        raise PermissionDenied('Za odabranu ispravku nemate odgovarajuće ovlaštenje.')


def medicines(patient):
    ids = {patient.lijek_id}
    for model in (m.Komisija, m.Terapija, m.PacijentRezervacija, m.PacijentZaduzenje,
                  m.KucnoIzdavanje, m.IzdavanjeOralneTerapije, m.Trebovanje):
        ids.update(model.objects.filter(pacijent=patient).values_list('lijek_id', flat=True))
    return list(m.Lijek.objects.filter(pk__in=ids).order_by('naziv', 'put_primjene', 'pk'))


def medicine_label(medicine):
    return ' · '.join(str(x) for x in (medicine.naziv, medicine.strength or medicine.jacina_mg,
        medicine.pharmaceutical_form, medicine.put_primjene or 'put primjene nije evidentiran', medicine.jedinice_zalihe[0]) if x)


def source_options(patient, medicine, kind):
    """IDs are values only. Users select actual dates, documents, lots and amounts."""
    unit = medicine.jedinice_zalihe[0]
    if kind in {'receipt', 'allocation', 'receipt_date'}:
        records = m.EvidencijaSaglasnostiZaprimanja.objects.filter(pacijent=patient,
            trebovanje__lijek=medicine).select_related('fizicka_transakcija', 'rezervacija', 'trebovanje').order_by('-pk')
        return [(r.pk, f"Prijem {inventory.receipt_date(r.fizicka_transakcija):%d.%m.%Y.} · "
            f"{inventory.allocation_quantity(r):g} {unit} za pacijenta · serija {r.fizicka_transakcija.serija or 'nije dokumentovana'} · "
            f"saglasnost {r.broj_saglasnosti_snapshot or 'nije navedena'}") for r in records if r.fizicka_transakcija_id]
    if kind in {'issue', 'return'}:
        if medicine.oralna_terapija:
            return []
        return [(i.pk, f"Predaja {i.datum:%d.%m.%Y.} · {i.efektivna_kolicina:g} {unit} · serija {i.serija or 'nije dokumentovana'}")
            for i in m.KucnoIzdavanje.objects.filter(pacijent=patient, lijek=medicine)
                .exclude(terapija__workflow_status='PONISTENA').order_by('-datum', '-pk')]
    if kind == 'transfer':
        return [(r.pk, f"Rezervisano {r.kolicina:g} {unit} · {r.datum_rezervacije:%d.%m.%Y.} · "
                    f"saglasnost {r.komisija.broj_saglasnosti if r.komisija else 'nije dokumentovana'}")
                for r in quick.transfer_sources(patient).filter(lijek=medicine).select_related('komisija')]
    if kind in {'approval', 'therapy', 'oral_issue'}:
        from dashboard.correction_forms import target_choices
        model = {'approval': m.Komisija, 'therapy': m.Terapija, 'oral_issue': m.IzdavanjeOralneTerapije}[kind]
        records = model.objects.filter(pacijent=patient, lijek=medicine)
        if kind == 'therapy':
            records = records.exclude(tip_evidencije=m.Terapija.TIP_KUCNA_TERAPIJA)
        ids = set(records.values_list('pk', flat=True))
        # Retain established selection semantics without asking users for model IDs.
        import re
        return [(pk, re.sub(r' · (?:odobrenje|radnja|izdavanje) #\d+', '', label))
                for pk, label in target_choices(patient, kind) if pk in ids]
    return []


def overview(patient, medicine):
    sumof = lambda query, field: query.aggregate(n=Sum(field))['n'] or Decimal(0)
    approvals = list(m.Komisija.objects.filter(pacijent=patient, lijek=medicine).exclude(
        status__in=['PONISTENA', 'ZAMIJENJENA']).order_by('-datum_odobrenja', '-pk'))
    claims = m.EvidencijaSaglasnostiZaprimanja.objects.filter(pacijent=patient,
        trebovanje__lijek=medicine).select_related('fizicka_transakcija', 'trebovanje')
    receipts = [{'id': c.pk, 'date': inventory.receipt_date(c.fizicka_transakcija) if c.fizicka_transakcija_id else None,
        'quantity': inventory.allocation_quantity(c), 'approval': c.broj_saglasnosti_snapshot,
        'source_known': bool(c.fizicka_transakcija_id and c.rezervacija_id)} for c in claims]
    reservations = sumof(m.PacijentRezervacija.objects.filter(pacijent=patient, lijek=medicine, aktivno=True), 'kolicina')
    assignments = m.PacijentZaduzenje.objects.filter(pacijent=patient, lijek=medicine)
    home_booked = sumof(assignments, 'preostalo') if assignments.exists() else None
    report = m.KucnaTerapijaPodatak.objects.filter(pacijent=patient, lijek=medicine,
        vrsta='IZJAVA').order_by('-datum_provjere', '-kreirano').first()
    issues = list(m.KucnoIzdavanje.objects.filter(pacijent=patient, lijek=medicine).exclude(
        terapija__workflow_status='PONISTENA').order_by('-datum', '-pk'))
    for issue in issues:
        issue.display_quantity = issue.efektivna_kolicina
    confirmed = m.Terapija.objects.filter(pacijent=patient, lijek=medicine,
        workflow_status='POTVRDJENA').exclude(tip_evidencije=m.Terapija.TIP_KUCNA_TERAPIJA).order_by('-datum', '-pk')
    oral = m.IzdavanjeOralneTerapije.objects.filter(pacijent=patient, lijek=medicine, status='AKTIVNO').order_by('-datum_izdavanja', '-pk')
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    return {'approvals': approvals, 'received': sum((r['quantity'] for r in receipts), Decimal(0)),
        'receipts': receipts, 'reserved': reservations, 'home_booked': home_booked, 'home_report': report,
        'issues': issues, 'applications': confirmed, 'oral_issues': oral,
        'stock': stock.u_frizideru if stock else None,
        'restricted': inventory.restricted_allocation_quantity([medicine.pk]),
        'scope': 'Evidentirana historija odabranog proizvoda; pojedinačna odobrenja prikazana su ispod.'}


def calculation_details(patient, medicine):
    """Explain the actual ledger inputs, not a second balance calculation."""
    from urllib.parse import urlencode
    from django.urls import reverse
    from .inventory import izracunaj_frizider_iz_transakcija, inventory_position_for_patient
    from .request_cache import begin_request_cache, end_request_cache
    cache = begin_request_cache(enabled=False)
    try:
        base_url = reverse('ispravi_podatke_pacijenta', args=[patient.pk])
        def link(kind, **params):
            return base_url+'?'+urlencode({'kind': kind, 'medicine': medicine.pk, **params})
        anchor = m.MigracijskoPocetnoStanjeZalihe.objects.filter(lijek=medicine).first()
        movements = m.ZalihaTransakcija.objects.filter(lijek=medicine).select_related('pacijent', 'korekcija')
        if anchor:
            movements = movements.filter(pk__gt=anchor.ledger_checkpoint_id or 0)
        physical = []
        for movement in movements.order_by('pk'):
            correction_url = None
            if movement.korekcija_id and movement.korekcija.pacijent_id == patient.pk:
                context = reversal_context(movement.korekcija, patient)
                if context:
                    correction_url = base_url+'?'+urlencode({k: v for k, v in {
                        **context, 'reverse_of': movement.korekcija_id}.items() if k != 'quantity'})
            elif movement.referenca_tip == 'PhysicalStockCorrection':
                correction_url = link('stock', previous_count=movement.referenca_id)
            elif movement.tip == 'ZAPRIMANJE':
                claim = movement.raspodjele_prijema.filter(pacijent=patient).first()
                if claim:
                    correction_url = link('receipt', source=claim.pk)
            elif movement.pacijent_id == patient.pk:
                kind = {'Terapija': 'therapy', 'KucnoIzdavanje': 'issue',
                        'IzdavanjeOralneTerapije': 'oral_issue'}.get(movement.referenca_tip)
                if kind:
                    correction_url = link(kind, source=movement.referenca_id)
            physical.append({'id': movement.pk, 'date': inventory.receipt_date(movement),
                'label': movement.get_tip_display(), 'patient': movement.pacijent,
                'delta': movement.frizider_delta(), 'reservation_delta': movement.promjena_rezervacije,
                'url': correction_url, 'reason': movement.napomena})
        reservations = []
        for item in m.PacijentRezervacija.objects.filter(pacijent=patient, lijek=medicine, aktivno=True).select_related('komisija'):
            claim = item.izvori_prijema.first()
            audit = m.PatientDataCorrection.objects.filter(pacijent=patient,
                scope='inventory_patient_stock', prometi__rezervacija=item).order_by('-pk').first()
            context = reversal_context(audit, patient) if audit else None
            url = (base_url+'?'+urlencode({k: v for k, v in {**context, 'reverse_of': audit.pk}.items() if k != 'quantity'})) if context else (
                link('allocation', source=claim.pk) if claim else None)
            reservations.append({'record': item, 'url': url})
        scheduled = m.Termin.objects.filter(pacijent=patient, lijek=medicine,
            datum__gte=timezone.localdate(), status__in=[m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA]).order_by('datum', 'vrijeme')
        position = inventory_position_for_patient(m.Pacijent.objects.get(pk=patient.pk))
        return {'anchor': anchor, 'physical': physical,
            'ledger_total': izracunaj_frizider_iz_transakcija(medicine),
            'reservations': reservations, 'position': position,
            'scheduled': scheduled,
            'future_need': sum((x.kolicina_po_terapiji or Decimal(0) for x in scheduled), Decimal(0)),
            'assignments': m.PacijentZaduzenje.objects.filter(pacijent=patient, lijek=medicine),
            'show_home': medicine.kucna_terapija or medicine.oralna_terapija}
    finally:
        end_request_cache(cache)


def verify_saved(patient, medicine, receipt, backend):
    """Fresh read after commit: report a mismatch without replaying a correction."""
    from .inventory import (izracunaj_frizider_iz_transakcija, inventory_position_for_patient,
                            patient_reservation_breakdown, _physical_medicine_ids)
    from .request_cache import begin_request_cache, end_request_cache
    cache = begin_request_cache(enabled=False)
    try:
        patient = m.Pacijent.objects.get(pk=patient.pk)
        medicine = m.Lijek.objects.get(pk=medicine.pk)
        stock = m.Zaliha.objects.filter(lijek=medicine).first()
        ledger = izracunaj_frizider_iz_transakcija(medicine)
        reservations = m.PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True)
        total_reserved = reservations.aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
        own = reservations.filter(pacijent=patient).aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
        warnings = []
        if stock is None or ledger != stock.u_frizideru:
            warnings.append('Ukupna fizička zaliha ne odgovara zbiru kontrolnog salda i prometa. Potrebna je provjera izvora.')
        if stock and stock.u_frizideru < total_reserved:
            warnings.append(f'Stvarni manjak: zaliha {stock.u_frizideru:g}, rezervisano {total_reserved:g}. Prava i rezervacije nisu automatski umanjeni.')
        position = inventory_position_for_patient(patient)
        current = patient.trenutni_proizvod
        if current:
            # The card can aggregate compatible products. Compare the same scope,
            # not total clinic stock, approval rights or a different SKU's balance.
            breakdown = patient_reservation_breakdown(patient, medicine_ids=_physical_medicine_ids(current))
            if position['reserved_in_fridge'] != breakdown['total_effective']:
                warnings.append('Prikaz pacijentove količine odstupa od povezanih aktivnih rezervacija. Potrebna je provjera prikaza.')
            if any(x['exclusion_reason'] for x in breakdown['items']):
                warnings.append('Dio fizičke rezervacije nema važeću komisijsku osnovu. Fizička količina je sačuvana; pravo treba provjeriti zasebno.')
        return {'warnings': warnings, 'stock': stock.u_frizideru if stock else None,
            'ledger': ledger, 'reserved': own, 'card_reserved': position['reserved_in_fridge'],
            'operation_id': str(receipt.operation_id), 'checked_at': timezone.now()}
    finally:
        end_request_cache(cache)


def reversal_context(receipt, patient):
    """A reversal is a new source correction, never a restore of old DB rows."""
    plan = receipt.posljedice
    if receipt.pacijent_id != patient.pk or not isinstance(plan, dict):
        return None
    if receipt.scope in LEGACY_TYPES - {'therapy', 'oral_issue'} and plan.get('medicine_id'):
        return {'kind': receipt.scope, 'source': plan.get('target_id'),
                'medicine': plan['medicine_id'], 'quantity': None}
    kind = receipt.scope.removeprefix('inventory_')
    if kind == 'patient_stock':
        return {'kind': kind, 'medicine': plan.get('medicine_id'), 'quantity': plan.get('before')}
    if kind not in {'receipt', 'allocation', 'issue', 'receipt_date'}:
        return None
    source, quantity = plan.get('target_id'), plan.get('before')
    if kind in {'receipt', 'receipt_date'}:
        claims = m.EvidencijaSaglasnostiZaprimanja.objects.filter(pacijent=patient, fizicka_transakcija_id=source)
        if claims.count() != 1:
            return None
        claim = claims.first()
        source = claim.pk
        if kind == 'receipt':
            allocation = next((a for a in plan.get('allocations', []) if a['claim_id'] == claim.pk), None)
            if allocation is None:
                return None
            quantity = allocation['quantity_before']
    return {'kind': kind, 'source': source, 'medicine': plan.get('medicine_id'), 'quantity': quantity}


@transaction.atomic
def build_plan(patient, medicine, kind, target_id, form, user, *, reverse_of=None, previous_count=None, previous_transfer=None):
    authorize(user, kind)
    fingerprint = legacy.digest(legacy.captured_rows())
    require(medicine.pk in {x.pk for x in medicines(patient)}, 'Prezentacija ne pripada ovom kartonu.')
    options = source_options(patient, medicine, kind)
    if kind in {'receipt', 'allocation', 'issue', 'receipt_date', 'return', 'approval', 'therapy', 'oral_issue', 'transfer'}:
        require(target_id in {pk for pk, _ in options}, 'Odaberite konkretan događaj iz ovog kartona. Izvor drugog pacijenta nije dozvoljen.')
    data = form.cleaned_data
    if reverse_of:
        previous = m.PatientDataCorrection.objects.filter(pk=reverse_of, pacijent=patient).first()
        context = reversal_context(previous, patient) if previous else None
        require(context and (context['kind'], context.get('source'), context['medicine']) == (kind, target_id, medicine.pk),
                'Povrat ne pripada odabranom izvoru i kartonu. Ponovo odaberite ispravku iz historije.')
        require(not previous.naknadne_ispravke.exists(),
                'Ova korekcija je već ispravljena. Otvorite posljednju povezanu korekciju u historiji.')
    target = target_id
    if kind == 'patient_stock':
        require(medicine.pk == patient.lijek_id, 'Odaberite aktivnu prezentaciju pacijenta; različiti oblici nisu zamjenjivi.')
        target = patient.pk
        plan, inner = inventory.make_preview(kind, target, {**data, 'medicine_id': medicine.pk,
            'context_patient_id': patient.pk, 'event_date': timezone.localdate(), 'reverse_of': reverse_of}, user)
        backend = 'inventory'
    elif kind in {'receipt', 'allocation', 'receipt_date'}:
        claim = m.EvidencijaSaglasnostiZaprimanja.objects.get(pk=target_id)
        tx = claim.fizicka_transakcija
        service_data = {'quantity': data.get('quantity'), 'reason': data['reason'],
            'event_date': data.get('event_date') or inventory.receipt_date(tx), 'context_patient_id': patient.pk,
            'reverse_of': reverse_of}
        if kind != 'allocation':
            target = tx.pk
            if kind == 'receipt':
                quantities = {str(c.pk): data.get('allocation_'+str(c.pk), inventory.allocation_quantity(c))
                    for c in tx.raspodjele_prijema.all()}
                quantities[str(claim.pk)] = data['quantity']
                service_data.update(allocations=quantities, quantity=sum(quantities.values(), Decimal(0)))
                if data.get('duplicate_id'):
                    other = m.EvidencijaSaglasnostiZaprimanja.objects.get(pk=data['duplicate_id'], pacijent=patient)
                    service_data.update(duplicate_id=other.fizicka_transakcija_id,
                                        duplicate_confirmed=data.get('duplicate_confirmed'))
        plan, inner = inventory.make_preview(kind, target, service_data, user)
        backend = 'inventory'
    elif kind in {'issue', 'return', 'writeoff'}:
        target = medicine.pk if kind == 'writeoff' else target_id
        obj, _ = inventory.target_context(kind, target)
        service_data = {**data, 'event_date': data.get('event_date') or getattr(obj, 'datum', timezone.localdate()),
                        'context_patient_id': patient.pk, 'reverse_of': reverse_of}
        if kind == 'return':
            service_data['batch'] = obj.serija
        plan, inner = inventory.make_preview(kind, target, service_data, user)
        backend = 'inventory'
    elif kind == 'stock':
        cleaned = {'lijek': medicine, 'kolicina': data['quantity'], 'razlog': data['reason'],
            'datum_dogadjaja': data['event_date'], 'obuhvat': 'LOT' if data.get('lot') else 'TOTAL',
            'razlog_kod': data['cause'], 'previous_correction_id': previous_count}
        if data.get('lot'):
            import json
            from datetime import date
            batch, expiry = json.loads(data['lot'])
            cleaned.update(serija=batch, rok_trajanja=date.fromisoformat(expiry) if expiry else None)
        plan, inner = physical.make_preview_token(SimpleNamespace(cleaned_data=cleaned), user)
        plan.update(rows=[{'label': 'Prebrojana fizička količina', 'before': plan['before'], 'after': plan['after']},
            {'label': 'Zajednička zaliha ambulante', 'before': plan['total_before'], 'after': plan['total_after']},
            {'label': 'Ukupno rezervisano — svi pacijenti', 'before': plan['reserved'], 'after': plan['reserved']}],
            impacts=['Odobrena prava, rezervacije, izdavanja i primjene ostaju sačuvani.'],
            status='Postoji manjak' if plan['warnings'] else 'Spremno za potvrdu')
        backend = 'physical'
    elif kind == 'transfer':
        require(medicine.pk == patient.lijek_id, 'Prijenos ranije terapije nije podržan; ne mijenjajte aktivnu terapiju radi prijenosa.')
        plan, inner = quick.make_preview(patient, 'transfer', {
            'rezervacija': target_id, 'primalac': data['recipient'].pk, 'kolicina': str(data['quantity']),
            'razlog': data['reason'], 'komisija_primaoca': data.get('recipient_approval') or None,
            'previous_transfer': previous_transfer}, user)
        backend = 'quick'
    else:
        if kind in {'regimen', 'migration', 'home', 'medicine'}:
            require(medicine.pk == patient.lijek_id, 'Ova ispravka pripada aktivnoj terapiji. Odaberite aktivnu prezentaciju unutar ovog ekrana; historijska terapija se ne prepisuje.')
        if kind in {'therapy', 'oral_issue'}:
            require(data.get('not_occurred') is True,
                'Potvrdite da je događaj pogrešno evidentiran i nije stvarno izvršen. Stvarno primijenjen lijek ne vraća se poništavanjem.')
        plan, inner = legacy.make_preview_token(patient, kind, form, user, target_id=target_id)
        backend = 'legacy'
    plan.setdefault('warnings', [])
    plan.setdefault('status', 'Spremno za potvrdu')
    plan.update(title=TYPES[kind], unit=medicine.jedinice_zalihe[0])
    # Optional dependent values are consistency assertions, NEVER extra ledger actions.
    expected = data.get('expected_stock')
    if expected is not None:
        rows = [r for r in plan['rows'] if r['label'] in {'Fizički raspoloživo u ambulanti', 'Zajednička zaliha ambulante', 'Ukupna fizička zaliha ambulante'}]
        require(rows and Decimal(str(rows[-1]['after'])) == expected,
                'Unesen cilj ukupne zalihe ne odgovara izračunatoj posljedici. Odaberite da li je pogrešan prijem, raspodjela ili fizičko brojanje; ništa nije sačuvano.')
    # Keep technical identities in signed state; visible rows speak in patient terms.
    import re
    for row in plan['rows']:
        row['label'] = re.sub(r' #\d+', '', row['label'])
    state = {'patient': patient.pk, 'medicine': medicine.pk, 'kind': kind, 'backend': backend,
             'target': target, 'user': user.pk, 'inner': inner, 'reverse_of': reverse_of,
             'event_date': str(data.get('event_date') or data.get('datum_odobrenja') or timezone.localdate())}
    require(fingerprint == legacy.digest(legacy.captured_rows()),
            'Podaci su se promijenili tokom povezivanja izvora. Ponovite pregled u kartonu.')
    return plan, signing.dumps(state, salt=SALT, compress=True)


@transaction.atomic
def confirm(token, patient, user):
    try:
        payload = signing.loads(token, salt=SALT)
    except signing.BadSignature:
        raise CorrectionBlocked('Pregled nije važeći. Ponovo pregledajte podatke u kartonu.') from None
    authorize(user, payload['kind'])
    require(payload['patient'] == patient.pk and payload['user'] == user.pk,
            'Potvrda ne pripada ovom kartonu ili korisniku.')
    if payload['backend'] == 'inventory':
        receipt, created = inventory.confirm(payload['inner'], user, kind=payload['kind'], target_id=payload['target'])
    elif payload['backend'] == 'physical':
        receipt, created = physical.apply_signed_correction(payload['inner'], user)
    elif payload['backend'] == 'quick':
        receipt, created = quick.confirm(payload['inner'], patient, user)
    else:
        receipt, created = legacy.apply_signed_correction(payload['inner'], patient, user)
    if created and payload['backend'] == 'legacy':
        receipt.posljedice.update(medicine_id=payload['medicine'], target_id=payload['target'],
            event_date=payload['event_date'])
        receipt.ponistava_id = payload.get('reverse_of')
        receipt.datum_dogadjaja = payload['event_date']
        receipt.save(update_fields=['posljedice', 'ponistava', 'datum_dogadjaja'])
    done = signing.dumps({'patient': patient.pk, 'medicine': payload['medicine'],
        'kind': payload['kind'], 'backend': payload['backend'], 'receipt': receipt.pk}, salt=SALT+'.saved', compress=True)
    return receipt, created, done


def audit_plan(receipt, backend):
    """Display/print only the saved audit, without replaying a correction."""
    raw = getattr(receipt, 'pregled', {}) if backend == 'physical' else (
        receipt.poslije if backend == 'quick' else receipt.posljedice)
    plan = serial(raw) if isinstance(raw, dict) else {}
    if backend == 'physical':
        plan['rows'] = [{'label':'Fizička količina odabrane serije / obuhvata',
            'before':str(receipt.prethodna_kolicina), 'after':str(receipt.nova_kolicina)},
            {'label':'Zajednička zaliha ambulante','before':plan.get('total_before'), 'after':plan.get('total_after')}]
    import re
    for row in plan.get('rows', []):
        row['label'] = re.sub(r' #\d+', '', row['label'])
    plan.setdefault('impacts', [])
    plan.setdefault('warnings', [])
    return plan
