"""Reviewed date/time changes; appointment and allocation identities are retained.

The nurse coordinator holds correction_transaction during analysis and commit.
Its table locks serialize capacity checks with ordinary appointment writers;
its signed snapshot, receipt and rollback cover this adapter and its audit.
"""
from copy import copy
from datetime import date, time, timedelta
from decimal import Decimal
from urllib.parse import urlencode

from django.urls import reverse
from django.db import transaction
from django.utils import timezone

from . import models as m
from .data_corrections import require, serial
from .scheduling import is_allowed_therapy_date
from .therapy_history import actually_administered_therapy_query

OCCUPIED = (m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_POTVRDJENA)
SCOPES = [('one', 'Pomjeri samo ovaj termin'),
          ('following', 'Pomjeri ovaj i preračunaj naredne termine')]


def scheduled(patient):
    return m.Termin.objects.filter(pacijent=patient, status=m.Termin.STATUS_PLANIRANA,
        datum__gte=timezone.localdate()).select_related('lijek', 'pacijent').order_by('datum', 'vrijeme', 'pk')


def appointment_for(patient, identity):
    appointment = scheduled(patient).filter(pk=identity).first()
    require(appointment is not None, 'Odaberite postojeći današnji ili budući zakazani termin ovog pacijenta.')
    require(not actual(appointment).exists(), 'Za ovaj termin postoji provedena terapija. Otvorite historiju; provedena terapija se ne pomjera.')
    return appointment


def actual(appointment):
    return actually_administered_therapy_query(m.Terapija.objects.filter(pacijent_id=appointment.pacijent_id,
        lijek_id__in=appointment.lijek.equivalent_ids(), datum=appointment.datum))


def context(appointment, *, when=None, ordinal=None):
    """Only a matching documented protocol may supply a clinical interval.

    An old presentation may still be moved, but today's different protocol must
    not be used to recalculate it. Ustekinumab's explicit IV/SC pair is separate.
    """
    from .individual_protocols import get_effective_protocol, get_interval_weeks
    from .regimen_changes import regimen_override
    patient, medicine = appointment.pacijent, appointment.lijek
    when = when or appointment.datum
    phase = patient.aktivni_fazni_protokol()
    if phase and medicine.pk in (phase.iv_lijek_id, phase.sc_lijek_id):
        scoped = copy(patient)
        scoped.lijek = medicine
        weeks = 8 if medicine.pk == phase.iv_lijek_id else int(
            regimen_override(scoped, when).get('interval_sedmica', phase.interval_odrzavanja_sedmica))
        return dict(interval=weeks, protocol=None, source='Dokumentovani IV/SC fazni protokol', phase=phase)
    if patient.lijek_id != medicine.pk:
        return dict(interval=None, protocol=None, source='Termin druge prezentacije — potrebna provjera naloga', phase=None)
    protocol = get_effective_protocol(patient, when)
    if not protocol or protocol.warning:
        return dict(interval=None, protocol=None, source='Nedostaje jednoznačan terapijski protokol', phase=None)
    weeks = get_interval_weeks(patient, when, after_application=True, application_number=ordinal)
    return dict(interval=int(weeks) if weeks else None, protocol=protocol.source_object,
                source='Dokumentovani terapijski protokol / važeći interval', phase=None)


def occupied(when, excluded):
    return m.Termin.objects.filter(datum=when, status__in=OCCUPIED).exclude(pk__in=excluded)


def _day_occupancy(appointment, when, excluded, proposed):
    from .calendar_capacity import calendar_occupancy
    booked_by_date, actual_by_date = calendar_occupancy(when, when, excluded=excluded)
    booked = list(booked_by_date.get(when, ()))
    booked += [dict(pacijent_id=appointment.pacijent_id, vrijeme=time.fromisoformat(p['new_time']))
               for p in proposed if p['new_date'] == str(when)]
    actual_patients = actual_by_date.get(when, set())
    return booked, actual_patients


def _daily_capacity_issues(appointment, booked, actual_patients):
    issues = []
    patients = {r['pacijent_id'] for r in booked}
    patients.update(actual_patients)
    if any(r['pacijent_id'] == appointment.pacijent_id for r in booked):
        issues.append('Pacijent već ima drugi aktivni termin na ovaj datum.')
    if appointment.pacijent_id in actual_patients:
        issues.append('Pacijent na ovaj datum već ima provedenu terapiju.')
    return issues, len(patients | {appointment.pacijent_id})


def daily_capacity_issues(appointment, when, *, excluded=(), proposed=()):
    """Blocking patient/day duplicates and prospective distinct-patient count.

    The configured usual daily capacity is advisory, never a booking limit.
    Mutations must hold the patient row lock before checking duplicates.
    """
    return _daily_capacity_issues(appointment, *_day_occupancy(appointment, when, excluded, proposed))


def daily_capacity_warning(appointment, when, *, excluded=(), proposed=()):
    from .calendar_capacity import capacity_warning
    _, count = daily_capacity_issues(appointment, when, excluded=excluded, proposed=proposed)
    return capacity_warning(count, when=when)


def slot_issues(appointment, when, clock, *, excluded=(), proposed=(), protocol=None):
    issues = []
    if when < timezone.localdate():
        issues.append('Novi aktivni termin ne može biti u prošlosti.')
    if not is_allowed_therapy_date(when, lijek=appointment.lijek, protokol=protocol):
        issues.append('Subota/nedjelja nisu dozvoljene.' if when.weekday() >= 5 else 'Datum nije dozvoljeni terapijski dan za ovaj protokol.')
    booked, actual_patients = _day_occupancy(appointment, when, excluded, proposed)
    capacity_issues, count = _daily_capacity_issues(appointment, booked, actual_patients)
    issues.extend(capacity_issues)
    if any(r['vrijeme'] == clock for r in booked):
        issues.append('Vrijeme se preklapa s drugim terminom. Odaberite slobodno vrijeme.')
    return issues, count


def order_compatible(appointment, when):
    from .appointment_plan import appointment_plan
    if appointment.lijek_id != appointment.pacijent.lijek_id:
        return True
    probe = copy(appointment)
    probe.datum = when
    old, new = appointment_plan(appointment, fresh=True), appointment_plan(probe, fresh=True)
    return all(old[k] == new[k] for k in ('quantity', 'dose_mg', 'conflict'))


def first_slot(appointment, start, clock, *, excluded=(), proposed=(), protocol=None, before=None, after=None, avoid=None):
    start = max(start, timezone.localdate())
    clocks = list(dict.fromkeys([clock, time(8), time(9), time(10), time(11), time(12), time(13), time(14)]))
    for offset in range(366):
        candidate = start + timedelta(days=offset)
        if before and candidate >= before:
            break
        if not is_allowed_therapy_date(candidate, lijek=appointment.lijek, protokol=protocol):
            continue
        if not order_compatible(appointment, candidate):
            continue
        for at in clocks:
            if (after and (candidate, at) <= after) or (candidate, at) == avoid:
                continue
            if not slot_issues(appointment, candidate, at, excluded=excluded, proposed=proposed, protocol=protocol)[0]:
                return dict(date=str(candidate), time=at.isoformat(timespec='minutes'))
    return None


def links(patient, medicine, identity, raw, slot=None):
    base = dict(cc_patient=patient.pk, cc_medicine=medicine.pk, appointment_id=identity)
    url = reverse('nurse_correction', args=['appointment'])
    def step(label, **values):
        return dict(label=label, url=url+'?'+urlencode(dict(base, **values)))
    actions = [step('Izaberi drugi slobodan termin')]
    if slot:
        actions.append(step('Prvi naredni odgovarajući termin · '+date.fromisoformat(slot['date']).strftime('%d.%m.%Y.')+' '+slot['time'],
                            new_date=slot['date'], new_time=slot['time'], move_scope=raw.get('move_scope', 'one')))
    actions.extend([step(label, move_scope=scope, **({k: raw[k] for k in ('new_date', 'new_time') if raw.get(k)}))
                    for scope, label in SCOPES])
    actions.append(dict(label='Odustani', url=reverse('correction_center')+'?'+urlencode(dict(cc_patient=patient.pk, section='corrections'))))
    return actions


def _row(appointment, when, clock, *, changed):
    reservations = list(m.PacijentRezervacija.objects.filter(termin=appointment).order_by('pk'))
    require(all(r.pacijent_id == appointment.pacijent_id and r.lijek_id == appointment.lijek_id for r in reservations),
            'Rezervacija ne odgovara pacijentu i prezentaciji termina. Potrebna je provjera veze prije pomjeranja.')
    return dict(id=appointment.pk, medicine_id=appointment.lijek_id, medicine=str(appointment.lijek),
        route=appointment.lijek.put_primjene, quantity=str(appointment.kolicina_po_terapiji or ''),
        old_date=str(appointment.datum), old_time=appointment.vrijeme.isoformat(timespec='minutes'),
        new_date=str(when), new_time=clock.isoformat(timespec='minutes'), changed=changed,
        reservation_ids=[r.pk for r in reservations], reservation_quantity=str(sum((r.kolicina for r in reservations if r.aktivno), Decimal(0))))


def coverage(patient, medicine, when, needed):
    from django.db.models import Sum
    from .inventory import inventory_position
    from .commission_service import patient_commission_coverage
    position = inventory_position(medicine, include_planned_need=False)
    rights = patient_commission_coverage(patient, medicine_ids=medicine.physical_equivalent_ids())['approved_remaining']
    dated = m.Komisija.objects.filter(pacijent=patient, lijek_id__in=medicine.physical_equivalent_ids(),
        status__in=m.Komisija.VAZECI_STATUSI, datum_odobrenja__lte=when).aggregate(n=Sum('preostale_doze'))['n'] or Decimal(0)
    return dict(physical=position['in_fridge'], rights=rights,
        physical_ok=needed > 0 and position['in_fridge'] >= needed and not position['physical_reservation_shortfall'],
        commission_ok=rights >= needed > 0 and dated >= needed)


def analyze(patient, medicine, raw):
    appointment = appointment_for(patient, raw['appointment_id'])
    require(appointment.lijek_id == medicine.pk, 'Odaberite prezentaciju zakazanog termina. Današnja terapija ne prepisuje termin.')
    when, clock = date.fromisoformat(str(raw['new_date'])), time.fromisoformat(str(raw['new_time']))
    scope = raw.get('move_scope')
    require(scope in dict(SCOPES), 'Odaberite način pomjeranja termina.')
    require(len(raw.get('note', '').strip()) >= 5, 'Unesite razlog pomjeranja (najmanje 5 znakova).')
    all_terms = list(scheduled(patient))
    key = lambda t: (t.datum, t.vrijeme, t.pk)
    following = [t for t in all_terms if key(t) > key(appointment)]
    earlier = [t for t in all_terms if key(t) < key(appointment)]
    # An existing duplicate booking is not evidence of another prescribed
    # application. A cascade must never turn it into a new future dose.
    seen, duplicate_booking = set(), False
    for term in [appointment, *following]:
        identity = (term.lijek_id, term.datum)
        duplicate_booking = duplicate_booking or identity in seen
        seen.add(identity)
    excluded = [appointment.pk] + ([t.pk for t in following] if scope == 'following' else [])
    base_ordinal = patient.broj_dosadasnjih_aplikacija() + len(earlier) + 1
    clinical = context(appointment, ordinal=base_ordinal)
    problems, count = slot_issues(appointment, when, clock, excluded=excluded, protocol=clinical['protocol'])
    if scope == 'following' and duplicate_booking:
        problems.append('Postoje mogući dupli termini iste prezentacije na isti dan. Preračun zahtijeva ručnu provjeru; pomjerite samo odabrani termin.')
    if (when, clock) == (appointment.datum, appointment.vrijeme):
        problems.append('Datum/vrijeme nisu promijenjeni.')
    if earlier and (when, clock) <= (earlier[-1].datum, earlier[-1].vrijeme):
        problems.append('Novi termin bi prethodio ranijem zakazanom terminu pacijenta.')
    if scope == 'one' and following and (when, clock) >= (following[0].datum, following[0].vrijeme):
        problems.append('Novi termin prelazi naredni termin. Izaberite raniji datum ili preračun narednih termina.')
    changes = [_row(appointment, when, clock, changed=True)]
    warnings = []
    previous_therapy = actually_administered_therapy_query(m.Terapija.objects.filter(pacijent=patient,
        lijek_id__in=medicine.equivalent_ids(), datum__lt=appointment.datum)).order_by('-datum', '-pk').first()
    anchor = earlier[-1].datum if earlier and earlier[-1].lijek_id == medicine.pk else previous_therapy.datum if previous_therapy else None
    expected = None
    if anchor and clinical['interval']:
        # Incoming induction intervals depend on the current ordinal, rather
        # than the maintenance interval after this application.
        from .individual_protocols import get_interval_weeks
        weeks = clinical['interval'] if clinical['phase'] else get_interval_weeks(patient, when, application_number=base_ordinal)
        expected = anchor + timedelta(weeks=weeks)
    phase = clinical['phase']
    if phase and medicine.pk == phase.sc_lijek_id and phase.faza == phase.FAZA_CEKA_PRVU_SC and phase.datum_iv_primjene:
        expected = phase.datum_iv_primjene + timedelta(weeks=8)
    interval_ok = bool(expected and when == expected)
    interval_label = ('odgovara' if interval_ok else 'odstupa' if expected else 'provjera — prethodna primjena/interval nisu dokazani')
    if not interval_ok:
        warnings.append(('Interval odstupa: očekivani datum '+expected.strftime('%d.%m.%Y.')+' ' if expected else
                         'Prethodna primjena ili interval nisu dokazani. ')+'Potvrdite promjenu prema dogovoru/nalogu; terapijski interval se ne mijenja.')
    if scope == 'following' and not duplicate_booking:
        previous = appointment
        for index, later in enumerate(following, start=1):
            if actual(later).exists():
                problems.append('Naredni termin ima provedenu terapiju i ne smije se pomjerati.')
                changes.append(_row(later, later.datum, later.vrijeme, changed=False))
                previous = later
                continue
            prev_context = context(previous, when=date.fromisoformat(changes[-1]['new_date']), ordinal=base_ordinal+index-1)
            next_context = context(later, ordinal=base_ordinal+index)
            weeks = prev_context['interval']
            transition = prev_context['phase']
            same_product = previous.lijek_id == later.lijek_id
            iv_sc = bool(transition and previous.lijek_id == transition.iv_lijek_id and later.lijek_id == transition.sc_lijek_id)
            if not weeks or not (same_product or iv_sc) or not (next_context['interval'] or iv_sc):
                problems.append('Naredni termin nema dokazan kompatibilan interval/prezentaciju. Pomjerite samo ovaj termin ili provjerite nalog.')
                changes.append(_row(later, later.datum, later.vrijeme, changed=False))
            else:
                due = date.fromisoformat(changes[-1]['new_date']) + timedelta(weeks=8 if iv_sc else weeks)
                if same_product:
                    from .regimen_changes import next_regimen_date
                    scoped = copy(patient)
                    scoped.lijek = previous.lijek
                    _, due = next_regimen_date(scoped, date.fromisoformat(changes[-1]['new_date']), weeks)
                slot = first_slot(later, due, later.vrijeme, excluded=excluded, proposed=changes, protocol=next_context['protocol'])
                if slot:
                    new_day, new_clock = date.fromisoformat(slot['date']), time.fromisoformat(slot['time'])
                    changes.append(_row(later, new_day, new_clock, changed=(new_day, new_clock) != (later.datum, later.vrijeme)))
                    if new_day != due:
                        warnings.append(f'Naredni termin {later.pk}: interval daje {due:%d.%m.%Y.}; prvi slobodan dozvoljeni dan je {new_day:%d.%m.%Y.}.')
                else:
                    problems.append('Nije pronađen siguran naredni termin u narednih 366 dana.')
                    changes.append(_row(later, later.datum, later.vrijeme, changed=False))
            previous = later
    else:
        changes.extend(_row(t, t.datum, t.vrijeme, changed=False) for t in following)
    # A date edit must not silently select a different clinical dose across a
    # dated order. Keep the prescribed plan explicit and review that change in
    # its own workflow; never rewrite quantity during a scheduling correction.
    for row in changes:
        if not row['changed']:
            continue
        original = next(t for t in all_terms if t.pk == row['id'])
        if not order_compatible(original, date.fromisoformat(row['new_date'])):
            problems.append('Novi datum prelazi promjenu kliničkog naloga/doze. Odaberite drugi datum ili prvo pregledajte dokumentovani nalog.')
    from .calendar_capacity import capacity_warning, normal_daily_capacity
    normal_capacity = normal_daily_capacity()
    capacity_warnings = []
    for row in changes:
        if row['changed']:
            term = next(t for t in all_terms if t.pk == row['id'])
            warning = daily_capacity_warning(term, date.fromisoformat(row['new_date']),
                excluded=excluded, proposed=changes)
            if warning:
                capacity_warnings.append(warning)
    first_capacity_warning = capacity_warning(count, when=when, capacity=normal_capacity)
    needed = Decimal(str(appointment.kolicina_po_terapiji or 0))
    reserved = Decimal(changes[0]['reservation_quantity'])
    checked = coverage(patient, medicine, when, needed)
    physical_ok, commission_ok, rights = checked['physical_ok'], checked['commission_ok'], checked['rights']
    cumulative = {}
    for earlier_term in earlier:
        group = tuple(sorted(earlier_term.lijek.physical_equivalent_ids()))
        cumulative[group] = cumulative.get(group, Decimal(0)) + Decimal(str(earlier_term.kolicina_po_terapiji or 0))
    for row in changes:
        term = next(t for t in all_terms if t.pk == row['id'])
        group = tuple(sorted(term.lijek.physical_equivalent_ids()))
        cumulative[group] = cumulative.get(group, Decimal(0)) + Decimal(row['quantity'] or '0')
        row['cumulative_quantity'] = str(cumulative[group])
        checked_term = coverage(patient, term.lijek, date.fromisoformat(row['new_date']), cumulative[group])
        row['physical_coverage'] = 'pokriveno' if checked_term['physical_ok'] else 'provjera'
        row['commission_coverage'] = 'pokriveno' if checked_term['commission_ok'] else 'provjera'
        if row['changed'] and row['id'] != appointment.pk and (not checked_term['physical_ok'] or not checked_term['commission_ok']):
            warnings.append(f'Naredni termin {row["id"]} · {row["medicine"]}: fizičko/komisijsko pokriće zahtijeva provjeru; saldo i pravo se ne mijenjaju.')
        if row['id'] == appointment.pk:
            physical_ok, commission_ok = checked_term['physical_ok'], checked_term['commission_ok']
    if not physical_ok:
        warnings.append('Fizičko pokriće zahtijeva provjeru. Pomjeranje ne troši niti dodjeljuje zalihu.')
    if not commission_ok:
        warnings.append('Komisijsko pokriće na novi datum zahtijeva provjeru. Pravo ostaje bez promjene.')
    if not reserved:
        warnings.append('Termin nema vezano aktivno zaduženje. Pomjeranje ne kreira novu rezervaciju.')
    rows = [dict(label='STARI TERMIN', before=appointment.datum.strftime('%d.%m.%Y.')+' '+appointment.vrijeme.strftime('%H:%M'), after=when.strftime('%d.%m.%Y.')+' '+clock.strftime('%H:%M')),
        dict(label='NOVI TERMIN', before='Predloženo', after=when.strftime('%d.%m.%Y.')+' '+clock.strftime('%H:%M')),
        dict(label='Lijek / prezentacija / put primjene termina', before=f'{medicine} · {medicine.put_primjene}', after=f'{medicine} · {medicine.put_primjene}'),
        dict(label='Aktivna terapija pacijenta', before=f'{patient.lijek} · {patient.lijek.put_primjene}', after=f'{patient.lijek} · {patient.lijek.put_primjene}'),
        dict(label='Rezervacija', before=f'{reserved:g} jedinica · termin {appointment.pk}', after='premješta se uz isti termin; količina i veza ostaju' if reserved else 'ostaje bez promjene; nema vezanog zaduženja'),
        dict(label='Interval', before=f'{clinical["interval"] or "nepotvrđen"} sedmica · {clinical["source"]}', after=interval_label),
        dict(label='Komisija', before=f'Preostalo pravo {rights:g}', after='pokriveno · pravo bez promjene' if commission_ok else 'provjera · pravo bez promjene'),
        dict(label='Fizičko pokriće', before=f'{checked["physical"]:g} jedinica', after='pokriveno · bez potrošnje' if physical_ok else 'provjera · bez potrošnje'),
        dict(label='Kapacitet', before=f'Uobičajeno {normal_capacity} pacijenata/dan',
            after=f'{count} pacijenata · informativno prekoračenje' if first_capacity_warning else f'{count} pacijenata · uobičajeni kapacitet'),
        dict(label='Naredni termin', before=f'{len(following)} zakazanih termina', after='preračun prema prikazanom pregledu' if scope == 'following' else 'bez promjene / preporučen preračun' if following else 'bez promjene — nema narednog termina')]
    for row in changes[1:]:
        rows.append(dict(label=f'Naredni termin {row["id"]} · {row["medicine"]} · {row["route"]}',
            before=row['old_date']+' '+row['old_time'], after=row['new_date']+' '+row['new_time']))
    phase_pointer = None
    if phase and phase.sljedeci_datum == appointment.datum:
        phase_pointer = dict(id=phase.pk, before=str(phase.sljedeci_datum), after=str(when))
        rows.append(dict(label='Naredni datum faznog protokola', before=phase_pointer['before'], after=phase_pointer['after']))
    slot = first_slot(appointment, max(when, expected or when), clock, excluded=excluded,
                      protocol=clinical['protocol'], before=following[0].datum if following and scope == 'one' else None,
                      after=(earlier[-1].datum, earlier[-1].vrijeme) if earlier else None,
                      avoid=(appointment.datum, appointment.vrijeme))
    return serial(dict(title='Promijeni zakazani termin', can_confirm=not problems, problems=list(dict.fromkeys(problems)),
        warnings=list(dict.fromkeys(warnings)), capacity_warnings=list(dict.fromkeys(capacity_warnings)),
        rows=rows, appointments=changes, phase_pointer=phase_pointer,
        interval=dict(weeks=clinical['interval'], expected=expected, ok=interval_ok),
        capacity=dict(patients=count, maximum=normal_capacity, normal=normal_capacity,
                      exceeded=bool(first_capacity_warning), warning=first_capacity_warning),
        physical_covered=physical_ok, commission_covered=commission_ok,
        first_available=slot, safe_next_actions=links(patient, medicine, appointment.pk, raw, slot), move_scope=scope))


@transaction.atomic
def apply_reviewed(result, patient, user, reason):
    from .therapy_workflow import record_status_history
    from .transaction_locking import select_for_update_self
    patient = m.Pacijent.objects.select_for_update().get(pk=patient.pk)
    require(result['can_confirm'], 'Termin nije prihvatljiv. Odaberite jedan od prikazanih sigurnih koraka.')
    excluded = [row['id'] for row in result['appointments'] if row['changed']]
    proposed, staged = [], []
    for row in result['appointments']:
        if not row['changed']:
            continue
        appointment = appointment_for(patient, row['id'])
        appointment = select_for_update_self(m.Termin.objects.select_related('pacijent', 'lijek')).get(pk=appointment.pk)
        appointment.pacijent = patient
        when, clock = date.fromisoformat(row['new_date']), time.fromisoformat(row['new_time'])
        issues, _ = slot_issues(appointment, when, clock, excluded=excluded,
            proposed=proposed, protocol=context(appointment)['protocol'])
        require(not issues, ' '.join(issues))
        require(order_compatible(appointment, when),
            'Novi datum prelazi promjenu kliničkog naloga/doze. Prvo pregledajte dokumentovani nalog.')
        proposed.append(row)
        staged.append((row, appointment))
    for row, appointment in staged:
        old = dict(datum=str(appointment.datum), vrijeme=appointment.vrijeme.isoformat(timespec='minutes'),
                   lijek_id=appointment.lijek_id, rezervacije=row['reservation_ids'], quantity=row['quantity'])
        appointment.datum, appointment.vrijeme = date.fromisoformat(row['new_date']), time.fromisoformat(row['new_time'])
        appointment.save(update_fields=['datum', 'vrijeme'])
        record_status_history(pacijent=patient, termin=appointment, previous_status=appointment.status,
            new_status=appointment.status, user=user, reason=reason, previous_state=old,
            new_state=dict(old, datum=row['new_date'], vrijeme=row['new_time'],
                           source='guided_appointment_reschedule', move_scope=result['move_scope'],
                           linked_changes='Isti termin i iste rezervacije; promijenjen datum/vrijeme'),
            event_type='PROMJENA_ZAKAZANOG_TERMINA')
    pointer = result.get('phase_pointer')
    if pointer:
        phase = m.FazniProtokolPacijenta.objects.get(pk=pointer['id'], pacijent=patient)
        phase.sljedeci_datum = date.fromisoformat(pointer['after'])
        phase.save(update_fields=['sljedeci_datum'])
