"""Restore only receipt-derived scheduling metadata, with later-change guards."""
from . import models as m
from .data_corrections import require, serial


def appointment_evidence(patient_id):
    """Proven boundary for later appointments, which have no creation timestamp."""
    return serial(list(m.Termin.objects.filter(pacijent_id=patient_id).order_by('pk').values(
        'id', 'lijek_id', 'datum', 'vrijeme', 'status', 'kolicina_po_terapiji')))


def therapy_reversal_evidence(therapy):
    """Saved domain rows prove that an undo cannot overwrite later changes."""
    snapshot=therapy.workflow_snapshot or {}
    result={}
    for label,model,ids in [
        ('patient',m.Pacijent,[therapy.pacijent_id]),
        ('commission',m.Komisija,[x['komisija_id'] for x in snapshot.get('komisijske_promjene',[])]+([snapshot['commission_id']] if snapshot.get('retrospective_accounting') and snapshot.get('commission_id') else [])),
        ('reservation',m.PacijentRezervacija,[x['rezervacija_id'] for key in ('rezervacijske_promjene','fazne_rezervacijske_promjene') for x in snapshot.get(key,[])]+([snapshot['fazna_naredna_rezervacija_id']] if snapshot.get('fazna_naredna_rezervacija_id') else [])+([snapshot['reservation_id']] if snapshot.get('retrospective_accounting') and snapshot.get('reservation_id') else [])),
        ('assignment',m.PacijentZaduzenje,[x['zaduzenje_id'] for x in snapshot.get('zaduzenja_promjene',[])]+([snapshot['zaduzenje_izdavanje']['zaduzenje_id']] if snapshot.get('zaduzenje_izdavanje') else [])),
        ('phase',m.FazniProtokolPacijenta,[snapshot['fazni_protokol_id']] if snapshot.get('fazni_protokol_id') else []),
    ]:
        result[label]=serial(list(model.objects.filter(pk__in=ids).order_by('pk').values()))
    return result


def metadata_restorations(event):
    """Audit rows are immutable; these are derived fields changed by complete_cycle."""
    result = []
    before, after = event.effects.get('before', {}), event.effects.get('after', {})
    fields_by_model = {
        m.PostavkeSistema: ('potvrdjeni_datum_naredne_komisije',),
        m.OperationalOutcome: ('actual_delivery_date', 'actual_lead_time_days',
            'delivery_variance_days', 'receipt_date', 'first_scheduled_therapy_after_receipt'),
    }
    for model, fields in fields_by_model.items():
        table = model._meta.db_table
        for key, saved in after.get(table, {}).items():
            original = before.get(table, {}).get(key)
            values = {field: original.get(field) if original else None for field in fields
                      if saved.get(field) != (original.get(field) if original else None)}
            if not values:continue
            current = model.objects.filter(pk=key).values().first()
            require(current is not None and all(serial(current.get(f)) == saved.get(f) for f in values),
                    'Plan komisije ili izvedeni podaci prijema su kasnije izmijenjeni. Poništavanje ne smije vratiti starije vrijednosti preko novih odluka.')
            result.append((model, key, values))
    return result


def restore_receipt_metadata(event, restorations):
    for model, key, values in restorations:
        model.objects.filter(pk=key).update(**values)
    cycle = event.request.komisijski_ciklus
    cycle.refresh_from_db()
    # The normal correction service already recalculates request quantities.
    # A reopened cycle has no completed-receipt date; retained receipts remain.
    if cycle.status != 'ZAPRIMLJENO':
        cycle.datum_zaprimanja = None
        cycle.save(update_fields=['datum_zaprimanja'])
        m.OperationalOutcome.objects.filter(commission_cycle=cycle).update(
            actual_delivery_date=None, actual_lead_time_days=None, delivery_variance_days=None,
            receipt_date=None, first_scheduled_therapy_after_receipt=None)


# Phase 4C.2: an audit/authorization envelope over existing reverse services.
# This deliberately has no independent stock or therapy mutation algorithm.
from datetime import date
from decimal import Decimal
from uuid import uuid4
from django.core import signing
from django.db import transaction
from django.db.models import Q
from django.urls import reverse
from django.utils import timezone
from .correction_protocol import correction_transaction
from .data_corrections import (CorrectionBlocked, backup_before_correction,
                              captured_rows, digest, differences)

REVERSAL_SALT = 'theraflow.safe-event-reversal.v1'
REVERSAL_STALE = 'Podaci su se promijenili nakon pregleda. Ponovo otvorite poništavanje.'
UNSAFE = 'Poništavanje nije sigurno za automatsku primjenu.'


def original_context(kind, object_id):
    require(kind in ('therapy', 'retrospective', 'correction', 'smart', 'oral'), 'Nepoznata vrsta događaja.')
    action = None
    if kind == 'smart':
        action = m.ReconciliationAction.objects.get(pk=object_id)
        source = action.event or action.data_correction
        if source is None:
            return dict(kind=kind, object_id=object_id, source=action, action=action,
                patient=action.appointment.pacijent if action.appointment_id else action.session.patient,
                medicine=action.appointment.lijek if action.appointment_id else action.session.medicine,
                cutoff=action.created_at, unsupported=True)
    else:
        source = {'therapy':m.Terapija, 'retrospective':m.RetrospectiveEvent,
                  'correction':m.PatientDataCorrection,'oral':m.IzdavanjeOralneTerapije}[kind].objects.get(pk=object_id)
    if isinstance(source,m.IzdavanjeOralneTerapije):
        return dict(kind=kind,object_id=object_id,source=source,action=None,patient=source.pacijent,medicine=source.lijek,cutoff=source.kreirano,unsupported=False)
    if isinstance(source, m.Terapija):
        event = m.RetrospectiveEvent.objects.filter(therapy=source).first()
        if event: source = event
    if isinstance(source, m.RetrospectiveEvent):
        action = action or m.ReconciliationAction.objects.filter(event=source).first()
        patient, medicine, cutoff = source.patient, source.medicine, source.created_at
    elif isinstance(source, m.PatientDataCorrection):
        action = action or m.ReconciliationAction.objects.filter(data_correction=source).first()
        details = source.posljedice if isinstance(source.posljedice, dict) else {}
        medicine_id = details.get('medicine_id') or details.get('controlled', {}).get('medicine_id')
        patient = source.pacijent
        medicine_id = medicine_id or (source.izvorna_transakcija.lijek_id if source.izvorna_transakcija_id else patient.lijek_id if patient else None)
        medicine, cutoff = m.Lijek.objects.filter(pk=medicine_id).first(), source.kreirano
    else:
        patient, medicine = source.pacijent, source.lijek
        history = m.TerapijaStatusHistorija.objects.filter(terapija=source).order_by('datum_vrijeme').first()
        cutoff = history.datum_vrijeme if history else None
    return dict(kind=kind, object_id=object_id, source=source, action=action,
                patient=patient, medicine=medicine, cutoff=action.created_at if action else cutoff, unsupported=medicine is None)


def reversal_parent(context):
    return f'{context["kind"]}:{context["object_id"]}'


def dependent_events(context):
    source, patient, medicine = context['source'], context['patient'], context['medicine']
    result = []
    def add(label, obj=None, url=None):
        result.append(dict(label=label, reference=f'{obj.__class__.__name__} #{obj.pk}' if obj else '',
            url=url or (reverse('patient_timeline', args=[patient.pk]) if patient else reverse('business_attention'))))
    if context['unsupported']:
        add('Ručno rješavanje kroz kontrolisanu korekciju. Ne postoji dokazivo siguran domain servis za povrat ove radnje.')
        return result
    cutoff = context['cutoff']
    if cutoff is None:
        add('Nije dokazano vrijeme izvorne potvrde; nije moguće isključiti kasnije promjene.')
        return result
    if isinstance(source,m.IzdavanjeOralneTerapije):
        for later in m.IzdavanjeOralneTerapije.objects.filter(pacijent=patient,lijek=medicine,status='AKTIVNO').filter(Q(pk__gt=source.pk)|Q(datum_izdavanja__gt=source.datum_izdavanja)).exclude(pk=source.pk)[:101]:
            add('Kasnije oralno izdavanje',later)
        if source.komisija_id and not source.is_migration_snapshot and source.komisija.preostale_doze != source.odobreno_preostalo_poslije:
            add('Komisijsko pravo nakon izdavanja više nije sačuvano.')
        if source.rezim_id and (not source.rezim.aktivan or source.rezim.tableta_dnevno != source.tableta_dnevno_snapshot):
            add('Oralni terapijski nalog je kasnije promijenjen.')
    therapy = source.therapy if isinstance(source, m.RetrospectiveEvent) else source if isinstance(source, m.Terapija) else None
    if therapy:
        # A home-use statement is a later dependency even though it deliberately
        # does not post another stock movement or clinical Terapija. Match the
        # existing issue-correction guard: never return dispensed units blindly
        # after a statement about their use or remaining quantity.
        from .therapy_workflow import home_issuance_report_dependencies
        for report in home_issuance_report_dependencies(therapy).order_by('pk')[:101]:
            add('Kasnija izjava o primjeni ili preostaloj kućnoj količini', report)
        for later in m.Terapija.objects.filter(pacijent=patient, workflow_status='POTVRDJENA').filter(
                Q(pk__gt=therapy.pk) | Q(datum__gt=therapy.datum)).exclude(pk=therapy.pk)[:101]:
            add('Kasnija terapija / izdavanje', later)
        evidence=therapy.workflow_snapshot.get('reversal_evidence')
        if evidence is None or evidence!=therapy_reversal_evidence(therapy):
            add('Povezano zaduženje, odobrenje ili terapijski plan je promijenjen ili nije pouzdano dokazan. Ručno rješavanje kroz kontrolisanu korekciju.')
        saved = therapy.workflow_snapshot.get('reversal_appointments')
        if saved is None:
            add('Izvorni snapshot ne dokazuje sve termine. Ručno rješavanje kroz kontrolisanu korekciju.')
        elif saved != appointment_evidence(patient.pk):
            add('Termin je naknadno kreiran, izmijenjen ili uklonjen. Pregledajte zavisne termine.')
    scope = Q(pacijent=patient) if patient else Q(pk__in=[])
    scope |= Q(posljedice__medicine_id=medicine.pk) | Q(posljedice__controlled__medicine_id=medicine.pk) | Q(izvorna_transakcija__lijek=medicine)
    corrections = m.PatientDataCorrection.objects.filter(scope, kreirano__gt=cutoff)
    if isinstance(source, m.PatientDataCorrection): corrections = corrections.exclude(pk=source.pk)
    for item in corrections.order_by('pk')[:101]: add('Kasnija korekcija', item)
    movements=m.ZalihaTransakcija.objects.filter(lijek=medicine,kreirano__gt=cutoff)
    if isinstance(source,m.IzdavanjeOralneTerapije):
        movements=movements.exclude(referenca_tip='IzdavanjeOralneTerapije',referenca_id=source.pk)
    for item in movements.order_by('pk')[:101]:
        add('Kasniji prijem / potrošnja / zaduženje', item)
    if patient:
        for item in m.BrzaIzmjenaPacijenta.objects.filter(Q(pacijent=patient)|Q(primalac=patient), kreirano__gt=cutoff)[:101]:
            add('Kasnija promjena plana / prijenos zaduženja', item)
        actions = m.ReconciliationAction.objects.filter(created_at__gt=cutoff).filter(
            Q(appointment__pacijent=patient)|Q(event__patient=patient)|Q(data_correction__pacijent=patient)|Q(session__patient=patient))
        for item in actions.exclude(pk=context['action'].pk if context['action'] else None).order_by('pk')[:101]:
            add('Kasniji Smart/Reconciliation događaj', item)
        for item in m.TerapijaStatusHistorija.objects.filter(pacijent=patient, datum_vrijeme__gt=cutoff).order_by('pk')[:101]:
            add('Kasnija promjena termina / prekid terapije', item)
    if isinstance(source, m.RetrospectiveEvent) and source.batch_id:
        add('Događaj pripada povezanom unosu; pregledajte cijeli unos.')
    return result


def current_values(context):
    from .correction_center import state
    values = state(context['patient'], context['medicine'])
    if context['patient']:
        from .therapy_history import actually_administered_therapy_query
        last = actually_administered_therapy_query(m.Terapija.objects.filter(
            pacijent=context['patient'], lijek=context['medicine'])).order_by('-datum', '-pk').first()
        values['last_actual'] = str(last.datum) if last else 'Nema validne primjene'
        values['expected_next'] = 'Potrebna provjera terapijskog plana / naloga ljekara.'
        if last:
            from .retrospective_history import patient_at
            from .retrospective_schedule import next_date_plan
            try:
                values['expected_next']=str(next_date_plan(patient_at(context['patient'],last.datum),last.datum)['due'])
            except ValueError:
                pass
    source = context['source']
    if isinstance(source, m.PatientDataCorrection) and source.scope == 'commission_link':
        receipt = m.UnlinkedStockReceipt.objects.get(pk=source.posljedice['receipt_id'])
        values['commission_link'] = receipt.request_id
    if isinstance(source, m.RetrospectiveEvent) and source.therapy_id:
        values['therapy_status'] = m.Terapija.objects.get(pk=source.therapy_id).workflow_status
    elif isinstance(source, m.Terapija): values['therapy_status'] = m.Terapija.objects.get(pk=source.pk).workflow_status
    elif isinstance(source,m.IzdavanjeOralneTerapije): values['therapy_status']=source.status
    return serial(values)


def native_reverse(context, user, reason, operation, backup):
    """No direct balance overwrites: invoke the existing domain/correction path."""
    source = context['source']
    if isinstance(source,m.IzdavanjeOralneTerapije):
        from .data_corrections import _void_preview
        from .oral_therapy import void_oral_issuance
        _void_preview(source.pacijent,'oral_issue',source.pk,{'impacts':[]},lambda *args:None)
        return void_oral_issuance(issue=source,reason=reason,user=user)
    if isinstance(source, m.RetrospectiveEvent):
        from .retrospective_events import reversal_preview, apply_reversal
        plan = reversal_preview(source, user, reason, allow_reconciliation=True)
        return apply_reversal(source, user, plan, backup)
    if isinstance(source, m.Terapija):
        from .data_corrections import _void_preview
        _void_preview(source.pacijent, 'therapy', source.pk, {'impacts':[]}, lambda *args: None)
        from .therapy_workflow import void_therapy
        return void_therapy(terapija=source, reason=reason, user=user)
    require(isinstance(source, m.PatientDataCorrection), 'Ručno rješavanje kroz kontrolisanu korekciju.')
    if source.scope == 'commission_link':
        receipt = m.UnlinkedStockReceipt.objects.select_for_update().get(pk=source.posljedice['receipt_id'])
        require(receipt.request_id == source.poslije['request_id'], 'Komisijska veza je već promijenjena.')
        receipt.request = None
        receipt.save(update_fields=['request'])  # Only the provenance FK; never stock.
        return receipt
    if source.scope == 'controlled_physical':
        from .physical_stock_corrections import preview, apply_plan
        previous = m.PhysicalStockCorrection.objects.get(pk=source.posljedice['physical_correction_id'])
        from .physical_stock_corrections import stock_summary
        current=stock_summary(context['medicine'])
        require(Decimal(current['before']) == Decimal(source.poslije['physical']) and
                Decimal(current['reserved']) == Decimal(source.poslije['reserved']), 'Stanje nakon korekcije više nije sačuvano.')
        plan = preview(dict(lijek=context['medicine'], kolicina=previous.prethodna_kolicina,
            razlog=reason, obuhvat=previous.pregled['scope'], serija=previous.pregled['batch'],
            rok_trajanja=date.fromisoformat(previous.pregled['expires']) if previous.pregled['expires'] else None, datum_dogadjaja=timezone.localdate(),
            razlog_kod='COUNT_UNKNOWN', previous_correction_id=previous.pk))
        return apply_plan(plan, user, operation, backup)[0]
    if source.scope == 'center_allocation':
        from .correction_center import allocation_plan, apply_allocation_plan
        native = source.posljedice
        plan = allocation_plan(context['patient'], context['medicine'],
            dict(kind='release' if native['kind']=='allocate' else 'allocate',
                quantity=native['quantity'], reservation_id=native['reservation_id'], reverse_of=source.pk,
                reason=reason, acknowledge_appointment=True), user)
        return apply_allocation_plan(plan, user, operation, backup)[0]
    raise CorrectionBlocked('Ručno rješavanje kroz kontrolisanu korekciju. Nije dostupan dokazivo siguran reverzni servis za ovu korekciju.')


def reversal_rows(before,after):
    from .correction_center import rows
    result=rows(before,after)
    for key,label in [('expected_next','Očekivani naredni datum — zasebna provjera rasporeda'),
                      ('last_actual','Posljednja stvarna primjena'),('therapy_status','Terapija'),('commission_link','Komisijska veza')]:
        if key in before:
            result.append(dict(label=label,before=before[key],after=after[key],unchanged=before[key]==after[key]))
    return serial(result)


def make_event_reversal_preview(kind, object_id, reason, user):
    from .correction_center import authorize, rows
    authorize(user)
    reason = str(reason).strip()
    require(5 <= len(reason) <= 500, 'Razlog poništavanja je obavezan (5–500 znakova).')
    with correction_transaction():
        context = original_context(kind, object_id)
        before = current_values(context) if context['medicine'] else {}
        dependencies = dependent_events(context)
        plan = dict(title='Poništi događaj', kind=kind, object_id=object_id, reason=reason,
            original=f'{context["source"].__class__.__name__} #{context["source"].pk}',
            original_at=str(context['cutoff']), administrative_link=isinstance(context['source'],m.PatientDataCorrection) and context['source'].scope=='commission_link', patient_id=context['patient'].pk if context['patient'] else None,
            medicine_id=context['medicine'].pk if context['medicine'] else None,
            session_id=context['action'].session_id if context['action'] else None,
            before=before, after=before, dependencies=dependencies, rows=[], allowed=False,
            unchanged=['Originalni događaj, audit, lijek, doza i klinički interval ostaju sačuvani.'])
        if isinstance(context['source'], m.PatientDataCorrection) and context['source'].scope=='commission_link':
            plan['unchanged'] += ['Fizičko stanje: bez promjene', 'Komisijsko pravo: bez promjene', 'Pacijentovo zaduženje: bez promjene', 'Stvarni prijem ostaje sačuvan.']
        operation = str(uuid4())
        if dependencies: return plan, None
        fingerprint = digest(captured_rows())
        try:
            with transaction.atomic():
                native_reverse(context, user, reason, operation, {})
                after = current_values(context)
                transaction.set_rollback(True)
        except ValueError as exc:
            plan['dependencies'] = [dict(label=str(exc), reference='', url=reverse('patient_timeline', args=[plan['patient_id']]) if plan['patient_id'] else reverse('business_attention'))]
            return plan, None
        require(fingerprint == digest(captured_rows()), REVERSAL_STALE)
        plan.update(after=after, allowed=True, rows=reversal_rows(before, after))
        return plan, signing.dumps(dict(kind=kind, object_id=object_id, user=user.pk,
            reason=reason, operation=operation, fingerprint=fingerprint, after=after), salt=REVERSAL_SALT, compress=True)


def confirm_event_reversal(token, user, *, kind, object_id):
    from .correction_center import authorize
    from dashboard.permissions import korisnik_uloga
    authorize(user)
    try: payload = signing.loads(token, salt=REVERSAL_SALT)
    except signing.BadSignature: raise CorrectionBlocked('Pregled nije važeći. Ponovo otvorite poništavanje.') from None
    require(payload['user']==user.pk and payload['kind']==kind and payload['object_id']==object_id, 'Potvrda ne pripada ovom korisniku i događaju.')
    with correction_transaction():
        context = original_context(kind, object_id)
        existing = m.PatientDataCorrection.objects.filter(posljedice__source='safe_event_reversal', posljedice__parent=reversal_parent(context)).first()
        if existing: return existing, False
        try: signing.loads(token, salt=REVERSAL_SALT, max_age=1800)
        except signing.BadSignature: raise CorrectionBlocked('Pregled je istekao. Ponovo otvorite poništavanje.') from None
        require(payload['fingerprint']==digest(captured_rows()), REVERSAL_STALE)
        require(not dependent_events(context), UNSAFE)
        before = current_values(context); before_rows = captured_rows()
        backup = backup_before_correction(payload['operation'])
        native = native_reverse(context, user, payload['reason'], payload['operation'], backup)
        after = current_values(context)
        require(after == payload['after'], REVERSAL_STALE)
        changed_before, changed_after = differences(before_rows, captured_rows())
        source = context['source']
        from .correction_center import rows
        metadata = serial(dict(parent=reversal_parent(context), original_kind=kind, original_id=object_id,
                original_model=source.__class__.__name__, original_pk=source.pk, source='safe_event_reversal',
                actor_role=korisnik_uloga(user), medicine_id=context['medicine'].pk,
                session_id=context['action'].session_id if context['action'] else None,
                native_reverse=f'{native.__class__.__name__} #{native.pk}', rows=reversal_rows(before, after),
                affected_before=changed_before, affected_after=changed_after))
        if isinstance(native, m.PatientDataCorrection):
            # The allocation service already produced the detailed audit.
            audit = native
            audit.posljedice = dict(audit.posljedice, **metadata)
            audit.save(update_fields=['posljedice'])
        else:
            audit = m.PatientDataCorrection.objects.create(operation_id=payload['operation'],
                scope='event_reversal', korisnik=user, pacijent=context['patient'],
                ponistava=source if isinstance(source, m.PatientDataCorrection) else None,
                razlog=payload['reason'], datum_dogadjaja=timezone.localdate(), prije=before, poslije=after,
                backup=backup, posljedice=metadata)
        if context['action']:
            session = context['action'].session
            m.ReconciliationAction.objects.create(operation_id=payload['operation'], session=session, user=user,
                decision='reversal', data_correction=audit, summary=serial(dict(audit.posljedice,
                    decision='Poništen događaj', reason=payload['reason'], patient=str(context['patient']), medicine=str(context['medicine']))))
            session.revision += 1; session.status='needs_review'; session.preview={}; session.preview_fingerprint=''
            session.save(update_fields=['revision','status','preview','preview_fingerprint','updated_at'])
        from .utils import upisi_log
        upisi_log(user, 'Poništen događaj', pacijent=context['patient'], objekat=audit,
            opis=f'{reversal_parent(context)}; uloga {korisnik_uloga(user)}; razlog: {payload["reason"]}.')
        return audit, True
