"""Informational clinic capacity over the existing active calendar evidence."""
from collections import defaultdict

from . import models as m
from .request_cache import get_or_set
from .therapy_history import actually_administered_therapy_query

OCCUPIED_APPOINTMENT_STATUSES = (m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_POTVRDJENA)
DEFAULT_NORMAL_DAILY_CAPACITY = 3


def normal_daily_capacity():
    def read():
        value = m.PostavkeSistema.objects.filter(pk=1).values_list(
            'uobicajeni_dnevni_kapacitet', flat=True).first()
        return value if value and value > 0 else DEFAULT_NORMAL_DAILY_CAPACITY
    return get_or_set('calendar_capacity', 'normal_daily_capacity', read)


def capacity_warning(count, when=None, capacity=None):
    capacity = normal_daily_capacity() if capacity is None else capacity
    if count <= capacity:
        return ''
    day = f' za {when:%d/%m/%Y}' if when else ''
    return (f'Broj pacijenata{day}: {count}. Uobičajeni dnevni kapacitet je {capacity}. '
            'Zakazivanje je dozvoljeno.')


def calendar_occupancy(start, end, *, excluded=()):
    """One evidence definition for duplicate validation and displayed counts."""
    booked = defaultdict(list)
    actual = defaultdict(set)
    rows = m.Termin.objects.filter(datum__range=(start, end),
        status__in=OCCUPIED_APPOINTMENT_STATUSES).exclude(pk__in=excluded)
    for row in rows.values('datum', 'pacijent_id', 'vrijeme'):
        booked[row['datum']].append(row)
    for day, patient_id in actually_administered_therapy_query(
            m.Terapija.objects.filter(datum__range=(start, end))).values_list('datum', 'pacijent_id'):
        actual[day].add(patient_id)
    return booked, actual


def daily_patient_counts(start, end):
    booked, actual = calendar_occupancy(start, end)
    return {day: len({row['pacijent_id'] for row in booked[day]} | actual[day])
            for day in set(booked) | set(actual)}


def capacity_warnings_for_dates(dates):
    dates = set(dates)
    if not dates:
        return []
    capacity = normal_daily_capacity()
    counts = daily_patient_counts(min(dates), max(dates))
    return [warning for day in sorted(dates)
            if (warning := capacity_warning(counts.get(day, 0), day, capacity))]


def notify_calendar_capacity(request, dates):
    from django.contrib import messages
    for warning in capacity_warnings_for_dates(dates):
        messages.info(request, warning)
