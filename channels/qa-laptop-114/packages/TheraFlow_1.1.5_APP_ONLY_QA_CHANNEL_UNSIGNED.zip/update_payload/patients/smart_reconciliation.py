"""Guided therapy review, orchestrating existing domains one atomic event at a time.

No receipt, count, reversal, clinical order editing or new inventory ledger lives
here. A session groups audit links, never holds a period-long write transaction.
"""
from datetime import timedelta
import uuid

from django.core import signing
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone

from . import models as m, retrospective_events as events
from .correction_protocol import correction_transaction
from .data_corrections import require, serial, digest, captured_rows, backup_before_correction
from .retrospective_history import proven_therapy_context, patient_at
from .therapy_history import actually_administered_therapy_query
from .request_cache import begin_request_cache, end_request_cache

SALT = 'theraflow.smart-therapy.v1'
STALE = 'Podaci su promijenjeni nakon pregleda. Ponovo pokrenite provjeru.'
MANUAL = 'Potrebna ručna provjera terapijskog plana'
DECISIONS = [('therapy', 'Terapija je primijenjena'), ('no_show', 'Pacijent nije došao'),
             ('postpone', 'Terapija je odgođena'), ('pause', 'Terapija je privremeno prekinuta'),
             ('skip', 'Preskoči / potrebno provjeriti')]


def authorize(user):
    from dashboard.permissions import je_sestra_ili_admin
    from django.core.exceptions import PermissionDenied
    if not user.is_active or not je_sestra_ili_admin(user):
        raise PermissionDenied('Pametno usklađivanje dostupno je sestri i administratoru.')


def authorize_event(user, session_id, data):
    """Nursing access is bound to the real guided session and its scope."""
    session = own_session(session_id, user)
    require(session.status not in ('completed', 'aligned', 'cancelled'), 'Proces je završen.')
    when = events.day(data['event_date'])
    require(session.period_start <= when <= session.period_end, 'Događaj nije u periodu procesa.')
    require(not session.patient_id or int(data['patient_id']) == session.patient_id, 'Pacijent nije dio procesa.')
    medicine = m.Lijek.objects.get(pk=data['medicine_id'])
    require(not session.medicine_id or medicine.pk in session.medicine.equivalent_ids(), 'Lijek nije dio procesa.')
    if data['kind'] == 'therapy':
        term = m.Termin.objects.get(pk=data['appointment_id'])
        require(any(row.get('id') == term.pk for row in session.findings) and
                term.pacijent_id == int(data['patient_id']) and term.lijek_id == medicine.pk,
                'Terapija nije dio odabranog workflowa.')
    else:
        require(session.workflow == 'absence' and data['kind'] in ('receipt', 'home'), 'Radnja nije dio vođenog odsustva.')
        if data['kind'] == 'receipt':
            request = m.Trebovanje.objects.get(pk=data['request_id'])
            require(any(row['id'] == request.pk for row in session.receipt_findings) and
                    request.pacijent_id == int(data['patient_id']) and request.lijek_id == medicine.pk,
                    'Komisijska stavka nije dio odabranog workflowa.')
    return session


def domain_snapshot():
    return {table: rows for table, rows in captured_rows().items()
            if not table.startswith(('patients_reconciliationsession', 'patients_reconciliationaction'))}


def actual_therapies(appointment, when=None):
    return actually_administered_therapy_query(m.Terapija.objects.filter(
        pacijent_id=appointment.pacijent_id, lijek_id__in=appointment.lijek.equivalent_ids(),
        datum=when or appointment.datum)).order_by('pk')


def card(appointment):
    actual = list(actual_therapies(appointment))
    result = dict(id=appointment.pk, patient=str(appointment.pacijent), medicine=str(appointment.lijek),
        patient_id=appointment.pacijent_id, medicine_id=appointment.lijek_id,
        date=str(appointment.datum), date_label=appointment.datum.strftime('%d.%m.%Y.'),
        status=appointment.get_status_display(), actual_ids=[x.pk for x in actual],
        actual_label=', '.join(f'#{x.pk} · {x.datum:%d.%m.%Y.}' for x in actual) or 'Nema',
        manual=False, can_apply=appointment.status in (m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA) and not actual,
        can_status=appointment.status == m.Termin.STATUS_PLANIRANA,
        warning='', quantity=None, dose_mg=None, interval=None)
    if actual:
        result['warning'] = ('Mogući duplikat već postoji.' if len(actual) > 1 else
            'Postoji evidentirana stvarna primjena; status termina zahtijeva provjeru.')
    try:
        _, plan = proven_therapy_context(appointment, appointment.datum)
        result.update(quantity=str(plan['quantity']), dose_mg=str(plan['dose_mg']), interval=plan['interval'])
        result['unit'] = appointment.lijek.jedinica_zalihe_za_kolicinu(plan['quantity'])
    except ValueError as exc:
        result.update(manual=True, can_apply=False, warning=MANUAL + ': ' + str(exc))
    result['reserved'] = str(m.PacijentRezervacija.objects.filter(pacijent_id=appointment.pacijent_id,
        lijek_id__in=appointment.lijek.equivalent_ids(), aktivno=True).aggregate(n=Sum('kolicina'))['n'] or 0)
    result['home'] = str(appointment.pacijent.zaduzeno_lijekova(lijek=appointment.lijek))
    from .stock_lots import lot_balances
    result['lots'] = [dict(batch=batch, expires=str(expiry or ''), quantity=str(quantity))
        for (batch, expiry), quantity in lot_balances(appointment.lijek).items() if batch and quantity > 0]
    if appointment.status not in (m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA) and not actual:
        result.update(can_apply=False, warning=result['warning'] or 'Status termina zahtijeva ručnu provjeru prije stvarne primjene.')
    return serial(result)


def scan(start, end, *, patient=None, medicine=None):
    cache = begin_request_cache(enabled=False)
    try:
        terms = m.Termin.objects.filter(datum__range=(start, end)).select_related('pacijent', 'lijek')
        if patient: terms = terms.filter(pacijent=patient)
        if medicine: terms = terms.filter(lijek_id__in=medicine.equivalent_ids())
        count = terms.count()
        require(count <= 500, f'Pregled nije kompletan i nije pokrenut: odabrani period sadrži {count} termina, '
                'a najviše je dozvoljeno 500. Sužite period ili odaberite pojedinačnog pacijenta/lijek pa ponovite provjeru.')
        result = []
        for term in terms.order_by('datum', 'vrijeme', 'pk'):
            actual = actual_therapies(term)
            count = actual.count()
            unresolved = term.status in (m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA)
            conflict = (term.status == m.Termin.STATUS_POTVRDJENA and not count) or (
                count and term.status != m.Termin.STATUS_POTVRDJENA)
            if unresolved or conflict or count > 1:
                result.append(card(term))
        # Actual duplicates without any appointment still need a visible alert.
        therapies = actually_administered_therapy_query(m.Terapija.objects.filter(datum__range=(start, end)))
        if patient: therapies = therapies.filter(pacijent=patient)
        if medicine: therapies = therapies.filter(lijek_id__in=medicine.equivalent_ids())
        seen = {(r['patient_id'], r['medicine_id'], r['date']) for r in result}
        for therapy in therapies.select_related('pacijent', 'lijek').order_by('datum', 'pk'):
            key = (therapy.pacijent_id, therapy.lijek_id, str(therapy.datum))
            if key in seen: continue
            duplicates = actually_administered_therapy_query(m.Terapija.objects.filter(
                pacijent=therapy.pacijent, lijek_id__in=therapy.lijek.equivalent_ids(), datum=therapy.datum))
            if duplicates.count() > 1:
                seen.add(key)
                result.append(dict(id=None, patient=str(therapy.pacijent), medicine=str(therapy.lijek),
                    patient_id=therapy.pacijent_id, medicine_id=therapy.lijek_id, date=str(therapy.datum),
                    date_label=therapy.datum.strftime('%d.%m.%Y.'), status='Bez jednoznačnog termina',
                    actual_ids=list(duplicates.values_list('pk', flat=True)), actual_label='Više stvarnih primjena',
                    can_apply=False, can_status=False, warning='Mogući duplikat već postoji.', manual=True))
        return serial(result)
    finally:
        end_request_cache(cache)


def start_session(*, user, start, end, patient=None, medicine=None, reason, workflow='therapy'):
    authorize(user)
    start, end = events.day(start), events.day(end)
    require(start <= end <= timezone.localdate(), 'Odaberite ispravan period koji završava najkasnije danas.')
    reason = str(reason).strip()
    require(5 <= len(reason) <= 500, 'Unesite razlog provjere (5–500 znakova).')
    findings = scan(start, end, patient=patient, medicine=medicine)
    require(workflow in ('therapy', 'absence'), 'Nepoznat postupak.')
    return m.ReconciliationSession.objects.create(user=user, period_start=start, period_end=end,
        patient=patient, medicine=medicine, reason=reason, findings=findings, workflow=workflow,
        status='draft' if findings or workflow == 'absence' else 'completed')


def own_session(session_id, user, *, lock=False):
    authorize(user)
    query = m.ReconciliationSession.objects.select_for_update() if lock else m.ReconciliationSession.objects
    return query.get(pk=session_id, user=user)


def normalize(session, raw):
    require(session.status not in ('completed', 'cancelled', 'aligned'), 'Ovaj proces je završen.')
    appointment = events.chosen(m.Termin, raw.get('appointment_id'), 'termin')
    finding = next((x for x in session.findings if x.get('id') == appointment.pk), None)
    require(finding is not None, 'Termin nije dio ove provjere.')
    require(finding['patient_id'] == appointment.pacijent_id and finding['medicine_id'] == appointment.lijek_id, STALE)
    require(session.period_start <= appointment.datum <= session.period_end, STALE)
    require(not session.actions.filter(appointment=appointment).exclude(decision='skip').exists(), 'Ova stavka je već razriješena u ovom procesu.')
    decision = raw.get('decision')
    require(decision in dict(DECISIONS), 'Odaberite šta se stvarno dogodilo.')
    note = str(raw.get('note', '')).strip()
    require(len(note) <= 2000, 'Napomena može imati najviše 2000 znakova.')
    data = dict(appointment_id=appointment.pk, decision=decision, note=note,
                next_choice=raw.get('next_choice') or 'keep')
    require(data['next_choice'] in ('keep', 'create'), 'Odaberite postupanje s narednim terminom.')
    if decision != 'skip':
        allowed = (m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA) if decision == 'therapy' else (m.Termin.STATUS_PLANIRANA,)
        require(appointment.status in allowed, 'Status termina traži ručnu provjeru; automatska potvrda nije dostupna.')
        require(not actual_therapies(appointment).exists(), 'Mogući duplikat već postoji. Pregledajte postojeću stvarnu primjenu.')
    if decision == 'therapy':
        when = events.day(raw.get('event_date'))
        require(session.period_start <= when <= session.period_end, 'Stvarni datum mora biti unutar odabranog perioda.')
        try:
            patient, plan = proven_therapy_context(appointment, when)
        except ValueError as exc:
            raise events.CorrectionBlocked(MANUAL + ': ' + str(exc)) from exc
        require(not actual_therapies(appointment, when).exists(), 'Mogući duplikat već postoji. Pregledajte postojeću stvarnu primjenu.')
        quantity = events.amount(raw.get('quantity') or plan['quantity'])
        require(quantity == plan['quantity'] or len(note) >= 5,
                'Količina se razlikuje od naloga. Navedite izvor provjere stvarno primijenjene količine.')
        data.update(event_date=str(when), quantity=str(quantity), dose_mg=str(plan['dose_mg']),
            kind='therapy', patient_id=patient.pk, medicine_id=patient.lijek_id,
            source_appointment_id=appointment.pk, history_confirmed=True,
            batch=str(raw.get('batch', '')).strip(), expires=str(raw.get('expires') or ''))
        # Existing late-entry services require a documented note for a historic
        # product switch. The process reason identifies the user's confirmation.
        data['note'] = note or session.reason
    elif decision in ('postpone', 'pause'):
        data['event_date'] = str(events.day(raw.get('pause_date') or raw.get('event_date') or appointment.datum))
        if decision == 'pause':
            require(session.period_start <= events.day(data['event_date']) <= session.period_end,
                    'Početak prekida mora biti unutar odabranog perioda.')
        else:
            data['new_date'] = str(events.day(raw['new_date'])) if raw.get('new_date') else ''
    return serial(data)


def quantities(appointment):
    from .inventory import patient_reservation_breakdown, _physical_medicine_ids
    patient = m.Pacijent.objects.get(pk=appointment.pacijent_id)
    medicine = appointment.lijek
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    # Status-only events need no clinical inference; scope amounts explicitly
    # to the appointment's presentation even after a subsequent drug switch.
    last = actually_administered_therapy_query(m.Terapija.objects.filter(pacijent=patient,
        lijek_id__in=medicine.equivalent_ids())).order_by('-datum', '-pk').first()
    return dict(physical=str(stock.u_frizideru if stock else 0),
        reserved=str(patient_reservation_breakdown(patient, medicine_ids=_physical_medicine_ids(medicine))['total_effective']),
        right=str(m.Komisija.objects.filter(pacijent=patient, lijek_id__in=medicine.equivalent_ids(),
            status__in=m.Komisija.VAZECI_STATUSI).aggregate(n=Sum('preostale_doze'))['n'] or 0),
        last=str(last.datum) if last else 'Nema', status=appointment.get_status_display(), date=str(appointment.datum))


def next_appointment(data, appointment, user):
    from .retrospective_schedule import next_date_plan
    from .therapy_workflow import schedule_therapy_appointment
    patient = patient_at(m.Pacijent.objects.get(pk=appointment.pacijent_id), events.day(data['event_date']))
    expected = next_date_plan(patient, events.day(data['event_date']), exclude_appointment=appointment.pk)
    due = expected['due']
    future = list(m.Termin.objects.filter(pacijent=patient,
        status__in=[m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA], datum__gt=expected['reference'])
        .exclude(pk=appointment.pk).order_by('datum', 'vrijeme', 'pk'))
    same = [t for t in future if t.datum == due and t.lijek_id == appointment.lijek_id]
    result = dict(expected=str(due), existing=[dict(id=t.pk, date=str(t.datum), medicine=str(t.lijek)) for t in future],
                  conflict=bool(future and (future[0].datum != due or future[0].lijek_id != appointment.lijek_id)),
                  created=False, existing_same=bool(same), can_create=False)
    current = m.Pacijent.objects.get(pk=patient.pk)
    result['can_create'] = not same and due >= timezone.localdate() and current.lijek_id == appointment.lijek_id and not current.na_aktivnoj_pauzi()
    if data['next_choice'] == 'create':
        require(same or result['can_create'], 'Naredni termin se ne može automatski kreirati. Provjerite datum i važeći plan.')
        if not same:
            scheduled, created = schedule_therapy_appointment(pacijent=current, lijek=appointment.lijek,
                datum=due, vrijeme=appointment.vrijeme, user=user,
                reason='Naredni termin nakon pametnog usklađivanja stvarne primjene.')
            result.update(created=created, scheduled_date=str(scheduled.datum))
    return result


def execute(session, data, user, operation_id, backup):
    """Called only inside preview savepoint or per-event correction transaction."""
    from .therapy_workflow import mark_no_show, postpone_therapy, pause_patient_therapy
    appointment = m.Termin.objects.select_related('pacijent', 'lijek').get(pk=data['appointment_id'])
    before = quantities(appointment)
    previous_history = set(m.TerapijaStatusHistorija.objects.values_list('pk', flat=True))
    event = None
    reason = data['note'] or session.reason
    decision = data['decision']
    next_plan = None
    if decision == 'therapy':
        # Strict context and duplicate validation runs again while locked.
        proven_therapy_context(appointment, events.day(data['event_date']))
        require(not actual_therapies(appointment, events.day(data['event_date'])).exists(), 'Mogući duplikat već postoji.')
        plan = events.preview(data, user, guided_session=session.pk)
        event = events.apply_plan(plan, user, operation_id, backup, guided_session=session.pk)
        next_plan = next_appointment(data, appointment, user)
        from .retrospective_reversal import appointment_evidence
        therapy = event.therapy
        therapy.refresh_from_db()
        therapy.workflow_snapshot['reversal_appointments'] = appointment_evidence(appointment.pacijent_id)
        if next_plan['created']:
            generated = m.Termin.objects.get(pacijent_id=appointment.pacijent_id, lijek=appointment.lijek,
                datum=events.day(next_plan['scheduled_date']), status=m.Termin.STATUS_PLANIRANA)
            therapy.workflow_snapshot['sljedeci_termin_id'] = generated.pk
            event.effects['generated_next'] = serial(m.Termin.objects.filter(pk=generated.pk).values().get())
            event.save(update_fields=['effects'])
        therapy.save(update_fields=['workflow_snapshot'])
    elif decision == 'no_show':
        mark_no_show(termin=appointment, reason=reason, user=user)
    elif decision == 'postpone':
        postpone_therapy(termin=appointment, reason=reason, user=user,
            new_date=events.day(data['new_date']) if data['new_date'] else None)
    elif decision == 'pause':
        pause_patient_therapy(pacijent=appointment.pacijent, start_date=events.day(data['event_date']), reason=reason, user=user)
    appointment.refresh_from_db()
    after = quantities(appointment)
    rows = []
    def row(label, left, right, why):
        rows.append(dict(label=label, before=str(left), after=str(right), why=why))
    if decision == 'therapy':
        row('Terapija', 'Nije evidentirana', 'Primijenjena ' + data['event_date'], 'Potvrđena stvarna primjena.')
        for key, label, why in [('reserved', 'Zaduženje u frižideru', 'Potrošnja pacijentove rezervacije prema postojećim pravilima.'),
            ('physical', 'Fizičko stanje u frižideru', 'Potrošnja stvarno primijenjene količine.'),
            ('right', 'Preostalo komisijsko pravo', 'Primjena troši postojeće odobreno pravo.'),
            ('last', 'Posljednja stvarna primjena', 'Historija se osvježava prema stvarnim datumima.')]:
            if before[key] != after[key]: row(label, before[key], after[key], why)
        row('Očekivani naredni datum', 'Prema važećem intervalu', next_plan['expected'], 'Izračun prema dokazanom planu, bez promjene intervala.')
        if next_plan['created']: row('Naredni termin', 'Nije zakazan na očekivani datum', next_plan['scheduled_date'], 'Izričito odabrano kreiranje u ovom pregledu.')
    elif decision == 'skip':
        row('Provjera', 'Potrebna potvrda', 'Preskočeno / potrebno provjeriti', 'Događaj nije potvrđen; poslovne evidencije se ne mijenjaju.')
    else:
        row('Status termina', before['status'], after['status'], reason)
        row('Potrošnja lijeka', '0', '0', 'Nije potvrđena stvarna primjena.')
        if decision == 'pause':
            paused = list(m.Termin.objects.filter(pacijent=appointment.pacijent,
                datum__gte=data['event_date'], status=m.Termin.STATUS_PAUSIRANA).values('id', 'datum'))
            row('Termini tokom prekida', 'Aktivni planirani termini', len(paused), 'Postojeći servis pauzira sve planirane termine od potvrđenog početka prekida.')
        if decision == 'postpone' and data['new_date']:
            row('Planirani datum', before.get('date', session.period_start), appointment.datum, 'Izričito odabrani datum odgode.')
    summary = serial(dict(patient=str(appointment.pacijent), medicine=str(appointment.lijek),
        decision=dict(DECISIONS)[decision], reason=reason, rows=rows, next=next_plan, data=data))
    history = list(m.TerapijaStatusHistorija.objects.exclude(pk__in=previous_history).values_list('pk', flat=True))
    return summary, event, history


def prepare(session_id, raw, user):
    authorize(user)
    with correction_transaction():
        session = own_session(session_id, user, lock=True)
        data = normalize(session, raw)
        fingerprint = digest(domain_snapshot())
        operation_id = uuid.uuid4()
        with transaction.atomic():
            plan, _, _ = execute(session, data, user, operation_id, {})
            transaction.set_rollback(True)
        require(fingerprint == digest(domain_snapshot()), 'Pregled nije prošao kontrolu; ništa nije primijenjeno.')
        session.revision += 1
        session.status = 'previewed'
        session.preview = dict(plan=plan, operation_id=str(operation_id), prepared_at=timezone.now().isoformat())
        session.preview_fingerprint = fingerprint
        session.save(update_fields=['revision', 'status', 'preview', 'preview_fingerprint'])
        return plan, preview_token(session, user)


def preview_token(session, user):
    require(session.user_id == user.pk and session.status == 'previewed', STALE)
    return signing.dumps(dict(session=session.pk, revision=session.revision, user=user.pk,
        operation_id=session.preview['operation_id'], fingerprint=session.preview_fingerprint), salt=SALT, compress=True)


def confirm(token, user, *, session_id=None):
    authorize(user)
    try:
        payload = signing.loads(token, salt=SALT)
    except signing.BadSignature:
        raise events.CorrectionBlocked('Pregled nije važeći. Ponovo pokrenite provjeru.') from None
    require(payload.get('user') == user.pk, 'Pregled ne pripada ovom korisniku.')
    require(session_id is None or payload.get('session') == session_id, 'Potvrda ne pripada ovom procesu.')
    with correction_transaction():
        session = own_session(payload['session'], user, lock=True)
        existing = session.actions.filter(operation_id=payload['operation_id']).first()
        if existing: return existing, False
        try:
            signing.loads(token, salt=SALT, max_age=1800)
        except signing.BadSignature:
            raise events.CorrectionBlocked('Pregled je istekao. Ponovo pokrenite provjeru.') from None
        require(session.status == 'previewed' and session.revision == payload['revision'] and
            session.preview.get('operation_id') == payload['operation_id'] and
            digest(domain_snapshot()) == payload['fingerprint'], STALE)
        require(timezone.now() - timezone.datetime.fromisoformat(session.preview['prepared_at']) < timedelta(minutes=30),
                'Pregled je istekao. Ponovo pokrenite provjeru.')
        data = normalize(session, session.preview['plan']['data'])
        # Re-run domain validation while all ordinary domain writers conflict
        # with the existing correction lock. Backups are verified before writes.
        if data['decision'] == 'therapy': events.preview(data, user, guided_session=session.pk)
        backup = backup_before_correction(uuid.uuid4())
        plan, event, history = execute(session, data, user, payload['operation_id'], backup)
        require(plan == session.preview['plan'], STALE)
        action = m.ReconciliationAction.objects.create(operation_id=payload['operation_id'], session=session,
            appointment_id=data['appointment_id'], user=user, decision=data['decision'], event=event, summary=plan)
        action.status_history.set(history)
        from .utils import upisi_log
        upisi_log(user, 'Pametno usklađivanje terapije', pacijent=action.appointment.pacijent, objekat=action,
            opis=f'Proces #{session.pk}: {plan["decision"]}. {plan["reason"]}')
        session.status = 'in_progress' if session.workflow == 'absence' else 'partially_applied'
        session.preview = {}
        session.preview_fingerprint = ''
        session.revision += 1
        session.save(update_fields=['status', 'preview', 'preview_fingerprint', 'revision'])
        return action, True


def finish(session_id, user, *, cancel=False):
    if own_session(session_id, user).workflow == 'absence':
        from .absence_reconciliation import finish as finish_absence
        return finish_absence(session_id, user, cancel=cancel)
    with correction_transaction():
        session = own_session(session_id, user, lock=True)
        if session.status in ('completed', 'cancelled'): return session
        session.status = 'cancelled' if cancel else 'needs_review' if session.actions.filter(decision='reversal').exists() else 'completed'
        session.revision += 1
        session.preview = {}
        session.preview_fingerprint = ''
        session.save(update_fields=['status', 'revision', 'preview', 'preview_fingerprint'])
        return session
