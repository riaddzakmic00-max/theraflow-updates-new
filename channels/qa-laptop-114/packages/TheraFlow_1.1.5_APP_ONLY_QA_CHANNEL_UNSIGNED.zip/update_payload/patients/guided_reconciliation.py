"""Shared impact graph and reviewed actions over existing business services.

The coordinator supplies the primary adapter. Projection runs that adapter and
selected safe actions in a rollback-only savepoint. No dose is inferred here;
clinical ambiguity is a linked manual step, never an executable recommendation.
"""
from copy import deepcopy
from contextlib import contextmanager
from datetime import date
from decimal import Decimal
from urllib.parse import urlencode
from uuid import UUID, uuid5

from django.db import transaction
from django.urls import reverse
from django.utils import timezone

from . import models as m
from .data_corrections import require, serial
from .inventory import inventory_position, patient_reservation_breakdown

PENDING = (m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA, m.Termin.STATUS_PAUSIRANA)


@contextmanager
def preserve_patient(patient):
    original = deepcopy(patient.__dict__) if patient else None
    try:
        yield
    finally:
        if patient:
            patient.__dict__.clear()
            patient.__dict__.update(original)


def step(category, patient=None, medicine=None, **extra):
    query = dict(extra)
    if patient:
        query['cc_patient'] = patient.pk
    if medicine:
        query['cc_medicine'] = medicine.pk
    query['cc_to'] = reverse('nurse_correction', args=[category])
    return reverse('correction_center') + '?' + urlencode(query)


def action(key, label, url, detail='', **fields):
    return dict(id=key, label=label, url=url, detail=detail, **fields)


def documented_mg(patient, on=None):
    from .regimen_changes import regimen_override
    from .individual_protocols import get_current_step
    from .phased_protocols import current_phase_details
    on = on or timezone.localdate()
    override = regimen_override(patient, on)
    if override.get('doza_mg'):
        return Decimal(override['doza_mg'])
    phase = patient.aktivni_fazni_protokol()
    if phase:
        details = current_phase_details(phase, on)
        return details['dose_mg'] if not details.get('dose_error') else None
    step = get_current_step(patient, on)
    return step.doza_mg if step and step.doza_mg else None


def recovery(category, patient, medicine, message, raw=None):
    """Every blocked attempt has explicit, contextual continuations."""
    actions = [action('edit', 'Ispravi unos i ponovo pregledaj', '#correction-input',
                      'Provjerite prikazani podatak i dokumentaciju.'),
               action('cancel', 'Odustani', reverse('correction_center'))]
    if category == 'therapy':
        # Preserve the user's event facts when choosing another safe source.
        # Notes and obsolete reservation IDs never enter the continuation URL.
        facts = {key:raw[key] for key in ('event_date','quantity','dose_mg') if raw and raw.get(key)}
        actions = [action('free', 'Potroši iz slobodne fizičke zalihe',
                          step('therapy', patient, medicine, accounting_choice='stock', **facts)),
                   action('historical', 'Odaberi drugo historijsko zaduženje',
                          step('therapy', patient, medicine, accounting_choice='both', **facts)),
                   action('history', 'Evidentiraj događaj bez promjene današnjeg stanja',
                          step('therapy', patient, medicine, accounting_choice='neither', **facts))] + actions
    elif patient:
        actions.insert(0, action('plan', 'Pregledaj dokumentovani terapijski plan',
                                reverse('uredi_individualni_protokol', args=[patient.pk])))
        actions.insert(1, action('reservation', 'Odaberi zaduženje za korekciju',
                                step('reservation', patient, medicine)))
    if medicine:
        actions.append(action('stock', 'Provjeri fizičko stanje i porijeklo', step('physical', patient, medicine)))
    return dict(primary_change=None, required_changes=[], recommended_changes=[], informational_checks=[],
                unresolved_items=[], blocked_actions=[dict(label='Radnja nije sačuvana', detail=message,
                safe_next_actions=actions)], safe_next_actions=actions, final_preview=[], checks=[])


def _appointments(patient):
    if not patient:
        return []
    return list(m.Termin.objects.filter(pacijent=patient, datum__gte=timezone.localdate(), status__in=PENDING)
                .select_related('lijek', 'pacijent').order_by('datum', 'vrijeme', 'pk'))


def state(patient, medicine):
    """Comparable relevant values; new DB sequence IDs are not preview values."""
    from .appointment_plan import display_appointment_dose
    products = {medicine.pk: medicine}
    appointments = _appointments(patient)
    if patient:
        patient = m.Pacijent.objects.select_related('lijek').get(pk=patient.pk)
        products[patient.lijek_id] = patient.lijek
        phase = patient.aktivni_fazni_protokol()
        if phase:
            for product in (phase.iv_lijek, phase.sc_lijek):
                if product:
                    products[product.pk] = product
            rows_phase = dict(label='Naredni datum faznog protokola', value=str(phase.sljedeci_datum or 'Nije planiran'))
        for reservation in m.PacijentRezervacija.objects.filter(pacijent=patient, aktivno=True).select_related('lijek'):
            products[reservation.lijek_id] = reservation.lijek
    for appointment in appointments:
        products[appointment.lijek_id] = appointment.lijek
    rows = {}
    if patient and phase:
        rows['phase_next_date'] = rows_phase
    for product in products.values():
        position = inventory_position(product, include_planned_need=False)
        rows[f'physical:{product.pk}'] = dict(label=f'Fizička zaliha · {product}', value=position['in_fridge'])
        rows[f'free:{product.pk}'] = dict(label=f'Slobodna fizička zaliha · {product}', value=position['freely_available'])
        if patient:
            own = patient_reservation_breakdown(patient, medicine_ids=product.physical_equivalent_ids())['total_effective']
            rows[f'reserved:{product.pk}'] = dict(label=f'Zaduženje pacijenta · {product}', value=own)
    if patient:
        rows['plan'] = dict(label='Terapijski plan / prezentacija / put primjene',
            value=f'{patient.lijek} · {patient.lijek.put_primjene} · interval {patient.interval_sedmica}')
        for commission in m.Komisija.objects.filter(pacijent=patient).order_by('pk'):
            rows[f'right:{commission.pk}'] = dict(label=f'Komisijsko pravo · {commission.lijek} · odobrenje {commission.pk}',
                value=commission.preostale_doze)
        for request in m.Trebovanje.objects.filter(pacijent=patient).order_by('pk'):
            rows[f'commission:{request.pk}'] = dict(label=f'Komisijsko planiranje · stavka {request.pk}',
                value=f'Zatraženo {request.broj_doza:g} · odobreno {request.odobrene_doze if request.odobrene_doze is not None else "nije evidentirano"} · {request.get_status_display()}')
        rows['appointments'] = dict(label='Budući termini', value='; '.join(
            f'{t.datum:%d.%m.%Y.} {t.vrijeme:%H:%M} · {t.lijek} · {t.get_status_display()} · {t.kolicina_po_terapiji} jedinica · {display_appointment_dose(t) or "mg doza nije potvrđena"}'
            for t in appointments) or 'Nema aktivnih budućih termina')
        rows['history'] = dict(label='Historija stvarnih primjena', value='; '.join(
            f'{t.datum:%d.%m.%Y.} · {t.lijek} · {t.kolicina:g} jedinica · {t.doza_mg if t.doza_mg else "mg nije evidentirano"} · {t.workflow_status}'
            for t in m.Terapija.objects.filter(pacijent=patient).select_related('lijek').order_by('datum','pk')) or 'Nema evidentiranih primjena')
        rows['oral_history'] = dict(label='Historija oralnih izdavanja', value='; '.join(
            f'{i.datum_izdavanja:%d.%m.%Y.} · {i.lijek} · {i.kolicina_tableta:g} tableta'
            for i in m.IzdavanjeOralneTerapije.objects.filter(pacijent=patient).select_related('lijek').order_by('datum_izdavanja','pk')) or 'Nema oralnih izdavanja')
        rows['home_balance'] = dict(label='Kućna terapija / preostalo kod pacijenta', value='; '.join(
            f'{a.lijek} · {a.preostalo:g} jedinica'
            for a in m.PacijentZaduzenje.objects.filter(pacijent=patient,aktivno=True).select_related('lijek').order_by('pk')) or 'Nema aktivnog kućnog zaduženja')
        snapshot = m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient).first()
        if snapshot:
            rows['migration_dates'] = dict(label='Historijski migracijski datumi (bez kreiranja terapije)',
                value=f'Posljednja primjena {snapshot.datum_posljednje_terapije or "nije evidentirana"} · informativni naredni datum {snapshot.sljedeca_terapija or "nije evidentiran"}')
    return serial(rows)


def inspect(category, patient, medicine, plan=None, raw=None):
    """Read-only checks of the projected or saved state, scoped to this operation."""
    from .appointment_plan import appointment_plan
    plan, raw = plan or {}, raw or {}
    result = dict(unresolved_items=[], recommended_changes=[], informational_checks=[], checks=[])
    unresolved, recommended = result['unresolved_items'], result['recommended_changes']
    def issue(key, label, detail, url):
        item = dict(id=key, label=label, detail=detail, url=url, classification='OBAVEZNO')
        unresolved.append(item)
        return item
    products = {medicine.pk: medicine}
    if patient:
        patient = m.Pacijent.objects.select_related('lijek').get(pk=patient.pk)
        products[patient.lijek_id] = patient.lijek
        phase = patient.aktivni_fazni_protokol()
        if phase:
            products.update({x.pk: x for x in (phase.iv_lijek, phase.sc_lijek) if x})
    for product in products.values():
        position = inventory_position(product, include_planned_need=False)
        shortfall = position['physical_reservation_shortfall']
        if shortfall:
            issue(f'stock:{product.pk}', 'Fizička zaliha / rezervacije',
                  f'Rezervacije premašuju fizičku zalihu za {shortfall:g} jedinica. Stvarno brojanje ostaje evidentirano; odaberite konkretno zaduženje za provjeru.',
                  step('reservation', patient, product))
            for reservation in m.PacijentRezervacija.objects.filter(lijek_id__in=product.physical_equivalent_ids(),
                    aktivno=True, kolicina__gt=0).select_related('pacijent', 'termin').order_by('pk'):
                result['informational_checks'].append(dict(label=f'Zaduženje {reservation.pk} · {reservation.pacijent}',
                    detail=f'{reservation.kolicina:g} jedinica · termin {reservation.termin.datum if reservation.termin else "nije povezan"}',
                    url=reverse('correction_center')+'?'+urlencode(dict(cc_to=reverse('correction_allocation',
                        args=[reservation.pacijent_id,reservation.lijek_id]), cc_patient=reservation.pacijent_id,
                        cc_medicine=reservation.lijek_id, kind='release',reservation_id=reservation.pk)), classification='INFORMATIVNO'))
        result['checks'].append(dict(label=f'Fizička zaliha · {product}', ok=not shortfall,
                                    url=step('physical', patient, product)))
    if patient:
        future = _appointments(patient)
        active = [t for t in future if t.lijek_id == patient.lijek_id]
        for appointment in future:
            resolved = appointment_plan(appointment, fresh=True)
            url = reverse('potvrdi_dolazak', args=[appointment.pk])
            if resolved['conflict']:
                issue(f'order:{appointment.pk}', 'Poseban nalog termina',
                      f'Termin {appointment.datum:%d.%m.%Y.} ima ručnu količinu koja se razlikuje od naloga. Potvrdite dokumentovani nalog prije primjene.', url)
            elif (resolved['source'] == 'REGIMEN' and appointment.kolicina_po_terapiji != resolved['quantity']
                  and appointment.status == m.Termin.STATUS_PLANIRANA and resolved['dose_mg']):
                item = issue(f'quantity:{appointment.pk}', 'Planirana količina budućeg termina',
                    f'{appointment.datum:%d.%m.%Y.}: {appointment.kolicina_po_terapiji} → {resolved["quantity"]} jedinica prema dokumentovanom nalogu.', url)
                item['classification'] = 'PREPORUČENO'
                recommended.append(action(f'sync:{appointment.pk}', 'Uskladi količinu budućeg termina', url, item['detail'],
                    kind='sync', appointment_id=appointment.pk, classification='PREPORUČENO'))
            if not resolved['dose_mg'] or Decimal(str(resolved['dose_mg'])) <= 0:
                issue(f'dose:{appointment.pk}', 'Propisana mg doza nije poznata',
                      'Potrebna je ručna potvrda prema nalogu ljekara. Broj bočica nije dokaz mg doze.', url)
            if category == 'appointment' and phase and appointment.lijek_id in (phase.iv_lijek_id, phase.sc_lijek_id):
                result['informational_checks'].append(dict(label='Termin dokumentovane IV/SC prezentacije',
                    detail=f'{appointment.datum:%d.%m.%Y.} · {appointment.lijek} · prezentacija ostaje sačuvana.', classification='INFORMATIVNO'))
            elif appointment.lijek_id != patient.lijek_id:
                issue(f'medicine:{appointment.pk}', 'Termin ranije prezentacije',
                      f'{appointment.datum:%d.%m.%Y.} · {appointment.lijek}. Potvrdite da li taj budući termin još važi.',
                      step('plan', patient, appointment.lijek))
        if active and not patient.lijek.oralna_terapija:
            appointment = active[0]
            resolved = appointment_plan(appointment, fresh=True)
            needed = Decimal(str(resolved['quantity'] or 0))
            own = patient_reservation_breakdown(patient, medicine_ids=patient.lijek.physical_equivalent_ids())['total_effective']
            missing = max(Decimal(0), needed-own)
            from .commission_service import patient_commission_coverage
            coverage = patient_commission_coverage(patient)
            approved = coverage['approved_remaining']
            if approved < needed:
                issue('commission', 'Komisijsko odobrenje za narednu primjenu',
                    f'Preostalo dokazano pravo {approved:g}; naredna primjena {needed:g} jedinica. Provjerite postojeće odobrenje; pravo se ne otvara niti pretpostavlja.',
                    reverse('profil_pacijenta',args=[patient.pk])+'?tab=komisije#komisije')
            result['checks'].append(dict(label='Komisija / odobrenje', ok=approved>=needed,
                url=reverse('profil_pacijenta',args=[patient.pk])+'?tab=komisije#komisije'))
            if missing:
                product = patient.lijek
                position = inventory_position(product, include_planned_need=False)
                item = issue(f'coverage:{product.pk}', 'Zaduženje za narednu primjenu',
                    f'Potrebno {needed:g}; zaduženo {own:g}; nedostaje {missing:g}; slobodno fizički {position["freely_available"]:g}.',
                    reverse('patient_add_allocation', args=[patient.pk]) + '?' + urlencode({'lijek':product.pk}))
                if position['freely_available'] >= missing and not resolved['conflict'] and resolved['dose_mg']:
                    recommended.append(action(f'allocate:{product.pk}',
                        f'Dodijeli {missing:g} {product.jedinica_za_kolicinu(missing)}', item['url'], item['detail'],
                        kind='allocate', medicine_id=product.pk, quantity=str(missing), classification='PREPORUČENO'))
        expected = plan.get('next_date')
        if category == 'interval' and expected and active:
            due = date.fromisoformat(str(expected))
            appointment = active[0]
            if appointment.datum != due:
                item = issue('interval-date', 'Datum budućeg termina',
                    f'Postojeći termin {appointment.datum:%d.%m.%Y.}; prema potvrđenom intervalu {due:%d.%m.%Y.}.',
                    step('interval', patient, patient.lijek))
                if len(active) == 1 and due >= timezone.localdate() and appointment.status == m.Termin.STATUS_PLANIRANA:
                    recommended.append(action(f'move:{appointment.pk}', 'Uskladi datum budućeg termina', item['url'], item['detail'],
                        kind='move', appointment_id=appointment.pk, date=str(due), classification='PREPORUČENO'))
        result['checks'].extend([dict(label='Terapijski plan / put primjene', ok=not any(
            i['id'].startswith(('medicine:', 'dose:', 'order:')) for i in unresolved), url=step('plan', patient, patient.lijek)),
            dict(label='Termin', ok=not any(i['id'].startswith(('medicine:', 'dose:', 'order:', 'quantity:', 'interval-')) for i in unresolved),
                 url=step('interval', patient, patient.lijek)),
            dict(label='Zaduženje', ok=not any(i['id'].startswith(('coverage:', 'stock:')) for i in unresolved),
                 url=step('reservation', patient, patient.lijek))])
    if category in ('therapy', 'home'):
        result['informational_checks'].append(dict(label='Historijski lijek / prezentacija / datum',
            detail=f'{medicine} · {medicine.put_primjene} · {raw.get("event_date", "")}. Današnji plan ne prepisuje historijski događaj.', classification='INFORMATIVNO'))
        if category == 'therapy':
            for protected in (plan.get('accounting') or {}).get('protected_reservations', []):
                result['informational_checks'].append(dict(label=protected['label'], detail='Buduća rezervacija neće biti korištena.', classification='INFORMATIVNO'))
            if raw.get('approval_action') == 'unresolved':
                issue('historical-approval', 'Veza historijskog odobrenja',
                      'Pravo nije ponovo umanjeno. Dokumentovana komisijska veza ostaje za provjeru.',
                      reverse('correction_center')+'?'+urlencode({'section':'history','cc_patient':patient.pk,'cc_medicine':medicine.pk}))
    # Every unresolved finding carries its own direct next step.
    result['safe_next_actions'] = [action(i['id'], i['label'], i['url'], i['detail']) for i in unresolved]
    if category == 'appointment':
        # Moving a date cannot implicitly allocate stock, change a dose or
        # reconcile another appointment. Those are separate reviewed actions.
        result['recommended_changes'] = []
    return serial(result)


def apply_actions(actions, patient, user, operation, reason):
    from .inventory import assign_free_stock_to_patient
    from .therapy_workflow import record_status_history
    for item in actions:
        if item['kind'] == 'allocate':
            assign_free_stock_to_patient(pacijent=patient, lijek=m.Lijek.objects.get(pk=item['medicine_id']),
                quantity=item['quantity'], user=user, reason=reason,
                operation_id=uuid5(UUID(str(operation)), item['id']))
        elif item['kind'] == 'move':
            appointment = m.Termin.objects.get(pk=item['appointment_id'], pacijent=patient, status=m.Termin.STATUS_PLANIRANA)
            from .scheduling import validate_therapy_date
            due = date.fromisoformat(item['date'])
            validate_therapy_date(due, lijek=appointment.lijek)
            from .appointment_reschedule import daily_capacity_issues
            issues, _ = daily_capacity_issues(appointment, due, excluded=[appointment.pk])
            require(not issues, ' '.join(issues))
            require(not m.Termin.objects.filter(pacijent=patient, datum=due, status__in=PENDING).exclude(pk=appointment.pk).exists(),
                    'Na predloženom datumu već postoji termin. Odaberite drugi datum u rasporedu.')
            old = str(appointment.datum)
            appointment.datum = due
            appointment.save(update_fields=['datum'])
            record_status_history(pacijent=patient, termin=appointment, new_status=appointment.status,
                user=user, reason=reason, previous_state={'datum':old}, new_state={'datum':str(due), 'source':'guided_reconciliation'})
        elif item['kind'] == 'sync':
            from .appointment_plan import appointment_plan, save_appointment_plan
            appointment = m.Termin.objects.get(pk=item['appointment_id'], pacijent=patient, status=m.Termin.STATUS_PLANIRANA)
            resolved = appointment_plan(appointment, fresh=True)
            require(resolved['source']=='REGIMEN' and not resolved['conflict'] and resolved['dose_mg'],
                    'Nalog termina nije jednoznačan. Potvrdite dokumentovani nalog prije usklađivanja.')
            save_appointment_plan(appointment, resolved, user=user, reason=reason)


def project(category, patient, medicine, plan, raw, user, primary_adapter):
    """Build the impact graph from actual service effects, then roll it all back."""
    before = state(patient, medicine)
    with preserve_patient(patient), transaction.atomic():
        primary_adapter()
        first = inspect(category, patient, medicine, plan, raw)
        requested = set(raw.get('guided_actions') or [])
        available = {item['id']:item for item in first['recommended_changes']}
        require(requested <= available.keys(), 'Preporuka više nije sigurna ili ne pripada ovom pregledu. Ponovo pregledajte podatke.')
        selected = list(available.values()) if raw.get('apply_recommended') else [available[key] for key in sorted(requested)]
        apply_actions(selected, patient, user, '00000000-0000-0000-0000-000000000001', plan['reason'])
        after = state(patient, medicine)
        final = inspect(category, patient, medicine, plan, raw)
        transaction.set_rollback(True)
    changes, unchanged = [], []
    for key in dict.fromkeys([*before, *after]):
        left, right = before.get(key), after.get(key)
        row = dict(label=(right or left)['label'], before=left['value'] if left else 'Nije evidentirano',
                   after=right['value'] if right else 'Nema aktivnog zapisa', key=key)
        (changes if row['before'] != row['after'] else unchanged).append(row)
    decisions = [dict(item, accepted=item in selected,
                      rejection_reason='' if item in selected else raw.get('rejection_reason') or 'Korisnik nije prihvatio preporuku; nastavak je prikazan.')
                 for item in first['recommended_changes']]
    optional_keys = set()
    for item in selected:
        if item['kind'] == 'allocate':
            optional_keys.update([f'reserved:{item["medicine_id"]}', f'free:{item["medicine_id"]}'])
        elif item['kind'] in ('sync', 'move'):
            optional_keys.add('appointments')
    for item in decisions:
        item['changes'] = [row for row in changes if row['key'] in optional_keys] if item['accepted'] else []
    rows = deepcopy(plan.get('rows') or []) + deepcopy((plan.get('accounting') or {}).get('protected_reservations') or []) + changes
    rows += [dict(label=row['label'], before=row['before'], after=row['after']) for row in unchanged if row['key'] != 'appointments']
    rows.append(dict(label='Audit', before='Dosadašnja historija', after='Bit će kreiran: početno/novo stanje, prihvaćene i odbijene preporuke, korisnik i vrijeme.'))
    graph = dict(primary_change=dict(label=plan['title'], rows=plan.get('rows') or []),
        required_changes=[dict(row, classification='OBAVEZNO') for row in changes if row['key'] not in optional_keys],
        recommended_changes=decisions, informational_checks=final['informational_checks'] + [
            dict(row, classification='INFORMATIVNO', detail='Bez promjene') for row in unchanged],
        unresolved_items=final['unresolved_items'], blocked_actions=[], safe_next_actions=final['safe_next_actions'],
        final_preview=rows, checks=final['checks'], selected_actions=selected, expected_state=after,
        status='Sve povezane evidencije su usklađene.' if not final['unresolved_items'] else
               f'Ostale su {len(final["unresolved_items"])} stavke koje zahtijevaju pažnju.')
    return serial(graph)
