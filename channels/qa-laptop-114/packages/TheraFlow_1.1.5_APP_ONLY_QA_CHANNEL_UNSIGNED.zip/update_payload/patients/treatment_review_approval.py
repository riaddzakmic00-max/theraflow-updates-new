"""Read approval metadata without borrowing a patient's newer agreement."""
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q

from .commission_receiving import normalize_agreement_number
from .models import Komisija, PacijentSaglasnost


class TreatmentReviewApprovalError(ValidationError):
    @property
    def user_message(self):
        return " ".join(self.messages)


def approval_document_values(commission, *, required=False):
    """Late entries apply only to their explicit source approval.

    vazi_od is the agreement's 'U upotrebi od' date, never the approval date.
    A commission's legacy number is a fallback when no linked version exists.
    """
    number = ""
    if commission:
        agreement = PacijentSaglasnost.objects.filter(
            pacijent_id=commission.pacijent_id,
        ).filter(
            Q(izvorna_komisija=commission)
            | Q(izvorna_komisija__isnull=True, izvorno_trebovanje__komisija=commission)
        ).order_by("-izmijenjeno", "-pk").first()
        number = normalize_agreement_number(
            agreement.broj_saglasnosti if agreement else commission.broj_saglasnosti
        )
    if required and not number:
        if commission:
            raise TreatmentReviewApprovalError(
                f"Za lijek „{commission.lijek.brand_name}“, odobrenje od "
                f"{commission.datum_odobrenja:%d/%m/%Y}, nedostaje broj saglasnosti. "
                "Dopunite broj za to odobrenje prije generisanja razduženja."
            )
        raise TreatmentReviewApprovalError(
            "Razduženje nema pouzdano povezano odobrenje. Provjerite pripadajuću saglasnost."
        )
    return {
        "broj_saglasnosti": number,
        "datum_odobrenja": commission.datum_odobrenja.strftime("%d/%m/%Y") if commission else "",
    }


def treatment_review_commission(patient, therapy=None, *, commission_id=None):
    """Use the recorded consumption link; never choose the latest for history."""
    commissions = Komisija.objects.filter(pacijent=patient).select_related("lijek")
    selected = None
    if commission_id:
        selected = commissions.filter(pk=commission_id).exclude(status="PONISTENA").first()
        if not selected:
            raise TreatmentReviewApprovalError("Odabrano odobrenje ne pripada ovom pacijentu ili je poništeno.")
        if not therapy:
            return selected
    if therapy:
        changes = (therapy.workflow_snapshot or {}).get("komisijske_promjene", [])
        ids = {item["komisija_id"] for item in changes
               if item.get("komisija_id") and Decimal(str(item.get("kolicina") or 0)) > 0}
        if len(ids) > 1:
            raise TreatmentReviewApprovalError(
                "Terapija je razdužena iz više odobrenja. Potrebni su odvojeni dokumenti po saglasnosti."
            )
        if ids:
            if selected and selected.pk not in ids:
                raise TreatmentReviewApprovalError("Odabrano odobrenje nije povezano s ovom terapijom.")
            commission = commissions.filter(pk=next(iter(ids))).first()
            if not commission:
                raise TreatmentReviewApprovalError("Povezano odobrenje terapije nije dostupno za ovog pacijenta.")
            return commission
        # Older imports may lack the workflow link. Only a single eligible
        # approval is unambiguous; a later active approval cannot replace it.
        candidates = list(commissions.filter(
            lijek=therapy.lijek, datum_odobrenja__lte=therapy.datum,
        ).exclude(status="PONISTENA")[:2])
        if selected:
            if selected.lijek_id != therapy.lijek_id or selected.datum_odobrenja > therapy.datum:
                raise TreatmentReviewApprovalError("Odabrano odobrenje ne odgovara lijeku i datumu terapije.")
            return selected
    else:
        candidates = list(commissions.filter(lijek=patient.lijek, status="AKTIVNA")[:2])
        if not candidates:
            candidates = list(commissions.filter(lijek=patient.lijek).exclude(status="PONISTENA")[:2])
    if len(candidates) != 1:
        raise TreatmentReviewApprovalError(
            "Nije moguće jednoznačno odrediti odobrenje za razduženje. "
            "Provjerite vezu terapije i pripadajuće saglasnosti."
        )
    return candidates[0]


@transaction.atomic
def link_existing_agreement(*, patient, agreement_id, commission, user):
    """Explicit card correction; preserve the existing agreement and approval IDs."""
    if commission.pacijent_id != patient.pk:
        raise ValueError("Odobrenje ne pripada ovom pacijentu.")
    agreement = PacijentSaglasnost.objects.select_for_update().filter(
        pk=agreement_id, pacijent=patient,
    ).first()
    if not agreement:
        raise ValueError("Odabrana saglasnost ne pripada ovom pacijentu.")
    previous_id = agreement.izvorna_komisija_id
    latest = PacijentSaglasnost.objects.filter(izvorna_komisija=commission, pacijent=patient).order_by("-izmijenjeno", "-pk").first()
    if previous_id == commission.pk and latest and latest.pk == agreement.pk:
        return agreement, False
    agreement.izvorna_komisija = commission
    agreement.izmijenio = user
    agreement.save(update_fields=["izvorna_komisija", "izmijenio", "izmijenjeno"])
    from .utils import upisi_log
    upisi_log(user, "Povezivanje broja saglasnosti s odobrenjem", pacijent=patient,
              objekat=agreement, opis=f"Saglasnost {agreement.broj_saglasnosti}: odobrenje {previous_id} → {commission.pk}. Sačuvani PDF dokumenti nisu izmijenjeni.")
    return agreement, True
