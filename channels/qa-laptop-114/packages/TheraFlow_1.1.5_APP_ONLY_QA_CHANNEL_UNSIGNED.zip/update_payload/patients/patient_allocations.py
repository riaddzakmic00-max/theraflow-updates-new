"""Patient-card projection over the existing presentation-specific inventory."""
from decimal import Decimal
from django.db.models import F

from . import models as m
from .inventory import free_stock_quantity, patient_allocation_product_ids
from .medication_groups import medicine_group, medicine_presentation_key


def prescribed_products(patient):
    phase = patient.aktivni_fazni_protokol()
    if phase:
        return {patient.lijek_id, phase.iv_lijek_id, phase.sc_lijek_id} - {None}
    candidate_ids = patient_allocation_product_ids(patient)
    if len(candidate_ids) <= 1:
        return candidate_ids
    # Legacy cards need no clinical protocol conversion just to reserve a
    # parallel presentation. Prefer the patient's SKU, then a stocked SKU for
    # each compatible presentation; aliases stay in the existing inventory pool.
    candidates = list(m.Lijek.objects.filter(pk__in=candidate_ids)
        .order_by(F('zaliha__u_frizideru').desc(nulls_last=True), 'pk'))
    if patient.lijek_id:
        candidates.sort(key=lambda medicine: medicine.pk != patient.lijek_id)
    products = {}
    for medicine in candidates:
        products.setdefault(medicine_presentation_key(medicine), medicine.pk)
    return set(products.values())


def compatible_presentations(patient):
    return m.Lijek.objects.filter(pk__in=prescribed_products(patient)).order_by('put_primjene', 'naziv', 'pk')


def allocation_rows(patient, reservations=None):
    reservations = list(reservations if reservations is not None else
        m.PacijentRezervacija.objects.filter(pacijent=patient, aktivno=True, kolicina__gt=0)
        .select_related('lijek').order_by('pk'))
    compatible = prescribed_products(patient)
    ids = compatible | {r.lijek_id for r in reservations}
    # The card already fetched the current product and reservation products.
    # Reuse those instances; only the missing parallel presentation needs a read.
    medicines = {r.lijek_id: r.lijek for r in reservations}
    if patient.lijek_id:
        medicines[patient.lijek_id] = patient.lijek
    missing = ids - medicines.keys()
    if missing:
        medicines.update((medicine.pk, medicine) for medicine in
            m.Lijek.objects.filter(pk__in=missing).select_related('terapijski_program'))
    rows = []
    for medicine in sorted(medicines.values(), key=lambda item: (item.put_primjene, item.naziv, item.pk)):
        rows.append(dict(medicine=medicine, route=medicine.put_primjene,
            group=medicine_group(medicine).label,
            quantity=sum((r.kolicina for r in reservations if r.lijek_id == medicine.pk), Decimal(0)),
            free=free_stock_quantity(medicine), can_assign=medicine.pk in compatible))
    return rows
