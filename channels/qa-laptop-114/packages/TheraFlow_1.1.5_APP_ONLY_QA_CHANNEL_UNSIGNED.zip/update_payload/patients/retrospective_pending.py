"""September facts saved now, inventory/approval attribution reviewed separately.

This is a mode of RetrospectiveEvent, not a second inventory ledger. A pending
event has NO stock movement, commission consumption or reservation consumption.
Only a real therapy is added to the clinical history. Its unresolved accounting
must remain visible; a count is never silently reclassified as a receipt.
"""
from decimal import Decimal
from django.db import transaction
from django.utils import timezone
from . import models as m
from .data_corrections import require, serial, captured_rows, differences

MODE = 'september_pending'
EXPLICIT_MODE = 'explicit_effects'
TITLES = {'therapy': 'Primijenjena terapija', 'receipt': 'Pristigli lijek'}


def is_pending(event):
    return event.effects.get('entry_mode') in (MODE, EXPLICIT_MODE)


def normalize(raw):
    from . import retrospective_events as e
    kind = raw.get('kind'); require(kind in TITLES, 'Odaberite primijenjenu terapiju ili pristigli lijek.')
    when = e.day(raw.get('event_date'))
    mode = raw.get('entry_mode', MODE)
    require(mode in (MODE, EXPLICIT_MODE), 'Nepoznat način naknadnog unosa.')
    require(when <= timezone.localdate() and (mode == EXPLICIT_MODE or (when.year == 2026 and when.month == 9)),
            'Stvarni datum ne može biti u budućnosti; septembarski obrazac prihvata septembar 2026.')
    require(mode != EXPLICIT_MODE or kind == 'therapy', 'Komisijski prijem unesite kroz postojeći detaljni prijem s isporukom i raspodjelom.')
    patient = e.chosen(m.Pacijent, raw.get('patient_id'), 'pacijenta')
    selected = e.chosen(m.Lijek, raw.get('selected_medicine_id') or raw.get('medicine_id'), 'lijek')
    medicine = selected
    if kind == 'therapy' and mode != EXPLICIT_MODE:
        from .retrospective_history import patient_at
        from .medicine_registry import patient_product_for_selection
        try:
            historical = patient_at(patient, when)
            medicine = patient_product_for_selection(historical, selected) or selected
        except ValueError:
            # The entered actual product stays explicit; its disputed link is
            # reviewed later, not replaced with today's inferred treatment.
            pass
    quantity = e.amount(raw.get('quantity'))
    note = str(raw.get('note', '')).strip()
    require(5 <= len(note) <= 2000, 'Unesite napomenu i razlog naknadnog unosa (5–2000 znakova).')
    batch = str(raw.get('batch', '')).strip()
    expires = e.day(raw.get('expires'), optional=True)
    require(len(batch) <= 100 and (not expires or batch and expires >= when),
            'Provjerite seriju i rok; nepoznate podatke ostavite prazne.')
    from . import retrospective_accounting as accounting
    effects = accounting.normalize(raw) if kind == 'therapy' else {}
    actual_route = raw.get('actual_route')
    if actual_route:
        from .late_event_sources import event_route
        require(mode == EXPLICIT_MODE and actual_route == event_route(medicine),
            'Put primjene ne odgovara obliku odabranog lijeka.')
    dose = e.amount(raw['dose_mg']) if raw.get('dose_mg') else None
    return dict(entry_mode=mode, kind=kind, event_date=str(when), patient_id=patient.pk,
        medicine_id=medicine.pk, selected_medicine_id=selected.pk, quantity=str(quantity),
        note=note, batch=batch, expires=str(expires or ''),
        **({'actual_route':actual_route} if actual_route else {}),
        **({'dose_mg':str(dose)} if dose else {}), **effects)


def guard_duplicate(data):
    from .retrospective_events import day
    from .inventory_corrections import receipt_date
    medicine = m.Lijek.objects.get(pk=data['medicine_id'])
    ids = medicine.equivalent_ids(); when = day(data['event_date']); quantity = Decimal(data['quantity'])
    query = m.RetrospectiveEvent.objects.filter(kind=data['kind'], medicine_id__in=ids,
        event_date=when, reversed_at__isnull=True)
    if data['kind'] == 'therapy':
        query = query.filter(patient_id=data['patient_id'])
        existing = m.Terapija.objects.filter(pacijent_id=data['patient_id'], lijek_id__in=ids,
            datum=when, workflow_status=m.Terapija.STATUS_POTVRDJENA,
            tip_evidencije=m.Terapija.TIP_AMBULANTA).exists()
    else:
        # Pending deliveries cannot yet prove distinct allocation sources. Same
        # date/product/quantity across patients is a possible shared delivery.
        query = query.filter(quantity=quantity)
        existing = any(receipt_date(tx) == when for tx in m.ZalihaTransakcija.objects.filter(
            lijek_id__in=ids, tip='ZAPRIMANJE', kolicina=quantity))
    require(not query.exists() and not existing,
            'Mogući duplikat: ovaj događaj već postoji. Otvorite postojeću evidenciju; ne knjižite ga ponovo.')


def guard_normal_entry(data):
    """The detailed flow may not post a previously saved pending fact again."""
    medicine = m.Lijek.objects.get(pk=data['medicine_id'])
    query = m.RetrospectiveEvent.objects.filter(effects__entry_mode__in=(MODE, EXPLICIT_MODE),
        reversed_at__isnull=True, kind=data['kind'], medicine_id__in=medicine.equivalent_ids(),
        event_date=data['event_date'])
    if data['kind'] == 'receipt':query = query.filter(quantity=data['quantity'])
    else:query = query.filter(patient_id=data['patient_id'])
    require(not query.exists(), 'Događaj je već sačuvan i čeka usklađivanje. Otvorite postojeću evidenciju, bez ponovnog unosa.')


def preview(raw, user):
    from .retrospective_events import authorize
    from .retrospective_batches import quantities
    authorize(user); data = normalize(raw); guard_duplicate(data)
    patient = m.Pacijent.objects.get(pk=data['patient_id']); medicine = m.Lijek.objects.get(pk=data['medicine_id'])
    state = quantities(patient, medicine)
    counts = list(m.PhysicalStockCorrection.objects.filter(lijek_id__in=medicine.equivalent_ids(),
        pregled__event_date='2026-09-30').order_by('pk'))
    delta = Decimal(data['quantity']) * (1 if data['kind'] == 'receipt' else -1)
    rows = [{'label':label,'before':state[key],'after':state[key]} for label,key in (
        ('Današnja fizička zaliha ambulante','physical'),('Današnja rezervacija pacijenta','reserved'),
        ('Evidentirana kućna količina','home'),('Preostalo odobreno pravo — čeka usklađivanje','right'))]
    result = serial(dict(data=data,title=TITLES[data['kind']],patient=str(patient),medicine=str(medicine),
        quantity=data['quantity'],unit=medicine.jedinica_zalihe_za_kolicinu(data['quantity']),
        event_date=data['event_date'],rows=rows,accounting_status='Čeka usklađivanje',
        factual_delta=delta,current_delta=0,counts=[dict(id=c.pk,total=c.nova_kolicina,delta=c.razlika) for c in counts],
        warnings=[
            'Događaj će biti sačuvan sa stvarnim datumom. Veza s prijemom, rezervacijom i odobrenjem čeka usklađivanje.',
            'Današnje stanje i rezervacija neće se povećavati niti umanjivati. Popis od 30.09. provjerava se odvojeno; nema drugog oduzimanja već prebrojane količine.',
            'Preostalo pravo trenutno nije konačno usklađeno s ovim događajem. Nije dodijeljeno novo pravo niti izmišljen prijem.',
            'Sačuvani popis od 30.09. je kontrolna tačka, a ne potvrda izvora ove jedinice.' if counts else
            'Popis od 30.09. nije pronađen za ovaj lijek. Zaliha ostaje nepromijenjena; potreban je kasniji pregled izvora i stanja.']))
    if data['kind']=='therapy':
        from . import retrospective_accounting as accounting
        effect=accounting.plan(data)
        result.update(accounting=effect,rows=effect['rows'],current_delta=effect['stock_delta'],
            choice_label=effect['choice_label'],accounting_status='Čeka usklađivanje odobrenja' if
            data['approval_action']=='unresolved' else 'Usklađeno prema odabranom učinku',
            warnings=effect['warnings']+['Kontrolni popis ostaje sačuvan. Ne knjiži se kompenzacijski prijem.'])
    return result


@transaction.atomic
def apply_plan(plan, user, operation_id, backup):
    if plan['data']['kind']=='therapy':
        from .retrospective_accounting import apply
        return apply(plan,user,operation_id,backup)
    from .retrospective_events import authorize
    from .utils import upisi_log
    authorize(user); data = normalize(plan['data']); guard_duplicate(data)
    before = captured_rows()
    therapy = None
    if data['kind'] == 'therapy':
        therapy = m.Terapija.objects.create(pacijent_id=data['patient_id'],lijek_id=data['medicine_id'],
            datum=data['event_date'],kolicina=data['quantity'],serija=data['batch'],evidentirao=user,
            workflow_snapshot={'retrospective_pending':True,'operation_id':str(operation_id),
                'accounting_status':'PENDING','inventory_effect':'0','note':data['note']})
    old,new = differences(before,captured_rows())
    event = m.RetrospectiveEvent.objects.create(operation_id=operation_id,kind=data['kind'],
        patient_id=data['patient_id'],medicine_id=data['medicine_id'],event_date=data['event_date'],
        quantity=data['quantity'],note=data['note'],user=user,therapy=therapy,backup=backup,
        effects=serial({'entry_mode':MODE,'reconciliation_status':'PENDING','preview':plan,
            'before':old,'after':new,'current_stock_delta':'0','reservation_delta':'0'}))
    upisi_log(user,'Naknadna evidencija — čeka usklađivanje',pacijent=event.patient,objekat=event,
        opis=f'{TITLES[event.kind]} {event.event_date}: {event.quantity} {event.medicine}. {event.note}')
    return event


def reversal_preview(event, user, reason):
    if event.effects.get('accounting_version'):
        from .retrospective_accounting import reversal_preview as preview
        return preview(event,user,reason)
    from .retrospective_events import authorize
    from .retrospective_batches import quantities
    authorize(user)
    require(not event.reversed_at and event.effects.get('reconciliation_status') == 'PENDING',
            'Ovaj događaj je već poništen ili povezan. Potrebna je provjera njegovih kasnijih veza.')
    require(5 <= len(reason.strip()) <= 500, 'Unesite razlog poništavanja (5–500 znakova).')
    require(not event.movements.exists() and not event.request_id and not event.issue_id and not event.stock_correction_id,
            'Događaj ima naknadno povezane promete; ne može se poništiti kao nepovezan unos.')
    # Every original changed domain record must still have the saved values.
    now = captured_rows()
    for table,records in event.effects.get('after',{}).items():
        for pk,values in records.items():
            require(now.get(table,{}).get(pk)==values,'Zapis je naknadno izmijenjen. Pregledajte povezanu historiju.')
    state = quantities(event.patient,event.medicine)
    return serial(dict(event_id=event.pk,title='Poništi naknadni unos',reason=reason.strip(),rows=[
        dict(label='Današnja fizička zaliha ambulante',before=state['physical'],after=state['physical']),
        dict(label='Današnja rezervacija pacijenta',before=state['reserved'],after=state['reserved'])],
        warnings=['Originalni događaj ostaje u historiji kao poništen. Zaliha, rezervacija i pravo se ne mijenjaju.']))


@transaction.atomic
def apply_reversal(event, user, plan, backup):
    if event.effects.get('accounting_version'):
        from .retrospective_accounting import reverse
        return reverse(event,user,plan,backup)
    from .utils import upisi_log
    reversal_preview(event,user,plan['reason']); before=captured_rows()
    if event.therapy_id:
        therapy=event.therapy
        therapy.workflow_status=m.Terapija.STATUS_PONISTENA
        therapy.ponistena_at=timezone.now();therapy.ponistio=user;therapy.razlog_ponistavanja=plan['reason']
        therapy.save(update_fields=['workflow_status','ponistena_at','ponistio','razlog_ponistavanja'])
    old,new=differences(before,captured_rows())
    event.reversed_at=timezone.now();event.reversed_by=user;event.reversal_reason=plan['reason']
    event.reversal_effects=serial({'preview':plan,'before':old,'after':new,'backup':backup})
    event.save(update_fields=['reversed_at','reversed_by','reversal_reason','reversal_effects'])
    upisi_log(user,'Poništen naknadni unos koji čeka usklađivanje',pacijent=event.patient,objekat=event,opis=plan['reason'])
    return event


def count_review(medicine):
    """Separate read-only review. A matching balance does not prove ownership."""
    from .retrospective_reconciliation import dated_movements
    from datetime import date
    records = list(m.RetrospectiveEvent.objects.filter(medicine=medicine,effects__entry_mode=MODE,
        reversed_at__isnull=True).select_related('patient','user').order_by('event_date','pk'))
    net = sum((e.quantity if e.kind=='receipt' else -e.quantity for e in records),Decimal(0))
    counts = list(m.PhysicalStockCorrection.objects.filter(lijek=medicine,
        pregled__event_date='2026-09-30').order_by('pk'))
    total = sum((delta for tx,delta in dated_movements(m.ZalihaTransakcija.objects.filter(
        lijek=medicine,datum__lte=date(2026,9,30))) if not (
        tx.referenca_tip=='PhysicalStockCorrection' and tx.referenca_id in {c.pk for c in counts})),Decimal(0))
    return dict(medicine=medicine,events=records,counts=counts,ledger_without_count=total,pending_delta=net,
        explained=total+net,comparisons=[dict(count=c,unexplained=c.nova_kolicina-total-net) for c in counts])
