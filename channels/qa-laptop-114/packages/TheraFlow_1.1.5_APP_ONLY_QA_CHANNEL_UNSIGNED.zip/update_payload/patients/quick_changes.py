"""Preview/confirm services for nursing quick actions, with one atomic receipt."""
from datetime import date, timedelta
from decimal import Decimal, ROUND_CEILING
import hashlib
import json
import re
import uuid

from django.core import signing
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone

from . import models as m
from .regimen_changes import regimen_override, next_regimen_date

SALT = "theraflow.quick-change.v1"


def authorize(user):
    from dashboard.permissions import je_terapijski_tim
    if not (user.is_active and je_terapijski_tim(user)):
        raise PermissionDenied("Brze izmjene dostupne su sestri, ljekaru, koordinatoru i administratoru TheraFlowa.")


def require(condition, message):
    if not condition:
        raise ValidationError(message)


def amount(value):
    try:
        value = Decimal(str(value))
        require(value.is_finite() and value > 0, "Količina mora biti veća od nule.")
        return value
    except (ArithmeticError, TypeError, ValueError):
        raise ValidationError("Unesite ispravnu pozitivnu količinu.") from None


def medicine_mg(medicine):
    if medicine.jacina_mg:
        return Decimal(str(medicine.jacina_mg))
    # Read presentation metadata, never a medicine-name mapping. Only explicit
    # mg per unit; concentration-only strings do not establish container size.
    match = re.fullmatch(r"\s*(\d+(?:[.,]\d+)?)\s*mg\s*", medicine.strength or "", re.I)
    return Decimal(match[1].replace(",", ".")) if match else None


def current_regimen(patient, on=None, *, protocol_step=None):
    from .individual_protocols import get_current_step, get_interval_weeks
    on = on or timezone.localdate()
    medicine = patient.lijek
    phase = patient.aktivni_fazni_protokol()
    if protocol_step:
        require(protocol_step == 'maintenance' and phase is not None
            and phase.faza in (phase.FAZA_CEKA_PRVU_SC, phase.FAZA_ODRZAVANJE)
            and patient.lijek_id == phase.sc_lijek_id, 'Odaberite SC održavanje iz aktivnog faznog protokola.')
    if medicine.oralna_terapija:
        regimen = m.OralniTerapijskiRezim.objects.filter(pacijent=patient, lijek=medicine,
            datum_od__lte=on).filter(m.models.Q(datum_do__isnull=True) | m.models.Q(datum_do__gte=on)).order_by("-datum_od", "-pk").first()
        require(regimen is not None, "Prvo potvrdite početni oralni režim u kartonu. Brza izmjena mijenja postojeći režim.")
        units = regimen.tableta_po_uzimanju
        return {"broj_jedinica": str(units), "doza_mg": str(units * medicine_mg(medicine)) if medicine_mg(medicine) else None,
                "uzimanja_dnevno": regimen.uzimanja_dnevno, "oral_regimen_id": regimen.pk}
    if phase:
        from .phased_protocols import current_phase_details
        if protocol_step:
            require(protocol_step == 'maintenance' and phase.faza in (phase.FAZA_CEKA_PRVU_SC, phase.FAZA_ODRZAVANJE)
                and patient.lijek_id == phase.sc_lijek_id, 'Odaberite SC održavanje iz prikazanih koraka protokola.')
            details = current_phase_details(phase, on)
            if phase.faza == phase.FAZA_CEKA_PRVU_SC:
                # Read the maintenance base interval without creating a fake
                # phase object that can contaminate Django's reverse-FK cache.
                details = {**details, 'interval_weeks': phase.interval_odrzavanja_sedmica}
        else:
            require(phase.faza == phase.FAZA_ODRZAVANJE,
                "Indukcija i prijelaz IV → SC imaju više koraka. Promijenite konkretan korak kroz Postavke faznog protokola.")
            details = current_phase_details(phase, on)
        result = {"broj_jedinica": str(details["units"]), "doza_mg": str(details["dose_mg"]), "interval_sedmica": details["interval_weeks"]}
    else:
        step = get_current_step(patient, on)
        from .individual_protocols import resolve_patient_protocol
        selection = resolve_patient_protocol(patient)
        require(not patient.protokol_za_potvrdu and not (selection.warning and not selection.protocol),
                "Novi protokol čeka potvrdu ljekara. Otvorite Individualni protokol.")
        require(not step or step.faza == step.FAZA_ODRZAVANJE,
                "Aktivna indukcija ima različite korake. Otvorite Individualni protokol za promjenu konkretnog koraka.")
        from .individual_protocols import get_units_per_application
        units = get_units_per_application(patient, on)
        mg = getattr(step, "doza_mg", None)
        if medicine_mg(medicine) and units:
            mg = mg or units * medicine_mg(medicine)
        result = {"broj_jedinica": str(units), "doza_mg": str(mg) if mg else None, "interval_sedmica": get_interval_weeks(patient, on)}
    require(not protocol_step or phase is not None, 'Odabrani korak nema aktivan fazni protokol.')
    result.update(regimen_override(patient, on, phase_scope=phase.FAZA_ODRZAVANJE if protocol_step else None))
    return result


def transfer_sources(patient):
    return m.PacijentRezervacija.objects.filter(pacijent=patient, lijek_id=patient.lijek_id,
        aktivno=True, kolicina__gt=0, potrosena_at__isnull=True).select_related("migracijski_snapshot", "trebovanje", "komisija").order_by("datum_rezervacije", "pk")


def source_evidence(reservation):
    evidence = {"reservation_id": reservation.pk, "medicine_id": reservation.lijek_id,
        "snapshot_id": reservation.migracijski_snapshot_id, "commission_id": reservation.komisija_id,
        "request_id": reservation.trebovanje_id, "initial_balance_id": reservation.migracijsko_pocetno_stanje_id,
        "appointment_id": reservation.termin_id, "pending_need_id": reservation.potreba_fizickog_pokrica_id}
    incoming = m.BrzaIzmjenaPacijenta.objects.filter(odredisna_rezervacija=reservation, vrsta="transfer").first()
    if incoming:
        evidence.update(incoming_transfer_id=incoming.pk, original_source=incoming.izvor)
        for name in ("serija", "rok_trajanja"):
            if incoming.izvor.get(name):
                evidence[name] = incoming.izvor[name]
    # Exact existing receipt links only. Multiple deliveries on the same day
    # remain separate; a date/quantity match is never a provenance link.
    evidence['receipt_links'] = [
        {'audit_id':a.pk,'movement_id':a.fizicka_transakcija_id,'reservation_id':a.rezervacija_id,
         'request_id':a.trebovanje_id,'cycle_id':a.komisijski_ciklus_id,'quantity':str(a.zaprimljena_kolicina)}
        for a in m.EvidencijaSaglasnostiZaprimanja.objects.filter(
            rezervacija=reservation,fizicka_transakcija__isnull=False).order_by('pk')]
    lots = set(m.ZalihaTransakcija.objects.filter(raspodjele_prijema__rezervacija=reservation)
        .values_list('serija', 'rok_trajanja'))
    from .patient_fridge_corrections import allocation_basis
    linked, basis, assignment = allocation_basis(reservation)
    if linked and basis is not None:
        lots.add((assignment.serija, assignment.rok_trajanja))
        evidence['patient_stock_correction_id'] = assignment.korekcija_id
        evidence['physical_source_id'] = assignment.izvorna_transakcija_id
    if len(lots) == 1:
        batch, expiry = next(iter(lots))
        evidence.update(serija=batch, rok_trajanja=str(expiry) if expiry else '')
    evidence['mixed_lots'] = len(lots) > 1
    opening = m.ZalihaTransakcija.objects.filter(lijek_id=reservation.lijek_id,
        tip=m.ZalihaTransakcija.TIP_POCETNO_STANJE_MIGRACIJE,
        referenca_tip="MigracijskiSnapshotPacijenta", referenca_id=reservation.migracijski_snapshot_id,
        lokacija=m.ZalihaTransakcija.LOKACIJA_FRIZIDER).first() if reservation.migracijski_snapshot_id else None
    evidence["opening_transaction_id"] = opening.pk if opening else None
    # Preserve recorded lot attributes when the source model has them. Home
    # dispensing is deliberately never used as a source of clinic inventory.
    for obj in (reservation, reservation.trebovanje, reservation.komisija):
        if obj:
            for name in ("serija", "rok_trajanja"):
                value = getattr(obj, name, None)
                if value:
                    evidence[name] = str(value)
    return evidence


def state_fingerprint(patient, recipient=None):
    ids = sorted({patient.pk} | ({recipient.pk} if recipient else set()))
    state = {}
    for model, query in (
        (m.Pacijent, {"pk__in": ids}),
        (m.Lijek, {"pk": patient.lijek_id}),
        (m.TerapijskiProtokol, {"lijek_id": patient.lijek_id}),
        (m.TerapijskiKorakProtokola, {"protokol__lijek_id": patient.lijek_id}),
        (m.Zaliha, {"lijek_id": patient.lijek_id}),
        (m.ZalihaTransakcija, {"lijek_id": patient.lijek_id}),
        (m.PacijentRezervacija, {"lijek_id": patient.lijek_id}),
        (m.EvidencijaSaglasnostiZaprimanja, {"pacijent_id__in": ids}),
        (m.Trebovanje, {"pacijent_id__in": ids}),
        (m.BrzaIzmjenaPacijenta, {"pacijent_id__in": ids}),
        (m.OralniTerapijskiRezim, {"pacijent_id__in": ids}),
        (m.IndividualniProtokolPacijenta, {"pacijent_id__in": ids}),
        (m.IndividualniKorakProtokola, {"protokol__pacijent_id__in": ids}),
        (m.MigracijskiSnapshotPacijenta, {"pacijent_id__in": ids}),
        (m.Komisija, {"pacijent_id__in": ids}),
        (m.FazniProtokolPacijenta, {"pacijent_id__in": ids}),
        (m.Termin, {"pacijent_id__in": ids}),
        (m.Terapija, {"pacijent_id__in": ids}),
        (m.KucnaTerapijaPodatak, {"pacijent_id__in": ids}),
        (m.PotrebaFizickogPokrica, {"lijek_id": patient.lijek_id}),
    ):
        state[model._meta.label] = list(model.objects.filter(**query).order_by("pk").values())
    return hashlib.sha256(json.dumps(state, sort_keys=True, default=str).encode()).hexdigest()


def preview(patient, kind, data, user):
    authorize(user)
    if kind == 'transfer':
        from dashboard.permissions import authorize_transfer as administrator
        administrator(user)
    require(patient.lijek_id, "Pacijent nema odabranu prezentaciju lijeka.")
    require(kind in {"interval", "dose", "transfer"}, "Nepoznata radnja.")
    reason = str(data.get("razlog", "")).strip()
    require(3 <= len(reason) <= 500, "Unesite kratak razlog, najmanje 3 znaka; za režim navedite nalog ljekara.")
    result = {"kind": kind, "patient_id": patient.pk, "medicine_id": patient.lijek_id,
              "reason": reason, "rows": [], "impacts": [], "patch": {}}
    if data.get('previous_change'):
        previous=m.BrzaIzmjenaPacijenta.objects.filter(pk=data['previous_change'],pacijent=patient,vrsta=kind,lijek_id=patient.lijek_id).first()
        require(previous is not None and kind in ('interval','dose'),'Odaberite postojeću promjenu istog režima iz historije.')
        require(not m.BrzaIzmjenaPacijenta.objects.filter(izvor__previous_change=previous.pk).exists(),
            'Ova odluka je već ispravljena; otvorite posljednju povezanu korekciju u historiji.')
        result['previous_change']=previous.pk
        result['impacts'].append(f'Nova povezana odluka ispravlja #{previous.pk}. Originalna odluka i stvarne primjene ostaju sačuvane.')
    row = lambda label, old, new: result["rows"].append({"label": label, "before": str(old) if old is not None else "Nije evidentirano", "after": str(new) if new is not None else "Nije evidentirano"})
    medicine = patient.lijek
    if kind == "transfer":
        from dashboard.permissions import je_admin
        administrative=je_admin(user)
        recipient = m.Pacijent.objects.filter(pk=data.get("primalac"), aktivan=True).first()
        require(recipient and recipient.pk != patient.pk, "Odaberite drugog aktivnog pacijenta.")
        require(recipient.lijek_id == medicine.pk,
                "Prijenos zahtijeva istu prezentaciju: lijek, jačinu, oblik i put primjene. IV i SC nisu zamjenjivi.")
        source = transfer_sources(patient).filter(pk=data.get("rezervacija")).first()
        require(source, "Odabrana rezervacija nije neiskorištena fizička količina ovog kartona u ambulanti.")
        if data.get('previous_transfer'):
            previous = m.BrzaIzmjenaPacijenta.objects.filter(pk=data['previous_transfer'], vrsta='transfer').first()
            require(previous and previous.primalac_id == patient.pk and previous.pacijent_id == recipient.pk
                    and previous.odredisna_rezervacija_id == source.pk,
                    'Prethodni prijenos ne odgovara ovim pacijentima i konkretnoj rezervaciji.')
            require(not m.BrzaIzmjenaPacijenta.objects.filter(izvor__previous_transfer=previous.pk).exists(),
                    'Ovaj prijenos je već ispravljen. Pregledajte posljednju korekciju u historiji.')
            result['previous_transfer'] = previous.pk
        quantity = amount(data.get("kolicina"))
        require(quantity == quantity.to_integral_value(), "Prenesite cijele fizičke jedinice lijeka, ne pakovanja niti dio bočice/pena.")
        require(quantity <= source.kolicina, f"Dostupno je {source.kolicina:g} {medicine.jedinica_za_kolicinu(source.kolicina)} u odabranoj rezervaciji.")
        stock = m.Zaliha.objects.filter(lijek=medicine).first()
        reserved = m.PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True).aggregate(n=Sum("kolicina"))["n"] or Decimal(0)
        require((administrative and stock and stock.u_frizideru >= 0) or (stock and stock.u_frizideru >= reserved and stock.u_frizideru >= quantity),
                "Fizički saldo ne pokriva postojeće rezervacije. Prvo provjerite brojanje i porijeklo u Zalihama.")
        from .inventory import izracunaj_frizider_iz_transakcija
        from .migration_service import migration_inventory_summary
        require(administrative or izracunaj_frizider_iz_transakcija(medicine) == stock.u_frizideru,
                "Prikazani saldo se razlikuje od evidencije zaliha. Prvo provjerite porijeklo i brojanje u Zalihama.")
        from .inventory_trace import explicit_receipt_basis
        has_receipt_links, receipt_quantity = explicit_receipt_basis(source)
        if has_receipt_links:
            proven = receipt_quantity is not None and receipt_quantity >= source.kolicina
        else:
            proven = any(detail["rezervacija"].pk == source.pk and detail["porijeklo_potvrdjeno"]
                for item in migration_inventory_summary() for detail in item["reservation_details"])
        require(administrative or proven, "Porijeklo odabrane fizičke rezervacije nije potvrđeno. Otvorite Zalihe → porijeklo rezervacija i prvo razriješite izvor.")
        evidence = source_evidence(source)
        if administrative and not proven:
            evidence['origin_status']='Porijeklo nije utvrđeno'
            result['impacts'].append('Upozorenje: porijeklo nije utvrđeno. Prenosi se postojeće zaduženje bez izmišljanja prijema, serije ili prava.')
        if administrative and stock.u_frizideru < reserved:
            result['impacts'].append(f'Fizički manjak: fizički {stock.u_frizideru}, rezervisano {reserved}. Ukupno rezervisano ostaje isto; zasebno provjerite popis.')
        require(not evidence['mixed_lots'], 'Rezervacija obuhvata više serija. Prvo razjasnite koje tačne jedinice i serija se prenose; sistem ih ne bira proizvoljno.')
        require(not evidence.get("rok_trajanja") or date.fromisoformat(evidence["rok_trajanja"]) >= timezone.localdate(), "Izvoru je istekao rok trajanja; nije raspoloživ za prijenos.")
        totals = lambda who: m.PacijentRezervacija.objects.filter(pacijent=who, lijek=medicine, aktivno=True).aggregate(n=Sum("kolicina"))["n"] or Decimal(0)
        donor_total, recipient_total = totals(patient), totals(recipient)
        approvals = [a for a in m.Komisija.objects.filter(pacijent=recipient, lijek=medicine)
                     if a.je_vazeca() and a.preostale_doze >= recipient_total+quantity]
        selected_approval = data.get('komisija_primaoca')
        if selected_approval:
            approvals = [a for a in approvals if a.pk == int(selected_approval)]
        require(administrative or len(approvals) == 1,
                'Primalac mora imati vlastito važeće odobrenje za ovu prezentaciju i dovoljan preostali iznos. Ako ih ima više, odaberite konkretno odobrenje primaoca.')
        recipient_approval = approvals[0] if len(approvals)==1 else None
        if administrative and recipient_approval is None:
            result['impacts'].append('Pravo primaoca nije jednoznačno dokazano. Stara komisijska veza ostaje u historiji; novo pravo nije otvoreno niti preneseno.')
        row(f"{patient} — rezervisano u ambulanti", donor_total, donor_total-quantity)
        row(f"{recipient} — rezervisano u ambulanti", recipient_total, recipient_total+quantity)
        row("Ukupna fizička zaliha ambulante", stock.u_frizideru, stock.u_frizideru)
        result.update(recipient_id=recipient.pk, source_id=source.pk, quantity=str(quantity), source=evidence,
                      recipient_approval_id=recipient_approval.pk if recipient_approval else None,
                      effective_from=timezone.localdate().isoformat())
        if recipient_approval:row(f'Odobreno pravo primaoca — odobrenje #{recipient_approval.pk}', recipient_approval.broj_odobrenih_doza, recipient_approval.broj_odobrenih_doza)
        result["impacts"] += [f"Prenosi se {quantity:g} {medicine.jedinica_za_kolicinu(quantity)}. Ukupno rezervisano ostaje {reserved:g}.",
            "Odobrene količine, brojevi saglasnosti, izvršene terapije i lijek kod kuće ostaju sačuvani."]
        if source.termin_id:
            result["impacts"].append(f"Rezervacija je vezana za termin #{source.termin_id}. Termin ostaje zakazan; nakon prijenosa može nedostajati fizičko pokriće.")
        result["fingerprint"] = state_fingerprint(patient, recipient)
    else:
        require(patient.aktivan, "Promjena režima traži aktivnog pacijenta.")
        effective = date.fromisoformat(str(data.get("vrijedi_od", "")))
        require(effective >= timezone.localdate(), "Nova promjena vrijedi danas ili ubuduće. Pogrešan historijski unos ispravlja administrator kroz Ispravi podatke.")
        require(not m.BrzaIzmjenaPacijenta.objects.filter(pacijent=patient, lijek=medicine, vrsta=kind, vrijedi_od__gt=effective).exists(),
                "Već postoji kasnija promjena iste vrste. Prvo pregledajte historiju režima kako se odluke ne bi preklopile.")
        protocol_step = data.get('protocol_step')
        current = current_regimen(patient, effective, protocol_step=protocol_step)
        phase = patient.aktivni_fazni_protokol()
        deferred = bool(protocol_step and phase.faza != phase.FAZA_ODRZAVANJE)
        if medicine.oralna_terapija:
            require(not m.OralniTerapijskiRezim.objects.filter(pacijent=patient, lijek=medicine,
                datum_od__gt=effective).exists(),
                "Već postoji oralni režim s kasnijim datumom. Unesite promjenu od tog datuma ili kasnije; raniji pogrešan nalog prvo treba ispraviti kroz Ispravi podatke.")
        patch = {}
        if kind == "interval":
            key = "uzimanja_dnevno" if medicine.oralna_terapija else "interval_sedmica"
            value = int(data.get(key, 0))
            require(1 <= value <= (12 if medicine.oralna_terapija else 52), "Unesite važeći cijeli interval/frekvenciju.")
            require(not protocol_step or value in (8,12), 'SC održavanje koristi potvrđeni interval 8 ili 12 sedmica.')
            patch[key] = value
            row("Uzimanja dnevno" if medicine.oralna_terapija else "Interval (sedmice)", current[key], value)
        else:
            mg = amount(data.get("doza_mg"))
            strength = medicine_mg(medicine)
            if strength:
                exact = mg / strength
                units = exact.to_integral_value(rounding=ROUND_CEILING) if medicine.put_primjene == m.Lijek.PUT_IV else exact
                require(units == units.to_integral_value(), "Propisana doza ne odgovara cijelom broju jedinica ove prezentacije. Provjerite nalog i jačinu lijeka.")
            else:
                units = amount(data.get("broj_jedinica"))
                require(units == units.to_integral_value(), "Unesite cijeli broj fizičkih jedinica iz naloga; jačina za automatski preračun nije evidentirana.")
            patch.update(doza_mg=str(mg), broj_jedinica=str(units))
            row("Propisana doza po primjeni/uzimanju (mg)", current.get("doza_mg"), mg)
            row("Fizička količina po primjeni/uzimanju ("+medicine.jedinica_za_kolicinu(units)+")", current["broj_jedinica"], units)
            package = medicine.effective_package_size
            result["impacts"].append(f"Pakovanje sadrži {package} pojedinačnih jedinica. Unesena potrošnja je po primjeni/uzimanju, ne broj pakovanja.")
        require(any(current.get(k) is None or Decimal(str(current[k])) != Decimal(str(v)) for k,v in patch.items()), "Nema promjene vrijednosti.")
        if protocol_step:
            patch['phase_scope'] = phase.FAZA_ODRZAVANJE
            row('Korak naloga', 'SC održavanje', 'SC održavanje')
            row('Trenutna faza pacijenta', phase.get_faza_display(), phase.get_faza_display())
            if deferred:
                result['impacts'].append('Nalog se aktivira u SC održavanju. Prva SC doza ostaje 90 mg i njen termin se ne mijenja.')
        result.update(patch=patch, before=current, after={**current, **patch}, effective_from=effective.isoformat())
        row("Nova promjena vrijedi od", "Dosadašnji režim", effective.strftime("%d/%m/%Y"))
        result["impacts"].append("Ne evidentira se primjena i ne skida se lijek sa zalihe. Procjene budućih potreba koriste datum važenja novog režima.")
        if medicine.oralna_terapija:
            before_daily = Decimal(current["broj_jedinica"])*Decimal(current["uzimanja_dnevno"])
            after_daily = Decimal(str(result["after"]["broj_jedinica"]))*Decimal(str(result["after"]["uzimanja_dnevno"]))
            row("Tableta dnevno", before_daily, after_daily)
            result["impacts"].append("Oralna terapija ne stvara ambulantne termine. Historijska izdavanja zadržavaju svoj snapshot.")
        else:
            from .home_therapy_evidence import home_evidence, supports_home_evidence
            evidence = home_evidence(patient)
            home = supports_home_evidence(patient)
            last = patient.posljednja_stvarno_primljena_terapija()
            snapshot = m.MigracijskiSnapshotPacijenta.objects.filter(pacijent=patient, lijek=medicine).first()
            phase = patient.aktivni_fazni_protokol()
            anchor = evidence.last_application if evidence else (last.datum if last else
                phase.datum_posljednje_primjene if phase else snapshot.datum_posljednje_terapije if snapshot else None)
            if deferred:
                result['next_date'] = None
                result['impacts'].append('Datum održavanja računa se od stvarne SC primjene. Postojeći prvi SC termin ostaje sačuvan.')
            elif not anchor:
                result["impacts"].append("Potrebna provjera: posljednja primjena nije poznata. Naredni datum nije moguće pouzdano izračunati. Datum izdavanja se ne koristi kao datum primjene.")
                result["next_date"] = None
            else:
                from .individual_protocols import get_interval_weeks
                old_next = next_regimen_date(patient, anchor, get_interval_weeks(patient, anchor))[1]
                # A dose-only order does not propose a different date. A future
                # interval order cannot move a therapy due before it starts.
                new_next = old_next
                if "interval_sedmica" in patch and effective <= old_next:
                    new_next = max(anchor + timedelta(weeks=int(patch["interval_sedmica"])), effective)
                if not home:
                    from .scheduling import adjust_to_allowed_therapy_date
                    new_next = adjust_to_allowed_therapy_date(new_next, lijek=medicine, protokol=patient.aktivni_protokol()).datum
                row("Predloženi naredni datum (nije pomjeranje termina)", old_next.strftime("%d/%m/%Y"), new_next.strftime("%d/%m/%Y"))
                result["next_date"] = new_next.isoformat()
            appointments = list(m.Termin.objects.filter(pacijent=patient, status=m.Termin.STATUS_PLANIRANA, datum__gte=timezone.localdate()).order_by("datum").values("id", "datum", "kolicina_po_terapiji"))
            result["appointments"] = [{**a, "datum": str(a["datum"]), "kolicina_po_terapiji": str(a["kolicina_po_terapiji"])} for a in appointments]
            if appointments:
                result["impacts"].append("Zakazani termini zadržavaju datume: "+", ".join(a["datum"].strftime("%d/%m/%Y") for a in appointments)+". Planirane količine koriste nalog koji vrijedi na datum terapije. Posebne ručne količine traže provjeru prije potvrde; datumi se mijenjaju zasebno u kalendaru.")
        if protocol_step:
            _scoped_order_rows(patient, kind, patch, current, effective, row)
        result["fingerprint"] = state_fingerprint(patient)
    return result


def make_preview(patient, kind, data, user):
    plan = preview(patient, kind, data, user)
    payload = {"operation": str(uuid.uuid4()), "actor": user.pk, "patient": patient.pk,
               "kind": kind, "data": data, "fingerprint": plan["fingerprint"]}
    return plan, signing.dumps(payload, salt=SALT, compress=True)


def confirmation_payload(token, patient, user, *, max_age=1800, kind=None):
    authorize(user)
    try:
        payload = signing.loads(token, salt=SALT, max_age=max_age)
    except signing.BadSignature:
        raise ValidationError("Pregled je istekao ili nije važeći. Ponovo prikažite promjenu.") from None
    require(payload["actor"] == user.pk and payload["patient"] == patient.pk, "Potvrda ne pripada ovom korisniku i kartonu.")
    require(kind is None or payload['kind'] == kind, "Potvrda ne pripada odabranoj radnji.")
    return payload


@transaction.atomic
def confirmation_status(token, patient, user, *, kind):
    """Read after any in-flight confirmation holding this patient's lock.

    A saved receipt remains readable after preview expiry. This never writes
    a regimen/reservation or generates a new operation ID for a retry.
    """
    payload = confirmation_payload(token, patient, user, max_age=None, kind=kind)
    patient = m.Pacijent.objects.select_for_update().get(pk=patient.pk)
    receipt = m.BrzaIzmjenaPacijenta.objects.filter(operation_id=payload['operation'],
        pacijent=patient, korisnik=user, vrsta=kind).first()
    return receipt, payload


@transaction.atomic
def confirm(token, patient, user, *, sync_appointments=True):
    payload = confirmation_payload(token, patient, user)
    if payload['kind'] == 'transfer':
        from dashboard.permissions import authorize_transfer as administrator
        administrator(user)
        from .correction_protocol import lock_correction_tables
        lock_correction_tables()
    recipient_id = payload["data"].get("primalac") if payload["kind"] == "transfer" else None
    ids = sorted({patient.pk} | ({int(recipient_id)} if recipient_id else set()))
    locked = {p.pk:p for p in m.Pacijent.objects.select_for_update().filter(pk__in=ids).order_by("pk")}
    patient = locked[patient.pk]
    medicine_id = patient.lijek_id
    # Use the patient -> stock lock order of the existing issuance services.
    # Sort both patient IDs so opposite transfers cannot lock them in reverse.
    list(m.Zaliha.objects.select_for_update().filter(lijek_id=medicine_id).order_by("pk"))
    existing = m.BrzaIzmjenaPacijenta.objects.filter(operation_id=payload["operation"]).first()
    if existing:
        return existing, False
    list(m.PacijentRezervacija.objects.select_for_update().filter(lijek_id=medicine_id).order_by("pk"))
    plan = preview(patient, payload["kind"], payload["data"], user)
    require(plan["fingerprint"] == payload["fingerprint"], "Podaci su se promijenili nakon pregleda. Ponovo pregledajte stanje prije potvrde.")
    fields = dict(operation_id=payload["operation"], pacijent=patient, lijek=patient.lijek, korisnik=user,
                  vrsta=plan["kind"], vrijedi_od=plan["effective_from"], razlog=plan["reason"],
                  prije={"rows": plan["rows"], "regimen": plan.get("before")},
                  poslije={"rows": plan["rows"], "regimen": plan.get("after"), "impacts": plan["impacts"]})
    if plan.get('previous_change'):fields['izvor']={'previous_change':plan['previous_change']}
    if plan["kind"] == "transfer":
        source = m.PacijentRezervacija.objects.get(pk=plan["source_id"])
        quantity = Decimal(plan["quantity"])
        source_before = source.kolicina
        source.kolicina -= quantity
        source.save(update_fields=["kolicina", "aktivno"])
        destination = m.PacijentRezervacija.objects.create(pacijent_id=plan["recipient_id"], lijek=patient.lijek,
            komisija_id=plan['recipient_approval_id'],
            kolicina=quantity, aktivno=True, napomena="Fizički prijenos između kartona; izvorna saglasnost ostaje kod izvornog pacijenta.")
        trace = {**plan['source'], 'allocation_trace':{
            'version':1,'unit':patient.lijek.jedinice_zalihe[0],
            'source_before':str(source_before),'source_after':str(source.kolicina),
            'destination_before':'0','destination_after':str(quantity)}}
        if plan.get('previous_transfer'):
            trace['previous_transfer'] = plan['previous_transfer']
        fields.update(primalac_id=plan["recipient_id"], izvorna_rezervacija=source, odredisna_rezervacija=destination,
                      kolicina=quantity, izvor=trace)
    elif patient.lijek.oralna_terapija:
        from .oral_therapy import confirm_oral_regimen
        current = plan["after"]
        confirm_oral_regimen(patient=patient, medicine=patient.lijek, tablets_per_intake=current["broj_jedinica"],
            intakes_per_day=current["uzimanja_dnevno"], effective_from=date.fromisoformat(plan["effective_from"]),
            phase=m.OralniTerapijskiRezim.FAZA_PRILAGODJENO, doctor_note=plan["reason"], user=user)
    else:
        fields["promjena_rezima"] = plan["patch"]
    from dashboard.permissions import korisnik_uloga
    fields['izvor'] = dict(fields.get('izvor', {}), actor_role=korisnik_uloga(user), source='quick_change')
    receipt = m.BrzaIzmjenaPacijenta.objects.create(**fields)
    if sync_appointments and receipt.vrsta == 'dose' and not patient.lijek.oralna_terapija:
        from .appointment_plan import sync_pending_order
        sync_pending_order(patient, receipt, user)
    from .utils import upisi_log
    details = "; ".join(f"{r['label']}: {r['before']} → {r['after']}" for r in plan["rows"])
    description = f"{receipt.get_vrsta_display()}; vrijedi od {plan['effective_from']}; {details}; razlog: {plan['reason']}"
    upisi_log(user, receipt.get_vrsta_display(), pacijent=patient, objekat=receipt, opis=description)
    if receipt.primalac_id:
        upisi_log(user, "Primljen prijenos zaduženja", pacijent=receipt.primalac, objekat=receipt,
            opis=f"Od {patient} prema {receipt.primalac}; {description}")
    from .commission_planning import recalculate_patient_commission_drafts
    for changed_patient in ([patient, receipt.primalac] if receipt.primalac_id else [patient]):
        recalculate_patient_commission_drafts(changed_patient, user=user,
            reason=f"Brza izmjena #{receipt.pk}: {plan['reason']}")
    return receipt, True


def _scoped_order_rows(patient, kind, patch, current, effective, row):
    """Read-only projection through the same appointment planner used at confirm."""
    from copy import copy
    from types import SimpleNamespace
    from .request_cache import begin_request_cache, end_request_cache
    from .appointment_plan import appointment_plan
    stock = m.Zaliha.objects.filter(lijek=patient.lijek).first()
    physical = stock.u_frizideru if stock else Decimal(0)
    held = m.PacijentRezervacija.objects.filter(pacijent=patient, lijek=patient.lijek,
        aktivno=True,potrosena_at__isnull=True).aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
    row('Fizička zaliha', physical, physical)
    row('Zaduženje pacijenta', held, held)
    for approval in m.Komisija.objects.filter(pacijent=patient,lijek=patient.lijek).order_by('pk'):
        row(f'Komisijsko pravo #{approval.pk} (preostalo)',approval.preostale_doze,approval.preostale_doze)
    probe = copy(patient)
    probe._workflow_regimen_changes = list(m.BrzaIzmjenaPacijenta.objects.filter(pacijent=patient,lijek=patient.lijek,
        vrsta__in=['interval','dose']).order_by('vrijedi_od','kreirano','pk'))
    probe._workflow_regimen_changes.append(SimpleNamespace(pk=-1,lijek_id=patient.lijek_id,vrijedi_od=effective,
        promjena_rezima=patch,prije={'regimen':current}))
    token = begin_request_cache(enabled=True)
    try:
        for appointment in m.Termin.objects.filter(pacijent=patient,lijek=patient.lijek,
                status=m.Termin.STATUS_PLANIRANA,datum__gte=effective).order_by('datum','pk'):
            appointment.pacijent=probe
            plan=appointment_plan(appointment)
            after = plan['quantity'] if kind == 'dose' and plan['source']=='REGIMEN' and not plan['conflict'] else appointment.kolicina_po_terapiji
            row(f'Termin #{appointment.pk} ({appointment.datum:%d/%m/%Y}) — planirana količina',appointment.kolicina_po_terapiji,after)
            if plan['conflict']:
                row(f'Termin #{appointment.pk} — poseban nalog','Potrebna provjera','Bez automatske izmjene; odaberite nalog iz kartona')
    finally:
        end_request_cache(token)
