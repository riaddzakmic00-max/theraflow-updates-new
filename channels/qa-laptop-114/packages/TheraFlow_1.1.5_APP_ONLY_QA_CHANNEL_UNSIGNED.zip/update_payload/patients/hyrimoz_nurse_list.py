"""Read-only dispensing list. Neither dispensing nor a patient statement proves use."""
import re

from django.db.models import Exists, OuterRef
from django.utils import timezone

from .models import KucnaTerapijaPodatak, KucnoIzdavanje, Lijek, Pacijent, Terapija
from .monthly_consumption import REPORT_TIME_ZONE


def sentence_unit(drug, quantity):
    if quantity is not None and drug.jedinice_zalihe[0] == "pen":
        number = int(quantity)
        if quantity == number and number % 10 in (2, 3, 4) and number % 100 not in (12, 13, 14):
            return "pena"
    return drug.jedinica_zalihe_u_recenici(quantity)


def build_hyrimoz_nurse_list(*, today=None):
    today = today or timezone.localdate(timezone=REPORT_TIME_ZONE)
    drugs = {drug.pk: drug for drug in Lijek.objects.filter(put_primjene="SC")
             if re.match(r"^hyrimoz\b", drug.brand_name.strip(), re.IGNORECASE)}
    rows = {}

    def row(patient, drug_id):
        return rows.setdefault((patient.pk, drug_id), {
            "patient": patient, "drug": drugs[drug_id], "issue": None,
            "application": None, "statement": None,
        })

    def latest(target, field, day, source, pk, **extra):
        previous = target[field]
        if previous is None or (day, pk) > (previous["date"], previous["pk"]):
            target[field] = {"date": day, "source": source, "pk": pk, **extra}

    # Include current patients even when there is no reliable dispensing history.
    for patient in Pacijent.objects.filter(lijek_id__in=drugs):
        row(patient, patient.lijek_id)
    issues = KucnoIzdavanje.objects.filter(lijek_id__in=drugs, datum__lte=today, kolicina__gt=0).exclude(
        terapija__workflow_status=Terapija.STATUS_PONISTENA).exclude(
        terapija__ponistena_at__isnull=False).select_related("pacijent")
    for issue in issues:
        if issue.efektivna_kolicina <= 0:
            continue
        latest(row(issue.pacijent, issue.lijek_id), "issue", issue.datum,
               f"Kućno izdavanje #{issue.pk}", issue.pk, quantity=issue.efektivna_kolicina)
    historical = KucnaTerapijaPodatak.objects.filter(
        lijek_id__in=drugs, vrsta=KucnaTerapijaPodatak.IZDAVANJE,
        datum_izdavanja__lte=today).select_related("pacijent")
    for item in historical:
        target = row(item.pacijent, item.lijek_id)
        # A current structured issuance is preferred over a same-day migration anchor.
        if not target["issue"] or item.datum_izdavanja > target["issue"]["date"]:
            latest(target, "issue", item.datum_izdavanja,
                   f"Historijsko izdavanje #{item.pk}", item.pk, quantity=item.izdata_kolicina)
    therapies = Terapija.objects.filter(lijek_id__in=drugs, datum__lte=today,
        workflow_status=Terapija.STATUS_POTVRDJENA, ponistena_at__isnull=True,
        is_migration=False).select_related("pacijent").annotate(
            # Explicit relation distinguishes the paired therapy from a second dispensing.
            has_issue=Exists(KucnoIzdavanje.objects.filter(terapija_id=OuterRef('pk'))))
    for therapy in therapies:
        kind = (therapy.workflow_snapshot or {}).get("vrsta")
        target = row(therapy.pacijent, therapy.lijek_id)
        if kind == "KUCNA_PRIMJENA" or (
            kind == "AMBULANTNA_PRIMJENA" and therapy.tip_evidencije != Terapija.TIP_KUCNA_TERAPIJA
        ):
            if therapy.kolicina > 0:
                latest(target, "application", therapy.datum,
                       f"Potvrđena {'kućna' if kind == 'KUCNA_PRIMJENA' else 'ambulantna'} primjena — terapija #{therapy.pk}",
                       therapy.pk)
        elif therapy.tip_evidencije == Terapija.TIP_KUCNA_TERAPIJA:
            if not therapy.has_issue and therapy.kolicina > 0 and kind != "KUCNA_PRIMJENA":
                if not target["issue"] or therapy.datum > target["issue"]["date"]:
                    latest(target, "issue", therapy.datum,
                           f"Ranije izdavanje — terapija #{therapy.pk}", therapy.pk,
                           quantity=therapy.kolicina)
        # A default type or migration anchor alone is not proof of an SC application.
    statements = KucnaTerapijaPodatak.objects.filter(lijek_id__in=drugs,
        vrsta=KucnaTerapijaPodatak.IZJAVA, datum_provjere__lte=today).select_related("pacijent")
    for statement in statements:
        latest(row(statement.pacijent, statement.lijek_id), "statement", statement.datum_provjere,
               f"Izjava pacijenta #{statement.pk}", statement.pk,
               application_date=statement.datum_primjene, remaining=statement.preostala_kolicina)
    for item in rows.values():
        if item["issue"]:
            item["issue"]["unit"] = sentence_unit(item["drug"], item["issue"]["quantity"])
        if item["statement"]:
            item["statement"]["unit"] = sentence_unit(item["drug"], item["statement"]["remaining"])
    return {"today": today, "generated_at": timezone.now(), "rows": sorted(rows.values(),
        key=lambda item: (item["patient"].prezime.casefold(), item["patient"].ime.casefold(),
                          item["patient"].pk, item["drug"].pk))}
