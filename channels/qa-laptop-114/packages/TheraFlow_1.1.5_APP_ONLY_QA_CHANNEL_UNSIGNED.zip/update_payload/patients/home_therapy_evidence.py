"""Facts about home use, kept separately from dispensing and clinical visits."""

from dataclasses import dataclass, replace
from datetime import timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .models import KucnaTerapijaPodatak, KucnoIzdavanje, Pacijent, Terapija
from .request_cache import get_or_set, request_cache_enabled


@dataclass(frozen=True)
class HomeEvidence:
    issued_on: object = None
    issued_quantity: object = None
    issue_source: str = ""
    report: object = None
    remaining_quantity: object = None
    last_application: object = None
    needs_review: bool = True
    reason: str = "Potrebna provjera: unesite datum primjene i preostalu količinu prema izjavi pacijenta."


def supports_home_evidence(patient):
    return bool(patient.lijek_id and not patient.lijek.oralna_terapija
                and patient.trenutni_korak_je_kucna_terapija())


def home_evidence(patient, *, today=None):
    today = today or timezone.localdate()
    return get_or_set("home_evidence", (patient.pk, patient.lijek_id, today),
                      lambda: _home_evidence(patient, today=today))


def _home_evidence(patient, *, today):
    if not supports_home_evidence(patient):
        return None
    ids = patient.lijek.physical_equivalent_ids()
    prefetched = (request_cache_enabled() and all(hasattr(patient, attr) for attr in
        ('_workflow_home_records', '_workflow_home_issues', '_workflow_therapies')))
    if prefetched:
        records = [r for r in patient._workflow_home_records if r.lijek_id in ids]
        historical = max((r for r in records if r.vrsta == KucnaTerapijaPodatak.IZDAVANJE),
            key=lambda r: (r.datum_izdavanja, r.pk), default=None)
        report = max((r for r in records if r.vrsta == KucnaTerapijaPodatak.IZJAVA),
            key=lambda r: (r.datum_provjere, r.kreirano, r.pk), default=None)
        issues = [r for r in patient._workflow_home_issues if r.lijek_id in ids]
        linked = {r.terapija_id for r in issues}
        legacy_issue = next((r for r in patient._workflow_therapies if r.lijek_id in ids
            and r.tip_evidencije == Terapija.TIP_KUCNA_TERAPIJA
            and r.workflow_status == Terapija.STATUS_POTVRDJENA and r.pk not in linked), None)
    else:
        records = KucnaTerapijaPodatak.objects.filter(pacijent=patient, lijek_id__in=ids)
        historical = records.filter(vrsta=KucnaTerapijaPodatak.IZDAVANJE).order_by("-datum_izdavanja", "-pk").first()
        issues = KucnoIzdavanje.objects.filter(pacijent=patient, lijek_id__in=ids).exclude(
            terapija__workflow_status=Terapija.STATUS_PONISTENA,
        ).order_by("-datum", "-pk")
        legacy_issue = Terapija.objects.filter(pacijent=patient, lijek_id__in=ids,
            tip_evidencije=Terapija.TIP_KUCNA_TERAPIJA, workflow_status=Terapija.STATUS_POTVRDJENA,
            kucno_izdavanje__isnull=True).order_by("-datum", "-pk").first()
        report = records.filter(vrsta=KucnaTerapijaPodatak.IZJAVA).order_by("-datum_provjere", "-kreirano", "-pk").first()
    issue = next((item for item in issues if item.efektivna_kolicina > 0), None)
    if not historical and not issue and not legacy_issue and not report:
        # Existing migrations with a known clinical anchor retain their history.
        return None
    issued_on, issued_quantity, issue_created, source = None, None, None, ""
    if historical:
        issued_on, issued_quantity, issue_created = historical.datum_izdavanja, historical.izdata_kolicina, historical.kreirano
        source = "Historijsko izdavanje — migracija"
    if issue and (not issued_on or issue.datum >= issued_on):
        issued_on, issued_quantity, issue_created = issue.datum, issue.efektivna_kolicina, issue.kreirano
        source = "Evidentirano izdavanje"
    if legacy_issue and (not issued_on or legacy_issue.datum > issued_on):
        issued_on, issued_quantity = legacy_issue.datum, legacy_issue.kolicina
        # Older Terapija rows have no creation timestamp; keep it unknown.
        issue_created = None
        source = "Evidentirano izdavanje — ranija evidencija"
    current_report = bool(report and (not issued_on or (
        report.datum_provjere >= issued_on and (issue_created is None or report.kreirano >= issue_created)
    )))
    remaining = report.preostala_kolicina if current_report else None
    application = report.datum_primjene if current_report else None
    reason = HomeEvidence.reason
    needs_review = remaining is None or application is None
    if not needs_review:
        from .individual_protocols import get_home_therapy_regimen

        units, interval = get_home_therapy_regimen(patient)
        needs_review = not units or not interval
        if not needs_review and application + timedelta(weeks=int(interval)) < today:
            needs_review = True
            reason = "Potrebna provjera: raniji datum primjene više nije dovoljan za budući plan. Potvrdite stanje s pacijentom."
    if report and not current_report:
        reason = "Potrebna provjera: nakon posljednjeg izdavanja nije evidentirana nova izjava pacijenta."
    return HomeEvidence(issued_on, issued_quantity, source, report, remaining,
                        application, needs_review, reason)


@transaction.atomic
def record_home_report(*, patient, user, checked_on, application_on=None, remaining=None, note=""):
    patient = Pacijent.objects.select_for_update().get(pk=patient.pk)
    if not supports_home_evidence(patient):
        raise ValidationError("Ovaj pacijent nije na kućnoj injekcijskoj terapiji.")
    if not checked_on or checked_on > timezone.localdate():
        raise ValidationError("Unesite datum provjere koji nije u budućnosti.")
    if application_on and application_on > checked_on:
        raise ValidationError("Datum primjene ne može biti nakon datuma provjere.")
    if remaining is not None:
        remaining = Decimal(str(remaining))
        if remaining < 0 or (not patient.lijek.dozvoljava_decimalnu_kolicinu and remaining != remaining.to_integral_value()):
            raise ValidationError("Unesite nenegativan cijeli broj preostalih jedinica ili ostavite nepoznatu količinu praznom.")
    report = KucnaTerapijaPodatak.objects.create(
        pacijent=patient, lijek=patient.lijek, vrsta=KucnaTerapijaPodatak.IZJAVA,
        datum_provjere=checked_on, datum_primjene=application_on,
        preostala_kolicina=remaining, napomena=note.strip(), korisnik=user,
    )
    from .utils import upisi_log

    upisi_log(user, "Provjera kućne terapije prema izjavi pacijenta", pacijent=patient,
              objekat=report, opis=f"Provjera: {checked_on}; primjena: {application_on or 'nepoznata'}; preostalo: {remaining if remaining is not None else 'nepoznato'}.")
    return report


def annotate_home_evidence_rows(rows, *, today):
    """Unknown coverage requires review; it is never a zero-need decision."""
    for row in rows:
        evidence = home_evidence(row["pacijent"], today=today)
        row["home_evidence"] = evidence
        if evidence and isinstance(row.get("coverage"), dict):
            row["coverage"]["at_patient"] = evidence.remaining_quantity
        if not evidence or not evidence.needs_review:
            continue
        row.update(status_oznaka="Potrebna provjera", status_klasa="red",
                   status_razlog=evidence.reason, sljedeci_korak="Provjeriti kućnu terapiju s pacijentom",
                   kategorija="pregled", za_pregled=True, blokira_predaju=True,
                   included_in_draft=False, ukljucen_u_nacrt=False, eligible_for_current_cycle=False,
                   komisijska_akcija_aktivna=False, rizik_dostave=False,
                   final_procurement_units=Decimal("0"), kolicina_za_nacrt=Decimal("0"))
        if row.get("commission_decision"):
            row["commission_decision"] = replace(row["commission_decision"],
                status_label="Potrebna provjera", current_status_label="Potrebna provjera",
                status_tone="amber", badge_label="Potrebna provjera", subject_label="Kućna terapija",
                action_label="Provjeriti kućnu terapiju s pacijentom", recommendation_text=evidence.reason,
                decision_status="REVIEW_REQUIRED", first_uncovered_dose=None,
                reasons=(evidence.reason,))
        for key in ("pokriven_do", "fizicki_pokriven_do", "fizicki_pokriven_do_operativno",
                    "planirano_pokriven_do", "planirano_pokriven_do_operativno",
                    "prva_nepokrivena_terapija", "prva_fizicki_nepokrivena_terapija",
                    "rizicna_terapija", "sljedeca_planirana_terapija"):
            row[key] = None
    return rows
