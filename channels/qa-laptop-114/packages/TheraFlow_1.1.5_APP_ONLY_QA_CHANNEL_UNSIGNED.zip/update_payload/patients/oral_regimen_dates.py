"""Use recorded effective dates for oral planning without rewriting issuances."""
from datetime import timedelta
from decimal import Decimal
from django.db.models import Q
from .request_cache import get_or_set


def regimen_is_confirmed(regimen):
    """Shared rule for current oral planning and reservation review.

    Select the dated record first: an unconfirmed replacement must not silently
    fall back to an older confirmed regimen. This never rewrites issue history.
    """
    # Scheduling a confirmed replacement closes the previous record immediately
    # (aktivan=False, datum_do set). The dated selector still legitimately uses
    # it before that end date. An inactive open-ended record is not usable.
    return bool(regimen and regimen.potvrdio_id and (regimen.aktivan or regimen.datum_do is not None))


def regimen_on(patient, on):
    from .models import OralniTerapijskiRezim
    return OralniTerapijskiRezim.objects.filter(pacijent=patient, lijek_id=patient.lijek_id,
        datum_od__lte=on).filter(Q(datum_do__isnull=True) | Q(datum_do__gte=on)).order_by("-datum_od", "-pk").first()


def dated_rates(regimen):
    """Activate this path only for confirmed quick changes of this presentation."""
    from .models import BrzaIzmjenaPacijenta, OralniTerapijskiRezim
    if not getattr(regimen, "pacijent_id", None):
        return ()
    def load():
        if not BrzaIzmjenaPacijenta.objects.filter(pacijent_id=regimen.pacijent_id, lijek_id=regimen.lijek_id,
                vrsta__in=["dose", "interval"]).exists():
            return ()
        return tuple(OralniTerapijskiRezim.objects.filter(pacijent_id=regimen.pacijent_id,
            lijek_id=regimen.lijek_id).order_by("datum_od", "pk"))
    return get_or_set("dated_oral_rates", (regimen.pacijent_id, regimen.lijek_id), load)


def _rate(rates, on, fallback):
    matching = [r for r in rates if r.datum_od <= on and (r.datum_do is None or r.datum_do >= on)]
    return Decimal(matching[-1].tableta_dnevno) if matching else Decimal(fallback)


def consumption_between(regimen, start, days, fallback=None):
    days = max(0, int(days)); end = start+timedelta(days=days)
    rates = dated_rates(regimen)
    fallback = regimen.tableta_dnevno if fallback is None else fallback
    boundaries = sorted({start, end} | {r.datum_od for r in rates if start < r.datum_od < end})
    return sum((_rate(rates, a, fallback)*Decimal((b-a).days) for a,b in zip(boundaries,boundaries[1:])), Decimal(0))


def covered_full_days(regimen, start, quantity):
    rates = dated_rates(regimen); remaining = Decimal(quantity); current = start
    for boundary in sorted({r.datum_od for r in rates if r.datum_od > start}):
        daily = _rate(rates, current, regimen.tableta_dnevno)
        span = (boundary-current).days
        if remaining < daily*span:
            return (current-start).days + int(remaining//daily)
        remaining -= daily*span; current = boundary
    return (current-start).days + int(remaining//_rate(rates,current,regimen.tableta_dnevno))
