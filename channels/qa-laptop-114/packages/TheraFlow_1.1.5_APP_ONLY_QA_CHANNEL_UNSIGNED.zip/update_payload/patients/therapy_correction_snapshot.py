"""Resolve legacy home-issue effects without modifying the original snapshot."""
from decimal import Decimal

from . import models as m


def verified_therapy_snapshot(therapy):
    snapshot = dict(therapy.workflow_snapshot or {})
    if snapshot.get("vrsta") == "KUCNO_IZDAVANJE":
        issue = m.KucnoIzdavanje.objects.filter(pk=snapshot.get("kucno_izdavanje_id"),
            terapija=therapy, pacijent_id=therapy.pacijent_id, lijek_id=therapy.lijek_id).first()
        ledger = m.ZalihaTransakcija.objects.filter(pk=snapshot.get("zaliha_transakcija_id"),
            pacijent_id=therapy.pacijent_id, lijek_id=therapy.lijek_id, tip="KUCNO_IZDAVANJE").first()
        if (issue is None or ledger is None or ledger.referenca_tip != "KucnoIzdavanje"
                or ledger.referenca_id != issue.pk or not (issue.kolicina == ledger.kolicina == therapy.kolicina)):
            raise ValueError("Izdavanje i transakcija nemaju jednoznačne učinke. Provjerite povezano izdavanje i porijeklo zalihe.")
        quantity = issue.kolicina
        if "zaliha_kolicina" in snapshot and Decimal(str(snapshot["zaliha_kolicina"])) != quantity:
            raise ValueError("Količina u zapisu učinaka ne odgovara izvornom izdavanju.")
        # Older supported releases recorded the issuance and ledger IDs, but
        # omitted this redundant quantity. Read it only after cross-validation.
        snapshot["zaliha_kolicina"] = str(quantity)
        expected_assignment = {"zaduzenje_id": issue.pacijent_zaduzenje_id, "kolicina": str(quantity)}
        item = snapshot.get("zaduzenje_izdavanje", {})
        commissions = snapshot.get("komisijske_promjene", [])
        if (item.get("zaduzenje_id") != expected_assignment["zaduzenje_id"]
                or Decimal(str(item.get("kolicina", 0))) != quantity
                or len(commissions) != 1 or commissions[0].get("komisija_id") != issue.komisija_id
                or Decimal(str(commissions[0].get("kolicina", 0))) != quantity):
            raise ValueError("Izdavanje nije jednoznačno povezano sa svojim zaduženjem i odobrenjem.")
    for key, model, field in [
        ("komisijske_promjene", m.Komisija, "komisija_id"),
        ("rezervacijske_promjene", m.PacijentRezervacija, "rezervacija_id"),
        ("fazne_rezervacijske_promjene", m.PacijentRezervacija, "rezervacija_id"),
        ("zaduzenja_promjene", m.PacijentZaduzenje, "zaduzenje_id"),
    ]:
        for item in snapshot.get(key, []):
            linked = model.objects.filter(pk=item.get(field), pacijent_id=therapy.pacijent_id)
            if key != "fazne_rezervacijske_promjene":
                linked = linked.filter(lijek_id=therapy.lijek_id)
            if not linked.exists() or Decimal(str(item.get("kolicina", 0))) <= 0:
                raise ValueError("Zapis učinaka sadrži nepouzdanu vezu. Povezana radnja mora pripadati istom pacijentu i lijeku.")
    return snapshot
