"""Validation shared by the existing audited patient-profile correction workflow."""
import re
from datetime import date

from django.core.exceptions import ValidationError
from django.db.models.functions import Trim
from django.utils import timezone

PROFILE_FIELDS = (
    'ime', 'prezime', 'jmbg', 'broj_kartona', 'spol', 'datum_rodenja',
    'adresa', 'kanton', 'telefon', 'dijagnoza', 'mkb_sifra',
)
IDENTIFICATION_FIELDS = ('ime', 'prezime', 'jmbg', 'broj_kartona', 'datum_rodenja')
PROFILE_LABELS = {
    'ime': 'Ime', 'prezime': 'Prezime', 'jmbg': 'JMBG',
    'broj_kartona': 'Broj kartona', 'spol': 'Spol', 'datum_rodenja': 'Datum rođenja',
    'adresa': 'Adresa', 'kanton': 'Kanton', 'telefon': 'Telefon',
    'dijagnoza': 'Dijagnoza', 'mkb_sifra': 'MKB šifra',
}


def identification_changes(patient, data):
    def normalized(value):
        return value.isoformat() if isinstance(value, date) else value or ''
    return [name for name in IDENTIFICATION_FIELDS if name in data
            and normalized(getattr(patient, name)) != normalized(data[name])]


def validate_profile_data(patient, data):
    from .models import Pacijent
    errors = {}
    jmbg = data.get('jmbg') or ''
    born = data.get('datum_rodenja')
    old_jmbg = patient.jmbg or ''
    born_changed = born != patient.datum_rodenja
    if born and born_changed and born > timezone.localdate():
        errors['datum_rodenja'] = 'Datum rođenja ne može biti u budućnosti.'
    # Unchanged legacy/demo identifiers do not prevent correcting contact details.
    # A new identifier or birth-date correction must be internally consistent.
    if jmbg and (jmbg != old_jmbg or born_changed):
        if not re.fullmatch(r'[0-9]{13}', jmbg):
            errors['jmbg'] = 'JMBG mora sadržavati tačno 13 cifara, bez razmaka ili drugih znakova.'
        else:
            try:
                year_code = int(jmbg[4:7])
                encoded = date((1000 if year_code >= 900 else 2000) + year_code,
                               int(jmbg[2:4]), int(jmbg[:2]))
            except ValueError:
                errors['jmbg'] = 'JMBG sadrži nevažeći datum rođenja. Provjerite dokument.'
            else:
                if encoded > timezone.localdate():
                    errors['jmbg'] = 'Datum rođenja sadržan u JMBG-u ne može biti u budućnosti.'
                # The last digit is the JMBG modulo-11 control digit.
                digits = [int(char) for char in jmbg]
                check = 11 - sum(weight * (digits[index] + digits[index + 6])
                                 for index, weight in enumerate((7, 6, 5, 4, 3, 2))) % 11
                check = 0 if check == 11 else check
                if 'jmbg' not in errors and check != digits[12]:
                    errors['jmbg'] = 'Kontrolna cifra JMBG-a nije valjana. Provjerite broj prema dokumentu.'
                if born and jmbg[:7] != born.strftime('%d%m') + f'{born.year % 1000:03d}':
                    errors['datum_rodenja'] = 'Datum rođenja se ne podudara s JMBG-om. Provjerite oba podatka prema dokumentu.'
    if jmbg and Pacijent.objects.filter(jmbg=jmbg).exclude(pk=patient.pk).exists():
        errors['jmbg'] = 'JMBG već pripada drugom kartonu. Ispravka ne može spojiti ili prepisati taj karton.'
    number = data.get('broj_kartona') or ''
    if number and number != (patient.broj_kartona or ''):
        others = Pacijent.objects.exclude(pk=patient.pk).annotate(clean_number=Trim('broj_kartona'))
        if others.filter(clean_number__iexact=number).exists():
            errors['broj_kartona'] = 'Broj kartona već koristi drugi pacijent. Provjerite identifikaciju prije ispravke.'
    if errors:
        raise ValidationError(errors)
