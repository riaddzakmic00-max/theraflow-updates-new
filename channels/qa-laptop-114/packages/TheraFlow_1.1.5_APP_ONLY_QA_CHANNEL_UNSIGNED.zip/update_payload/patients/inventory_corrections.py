"""Connected corrections over existing stock movements and allocation snapshots.

Original receipts, issues, clinical applications and approval documents are kept.
New ledger rows carry deltas; PatientDataCorrection is the existing audit receipt.
Unknown provenance is a blocking finding, never a guessed allocation.
"""
from datetime import date
from decimal import Decimal
import uuid

from django.core import signing
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone

from . import models as m
from .correction_protocol import correction_transaction
from .data_corrections import (CorrectionBlocked, backup_before_correction, captured_rows,
                               differences, digest, require, serial)
from .request_cache import get_or_set

SALT = 'theraflow.inventory-correction.v1'
KINDS = {'patient_stock': 'Količina za ovog pacijenta u frižideru',
         'receipt': 'Ispravka zaprimanja', 'issue': 'Ispravka kućnog izdavanja',
         'allocation': 'Ispravka raspodjele bez promjene fizičke zalihe',
         'writeoff': 'Otpis / oštećenje', 'return': 'Povrat pacijenta u karantin',
         'receipt_date': 'Ispravka datuma zaprimanja',
         'receipt_metadata': 'Dopuna podataka o komisijskom prijemu'}


def authorize(user, kind):
    from dashboard.permissions import je_admin, je_sestra_ili_admin
    # Existing nursing receipt/issue privileges do not grant stock-count,
    # migration, clinical-decision or unrestricted historical correction rights.
    allowed = je_admin(user) if kind in {'writeoff', 'return', 'patient_stock'} else je_sestra_ili_admin(user)
    if not (user.is_authenticated and user.is_active and kind in KINDS and allowed):
        raise PermissionDenied('Nemate ovlaštenje za ovu vrstu ispravke.')


def units(value):
    try:
        result = Decimal(str(value))
        require(result.is_finite() and 0 <= result <= Decimal('999999.99')
                and result == result.to_integral_value(), 'Unesite cijeli broj pojedinačnih jedinica, ne broj pakovanja.')
        return result
    except (ArithmeticError, TypeError):
        raise CorrectionBlocked('Unesite ispravnu količinu.') from None


def receipt_quantity(tx):
    return tx.kolicina + sum((row.frizider_delta() for row in tx.povezani_prometi.filter(
        tip='KOREKCIJA', korekcija__scope='inventory_receipt')), Decimal(0))


def receipt_date(tx):
    latest = tx.ispravke.filter(scope='inventory_receipt_date').order_by('-kreirano', '-pk').first()
    return latest.datum_dogadjaja if latest else tx.datum


def has_commission_receipt_identity(tx):
    """Concrete cycle/source identity does not require an external label."""
    from dashboard.receipt_display import full_shipment_reference
    return bool(tx.komisijski_ciklus_id and tx.referenca_tip == 'KomisijskiCiklus'
        and tx.referenca_id == tx.komisijski_ciklus_id
        and (tx.operation_id or full_shipment_reference(tx)))


def receipt_metadata(tx):
    """Effective documented labels; original movement and lot ledger stay intact.

    A supplement is evidence about a receipt, never an inventory count or a
    retrospective assertion that every remaining unknown unit belongs to a lot.
    """
    result = {'reference': tx.shipment_reference or '', 'batch': tx.serija or '',
              'expires': str(tx.rok_trajanja or ''), 'audit_id': None}
    latest = tx.ispravke.filter(scope='inventory_receipt_metadata').order_by('-kreirano', '-pk').first()
    if latest:
        result.update(latest.posljedice.get('metadata_after', {}))
        result['audit_id'] = latest.pk
    if not result['reference']:
        unlinked = m.UnlinkedStockReceipt.objects.filter(movement=tx).first()
        if unlinked:
            result['reference'] = (unlinked.backup or {}).get('shipment_reference') or unlinked.delivery_reference or ''
    if not result['reference'] and tx.operation_id:
        siblings = m.ZalihaTransakcija.objects.filter(operation_id=tx.operation_id, tip='ZAPRIMANJE')
        result['reference'] = (siblings.exclude(shipment_reference='').order_by('pk')
            .values_list('shipment_reference', flat=True).first() or '')
        if not result['reference']:
            shared = m.PatientDataCorrection.objects.filter(scope='inventory_receipt_metadata',
                izvorna_transakcija__in=siblings).order_by('-kreirano', '-pk')
            for audit in shared:
                reference = audit.posljedice.get('metadata_after', {}).get('reference', '')
                if reference:
                    result['reference'] = reference
                    break
    return result


def receipt_metadata_warnings(tx, metadata=None):
    metadata = metadata or receipt_metadata(tx)
    warnings = []
    if not metadata['expires']:
        warnings.append('Rok nije evidentiran. Nepoznat rok nije potvrda ispravnosti lijeka za upotrebu.')
    elif date.fromisoformat(metadata['expires']) < timezone.localdate():
        warnings.append('Evidentirani rok je istekao. Prije izdavanja ili primjene potrebna je provjera stvarnih jedinica; dopuna ne odobrava upotrebu.')
    if metadata.get('audit_id'):
        warnings.append('Dopuna podataka ne mijenja saldo ni ranije zaduženje i ne potvrđuje seriju preostalih jedinica. Obuhvat zalihe ostaje izvorno dokumentovan.')
    return warnings


def annotate_receipt_metadata(tx):
    metadata = receipt_metadata(tx)
    tx.effective_reference, tx.effective_batch = metadata['reference'], metadata['batch']
    tx.effective_expiry = date.fromisoformat(metadata['expires']) if metadata['expires'] else None
    tx.metadata_audit_id = metadata.get('audit_id')
    tx.metadata_warnings = receipt_metadata_warnings(tx, metadata)
    tx.can_supplement_metadata = (tx.tip == 'ZAPRIMANJE'
        and not all(metadata[key] for key in ('reference', 'batch', 'expires'))
        and bool(tx.komisijski_ciklus_id or tx.referenca_tip == 'KomisijskiCiklus'
                 or tx.raspodjele_prijema.filter(komisijski_ciklus__isnull=False).exists()))
    return tx


def allocation_quantity(evidence):
    return evidence.zaprimljena_kolicina + (m.ZalihaTransakcija.objects.filter(
        izvorna_transakcija_id=evidence.fizicka_transakcija_id, rezervacija_id=evidence.rezervacija_id,
        korekcija__scope__in=['inventory_receipt', 'inventory_allocation']).aggregate(n=Sum('promjena_rezervacije'))['n'] or Decimal(0))


def restricted_allocation_quantity(medicine_ids):
    """Released claims stay attached to their original receipt, pending a decision.

    This is derived from the existing ledger, not another balance table.
    A positive corrective reservation delta restores the same original claim.
    """
    medicine_ids = tuple(sorted(set(medicine_ids)))
    net = get_or_set('restricted_allocation_delta', medicine_ids, lambda:
        m.ZalihaTransakcija.objects.filter(lijek_id__in=medicine_ids,
            korekcija__scope='inventory_allocation')
        .aggregate(n=Sum('promjena_rezervacije'))['n'] or Decimal(0))
    return max(Decimal(0), -net)


def issue_movement(issue):
    rows = list(m.ZalihaTransakcija.objects.filter(referenca_tip='KucnoIzdavanje',
        referenca_id=issue.pk, tip='KUCNO_IZDAVANJE', lijek=issue.lijek, pacijent=issue.pacijent))
    require(len(rows) == 1, 'Izdavanje nema jedan dokazani promet. Provjerite izvorne zapise; sličan datum i količina nisu dokaz veze.')
    return rows[0]


def effective_issue_quantity(issue):
    # A correction of a mistaken issue restores only units confirmed never handed over.
    delta = get_or_set('corrected_home_issue_delta', issue.pk, lambda:
        m.ZalihaTransakcija.objects.filter(izvorna_transakcija__referenca_tip='KucnoIzdavanje',
            izvorna_transakcija__referenca_id=issue.pk, korekcija__scope='inventory_issue'
        ).aggregate(n=Sum('promjena_salda'))['n'] or Decimal(0))
    return issue.kolicina - delta


def reservation_consumption(reservation):
    """Only persisted workflow IDs establish which reservation was consumed."""
    consumed, events = Decimal(0), []
    for therapy in m.Terapija.objects.filter(pacijent=reservation.pacijent, lijek=reservation.lijek).exclude(
            workflow_status=m.Terapija.STATUS_PONISTENA):
        snapshot = therapy.workflow_snapshot or {}
        changes = snapshot.get('rezervacijske_promjene', []) + snapshot.get('fazne_rezervacijske_promjene', [])
        # Earlier explicit-effect events saved the selected reservation under a
        # separate key. Read that proven debit without rewriting their audit,
        # and prefer canonical changes when newer records already contain them.
        if (snapshot.get('retrospective_accounting') and snapshot.get('reservation_id') == reservation.pk
                and snapshot.get('accounting_choice') in ('both', 'patient')
                and not any(item.get('rezervacija_id') == reservation.pk for item in changes)):
            changes = changes + [dict(rezervacija_id=reservation.pk, kolicina=str(therapy.kolicina))]
        for item in changes:
            if item.get('rezervacija_id') == reservation.pk:
                quantity = Decimal(str(item['kolicina']))
                consumed += quantity
                events.append({'type': 'Terapija', 'id': therapy.pk, 'date': str(therapy.datum),
                    'quantity': str(quantity), 'label': 'Kućno izdavanje' if therapy.tip_evidencije == m.Terapija.TIP_KUCNA_TERAPIJA else 'Primjena'})
    for change in reservation.oralna_razduzenja.select_related('izdavanje').exclude(izdavanje__status='PONISTENO'):
        consumed += change.kolicina
        events.append({'type': 'IzdavanjeOralneTerapije', 'id': change.izdavanje_id,
            'date': str(change.izdavanje.datum_izdavanja), 'quantity': str(change.kolicina), 'label': 'Oralno izdavanje'})
    restored = m.ZalihaTransakcija.objects.filter(rezervacija=reservation,
        korekcija__scope='inventory_issue').aggregate(n=Sum('promjena_rezervacije'))['n'] or Decimal(0)
    return consumed-restored, events


def target_context(kind, target_id):
    if kind == 'patient_stock':
        target = m.Pacijent.objects.select_related('lijek').filter(pk=target_id).first()
    elif kind == 'allocation':
        target = m.EvidencijaSaglasnostiZaprimanja.objects.select_related(
            'pacijent', 'trebovanje__lijek', 'fizicka_transakcija', 'rezervacija').filter(pk=target_id).first()
    elif kind in {'receipt', 'receipt_date', 'receipt_metadata'}:
        target = m.ZalihaTransakcija.objects.select_related('lijek', 'pacijent').filter(pk=target_id, tip='ZAPRIMANJE').first()
    elif kind in {'issue', 'return'}:
        target = m.KucnoIzdavanje.objects.select_related('lijek', 'pacijent', 'komisija', 'pacijent_zaduzenje', 'terapija').filter(pk=target_id).first()
    elif kind == 'writeoff':
        target = m.Lijek.objects.filter(pk=target_id).first()
    else:
        target = None
    require(target is not None, 'Odaberite postojeći izvorni zapis odgovarajuće vrste.')
    medicine = target if kind == 'writeoff' else target.trebovanje.lijek if kind == 'allocation' else target.lijek
    return target, medicine


def _row(plan, label, before, after):
    plan['rows'].append({'label': label, 'before': str(before), 'after': str(after)})


def _allocation_plan(plan, claim, data):
    tx, res, req = claim.fizicka_transakcija, claim.rezervacija, claim.trebovanje
    require(tx and res, 'Potreban podatak: ovoj raspodjeli nedostaje dokumentovana veza s prijemom.')
    from .inventory_trace import explicit_receipt_basis
    linked, basis = explicit_receipt_basis(res)
    require(linked and basis is not None and res.izvori_prijema.count() == 1,
            'Raspodjela nema jedan dokazani izvor. Odaberite prijem i razjasnite porijeklo u ovom kartonu.')
    require(not m.BrzaIzmjenaPacijenta.objects.filter(izvorna_rezervacija=res, vrsta='transfer').exists(),
            'Raspodjela ima prijenos drugom pacijentu. Potrebno je razjasniti pogođene raspodjele.')
    old, new = allocation_quantity(claim), units(data['quantity'])
    consumed, events = reservation_consumption(res)
    require(old == res.kolicina+consumed, 'Raspodjela i dokazani izlazi nisu usklađeni. Razjasnite kasniju potrošnju.')
    require(new >= consumed, f'Već je izdato/primijenjeno {consumed:g}. Razjasnite izvor tih jedinica prije smanjenja raspodjele.')
    delta = new-old
    held = -(tx.povezani_prometi.filter(rezervacija=res, korekcija__scope='inventory_allocation')
             .aggregate(n=Sum('promjena_rezervacije'))['n'] or Decimal(0))
    require(delta != 0, 'Nema promjene raspodjele.')
    require(delta <= held, 'Veća raspodjela može vratiti samo ranije izdvojene jedinice istog izvora. Nova dodjela traži provjeru prava i porijekla.')
    approved = req.odobrene_doze if req.odobrene_doze is not None else req.broj_doza
    require(0 <= req.zaprimljene_doze+delta <= approved, 'Nova raspodjela prelazi dokumentovano pravo zahtjeva.')
    require(plan['event_date'] == str(receipt_date(tx)), 'Zadržite datum izvornog prijema za korekciju raspodjele.')
    plan.update(before=old, after=new, delta=delta, original_movement_id=tx.pk,
        batch=tx.serija, expires=str(tx.rok_trajanja or ''), events=events,
        allocations=[{'claim_id': claim.pk, 'reservation_id': res.pk, 'request_id': req.pk,
            'patient_id': claim.pacijent_id, 'quantity_before': old, 'quantity_after': new,
            'delta': delta, 'reserved_after': new-consumed}])
    _row(plan, 'Zaprimljeno i raspodijeljeno ovom pacijentu', old, new)
    _row(plan, f'{claim.pacijent} — rezervisano u ambulanti', res.kolicina, new-consumed)
    _row(plan, 'Izdvojeno iz raspodjele — čeka odluku o dostupnosti', held, held-delta)
    plan['impacts'].append('Fizički prijem i ukupna zaliha ostaju isti. Oslobođene jedinice zadržavaju izvor, seriju i rok; nisu slobodne za drugo izdavanje ili automatsku dodjelu. Odobreno pravo ostaje isto.')


def _receipt_plan(plan, tx, data):
    old, new = receipt_quantity(tx), units(data['quantity'])
    delta = new-old
    require(delta != 0, 'Nema promjene zaprimljene količine.')
    claims = list(tx.raspodjele_prijema.select_related('rezervacija', 'trebovanje', 'pacijent'))
    claimed = sum((allocation_quantity(a) for a in claims), Decimal(0))
    documented_remainder = has_commission_receipt_identity(tx) and claimed <= old
    plan.update(before=old, after=new, delta=delta, allocations=[], events=[])
    require(tx.frizider_delta() == tx.kolicina and tx.lokacija in ('', 'FRIZIDER'), 'Izvor nije fizičko zaprimanje u ambulantu.')
    if not claims:
        # Legacy patient/cycle receipts lack proof of the allocation, not proof of no allocation.
        require(not tx.pacijent_id and not tx.rezervisana_pacijentu and (not tx.referenca_tip or documented_remainder),
                'Potreban podatak: zaprimanje nema dokazanu vezu s raspodjelom. Provjerite evidenciju prijema; ne smije se pretpostaviti da je količina slobodna.')
        reserved = m.PacijentRezervacija.objects.filter(lijek=tx.lijek, aktivno=True).aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
        require(reserved == 0 and not m.ZalihaTransakcija.objects.filter(lijek=tx.lijek, pk__gt=tx.pk).exclude(
            izvorna_transakcija=tx).exists(), 'Slobodnom prijemu slijede drugi prometi. Najprije razjasnite potrošnju upravo tog izvora.')
    else:
        require(claimed == old or documented_remainder,
                'Raspodjele ne pokrivaju tačno izvorni prijem. Potrebna je provjera nepoznatog dijela izvora.')
        specified = data.get('allocations', {})
        require(len(claims) == 1 and not documented_remainder or set(specified) == {str(a.pk) for a in claims},
                'Za prijem više pacijenata navedite novu količinu svake imenovane raspodjele.')
        for claim in claims:
            reservation, req = claim.rezervacija, claim.trebovanje
            require(reservation and (reservation.pacijent_id, reservation.lijek_id, reservation.trebovanje_id) ==
                    (claim.pacijent_id, tx.lijek_id, req.pk), 'Raspodjela, pacijent i konkretna prezentacija nisu jednoznačno povezani.')
            old_allocation = allocation_quantity(claim)
            new_allocation = units(specified[str(claim.pk)]) if len(claims) > 1 or documented_remainder else new
            consumed, events = reservation_consumption(reservation)
            transfers = m.BrzaIzmjenaPacijenta.objects.filter(izvorna_rezervacija=reservation, vrsta='transfer')
            require(not transfers.exists(), f'Rezervacija #{reservation.pk} ima prijenos na drugi karton. Pregledajte prijenos i prvo potvrdite raspodjelu ispravke među tim pacijentima.')
            sources = list(reservation.izvori_prijema.all())
            mixed = len(sources) > 1
            require(not mixed or consumed == 0,
                    f'Rezervacija #{reservation.pk} ima više prijema i potrošnju. Potreban je dokaz iz kojeg prijema su izdavane jedinice.')
            source_total = sum((allocation_quantity(a) for a in sources), Decimal(0))
            require(source_total == reservation.kolicina + consumed,
                    f'Potreban podatak: raspodjela #{claim.pk}, preostalo i dokazani izlazi se ne slažu. Nepoznate događaje sistem ne dopisuje.')
            require(new_allocation >= consumed,
                    f'Iz raspodjele #{claim.pk} dokazano je izdato/primijenjeno {consumed:g}, a nova količina je {new_allocation:g}. Razjasnite izvor već izdatih jedinica.')
            new_reserved = reservation.kolicina + new_allocation-old_allocation
            change = new_allocation-old_allocation
            approved = req.odobrene_doze if req.odobrene_doze is not None else req.broj_doza
            require(0 <= req.zaprimljene_doze+change <= approved,
                    f'Ispravljeni prijem zahtjeva #{req.pk} prelazi dokumentovano pravo. Saglasnost se ne mijenja ovom ispravkom.')
            require(plan['event_date'] == str(receipt_date(tx)) and all(plan['event_date'] <= e['date'] for e in events),
                    'Datum stvarnog prijema ne smije slijediti povezano izdavanje ili primjenu.')
            plan['allocations'].append({'claim_id': claim.pk, 'reservation_id': reservation.pk,
                'request_id': req.pk, 'patient_id': claim.pacijent_id, 'quantity_before': old_allocation,
                'quantity_after': new_allocation, 'delta': change, 'reserved_after': new_reserved})
            plan['events'] += events
            _row(plan, f'{claim.pacijent} — rezervacija #{reservation.pk}', reservation.kolicina, new_reserved)
            _row(plan, f'Zahtjev #{req.pk} — ukupno zaprimljeno', req.zaprimljene_doze, req.zaprimljene_doze+change)
        assigned_after = sum((a['quantity_after'] for a in plan['allocations']), Decimal(0))
        require(assigned_after <= new if documented_remainder else assigned_after == new,
                'Zbir novih raspodjela mora biti jednak stvarno zaprimljenoj količini.')
        if documented_remainder:
            if new-assigned_after < old-claimed:
                require(not m.ZalihaTransakcija.objects.filter(lijek=tx.lijek, pk__gt=tx.pk)
                    .exclude(izvorna_transakcija=tx).exists(),
                    'Neraspoređenom dijelu slijede drugi prometi. Najprije razjasnite potrošnju upravo tog izvora prije umanjenja.')
            _row(plan, 'Neraspoređeni dio izvornog prijema', old-claimed, new-assigned_after)
    _row(plan, f'Zaprimanje #{tx.pk} — efektivna količina', old, new)
    plan['stock_delta'] = delta
    plan['impacts'].append('Izvorni prijem i snimak saglasnosti ostaju sačuvani. Dodaje se korektivni promet; odobreno pravo i izvršena izdavanja/primjene ostaju ista.')


def _issue_plan(plan, issue, data):
    from .therapy_correction_snapshot import verified_therapy_snapshot
    require(issue.terapija and issue.pacijent_zaduzenje and issue.komisija,
            'Izdavanje nema sve izvorne veze sa zaduženjem i odobrenjem. Potrebna je provjera dokumentacije.')
    require(issue.terapija.workflow_status != m.Terapija.STATUS_PONISTENA, 'Izdavanje je već poništeno.')
    snapshot = verified_therapy_snapshot(issue.terapija)
    tx = issue_movement(issue)
    require(tx.kolicina == issue.kolicina and tx.datum == issue.datum, 'Izvorno izdavanje i promet imaju različite količine ili datume.')
    old, new = effective_issue_quantity(issue), units(data['quantity'])
    require(data.get('actual_handover') is True,
            'Potvrdite šta je stvarno predato pacijentu. Stvaran povrat se evidentira zasebno, u karantin.')
    require(new != old, 'Nema promjene količine izdavanja.')
    require(plan['event_date'] == str(issue.datum), 'Za ovu ispravku zadržite datum izvornog izdavanja. Pomjeranje datuma uz kasnije događaje zahtijeva zasebnu provjeru.')
    later = m.Terapija.objects.filter(pacijent=issue.pacijent, lijek=issue.lijek, datum__gte=issue.datum).exclude(pk=issue.terapija_id).exclude(workflow_status=m.Terapija.STATUS_PONISTENA)
    if plan.get('duplicate_id'):
        # The explicitly confirmed original dispensing is not a later use of
        # the phantom units. Any other issuance/application still blocks.
        original_issue = m.KucnoIzdavanje.objects.get(pk=plan['duplicate_id'])
        later = later.exclude(pk=original_issue.terapija_id)
    reports = m.KucnaTerapijaPodatak.objects.filter(pacijent=issue.pacijent, lijek=issue.lijek,
        vrsta='IZJAVA', datum_provjere__gte=issue.datum)
    require(not later.exists() and not reports.exists(),
            'Poslije izdavanja postoji primjena, drugo izdavanje ili izjava o stanju. Razjasnite te zavisnosti; lijek se ne vraća automatski.')
    require(not tx.povezani_prometi.filter(korekcija__scope='inventory_return').exists(),
            'Postoji stvaran povrat iz ovog izdavanja. Prvo razjasnite povrat i preostalu kućnu količinu.')
    delta = new-old
    assignment = issue.pacijent_zaduzenje
    require((assignment.pacijent_id, assignment.lijek_id) == (issue.pacijent_id, issue.lijek_id)
            and (issue.komisija.pacijent_id, issue.komisija.lijek_id) == (issue.pacijent_id, issue.lijek_id),
            'Zaduženje ili odobrenje pripada drugom pacijentu/prezentaciji. Razjasnite izvorne veze.')
    require(0 <= assignment.preostalo+delta <= assignment.ukupno_zaduzeno+delta,
            'Ispravka bi umanjila već potrošeno kućno zaduženje. Potrebna je provjera primjene.')
    require(0 <= issue.komisija.preostale_doze-delta <= issue.komisija.broj_odobrenih_doza,
            'Ispravka nije usklađena s preostalim komisijskim pravom; odobrena količina se ne mijenja.')
    changes = snapshot.get('rezervacijske_promjene', [])
    require(len(changes) <= 1, 'Izdavanje je uzeto iz više rezervacija. Potrebno je potvrditi tačnu raspodjelu korekcije po izvorima.')
    plan.update(before=old, after=new, delta=delta, stock_delta=-delta, home_delta=delta,
                original_movement_id=tx.pk, issue_id=issue.pk, reservations=[])
    if changes:
        change = changes[0]
        require(Decimal(str(change['kolicina'])) == issue.kolicina,
                'Izdavanje miješa slobodnu zalihu i rezervaciju. Razjasnite tačne jedinice iz oba izvora.')
        res = m.PacijentRezervacija.objects.get(pk=change['rezervacija_id'])
        require(res.lijek_id == issue.lijek_id and res.pacijent_id == issue.pacijent_id,
                'Serija ili oblik izvora ne odgovara izdavanju; IV i SC nisu zamjenjivi.')
        known_lots = {(a.fizicka_transakcija.serija, a.fizicka_transakcija.rok_trajanja)
            for a in res.izvori_prijema.select_related('fizicka_transakcija')
            if a.fizicka_transakcija_id and a.fizicka_transakcija.serija}
        require(not known_lots or known_lots == {(issue.serija, issue.rok_trajanja)},
                'Serija ili rok izdavanja ne odgovara dokazanom prijemu rezervacije. Razjasnite porijeklo jedinica.')
        require(res.kolicina-delta >= 0, 'Nema dovoljno jedinica u izvornoj rezervaciji za veće izdavanje.')
        plan['reservations'].append({'id': res.pk, 'delta': -delta, 'after': res.kolicina-delta})
        _row(plan, f'Rezervacija #{res.pk}', res.kolicina, res.kolicina-delta)
    _row(plan, 'Stvarno predato pacijentu', old, new)
    _row(plan, 'Kućno zaduženje — preostalo', assignment.preostalo, assignment.preostalo+delta)
    _row(plan, 'Preostalo pravo (odobrena količina ostaje ista)', issue.komisija.preostale_doze, issue.komisija.preostale_doze-delta)
    plan['impacts'].append('Ispravlja se dokazano pogrešan unos predaje. Ne evidentira se primjena. Originalno izdavanje i svi raniji dokumenti ostaju sačuvani; ispravka ima vlastitu potvrdu.')


def _receipt_metadata_plan(tx, medicine, data, reason, event_date):
    require(bool(tx.komisijski_ciklus_id or tx.referenca_tip == 'KomisijskiCiklus'
        or tx.raspodjele_prijema.filter(komisijski_ciklus__isnull=False).exists()),
        'Odaberite fizički prijem iz komisijskog toka.')
    require(event_date == receipt_date(tx), 'Dopuna podataka ne mijenja datum prijema. Za datum koristite povezanu ispravku datuma.')
    require(not data.get('reverse_of') and 'quantity' not in data and not data.get('allocations'),
        'Dopuna podataka ne može mijenjati količine ili raspodjelu.')
    if data.get('medicine_id'):
        require(int(data['medicine_id']) == medicine.pk, 'Odabrani lijek ne odgovara izvornom prijemu.')
    context_id = int(data['context_patient_id']) if data.get('context_patient_id') else None
    if context_id:
        require(tx.pacijent_id == context_id or tx.raspodjele_prijema.filter(pacijent_id=context_id).exists(),
            'Izvor ne pripada odabranom kartonu.')
    before = receipt_metadata(tx)
    after = {key: before[key] for key in ('reference', 'batch', 'expires')}
    supplied = {'reference': ' '.join(str(data.get('shipment_reference', '') or '').strip().upper().split()),
                'batch': str(data.get('batch', '') or '').strip(),
                'expires': str(data.get('expires', '') or '').strip()}
    require(len(supplied['reference']) <= 100 and len(supplied['batch']) <= 100,
        'Otpremnica i serija mogu imati najviše 100 znakova.')
    if supplied['expires']:
        try:
            date.fromisoformat(supplied['expires'])
        except ValueError:
            raise CorrectionBlocked('Unesite ispravan dokumentovani rok trajanja.') from None
    for key, value in supplied.items():
        if key == 'reference' and before[key] and value.casefold() == before[key].casefold():
            value = before[key]
        require(not before[key] or not value or value == before[key],
            'Dopuna ne prepisuje već evidentirane podatke. Potrebna je zasebna provjera ispravke izvora.')
        if value:
            after[key] = value
    require(any(before[key] != after[key] for key in after), 'Nema novih podataka za dopunu.')
    sources = m.ZalihaTransakcija.objects.filter(pk=tx.pk)
    if tx.operation_id:
        sources = m.ZalihaTransakcija.objects.filter(operation_id=tx.operation_id, tip='ZAPRIMANJE')
    medicine_ids = sorted(set(sources.values_list('lijek_id', flat=True)))
    if after['reference'] and not before['reference']:
        from dashboard.receipt_display import receipt_document_exists
        require(not any(receipt_document_exists(pk, after['reference']) for pk in medicine_ids),
            'Ista otpremnica je već evidentirana za ovaj lijek. Razjasnite duplikat prije dopune.')
    plan = {'kind': 'receipt_metadata', 'title': KINDS['receipt_metadata'],
        'target_id': tx.pk, 'original_movement_id': tx.pk, 'medicine_id': medicine.pk,
        'medicine': str(medicine), 'presentation': f'{medicine.strength} {medicine.pharmaceutical_form} {medicine.put_primjene}',
        'unit': medicine.jedinice_zalihe[0], 'reason': reason, 'event_date': str(event_date),
        'patient_id': context_id or tx.pacijent_id, 'batch': after['batch'], 'expires': after['expires'],
        'metadata_before': {key: before[key] for key in after}, 'metadata_after': after,
        'original_receipt_snapshot': serial(m.ZalihaTransakcija.objects.filter(pk=tx.pk).values().get()),
        'document_movement_ids': list(sources.order_by('pk').values_list('pk', flat=True)),
        'document_medicine_ids': medicine_ids, 'rows': [], 'stock_delta': Decimal(0), 'home_delta': Decimal(0),
        'status': 'Dopuna spremna za potvrdu',
        'impacts': ['Čuvaju se originalni prijem i svi raniji izlazi, zaduženja i zalihe. Dopuna ne potvrđuje seriju preostalih jedinica niti odobrava upotrebu lijeka.'],
        'warnings': receipt_metadata_warnings(tx, {**after, 'audit_id': True})}
    for key, label in (('reference', 'Otpremnica'), ('batch', 'Serija'), ('expires', 'Rok trajanja')):
        if before[key] != after[key]:
            _row(plan, label, before[key] or 'Nije evidentirano', after[key])
    return plan


def preview(kind, target_id, data, user):
    authorize(user, kind)
    target, medicine = target_context(kind, target_id)
    reason = str(data.get('reason', '')).strip()
    require(5 <= len(reason) <= 500, 'Unesite razlog ispravke (5–500 znakova).')
    try:
        event_date = date.fromisoformat(str(data.get('event_date', '')))
    except (ValueError, TypeError):
        raise CorrectionBlocked('Unesite datum stvarnog događaja.') from None
    require(event_date <= timezone.localdate(), 'Stvarni događaj ne može biti u budućnosti.')
    if kind == 'receipt_metadata':
        return _receipt_metadata_plan(target, medicine, data, reason, event_date)
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    require(stock is not None, 'Nema fizičkog salda. Administrator prvo treba provjeriti početno stanje.')
    from .inventory import izracunaj_frizider_iz_transakcija
    require(izracunaj_frizider_iz_transakcija(medicine) == stock.u_frizideru,
            'Saldo i prometi se razlikuju. Prvo provjerite fizičko stanje; ispravka izvora ne može prikriti nepoznatu razliku.')
    plan = {'kind': kind, 'title': KINDS[kind], 'target_id': target.pk, 'medicine_id': medicine.pk,
        'medicine': str(medicine), 'presentation': f'{medicine.strength} {medicine.pharmaceutical_form} {medicine.put_primjene}',
        'unit': medicine.jedinice_zalihe[0], 'reason': reason, 'event_date': str(event_date),
        'batch': getattr(target, 'serija', ''), 'expires': str(getattr(target, 'rok_trajanja', '') or ''),
        'patient_id': getattr(target, 'pacijent_id', None), 'rows': [], 'impacts': [], 'warnings': [],
        'stock_delta': Decimal(0), 'home_delta': Decimal(0), 'status': 'Spremno za potvrdu'}
    if data.get('context_patient_id'):
        context_id = int(data['context_patient_id'])
        valid_context = (kind == 'patient_stock' and target.pk == context_id
            or kind == 'writeoff' and m.Pacijent.objects.filter(pk=context_id, lijek=medicine).exists()
            or getattr(target, 'pacijent_id', None) == context_id
            or kind in {'receipt', 'receipt_date'} and target.raspodjele_prijema.filter(pacijent_id=context_id).exists())
        require(valid_context, 'Izvor ne pripada odabranom kartonu.')
        plan['patient_id'] = context_id
    # Context is fixed server-side. A hidden field or forged POST cannot change presentation/lot.
    if data.get('medicine_id'):
        require(int(data['medicine_id']) == medicine.pk, 'Odabrani oblik/prezentacija ne odgovara izvornom zapisu.')
    if data.get('batch') is not None and kind not in {'writeoff', 'patient_stock'}:
        require(data['batch'] == plan['batch'], 'Serija ne odgovara izvornom zapisu. Ne prebacujte jedinice između serija.')
    duplicate_id = data.get('duplicate_id')
    if data.get('reverse_of'):
        previous = m.PatientDataCorrection.objects.filter(pk=data['reverse_of'], scope='inventory_'+kind).first()
        require(previous and previous.posljedice.get('target_id') == target.pk,
                'Povrat ne pripada ovom izvornom zapisu.')
        plan['reverse_of'] = previous.pk
        plan['impacts'].append(f'Nova korekcija nakon ponovne provjere zavisnosti ispravke #{previous.pk}; originalna ispravka ostaje u historiji.')
    if duplicate_id:
        require(kind in {'receipt', 'issue'} and units(data['quantity']) == 0 and data.get('duplicate_confirmed') is True,
                'Za poništenje duplikata izaberite oba zapisa, potvrdite dokaz duplog unosa i količinu 0.')
        other, other_medicine = target_context(kind, duplicate_id)
        require(other.pk != target.pk and other_medicine.pk == medicine.pk and
                getattr(other, 'pacijent_id', None) == getattr(target, 'pacijent_id', None) and
                getattr(other, 'serija', '') == plan['batch'] and
                getattr(other, 'rok_trajanja', None) == getattr(target, 'rok_trajanja', None),
                'Označeni drugi zapis ne odgovara pacijentu, lijeku, seriji ili roku.')
        other_quantity = receipt_quantity(other) if kind == 'receipt' else effective_issue_quantity(other)
        require(other_quantity > 0, 'Drugi zapis je već poništen ili ima količinu 0. Potvrdite važeći izvorni događaj.')
        _row(plan, f'Drugi zapis #{other.pk} od {other.datum} — ostaje sačuvan', other_quantity, other_quantity)
        plan['duplicate_id'] = other.pk
        plan['impacts'].append(f'Korisnik je potvrdio dokaz duplog unosa #{target.pk} naspram #{other.pk}. Drugi zapis se ne mijenja; original se čuva uz korekciju.')
    if kind == 'patient_stock':
        from .patient_fridge_corrections import plan_correction
        plan_correction(plan, target, medicine, data, stock)
    elif kind == 'allocation':
        _allocation_plan(plan, target, data)
    elif kind == 'receipt':
        _receipt_plan(plan, target, data)
        plan['original_movement_id'] = target.pk
    elif kind == 'issue':
        _issue_plan(plan, target, data)
    elif kind == 'receipt_date':
        claims = list(target.raspodjele_prijema.select_related('rezervacija'))
        require(claims and all(a.rezervacija_id for a in claims), 'Potreban podatak: datum se ne može provjeriti bez veza sa raspodjelama.')
        dates = [e['date'] for a in claims for e in reservation_consumption(a.rezervacija)[1]]
        require(not dates or str(event_date) <= min(dates), 'Novi datum prijema bio bi poslije povezanog izdavanja ili primjene.')
        before_date = receipt_date(target)
        require(before_date != event_date, 'Datum je već tako evidentiran.')
        plan.update(original_movement_id=target.pk, before=str(before_date), after=str(event_date))
        _row(plan, 'Datum prijema — korekcija uz original', before_date, event_date)
    elif kind == 'writeoff':
        from .stock_lots import lot_balances
        quantity = units(data['quantity'])
        require(quantity > 0, 'Unesite pozitivnu količinu otpisa.')
        batch = str(data.get('batch', '')).strip()
        expiry = date.fromisoformat(str(data['expires'])) if data.get('expires') else None
        available = lot_balances(medicine).get((batch, expiry), Decimal(0))
        require(quantity <= available, 'Nema dovoljno jedinica odabrane serije i roka. Nepoznata serija ostaje zaseban nepoznati dio zalihe.')
        plan.update(before=available, after=available-quantity, delta=-quantity,
            batch=batch, expires=str(expiry or ''), stock_delta=-quantity)
        _row(plan, 'Otpis / oštećenje u ambulanti', available, available-quantity)
    elif kind == 'return':
        quantity = units(data['quantity'])
        require(quantity > 0 and data.get('actual_return') is True, 'Potvrdite stvarni povrat i tačnu količinu preuzetu od pacijenta.')
        require(event_date >= target.datum, 'Povrat ne može prethoditi izdavanju.')
        assignment = target.pacijent_zaduzenje
        require(assignment and (assignment.pacijent_id, assignment.lijek_id) == (target.pacijent_id, target.lijek_id),
                'Kućno zaduženje nije povezano s ovim pacijentom i prezentacijom. Provjerite izvor povrata.')
        tx = issue_movement(target)
        returned = tx.povezani_prometi.filter(korekcija__scope='inventory_return').aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
        require(assignment and assignment.preostalo >= quantity and quantity <= effective_issue_quantity(target)-returned,
                'Povrat prelazi dokazanu preostalu količinu. Razjasnite primjene i izvor vraćenih jedinica.')
        require(data.get('batch') == target.serija and bool(target.serija), 'Za povrat potvrdite poznatu seriju iz izvornog izdavanja.')
        plan.update(before=assignment.preostalo, after=assignment.preostalo-quantity, quantity=quantity,
            home_delta=-quantity, original_movement_id=tx.pk, issue_id=target.pk)
        _row(plan, 'Kod pacijenta', assignment.preostalo, assignment.preostalo-quantity)
        _row(plan, 'Povrat u karantin — nije raspoloživo za izdavanje', 0, quantity)
        plan['impacts'].append('Povrat se čuva u karantinu. Fizička raspoloživa zaliha i komisijsko pravo se ne povećavaju.')
    require(stock.u_frizideru+plan['stock_delta'] >= 0 and stock.kod_pacijenata+plan['home_delta'] >= 0,
            'Ispravka bi stvorila negativno fizičko ili kućno stanje. Razjasnite povezane izvore.')
    from .stock_lots import coverage_preview
    reservation_deltas = {}
    for item in plan.get('allocations', []) + plan.get('reservations', []):
        key = item.get('reservation_id', item.get('id'))
        reservation_deltas[key] = reservation_deltas.get(key, Decimal(0)) + item['delta']
    coverage = coverage_preview(medicine, stock.u_frizideru, stock.u_frizideru+plan['stock_delta'],
        reservation_deltas=reservation_deltas, new_allocation=(
            {'patient_id': plan['patient_id'], 'patient': str(target), 'approval_id': plan['approval_id'],
             'quantity': plan['new_reservation_delta']} if kind == 'patient_stock' and not plan.get('revision') else None))
    reservation_delta = sum((a['delta'] for a in plan.get('allocations', [])), Decimal(0))
    reservation_delta += sum((r['delta'] for r in plan.get('reservations', [])), Decimal(0))
    reservation_delta += plan.get('new_reservation_delta', Decimal(0))
    if kind not in {'writeoff', 'return', 'receipt_date'}:
        require(stock.u_frizideru+plan['stock_delta'] >= coverage['reserved']+reservation_delta,
                'Preostalo fizičko stanje ne pokriva povezane rezervacije. Razjasnite izvore; stvaran inventurni manjak evidentira administrator kroz fizički popis.')
    if kind == 'writeoff' and coverage['shortfall_after'] > 0:
        plan['status'] = 'Postoji manjak'
        plan['warnings'].append(f"Otpis otkriva manjak {coverage['shortfall_after']:g} jedinica. Prava i rezervacije ostaju sačuvani; provjerite pokriće.")
    _row(plan, 'Fizički raspoloživo u ambulanti', stock.u_frizideru, stock.u_frizideru+plan['stock_delta'])
    if plan['home_delta']:
        _row(plan, 'Evidentirano kod pacijenata', stock.kod_pacijenata, stock.kod_pacijenata+plan['home_delta'])
    if not plan['batch']:
        plan['warnings'].append('Serija nije dokumentovana. Pregled ne potvrđuje stanje po poznatoj seriji niti izmišlja porijeklo.')
    plan['coverage'] = coverage
    return plan


@transaction.atomic
def make_preview(kind, target_id, data, user):
    from .request_cache import begin_request_cache, end_request_cache
    cache = begin_request_cache(enabled=False)
    try:
        before = digest(captured_rows())
        plan = preview(kind, target_id, data, user)
        require(before == digest(captured_rows()), 'Podaci su se promijenili tokom pregleda. Ponovite pregled.')
        payload = {'operation_id': str(uuid.uuid4()), 'user_id': user.pk, 'kind': kind,
                   'target_id': target_id, 'data': serial(data), 'fingerprint': before}
        return plan, signing.dumps(payload, salt=SALT, compress=True)
    finally:
        end_request_cache(cache)


def confirm(token, user, *, kind, target_id):
    authorize(user, kind)
    try:
        payload = signing.loads(token, salt=SALT)
    except signing.BadSignature:
        raise CorrectionBlocked('Pregled nije važeći. Ponovo pregledajte ispravku.') from None
    require(payload['user_id'] == user.pk and payload['kind'] == kind and payload['target_id'] == target_id,
            'Potvrda ne pripada ovom korisniku, zapisu ili vrsti korekcije.')
    with correction_transaction():
        existing = m.PatientDataCorrection.objects.filter(operation_id=payload['operation_id']).first()
        if existing:
            return existing, False
        try:
            signing.loads(token, salt=SALT, max_age=1800)
        except signing.BadSignature:
            raise CorrectionBlocked('Pregled je istekao. Ponovo pregledajte ispravku.') from None
        before = captured_rows()
        require(digest(before) == payload['fingerprint'], 'Podaci su se promijenili nakon pregleda. Ništa nije upisano; napravite novi pregled.')
        plan = preview(kind, target_id, payload['data'], user)
        try:
            backup = backup_before_correction(payload['operation_id'])
        except Exception as exc:
            raise CorrectionBlocked('Sigurnosna kopija nije verificirana. Korekcija nije upisana; provjerite backup.') from exc
        return apply_plan(plan, user, payload['operation_id'], backup), True


@transaction.atomic
def apply_plan(plan, user, operation_id, backup):
    """Existing write path, also used inside a locked retrospective batch."""
    kind, target_id = plan['kind'], plan['target_id']
    authorize(user, kind)
    before = captured_rows()
    receipt = m.PatientDataCorrection.objects.create(operation_id=operation_id,
        pacijent_id=plan['patient_id'], korisnik=user, scope='inventory_'+kind,
        izvorna_transakcija_id=plan.get('original_movement_id'), datum_dogadjaja=plan['event_date'],
        ponistava_id=plan.get('reverse_of'), razlog=plan['reason'], posljedice=serial(plan), backup=backup)
    _apply(plan, receipt, user)
    old, new = differences(before, captured_rows())
    if kind == 'receipt_metadata':
        table, key = m.ZalihaTransakcija._meta.db_table, str(target_id)
        # Persist the original unchanged full row alongside the effective labels.
        old.setdefault(table, {})[key] = before[table][key]
        new.setdefault(table, {})[key] = before[table][key]
    receipt.prije, receipt.poslije = old, new
    receipt.save(update_fields=['prije', 'poslije'])
    from .utils import upisi_log
    upisi_log(user, plan['title'], pacijent=receipt.pacijent, objekat=receipt,
              opis=f"{plan['reason']} · izvor #{target_id} · korekcija #{receipt.pk}")
    return receipt


def _apply(plan, receipt, user):
    if plan['kind'] == 'receipt_metadata':
        # The immutable audit itself is the effective metadata. Do not write a
        # zero stock movement, relabel old lots, or recalculate clinical drafts.
        return
    if plan['kind'] == 'patient_stock':
        from .patient_fridge_corrections import apply_correction
        return apply_correction(plan, receipt, user)
    medicine = m.Lijek.objects.get(pk=plan['medicine_id'])
    stock = m.Zaliha.objects.get(lijek=medicine)
    def movement(delta, *, reservation=None, reservation_delta=0, movement_type='KOREKCIJA', quantity=None, location='FRIZIDER'):
        return m.ZalihaTransakcija.objects.create(lijek=medicine, tip=movement_type,
            kolicina=delta if quantity is None else quantity, promjena_salda=delta,
            datum=timezone.localdate(), pacijent_id=getattr(reservation, 'pacijent_id', None) or plan['patient_id'],
            korisnik=user, referenca_tip='ZalihaTransakcija' if plan.get('original_movement_id') else 'PatientDataCorrection',
            referenca_id=plan.get('original_movement_id') or receipt.pk,
            izvorna_transakcija_id=plan.get('original_movement_id'), korekcija=receipt,
            rezervacija=reservation, promjena_rezervacije=reservation_delta,
            operation_id=receipt.operation_id, serija=plan['batch'],
            rok_trajanja=plan['expires'] or None, lokacija=location, napomena=plan['reason'])
    if plan['kind'] in {'receipt', 'allocation'}:
        for allocation in plan['allocations']:
            res = m.PacijentRezervacija.objects.get(pk=allocation['reservation_id'])
            res.kolicina = allocation['reserved_after']
            res.aktivno = res.kolicina > 0
            res.save(update_fields=['kolicina', 'aktivno'])
            req = m.Trebovanje.objects.get(pk=allocation['request_id'])
            req.zaprimljene_doze += allocation['delta']
            req.status = 'ZAPRIMLJENO' if req.zaprimljene_doze >= (req.odobrene_doze if req.odobrene_doze is not None else req.broj_doza) else req.STATUS_CEKA_ISPORUKU
            req.zaduzenje_kreirano = req.status == 'ZAPRIMLJENO'
            req.save(update_fields=['zaprimljene_doze', 'status', 'zaduzenje_kreirano'])
            movement(allocation['delta'] if plan['kind'] == 'receipt' else 0,
                     reservation=res, reservation_delta=allocation['delta'])
        if not plan['allocations']:
            movement(plan['stock_delta'])
        elif plan['kind'] == 'receipt':
            # A documented new receipt may include free units. Their correction
            # needs its own movement, separate from reservation corrections.
            free_delta = plan['stock_delta'] - sum((a['delta'] for a in plan['allocations']), Decimal(0))
            if free_delta:
                movement(free_delta)
        cycle_ids = set(m.Trebovanje.objects.filter(pk__in=[a['request_id'] for a in plan['allocations']])
                        .values_list('komisijski_ciklus_id', flat=True)) - {None}
        if plan.get('original_movement_id'):
            original_cycle = m.ZalihaTransakcija.objects.filter(pk=plan['original_movement_id']).values_list(
                'komisijski_ciklus_id', flat=True).first()
            if original_cycle:
                cycle_ids.add(original_cycle)
        from dashboard.receipt_display import physically_complete
        for cycle in m.KomisijskiCiklus.objects.filter(pk__in=cycle_ids):
            outstanding = not physically_complete(cycle)
            if outstanding and cycle.status == 'ZAPRIMLJENO':
                cycle.status = 'DJELOMICNO_ZAPRIMLJENO'
                cycle.save(update_fields=['status'])
    elif plan['kind'] == 'issue':
        issue = m.KucnoIzdavanje.objects.get(pk=plan['issue_id'])
        assignment = issue.pacijent_zaduzenje
        assignment.ukupno_zaduzeno += plan['delta']
        assignment.preostalo += plan['delta']
        assignment.aktivno = assignment.preostalo > 0
        assignment.save(update_fields=['ukupno_zaduzeno', 'preostalo', 'aktivno'])
        commission = issue.komisija
        commission.preostale_doze -= plan['delta']
        if commission.status in {'AKTIVNA', 'POTROSENA'}:
            commission.status = 'AKTIVNA' if commission.preostale_doze > 0 else 'POTROSENA'
        commission.save(update_fields=['preostale_doze', 'status'])
        for item in plan['reservations']:
            res = m.PacijentRezervacija.objects.get(pk=item['id'])
            res.kolicina, res.aktivno = item['after'], item['after'] > 0
            res.potrosena_at = None if res.aktivno else res.potrosena_at
            res.save(update_fields=['kolicina', 'aktivno', 'potrosena_at'])
        movement(plan['stock_delta'], reservation=res if plan['reservations'] else None,
                 reservation_delta=-plan['delta'] if plan['reservations'] else 0)
    elif plan['kind'] == 'return':
        issue = m.KucnoIzdavanje.objects.get(pk=plan['issue_id'])
        assignment = issue.pacijent_zaduzenje
        assignment.preostalo -= plan['quantity']
        assignment.aktivno = assignment.preostalo > 0
        assignment.save(update_fields=['preostalo', 'aktivno'])
        movement(0, movement_type='POVRAT', quantity=plan['quantity'], location='KARANTIN')
    elif plan['kind'] == 'writeoff':
        movement(-plan['stock_delta'], movement_type='OTPIS', quantity=-plan['stock_delta'])
    else:
        movement(0)
    stock.u_frizideru += plan['stock_delta']
    stock.kod_pacijenata += plan['home_delta']
    # Explicit loss can expose an existing reservation shortfall, not erase it.
    if plan['kind'] in {'writeoff', 'return', 'receipt_date'}:
        m.Zaliha.objects.filter(pk=stock.pk).update(u_frizideru=stock.u_frizideru,
            ukupno=stock.u_frizideru, kod_pacijenata=stock.kod_pacijenata)
    else:
        stock.save(update_fields=['u_frizideru', 'kod_pacijenata', 'ukupno'])
    from .inventory import izracunaj_frizider_iz_transakcija
    require(izracunaj_frizider_iz_transakcija(medicine) == stock.u_frizideru, 'Kontrola prometa nije prošla. Cijela korekcija je poništena.')
    from .commission_planning import recalculate_patient_commission_drafts
    patients = {a['patient_id'] for a in plan.get('allocations', [])}
    if plan['patient_id']:
        patients.add(plan['patient_id'])
    for patient in m.Pacijent.objects.filter(pk__in=patients):
        recalculate_patient_commission_drafts(patient, user=user, reason=f'Ispravka #{receipt.pk}: {plan["reason"]}')
