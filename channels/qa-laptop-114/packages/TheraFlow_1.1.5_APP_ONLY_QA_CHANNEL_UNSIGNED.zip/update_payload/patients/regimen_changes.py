"""Date-aware overlay for confirmed nursing entries of a doctor's order.

Historical protocol/therapy records remain untouched. Each reader asks for
the date it is planning/administering; only the selected presentation applies.
"""
from dataclasses import replace
from datetime import timedelta
from decimal import Decimal

from django.utils import timezone
from .request_cache import get_or_set


def changes_for(patient, *, phase_scope=None):
    if not patient.pk or not patient.lijek_id:
        return ()
    from .models import BrzaIzmjenaPacijenta
    from .request_cache import request_cache_enabled
    if request_cache_enabled() and hasattr(patient, '_workflow_regimen_changes'):
        orders = tuple(c for c in patient._workflow_regimen_changes if c.lijek_id == patient.lijek_id)
    else:
        orders = get_or_set("dated_regimen_changes", (patient.pk, patient.lijek_id), lambda: tuple(
            BrzaIzmjenaPacijenta.objects.filter(pacijent=patient, lijek_id=patient.lijek_id,
                vrsta__in=["interval", "dose"]).order_by("vrijedi_od", "kreirano", "pk")
        ))
    from .therapy_protocol_identity import current_course_change
    course = current_course_change(patient)
    if course:
        start = course.datum_pocetka_nove_terapije
        previous_ids = set(course.prethodni_zapisi.get('order_ids', []))
        orders = tuple(c for c in orders if c.pk not in previous_ids and timezone.localdate(c.kreirano) >= start and c.vrijedi_od >= start)
    if not any(change.promjena_rezima.get('phase_scope') for change in orders):
        return orders
    phase = patient.aktivni_fazni_protokol()
    key = phase_scope or (phase.faza if phase else None)
    return tuple(change for change in orders if not change.promjena_rezima.get('phase_scope')
        or change.promjena_rezima['phase_scope'] == key)


def regimen_override(patient, on=None, *, phase_scope=None):
    on = on or timezone.localdate()
    values = {}
    for change in changes_for(patient, phase_scope=phase_scope):
        if change.vrijedi_od <= on:
            values.update({key:value for key,value in change.promjena_rezima.items() if key != 'phase_scope'})
    return values


def overlay_protocol(patient, protocol, on=None):
    change = regimen_override(patient, on)
    if not change or not protocol:
        return protocol
    fields = {}
    for key in ("doza_mg", "broj_jedinica"):
        if key in change:
            fields[key] = Decimal(change[key])
    if "interval_sedmica" in change:
        fields["interval_sedmica"] = int(change["interval_sedmica"])
    return replace(protocol, steps=tuple(
        replace(step, **fields) if step.faza == "ODRZAVANJE" else step for step in protocol.steps))


def next_regimen_date(patient, anchor, base_interval):
    """Order starts on its effective date, never silently backdates a dose."""
    interval = int(base_interval)
    candidate = anchor + timedelta(weeks=interval)
    for change in changes_for(patient):
        weeks = change.promjena_rezima.get("interval_sedmica")
        if weeks is not None and change.vrijedi_od <= candidate:
            interval = int(weeks)
            candidate = max(anchor + timedelta(weeks=interval), change.vrijedi_od)
    return interval, candidate


def regimen_quantity(patient, on, fallback):
    value = regimen_override(patient, on).get("broj_jedinica")
    return Decimal(value) if value is not None else fallback
