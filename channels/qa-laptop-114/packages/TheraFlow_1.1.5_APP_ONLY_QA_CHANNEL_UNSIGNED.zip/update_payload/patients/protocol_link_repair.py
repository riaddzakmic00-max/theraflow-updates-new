"""Controlled link repair, based only on recorded therapy-change evidence.

Preview is read-only. Confirmation requires the same signed review, an authorised
clinical user, unchanged database state and the established verified backup.
No dose, appointment, administration, approval or inventory row is rewritten.
"""
from uuid import uuid4
from django.core import signing
from django.db import transaction
from . import models as m
from .data_corrections import captured_rows, digest, differences, serial, require, backup_before_correction
from .request_cache import begin_request_cache, end_request_cache

SALT = "theraflow.protocol-link-repair.v1"


def authorize(user):
    from dashboard.permissions import je_doktor_ili_admin
    require(user and user.is_active and je_doktor_ili_admin(user), "Ispravku veze potvrđuje ljekar ili administrator.")


def repair_plan(patient, reason):
    require(bool(reason.strip()), "Unesite razlog ispravke.")
    change = patient.promjene_terapije.order_by("-datum_pocetka_nove_terapije", "-pk").first()
    require(change is not None, "Nema evidentirane promjene terapije; lijek se ne zaključuje iz zaduženja ili komisije.")
    require(patient.lijek_id == change.novi_lijek_id, "Trenutni lijek i posljednja promjena nisu usklađeni. Potrebna je provjera kliničke odluke.")
    product = change.novi_lijek
    require(product.terapijski_program_id is not None, "Lijek nema povezan terapijski program.")
    protocol = change.novi_protokol
    require(not protocol or protocol.lijek_id in product.equivalent_ids(), "Evidentirani novi protokol pripada drugom lijeku.")
    updates = {}
    if patient.terapijski_program_id != product.terapijski_program_id:
        updates['terapijski_program_id'] = product.terapijski_program_id
    if patient.terapijski_protokol_id != change.novi_protokol_id:
        updates['terapijski_protokol_id'] = change.novi_protokol_id
    try:
        order = patient.individualni_protokol
    except m.IndividualniProtokolPacijenta.DoesNotExist:
        order = None
    from .therapy_protocol_identity import individual_matches
    deactivate = bool(order and order.aktivan and not individual_matches(patient, order))
    if updates or deactivate:
        updates['protokol_za_potvrdu'] = True
    require(bool(updates), "Nema dokazano neusklađenih veza za ispravku.")
    return dict(patient_id=patient.pk, change_id=change.pk, reason=reason.strip(),
        updates=updates, deactivate_order_id=order.pk if deactivate else None,
        rows=[dict(field=k, before=getattr(patient, k), after=v) for k,v in updates.items()],
        warnings=["Novi nalog ostaje na potvrdi ljekara. Koraci individualnog naloga se ne prevezuju automatski.",
                  "Primjene, termini, komisije, zaduženja i fizičke količine ostaju nepromijenjeni."])


def make_preview(patient, reason, user):
    authorize(user)
    token = begin_request_cache(enabled=False)
    try:
        plan = repair_plan(patient, reason)
        payload = dict(operation=str(uuid4()), user=user.pk, plan=serial(plan), fingerprint=digest(captured_rows()))
        return plan, signing.dumps(payload, salt=SALT, compress=True)
    finally:
        end_request_cache(token)


def confirm(token, user, *, confirmed=False):
    authorize(user)
    require(confirmed, "Potrebna je izričita potvrda prikazanog pregleda.")
    payload = signing.loads(token, salt=SALT, max_age=1800)
    require(payload['user'] == user.pk, "Pregled pripada drugom korisniku.")
    cache = begin_request_cache(enabled=False)
    try:
        with transaction.atomic():
            existing = m.PatientDataCorrection.objects.filter(operation_id=payload['operation']).first()
            if existing:
                return existing, False
            patient = m.Pacijent.objects.select_for_update().get(pk=payload['plan']['patient_id'])
            before = captured_rows()
            require(digest(before) == payload['fingerprint'], "Podaci su promijenjeni nakon pregleda. Ponovo pregledajte ispravku.")
            plan = repair_plan(patient, payload['plan']['reason'])
            require(serial(plan) == payload['plan'], "Predložena ispravka se promijenila.")
            backup = backup_before_correction(payload['operation'])
            m.Pacijent.objects.filter(pk=patient.pk).update(**plan['updates'])
            if plan['deactivate_order_id']:
                order = m.IndividualniProtokolPacijenta.objects.select_for_update().get(pk=plan['deactivate_order_id'])
                old = order.snapshot()
                order.aktivan = False
                order.save(update_fields=['aktivan', 'datum_izmjene'])
                m.IzmjenaIndividualnogProtokola.objects.create(protokol=order, korisnik=user,
                    razlog=plan['reason'], prethodno_stanje=old, novo_stanje=order.snapshot())
            after = captured_rows()
            allowed = {'patients_pacijent', 'patients_individualniprotokolpacijenta', 'patients_izmjenaindividualnogprotokola'}
            require(all(before[t] == after[t] for t in before if t not in allowed), "Ispravka je pokušala izmijeniti zaštićene zapise; poništena je.")
            old, new = differences(before, after)
            receipt = m.PatientDataCorrection.objects.create(operation_id=payload['operation'], pacijent=patient,
                korisnik=user, scope='protocol_links', razlog=plan['reason'][:500], prije=old, poslije=new,
                posljedice=serial(plan), backup=backup)
            from .utils import upisi_log
            upisi_log(user, 'Kontrolisana ispravka veze protokola', pacijent=patient, objekat=receipt, opis=plan['reason'])
            return receipt, True
    finally:
        end_request_cache(cache)
