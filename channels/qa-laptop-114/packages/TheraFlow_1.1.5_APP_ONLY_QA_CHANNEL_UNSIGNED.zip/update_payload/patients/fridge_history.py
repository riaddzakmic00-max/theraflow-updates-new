"""Dated physical balances. Never subtract patient reservations from a fridge."""
from collections import defaultdict
from decimal import Decimal
from hashlib import sha256
from zoneinfo import ZoneInfo

from django.utils import timezone

from .models import (HistorijskoStanjeFrizidera, IzdavanjeOralneTerapije, KucnoIzdavanje,
                     Terapija, Zaliha, ZalihaTransakcija)

REPORT_ZONE = ZoneInfo("Europe/Sarajevo")
UNKNOWN = "Nema dovoljno podataka"


def remember_fridge_checkpoint(initial):
    """Called under the existing opening-balance transaction/row lock."""
    identity = f"{initial.pk}:{initial.izmijenjeno.isoformat()}:{initial.ledger_checkpoint_id or 0}:{initial.kolicina:.2f}"
    return HistorijskoStanjeFrizidera.objects.get_or_create(
        snapshot_key=sha256(identity.encode()).hexdigest(),
        defaults={"pocetno_stanje": initial, "kolicina": initial.kolicina,
                  "ledger_checkpoint_id": initial.ledger_checkpoint_id,
                  "stanje_at": initial.izmijenjeno},
    )[0]


def fridge_balances_at(cutoff, *, current=False):
    """Per-SKU physical totals, or an explicit unknown with an explanation.

    Closed periods use an immutable checkpoint on/before the cutoff plus
    physical ledger deltas after its ID. Neither today's stock nor a later
    checkpoint is extrapolated backwards. A backdated entry preceding the
    checkpoint, missing clinical ledger entries or negative balances fail closed.
    """
    def unknown(reason):
        return {"quantity": None, "reason": reason}

    if current:
        return {stock.lijek_id: ({"quantity": stock.u_frizideru, "reason": "Ukupna fizička zaliha u frižideru."}
                                if stock.u_frizideru is not None and stock.u_frizideru >= 0 else unknown(UNKNOWN))
                for stock in Zaliha.objects.all()}

    histories = HistorijskoStanjeFrizidera.objects.select_related("pocetno_stanje").order_by("stanje_at", "pk")
    anchors = {}
    for item in histories:
        if timezone.localdate(item.stanje_at, REPORT_ZONE) <= cutoff:
            anchors[item.pocetno_stanje.lijek_id] = item
    result = {}
    ledger = defaultdict(list)
    for tx in ZalihaTransakcija.objects.filter(datum__lte=cutoff).select_related('korekcija','izvorna_transakcija').order_by("datum", "pk"):
        ledger[tx.lijek_id].append(tx)
    # Exact ID lookup is necessary: a checkpoint can refer to a future-dated
    # entry already folded into the balance. Such an anchor is not trustworthy.
    boundary_ids = {item.ledger_checkpoint_id for item in anchors.values() if item.ledger_checkpoint_id}
    boundaries = ZalihaTransakcija.objects.in_bulk(boundary_ids)
    supported_types = {value for value, _ in ZalihaTransakcija.TIPOVI}

    known_drugs = set(Zaliha.objects.values_list("lijek_id", flat=True))
    for drug_id in set(ledger) | set(anchors) | known_drugs:
        anchor = anchors.get(drug_id)
        if anchor is None:
            result[drug_id] = unknown("Nema potvrđenog ukupnog početnog stanja do odabranog datuma.")
            continue
        day = timezone.localdate(anchor.stanje_at, REPORT_ZONE)
        checkpoint = anchor.ledger_checkpoint_id or 0
        if checkpoint and (checkpoint not in boundaries or boundaries[checkpoint].lijek_id != drug_id
                           or ZalihaTransakcija.objects.filter(lijek_id=drug_id, pk__lte=checkpoint, datum__gt=day).exists()):
            result[drug_id] = unknown("Početno stanje nema pouzdanu granicu kretanja zalihe.")
            continue
        quantity = anchor.kolicina
        reason = None
        from .retrospective_reconciliation import dated_movements
        for tx, delta in dated_movements([tx for tx in ledger[drug_id] if tx.pk > checkpoint]):
            if tx.tip not in supported_types:
                reason = "Historija sadrži neprepoznato kretanje zalihe."
                break
            if delta and tx.datum < day:
                reason = "Postoji naknadno uneseno kretanje prije potvrđenog početnog stanja."
                break
            quantity += delta
            if quantity < 0:
                reason = "Evidentirana kretanja daju negativno fizičko stanje."
                break
        result[drug_id] = unknown(reason) if reason else {"quantity": quantity,
            "reason": f"Potvrđeno stanje {day:%d/%m/%Y} i evidentirana fizička kretanja do {cutoff:%d/%m/%Y}."}

    # Clinical history without a physical ledger cannot establish a closing
    # stock, even when it can still contribute to the consumption report.
    if anchors:
        earliest = min(timezone.localdate(item.stanje_at, REPORT_ZONE) for item in anchors.values())
        linked = {(tx.referenca_tip, tx.referenca_id) for entries in ledger.values() for tx in entries
                  if tx.tip in {"AMBULANTNA_POTROSNJA", "KUCNO_IZDAVANJE", "ORALNO_IZDAVANJE"}}
        issues = list(KucnoIzdavanje.objects.filter(datum__range=(earliest, cutoff))
                      .select_related("lijek", "terapija"))
        home_therapy_ids = {issue.terapija_id for issue in issues if issue.terapija_id}
        sources = [*issues,
            *Terapija.objects.filter(datum__range=(earliest, cutoff), is_migration=False).select_related("lijek"),
            *IzdavanjeOralneTerapije.objects.filter(datum_izdavanja__range=(earliest, cutoff),
                                                   is_migration_snapshot=False).select_related("lijek")]
        for source in sources:
            anchor = anchors.get(source.lijek_id)
            if not anchor or result[source.lijek_id]["quantity"] is None:
                continue
            when = source.datum_izdavanja if isinstance(source, IzdavanjeOralneTerapije) else source.datum
            if when < timezone.localdate(anchor.stanje_at, REPORT_ZONE):
                continue
            if isinstance(source, Terapija) and (source.workflow_snapshot or {}).get("vrsta") == "KUCNA_PRIMJENA":
                continue
            key = (type(source).__name__, source.pk)
            if key in linked or (isinstance(source, Terapija) and source.pk in home_therapy_ids):
                continue
            if isinstance(source, KucnoIzdavanje) and ("Terapija", source.terapija_id) in linked:
                continue
            result[source.lijek_id] = unknown("Nedostaje povezano fizičko kretanje za evidentiranu primjenu ili izdavanje.")
    return result
