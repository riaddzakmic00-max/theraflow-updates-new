"""Generički, atomski workflow režima i izdavanja oralne terapije."""

import uuid
from datetime import timedelta
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_HALF_UP

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q, Sum
from django.utils import timezone

from .transaction_locking import select_for_update_self


def _decimal(value):
    try:
        return Decimal(str(value or 0))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError("Količina nije ispravan broj.") from exc


def tablets_for_days(regimen, days, start_date=None):
    """Vrati tačan broj tableta; nikada ne zaokružuje prijedlog tiho."""

    days = int(days or 0)
    if days <= 0:
        raise ValueError("Broj dana mora biti veći od nule.")
    from .oral_regimen_dates import consumption_between
    quantity = consumption_between(regimen, start_date or timezone.localdate(), days)
    if quantity != quantity.to_integral_value():
        raise ValueError(
            "Izabrani broj dana ne daje cijeli broj tableta. "
            "Unesite konačnu količinu tableta ručno."
        )
    return int(quantity)


def oral_issue_projection(regimen, days, start_date=None):
    """Izračunaj fizički izvodivu količinu za željeni period izdavanja.

    Projekcija koristi potvrđeni dnevni režim i konfiguraciju konkretnog SKU-a.
    Kada se lijek izdaje isključivo u cijelim pakovanjima, prijedlog se zaokružuje
    naviše na prvo cijelo pakovanje i vraća stvarnu, a ne samo željenu
    pokrivenost. Backend izdavanja i dalje ponavlja sve sigurnosne provjere.
    """

    days = int(days or 0)
    if days <= 0:
        raise ValueError("Broj dana mora biti veći od nule.")
    daily = _decimal(regimen.tableta_dnevno)
    if daily <= 0:
        raise ValueError("Dnevna doza mora biti veća od nule.")

    medicine = regimen.lijek
    from .oral_regimen_dates import consumption_between, covered_full_days, dated_rates
    start_date = start_date or timezone.localdate()
    requested_tablets = consumption_between(regimen, start_date, days)
    package_size = int(medicine.broj_tableta_u_pakovanju or 0)
    if medicine.izdavanje_cijelih_pakovanja:
        if package_size <= 0:
            raise ValueError(
                "Lijek je podešen za izdavanje cijelih pakovanja, ali veličina "
                "pakovanja nije konfigurirana."
            )
        package_count = int(
            (requested_tablets / Decimal(package_size)).to_integral_value(
                rounding=ROUND_CEILING
            )
        )
        quantity = package_count * package_size
    else:
        quantity = int(requested_tablets.to_integral_value(rounding=ROUND_CEILING))
        package_count = (
            quantity // package_size
            if package_size > 0 and quantity % package_size == 0
            else None
        )

    exact_days = (Decimal(quantity) / daily).quantize(
        Decimal("0.0001"),
        rounding=ROUND_HALF_UP,
    )
    if dated_rates(regimen):
        full_days = covered_full_days(regimen, start_date, quantity)
        used = consumption_between(regimen, start_date, full_days)
        next_daily = consumption_between(regimen, start_date+timedelta(days=full_days), 1)
        exact_days = (Decimal(full_days)+(Decimal(quantity)-used)/next_daily).quantize(Decimal("0.0001"))
    return {
        "requested_days": days,
        "requested_tablets": requested_tablets,
        "quantity": quantity,
        "package_size": package_size or None,
        "package_count": package_count,
        "exact_days": exact_days,
        "rounded": Decimal(quantity) != requested_tablets,
    }


def oral_commission_requirement(
    regimen,
    *,
    days,
    approved_remaining=0,
    at_patient=0,
    start_date=None,
):
    """Plan u tabletama i nabavnim pakovanjima za zadani horizont komisije."""

    from .package_sizes import procurement_breakdown

    gross = Decimal(tablets_for_days(regimen, days, start_date=start_date))
    remaining = max(Decimal("0"), _decimal(approved_remaining))
    issued_remaining = max(Decimal("0"), _decimal(at_patient))
    already_covered = remaining + issued_remaining
    net = max(Decimal("0"), gross - already_covered)
    procurement = procurement_breakdown(net, regimen.lijek)
    return {
        "days": int(days),
        "gross_tablets": gross,
        "approved_remaining": remaining,
        "at_patient": issued_remaining,
        "already_covered": already_covered,
        # Klinička neto potreba ostaje vidljiva i nikada se tiho ne zaokružuje.
        "tablets_to_request": net,
        # Nabavni prijedlog poštuje cijelo pakovanje i koristi ispravnu jedinicu.
        "procurement_tablets": procurement["rounded_procurement_units"],
        "packages_to_request": procurement["package_count"],
        "package_size": procurement["units_per_package"],
        "procurement": procurement,
    }


def oral_commission_timeline(
    regimen,
    *,
    today=None,
    at_patient=0,
    approved_remaining=0,
):
    """Planiraj oralnu komisiju prema stvarnom datumu očekivane isporuke.

    Izdato pacijentu i preostalo odobreno predstavljaju dva odvojena izvora,
    ali oba odgađaju prvi dan bez administrativnog pokrića. Novi zahtjev se
    računa za ciljni period koji počinje tek na očekivani datum isporuke, pa
    se ne oduzimaju tablete koje će do tada već biti potrošene.
    """

    from .commission_eligibility import commission_windows
    from .commission_service import get_settings
    from .package_sizes import procurement_breakdown

    today = today or timezone.localdate()
    daily = _decimal(regimen.tableta_dnevno)
    if daily <= 0:
        raise ValueError("Dnevna doza mora biti veća od nule.")

    issued = max(Decimal("0"), _decimal(at_patient))
    approved = max(Decimal("0"), _decimal(approved_remaining))
    # Fizička pokrivenost oralne terapije postoji samo za tablete koje su
    # stvarno izdate pacijentu. Neiskorišteno odobreno pravo ostaje zaseban
    # administrativni izvor i ne smije odgoditi datum prvog fizičkog manjka.
    from .oral_regimen_dates import covered_full_days, consumption_between
    physical_full_days = covered_full_days(regimen, today, issued)
    physical_covered_until = (
        today + timedelta(days=physical_full_days - 1)
        if physical_full_days > 0 else None
    )
    first_uncovered = today + timedelta(days=physical_full_days)

    total_covered = issued + approved
    administrative_full_days = covered_full_days(regimen, today, total_covered)
    administratively_covered_until = (
        today + timedelta(days=administrative_full_days - 1)
        if administrative_full_days > 0 else None
    )
    commission_first_uncovered = today + timedelta(
        days=administrative_full_days
    )

    settings = get_settings()
    windows = commission_windows(today=today, settings=settings)
    safe_windows = tuple(
        window
        for window in windows
        if window.najkasnija_isporuka <= commission_first_uncovered
    )
    first_safe = safe_windows[0] if safe_windows else None
    latest_safe = safe_windows[-1] if safe_windows else None
    # Najkasniji siguran ciklus sprječava prerano traženje. Ako nijedan ne
    # stiže na vrijeme, prvi dostupni ciklus ostaje operativni izbor uz rizik.
    recommended = latest_safe or (windows[0] if windows else None)
    expected_delivery = (
        recommended.najkasnija_isporuka if recommended else today
    )
    days_until_delivery = max((expected_delivery - today).days, 0)
    physical_remaining_at_delivery = max(
        Decimal("0"),
        issued - consumption_between(regimen, today, days_until_delivery),
    )
    coverage_remaining_at_delivery = max(
        Decimal("0"),
        total_covered - consumption_between(regimen, today, days_until_delivery),
    )
    target_days = max(int(settings.ciljni_broj_dana_pokrivenosti or 90), 1)
    requirement = oral_commission_requirement(
        regimen,
        days=target_days,
        start_date=expected_delivery,
        approved_remaining=coverage_remaining_at_delivery,
        at_patient=0,
    )
    standard_procurement = procurement_breakdown(
        requirement["gross_tablets"],
        regimen.lijek,
    )
    target_period_start = expected_delivery
    target_period_end = target_period_start + timedelta(days=target_days - 1)
    needs_commission = requirement["tablets_to_request"] > 0
    preparation_deadline = recommended.rok_pripreme if recommended else None
    must_use_current_cycle = bool(
        needs_commission
        and recommended is not None
        and windows
        and recommended.datum_komisije == windows[0].datum_komisije
    )
    due_now = bool(
        needs_commission
        and (
            recommended is None
            or preparation_deadline is None
            or preparation_deadline <= today
        )
    )
    delivery_risk = bool(
        needs_commission
        and recommended is not None
        and not safe_windows
    )
    return {
        "requirement": requirement,
        # Klinička standardna potreba nije operativni zahtjev. Ona opisuje
        # samo koliko potvrđeni režim troši u ciljnom broju dana.
        "standard_requirement": {
            "days": target_days,
            "tablets": requirement["gross_tablets"],
            "procurement": standard_procurement,
        },
        # Neto vrijednost requirementa pripada projekciji na očekivani datum
        # isporuke. Period i početno pokriće moraju putovati zajedno s njom da
        # se buduća projekcija nikad ne predstavi kao današnja potreba.
        "future_requirement": {
            "period_start": target_period_start,
            "period_end": target_period_end,
            "gross_tablets": requirement["gross_tablets"],
            "covered_at_period_start": coverage_remaining_at_delivery,
            "net_tablets": requirement["tablets_to_request"],
            "procurement": requirement["procurement"],
        },
        "daily_tablets": daily,
        "issued_remaining": issued,
        "approved_remaining": approved,
        "total_covered": total_covered,
        "physical_covered_until": physical_covered_until,
        "administratively_covered_until": administratively_covered_until,
        "first_uncovered": first_uncovered,
        "commission_first_uncovered": commission_first_uncovered,
        "first_safe_cycle": first_safe,
        "latest_safe_cycle": latest_safe,
        "recommended_cycle": recommended,
        "expected_delivery": expected_delivery if recommended else None,
        "preparation_deadline": preparation_deadline,
        "physical_remaining_at_delivery": physical_remaining_at_delivery,
        "remaining_at_delivery": coverage_remaining_at_delivery,
        "needs_commission": needs_commission,
        "must_use_current_cycle": must_use_current_cycle,
        "due_now": due_now,
        "delivery_risk": delivery_risk,
        "schedule_configured": bool(windows),
    }


def _coverage_values(*, quantity, tablets_daily, starts_on):
    tablets_daily = _decimal(tablets_daily)
    if tablets_daily <= 0:
        raise ValueError("Dnevna doza mora biti veća od nule.")
    exact_days = (Decimal(quantity) / tablets_daily).quantize(
        Decimal("0.0001"),
        rounding=ROUND_HALF_UP,
    )
    full_days = int(Decimal(quantity) // tablets_daily)
    covered_until = (
        starts_on + timedelta(days=full_days - 1)
        if full_days > 0
        else None
    )
    next_uncovered = starts_on + timedelta(days=full_days)
    return exact_days, covered_until, next_uncovered


def oral_issue_quantity_remaining(issue, *, today=None):
    """Projektuj fizički ostatak jednog stvarnog oralnog izdavanja.

    Model nema dummy saldo kod pacijenta. Količina se izvodi iz izdate
    količine, njenog kanonskog intervala pokrivenosti i snapshotovane dnevne
    potrošnje. Poništena izdavanja ne predstavljaju fizičku količinu kod
    pacijenta.
    """

    from .models import IzdavanjeOralneTerapije

    if issue.status != IzdavanjeOralneTerapije.STATUS_AKTIVNO:
        return Decimal("0")
    today = today or timezone.localdate()
    starts_on = issue.pokrivenost_od or issue.datum_izdavanja
    elapsed_days = max(0, (today - starts_on).days)
    from .oral_regimen_dates import consumption_between
    consumed = consumption_between(issue.rezim, starts_on, elapsed_days, fallback=issue.tableta_dnevno_snapshot)
    return max(Decimal("0"), _decimal(issue.kolicina_tableta) - consumed)


def oral_quantity_at_patient(*, medicine_ids, patient=None, today=None):
    """Zbir projektovanih preostalih tableta iz aktivnih dispensing zapisa."""

    from .models import IzdavanjeOralneTerapije

    today = today or timezone.localdate()
    issues = IzdavanjeOralneTerapije.objects.filter(
        lijek_id__in=medicine_ids,
        status=IzdavanjeOralneTerapije.STATUS_AKTIVNO,
    )
    if patient is not None:
        issues = issues.filter(pacijent=patient)
    return sum(
        (
            oral_issue_quantity_remaining(issue, today=today)
            for issue in issues.only(
                "status",
                "kolicina_tableta",
                "datum_izdavanja",
                "pokrivenost_od",
                "tableta_dnevno_snapshot",
            )
        ),
        Decimal("0"),
    )


def _documented_oral_approval_links(items):
    """Join two projections only through a verified document's concrete FKs."""
    from .models import Komisija, KomisijskaDokumentStavka, Trebovanje

    items = {item.pk: item for item in items}
    lines = list(KomisijskaDokumentStavka.objects.filter(
        stavka_lijeka_id__in=items, komisija__isnull=False,
    ).exclude(odluka='ceka').select_related('dokument', 'komisija', 'saglasnost'))
    requests = list(Trebovanje.objects.filter(
        komisija_id__in={line.komisija_id for line in lines},
    ).exclude(status=Trebovanje.STATUS_OTKAZANO))
    candidates = {}
    for line in lines:
        item = items[line.stavka_lijeka_id]
        request = item.komisijski_zahtjev
        agreement = getattr(request, 'saglasnost', None)
        commission = line.komisija
        linked = [row for row in requests if row.komisija_id == commission.pk]
        if (not agreement or len(linked) != 1
                or line.komisijski_zahtjev_id != request.pk
                or line.dokument.komisijski_ciklus_id != request.komisijski_ciklus_id
                or line.pacijent_id != request.pacijent_id
                or line.lijek_id != item.lijek_id
                or line.saglasnost_id != agreement.pk
                or line.odluka != agreement.odluka
                or line.odobrena_kolicina_snapshot != item.odobrena_kolicina
                or line.trazena_kolicina_snapshot != item.kolicina
                or line.jedinica_snapshot != item.jedinica
                or commission.pacijent_id != request.pacijent_id
                or commission.lijek_id != item.lijek_id
                or commission.broj_odobrenih_doza != item.odobrena_kolicina
                or commission.status not in (*Komisija.VAZECI_STATUSI, 'POTROSENA')
                or not 0 <= commission.preostale_doze <= commission.broj_odobrenih_doza
                or line.dokument.datum_dokumenta != agreement.datum_saglasnosti
                or commission.datum_odobrenja != agreement.datum_saglasnosti
                or line.dokument.broj_dokumenta != (agreement.broj_saglasnosti or '').strip()
                or (commission.broj_saglasnosti or '').strip() != line.dokument.broj_dokumenta):
            continue
        legacy = linked[0]
        if ((legacy.pacijent_id, legacy.lijek_id, legacy.komisijski_ciklus_id)
                != (request.pacijent_id, item.lijek_id, request.komisijski_ciklus_id)
                or legacy.odobrene_doze != item.odobrena_kolicina):
            continue
        candidates.setdefault(item.pk, []).append(commission)
    # Ambiguous document memberships cannot silently merge independent rights.
    unique = {item_id: matches[0] for item_id, matches in candidates.items() if len(matches) == 1}
    return {item_id: commission for item_id, commission in unique.items()
            if sum(other.pk == commission.pk for other in unique.values()) == 1}


def _approval_item_remaining(item, *, linked_commission=None):
    from .models import IzdavanjeOralneTerapije

    if linked_commission is None:
        linked_commission = _documented_oral_approval_links([item]).get(item.pk)
    if linked_commission is not None:
        issues = IzdavanjeOralneTerapije.objects.filter(
            Q(komisijska_stavka_id=item.pk) | Q(komisija_id=linked_commission.pk),
            status=IzdavanjeOralneTerapije.STATUS_AKTIVNO,
        )
        legacy_used = max(Decimal('0'), linked_commission.broj_odobrenih_doza
                          - linked_commission.preostale_doze)
        legacy_issues = Decimal('0')
        modern_issues = Decimal('0')
        for issue in issues:
            if (issue.pacijent_id != item.komisijski_zahtjev.pacijent_id
                    or issue.lijek_id != item.lijek_id
                    or issue.komisija_id not in (None, linked_commission.pk)
                    or issue.komisijska_stavka_id not in (None, item.pk)):
                return Decimal('0')
            if issue.komisija_id == linked_commission.pk:
                legacy_issues += Decimal(issue.kolicina_tableta)
            else:
                modern_issues += Decimal(issue.kolicina_tableta)
        return max(Decimal('0'), _decimal(item.odobrena_kolicina)
                   - max(legacy_used, legacy_issues) - modern_issues)
    used = _decimal(
        item.oralna_izdavanja.filter(
            status=IzdavanjeOralneTerapije.STATUS_AKTIVNO
        ).aggregate(total=Sum("kolicina_tableta"))["total"]
    )
    return max(Decimal("0"), _decimal(item.odobrena_kolicina) - used)


def approval_options(patient, medicine):
    """Aktivni izvori prava za tačnu prezentaciju lijeka."""

    from .models import Komisija, KomisijskaSaglasnost, KomisijskaStavkaLijeka

    options = []
    items = list(
        KomisijskaStavkaLijeka.objects.filter(
            komisijski_zahtjev__pacijent=patient,
            lijek=medicine,
            odobrena_kolicina__gt=0,
            komisijski_zahtjev__saglasnost__odluka__in=(
                KomisijskaSaglasnost.Odluka.ODOBRENO,
                KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
            ),
        )
        .select_related("komisijski_zahtjev__saglasnost")
        .order_by("komisijski_zahtjev__saglasnost__datum_saglasnosti", "pk")
    )
    linked_commissions = _documented_oral_approval_links(items)
    for item in items:
        remaining = _approval_item_remaining(item, linked_commission=linked_commissions.get(item.pk))
        if remaining <= 0:
            continue
        agreement = item.komisijski_zahtjev.saglasnost
        options.append(
            {
                "value": f"stavka:{item.pk}",
                "kind": "phase3",
                "object": item,
                "remaining": remaining,
                "agreement_number": agreement.broj_saglasnosti or "",
                "approval_date": agreement.datum_saglasnosti,
                "valid_until": None,
                "label": (
                    f"Saglasnost {agreement.broj_saglasnosti or 'bez broja'} · "
                    f"preostalo {remaining:g} tableta"
                ),
            }
        )

    commissions = Komisija.objects.filter(
        pacijent=patient,
        lijek=medicine,
        status__in=Komisija.VAZECI_STATUSI,
        preostale_doze__gt=0,
    ).exclude(pk__in=[commission.pk for commission in linked_commissions.values()]
    ).order_by("datum_odobrenja", "pk")
    for commission in commissions:
        remaining = _decimal(commission.preostale_doze)
        approval_label = (
            commission.broj_saglasnosti
            or commission.datum_odobrenja.strftime("%d/%m/%Y")
        )
        options.append(
            {
                "value": f"komisija:{commission.pk}",
                "kind": "legacy",
                "object": commission,
                "remaining": remaining,
                "agreement_number": commission.broj_saglasnosti or "",
                "approval_date": commission.datum_odobrenja,
                # Datum isteka je historijski podatak, ne kriterij važenja.
                "valid_until": None,
                "label": (
                    f"Komisija {approval_label} · "
                    f"preostalo {remaining:g} tableta"
                ),
            }
        )
    return options


@transaction.atomic
def confirm_oral_regimen(
    *,
    patient,
    medicine,
    tablets_per_intake,
    intakes_per_day,
    effective_from,
    phase,
    standard_regimen=None,
    doctor_note="",
    user=None,
):
    """Potvrdi novi režim i zatvori prethodni bez automatske kliničke odluke."""

    from .models import (
        Lijek,
        OralniTerapijskiRezim,
        Pacijent,
        StandardniOralniRezim,
    )
    from .utils import upisi_log

    patient = Pacijent.objects.select_for_update().get(pk=patient.pk)
    medicine = Lijek.objects.get(pk=medicine.pk)
    if patient.lijek_id != medicine.pk:
        raise ValueError("Režim mora koristiti trenutnu prezentaciju lijeka pacijenta.")
    if not medicine.oralna_terapija or medicine.farmaceutski_oblik != Lijek.OBLIK_TABLETA:
        raise ValueError("Lijek nije podešen kao oralna terapija u tabletama.")
    tablets_per_intake = _decimal(tablets_per_intake)
    if tablets_per_intake <= 0:
        raise ValueError("Broj tableta po uzimanju mora biti veći od nule.")
    try:
        intakes_per_day = int(intakes_per_day)
    except (TypeError, ValueError) as exc:
        raise ValueError("Broj uzimanja dnevno mora biti cijeli broj.") from exc
    if intakes_per_day <= 0:
        raise ValueError("Broj uzimanja dnevno mora biti veći od nule.")
    if phase not in dict(OralniTerapijskiRezim.FAZE):
        raise ValueError("Faza oralne terapije nije ispravna.")
    if not effective_from:
        raise ValueError("Datum početka režima je obavezan.")

    if standard_regimen is not None:
        standard_regimen = StandardniOralniRezim.objects.filter(
            pk=getattr(standard_regimen, "pk", standard_regimen),
            aktivan=True,
        ).first()
        if not standard_regimen or standard_regimen.lijek_id != medicine.pk:
            raise ValueError("Standardni prijedlog ne pripada trenutnom lijeku pacijenta.")
        if (
            tablets_per_intake != _decimal(standard_regimen.tableta_po_uzimanju)
            or intakes_per_day != int(standard_regimen.uzimanja_dnevno)
            or phase != standard_regimen.faza
        ):
            raise ValueError(
                "Potvrđene vrijednosti ne odgovaraju izabranom standardnom prijedlogu."
            )

    previous = list(
        OralniTerapijskiRezim.objects.select_for_update().filter(
            pacijent=patient,
            aktivan=True,
        )
    )
    for regimen in previous:
        regimen.aktivan = False
        regimen.datum_do = max(regimen.datum_od, effective_from - timedelta(days=1))
        regimen.save(update_fields=["aktivan", "datum_do", "izmijenjeno"])

    regimen = OralniTerapijskiRezim.objects.create(
        pacijent=patient,
        lijek=medicine,
        standardni_rezim=standard_regimen,
        tableta_po_uzimanju=tablets_per_intake,
        uzimanja_dnevno=intakes_per_day,
        datum_od=effective_from,
        faza=phase,
        napomena_ljekara=(doctor_note or "").strip(),
        potvrdio=user if getattr(user, "is_authenticated", False) else None,
        aktivan=True,
    )
    upisi_log(
        user,
        "Potvrđen režim oralne terapije",
        pacijent=patient,
        objekat=regimen,
        opis=(
            f"{medicine.prikaz_naziv}: {tablets_per_intake:g} tableta po uzimanju, "
            f"{intakes_per_day} puta dnevno ({regimen.tableta_dnevno:g} tableta/dan); "
            f"faza {regimen.get_faza_display()}."
        ),
    )
    return regimen


def _recalculate_coverage_locked(patient, medicine):
    from .models import IzdavanjeOralneTerapije

    issues = list(
        IzdavanjeOralneTerapije.objects.select_for_update()
        .filter(
            pacijent=patient,
            lijek=medicine,
            status=IzdavanjeOralneTerapije.STATUS_AKTIVNO,
        )
        .order_by("datum_izdavanja", "kreirano", "pk")
    )
    next_uncovered = None
    for issue in issues:
        starts_on = max(
            issue.datum_izdavanja,
            next_uncovered or issue.datum_izdavanja,
        )
        exact_days, covered_until, next_uncovered = _coverage_values(
            quantity=issue.kolicina_tableta,
            tablets_daily=issue.tableta_dnevno_snapshot,
            starts_on=starts_on,
        )
        updates = []
        for field, value in (
            ("pokrivenost_od", starts_on),
            ("pokrivenost_do", covered_until),
            ("sljedeci_nepokriveni_datum", next_uncovered),
            ("pokrivenost_dana", exact_days),
        ):
            if getattr(issue, field) != value:
                setattr(issue, field, value)
                updates.append(field)
        if updates:
            issue.save(update_fields=updates)
    return issues


def _resolve_approval_locked(*, source, patient, medicine):
    from .models import Komisija, KomisijskaSaglasnost, KomisijskaStavkaLijeka

    try:
        kind, raw_id = (source or "").split(":", 1)
        object_id = int(raw_id)
    except (TypeError, ValueError):
        raise ValueError("Izaberite važeću saglasnost ili komisijsko pravo.")

    if kind == "stavka":
        item = (
            select_for_update_self(KomisijskaStavkaLijeka.objects.all())
            .filter(pk=object_id)
            .first()
        )
        if not item or item.komisijski_zahtjev.pacijent_id != patient.pk:
            raise ValueError("Izabrana saglasnost ne pripada pacijentu.")
        if item.lijek_id != medicine.pk:
            raise ValueError("Saglasnost nije za izabranu jačinu lijeka.")
        agreement = getattr(item.komisijski_zahtjev, "saglasnost", None)
        if not agreement or agreement.odluka not in {
            KomisijskaSaglasnost.Odluka.ODOBRENO,
            KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
        }:
            raise ValueError("Komisijska stavka nema važeću odobrenu saglasnost.")
        linked = _documented_oral_approval_links([item]).get(item.pk)
        if linked:
            linked = Komisija.objects.select_for_update().get(pk=linked.pk)
        remaining = _approval_item_remaining(item, linked_commission=linked)
        return {
            "commission": None,
            "item": item,
            "remaining": remaining,
            "agreement_number": agreement.broj_saglasnosti or "",
        }

    if kind == "komisija":
        commission = Komisija.objects.select_for_update().filter(pk=object_id).first()
        if not commission or commission.pacijent_id != patient.pk:
            raise ValueError("Izabrana komisija ne pripada pacijentu.")
        if commission.lijek_id != medicine.pk:
            raise ValueError("Komisija nije za izabranu jačinu lijeka.")
        if not commission.je_vazeca():
            raise ValueError("Izabrana komisija nema preostalih odobrenih tableta.")
        items = list(KomisijskaStavkaLijeka.objects.filter(
            dokument_stavke__komisija=commission,
        ).select_related('komisijski_zahtjev__saglasnost').distinct())
        links = _documented_oral_approval_links(items)
        linked_items = [item for item in items
                        if getattr(links.get(item.pk), 'pk', None) == commission.pk]
        remaining = _decimal(commission.preostale_doze)
        if len(linked_items) == 1:
            item = select_for_update_self(KomisijskaStavkaLijeka.objects.all()).get(pk=linked_items[0].pk)
            remaining = _approval_item_remaining(item, linked_commission=commission)
        return {
            "commission": commission,
            "item": None,
            "remaining": remaining,
            "agreement_number": commission.broj_saglasnosti or "",
        }
    raise ValueError("Izaberite važeću saglasnost ili komisijsko pravo.")


@transaction.atomic
def issue_oral_therapy(
    *,
    patient,
    regimen,
    approval_source,
    quantity,
    issued_on,
    idempotency_key,
    batch="",
    note="",
    suggested_quantity=None,
    adjustment_reason="",
    early_issue_reason="",
    user=None,
    retrospective=False,
    expires_on=None,
):
    """Jednom transakcijom umanji tačnu zalihu i raspoloživo pravo."""

    from .models import (
        IzdavanjeOralneTerapije,
        Lijek,
        OralnoRazduzenjeRezervacije,
        OralniTerapijskiRezim,
        Pacijent,
        Zaliha,
        ZalihaTransakcija,
    )
    from .utils import upisi_log

    patient = Pacijent.objects.select_for_update().get(pk=patient.pk)
    existing = IzdavanjeOralneTerapije.objects.select_for_update().filter(
        idempotency_key=idempotency_key
    ).first()
    if existing:
        if existing.pacijent_id != patient.pk:
            raise ValueError("Ključ izdavanja već pripada drugom pacijentu.")
        if (existing.rezim_id != regimen.pk
                or existing.datum_izdavanja != issued_on
                or existing.kolicina_tableta != _decimal(quantity)):
            raise ValueError("Ključ izdavanja već pripada drugom događaju. Ponovo pregledajte izdavanje.")
        return existing, False
    if retrospective:
        from .retrospective_events import authorize
        authorize(user)
        if issued_on > timezone.localdate():
            raise ValueError('Datum stvarnog izdavanja ne može biti u budućnosti.')
    if not retrospective and not patient.aktivan:
        raise ValueError("Neaktivnom pacijentu nije moguće izdati oralnu terapiju.")

    regimen = select_for_update_self(
        OralniTerapijskiRezim.objects.select_related("lijek")
    ).get(pk=regimen.pk)
    medicine = Lijek.objects.get(pk=regimen.lijek_id)
    if regimen.pacijent_id != patient.pk or (not retrospective and patient.lijek_id != medicine.pk):
        raise ValueError("Aktivni režim ne pripada pacijentu i trenutnom lijeku.")
    from .oral_regimen_dates import regimen_is_confirmed, regimen_on
    if retrospective:
        from .late_event_sources import event_patient
        historical = event_patient(patient, medicine)
        effective_regimen = regimen_on(historical, issued_on)
    else:
        effective_regimen = regimen_on(patient, issued_on)
    if not regimen_is_confirmed(effective_regimen) or effective_regimen.pk != regimen.pk:
        raise ValueError("Oralni terapijski režim nije važeći na datum izdavanja.")
    if issued_on < regimen.datum_od or (
        regimen.datum_do and issued_on > regimen.datum_do
    ):
        raise ValueError("Datum izdavanja nije unutar važenja oralnog režima.")
    if not medicine.oralna_terapija or medicine.farmaceutski_oblik != Lijek.OBLIK_TABLETA:
        raise ValueError("Lijek nije podešen kao oralna terapija u tabletama.")

    raw_quantity = _decimal(quantity)
    if not raw_quantity.is_finite() or raw_quantity <= 0 or raw_quantity != raw_quantity.to_integral_value():
        raise ValueError("Količina mora biti pozitivan cijeli broj tableta.")
    quantity = int(raw_quantity)
    if (
        medicine.izdavanje_cijelih_pakovanja
        and medicine.broj_tableta_u_pakovanju
        and quantity % medicine.broj_tableta_u_pakovanju != 0
    ):
        raise ValueError(
            f"Lijek se izdaje u cijelim pakovanjima od "
            f"{medicine.broj_tableta_u_pakovanju} tableta."
        )

    manual_adjustment = None
    if suggested_quantity is not None:
        raw_suggested = _decimal(suggested_quantity)
        if raw_suggested != Decimal(quantity):
            reason = (adjustment_reason or "").strip()
            if not reason:
                raise ValueError("Unesite razlog ručne korekcije količine.")
            manual_adjustment = {
                "suggested": raw_suggested,
                "final": Decimal(quantity),
                "reason": reason,
            }

    approval = _resolve_approval_locked(
        source=approval_source,
        patient=patient,
        medicine=medicine,
    )
    if retrospective:
        approved_on = (approval['commission'].datum_odobrenja if approval['commission'] else
            approval['item'].komisijski_zahtjev.saglasnost.datum_saglasnosti)
        if approved_on > issued_on:
            raise ValueError('Odobrenje nije postojalo na stvarni datum izdavanja.')
    if expires_on and (not batch or expires_on < issued_on):
        raise ValueError('Provjerite dokumentovanu seriju i rok na datum izdavanja.')
    remaining_before = approval["remaining"]
    if remaining_before < quantity:
        raise ValueError(
            f"Nema dovoljno preostalih odobrenih tableta. "
            f"Dostupno {remaining_before:g}, traženo {quantity}."
        )

    from .inventory import lock_physical_stock
    stock = lock_physical_stock(medicine)
    available = _decimal(stock.u_frizideru) if stock else Decimal("0")
    if not stock or available < quantity:
        raise ValueError(
            f"Nema dovoljno fizičke zalihe tačne jačine. "
            f"Dostupno {available:g}, traženo {quantity}."
        )

    previous_query = (
        IzdavanjeOralneTerapije.objects.select_for_update()
        .filter(
            pacijent=patient,
            lijek=medicine,
            status=IzdavanjeOralneTerapije.STATUS_AKTIVNO,
        )
    )
    if retrospective:
        previous_query = previous_query.filter(datum_izdavanja__lte=issued_on)
    previous = previous_query.order_by('-sljedeci_nepokriveni_datum', '-pk').first()
    is_early_issue = bool(
        previous
        and issued_on < previous.sljedeci_nepokriveni_datum
        and oral_issue_quantity_remaining(previous, today=issued_on) > 0
    )
    early_issue_reason = (early_issue_reason or "").strip()
    if is_early_issue and not early_issue_reason:
        raise ValueError("Razlog ranijeg izdavanja je obavezan.")
    starts_on = max(
        issued_on,
        previous.sljedeci_nepokriveni_datum if previous else issued_on,
    )
    exact_days, covered_until, next_uncovered = _coverage_values(
        quantity=quantity,
        tablets_daily=regimen.tableta_dnevno,
        starts_on=starts_on,
    )

    from .inventory import consume_patient_physical_reservation
    allocation = consume_patient_physical_reservation(
        pacijent=patient, lijek=medicine, quantity=quantity, exact_medicine=True,
        event_date=issued_on if retrospective else None,
    )
    stock.u_frizideru = available - Decimal(quantity)
    stock.save(update_fields=["u_frizideru", "ukupno"])
    remaining_after = remaining_before - Decimal(quantity)
    commission = approval["commission"]
    if commission:
        # A linked modern issuance is already counted by the shared capacity
        # guard. This legacy counter records its own debit, not that debit again.
        commission.preostale_doze = max(Decimal('0'),
            _decimal(commission.preostale_doze) - Decimal(quantity))
        if commission.preostale_doze <= 0:
            commission.preostale_doze = Decimal("0")
            commission.status = "POTROSENA"
        commission.save(update_fields=["preostale_doze", "status"])

    issue_note = (note or "").strip()
    if is_early_issue:
        issue_note = f"{issue_note}\n{early_issue_reason}".strip()
    if manual_adjustment:
        audit_note = (
            f"Ručna korekcija količine: sistem "
            f"{manual_adjustment['suggested']:g} → "
            f"{manual_adjustment['final']:g} tableta. "
            f"Razlog: {manual_adjustment['reason']}"
        )
        issue_note = f"{issue_note}\n{audit_note}".strip()

    issue = IzdavanjeOralneTerapije.objects.create(
        pacijent=patient,
        lijek=medicine,
        rezim=regimen,
        komisija=commission,
        komisijska_stavka=approval["item"],
        kolicina_tableta=quantity,
        datum_izdavanja=issued_on,
        pokrivenost_od=starts_on,
        pokrivenost_do=covered_until,
        sljedeci_nepokriveni_datum=next_uncovered,
        pokrivenost_dana=exact_days,
        jacina_mg_snapshot=medicine.jacina_mg,
        tableta_po_uzimanju_snapshot=regimen.tableta_po_uzimanju,
        uzimanja_dnevno_snapshot=regimen.uzimanja_dnevno,
        tableta_dnevno_snapshot=regimen.tableta_dnevno,
        faza_snapshot=regimen.faza,
        broj_saglasnosti_snapshot=approval["agreement_number"],
        odobreno_preostalo_prije=remaining_before,
        odobreno_preostalo_poslije=remaining_after,
        serija=(batch or "").strip(),
        napomena=issue_note,
        idempotency_key=idempotency_key,
        korisnik_koji_je_izdao=(
            user if getattr(user, "is_authenticated", False) else None
        ),
    )
    for change in allocation["changes"]:
        OralnoRazduzenjeRezervacije.objects.create(
            izdavanje=issue, rezervacija_id=change["rezervacija_id"],
            kolicina=Decimal(change["kolicina"]),
        )
    ZalihaTransakcija.objects.create(
        lijek=medicine,
        tip=ZalihaTransakcija.TIP_ORALNO_IZDAVANJE,
        kolicina=Decimal(quantity),
        datum=issued_on,
        pacijent=patient,
        komisija=commission,
        referenca_tip="IzdavanjeOralneTerapije",
        referenca_id=issue.pk,
        operation_id=idempotency_key,
        jedinica_snapshot=medicine.jedinice_zalihe[0],
        serija=(batch or '').strip(),
        rok_trajanja=expires_on,
        korisnik=user if getattr(user, "is_authenticated", False) else None,
        napomena=(
            f"{medicine.prikaz_naziv}: izdato {quantity} tableta; "
            f"pokrivenost {exact_days:g} dana."
        ),
    )
    _recalculate_coverage_locked(patient, medicine)
    issue.refresh_from_db()
    adjustment_log = ""
    if manual_adjustment:
        adjustment_log = (
            f" Ručna korekcija: sistem {manual_adjustment['suggested']:g} → "
            f"izdato {manual_adjustment['final']:g} tableta; razlog: "
            f"{manual_adjustment['reason']}."
        )
    early_issue_log = (
        f" {early_issue_reason}" if is_early_issue else ""
    )
    upisi_log(
        user,
        "Izdata oralna terapija",
        pacijent=patient,
        objekat=issue,
        opis=(
            f"{medicine.prikaz_naziv}: {quantity} tableta; fizička zaliha "
            f"{available:g} → {stock.u_frizideru:g}; odobreno preostalo "
            f"{remaining_before:g} → {remaining_after:g}; pokrivenost "
            f"{issue.pokrivenost_od:%d/%m/%Y} – "
            f"{issue.pokrivenost_do:%d/%m/%Y}.{adjustment_log}{early_issue_log}" if issue.pokrivenost_do else
            f"{medicine.prikaz_naziv}: {quantity} tableta; manje od jednog punog dana pokrivenosti.{adjustment_log}{early_issue_log}"
        ),
    )
    return issue, True


@transaction.atomic
def record_migrated_oral_dispensing(
    *,
    patient,
    regimen,
    quantity,
    issued_on,
    approved_remaining=0,
    commission=None,
    migration_identifier,
    note="",
    user=None,
):
    """Upiši historijsko izdavanje bez retroaktivne promjene današnjeg salda.

    Snapshot koristi isti kanonski model i coverage engine kao stvarno novo
    izdavanje, ali je eksplicitno označen tako da ne glumi današnju transakciju
    zalihe niti ponovo troši već uneseno *preostalo* komisijsko pravo.
    """

    from .models import IzdavanjeOralneTerapije
    from .utils import upisi_log

    raw_quantity = _decimal(quantity)
    if raw_quantity <= 0 or raw_quantity != raw_quantity.to_integral_value():
        raise ValueError(
            "Količina posljednjeg oralnog izdavanja mora biti pozitivan "
            "cijeli broj tableta."
        )
    if issued_on > timezone.localdate():
        raise ValueError("Datum posljednjeg oralnog izdavanja ne može biti u budućnosti.")
    if regimen.pacijent_id != patient.pk or regimen.lijek_id != patient.lijek_id:
        raise ValueError("Potvrđeni oralni režim ne pripada migriranom pacijentu.")

    idempotency_key = uuid.uuid5(
        uuid.NAMESPACE_URL,
        f"theraflow:oral-migration:{migration_identifier}",
    )
    existing = IzdavanjeOralneTerapije.objects.filter(
        idempotency_key=idempotency_key
    ).first()
    if existing:
        return existing, False

    quantity = int(raw_quantity)
    exact_days, covered_until, next_uncovered = _coverage_values(
        quantity=quantity,
        tablets_daily=regimen.tableta_dnevno,
        starts_on=issued_on,
    )
    remaining = max(Decimal("0"), _decimal(approved_remaining))
    issue = IzdavanjeOralneTerapije.objects.create(
        pacijent=patient,
        lijek=regimen.lijek,
        rezim=regimen,
        komisija=commission,
        kolicina_tableta=quantity,
        datum_izdavanja=issued_on,
        pokrivenost_od=issued_on,
        pokrivenost_do=covered_until,
        sljedeci_nepokriveni_datum=next_uncovered,
        pokrivenost_dana=exact_days,
        jacina_mg_snapshot=regimen.lijek.jacina_mg,
        tableta_po_uzimanju_snapshot=regimen.tableta_po_uzimanju,
        uzimanja_dnevno_snapshot=regimen.uzimanja_dnevno,
        tableta_dnevno_snapshot=regimen.tableta_dnevno,
        faza_snapshot=regimen.faza,
        broj_saglasnosti_snapshot=(
            (commission.broj_saglasnosti or "") if commission else ""
        ),
        odobreno_preostalo_prije=remaining,
        odobreno_preostalo_poslije=remaining,
        napomena=(note or "").strip(),
        is_migration_snapshot=True,
        idempotency_key=idempotency_key,
        korisnik_koji_je_izdao=(
            user if getattr(user, "is_authenticated", False) else None
        ),
    )
    _recalculate_coverage_locked(patient, regimen.lijek)
    issue.refresh_from_db()
    upisi_log(
        user,
        "Migrirano historijsko oralno izdavanje",
        pacijent=patient,
        objekat=issue,
        opis=(
            f"{regimen.lijek.prikaz_naziv}: historijski izdato {quantity} "
            f"tableta {issued_on:%d/%m/%Y}; trenutna zaliha i preostalo "
            "odobrenje nisu mijenjani."
        ),
    )
    return issue, True


@transaction.atomic
def void_oral_issuance(*, issue, reason, user=None):
    """Kontrolisani storno vraća zalihu/pravo i ponovo slaže pokrivenost."""

    from dashboard.permissions import je_koordinator_ili_admin
    from .models import IzdavanjeOralneTerapije, Pacijent, Zaliha, ZalihaTransakcija
    from .utils import upisi_log

    if not je_koordinator_ili_admin(user):
        raise PermissionError(
            "Samo administrator ili koordinator može poništiti oralno izdavanje."
        )
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("Razlog poništavanja je obavezan.")

    # Match dispensing/replay: lock the persisted parent before its issue.
    # Read ownership without a row lock, then scope the locked issue to that
    # parent so a concurrent ownership change cannot cross the lock boundary.
    patient_id = IzdavanjeOralneTerapije.objects.values_list("pacijent_id", flat=True).get(pk=issue.pk)
    patient = Pacijent.objects.select_for_update().get(pk=patient_id)
    issue = (
        select_for_update_self(
            IzdavanjeOralneTerapije.objects.select_related("pacijent", "lijek")
        )
        .get(pk=issue.pk, pacijent_id=patient.pk)
    )
    if issue.status == IzdavanjeOralneTerapije.STATUS_PONISTENO:
        raise ValueError("Oralno izdavanje je već poništeno.")

    if issue.is_migration_snapshot:
        issue.status = IzdavanjeOralneTerapije.STATUS_PONISTENO
        issue.ponistio = user
        issue.ponisteno_at = timezone.now()
        issue.razlog_ponistavanja = reason
        issue.save(
            update_fields=[
                "status",
                "ponistio",
                "ponisteno_at",
                "razlog_ponistavanja",
            ]
        )
        _recalculate_coverage_locked(patient, issue.lijek)
        upisi_log(
            user,
            "Poništen migracijski snapshot oralnog izdavanja",
            pacijent=patient,
            objekat=issue,
            opis=(
                "Historijski snapshot je isključen iz pokrivenosti bez "
                f"promjene zalihe ili komisijskog prava. Razlog: {reason}"
            ),
        )
        return issue

    stock = Zaliha.objects.select_for_update().get(lijek=issue.lijek)
    before_stock = _decimal(stock.u_frizideru)
    stock.u_frizideru = before_stock + Decimal(issue.kolicina_tableta)
    stock.save(update_fields=["u_frizideru", "ukupno"])

    # Only new explicit links may restore an allocation. Never infer old
    # reservation ownership from the issue date, quantity or commission.
    from .models import PacijentRezervacija
    for change in issue.razduzenja_rezervacija.select_for_update().order_by("rezervacija_id"):
        reservation = PacijentRezervacija.objects.select_for_update().get(pk=change.rezervacija_id)
        if (reservation.pacijent_id, reservation.lijek_id) != (patient.pk, issue.lijek_id):
            raise ValueError("Izvorna rezervacija više ne pripada pacijentu i lijeku; provjerite trag izdavanja.")
        reservation.kolicina += change.kolicina
        reservation.aktivno = True
        reservation.potrosena_at = None
        reservation.save(update_fields=["kolicina", "aktivno", "potrosena_at"])

    if issue.komisija_id:
        commission = issue.komisija.__class__.objects.select_for_update().get(
            pk=issue.komisija_id
        )
        if (commission.pacijent_id != patient.pk
                or commission.lijek_id != issue.lijek_id
                or commission.status not in {"AKTIVNA", "ODOBRENA", "POTROSENA"}):
            raise ValueError("Izvorno odobrenje je izmijenjeno ili poništeno. Provjerite historiju prije poništavanja izdavanja.")
        commission.preostale_doze = _decimal(
            commission.preostale_doze
        ) + Decimal(issue.kolicina_tableta)
        if commission.preostale_doze > _decimal(commission.broj_odobrenih_doza):
            raise ValueError("Poništavanje bi vratilo više prava od stvarno odobrene količine.")
        if commission.status == "POTROSENA":
            commission.status = "AKTIVNA"
        commission.save(update_fields=["preostale_doze", "status"])
    elif issue.komisijska_stavka_id:
        issue.komisijska_stavka.__class__.objects.select_for_update().get(
            pk=issue.komisijska_stavka_id
        )

    issue.status = IzdavanjeOralneTerapije.STATUS_PONISTENO
    issue.ponistio = user
    issue.ponisteno_at = timezone.now()
    issue.razlog_ponistavanja = reason
    issue.save(
        update_fields=[
            "status",
            "ponistio",
            "ponisteno_at",
            "razlog_ponistavanja",
        ]
    )
    ZalihaTransakcija.objects.create(
        lijek=issue.lijek,
        tip=ZalihaTransakcija.TIP_POVRAT,
        kolicina=Decimal(issue.kolicina_tableta),
        datum=timezone.localdate(),
        pacijent=patient,
        komisija=issue.komisija,
        referenca_tip="Poništeno oralno izdavanje",
        referenca_id=issue.pk,
        korisnik=user,
        napomena=reason,
    )
    _recalculate_coverage_locked(patient, issue.lijek)
    upisi_log(
        user,
        "Poništeno oralno izdavanje",
        pacijent=patient,
        objekat=issue,
        opis=(
            f"Vraćeno {issue.kolicina_tableta} tableta lijeka "
            f"{issue.lijek.prikaz_naziv}; zaliha {before_stock:g} → "
            f"{stock.u_frizideru:g}. Razlog: {reason}"
        ),
    )
    return issue


def oral_therapy_status(patient, *, today=None):
    """Sažetak režima, pokrivenosti, prava i fizičke zalihe za UI."""

    from .models import (
        IzdavanjeOralneTerapije,
        Komisija,
        KomisijskaSaglasnost,
        KomisijskaStavkaLijeka,
        OralniTerapijskiRezim,
        Zaliha,
    )
    from .therapy_regimens import oral_regimen_configuration

    medicine = patient.lijek
    today = today or timezone.localdate()
    from .oral_regimen_dates import regimen_is_confirmed, regimen_on
    recorded_regimen = regimen_on(patient, today)
    regimen = recorded_regimen if regimen_is_confirmed(recorded_regimen) else None
    regimen_history = (
        OralniTerapijskiRezim.objects.filter(pacijent=patient)
        .select_related("lijek", "potvrdio", "standardni_rezim")
        .order_by("-datum_od", "-pk")[:20]
    )
    configuration = oral_regimen_configuration(
        medicine,
        selected=getattr(patient, "predlozeni_oralni_rezim_id", None),
    )
    issues = IzdavanjeOralneTerapije.objects.none()
    active_issues = []
    last_issue = None
    if medicine:
        issues = IzdavanjeOralneTerapije.objects.filter(
            pacijent=patient,
            lijek=medicine,
        ).select_related(
            "lijek", "rezim", "komisija", "komisijska_stavka", "korisnik_koji_je_izdao"
        )
        active_issues = list(issues.filter(
            status=IzdavanjeOralneTerapije.STATUS_AKTIVNO
        ).order_by("pokrivenost_od", "datum_izdavanja", "pk"))
        # Dispensing date is a recorded fact, not a coverage/projection date.
        last_issue = max(active_issues, key=lambda item: (item.datum_izdavanja, item.pk), default=None)
    quantity_at_patient = sum(
        (
            oral_issue_quantity_remaining(issue, today=today)
            for issue in active_issues
        ),
        Decimal("0"),
    ) if regimen else None
    issued_active_total = sum(
        (Decimal(issue.kolicina_tableta) for issue in active_issues),
        Decimal("0"),
    )
    options = approval_options(patient, medicine) if medicine else []
    stock = Zaliha.objects.filter(lijek=medicine).first() if medicine else None
    physical_available = _decimal(stock.u_frizideru) if stock else Decimal("0")
    approved_remaining = sum(
        (item["remaining"] for item in options),
        Decimal("0"),
    )
    has_approved_source = bool(
        medicine
        and (
            KomisijskaStavkaLijeka.objects.filter(
                komisijski_zahtjev__pacijent=patient,
                lijek=medicine,
                odobrena_kolicina__gt=0,
                komisijski_zahtjev__saglasnost__odluka__in=(
                    KomisijskaSaglasnost.Odluka.ODOBRENO,
                    KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
                ),
            ).exists()
            or Komisija.objects.filter(
                pacijent=patient,
                lijek=medicine,
                broj_odobrenih_doza__gt=0,
            ).exists()
        )
    )
    commission_plan = None
    commission_timeline = None
    if regimen:
        try:
            commission_timeline = oral_commission_timeline(
                regimen,
                today=today,
                approved_remaining=approved_remaining,
                at_patient=quantity_at_patient,
            )
            commission_plan = commission_timeline["requirement"]
        except ValueError:
            commission_plan = None
            commission_timeline = None
    physical_covered_until = (
        commission_timeline["physical_covered_until"]
        if commission_timeline and last_issue
        else (last_issue.pokrivenost_do if last_issue else None)
    )
    physical_next_uncovered = (
        commission_timeline["first_uncovered"]
        if commission_timeline and last_issue
        else (last_issue.sljedeci_nepokriveni_datum if last_issue else None)
    )
    if not regimen:
        # Stored issue coverage was derived under the old regimen. Keep the
        # issue itself, but do not reuse those dates as a current projection.
        physical_covered_until = None
        physical_next_uncovered = None
    if not regimen and configuration["status"] == "NOT_CONFIGURED":
        coverage_state = "REGIMEN_NOT_CONFIGURED"
        coverage_label = "Režim nije konfigurisan"
    elif not regimen:
        coverage_state = "REGIMEN_NOT_CONFIRMED"
        coverage_label = "Režim čeka potvrdu"
    elif not last_issue:
        coverage_state = "NO_COVERAGE"
        coverage_label = "Čeka prvo izdavanje"
    elif physical_covered_until and physical_covered_until >= today:
        coverage_state = "COVERED"
        coverage_label = f"Pokriveno do {physical_covered_until:%d/%m/%Y}"
    elif physical_covered_until:
        coverage_state = "EXPIRED"
        coverage_label = (
            f"Pokrivenost je istekla {physical_covered_until:%d/%m/%Y}"
        )
    else:
        coverage_state = "NO_FULL_DAY"
        coverage_label = "Nema punog pokrivenog dana"

    medicine_title = ""
    medicine_generic = ""
    if medicine:
        brand = (medicine.brand_name or medicine.naziv or "").strip()
        title_parts = [brand]
        normalized_brand = brand.casefold().replace(",", ".")
        if medicine.jacina_mg is not None:
            strength = format(Decimal(str(medicine.jacina_mg)).normalize(), "f")
            strength_label = f"{strength} mg"
            if strength_label.casefold() not in normalized_brand:
                title_parts.append(strength_label)
        if (
            medicine.put_primjene
            and medicine.put_primjene.casefold() not in normalized_brand.split()
        ):
            title_parts.append(medicine.put_primjene)
        medicine_title = " ".join(part for part in title_parts if part)
        generic = (medicine.generic_name or "").strip()
        if generic and generic.casefold() != brand.casefold():
            medicine_generic = generic

    can_issue = bool(
        patient.aktivan
        and regimen
        and approved_remaining > 0
        and physical_available > 0
    )
    package_size = int(
        getattr(medicine, "broj_tableta_u_pakovanju", 0) or 0
    ) if medicine else 0
    issue_block_reason = ""
    if not patient.aktivan:
        issue_block_reason = "Pacijent nije aktivan"
    elif not regimen:
        issue_block_reason = "Oralni režim nije potvrđen"
    elif not options and has_approved_source:
        issue_block_reason = "Nema preostalog komisijskog prava"
    elif not options:
        issue_block_reason = "Nema važeće saglasnosti"
    elif approved_remaining <= 0:
        issue_block_reason = "Nema preostalog komisijskog prava"
    elif physical_available <= 0:
        issue_block_reason = "Nema fizički dostupnih tableta u ustanovi"
    elif package_size <= 0:
        issue_block_reason = "Veličina pakovanja nije podešena"

    issue_enabled = not issue_block_reason
    requires_early_reason = bool(
        issue_enabled
        and physical_next_uncovered
        and today < physical_next_uncovered
        and quantity_at_patient > 0
    )
    due_soon = bool(
        not physical_next_uncovered
        or physical_next_uncovered <= today + timedelta(days=14)
    )
    issue_action = {
        "visible": bool(medicine and medicine.oralna_terapija),
        "enabled": issue_enabled,
        "disabled_reason": issue_block_reason,
        "is_early": bool(issue_enabled and not due_soon),
        "requires_early_reason": requires_early_reason,
        "label": (
            "Izdaj ranije"
            if issue_enabled and not due_soon
            else "Izdaj oralnu terapiju"
        ),
        "css_class": "tf-btn-secondary" if issue_enabled and not due_soon else "tf-btn-primary",
    }
    if not regimen:
        next_action = "Potvrditi oralni režim."
    elif not last_issue and can_issue:
        next_action = "Izdati oralnu terapiju prema važećem odobrenju."
    elif not last_issue and approved_remaining <= 0:
        next_action = "Evidentirati odobrenje prije prvog izdavanja."
    elif not last_issue and physical_available <= 0:
        next_action = "Zaprimiti lijek prije prvog izdavanja."
    elif last_issue and physical_next_uncovered:
        next_action = (
            "Pripremiti naredno izdavanje do "
            f"{physical_next_uncovered:%d/%m/%Y}."
        )
    else:
        next_action = "Pratiti aktivni oralni režim."
    return {
        "regimen": regimen,
        "recorded_regimen": recorded_regimen,
        "regimen_confirmed": bool(regimen),
        "regimen_history": regimen_history,
        "medicine": medicine,
        "issues": issues.order_by("-datum_izdavanja", "-pk")[:20],
        "last_issue": last_issue,
        "coverage_until": physical_covered_until,
        "next_uncovered": physical_next_uncovered,
        "quantity_at_patient": quantity_at_patient,
        "issued_active_total": issued_active_total,
        "physical_available": physical_available,
        "approval_options": options,
        "approved_remaining": approved_remaining,
        "commission_plan": commission_plan,
        "commission_timeline": commission_timeline,
        "standard_requirement": (
            commission_timeline["standard_requirement"]
            if commission_timeline else None
        ),
        "future_requirement": (
            commission_timeline["future_requirement"]
            if commission_timeline else None
        ),
        "regimen_configuration_status": configuration["status"],
        "standard_regimen_options": configuration["options"],
        "suggested_standard_regimen": configuration["suggested"],
        "coverage_state": coverage_state,
        "coverage_label": coverage_label,
        "medicine_title": medicine_title,
        "medicine_generic": medicine_generic,
        "awaiting_first_issue": bool(regimen and not last_issue),
        "can_issue": can_issue,
        "issue_action": issue_action,
        "next_action": next_action,
    }
