"""One dated prescription for a pending appointment, separate from actual use.

The appointment quantity is a booking snapshot. Dated orders supersede that
snapshot; ambiguous/manual exceptions require an explicit audited decision.
"""
import hashlib
import json
from decimal import Decimal

from django.core import signing
from django.db import transaction

from . import models as m
from .request_cache import begin_request_cache, end_request_cache, get_or_set, request_cache_enabled

SALT = 'theraflow.appointment-plan.v1'
STALE = 'Nalog ili termin je promijenjen nakon otvaranja obrasca. Zaliha nije skinuta. Ponovo pregledajte aktuelnu dozu i količinu.'


def appointment_plan(appointment, *, fresh=False, retrospective=False, historical_date=None):
    token = begin_request_cache(enabled=False) if fresh else None
    try:
        calculate = lambda: _appointment_plan(appointment, retrospective=retrospective, historical_date=historical_date)
        if appointment.pk is None:
            return calculate()
        # One HTTP read may visit the same dated appointment via several
        # canonical projections. Never cache across requests or confirmations.
        key = (appointment.pk, appointment.pacijent_id, appointment.lijek_id,
               appointment.datum, appointment.status, appointment.kolicina_po_terapiji,
               retrospective, historical_date)
        return dict(get_or_set('appointment_plan', key, calculate))
    finally:
        if fresh:
            end_request_cache(token)


def _appointment_plan(appointment, *, retrospective=False, historical_date=None):
    from .individual_protocols import get_current_step, get_units_per_application, get_interval_weeks
    from .regimen_changes import changes_for
    from .phased_protocols import phased_protocol_for_patient, current_phase_details

    patient, day = appointment.pacijent, historical_date or appointment.datum
    if retrospective:
        from .retrospective_history import patient_at
        patient = patient_at(patient, day)
    state = phased_protocol_for_patient(patient)
    phase = current_phase_details(state, day) if state else None
    # A phase is a prescription for its own presentation. A retained IV
    # booking after SC transition (or a future SC booking while waiting for
    # IV) keeps its recorded physical quantity and requires clinical review.
    if phase and appointment.lijek_id not in phase['medicine'].physical_equivalent_ids():
        phase = None
    step = get_current_step(patient, day) if not state else None
    ordinal = None
    if retrospective and not state:
        from .retrospective_schedule import application_number_at
        from .individual_protocols import get_step_for_application_number
        ordinal = application_number_at(patient, day)
        step = get_step_for_application_number(patient, ordinal, day)
    current_medicine_ids = (patient.lijek.physical_equivalent_ids() if state
        else patient.lijek.equivalent_ids()) if patient.lijek_id else ()
    quantity = appointment.kolicina_po_terapiji
    if quantity is None:
        quantity = get_units_per_application(patient, day) if appointment.lijek_id in current_medicine_ids else 0
    quantity = Decimal(str(quantity or 0))
    mg = phase['dose_mg'] if phase else (step.doza_mg if step else None)
    if state:
        interval = (phase['interval_weeks'] or 8) if phase else None
    else:
        interval = get_interval_weeks(patient, day, after_application=True, application_number=ordinal)
    if phase:
        quantity = Decimal(str(phase['units'] or 0))
    applicable = [c for c in changes_for(patient) if c.lijek_id == appointment.lijek_id and c.vrijedi_od <= day]
    dose_orders = [c for c in applicable if 'broj_jedinica' in c.promjena_rezima]
    conflict = False
    source = 'SNAPSHOT'
    required = quantity
    order_id = dose_orders[-1].pk if dose_orders else None
    # Impact analysis also resolves an unsaved, dated probe. Only a real
    # appointment can have a recorded manual decision; never query with that probe.
    if request_cache_enabled() and hasattr(appointment, '_workflow_plan_decisions'):
        decision = next(iter(appointment._workflow_plan_decisions), None)
    else:
        decision = (m.TerapijaStatusHistorija.objects.filter(termin_id=appointment.pk,
            novo_stanje__plan_source__isnull=False).order_by('-pk').first()
            if appointment.pk is not None else None)
    decision_data = decision.novo_stanje if decision else {}
    if dose_orders and appointment.status != m.Termin.STATUS_POTVRDJENA and not (phase and phase.get('dose_error')):
        order = dose_orders[-1]
        required = Decimal(order.promjena_rezima['broj_jedinica'])
        mg = Decimal(order.promjena_rezima['doza_mg'])
        # Old versions did not store quantity provenance. Only recognise
        # snapshots matching a recorded regimen; preserve other values for review.
        known = {required}
        for change in dose_orders:
            old = (change.prije or {}).get('regimen') or {}
            if old.get('broj_jedinica') is not None:
                known.add(Decimal(str(old['broj_jedinica'])))
            known.add(Decimal(change.promjena_rezima['broj_jedinica']))
        same_decision = decision_data.get('order_id') == order_id and quantity == Decimal(str(decision_data.get('quantity', '-1')))
        explicit_manual = decision_data.get('plan_source') == 'MANUAL'
        conflict = bool((explicit_manual and not same_decision) or
                        (appointment.kolicina_po_terapiji is not None and quantity not in known and not same_decision))
        if same_decision and explicit_manual:
            source = 'MANUAL'
            mg = Decimal(str(decision_data['dose_mg'])) if decision_data.get('dose_mg') else None
        elif not conflict:
            quantity = required
            source = 'REGIMEN'
    elif decision_data.get('plan_source') == 'MANUAL':
        source = 'MANUAL'
    elif not retrospective and step and appointment.lijek_id == patient.lijek_id and appointment.kolicina_po_terapiji is not None:
        required = Decimal(str(get_units_per_application(patient, day)))
        conflict = quantity != required
    if not retrospective and appointment.status != m.Termin.STATUS_POTVRDJENA:
        if patient.protokol_za_potvrdu:
            conflict = True
        if not state and step is None:
            from .individual_protocols import resolve_patient_protocol
            if resolve_patient_protocol(patient).warning:
                conflict = True
        if patient.lijek_id and appointment.lijek_id not in current_medicine_ids:
            # A booked old-drug visit is never a prescription for the new drug.
            step, mg, interval, phase = None, None, None, None
            conflict = True
    result = dict(quantity=quantity, dose_mg=mg, interval=interval, regimen_quantity=required,
        conflict=conflict, source=source, order_id=order_id, step=step, has_orders=bool(applicable))
    numeric = lambda value: None if value is None else format(Decimal(str(value)).normalize(),'f')
    payload = dict(appointment=appointment.pk, patient=patient.pk, medicine=appointment.lijek_id,
        date=day.isoformat(), status=appointment.status, quantity=numeric(quantity), dose_mg=numeric(mg),
        interval=interval, required_quantity=numeric(required),
        booked=numeric(appointment.kolicina_po_terapiji), conflict=conflict,
        orders=[c.pk for c in applicable], decision=decision.pk if decision else None)
    result['fingerprint'] = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    return result


def display_appointment_dose(appointment):
    """Presentation-specific planning display, without changing clinical orders.

    A pending SC continuation must not display the waiting IV phase's dose.
    Likewise, today's different medication is not proof of an old booking dose.
    """
    from copy import copy
    from .regimen_changes import regimen_override
    phase = appointment.pacijent.aktivni_fazni_protokol()
    if phase:
        if appointment.lijek_id == phase.iv_lijek_id:
            return phase.indukcijska_doza_mg
        if appointment.lijek_id == phase.sc_lijek_id:
            scoped = copy(appointment.pacijent)
            scoped.lijek = appointment.lijek
            return Decimal(str(regimen_override(scoped, appointment.datum).get('doza_mg', '90')))
    if appointment.lijek_id != appointment.pacijent.lijek_id:
        return None
    return appointment_plan(appointment, fresh=True)['dose_mg']


def plan_token(appointment, user, plan=None):
    plan = plan or appointment_plan(appointment)
    return signing.dumps({'appointment':appointment.pk,'user':getattr(user,'pk',None),
        'fingerprint':plan['fingerprint']},salt=SALT,compress=True)


def validate_plan_token(token, appointment, user, plan):
    try:
        payload = signing.loads(token, salt=SALT, max_age=8*60*60)
    except signing.BadSignature:
        raise ValueError(STALE) from None
    if payload != {'appointment':appointment.pk,'user':getattr(user,'pk',None),'fingerprint':plan['fingerprint']}:
        raise ValueError(STALE)


def save_appointment_plan(appointment, plan, *, user, reason, source='REGIMEN', dose_mg=None):
    from .therapy_workflow import record_status_history
    previous = {'quantity':str(appointment.kolicina_po_terapiji)}
    quantity = plan['regimen_quantity'] if source == 'REGIMEN' else plan['quantity']
    appointment.kolicina_po_terapiji = quantity
    appointment.save(update_fields=['kolicina_po_terapiji'])
    record_status_history(pacijent=appointment.pacijent,termin=appointment,
        previous_status=appointment.status,new_status=appointment.status,reason=reason,user=user,
        previous_state=previous,new_state={'plan_source':source,'quantity':str(quantity),
            'dose_mg':str(dose_mg if dose_mg is not None else plan['dose_mg']), 'order_id':plan['order_id']})


@transaction.atomic
def resolve_plan(*, appointment, user, token, choice, reason, dose_mg=None):
    from .quick_changes import authorize
    authorize(user)
    patient = m.Pacijent.objects.select_for_update().get(pk=appointment.pacijent_id)
    appointment = m.Termin.objects.select_for_update().get(pk=appointment.pk)
    appointment.pacijent = patient
    if appointment.status != m.Termin.STATUS_PLANIRANA:
        raise ValueError('Samo nepotvrđen planirani termin može se uskladiti.')
    plan = appointment_plan(appointment, fresh=True)
    validate_plan_token(token, appointment, user, plan)
    if choice not in ('REGIMEN','MANUAL') or len(reason.strip()) < 3:
        raise ValueError('Odaberite nalog za ovaj termin i unesite kratak razlog odluke.')
    if choice == 'MANUAL':
        try:
            dose_mg = Decimal(str(dose_mg))
            if not dose_mg.is_finite() or dose_mg <= 0:
                raise ValueError()
        except (ValueError, ArithmeticError):
            raise ValueError('Za poseban nalog unesite propisanu dozu u mg.') from None
    save_appointment_plan(appointment,plan,user=user,reason=reason,source=choice,dose_mg=dose_mg if choice=='MANUAL' else None)
    from .commission_planning import recalculate_patient_commission_drafts
    recalculate_patient_commission_drafts(patient,user=user,reason=reason)


def sync_pending_order(patient, receipt, user):
    """Caller holds the patient lock; dates, stock and completed therapy stay intact."""
    for appointment in m.Termin.objects.select_for_update().filter(pacijent=patient,lijek=receipt.lijek,
            status=m.Termin.STATUS_PLANIRANA,datum__gte=receipt.vrijedi_od):
        appointment.pacijent = patient
        plan = appointment_plan(appointment, fresh=True)
        if plan['source']=='REGIMEN' and not plan['conflict'] and appointment.kolicina_po_terapiji != plan['quantity']:
            save_appointment_plan(appointment,plan,user=user,reason=f'Usklađeno s nalogom #{receipt.pk}: {receipt.razlog}')
