"""Read existing historical appointment tags; never create or delete records."""
from .models import TerapijaStatusHistorija

VIDEO_DEMO_MARKER = "VIDEO DEMO TERMIN"


def tagged_video_demo_appointment_ids(*, start_date=None, end_date=None):
    queryset = TerapijaStatusHistorija.objects.filter(
        termin_id__isnull=False,
        razlog__startswith=VIDEO_DEMO_MARKER,
    )
    if start_date is not None:
        queryset = queryset.filter(termin__datum__gte=start_date)
    if end_date is not None:
        queryset = queryset.filter(termin__datum__lte=end_date)
    return set(queryset.values_list("termin_id", flat=True))
