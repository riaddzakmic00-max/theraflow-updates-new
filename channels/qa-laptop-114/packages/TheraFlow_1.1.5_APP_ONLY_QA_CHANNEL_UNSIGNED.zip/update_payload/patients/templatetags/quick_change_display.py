"""Read-only presentation of the same current values used by quick actions."""
from decimal import Decimal

from django import template
from django.core.exceptions import ValidationError
from django.db.models import Sum
from django.utils.formats import number_format

from patients.home_therapy import format_stock_quantity
from patients.quick_changes import current_regimen, transfer_sources

register = template.Library()


def number(value):
    return number_format(Decimal(str(value)).normalize(), use_l10n=True)


@register.simple_tag
def quick_change_values(patient):
    values = {
        'interval': 'Nije evidentirano', 'interval_note': 'Trenutni interval',
        'dose': 'Nije evidentirano', 'dose_note': 'Propisana doza po primjeni',
        'stock': 'Nije evidentirano', 'stock_note': 'Rezervisano za ovog pacijenta',
    }
    if not patient.lijek_id:
        return values
    medicine = patient.lijek
    # Active, unconsumed reservations for this presentation; home supplies and
    # commission approvals are not part of the clinic assignment.
    stock = transfer_sources(patient).aggregate(total=Sum('kolicina'))['total']
    values['stock'] = format_stock_quantity(medicine, stock if stock is not None else Decimal('0'))
    try:
        phase = patient.aktivni_fazni_protokol()
        if phase and phase.faza != phase.FAZA_ODRZAVANJE:
            # Read the confirmed current step without enabling the quick-change
            # write path for a multi-step induction/transition protocol.
            from patients.phased_protocols import current_phase_details
            details = current_phase_details(phase)
            if details.get('dose_error'):
                values.update(dose=details['dose_error'], dose_note='Ljekar treba ispraviti protokol',
                    interval='Prema faznom protokolu')
                return values
            regimen = dict(doza_mg=details['dose_mg'],broj_jedinica=details['units'],interval_sedmica=details['interval_weeks'])
            if not details['interval_weeks']:
                values.update(interval='Prema faznom protokolu',interval_note='Jednokratna IV indukcija')
        else:
            from patients.individual_protocols import get_current_step, get_interval_weeks
            step = get_current_step(patient)
            if step and step.faza == step.FAZA_INDUKCIJA:
                regimen = dict(doza_mg=step.doza_mg, broj_jedinica=step.broj_jedinica,
                               interval_sedmica=get_interval_weeks(patient))
                values['interval_note'] = step.opis_za_prikaz()
                values['dose_note'] = 'Trenutni indukcijski korak'
            else:
                regimen = current_regimen(patient)
    except ValidationError:
        # Multi-step induction and an unconfirmed oral regimen have no single
        # current value suitable for these actions. Do not invent a zero dose.
        if patient.protokol_za_potvrdu:
            values.update(interval='Čeka potvrdu protokola', dose='Čeka potvrdu protokola')
        else:
            values.update(interval='Provjerite protokol', dose='Provjerite protokol')
        return values
    if medicine.oralna_terapija:
        frequency = regimen.get('uzimanja_dnevno')
        if frequency is not None:
            values['interval'] = f'{frequency} × dnevno'
        values['interval_note'] = 'Trenutna učestalost uzimanja'
        values['dose_note'] = 'Propisana doza po uzimanju'
    elif regimen.get('interval_sedmica'):
        weeks = regimen['interval_sedmica']
        values['interval'] = f'{weeks} sedmica'
    if regimen.get('doza_mg') is not None:
        values['dose'] = f"{number(regimen['doza_mg'])} mg"
    units = regimen.get('broj_jedinica')
    if units is not None:
        values['dose_note'] += ' · ' + format_stock_quantity(medicine, Decimal(str(units)))
    return values
