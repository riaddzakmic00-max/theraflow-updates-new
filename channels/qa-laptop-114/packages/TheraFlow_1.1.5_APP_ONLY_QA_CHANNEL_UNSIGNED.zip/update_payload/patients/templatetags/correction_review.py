"""Read-only presentation of an existing correction preview; no service calls."""
from decimal import Decimal, InvalidOperation
from django import template

register = template.Library()


def value_key(value):
    text = str(value)
    try:
        value = Decimal(text)
        return value if value.is_finite() else text
    except InvalidOperation:
        return text


def display_row(row, medicine):
    title, _, detail = row.get('label', '').partition(' · ')
    title = {'Ukupna fizička zaliha': 'Fizička zaliha',
             'Pacijentovo zaduženje u frižideru': 'Zaduženje pacijenta',
             'STARI TERMIN': 'Zakazani termin'}.get(title, title)
    product_row = any(word in title.lower() for word in ('zaliha', 'zaduženje', 'doza', 'količina', 'interval')) or title == 'Zakazani termin'
    return dict(row, title=title, subtitle=detail or (str(medicine) if product_row and medicine else ''),
                long=len(str(row.get('before', ''))) + len(str(row.get('after', ''))) > 160)


@register.simple_tag(takes_context=True)
def correction_review(context):
    """Group supplied rows without mutating the signed preview or its checks."""
    preview = context.get('preview') or {}
    graph = context.get('guided_impact') or preview.get('guided_impact') or {}
    medicine = context.get('medicine') or getattr(context.get('pacijent'), 'lijek', None)
    rows = context.get('review_rows') or preview.get('rows') or []
    changed, unchanged, notes, seen = [], [], [], set()
    appointment = context.get('category') == 'appointment'
    appointment_labels = {r['label'] for r in preview.get('rows', [])} if appointment else set()
    optional_keys = {row.get('key') for decision in graph.get('recommended_changes', []) if decision.get('accepted') for row in decision.get('changes', [])}
    metadata = {r['label']: r for r in [*graph.get('required_changes', []), *graph.get('informational_checks', [])]}
    for raw in rows:
        if raw.get('label') == 'Terapijski plan' and raw.get('before') == raw.get('after') and 'Terapijski plan / prezentacija / put primjene' in metadata:
            continue  # The state row below contains the full checked plan.
        row = display_row(raw, medicine)
        row['key'] = raw.get('key') or metadata.get(raw.get('label'), {}).get('key')
        row['classification'] = 'PREPORUČENO' if row.get('key') in optional_keys else 'OBAVEZNO'
        key = (row['title'], row['subtitle'], value_key(row.get('before', '')), value_key(row.get('after', '')))
        if key in seen:
            continue
        seen.add(key)
        if row['title'] == 'Audit':
            notes.append(dict(label='Audit', detail=row.get('after')))
        elif value_key(row.get('before')) == value_key(row.get('after')):
            unchanged.append(row)
        elif appointment and raw.get('label') == 'NOVI TERMIN':
            continue  # The same requested date is already shown before → after.
        elif appointment and raw.get('label') in appointment_labels and not (
                raw.get('label') == 'STARI TERMIN' or raw.get('label', '').startswith('Naredni termin ')
                or raw.get('label') == 'Naredni datum faznog protokola'):
            notes.append(dict(label=row['title'], detail=row.get('after')))
        elif raw.get('label', '').startswith('Predloženi naredni datum'):
            notes.append(dict(label=row['title'], detail=f'{row.get("before")} → {row.get("after")}'))
        else:
            changed.append(row)
    for raw in graph.get('informational_checks', []):
        if raw.get('detail') == 'Bez promjene' and 'before' in raw:
            row = display_row(raw, medicine)
            key = (row['title'], row['subtitle'], value_key(row.get('before')), value_key(row.get('after')))
            if key not in seen:
                unchanged.append(row)
                seen.add(key)
        elif raw.get('detail'):
            notes.append(raw)
    # Quick previews without an alignment graph must not imply successful checks.
    notes.extend(dict(label='Informativno', detail=detail) for detail in preview.get('impacts', []))
    checks = graph.get('checks') or []
    blocked = bool(appointment and not preview.get('can_confirm'))
    warnings = context.get('display_warnings') or preview.get('warnings') or []
    attention = bool(warnings) or blocked or bool(graph.get('unresolved_items')) or any(not check.get('ok') for check in checks)
    extra_keys = ('free:', 'history', 'oral_history', 'home_balance', 'phase_next_date', 'migration_dates')
    extra = [r for r in unchanged if str(r.get('key', '')).startswith(extra_keys)]
    unchanged = [r for r in unchanged if r not in extra]
    return dict(changed=changed, unchanged=unchanged, extra_unchanged=extra, notes=notes, checks=checks, warnings=warnings,
                attention=attention, verified=bool(checks) and not attention,
                status=graph.get('status'), remaining=graph.get('unresolved_items') or [])
