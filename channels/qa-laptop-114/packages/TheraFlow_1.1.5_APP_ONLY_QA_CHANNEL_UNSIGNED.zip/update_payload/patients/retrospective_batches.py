"""Drafts and atomic chronological orchestration over existing event services."""
from collections import defaultdict
from decimal import Decimal
import uuid
from django.core import signing
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone
from . import models as m, retrospective_events as events
from .correction_protocol import correction_transaction
from .data_corrections import require, serial, captured_rows, digest, differences, backup_before_correction

SALT = 'theraflow.retrospective-batch.v1'


def save_draft(*, patient, user, start, end, reason, rows, draft_id=None, revision=None, correction_of=None, reconstruction=None):
    events.authorize(user)
    start, end = events.day(start), events.day(end)
    require(start <= end <= timezone.localdate(), 'Odaberite period koji završava najkasnije danas.')
    require(isinstance(rows,list) and len(rows) <= 20, 'Jedan nacrt može sadržati do 20 događaja.')
    require(len(reason) <= 500, 'Razlog može imati najviše 500 znakova.')
    # Draft accepts incomplete/invalid row fields; validation belongs to preview.
    rows = serial(rows)
    require(len(str(rows)) <= 100000, 'Nacrt je prevelik.')
    with transaction.atomic():
        if draft_id:
            draft = m.RetrospectiveBatch.objects.select_for_update().get(pk=draft_id,patient=patient)
            require(draft.status == 'DRAFT', 'Potvrđen unos se ne prepisuje. Otvorite povezanu ispravku.')
            require(draft.revision == int(revision), 'Nacrt je u međuvremenu izmijenjen. Ponovo ga otvorite prije čuvanja.')
            draft.revision += 1
        else:
            if correction_of:
                parent = m.RetrospectiveBatch.objects.get(pk=correction_of,patient=patient)
                require(parent.status == 'REVERSED', 'Prvo pregledajte i potvrdite kontrolisano poništavanje originalnih događaja.')
            draft = m.RetrospectiveBatch(patient=patient,user=user,correction_of_id=correction_of)
        draft.period_start, draft.period_end = start, end
        draft.reason, draft.rows = reason.strip(), rows
        if reconstruction is not None:
            require(isinstance(reconstruction,dict) and len(str(reconstruction)) <= 2000, 'Neispravni podaci kontrolnog popisa.')
            draft.reconstruction = serial(reconstruction)
        draft.save()
    return draft


def quantities(patient, medicine):
    from .inventory import izracunaj_frizider_iz_transakcija, inventory_position
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    position = inventory_position(medicine,include_planned_need=False)
    return serial(dict(medicine=str(medicine),medicine_id=medicine.pk,unit=medicine.jedinice_zalihe[0],
        physical=stock.u_frizideru if stock else 0, ledger=izracunaj_frizider_iz_transakcija(medicine),
        reserved=m.PacijentRezervacija.objects.filter(pacijent=patient,lijek=medicine,aktivno=True).aggregate(n=Sum('kolicina'))['n'] or 0,
        home=m.PacijentZaduzenje.objects.filter(pacijent=patient,lijek=medicine,aktivno=True).aggregate(n=Sum('preostalo'))['n'] or 0,
        right=m.Komisija.objects.filter(pacijent=patient,lijek=medicine,status__in=m.Komisija.VAZECI_STATUSI).aggregate(n=Sum('preostale_doze'))['n'] or 0,
        coverage=position))


def normalize_rows(draft):
    require(5 <= len(draft.reason.strip()) <= 500, 'Unesite razlog naknadne evidencije (5–500 znakova).')
    require(1 <= len(draft.rows) <= 20, 'Dodajte najmanje jedan događaj.')
    rows = []
    for index, raw in enumerate(draft.rows,1):
        try:
            source = dict(raw, note=str(raw.get('note') or '').strip() or draft.reason)
            data = events.normalize({**source,'patient_id':raw.get('patient_id') or draft.patient_id} if draft.reconstruction else {**source,'patient_id':draft.patient_id})
            require(draft.period_start <= events.day(data['event_date']) <= draft.period_end,
                'Stvarni datum nije unutar odabranog perioda.')
            if data['kind'] != 'receipt' and not draft.reconstruction:
                require(data['patient_id']==draft.patient_id,'Događaj ne pripada odabranom pacijentu.')
            data['note'] = data['note'] or draft.reason
            for key in ('stock_correction_id','count_link_confirmed','count_link_reason','receipt_mode','existing_receipt_id','count_reservation_id'):
                data[key] = raw.get(key)
            data['row_number'] = index
            rows.append(data)
        except (ValueError, m.Trebovanje.DoesNotExist) as exc:
            raise events.CorrectionBlocked(f'Događaj {index}: {exc}') from exc
    return sorted(rows, key=lambda x:(x['event_date'],0 if x['kind']=='receipt' else 1,x['row_number']))


def _existing_receipt(data, user):
    from .inventory_corrections import allocation_quantity, receipt_date
    claim = m.EvidencijaSaglasnostiZaprimanja.objects.filter(pk=data.get('existing_receipt_id'),
        trebovanje_id=data['request_id'],pacijent_id=data['patient_id'],fizicka_transakcija__lijek_id=data['medicine_id']).select_related('fizicka_transakcija').first()
    require(claim and receipt_date(claim.fizicka_transakcija)==events.day(data['event_date'])
        and allocation_quantity(claim)==Decimal(data['quantity']),
        'Postojeći prijem mora odgovarati pacijentu, komisijskoj stavci, datumu i stvarno raspodijeljenoj količini.')
    require(not data.get('stock_correction_id'),'Veza s postojećim prijemom ne mijenja fizičku zalihu.')
    require(data.get('batch','')==claim.fizicka_transakcija.serija
        and str(data.get('expires') or '')==str(claim.fizicka_transakcija.rok_trajanja or ''),
        'Serija i rok moraju odgovarati već evidentiranom prijemu.')
    return dict(data=data,title='Veza s već evidentiranim prijemom',rows=[],warnings=[
        'Ova raspodjela je već evidentirana. Fizička isporuka se ne knjiži ponovo.'],
        existing_receipt_id=claim.pk,physical_movement_id=claim.fizicka_transakcija_id)


def _receipt_plans(group, user):
    from .inventory_corrections import receipt_date, allocation_quantity
    plans = []
    require(len({x['request_id'] for x in group})==len(group),
        'Ista komisijska stavka se ponavlja u istoj isporuci; objedinite količinu u jedan red.')
    for data in group:
        prior = [x for x in m.EvidencijaSaglasnostiZaprimanja.objects.filter(trebovanje_id=data['request_id']).select_related('fizicka_transakcija')
            if x.fizicka_transakcija_id and receipt_date(x.fizicka_transakcija)==events.day(data['event_date'])
            and allocation_quantity(x)==Decimal(data['quantity'])]
        require(not prior or data['separate_event'] and len(data['note'])>=5,
            'Mogući duplikat: već postoji prijem iste stavke, datuma i količine. Povežite postojeći prijem ili dokumentujte drugu stvarnu isporuku.')
        plans.append(events.preview(data,user))
    return plans


def _apply_receipt_group(group, plans, draft, user, backup):
    """One bulk physical receipt; separate patient allocations/audits share it."""
    from dashboard.views import _zaprimi_odabrana_trebovanja_ciklusa
    first = plans[0]['data']; medicine = m.Lijek.objects.get(pk=first['medicine_id'])
    requests = [m.Trebovanje.objects.get(pk=p['data']['request_id']) for p in plans]
    before = captured_rows()
    old_ids = set(m.ZalihaTransakcija.objects.values_list('pk',flat=True))
    amounts = {p['data']['request_id']:Decimal(p['data']['quantity']) for p in plans}
    _zaprimi_odabrana_trebovanja_ciklusa(ciklus=requests[0].komisijski_ciklus,trebovanja=requests,
        doze_po_trebovanju=amounts,zaprimljeno_po_lijeku={medicine.pk:sum(amounts.values())},
        datum_odobrenja=events.day(first['approval_date']),
        brojevi_saglasnosti={p['data']['request_id']:p['data']['agreement'] for p in plans},
        korisnik=user,datum_prijema=events.day(first['event_date']),
        lot_by_medicine={medicine.pk:first['lots'][0]},audit_action='Povezani naknadni prijem')
    old,new = differences(before,captured_rows())
    movements = list(m.ZalihaTransakcija.objects.exclude(pk__in=old_ids))
    shared = [r.pk for r in requests]
    result=[]
    for data, plan in zip(group,plans):
        event=m.RetrospectiveEvent.objects.create(batch=draft,operation_id=uuid.uuid5(draft.operation_id,str(data['row_number'])),
            kind='receipt',event_date=data['event_date'],user=user,patient_id=data['patient_id'],medicine=medicine,
            quantity=data['quantity'],note=data['note'],request_id=data['request_id'],delivery_reference=data['delivery_reference'],
            backup=backup,effects=serial({'preview':plan,'before':old,'after':new,'shared_requests':shared,'batch_reason':draft.reason}))
        event.movements.set(movements); result.append(event)
    return result


def execute(draft,user,backup):
    if draft.reconstruction:
        from .september_reconstruction import execute as reconstruct
        return reconstruct(draft,user,backup,_execute)
    return _execute(draft,user,backup)


def _execute(draft,user,backup):
    rows = normalize_rows(draft)
    medicines = m.Lijek.objects.in_bulk({r['medicine_id'] for r in rows})
    initial = {pk:quantities(draft.patient,med) for pk,med in medicines.items()}
    report=[]; handled=set()
    for data in rows:
        if data['row_number'] in handled:continue
        number = data['row_number']
        try:
            from .september_reconstruction import set_event
            set_event(data)
            med=medicines[data['medicine_id']]
            row_patient=m.Pacijent.objects.get(pk=data['patient_id'])
            before=quantities(row_patient,med)
            if data['kind']=='receipt' and data.get('receipt_mode')=='EXISTING':
                plan=_existing_receipt(data,user)
            elif data['kind']=='receipt':
                require(data.get('receipt_mode') in (None,'','NEW'),'Odaberite novi prijem ili postojeći dokazani prijem.')
                key=lambda r:(r['medicine_id'],r.get('cycle_id'),r['event_date'],r.get('delivery_reference'),r.get('batch'),r.get('expires'))
                group=[r for r in rows if r['kind']=='receipt' and r.get('receipt_mode')!='EXISTING' and key(r)==key(data)]
                plans=_receipt_plans(group,user)
                if len(group)==1:
                    event=events.apply_plan(plans[0],user,uuid.uuid5(draft.operation_id,str(number)),backup)
                    event.batch=draft;event.effects['batch_reason']=draft.reason;event.save(update_fields=['batch','effects'])
                else:
                    require(all(len(p['data']['lots'])==1 for p in plans),'Zajedničku isporuku unesite po jednoj stvarnoj seriji u redu.')
                    _apply_receipt_group(group,plans,draft,user,backup)
                handled.update(r['row_number'] for r in group)
                plan=dict(title='Povezani prijem',data=data,rows=[x for p in plans for x in p['rows']],
                    warnings=[w for p in plans for w in p['warnings']],
                    allocations=[dict(patient=p['patient'],quantity=p['quantity'],unit=p['unit']) for p in plans])
            else:
                reconciliation=None
                if data.get('stock_correction_id'):
                    from .retrospective_reconciliation import apply
                    reconciliation=apply(data,draft.patient,user,uuid.uuid5(draft.operation_id,f'count-{number}'),backup)
                plan=events.preview(data,user,reconciled_count_id=reconciliation[0].pk if reconciliation else None)
                event=events.apply_plan(plan,user,uuid.uuid5(draft.operation_id,str(number)),backup,
                    stock_count_audit=reconciliation[1].pk if reconciliation else None)
                event.batch=draft;event.effects['batch_reason']=draft.reason
                if reconciliation:
                    correction,audit,movement=reconciliation
                    event.stock_correction=correction
                    event.effects['count_link']={'audit_id':audit.pk,'movement_id':movement.pk,'reason':data['count_link_reason']}
                    event.movements.add(movement)
                    plan['warnings'].append(f'Popis #{correction.pk}: {event.quantity} jedinica ranijeg manjka razjašnjeno je ovom stvarnom potrošnjom. Ukupna današnja zaliha se ne umanjuje drugi put.')
                event.save(update_fields=['batch','stock_correction','effects'])
            after=quantities(row_patient,med)
            require(Decimal(after['physical'])==Decimal(after['ledger']),'Fizička zaliha i zbir prometa nisu usklađeni.')
            report.append(serial(dict(number=number,date=data['event_date'],date_label=events.day(data['event_date']).strftime('%d.%m.%Y.'),
                kind=data['kind'],patient=str(row_patient),medicine=str(med),quantity=data['quantity'],
                unit=med.jedinica_zalihe_za_kolicinu(data['quantity']),before=before,after=after,plan=plan)))
        except (ValueError, m.Zaliha.DoesNotExist) as exc:
            raise events.CorrectionBlocked(f'Događaj {number} ({data["event_date"]}): {exc}') from exc
    return serial(dict(rows=report,before=initial,after={pk:quantities(draft.patient,med) for pk,med in medicines.items()},
        reason=draft.reason,operation_id=draft.operation_id))


def make_preview(draft,user):
    events.authorize(user)
    with correction_transaction():
        draft=m.RetrospectiveBatch.objects.get(pk=draft.pk)
        require(draft.status=='DRAFT','Ovaj unos više nije nacrt.')
        fingerprint=digest(captured_rows())
        # Run the same domain operations in a savepoint, then discard every row.
        # No backup files or external operations are created during this preview.
        with transaction.atomic():
            plan=execute(draft,user,{})
            transaction.set_rollback(True)
        require(fingerprint==digest(captured_rows()),'Pregled je promijenio podatke; ništa nije potvrđeno.')
        token=signing.dumps(dict(batch=draft.pk,revision=draft.revision,user=user.pk,
            fingerprint=fingerprint,action='confirm'),salt=SALT,compress=True)
        return plan,token


def confirm(token,user,patient):
    events.authorize(user)
    try:payload=signing.loads(token,salt=SALT)
    except signing.BadSignature:raise events.CorrectionBlocked('Pregled nije važeći. Ponovite pregled.') from None
    require(payload['user']==user.pk and payload['action']=='confirm','Potvrda ne pripada ovom korisniku.')
    with correction_transaction():
        draft=m.RetrospectiveBatch.objects.get(pk=payload['batch'],patient=patient)
        if draft.status=='CONFIRMED':return draft,False
        require(draft.status=='DRAFT','Ovaj unos je već ispravljen; originalna potvrda se ne ponavlja.')
        try:signing.loads(token,salt=SALT,max_age=1800)
        except signing.BadSignature:raise events.CorrectionBlocked('Pregled je istekao. Ponovite pregled.') from None
        require(draft.revision==payload['revision'] and digest(captured_rows())==payload['fingerprint'],
            'Podaci ili nacrt su promijenjeni nakon pregleda. Ništa nije upisano; ponovite pregled.')
        # A failed attempt retains its backup. A retry needs a new archive of
        # the freshly validated state, while event idempotency stays batch-bound.
        backup=backup_before_correction(uuid.uuid4())
        backup['batch_operation_id']=str(draft.operation_id)
        plan=execute(draft,user,backup)
        draft.status='CONFIRMED';draft.confirmed_at=timezone.now();draft.preview=plan;draft.backup=backup
        draft.save(update_fields=['status','confirmed_at','preview','backup','updated_at'])
        return draft,True


def verify_saved(draft):
    from .request_cache import begin_request_cache,end_request_cache
    cache=begin_request_cache(enabled=False)
    try:
        warnings=[];states=[]
        for pk in draft.preview.get('after',{}):
            current=quantities(draft.patient,m.Lijek.objects.get(pk=pk));states.append(current)
            if Decimal(current['physical']) != Decimal(current['ledger']):
                warnings.append(current['medicine']+': fizička zaliha i promet zahtijevaju provjeru.')
            expected=draft.preview['after'][pk]
            if draft.status=='CONFIRMED' and any(Decimal(str(current[k]))!=Decimal(str(expected[k]))
                    for k in ('physical','reserved','home','right')):
                warnings.append(current['medicine']+': unos je sačuvan, ali stanje je nakon njega izmijenjeno. '
                    'Provjerite kasnije događaje u historiji; nemojte ponovo knjižiti ovaj unos.')
        return {'states':states,'warnings':warnings,'checked_at':timezone.now()}
    finally:end_request_cache(cache)


def execute_reversal(draft,user,reason,backup):
    if draft.reconstruction:
        from .september_reconstruction import reverse as reverse_reconstruction
        return reverse_reconstruction(draft,user,reason,backup,_execute_reversal)
    return _execute_reversal(draft,user,reason,backup)


def _execute_reversal(draft,user,reason,backup):
    require(draft.status=='CONFIRMED','Samo potvrđen unos može se ispraviti.')
    require(5 <= len(reason.strip()) <= 500,'Unesite razlog ispravke (5–500 znakova).')
    results=[];handled=set()
    for event in draft.events.select_related('patient','medicine','therapy','request').order_by('-event_date','-pk'):
        if event.pk in handled:continue
        require(not event.reversed_at,'Jedan od povezanih događaja je već ispravljen. Provjerite historiju.')
        plan=events.reversal_preview(event,user,reason)
        events.apply_reversal(event,user,plan,backup)
        handled.add(event.pk)
        if event.effects.get('shared_requests'):
            # One physical receipt serves all allocations. Its existing
            # correction reverses all of them once; keep every original audit.
            shared_ids=list(event.movements.filter(tip='ZAPRIMANJE').values_list('pk',flat=True))
            for related in draft.events.filter(kind='receipt',movements__pk__in=shared_ids).exclude(pk=event.pk).distinct():
                related.reversed_at=event.reversed_at;related.reversed_by=user;related.reversal_reason=reason
                related.reversal_effects=serial({'shared_reversal_event_id':event.pk,'backup':backup,'preview':plan})
                related.save(update_fields=['reversed_at','reversed_by','reversal_reason','reversal_effects'])
                handled.add(related.pk)
        results.append(plan)
    return serial({'rows':results,'reason':reason,'operation_id':draft.operation_id})


def make_reversal_preview(draft,user,reason):
    events.authorize(user)
    with correction_transaction():
        draft=m.RetrospectiveBatch.objects.get(pk=draft.pk)
        fingerprint=digest(captured_rows())
        with transaction.atomic():
            plan=execute_reversal(draft,user,reason,{})
            transaction.set_rollback(True)
        require(fingerprint==digest(captured_rows()),'Pregled poništavanja je promijenio podatke.')
        token=signing.dumps(dict(batch=draft.pk,user=user.pk,fingerprint=fingerprint,
            action='reverse',reason=reason,operation_id=str(uuid.uuid4())),salt=SALT,compress=True)
        return plan,token


def reverse(token,user,patient):
    events.authorize(user)
    try:payload=signing.loads(token,salt=SALT)
    except signing.BadSignature:raise events.CorrectionBlocked('Pregled nije važeći. Ponovite pregled.') from None
    require(payload['user']==user.pk and payload['action']=='reverse','Potvrda ne pripada ovom korisniku.')
    with correction_transaction():
        draft=m.RetrospectiveBatch.objects.get(pk=payload['batch'],patient=patient)
        if draft.status=='REVERSED':return draft,False
        try:signing.loads(token,salt=SALT,max_age=1800)
        except signing.BadSignature:raise events.CorrectionBlocked('Pregled je istekao. Ponovite pregled.') from None
        require(digest(captured_rows())==payload['fingerprint'],'Podaci su promijenjeni. Ponovite pregled ispravke.')
        backup=backup_before_correction(payload['operation_id'])
        execute_reversal(draft,user,payload['reason'],backup)
        draft.status='REVERSED';draft.save(update_fields=['status','updated_at'])
        return draft,True
