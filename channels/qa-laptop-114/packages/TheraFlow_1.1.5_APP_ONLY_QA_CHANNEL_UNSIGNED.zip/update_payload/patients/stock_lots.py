"""Read stock lots from the existing movement ledger; legacy unknown stays unknown."""
from decimal import Decimal

from . import models as m


def lot_balances(medicine):
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    total = stock.u_frizideru if stock else Decimal(0)
    lots = {}
    transactions = list(m.ZalihaTransakcija.objects.filter(lijek=medicine).exclude(serija=''))
    # An outgoing recorded lot alone does not identify the lot of legacy inputs.
    established = {(tx.serija, tx.rok_trajanja) for tx in transactions
                   if (tx.tip == 'ZAPRIMANJE' or tx.tip == 'KOREKCIJA' and tx.korekcija_id
                       and tx.korekcija.scope == 'inventory_patient_stock' and tx.frizider_delta() > 0)
                   and tx.lokacija in ('', 'FRIZIDER')}
    for tx in transactions:
        if tx.lokacija not in ('', 'FRIZIDER'):
            continue
        key = (tx.serija, tx.rok_trajanja)
        if key not in established:
            continue
        lots[key] = lots.get(key, Decimal(0)) + tx.frizider_delta()
    lots[('', None)] = total - sum(lots.values(), Decimal(0))
    return lots


def coverage_preview(medicine, before, after, *, reservation_deltas=None, new_allocation=None):
    """No priority is guessed. Ranges expose shared shortage without reallocating."""
    reservations = list(m.PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True,
        kolicina__gt=0).select_related('pacijent', 'komisija').order_by('pk'))
    reserved = sum((r.kolicina for r in reservations), Decimal(0))
    changes = reservation_deltas or {}
    # A correction can reactivate an exhausted source reservation.
    present = {r.pk for r in reservations}
    reservations += list(m.PacijentRezervacija.objects.filter(pk__in=set(changes)-present,
        lijek=medicine).select_related('pacijent', 'komisija'))
    reserved_after = reserved + sum(changes.values(), Decimal(0))
    if new_allocation:
        reserved_after += new_allocation['quantity']
    rows = []
    for r in reservations:
        after_quantity = r.kolicina + changes.get(r.pk, Decimal(0))
        rows.append({'id': r.pk, 'patient_id': r.pacijent_id, 'patient': str(r.pacijent),
            'quantity': r.kolicina, 'quantity_after': after_quantity, 'approval_id': r.komisija_id,
            'before_min': max(Decimal(0), min(r.kolicina, before - (reserved-r.kolicina))),
            'before_max': min(r.kolicina, max(Decimal(0), before)),
            'after_min': max(Decimal(0), min(after_quantity, after - (reserved_after-after_quantity))),
            'after_max': min(after_quantity, max(Decimal(0), after))})
    if new_allocation:
        amount = new_allocation['quantity']
        rows.append({**new_allocation, 'id': None, 'quantity': Decimal(0), 'quantity_after': amount,
            'before_min': 0, 'before_max': 0,
            'after_min': max(Decimal(0), min(amount, after-(reserved_after-amount))),
            'after_max': min(amount, max(Decimal(0), after))})
    return {'reserved': reserved, 'covered_before': min(reserved, before),
        'reserved_after': reserved_after,
        'covered_after': min(reserved_after, after), 'shortfall_before': max(Decimal(0), reserved-before),
        'shortfall_after': max(Decimal(0), reserved_after-after), 'patients': rows,
        'policy': ('Mijenjaju se samo izričito navedene povezane rezervacije. ' if changes or new_allocation else 'Rezervacije i prava ostaju isti. ')
                  + 'Kod zajedničkog manjka prikazan je raspon mogućeg '
                  'pokrića; sistem ne bira pacijenta kome će oduzeti rezervaciju. Potrebna je izričita odluka o raspodjeli.'}
