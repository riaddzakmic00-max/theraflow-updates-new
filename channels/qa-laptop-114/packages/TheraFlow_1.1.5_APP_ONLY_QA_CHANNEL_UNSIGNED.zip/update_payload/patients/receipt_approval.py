"""Read-only, request-scoped approval identity and non-duplicated usage."""
from decimal import Decimal

from django.db.models import Q

from .models import (EvidencijaSaglasnostiZaprimanja, Komisija, KomisijskaStavkaLijeka,
                     KomisijskaSaglasnost, PacijentRezervacija, PacijentSaglasnost, PacijentZaduzenje,
                     KucnoIzdavanje, IzdavanjeOralneTerapije, Terapija, Trebovanje)


def _finite_quantity(value):
    try:
        return value is not None and Decimal(str(value)).is_finite()
    except (ArithmeticError, TypeError, ValueError):
        return False


def _positive_quantity(value):
    return _finite_quantity(value) and Decimal(str(value)) > 0


def _issued_approval_usage(request, commission, modern_item):
    """Independent direct-FK home/oral evidence, without another number search."""
    from .inventory_corrections import effective_issue_quantity
    zero = Decimal('0')
    assignment_total, actual_issued = zero, zero
    proofs = {'assignments': [], 'home_issues': [], 'oral_issues': []}
    assignments = list(PacijentZaduzenje.objects.filter(komisija=commission).order_by('pk')) if commission else []
    for assignment in assignments:
        if (assignment.pacijent_id != request.pacijent_id or assignment.lijek_id != request.lijek_id
                or not 0 <= assignment.preostalo <= assignment.ukupno_zaduzeno):
            return zero, zero, proofs, 'Kućno zaduženje ne odgovara pacijentu, proizvodu ili odobrenju. Provjerite izvore.'
        assignment_total += assignment.ukupno_zaduzeno
        proofs['assignments'].append({'id': assignment.pk, 'total': str(assignment.ukupno_zaduzeno),
                                      'remaining': str(assignment.preostalo), 'active': assignment.aktivno})
    home_filter = Q(komisija_id=commission.pk) | Q(pacijent_zaduzenje__komisija_id=commission.pk) if commission else Q(pk__in=[])
    for issue in KucnoIzdavanje.objects.filter(home_filter).select_related('terapija', 'pacijent_zaduzenje').order_by('pk'):
        if (issue.pacijent_id != request.pacijent_id or issue.lijek_id != request.lijek_id
                or (issue.komisija_id and issue.komisija_id != request.komisija_id)
                or (issue.pacijent_zaduzenje_id and issue.pacijent_zaduzenje.komisija_id != request.komisija_id)):
            return zero, zero, proofs, 'Kućno izdavanje ima drugo zaduženje ili odobrenje. Provjerite izvore.'
        if issue.terapija_id and issue.terapija.workflow_status == Terapija.STATUS_PONISTENA:
            continue
        quantity = max(zero, effective_issue_quantity(issue))
        actual_issued += quantity
        proofs['home_issues'].append({'id': issue.pk, 'quantity': str(quantity),
                                      'assignment_id': issue.pacijent_zaduzenje_id, 'therapy_id': issue.terapija_id})
    oral_filter = Q(komisija_id=commission.pk) if commission else Q(pk__in=[])
    if modern_item:
        oral_filter |= Q(komisijska_stavka_id=modern_item.pk)
    for issue in IzdavanjeOralneTerapije.objects.filter(oral_filter, status=IzdavanjeOralneTerapije.STATUS_AKTIVNO,
            is_migration_snapshot=False).order_by('pk'):
        if (issue.pacijent_id != request.pacijent_id or issue.lijek_id != request.lijek_id
                or (issue.komisija_id and issue.komisija_id != request.komisija_id)
                or (issue.komisijska_stavka_id and issue.komisijska_stavka_id != getattr(modern_item, 'pk', None))):
            return zero, zero, proofs, 'Oralno izdavanje ne pripada istom pacijentu, proizvodu i odobrenju. Provjerite izvore.'
        quantity = Decimal(issue.kolicina_tableta)
        actual_issued += quantity
        proofs['oral_issues'].append({'id': issue.pk, 'quantity': str(quantity), 'item_id': issue.komisijska_stavka_id})
    # Old home assignments can precede the explicit issuance model. Their
    # cumulative total remains used even after the patient consumes the last
    # unit. An ambulatory legacy assignment is only a floor, not another issue.
    if request.lijek.kucna_terapija or request.pacijent.trenutni_korak_je_kucna_terapija():
        actual_issued = max(actual_issued, assignment_total)
    return assignment_total, actual_issued, proofs, ''


def _issued_reservation_overlap(issue_proofs, reservation_proofs):
    """Only the same persisted issuance can be counted in both sources."""
    zero = Decimal('0')
    remaining = {('Terapija', issue['therapy_id']): Decimal(issue['quantity'])
                 for issue in issue_proofs['home_issues'] if issue['therapy_id']}
    remaining.update({('IzdavanjeOralneTerapije', issue['id']): Decimal(issue['quantity'])
                      for issue in issue_proofs['oral_issues']})
    overlap = zero
    for reservation in reservation_proofs:
        consumed = Decimal(reservation['consumed'])
        for event in reservation['events']:
            identity = (event['type'], event['id'])
            quantity = min(max(zero, consumed), max(zero, Decimal(event['quantity'])),
                           remaining.get(identity, zero))
            if quantity:
                overlap += quantity
                consumed -= quantity
                remaining[identity] -= quantity
    return overlap


def _shared_document_basis(request, number, approval_date, commission, modern):
    """Describe repeated labels without treating a number as an identity."""
    if not number:
        return False, [], ''
    owners, proofs = {request.pacijent_id}, []
    others = Komisija.objects.filter(broj_saglasnosti__iexact=number)
    if commission:
        others = others.exclude(pk=commission.pk)
    for other in others.order_by('pk'):
        linked = list(Trebovanje.objects.filter(komisija=other).exclude(status=Trebovanje.STATUS_OTKAZANO))
        owners.add(other.pacijent_id)
        proofs.append({'type': 'Komisija', 'id': other.pk, 'patient_id': other.pacijent_id,
                       'medicine_id': other.lijek_id, 'date': str(other.datum_odobrenja),
                       'request_ids': [row.pk for row in linked]})
    modern_others = KomisijskaSaglasnost.objects.filter(broj_saglasnosti__iexact=number).select_related('komisijski_zahtjev')
    if modern:
        modern_others = modern_others.exclude(pk=modern.pk)
    for other in modern_others.order_by('pk'):
        owners.add(other.komisijski_zahtjev.pacijent_id)
        proofs.append({'type': 'KomisijskaSaglasnost', 'id': other.pk,
                       'request_id': other.komisijski_zahtjev_id,
                       'patient_id': other.komisijski_zahtjev.pacijent_id,
                       'cycle_id': other.komisijski_zahtjev.komisijski_ciklus_id,
                       'date': str(other.datum_saglasnosti)})
    for other in PacijentSaglasnost.objects.filter(broj_saglasnosti__iexact=number).exclude(
            pacijent_id__in=owners).order_by('pk'):
        proofs.append({'type': 'PacijentSaglasnost', 'id': other.pk, 'patient_id': other.pacijent_id})
    return bool(proofs), proofs, ('Broj saglasnosti se ponavlja; koristi se konkretno odobrenje ovog zahtjeva.'
                                  if proofs else '')


def _physical_exception_scope(request):
    """Only a known approved shipment can enter the controlled free path."""
    from .commission_exclusions import visible_commission_requests
    from .inventory import patient_allocation_product_ids
    from .models import PotrebaFizickogPokrica, Zaliha
    from dashboard.receipt_display import receipt_totals
    if (not request.komisijski_ciklus_id or not _positive_quantity(request.broj_doza)
            or request.status not in ('ODOBRENO', 'CEKA_ISPORUKU', 'DJELOMICNO_ODOBRENO')
            or request.komisijski_ciklus.status not in ('ODOBRENO', 'CEKA_ISPORUKU', 'DJELOMICNO_ZAPRIMLJENO')
            or not request.pacijent.aktivan or request.pacijent.na_aktivnoj_pauzi()
            or request.lijek_id not in patient_allocation_product_ids(request.pacijent)):
        return False
    rows = list(visible_commission_requests(request.komisijski_ciklus.trebovanja.filter(
        lijek_id=request.lijek_id)).select_related('lijek'))
    if request.pk not in {row.pk for row in rows}:
        return False
    if any(row.pk != request.pk and row.pacijent_id == request.pacijent_id
           and row.status != Trebovanje.STATUS_OTKAZANO for row in rows):
        return False
    commission = request.komisija if request.komisija_id else None
    if (commission and commission.pacijent_id == request.pacijent_id and commission.lijek_id == request.lijek_id
            and Trebovanje.objects.filter(komisija=commission).exclude(pk=request.pk).exclude(
                status=Trebovanje.STATUS_OTKAZANO).exists()):
        return False
    if receipt_totals(request.komisijski_ciklus, request.lijek, rows)['history_incomplete']:
        return False
    physical_ids = request.lijek.physical_equivalent_ids()
    stocks = list(Zaliha.objects.filter(lijek_id__in=physical_ids).values_list('u_frizideru', flat=True))
    reserved = sum(PacijentRezervacija.objects.filter(lijek_id__in=physical_ids, aktivno=True)
                   .values_list('kolicina', flat=True), Decimal('0'))
    if any(quantity < 0 for quantity in stocks) or reserved > sum(stocks, Decimal('0')):
        return False
    return not PotrebaFizickogPokrica.objects.filter(lijek_id__in=physical_ids,
        status=PotrebaFizickogPokrica.STATUS_CEKA, preostala_kolicina__gt=0).exists()


def _physical_received_for_request(request, claims):
    """Count proven request sources; an unassigned cycle receipt stays group stock."""
    from .inventory_corrections import allocation_quantity, receipt_quantity
    from .models import UnlinkedStockReceipt, ZalihaTransakcija
    zero = Decimal('0')
    quantities = {}
    for claim in claims:
        if claim.fizicka_transakcija_id:
            quantities[claim.fizicka_transakcija_id] = quantities.get(claim.fizicka_transakcija_id, zero) + max(
                zero, allocation_quantity(claim))
    direct = ZalihaTransakcija.objects.filter(lijek_id=request.lijek_id, tip='ZAPRIMANJE',
        referenca_tip='Trebovanje', referenca_id=request.pk)
    for source in direct:
        quantities[source.pk] = max(quantities.get(source.pk, zero), max(zero, receipt_quantity(source)))
    for link in UnlinkedStockReceipt.objects.filter(request=request).select_related('movement'):
        quantities[link.movement_id] = max(quantities.get(link.movement_id, zero), max(zero, receipt_quantity(link.movement)))
    return sum(quantities.values(), zero)


def request_receipt_accounting(request, *, commission=None, modern_item=None):
    """Read exact receipt/allocation sources even when request quantities conflict.

    This exposes facts, never an approval or permission. A cycle-only free
    receipt remains outside the patient-owned physical quantity.
    """
    from .commission_receiving import received_commission_quantity
    from .inventory_corrections import allocation_quantity, reservation_consumption
    zero = Decimal('0')
    commission = commission or (request.komisija if request.komisija_id else None)
    if commission and (commission.pacijent_id, commission.lijek_id) != (request.pacijent_id, request.lijek_id):
        return {}, 'Povezano odobrenje pripada drugom pacijentu ili proizvodu.'
    claims = list(EvidencijaSaglasnostiZaprimanja.objects.filter(trebovanje=request)
                  .select_related('saglasnost', 'fizicka_transakcija', 'rezervacija').order_by('pk'))
    claim_quantity = zero
    for claim in claims:
        if (claim.pacijent_id != request.pacijent_id or claim.saglasnost.pacijent_id != request.pacijent_id
                or claim.komisijski_ciklus_id != request.komisijski_ciklus_id
                or (claim.fizicka_transakcija_id and claim.fizicka_transakcija.lijek_id != request.lijek_id)):
            return {}, 'Raniji prijem nije povezan s istim pacijentom, zahtjevom i proizvodom. Provjerite izvore.'
        source, reservation = claim.fizicka_transakcija, claim.rezervacija
        if (source and ((source.komisija_id and source.komisija_id != request.komisija_id)
                or (source.komisijski_ciklus_id and source.komisijski_ciklus_id != request.komisijski_ciklus_id)
                or (source.pacijent_id and source.pacijent_id != request.pacijent_id))):
            return {}, 'Izvor ranijeg prijema pripada drugom pacijentu ili odobrenju. Provjerite vezu prijema.'
        if (reservation and (reservation.pacijent_id != request.pacijent_id
                or reservation.lijek_id != request.lijek_id
                or (reservation.trebovanje_id and reservation.trebovanje_id != request.pk)
                or (reservation.komisija_id and reservation.komisija_id != request.komisija_id))):
            return {}, 'Dokaz ranije raspodjele ima drugo zaduženje ili odobrenje. Provjerite izvore.'
        claim_quantity += max(zero, allocation_quantity(claim))
    reservation_filter = Q(trebovanje_id=request.pk)
    if commission:
        reservation_filter |= Q(komisija_id=commission.pk)
    reservations = list(PacijentRezervacija.objects.filter(reservation_filter).order_by('pk'))
    reserved, consumed = zero, zero
    reservation_proofs = []
    for reservation in reservations:
        if (reservation.pacijent_id != request.pacijent_id or reservation.lijek_id != request.lijek_id
                or (reservation.trebovanje_id and reservation.trebovanje_id != request.pk)
                or (reservation.komisija_id and reservation.komisija_id != request.komisija_id)):
            return {}, 'Ranije zaduženje ima drugo odobrenje ili zahtjev. Provjerite izvore prije raspodjele.'
        current = Decimal(str(reservation.kolicina or 0)) if reservation.aktivno else zero
        spent, events = reservation_consumption(reservation)
        spent = max(zero, spent)
        reserved += current
        consumed += spent
        reservation_proofs.append({'id': reservation.pk, 'current': str(current),
                                   'consumed': str(spent), 'events': events})
    received = max(zero, received_commission_quantity(request), claim_quantity)
    commission_used = (max(zero, commission.broj_odobrenih_doza - commission.preostale_doze)
                       if commission else zero)
    assigned_total, issued_total, issue_proofs, issue_error = _issued_approval_usage(request, commission, modern_item)
    if issue_error:
        return {}, issue_error
    issued_from_reservations = _issued_reservation_overlap(issue_proofs, reservation_proofs)
    independently_issued = max(zero, issued_total - issued_from_reservations)
    previously_allocated = max(zero, Decimal(str(request.zaprimljene_doze or zero)), claim_quantity,
                               reserved + consumed + independently_issued, assigned_total, commission_used)
    used = max(received, previously_allocated)
    return {'received': str(received), 'reserved': str(reserved), 'consumed': str(consumed),
        'issued': str(issued_total), 'used': str(used),
        'physically_received': str(_physical_received_for_request(request, claims)),
        'previously_allocated': str(previously_allocated),
        'approval_proofs': {'request_id': request.pk, 'commission_id': request.komisija_id,
            'modern_agreement_id': modern_item.komisijski_zahtjev.saglasnost.pk if modern_item else None,
            'modern_item_id': modern_item.pk if modern_item else None,
            'receipt_claim_ids': [claim.pk for claim in claims], 'receipt_claim_quantity': str(claim_quantity),
            'request_received': str(request.zaprimljene_doze or zero), 'commission_used': str(commission_used),
            'reservations': reservation_proofs, 'issued': issue_proofs, 'assignment_total': str(assigned_total),
            'issued_from_reservations': str(issued_from_reservations),
            'independently_issued': str(independently_issued)}}, ''


def _accounting_result(result, request, commission, modern_item, approved):
    accounting, error = request_receipt_accounting(request, commission=commission, modern_item=modern_item)
    if error:
        return error
    accounting['approval_proofs'] = {**result.get('approval_proofs', {}), **accounting['approval_proofs']}
    result.update(accounting)
    result.update(remaining_delivery=str(max(Decimal(0), approved - Decimal(accounting['physically_received']))),
                  remaining_allocation=str(max(Decimal(0), approved - Decimal(accounting['previously_allocated']))))
    return ''


def _document_membership(request, modern_item, commission):
    """Prove a concrete document membership; a shared printed label is no FK."""
    if not modern_item:
        return None, ''
    from .models import KomisijskaDokumentStavka
    modern = modern_item.komisijski_zahtjev.saglasnost
    lines = list(KomisijskaDokumentStavka.objects.filter(stavka_lijeka=modern_item)
        .exclude(odluka='ceka').select_related('dokument', 'saglasnost').order_by('pk'))
    if not lines:
        return None, ''
    valid = [line for line in lines if
        line.dokument.komisijski_ciklus_id == request.komisijski_ciklus_id
        and line.komisijski_zahtjev_id == modern_item.komisijski_zahtjev_id
        and line.pacijent_id == request.pacijent_id and line.lijek_id == request.lijek_id
        and line.saglasnost_id == modern.pk
        and (not line.komisija_id or line.komisija_id == getattr(commission, 'pk', None))
        and line.odluka == modern.odluka
        and line.odobrena_kolicina_snapshot == modern_item.odobrena_kolicina
        and line.trazena_kolicina_snapshot == modern_item.kolicina
        and line.jedinica_snapshot == modern_item.jedinica
        and line.dokument.broj_dokumenta == (modern.broj_saglasnosti or '').strip()
        and line.dokument.datum_dokumenta == modern.datum_saglasnosti]
    if len(valid) != 1:
        return None, 'Članstvo u dokumentu odluke nije jednoznačno povezano s ovim pacijentom, proizvodom i odobrenjem. Potrebna je provjera.'
    line = valid[0]
    return {'document_id': line.dokument_id, 'document_number': line.dokument.broj_dokumenta,
        'document_label': line.dokument.display_label,
        'document_line_id': line.pk, 'document_date': line.dokument.datum_dokumenta.isoformat(),
        'document_proof': {'document_id': line.dokument_id, 'line_id': line.pk,
            'request_id': line.komisijski_zahtjev_id, 'item_id': line.stavka_lijeka_id,
            'patient_id': line.pacijent_id, 'medicine_id': line.lijek_id,
            'modern_agreement_id': line.saglasnost_id, 'commission_id': line.komisija_id,
            'approved_snapshot': str(line.odobrena_kolicina_snapshot)}}, ''


def _same_document_owners(document_id, proofs):
    from .models import KomisijskaDokumentStavka
    siblings = list(KomisijskaDokumentStavka.objects.filter(dokument_id=document_id)
        .exclude(odluka='ceka').values('komisija_id', 'saglasnost_id', 'pacijent_id'))
    commissions = {line['komisija_id'] for line in siblings if line['komisija_id']}
    agreements = {line['saglasnost_id'] for line in siblings if line['saglasnost_id']}
    patients = {line['pacijent_id'] for line in siblings}
    return all((proof['type'] == 'Komisija' and proof['id'] in commissions)
        or (proof['type'] == 'KomisijskaSaglasnost' and proof['id'] in agreements)
        or (proof['type'] == 'PacijentSaglasnost' and proof['patient_id'] in patients)
        for proof in proofs)


def request_receipt_approval(request, agreement_number=None):
    """Resolve this request's document, never another patient's matching number.

    A reservation and its receipt snapshot describe the same allocated units.
    Consumption also belongs to those units, rather than reopening capacity.
    All quantities are strings so the complete basis can be signed/audited.
    """
    from .commission_receiving import normalize_agreement_number

    zero = Decimal('0')
    approved = Decimal(str(request.odobrene_doze or 0))
    result = {'approved': str(approved), 'request_requested': str(request.broj_doza or zero),
              'request_approved': str(approved), 'actual_approved': None,
              'physically_received': None, 'previously_allocated': None,
              'remaining_delivery': None, 'remaining_allocation': None,
              'document_id': None, 'document_number': '', 'document_line_id': None,
              'document_date': '', 'document_proof': None,
              'shared_document': False, 'external_number_required': True, 'document_label': '',
              'received': '0', 'reserved': '0', 'used': '0',
              'consumed': '0', 'issued': '0', 'maximum': '0', 'approval_identity': '',
              'approval_source': 'MISSING', 'approval_number': '', 'approval_date': '', 'shared_number': False,
              'approval_proofs': {}, 'blocked': False, 'warning': '', 'physical_blocked': False,
              'number_repeated': False, 'number_warning': '', 'identity_conflict': False,
              'quantity_conflict': False, 'physical_exception_required': False, 'physical_exception_code': ''}

    def blocked(message, *, physical=True, code='', exception=False):
        result.update(blocked=True, warning=message, maximum='0', physical_blocked=physical,
                      physical_exception_code=code,
                      physical_exception_required=bool(exception and _physical_exception_scope(request)))
        return result

    if not approved.is_finite() or approved <= 0:
        result['approved'] = '0'
        return blocked('Nedostaje pouzdana odobrena količina za ovaj zahtjev.')
    if not _positive_quantity(request.broj_doza):
        return blocked('Nedostaje pouzdana pozitivna količina komisijskog zahtjeva.')

    commission = request.komisija if request.komisija_id else None
    # Modern requests have no direct FK to Trebovanje. The exact patient,
    # cycle and presentation must therefore identify ONE decided item.
    decided_items = list(KomisijskaStavkaLijeka.objects.filter(
        komisijski_zahtjev__pacijent_id=request.pacijent_id,
        komisijski_zahtjev__komisijski_ciklus_id=request.komisijski_ciklus_id,
        lijek_id=request.lijek_id, komisijski_zahtjev__saglasnost__isnull=False,
    ).select_related('komisijski_zahtjev__saglasnost').order_by('pk'))
    if len(decided_items) > 1:
        result.update(identity_conflict=True, approval_proofs={'request_id': request.pk,
            'modern_item_ids': [item.pk for item in decided_items]})
        all_approved = all(item.komisijski_zahtjev.saglasnost.odluka in (
            KomisijskaSaglasnost.Odluka.ODOBRENO, KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO)
            and _positive_quantity(item.odobrena_kolicina) for item in decided_items)
        return blocked('Više odluka za isti zahtjev i proizvod. Potrebna je provjera identiteta odobrenja.',
                       code='MULTIPLE_APPROVAL_ITEMS', exception=all_approved)
    modern_item = decided_items[0] if decided_items else None
    modern = modern_item.komisijski_zahtjev.saglasnost if modern_item else None
    document, document_error = _document_membership(request, modern_item, commission)
    if document_error:
        result['identity_conflict'] = True
        return blocked(document_error, code='DOCUMENT_MEMBERSHIP_CONFLICT')
    if document:
        result.update(document)
        result['shared_document'] = True
    if modern and not _positive_quantity(modern_item.odobrena_kolicina):
        result.update(approved='0', actual_approved=str(modern_item.odobrena_kolicina)
                      if _finite_quantity(modern_item.odobrena_kolicina) else None,
                      approval_identity=f'KomisijskaSaglasnost:{modern.pk}:stavka:{modern_item.pk}',
                      approval_source='MODERN_AGREEMENT', approval_proofs={'request_id': request.pk,
                          'modern_agreement_id': modern.pk, 'modern_item_id': modern_item.pk,
                          'modern_approved': str(modern_item.odobrena_kolicina)})
        return blocked('Nedostaje pouzdana pozitivna odobrena količina u komisijskoj odluci.')
    if modern and (modern.odluka not in (KomisijskaSaglasnost.Odluka.ODOBRENO,
                                       KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO)
                   or modern_item.odobrena_kolicina != approved):
        result.update(approved=str(modern_item.odobrena_kolicina or zero),
                      actual_approved=str(modern_item.odobrena_kolicina or zero), quantity_conflict=True,
                      approval_identity=f'KomisijskaSaglasnost:{modern.pk}:stavka:{modern_item.pk}',
                      approval_source='MODERN_AGREEMENT', approval_number=normalize_agreement_number(modern.broj_saglasnosti),
                      approval_date=modern.datum_saglasnosti.isoformat(), approval_proofs={
                          'request_id': request.pk, 'modern_agreement_id': modern.pk,
                          'modern_item_id': modern_item.pk, 'request_approved': str(approved),
                          'modern_approved': str(modern_item.odobrena_kolicina or zero)})
        valid_decision = modern.odluka in (KomisijskaSaglasnost.Odluka.ODOBRENO,
            KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO) and _positive_quantity(modern_item.odobrena_kolicina)
        if valid_decision and not commission:
            _accounting_result(result, request, None, modern_item, modern_item.odobrena_kolicina)
        return blocked('Odluka i odobrena količina zahtjeva nisu usklađene. Provjerite odobrenje.',
                       code='APPROVAL_QUANTITY_MISMATCH', exception=bool(valid_decision))
    if commission:
        if not _positive_quantity(commission.broj_odobrenih_doza) or not _finite_quantity(commission.preostale_doze):
            result.update(approved='0', actual_approved=str(commission.broj_odobrenih_doza)
                          if _finite_quantity(commission.broj_odobrenih_doza) else None,
                          approval_identity=f'Komisija:{commission.pk}', approval_source='LEGACY_COMMISSION',
                          approval_proofs={'request_id': request.pk, 'commission_id': commission.pk,
                              'commission_approved': str(commission.broj_odobrenih_doza),
                              'commission_remaining': str(commission.preostale_doze)})
            return blocked('Nedostaje pouzdana pozitivna količina ili saldo povezanog odobrenja.')
        result.update(approval_identity=f'Komisija:{commission.pk}', approval_source='LEGACY_COMMISSION',
                      approved=str(commission.broj_odobrenih_doza),
                      approval_number=normalize_agreement_number(commission.broj_saglasnosti),
                      approval_date=commission.datum_odobrenja.isoformat(),
                      used=str(max(zero, commission.broj_odobrenih_doza - commission.preostale_doze)),
                      approval_proofs={'commission_id': commission.pk,
                          'request_id': request.pk, 'request_patient_id': request.pacijent_id,
                          'request_medicine_id': request.lijek_id, 'request_cycle_id': request.komisijski_ciklus_id,
                          'commission_patient_id': commission.pacijent_id, 'commission_medicine_id': commission.lijek_id,
                          'commission_approved': str(commission.broj_odobrenih_doza),
                          'commission_remaining': str(commission.preostale_doze),
                          'request_approved': str(approved)})
        identity_mismatch = commission.pacijent_id != request.pacijent_id or commission.lijek_id != request.lijek_id
        result.update(actual_approved=None if identity_mismatch else str(commission.broj_odobrenih_doza),
                      previously_allocated=None if identity_mismatch else result['used'],
                      identity_conflict=identity_mismatch,
                      quantity_conflict=commission.broj_odobrenih_doza != approved)
        if identity_mismatch or commission.broj_odobrenih_doza != approved:
            valid_commission = (commission.status in (*commission.VAZECI_STATUSI, 'POTROSENA')
                                and commission.broj_odobrenih_doza > 0
                                and 0 <= commission.preostale_doze <= commission.broj_odobrenih_doza)
            if not identity_mismatch and valid_commission:
                _accounting_result(result, request, commission, None, commission.broj_odobrenih_doza)
            return blocked('Povezano odobrenje ne odgovara pacijentu, proizvodu ili odobrenoj količini zahtjeva.',
                           code='APPROVAL_IDENTITY_MISMATCH' if identity_mismatch else 'APPROVAL_QUANTITY_MISMATCH',
                           exception=valid_commission)
        if not 0 <= commission.preostale_doze <= approved:
            return blocked('Saldo povezanog odobrenja nije usklađen. Provjerite izvore.')
        if commission.status not in (*commission.VAZECI_STATUSI, 'POTROSENA'):
            return blocked('Povezano odobrenje nije važeće. Potrebna je provjera odluke.')
        if Trebovanje.objects.filter(komisija_id=commission.pk).exclude(pk=request.pk).exclude(
                status=Trebovanje.STATUS_OTKAZANO).exists():
            return blocked('Isto odobrenje je povezano s više zahtjeva. Provjerite duplikate prije raspodjele.')
        if modern and (commission.datum_odobrenja != modern.datum_saglasnosti or
                normalize_agreement_number(commission.broj_saglasnosti).casefold() !=
                normalize_agreement_number(modern.broj_saglasnosti).casefold()):
            result.update(identity_conflict=True, actual_approved=None)
            return blocked('Povezano i komisijsko odobrenje nisu ista odluka. Potrebna je provjera.',
                           code='APPROVAL_DECISION_CONFLICT', exception=True)
    elif modern:
        result.update(approval_identity=f'KomisijskaSaglasnost:{modern.pk}:stavka:{modern_item.pk}',
                      approval_source='MODERN_AGREEMENT',
                      actual_approved=str(approved),
                      approval_number=normalize_agreement_number(modern.broj_saglasnosti),
                      approval_date=modern.datum_saglasnosti.isoformat())
    else:
        # Old explicit receiving rows can predate both approval models. Do not
        # infer an approval from requested quantity, a date on another cycle or
        # a number belonging to another request.
        cycle = request.komisijski_ciklus
        number = normalize_agreement_number(agreement_number)
        if (not cycle or not cycle.datum_odobrenja or not number
                or request.status not in ('ODOBRENO', 'CEKA_ISPORUKU', 'DJELOMICNO_ODOBRENO')):
            return blocked('Nedostaje pouzdano odobrenje za ovaj zahtjev. Provjerite odluku komisije.')
        result.update(approval_identity=f'Trebovanje:{request.pk}:ciklus:{cycle.pk}',
                      approval_source='LEGACY_REQUEST', actual_approved=str(approved), approval_number=number,
                      approval_date=cycle.datum_odobrenja.isoformat())
    if Trebovanje.objects.filter(pacijent_id=request.pacijent_id, lijek_id=request.lijek_id,
            komisijski_ciklus_id=request.komisijski_ciklus_id).exclude(pk=request.pk).exclude(
                status=Trebovanje.STATUS_OTKAZANO).exists():
        return blocked('Više zahtjeva za isti proizvod i pacijenta: provjerite duplikate.')
    supplied_number = normalize_agreement_number(agreement_number)
    number_conflict = ''
    if supplied_number and (result['approval_number'] or document) and supplied_number.casefold() != result['approval_number'].casefold():
        number_conflict = 'Uneseni broj saglasnosti ne odgovara odobrenju ovog zahtjeva.'
    approval_date = (commission.datum_odobrenja if commission else
                     modern.datum_saglasnosti if modern else request.komisijski_ciklus.datum_odobrenja)
    shared, shared_proofs, number_warning = _shared_document_basis(request,
        result['approval_number'] or supplied_number, approval_date, commission, modern)
    result.update(shared_number=shared, number_repeated=shared, number_warning=number_warning)
    if document and _same_document_owners(document['document_id'], shared_proofs):
        result['number_warning'] = ''

    accounting_error = _accounting_result(result, request, commission, modern_item, approved)
    if accounting_error:
        return blocked(accounting_error)
    result['actual_approved'] = str(approved)
    result['maximum'] = str(max(zero, approved - Decimal(result['used'])))
    result['approval_proofs']['shared_document'] = shared_proofs
    if document:
        result['approval_proofs']['document_membership'] = document['document_proof']
    if Decimal(result['used']) > approved:
        return blocked('Raniji prijemi ili zaduženja prelaze isto odobrenje. Potrebna je provjera izvora.')
    if number_conflict:
        return blocked(number_conflict, physical=False)
    # The persisted item FK supplies identity only after all approval/usage
    # checks passed. An absent number alone never grants receiving rights.
    result['external_number_required'] = not bool(document)
    return result
