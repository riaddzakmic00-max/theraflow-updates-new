"""A reasoned administrative envelope around existing correction services.

No clinical override, arbitrary field editor or new inventory arithmetic.
"""
from uuid import uuid4

from django.core import signing

from . import models as m, correction_center, physical_stock_corrections, inventory_corrections
from .correction_protocol import correction_read_snapshot, correction_transaction
from .data_corrections import CorrectionBlocked, backup_before_correction, captured_rows, digest, require, serial

SALT = 'theraflow.controlled-correction.v1'
STALE = 'Podaci su promijenjeni nakon pregleda. Ponovo pokrenite provjeru.'
PROBLEMS = [('historical', 'Historijski terapijski plan nije dokazan'),
            ('allocation', 'Nerazriješeno zaduženje'),
            ('commission', 'Komisijska veza nije pronađena'),
            ('physical', 'Fizičko neslaganje'),
            ('legacy', 'Stara nekonzistentna evidencija')]


def plan(raw, user):
    correction_center.authorize(user)
    require(raw.get('problem') in dict(PROBLEMS), 'Odaberite problem standardnog workflowa.')
    reason = str(raw.get('reason', '')).strip()
    explanation = str(raw.get('explanation', '')).strip()
    require(5 <= len(reason) <= 500, 'Razlog korekcije je obavezan (5–500 znakova).')
    require(5 <= len(explanation) <= 1000, 'Objasnite zašto standardni workflow ne može završiti radnju (5–1.000 znakova).')
    medicine = m.Lijek.objects.get(pk=raw['medicine_id'])
    patient = m.Pacijent.objects.get(pk=raw['patient_id']) if raw.get('patient_id') else None
    kind = raw['kind']
    if kind == 'physical':
        from dashboard.stock_correction_forms import PhysicalStockCorrectionForm
        form = PhysicalStockCorrectionForm(dict(lijek=medicine.pk, kolicina=raw['quantity'], razlog=reason,
            obuhvat=raw.get('scope') or 'TOTAL', serija=raw.get('batch', ''),
            rok_trajanja=raw.get('expires', ''), datum_dogadjaja=raw.get('event_date', ''),
            razlog_kod='COUNT_UNKNOWN'))
        require(form.is_valid(), 'Provjerite fizičku količinu, datum, seriju i rok: ' + str(form.errors.as_text()))
        native = physical_stock_corrections.preview(form.cleaned_data)
        native['title'] = 'Ispravka prema fizičkom popisu'
        native['rows'] = [dict(label='Fizičko stanje', before=str(native['total_before']), after=str(native['total_after'])),
                          dict(label='Rezervacije / zaduženja', before=str(native['reserved']), after=str(native['reserved']))]
    elif kind in ('allocate', 'release'):
        require(patient is not None, 'Za zaduženje odaberite pacijenta.')
        native = correction_center.allocation_plan(patient, medicine, dict(kind=kind, quantity=raw['quantity'],
            reason=reason, reservation_id=raw.get('reservation_id'),
            acknowledge_appointment=raw.get('acknowledge_appointment') is True), user)
    elif kind == 'record':
        require(raw.get('target_kind') in ('receipt', 'allocation', 'patient_stock', 'issue'),
                'Odaberite konkretan dokumentovani prijem, raspodjelu, zaduženje ili kućno izdavanje.')
        data = dict(quantity=raw['quantity'], reason=reason, event_date=raw.get('event_date'),
                    context_patient_id=patient.pk if patient else None)
        if raw['target_kind'] == 'patient_stock':
            data.update(source_mode='EXISTING', approval=raw.get('approval'), source_movement=raw.get('source_movement'))
        native = inventory_corrections.preview(raw['target_kind'], raw.get('target_id'), data, user)
        require(native['medicine_id'] == medicine.pk and
                (not patient or native.get('patient_id') == patient.pk), 'Konkretan zapis ne pripada odabranom pacijentu / prezentaciji.')
        patient = m.Pacijent.objects.get(pk=native['patient_id']) if native.get('patient_id') else patient
    else:
        raise CorrectionBlocked('Odaberite podržanu kontrolisanu korekciju.')
    session = None
    if raw.get('session_id'):
        session = m.ReconciliationSession.objects.get(pk=raw['session_id'], user=user)
        require(session.status not in ('cancelled', 'completed', 'aligned'), 'Proces je završen; otvorite novi postupak.')
        require(not session.patient_id or patient and patient.pk == session.patient_id, 'Pacijent nije dio procesa.')
        require(not session.medicine_id or medicine.pk in session.medicine.equivalent_ids(), 'Lijek nije dio procesa.')
    from dashboard.permissions import korisnik_uloga
    metadata = dict(actor_role=korisnik_uloga(user), source='controlled_correction', problem=raw['problem'], problem_label=dict(PROBLEMS)[raw['problem']],
        explanation=explanation, reason=reason, medicine_id=medicine.pk, medicine=str(medicine),
        patient=str(patient) if patient else 'Zajednička zaliha',
        patient_id=patient.pk if patient else None, session_id=session.pk if session else None, kind=kind)
    from .correction_impact import impact_analysis
    return native, metadata, impact_analysis(patient, medicine, native, user)


def preview(raw, user):
    with correction_read_snapshot():
        native, metadata, impact = plan(raw, user)
        token = signing.dumps(dict(operation=str(uuid4()), user=user.pk, raw=serial(raw),
            fingerprint=digest(captured_rows()), plan_digest=digest(serial(native)), metadata=metadata), salt=SALT, compress=True)
        return dict(native=serial(native), metadata=metadata, impact=impact), token


def confirm(token, user):
    correction_center.authorize(user)
    try:
        payload = signing.loads(token, salt=SALT)
    except signing.BadSignature:
        raise CorrectionBlocked('Pregled nije važeći. Ponovite korekciju.') from None
    require(payload['user'] == user.pk, 'Pregled pripada drugom korisniku.')
    with correction_transaction():
        existing = m.PatientDataCorrection.objects.filter(operation_id=payload['operation']).first()
        if existing:
            require(existing.korisnik_id == user.pk and isinstance(existing.posljedice, dict) and
                    existing.posljedice.get('controlled', {}).get('source') == 'controlled_correction', STALE)
            return existing, False
        try:
            signing.loads(token, salt=SALT, max_age=1800)
        except signing.BadSignature:
            raise CorrectionBlocked('Pregled je istekao. Ponovite korekciju.') from None
        require(digest(captured_rows()) == payload['fingerprint'], STALE)
        native, metadata, _ = plan(payload['raw'], user)
        require(digest(serial(native)) == payload['plan_digest'] and metadata == payload['metadata'], STALE)
        backup = backup_before_correction(payload['operation'])
        if metadata['kind'] == 'physical':
            physical, _ = physical_stock_corrections.apply_plan(native, user, payload['operation'], backup)
            receipt = m.PatientDataCorrection.objects.create(operation_id=payload['operation'],
                korisnik=user, pacijent_id=metadata['patient_id'], scope='controlled_physical',
                razlog=metadata['reason'], datum_dogadjaja=native['event_date'],
                prije=serial(dict(physical=native['total_before'], reserved=native['reserved'])),
                poslije=serial(dict(physical=native['total_after'], reserved=native['reserved'])),
                posljedice=dict(rows=native['rows'], warnings=native['warnings'],
                    medicine_id=metadata['medicine_id'], physical_correction_id=physical.pk), backup=backup)
            movement = m.ZalihaTransakcija.objects.get(referenca_tip='PhysicalStockCorrection', referenca_id=physical.pk)
            receipt.izvorna_transakcija = movement
        elif metadata['kind'] in ('allocate', 'release'):
            receipt, _ = correction_center.apply_allocation_plan(native, user, payload['operation'], backup)
        else:
            receipt = inventory_corrections.apply_plan(native, user, payload['operation'], backup)
        receipt.posljedice = dict(receipt.posljedice, controlled=metadata)
        receipt.save(update_fields=['posljedice', 'izvorna_transakcija'])
        if metadata['session_id']:
            session = m.ReconciliationSession.objects.select_for_update().get(pk=metadata['session_id'], user=user)
            m.ReconciliationAction.objects.create(operation_id=payload['operation'], session=session,
                user=user, decision='controlled_correction', data_correction=receipt,
                summary=serial(dict(metadata, decision='Kontrolisana administratorska korekcija',
                    rows=receipt.posljedice.get('rows', []), warnings=receipt.posljedice.get('warnings', []))))
            session.revision += 1
            session.status = 'needs_review'
            session.save(update_fields=['revision', 'status', 'updated_at'])
        from .utils import upisi_log
        upisi_log(user, 'Kontrolisana administratorska korekcija', pacijent=receipt.pacijent,
            objekat=receipt, opis=f'{metadata["problem_label"]}: {metadata["explanation"]}. '
            f'Razlog: {metadata["reason"]}; izvor: Kontrolisana korekcija.')
        return receipt, True


def remaining_checks(receipt, user):
    """Fresh, read-only analysis AFTER commit, never part of the write effects."""
    correction_center.authorize(user)
    from .activity_review import read_projection
    from .correction_impact import impact_analysis, balance_explanation
    with read_projection():
        patient = receipt.pacijent
        medicine = m.Lijek.objects.get(pk=receipt.posljedice['controlled']['medicine_id'])
        return dict(impact=impact_analysis(patient, medicine, {}, user),
                    balance=balance_explanation(medicine, patient))
