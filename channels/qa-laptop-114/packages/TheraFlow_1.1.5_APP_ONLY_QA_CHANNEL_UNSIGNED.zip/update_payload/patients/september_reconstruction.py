"""Bounded reconstruction using normal receipts/therapies and an audited count.

The count is an observation, never a receipt. Its provisional ledger difference
is reclassified only when complete documented history explains that difference.
All calls run inside the existing batch correction transaction/savepoint.
"""
from contextvars import ContextVar
from datetime import date, timedelta
from decimal import Decimal
import uuid
from django.db.models import Sum
from django.utils import timezone
from . import models as m
from .data_corrections import require, serial

START, END = date(2026, 9, 1), date(2026, 9, 30)
_context = ContextVar('september_reconstruction', default=None)


def active():
    return _context.get()


def set_event(data):
    state = active()
    if state:
        state['when'] = date.fromisoformat(data['event_date'])


def eligible_reservations(items):
    """Never spend a later reservation to explain an earlier administration."""
    state = active()
    if not state:
        return list(items)
    from .inventory_corrections import receipt_date
    result = []
    for item in items:
        if item.pk in state['original_reservations'] and item.datum_rezervacije > state['when']:
            continue
        claims = list(item.izvori_prijema.select_related('fizicka_transakcija'))
        if claims:
            eligible = all(c.fizicka_transakcija_id and receipt_date(c.fizicka_transakcija) <= state['when'] for c in claims)
        else:
            eligible = item.datum_rezervacije <= state['when']
        if eligible:
            result.append(item)
    return result


def separate_receipt_reservation(source, pending):
    state = active()
    if not state:
        return source
    require(pending is None, 'Postoji ranija neriješena potreba za raspodjelom. Rekonstrukcija ne smije preusmjeriti lijek na drugi događaj.')
    return None if source and source.pk in state['original_reservations'] else source


def selected_count_id():
    return active()['count'].pk if active() else None


def _proof(draft, rows):
    from .fridge_history import fridge_balances_at
    from .inventory import izracunaj_frizider_iz_transakcija
    info = draft.reconstruction
    require(draft.period_start == START and draft.period_end == END,
            'Privremeni unos obuhvata tačno period 01.09.–30.09.2026.')
    require(info.get('verified') is True and len(str(info.get('evidence', '')).strip()) >= 10,
            'Potvrdite provjeru popisa i navedite dokument ili izvršenu provjeru izvora.')
    count = m.PhysicalStockCorrection.objects.filter(pk=info.get('count_id')).first()
    require(count is not None and count.pregled.get('event_date') == str(END),
            'Odaberite konkretan dokumentovani fizički popis od 30.09.2026.')
    require(count.pregled.get('cause') == 'COUNT_UNKNOWN',
            'Odabrana korekcija mora biti popis s prvobitno nerazjašnjenom razlikom, ne drugi poslovni događaj.')
    require(not m.PhysicalStockCorrection.objects.filter(pregled__previous_correction_id=count.pk).exists(),
            'Ovaj popis je naknadno ispravljen. Potrebna je provjera posljednjeg važećeg popisa.')
    require(not m.RetrospectiveBatch.objects.filter(status='CONFIRMED', reconstruction__count_id=count.pk).exclude(pk=draft.pk).exists()
            and not count.retrospective_events.filter(reversed_at__isnull=True).exists(),
            'Odabrani popis već je razjašnjen povezanim događajima. Otvorite njihov zajednički pregled.')
    source = list(m.ZalihaTransakcija.objects.filter(referenca_tip='PhysicalStockCorrection', referenca_id=count.pk, lijek=count.lijek))
    require(len(source) == 1 and source[0].datum == END and source[0].frizider_delta() == count.razlika,
            'Popis nema jednoznačan neizmijenjen promet na 30.09. Datumi postojećih zapisa se ne mijenjaju.')
    source = source[0]
    require(not m.ZalihaTransakcija.objects.filter(lijek=count.lijek, datum=END, pk__gt=source.pk).exists(),
            'Poslije popisa postoje drugi prometi na isti datum. Potrebno je razjasniti njihov redoslijed prije rekonstrukcije.')
    require(all(r['medicine_id'] == count.lijek_id and r['kind'] in ('receipt', 'therapy')
                and not r.get('stock_correction_id') for r in rows),
            'Jedan kontrolni popis obuhvata isti proizvod: stvarne prijeme i ambulantne primjene. Za drugi proizvod otvorite zaseban unos.')
    from .inventory_corrections import receipt_date, allocation_quantity
    for row in rows:
        if row['kind'] != 'receipt' or row.get('receipt_mode') == 'EXISTING':
            continue
        claims=m.EvidencijaSaglasnostiZaprimanja.objects.filter(trebovanje_id=row['request_id']).select_related('fizicka_transakcija')
        require(not any(c.fizicka_transakcija_id and receipt_date(c.fizicka_transakcija)==date.fromisoformat(row['event_date'])
                        and allocation_quantity(c)==Decimal(row['quantity']) for c in claims),
                'Mogući duplikat stvarnog prijema. Povežite postojeći prijem; potvrda druge isporuke ne zaobilazi kontrolu rekonstrukcije.')
    # A real opening anchor is mandatory. A current count never fabricates one.
    opening = fridge_balances_at(START - timedelta(days=1)).get(count.lijek_id, {})
    closing = fridge_balances_at(END).get(count.lijek_id, {})
    require(opening.get('quantity') is not None and closing.get('quantity') is not None,
            'Nedostaje pouzdano dokumentovano početno stanje prije septembra ili potpuna historija. Popis od 30.09. nije dokaz izmišljenog prijema. '
            + opening.get('reason', '') + ' ' + closing.get('reason', ''))
    require(closing['quantity'] == count.nova_kolicina,
            f'Historija na 30.09. daje {closing["quantity"]}, a popis {count.nova_kolicina}. Prvo razjasnite postojeće neslaganje.')
    require(not m.PhysicalStockCorrection.objects.filter(lijek=count.lijek,
            pregled__event_date__gte=str(START), pregled__event_date__lte=str(END)).exclude(pk=count.pk).exists(),
            'U periodu postoje dodatna brojanja. Njihova veza mora se razjasniti prije ove rekonstrukcije.')
    net = sum((Decimal(r['quantity']) * (1 if r['kind'] == 'receipt' else -1)
               for r in rows if r.get('receipt_mode') != 'EXISTING'), Decimal(0))
    reconstructed = closing['quantity'] - count.razlika + net
    require(reconstructed == count.nova_kolicina,
            f'Neslaganje na 30.09.: historija bez privremene korekcije {closing["quantity"] - count.razlika:g}, '
            f'novi stvarni događaji {net:+g}, rekonstruisano {reconstructed:g}, prebrojano {count.nova_kolicina:g}; '
            f'razlika {reconstructed - count.nova_kolicina:+g}. Potvrda je zaustavljena; unesite samo dokazive događaje.')
    stock = m.Zaliha.objects.get(lijek=count.lijek)
    require(stock.u_frizideru == izracunaj_frizider_iz_transakcija(count.lijek), 'Današnja fizička zaliha i promet se razlikuju.')
    reservations = {r.pk: serial(m.PacijentRezervacija.objects.filter(pk=r.pk).values().get())
                    for r in m.PacijentRezervacija.objects.filter(lijek=count.lijek)}
    return dict(count=count, source=source, net=net, opening=opening['quantity'], current=stock.u_frizideru,
                original_reservations=reservations, when=START, mappings=[])


def _offset(state, draft, user, backup, *, reverse=False, reason=''):
    """Append compensating count classification; do not edit the original count."""
    source, count = state['source'], state['count']
    delta = state['net'] if reverse else -state['net']
    stock = m.Zaliha.objects.get(lijek=count.lijek)
    require(stock.u_frizideru + delta >= 0, 'Razjašnjenje popisa bi napravilo negativnu fizičku zalihu.')
    original = None
    if reverse:
        original = m.PatientDataCorrection.objects.get(pk=draft.preview['checkpoint']['audit_id'])
        require(not original.naknadne_ispravke.exists(), 'Razjašnjenje ovog popisa je već poništeno.')
    audit = m.PatientDataCorrection.objects.create(
        operation_id=uuid.uuid5(draft.operation_id, 'checkpoint-reverse' if reverse else 'checkpoint'),
        pacijent=draft.patient, korisnik=user, izvorna_transakcija=source,
        datum_dogadjaja=timezone.localdate() if reverse else END,
        scope='retro_checkpoint', ponistava=original, razlog=reason or draft.reason,
        prije=serial({'physical':stock.u_frizideru}), poslije=serial({'physical':stock.u_frizideru+delta}),
        posljedice=serial({'physical_count_id':count.pk, 'batch_id':draft.pk, 'delta':delta,
            'counted':count.nova_kolicina, 'original_count_delta':count.razlika,
            'evidence':draft.reconstruction['evidence'], 'reversed':reverse}), backup=backup)
    m.ZalihaTransakcija.objects.create(lijek=count.lijek, korisnik=user,
        tip='KOREKCIJA', datum=audit.datum_dogadjaja, kolicina=abs(delta), promjena_salda=delta,
        izvorna_transakcija=source, korekcija=audit, operation_id=audit.operation_id,
        referenca_tip='PatientDataCorrection', referenca_id=audit.pk, serija=source.serija,
        rok_trajanja=source.rok_trajanja, lokacija='FRIZIDER', napomena=reason or draft.reason)
    # Temporary balances stay inside the locked transaction. Final consistency
    # is checked after normal services and reservation provenance reconciliation.
    m.Zaliha.objects.filter(pk=stock.pk).update(u_frizideru=stock.u_frizideru+delta, ukupno=stock.u_frizideru+delta)
    return audit


def _map_reservations(state, rows):
    """Explicitly link receipt remainder already assigned at the count, once."""
    used = set()
    for row in rows:
        target_id = row.get('count_reservation_id')
        if not target_id:
            continue
        require(row['kind'] == 'receipt' and row.get('receipt_mode') != 'EXISTING',
                'Veza današnje rezervacije pripada samo novom stvarnom prijemu.')
        target_id = int(target_id)
        require(target_id not in used and target_id in state['original_reservations'],
                'Ista postojeća rezervacija ne smije se povezati dvaput.')
        used.add(target_id)
        target = m.PacijentRezervacija.objects.get(pk=target_id)
        claims = list(m.EvidencijaSaglasnostiZaprimanja.objects.filter(trebovanje_id=row['request_id'],
            fizicka_transakcija__retrospective_events__batch_id=state['draft_id']).distinct())
        # The association is one exact allocation, not a guessed replacement.
        require(len(claims) == 1, 'Raspodjela prijema nema jednoznačnu vezu s rezervacijom.')
        claim = claims[0]; created = claim.rezervacija
        request = m.Trebovanje.objects.get(pk=row['request_id'])
        require(created is not None and created.pk not in state['original_reservations'] and created.pk != target.pk,
                'Prijem se ne smije spojiti s današnjom rezervacijom prije provjere historijske potrošnje.')
        require(target.aktivno and target.kolicina > 0 and target.datum_rezervacije == END
                and target.pacijent_id == row['patient_id'] and target.lijek_id == row['medicine_id']
                and target.komisija_id == request.komisija_id and not target.izvori_prijema.exists(),
                'Odaberite rezervaciju istog pacijenta, proizvoda i odobrenja od 30.09. koja još nema dokazan prijem.')
        require(created.kolicina == target.kolicina and created.aktivno,
                f'Preostala raspodjela prijema iznosi {created.kolicina:g}, a odabrana današnja rezervacija {target.kolicina:g}. Veza nije jednoznačna.')
        before = serial(m.PacijentRezervacija.objects.filter(pk=created.pk).values().get())
        # Preserve both reservation records. The new receipt now proves the
        # old current allocation; only its temporary duplicate is deactivated.
        created.kolicina = 0; created.aktivno = False
        created.save(update_fields=['kolicina', 'aktivno'])
        claim.rezervacija = target; claim.save(update_fields=['rezervacija'])
        state['mappings'].append(dict(claim_id=claim.pk, created_id=created.pk, target_id=target.pk,
            quantity=str(target.kolicina), before=before, target=state['original_reservations'][target.pk]))


def execute(draft, user, backup, normal):
    from . import retrospective_batches as batches
    from .fridge_history import fridge_balances_at
    from .retrospective_reconciliation import shortfall
    rows = batches.normalize_rows(draft)
    state = _proof(draft, rows); state['draft_id'] = draft.pk
    original_shortfall = shortfall(m.Zaliha.objects.get(lijek=state['count'].lijek))
    token = _context.set(state)
    try:
        audit = _offset(state, draft, user, backup) if state['net'] < 0 else None
        plan = normal(draft, user, backup)
        _map_reservations(state, rows)
        if audit is None:
            audit = _offset(state, draft, user, backup)
        stock = m.Zaliha.objects.get(lijek=state['count'].lijek)
        require(stock.u_frizideru == state['current'] and shortfall(stock) <= original_shortfall,
                'Rekonstrukcija ne smije promijeniti već prebrojanu današnju količinu niti stvoriti dodatni manjak rezervacija. Provjerite veze preostalih raspodjela s rezervacijama od 30.09.')
        for pk, original in state['original_reservations'].items():
            if date.fromisoformat(original['datum_rezervacije']) == END:
                require(serial(m.PacijentRezervacija.objects.filter(pk=pk).values().get()) == original,
                        f'Rezervacija #{pk} od 30.09. bi se promijenila. Ranija primjena je ne smije potrošiti.')
        closing = fridge_balances_at(END).get(stock.lijek_id, {})
        require(closing.get('quantity') == state['count'].nova_kolicina,
                'Završna historija ne odgovara popisu od 30.09. Ništa nije sačuvano.')
        patients = {r['patient_id'] for r in rows}
        plan['checkpoint'] = serial(dict(count_id=state['count'].pk, count_date=END, opening=state['opening'],
            counted=state['count'].nova_kolicina, original_delta=state['count'].razlika, net_events=state['net'],
            current_before=state['current'], current_after=stock.u_frizideru, audit_id=audit.pk,
            mappings=state['mappings'], evidence=draft.reconstruction['evidence'],
            patients=[dict(patient_id=pk, patient=str(m.Pacijent.objects.get(pk=pk)),
                state=batches.quantities(m.Pacijent.objects.get(pk=pk),stock.lijek)) for pk in sorted(patients)]))
        plan['after'] = {str(stock.lijek_id):batches.quantities(draft.patient, stock.lijek)}
        for row in plan['rows']:
            row['historical_end_of_day'] = serial(fridge_balances_at(date.fromisoformat(row['date'])).get(stock.lijek_id, {}).get('quantity'))
        audit.posljedice['mappings'] = state['mappings']; audit.save(update_fields=['posljedice'])
        return serial(plan)
    finally:
        _context.reset(token)


def reverse(draft, user, reason, backup, normal):
    checkpoint = draft.preview['checkpoint']
    count = m.PhysicalStockCorrection.objects.get(pk=checkpoint['count_id'])
    source = m.ZalihaTransakcija.objects.get(referenca_tip='PhysicalStockCorrection', referenca_id=count.pk)
    state = dict(count=count, source=source, net=Decimal(checkpoint['net_events']))
    stock_before = m.Zaliha.objects.get(lijek=count.lijek).u_frizideru
    for mapping in checkpoint['mappings']:
        target = serial(m.PacijentRezervacija.objects.filter(pk=mapping['target_id']).values().get())
        require(target == mapping['target'], 'Povezana rezervacija od 30.09. kasnije je izmijenjena. Poništavanje je zaustavljeno.')
        claim = m.EvidencijaSaglasnostiZaprimanja.objects.get(pk=mapping['claim_id'])
        created = m.PacijentRezervacija.objects.get(pk=mapping['created_id'])
        require(claim.rezervacija_id == mapping['target_id'] and created.kolicina == 0 and not created.aktivno,
                'Veza prijema i rezervacije je naknadno izmijenjena.')
        claim.rezervacija = created; claim.save(update_fields=['rezervacija'])
        created.kolicina = Decimal(mapping['before']['kolicina']); created.aktivno = True
        created.save(update_fields=['kolicina', 'aktivno'])
    if state['net'] >= 0:
        _offset(state, draft, user, backup, reverse=True, reason=reason)
    result = normal(draft, user, reason, backup)
    if state['net'] < 0:
        _offset(state, draft, user, backup, reverse=True, reason=reason)
    require(m.Zaliha.objects.get(lijek=count.lijek).u_frizideru == stock_before,
            'Poništavanje rekonstrukcije ne smije promijeniti današnju prebrojanu zalihu.')
    return result
