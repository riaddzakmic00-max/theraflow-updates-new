"""Explicit effects of one late administration, over the existing ledger.

The actual administration date and units are independent of today's debit.
Only an explicitly selected reservation/approval may be consumed. No scheduler
or FIFO allocation is called for a historical event.
"""
from decimal import Decimal
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone
from . import models as m
from .data_corrections import require, serial, captured_rows, differences

CHOICES = [
    ('both', 'Umanji zalihu i razduži pacijenta.'),
    ('patient', 'Samo razduži pacijenta — fizička zaliha je već usklađena.'),
    ('stock', 'Samo umanji zalihu — pacijent je već razdužen.'),
    ('neither', 'Evidentiraj terapiju bez promjene zalihe i zaduženja — oboje je već usklađeno.'),
]
EXPLANATIONS = [
    'Oboje: umanjuje današnji frižider i tačno odabranu pacijentovu rezervaciju.',
    'Samo pacijent: umanjuje odabranu rezervaciju; prebrojana fizička zaliha ostaje ista.',
    'Samo zaliha: umanjuje frižider; nijedna pacijentova rezervacija se ne dira.',
    'Bez promjene: dodaje stvarnu primjenu u historiju i izvještaj, bez ponovnog umanjenja salda.',
]
APPROVAL_CHOICES = [('consume','Ovu primjenu još treba odbiti od odobrenja'),
    ('already','Potrošnja ove primjene već je uračunata u odobrenje'),
    ('unresolved','Veza s odobrenjem nije razjašnjena — ostavi označeno za provjeru')]


def normalize(raw):
    choice=raw.get('accounting_choice','')
    require(choice in dict(CHOICES), 'Odaberite šta treba uskladiti ovom evidencijom; odgovor nije unaprijed odabran.')
    skip=str(raw.get('skip_reason','')).strip()
    require(len(skip)<=1000 and (choice=='both' or len(skip)>=5),
        'Navedite obavezan razlog i izvor provjere kada preskačete umanjenje zalihe ili zaduženja.')
    action=raw.get('approval_action','')
    require(action in dict(APPROVAL_CHOICES),'Odaberite šta ova primjena mijenja na komisijskom odobrenju.')
    reason=str(raw.get('link_reason','')).strip()
    require(5<=len(reason)<=1000,'Navedite izvor provjere veze s rezervacijom i odobrenjem, odnosno šta još nije razjašnjeno.')
    cleaned=dict(accounting_choice=choice,skip_reason=skip,approval_action=action,link_reason=reason)
    for key in ('reservation_id','commission_id','source_id'):
        value=raw.get(key)
        require(not value or str(value).isdigit(), 'Provjerite odabranu vezu: '+key)
        cleaned[key]=int(value) if value else None
    return cleaned


def plan(data):
    from .retrospective_events import day
    from .inventory import inventory_position_for_patient
    from .stock_lots import lot_balances
    q=Decimal(data['quantity']); when=day(data['event_date'])
    patient=m.Pacijent.objects.get(pk=data['patient_id']);medicine=m.Lijek.objects.get(pk=data['medicine_id'])
    require(not medicine.oralna_terapija or data.get('actual_route') == m.Lijek.PUT_PO,
        'Oralno izdavanje nije dokaz stvarne ambulantne primjene; koristite njegov postojeći postupak.')
    stock=m.Zaliha.objects.filter(lijek=medicine).first();physical=stock.u_frizideru if stock else Decimal(0)
    reserved=m.PacijentRezervacija.objects.filter(pacijent=patient,lijek=medicine,aktivno=True).aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
    debit_stock=data['accounting_choice'] in ('both','stock')
    debit_patient=data['accounting_choice'] in ('both','patient')
    reservation=source=commission=None
    warnings=[]
    if debit_patient:
        reservation=m.PacijentRezervacija.objects.select_related('termin','trebovanje').filter(pk=data['reservation_id']).first()
        require(reservation is not None,'Odaberite konkretnu rezervaciju koju ova ranija primjena treba razdužiti.')
        require(reservation.pacijent_id==patient.pk and reservation.lijek_id==medicine.pk and reservation.aktivno
            and reservation.kolicina>=q,f'Odabrano zaduženje/rezervacija #{reservation.pk} ima {reservation.kolicina:g}; traženo {q:g}; nema dovoljnu količinu ili ne pripada pacijentu i proizvodu. Otvorite Ispravi zaduženje u ovom centru, zatim se vratite na unos.')
        require(not reservation.termin_id or reservation.termin.datum==when,
            'Odabrana rezervacija pripada drugom, moguće budućem terminu. Ne smije se potrošiti za ovu raniju primjenu.')
        from .late_event_sources import historical_reservations
        require(historical_reservations(patient, medicine, when).filter(pk=reservation.pk).exists(),
            'Nema odgovarajućeg historijskog zaduženja za ovaj datum i prezentaciju. Odaberite potrošnju iz slobodne fizičke zalihe ili evidenciju bez promjene današnjeg stanja; buduća rezervacija ostaje sačuvana.')
    else:
        require(not data['reservation_id'],'Ne birajte rezervaciju kada je odabrano da se pacijent ne razdužuje.')
    action=data['approval_action']
    if action!='unresolved':
        commission=m.Komisija.objects.filter(pk=data['commission_id']).first()
        require(commission is not None,'Odaberite konkretno postojeće komisijsko odobrenje.')
        require(commission.pacijent_id==patient.pk and commission.lijek_id in medicine.physical_equivalent_ids()
            and commission.datum_odobrenja<=when and commission.status not in ('PONISTENA','ZAMIJENJENA'),
            'Odobrenje ne pripada pacijentu, lijeku ili stvarnom datumu primjene.')
        if reservation and reservation.komisija_id:
            require(reservation.komisija_id==commission.pk,'Rezervacija i odabrano odobrenje nisu povezani. Razjasnite tačnu vezu.')
        if action=='consume':
            require(commission.preostale_doze>=q,'Nema dovoljno preostalog odobrenja za ovo umanjenje.')
        else:
            # Only previously consumed but not already attributed units can be claimed.
            recorded=Decimal(0)
            for t in m.Terapija.objects.filter(pacijent=patient,workflow_status='POTVRDJENA'):
                snap=t.workflow_snapshot or {}
                for change in snap.get('komisijske_promjene',[]):
                    if change['komisija_id']==commission.pk:recorded+=Decimal(change['kolicina'])
                if snap.get('retrospective_accounting') and snap.get('commission_id')==commission.pk:
                    canonical = any(change.get('komisija_id') == commission.pk
                        for change in snap.get('komisijske_promjene', []))
                    if snap.get('approval_action') == 'already' or snap.get('approval_action') == 'consume' and not canonical:
                        recorded+=t.kolicina
            available=commission.broj_odobrenih_doza-commission.preostale_doze-recorded
            require(available>=q,'Odobrenje nema dovoljno ranije potrošene, još nepovezane količine. Ne označavajte potrošnju kao već uračunatu; provjerite vezu.')
    else:
        require(not data['commission_id'],'Za nerazjašnjenu vezu ne birajte proizvoljno odobrenje.')
        warnings.append('Potrošnja odobrenja nije promijenjena i čeka provjeru. Zaliha i rezervacija slijede odabranu opciju.')
    if data['source_id']:
        from .inventory_corrections import receipt_date
        source=m.ZalihaTransakcija.objects.filter(pk=data['source_id'],lijek=medicine,tip='ZAPRIMANJE').first()
        require(source is not None and receipt_date(source)<=when and source.pacijent_id in (None,patient.pk),
            'Odabrani prijem ne odgovara lijeku, pacijentu ili datumu primjene.')
        require(not source.rok_trajanja or source.rok_trajanja>=when,'Serija iz odabranog prijema bila je istekla na datum primjene.')
        require(not data['batch'] or data['batch']==source.serija,'Serija primjene ne odgovara odabranom prijemu.')
        require(not data['expires'] or data['expires']==str(source.rok_trajanja or ''),'Rok ne odgovara odabranom prijemu.')
        if reservation and reservation.trebovanje_id and source.referenca_tip=='Trebovanje':
            require(source.referenca_id==reservation.trebovanje_id,'Prijem ne pripada odabranoj rezervaciji.')
    else:
        warnings.append('Konkretan prijem nije povezan. Nepoznata serija i izvor ostaju prazni; razlog provjere je sačuvan.')
    if debit_stock:
        require(stock is not None and physical>=q,f'Nema dovoljno fizičke zalihe za odabrano umanjenje: lijek #{medicine.pk}, fizički {physical:g}, potrebno {q:g}. Provjerite stvarni prijem ili fizičko brojanje u ovom centru; ne stvarajte izmišljeni prijem.')
        from .late_event_sources import compatible_source_ids
        pool_ids = compatible_source_ids(medicine) if data.get('actual_route') else [medicine.pk]
        physical_pool = m.Zaliha.objects.filter(lijek_id__in=pool_ids).aggregate(n=Sum('u_frizideru'))['n'] or Decimal(0)
        all_reserved=m.PacijentRezervacija.objects.filter(lijek_id__in=pool_ids,aktivno=True).aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
        from .inventory_corrections import restricted_allocation_quantity
        require(physical_pool-q>=all_reserved + restricted_allocation_quantity(pool_ids)-(q if debit_patient else 0),
            'Umanjenje bi uzelo fizičko pokriće drugih ili budućih rezervacija. Razjasnite konkretno zaduženje; rezervacije se ne biraju automatski.')
        batch=data['batch'] or (source.serija if source else '')
        expires=day(data['expires'],optional=True) or (source.rok_trajanja if source else None)
        lots=lot_balances(medicine)
        require(lots.get((batch,expires),Decimal(0))>=q,
            'Nema dovoljno raspoložive količine iz navedene serije/izvora. Odaberite dokumentovanu seriju i rok; nepoznat izvor se ne izmišlja.')
    physical_after=physical-(q if debit_stock else 0);reserved_after=reserved-(q if debit_patient else 0)
    right=commission.preostale_doze if commission else None
    from .correction_center import state, rows as center_rows
    from copy import deepcopy
    from .inventory import _physical_medicine_ids
    from .inventory_corrections import restricted_allocation_quantity
    before_state=state(patient,medicine);after_state=deepcopy(before_state)
    for key,delta in (('physical',-q if debit_stock else 0),('reserved',-q if debit_patient else 0),('patient',-q if debit_patient else 0)):
        after_state[key]=str(Decimal(str(before_state[key]))+delta)
    after_state['free']=str(max(Decimal(0),Decimal(after_state['physical'])-Decimal(after_state['reserved'])-restricted_allocation_quantity(_physical_medicine_ids(medicine))))
    after_state['therapies']+=1
    if commission and action=='consume':
        for item in after_state['approvals']:
            if item['id']==commission.pk:
                item['remaining']=str(Decimal(str(item['remaining']))-q)
                if Decimal(item['remaining'])==0:item['status']='POTROSENA'
    from .late_event_sources import protected_future_rows
    return serial(dict(stock_id=stock.pk if stock else None,physical=physical,physical_after=physical_after,
        reserved=reserved,reserved_after=reserved_after,reservation_id=reservation.pk if reservation else None,
        commission_id=commission.pk if commission else None,source_id=source.pk if source else None,
        stock_delta=-q if debit_stock else 0,reservation_delta=-q if debit_patient else 0,
        approval_delta=-q if action=='consume' else 0,
        batch=data['batch'] or (source.serija if source else ''),
        expires=data['expires'] or (str(source.rok_trajanja or '') if source else ''),
        rows=center_rows(before_state,after_state)+[dict(label='Ukupna fizička zaliha lijeka',before=physical,after=physical_after),
            dict(label='Pacijentova količina u frižideru — rezervacije',before=reserved,after=reserved_after),
            dict(label='Odabrana rezervacija / zaduženje',before=reservation.kolicina if reservation else 'Ne mijenja se',
                after=reservation.kolicina-q if reservation else 'Ne mijenja se'),
            dict(label='Preostalo na odobrenju #'+str(commission.pk) if commission else 'Odobrenje — veza čeka provjeru',
                before=right if right is not None else 'Nije razjašnjeno',
                after=right-(q if action=='consume' else 0) if right is not None else 'Nije razjašnjeno')],
        protected_reservations=protected_future_rows(patient, when),
        warnings=warnings,choice_label=dict(CHOICES)[data['accounting_choice']]))


@transaction.atomic
def apply(plan_data,user,operation_id,backup):
    from . import retrospective_pending as pending
    from .utils import upisi_log
    data=pending.normalize(plan_data['data']);pending.guard_duplicate(data);effect=plan(data)
    require(effect==plan_data['accounting'],'Učinak se promijenio. Ponovite pregled.')
    before=captured_rows();q=Decimal(data['quantity']);stock_delta=Decimal(effect['stock_delta'])
    snapshot=dict(retrospective_pending=True,retrospective_accounting=1,operation_id=str(operation_id),
        accounting_status='PENDING' if data['approval_action']=='unresolved' else 'RECONCILED',
        inventory_effect=str(stock_delta),**{k:data[k] for k in ('accounting_choice','skip_reason','approval_action','link_reason')},
        commission_id=effect['commission_id'],reservation_id=effect['reservation_id'])
    snapshot['komisijske_promjene'] = []
    snapshot['rezervacijske_promjene'] = ([dict(rezervacija_id=effect['reservation_id'], kolicina=str(q))]
        if effect['reservation_id'] else [])
    if data.get('actual_route'):
        snapshot['put_primjene'] = data['actual_route']
    therapy=m.Terapija.objects.create(pacijent_id=data['patient_id'],lijek_id=data['medicine_id'],
        datum=data['event_date'],kolicina=q,doza_mg=data.get('dose_mg'),serija=effect['batch'],evidentirao=user,workflow_snapshot=snapshot)
    reservation=None
    if effect['reservation_id']:
        reservation=m.PacijentRezervacija.objects.select_for_update().get(pk=effect['reservation_id'])
        reservation.kolicina-=q
        if reservation.kolicina==0:reservation.aktivno=False;reservation.potrosena_at=timezone.now()
        reservation.save(update_fields=['kolicina','aktivno','potrosena_at'])
    if data['approval_action']=='consume':
        commission=m.Komisija.objects.select_for_update().get(pk=effect['commission_id'])
        snapshot['komisijske_promjene'] = [dict(komisija_id=commission.pk, lijek_id=commission.lijek_id,
            kolicina=str(q), status_prije=commission.status, preostale_prije=str(commission.preostale_doze),
            preostale_poslije=str(commission.preostale_doze-q))]
        commission.preostale_doze-=q
        if commission.preostale_doze==0:commission.status='POTROSENA'
        commission.save(update_fields=['preostale_doze','status'])
    if stock_delta:
        stock=m.Zaliha.objects.select_for_update().get(pk=effect['stock_id'])
        stock.u_frizideru+=stock_delta;stock.ukupno=stock.u_frizideru+stock.kod_pacijenata
        stock.save(update_fields=['u_frizideru','ukupno'])
    # Always one dated factual outflow. promjena_salda records its separate
    # present-day stock effect (including zero), and reports use therapy.datum.
    movement=m.ZalihaTransakcija.objects.create(lijek_id=data['medicine_id'],pacijent_id=data['patient_id'],
        tip='AMBULANTNA_POTROSNJA',kolicina=q,promjena_salda=-stock_delta,datum=timezone.localdate(),
        referenca_tip='Terapija',referenca_id=therapy.pk,korisnik=user,operation_id=operation_id,
        komisija_id=effect['commission_id'],rezervacija=reservation,promjena_rezervacije=effect['reservation_delta'],
        izvorna_transakcija_id=effect['source_id'],serija=effect['batch'],rok_trajanja=effect['expires'] or None,
        lokacija='FRIZIDER',jedinica_snapshot=therapy.lijek.jedinice_zalihe[0],
        napomena=f'Stvarna primjena {data["event_date"]}. {effect["choice_label"]} {data["skip_reason"]} {data["link_reason"]}')
    from .commission_planning import recalculate_patient_commission_drafts
    recalculate_patient_commission_drafts(therapy.pacijent,user=user,reason='Izričito usklađivanje naknadne primjene.')
    from .retrospective_reversal import appointment_evidence, therapy_reversal_evidence
    therapy.workflow_snapshot['reversal_appointments'] = appointment_evidence(therapy.pacijent_id)
    therapy.workflow_snapshot['reversal_evidence'] = therapy_reversal_evidence(therapy)
    therapy.save(update_fields=['workflow_snapshot'])
    from .inventory import inventory_position_for_patient
    current=m.Zaliha.objects.filter(lijek_id=data['medicine_id']).first()
    require((current.u_frizideru if current else 0)==Decimal(effect['physical_after']) and
        (m.PacijentRezervacija.objects.filter(pacijent=therapy.pacijent,lijek=therapy.lijek,aktivno=True).aggregate(n=Sum('kolicina'))['n'] or 0)==Decimal(effect['reserved_after']),
        'Provjera stanja nakon upisa nije prošla. Cijela transakcija je poništena.')
    old,new=differences(before,captured_rows())
    event=m.RetrospectiveEvent.objects.create(operation_id=operation_id,kind='therapy',patient_id=data['patient_id'],
        medicine_id=data['medicine_id'],event_date=data['event_date'],quantity=q,note=data['note'],user=user,
        therapy=therapy,backup=backup,effects=serial(dict(entry_mode=data['entry_mode'],accounting_version=1,
            reconciliation_status=snapshot['accounting_status'],preview=plan_data,before=old,after=new,
            current_stock_delta=stock_delta,reservation_delta=effect['reservation_delta'])))
    event.movements.add(movement)
    upisi_log(user,'Naknadna primjena — odabrano usklađivanje',pacijent=event.patient,objekat=event,
        opis=f'{movement.napomena} Lijek/prezentacija: {event.medicine} (ID {event.medicine_id}); '
             f'put {data.get("actual_route", "nije naveden")}; {q} jedinica; '
             f'fizička zaliha {effect["physical"]} → {effect["physical_after"]}; '
             f'zaduženje {effect["reserved"]} → {effect["reserved_after"]}; '
             f'promjena komisijskog prava {effect["approval_delta"]}.')
    return event


def reversal_preview(event,user,reason):
    from .retrospective_events import authorize
    authorize(user);require(not event.reversed_at,'Događaj je već poništen.')
    require(5<=len(reason.strip())<=500,'Unesite razlog poništavanja (5–500 znakova).')
    now=captured_rows()
    for table,records in event.effects['after'].items():
        for pk,values in records.items():
            require(now.get(table,{}).get(pk)==values,'Zapis je naknadno izmijenjen. Pregledajte povezanu historiju prije poništavanja.')
    e=event.effects['preview']['accounting']
    return dict(event_id=event.pk,title='Poništi naknadnu primjenu i samo njena knjiženja',reason=reason.strip(),
        rows=[dict(label='Ukupna fizička zaliha',before=e['physical_after'],after=e['physical']),
              dict(label='Pacijentova rezervacija',before=e['reserved_after'],after=e['reserved'])],
        warnings=['Original ostaje u historiji. Vraćaju se samo količine koje je ovaj unos zaista umanjio.'])


@transaction.atomic
def reverse(event,user,preview,backup):
    from .utils import upisi_log
    reversal_preview(event,user,preview['reason']);before=captured_rows()
    e=event.effects['preview']['accounting'];q=event.quantity
    movements = event.movements.filter(tip=m.ZalihaTransakcija.TIP_AMBULANTNA_POTROSNJA,
        referenca_tip='Terapija', referenca_id=event.therapy_id)
    require(movements.count() == 1, 'Nedostaje jednoznačan izvorni promet ove primjene. Pregledajte povezanu historiju.')
    original = movements.get()
    for model,fields in ((m.Zaliha,['u_frizideru','ukupno']),
            (m.PacijentRezervacija,['kolicina','aktivno','potrosena_at']),
            (m.Komisija,['preostale_doze','status'])):
        for pk,row in event.effects['before'].get(model._meta.db_table,{}).items():
            if row:model.objects.filter(pk=pk).update(**{k:row[k] for k in fields})
    therapy=event.therapy;therapy.workflow_status='PONISTENA';therapy.ponistena_at=timezone.now()
    therapy.ponistio=user;therapy.razlog_ponistavanja=preview['reason']
    therapy.save(update_fields=['workflow_status','ponistena_at','ponistio','razlog_ponistavanja'])
    m.ZalihaTransakcija.objects.create(lijek=event.medicine,pacijent=event.patient,tip='POVRAT',kolicina=q,
        promjena_salda=-Decimal(e['stock_delta']),datum=timezone.localdate(),referenca_tip='Poništena terapija',
        referenca_id=therapy.pk,korisnik=user,lokacija='FRIZIDER',napomena=preview['reason'],
        komisija=original.komisija, rezervacija=original.rezervacija,
        promjena_rezervacije=-Decimal(e['reservation_delta']), jedinica_snapshot=original.jedinica_snapshot)
    from .commission_planning import recalculate_patient_commission_drafts
    recalculate_patient_commission_drafts(event.patient,user=user,reason='Poništeno usklađivanje naknadne primjene.')
    old,new=differences(before,captured_rows());event.reversed_at=timezone.now();event.reversed_by=user
    event.reversal_reason=preview['reason'];event.reversal_effects=serial(dict(preview=preview,before=old,after=new,backup=backup))
    event.save(update_fields=['reversed_at','reversed_by','reversal_reason','reversal_effects'])
    upisi_log(user,'Poništena naknadna primjena i njena knjiženja',pacijent=event.patient,objekat=event,opis=preview['reason'])
    return event
