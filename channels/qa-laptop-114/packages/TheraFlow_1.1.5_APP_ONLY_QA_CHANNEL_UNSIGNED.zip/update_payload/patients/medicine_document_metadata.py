"""Administrative presentation metadata, independent of dose/stock calculations."""

from django.core.exceptions import ValidationError


METADATA_FIELDS = {
    "atc_code": "ATC",
    "pharmaceutical_form": "Oblik",
    "strength": "Jačina",
}


class MedicineMetadataError(ValidationError):
    @property
    def user_message(self):
        return " ".join(self.messages)


def validate_metadata(name, values, *, required_fields=METADATA_FIELDS):
    values = {field: " ".join(str(values.get(field, "") or "").split()) for field in METADATA_FIELDS}
    missing = [label for field, label in METADATA_FIELDS.items()
               if field in required_fields and not values[field]]
    if missing:
        raise MedicineMetadataError(
            f"Za lijek „{name}“ nedostaju podaci: {', '.join(missing)}. "
            "Dopunite prezentaciju lijeka u administraciji (Lijekovi) prije generisanja zahtjeva."
        )
    return {"atc_code": values["atc_code"], "form": values["pharmaceutical_form"],
            "strength": values["strength"]}


def presentation_metadata(medicine, *, required_fields=METADATA_FIELDS):
    return validate_metadata(
        getattr(medicine, "naziv", None) or "Neodređen lijek",
        {field: getattr(medicine, field, "") for field in METADATA_FIELDS},
        required_fields=required_fields,
    )


def is_active_document(request):
    """Only unsent requests/cycles may take current registry values."""
    if request.status not in {"nacrt", "potvrdjen", "U_PRIPREMI", "NACRT", "SPREMAN"}:
        return False
    cycle = getattr(request, "komisijski_ciklus", None)
    return not cycle or cycle.status in {"nacrt", "spremno_za_stampu", "odstampano", "SIMULACIJA"}
