"""Explicit per-patient review; no application unless --confirm is supplied."""
import json
from pathlib import Path
from django.contrib.auth import get_user_model
from django.core.signing import BadSignature
from django.core.management.base import BaseCommand, CommandError
from patients.models import Pacijent
from patients.protocol_link_repair import make_preview, confirm
from patients.data_corrections import serial


class Command(BaseCommand):
    help = "Pregled neusklađenih veza protokola za jedan karton; primjena samo potvrđenog pregleda."

    def add_arguments(self, parser):
        parser.add_argument('--patient', type=int)
        parser.add_argument('--user', type=int, required=True)
        parser.add_argument('--reason', default='')
        parser.add_argument('--review-file', required=True)
        parser.add_argument('--confirm', action='store_true')

    def handle(self, *args, **options):
        try:
            user = get_user_model().objects.get(pk=options['user'])
            file = Path(options['review_file'])
            if options['confirm']:
                review = json.loads(file.read_text(encoding='utf-8'))
                receipt, created = confirm(review['token'], user, confirmed=True)
                self.stdout.write(json.dumps(dict(audit_id=receipt.pk, created=created)))
            else:
                if not options['patient']:
                    raise CommandError('Za pregled odaberite jedan --patient ID.')
                patient = Pacijent.objects.get(pk=options['patient'])
                plan, token = make_preview(patient, options['reason'], user)
                file.write_text(json.dumps(dict(plan=serial(plan), token=token), ensure_ascii=False, indent=2), encoding='utf-8')
                self.stdout.write(json.dumps(serial(plan), ensure_ascii=False, indent=2))
        except (ValueError, KeyError, BadSignature) as exc:
            raise CommandError(str(exc)) from exc

