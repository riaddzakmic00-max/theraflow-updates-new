"""Explicit local synthetic database reset, with a readable full DB backup."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
from datetime import date, datetime

from django.core.management.base import BaseCommand, CommandError
from django.db import connection
from patients.synthetic_diagnostics import safe_target, seed


class Command(BaseCommand):
    help = 'Kreiraj pet TEST dijagnostičkih kartona samo u lokalnoj sintetičkoj bazi; običan ponovni poziv ne mijenja podatke.'

    def add_arguments(self, parser):
        parser.add_argument('--database-name', required=True)
        parser.add_argument('--replace', action='store_true', help='Eksplicitno zamijeni sve operativne podatke u sintetičkoj bazi.')
        parser.add_argument('--backup-dir', type=Path, help='Obavezno za --replace; puna kopija prije atomske zamjene.')
        parser.add_argument('--pg-bin', type=Path, default=Path('C:/Program Files/PostgreSQL/18/bin'))
        parser.add_argument('--received-on', type=date.fromisoformat)
        parser.add_argument('--report', type=Path)

    def handle(self, *args, **options):
        try:
            target = safe_target(options['database_name'])
            backup_proof = None
            if options['replace']:
                folder = options['backup_dir']
                if folder is None:
                    raise ValueError('--replace zahtijeva --backup-dir; postojeća kopija se ne prepisuje.')
                folder.mkdir(parents=True, exist_ok=True)
                stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
                backup = folder/f'before-five-cases-{stamp}.dump'
                db = connection.settings_dict
                env = dict(os.environ, PGPASSWORD=str(db.get('PASSWORD','')))
                subprocess.run([str(options['pg_bin']/'pg_dump.exe'), '-h',db['HOST'], '-p',str(db['PORT']),
                    '-U',db['USER'],'-Fc','--no-owner','--no-acl','-f',str(backup),db['NAME']],env=env,check=True)
                toc = subprocess.run([str(options['pg_bin']/'pg_restore.exe'),'--list',str(backup)],
                    capture_output=True, check=True)
                backup.with_suffix('.contents.txt').write_bytes(toc.stdout)
                backup_proof = {'path':str(backup.resolve()), 'bytes':backup.stat().st_size,
                    'sha256':hashlib.sha256(backup.read_bytes()).hexdigest(), 'toc_readable':True}
            result = seed(expected_name=target['name'], replace=options['replace'], received_on=options['received_on'])
            result['backup'] = backup_proof
            output = json.dumps(result,ensure_ascii=False,indent=2)
            if options['report']:
                options['report'].write_text(output,encoding='utf-8')
            self.stdout.write(output)
        except (ValueError, subprocess.CalledProcessError, OSError) as exc:
            raise CommandError(str(exc)) from exc
