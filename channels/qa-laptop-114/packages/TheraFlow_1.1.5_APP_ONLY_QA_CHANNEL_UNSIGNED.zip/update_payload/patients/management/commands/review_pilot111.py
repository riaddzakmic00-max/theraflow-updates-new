import json
from pathlib import Path
from django.core.management.base import BaseCommand
from dashboard.diagnostics.readonly import diagnostic_snapshot
from patients.pilot111_review import review_after_111, review_export


class Command(BaseCommand):
    help = 'Potrebna provjera nakon 1.1.1 — isključivo čitanje, bez popravke podataka.'

    def add_arguments(self, parser):
        parser.add_argument('--output')
        parser.add_argument('--diagnostics-file')

    def handle(self, *args, **options):
        with diagnostic_snapshot(seconds=60):
            report = review_after_111()
        if options['diagnostics_file']:
            report['external_evidence'] = review_export(json.loads(Path(options['diagnostics_file']).read_text(encoding='utf-8-sig')))
        content = json.dumps(report, ensure_ascii=False, indent=2)
        if options['output']:
            Path(options['output']).write_text(content, encoding='utf-8')
            self.stdout.write(f"Potrebna provjera nakon 1.1.1: {report['record_count']} zapisa, {report['patient_count']} pacijenata. Read-only.")
        else:
            self.stdout.write(content)
