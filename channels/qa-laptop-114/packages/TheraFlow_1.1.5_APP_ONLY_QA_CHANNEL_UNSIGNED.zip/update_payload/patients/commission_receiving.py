"""Canonical approval metadata and patient agreements used during receiving."""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from .models import (
    EvidencijaSaglasnostiZaprimanja,
    Komisija,
    KomisijskaSaglasnost,
    PacijentSaglasnost,
    Trebovanje,
)
from .receipt_approval import request_receipt_approval


RECEIVABLE_STATUSES = ('ODOBRENO', 'CEKA_ISPORUKU', 'DJELOMICNO_ODOBRENO')


def propose_receipt_distribution(cycle, quantities, *, planning_rows=None, agreement_numbers=None,
                                 expiry_by_medicine=None, lots_by_medicine=None):
    """Read-only adapter of canonical demand to the existing bulk receipt.

    No stock, rights, pending obligations or reservations are created here.
    Physical sources and home therapy are calculated by the shared planner;
    this adapter only budgets the counted shipment in whole procurement packs.
    """
    from collections import Counter
    from decimal import ROUND_CEILING
    from .commission_exclusions import visible_commission_requests
    from .commission_planning import commission_planning_rows
    from .inventory import patient_allocation_product_ids, free_stock_quantity
    from .models import PacijentRezervacija, PotrebaFizickogPokrica, Zaliha
    from .package_sizes import package_size_for, validate_package_multiple
    from dashboard.receipt_display import receipt_totals

    requests = list(visible_commission_requests(cycle.trebovanja.all())
        .select_related('pacijent', 'lijek', 'komisija').order_by('pk'))
    duplicates = Counter((r.pacijent_id, r.lijek_id) for r in requests
                         if r.status != Trebovanje.STATUS_OTKAZANO)
    if planning_rows is None:
        from .request_cache import begin_request_cache, end_request_cache, set_cached
        from .models import PostavkeSistema
        cache_token = begin_request_cache()
        try:
            # The shared planner normally initializes singleton settings on a
            # first visit. A receipt preview must not persist even that default.
            set_cached('commission_settings', 1,
                PostavkeSistema.objects.filter(pk=1).first() or PostavkeSistema(pk=1))
            planning_rows = commission_planning_rows()
        finally:
            end_request_cache(cache_token)
    planning = {r['pacijent'].pk: r for r in planning_rows}
    result = {'medicines': {}, 'rows': {}}
    for medicine_id, raw in sorted(quantities.items()):
        rows = [r for r in requests if r.lijek_id == medicine_id]
        if not rows:
            raise ValueError('Odabrani lijek ne pripada ovoj komisiji.')
        medicine = rows[0].lijek
        amount = Decimal(str(raw))
        if not amount.is_finite() or amount <= 0:
            raise ValueError('Unesite pozitivnu ukupnu pristiglu količinu.')
        validate_package_multiple(amount, medicine, label='Stiglo sada')
        if any(request.odobrene_doze is not None and not Decimal(str(request.odobrene_doze)).is_finite()
               for request in rows if request.status not in ('ODBIJENO', 'OTKAZANO')):
            raise ValueError('Odobrena količina zahtjeva nije pouzdana. Provjerite odluku prije prijema.')
        totals = receipt_totals(cycle, medicine, rows)
        if totals['history_incomplete']:
            raise ValueError('Nedostaje dio historije fizičkog prijema. Potrebna je provjera prije novog prijema.')
        if amount > totals['remaining_physical']:
            raise ValueError('Stiglo sada prelazi preostalu odobrenu količinu za ovaj lijek.')
        package = Decimal(package_size_for(medicine))
        expiry_raw = (expiry_by_medicine or {}).get(str(medicine_id), '')
        expiry = date.fromisoformat(expiry_raw) if expiry_raw else None
        supplied_lots = (lots_by_medicine or {}).get(str(medicine_id))
        lots = supplied_lots or [{'quantity': str(amount), 'expires': expiry_raw}]
        if sum((Decimal(lot['quantity']) for lot in lots), Decimal(0)) != amount:
            raise ValueError('Zbir količina serija ne odgovara fizičkom prijemu.')
        latest_expiry = (None if any(not lot.get('expires') for lot in lots) else
                         max(date.fromisoformat(lot['expires']) for lot in lots))
        events, fallback_requests = [], []
        physical = Zaliha.objects.filter(lijek=medicine).values_list('u_frizideru', flat=True).first() or Decimal(0)
        reserved = sum(PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True)
                       .values_list('kolicina', flat=True), Decimal(0))
        physical_ids = medicine.physical_equivalent_ids()
        physical_pool = list(Zaliha.objects.filter(lijek_id__in=physical_ids).values_list('u_frizideru', flat=True))
        reserved_pool = sum(PacijentRezervacija.objects.filter(lijek_id__in=physical_ids, aktivno=True)
                            .values_list('kolicina', flat=True), Decimal(0))
        inventory_conflict = any(quantity < 0 for quantity in physical_pool) or reserved_pool > sum(physical_pool, Decimal(0))
        pending = PotrebaFizickogPokrica.objects.filter(lijek_id__in=physical_ids,
            status=PotrebaFizickogPokrica.STATUS_CEKA, preostala_kolicina__gt=0).exists()
        for request in rows:
            agreement_number = (agreement_numbers or {}).get(str(request.pk))
            approval = request_receipt_approval(request, agreement_number=agreement_number)
            if agreement_number is None and approval.get('external_number_required', True):
                agreement_number = approval['approval_number'] or patient_agreement_suggestion(request.pacijent).number
                if agreement_number and not approval['approval_number']:
                    # Old explicitly approved rows can lack a document model.
                    # A neutral number supplies its label, never its quantity.
                    approval = request_receipt_approval(request, agreement_number=agreement_number)
            approved = Decimal(approval['approved'])
            # Patient rights and counted deliveries are different budgets.
            # The medicine group's real receipt ledger still limits incoming
            # stock; physical receipts alone do not count as an allocation.
            capacity = (Decimal(approval['remaining_allocation'])
                        if not approval['blocked'] and approval.get('remaining_allocation') is not None
                        else Decimal(approval['maximum']))
            row = planning.get(request.pacijent_id)
            warning, blocked = approval['warning'], approval['blocked']
            if blocked:
                pass
            elif request.status not in RECEIVABLE_STATUSES or not approved or capacity <= 0:
                warning, blocked = 'Zahtjev nije otvoren za novo zaduženje.', True
            elif duplicates[(request.pacijent_id, medicine_id)] > 1:
                warning, blocked = 'Više zahtjeva za isti proizvod i pacijenta: provjerite duplikate.', True
            elif not request.pacijent.aktivan or request.pacijent.na_aktivnoj_pauzi():
                warning, blocked = 'Pacijent je neaktivan ili na pauzi. Potrebna je provjera.', True
            elif medicine_id not in patient_allocation_product_ids(request.pacijent):
                warning, blocked = 'Odobreni proizvod ne odgovara terapiji pacijenta. Provjerite IV/SC fazu.', True
            elif pending:
                warning, blocked = 'Postoji ranija potreba koja čeka fizičko pokriće. Provjerite izvore u Zalihama prije novog zaduženja.', True
            elif inventory_conflict:
                warning, blocked = 'Aktivne rezervacije nemaju dovoljno fizičkog pokrića ili je fizička zaliha negativna. Provjerite Zalihu prije novog prijema.', True
            elif not agreement_number and approval.get('external_number_required', True):
                warning = 'Nedostaje broj saglasnosti. Provjerite broj i ponovo prikažite kome ide lijek.'
            elif row and medicine_id not in (row.get('potreban_proizvod') or row['lijek']).physical_equivalent_ids():
                # The patient can have independently approved future IV/SC
                # presentations. Another SKU's schedule is not this one's.
                row = None
            entry = {**approval, 'proposed': '0', 'maximum': str(capacity), 'warning': warning,
                     'blocked': blocked, 'first_need': '', 'needs': [],
                     'approval_basis': False, 'review_required': False}
            result['rows'][str(request.pk)] = entry
            if warning:
                continue
            needs = (row or {}).get('buduci_fizicki_nepokriveni_detalji') or ()
            for need in needs:
                missing = max(Decimal(0), Decimal(str(need['buduca_nepokrivena_potreba']))
                    - Decimal(str(need.get('pokriveno_slobodnom_zalihom') or 0)))
                if missing > 0:
                    entry['needs'].append([str(need['datum']), str(missing)])
            # Home and oral projections have their own canonical coverage dates.
            if not needs:
                day = (row or {}).get('prva_fizicki_nepokrivena_terapija')
                missing = Decimal(str((row or {}).get('buduca_nepokrivena_potreba') or 0))
                if day and missing > 0:
                    entry['needs'].append([str(day), str(missing)])
            usable_needs = [(date.fromisoformat(day), Decimal(quantity)) for day, quantity in entry['needs']
                            if not latest_expiry or day <= latest_expiry.isoformat()]
            if entry['needs'] and not usable_needs and latest_expiry:
                entry['warning'] = 'Nema nepokrivene potrebe prije roka ove serije. Provjerite ostatak; lijek se ne smije koristiti nakon roka.'
                continue
            home = (row or {}).get('home_projection')
            reliable = bool(row and not row.get('za_pregled') and not row.get('relativna_pocetna_projekcija')
                            and not (home and not home.date_plan_reliable))
            if reliable and usable_needs:
                events.extend((day, request.pk, missing) for day, missing in usable_needs)
            else:
                # Capacity is proven by the exact approval; no dose or therapy
                # date is fabricated to turn that document into a schedule.
                entry.update(approval_basis=True, review_required=True, warning='Provjeriti terapijski raspored')
                fallback_requests.append(request.pk)
        remaining = amount
        credits, uncovered = {}, [missing for _, _, missing in sorted(events)]
        ordered_events = sorted(events)
        # Same priority as canonical physical coverage: dated need, stable ID.
        for lot_index, lot in sorted(enumerate(lots), key=lambda pair: (pair[1].get('expires') or '9999-12-31', pair[0])):
            credits = {}
            lot_remaining = Decimal(lot['quantity'])
            lot_expiry = date.fromisoformat(lot['expires']) if lot.get('expires') else None
            for event_index, (day, request_id, _) in enumerate(ordered_events):
                if lot_expiry and day > lot_expiry:
                    continue
                entry = result['rows'][str(request_id)]
                missing = uncovered[event_index]
                credit = credits.get(request_id, Decimal(0))
                consumed_credit = min(credit, missing)
                missing -= consumed_credit
                credits[request_id] = credit - consumed_credit
                used = Decimal(entry['proposed'])
                required = (missing / package).to_integral_value(rounding=ROUND_CEILING) * package
                addition = min(lot_remaining, required, Decimal(entry['maximum']) - used)
                addition = (addition // package) * package
                uncovered[event_index] = max(Decimal(0), missing - addition)
                if addition > 0:
                    entry['proposed'] = str(used + addition)
                    entry['first_need'] = entry['first_need'] or str(day)
                    remaining -= addition
                    lot_remaining -= addition
                    credits[request_id] = max(Decimal(0), addition - missing)
                    if supplied_lots:
                        parts = entry.setdefault('lot_proposed', {})
                        parts[str(lot_index)] = str(Decimal(parts.get(str(lot_index), '0')) + addition)
        # Dated canonical needs keep priority. Undated approval capacity only
        # uses the remaining counted shipment, in complete procurement packs.
        fallback_coverage = {request_id: [[day, Decimal(quantity)] for day, quantity in
            result['rows'][str(request_id)]['needs']] for request_id in fallback_requests}
        for lot_index, lot in sorted(enumerate(lots), key=lambda pair: (pair[1].get('expires') or '9999-12-31', pair[0])):
            allocated_before = sum((Decimal(result['rows'][str(request.pk)].get('lot_proposed', {}).get(str(lot_index), '0'))
                                    for request in rows), Decimal(0)) if supplied_lots else amount - remaining
            lot_remaining = max(Decimal(0), Decimal(lot['quantity']) - allocated_before)
            for request_id in sorted(fallback_requests):
                entry = result['rows'][str(request_id)]
                used = Decimal(entry['proposed'])
                limit = Decimal(entry['maximum']) - used
                known_needs = fallback_coverage[request_id]
                if lot.get('expires') and known_needs:
                    dated = sum((quantity for day, quantity in known_needs if day <= lot['expires']), Decimal(0))
                    limit = min(limit, (dated / package).to_integral_value(rounding=ROUND_CEILING) * package)
                addition = (min(lot_remaining, limit) // package) * package
                if addition <= 0:
                    continue
                entry['proposed'] = str(used + addition)
                remaining -= addition
                lot_remaining -= addition
                coverage = addition
                for need in known_needs:
                    if lot.get('expires') and need[0] > lot['expires']:
                        continue
                    covered = min(coverage, need[1])
                    need[1] -= covered
                    coverage -= covered
                if supplied_lots:
                    parts = entry.setdefault('lot_proposed', {})
                    parts[str(lot_index)] = str(Decimal(parts.get(str(lot_index), '0')) + addition)
        if supplied_lots:
            for request in rows:
                entry = result['rows'][str(request.pk)]
                entry['series'] = [dict(lots[int(index)], quantity=quantity,
                    expiry_display=(date.fromisoformat(lots[int(index)]['expires']).strftime('%d/%m/%Y')
                                    if lots[int(index)].get('expires') else ''))
                                   for index, quantity in entry.get('lot_proposed', {}).items()]
        physical_rows = [result['rows'][str(request.pk)] for request in rows
                         if request.status not in ('ODBIJENO', 'OTKAZANO') and request.odobrene_doze]
        physical_warnings = list(dict.fromkeys(entry['warning'] for entry in physical_rows
                                               if entry.get('physical_blocked')))
        if inventory_conflict:
            physical_warnings.append('Aktivne rezervacije nemaju dovoljno fizičkog pokrića ili je fizička zaliha negativna.')
        blocked_physical_rows = [request for request in rows
            if result['rows'][str(request.pk)].get('physical_blocked')
            and request.status not in ('ODBIJENO', 'OTKAZANO') and request.odobrene_doze]
        physical_exception_required = bool(blocked_physical_rows) and not pending and not inventory_conflict and all(
            result['rows'][str(request.pk)].get('physical_exception_required') for request in blocked_physical_rows)
        identities = {}
        for entry in physical_rows:
            identities.setdefault(entry['approval_identity'], entry)
        concrete_expected = sum((Decimal(entry['approved']) for entry in identities.values()), Decimal(0))
        concrete_used = sum((Decimal(entry['used']) for entry in identities.values()), Decimal(0))
        maximum_physical = min(totals['remaining_physical'], max(Decimal(0),
            concrete_expected - max(totals['physical_before'], concrete_used)))
        result['medicines'][str(medicine_id)] = {
            'request_ids': [request.pk for request in rows],
            'arrived': str(amount), 'allocated': str(amount - remaining), 'remainder': str(remaining),
            'physical_before': str(physical), 'reserved_before': str(reserved),
            'free_before': str(free_stock_quantity(medicine)),
            'physical_blocked': bool(physical_warnings), 'physical_warning': ' '.join(physical_warnings),
            'physical_exception_required': physical_exception_required,
            'physical_exception_request_ids': [request.pk for request in blocked_physical_rows]
                if physical_exception_required else [],
            'physical_exception_maximum': str(totals['remaining_physical']) if physical_exception_required else '0',
            'maximum_physical': str(maximum_physical),
            'warning': 'Ranije potrebe za fizičkim pokrićem zahtijevaju provjeru u Zalihama.' if pending else '',
        }
    return result


def split_receipt_lot_allocations(lots, requests, quantities, proposal_rows, *, reviewed_request_ids=()):
    """Budget reviewed allocations against exact series, without posting stock."""
    from decimal import ROUND_CEILING
    from .package_sizes import package_size_for
    budgets = [Decimal(lot['quantity']) for lot in lots]
    reviewed_request_ids = {str(value) for value in reviewed_request_ids}
    result = {request.pk: [] for request in requests}
    ordered_lots = sorted(range(len(lots)), key=lambda index: (lots[index].get('expires') or '9999-12-31', index))
    ordered_requests = sorted(requests, key=lambda request: (
        proposal_rows.get(str(request.pk), {}).get('first_need') or '9999-12-31', request.pk))
    for request in ordered_requests:
        remaining = Decimal(str(quantities[request.pk]))
        entry = proposal_rows.get(str(request.pk), {})
        if remaining > 0 and entry.get('blocked'):
            raise ValueError(entry.get('warning') or 'Odobrenje nije pouzdano za raspodjelu.')
        if remaining > Decimal(entry.get('maximum', remaining)):
            raise ValueError('Raspodjela prelazi preostalu količinu ovog odobrenja.')
        if remaining > 0 and entry.get('review_required') and str(request.pk) not in reviewed_request_ids:
            raise ValueError('Provjeriti terapijski raspored: unesite razlog prije potvrde raspodjele.')
        needs = [[day, Decimal(str(quantity))] for day, quantity in entry.get('needs', [])]
        package = Decimal(package_size_for(request.lijek))
        preferred = entry.get('lot_proposed', {}) if remaining == Decimal(entry.get('proposed', '0')) else {}
        indexes = sorted(ordered_lots, key=lambda index: (str(index) not in preferred, ordered_lots.index(index)))
        for index in indexes:
            expiry = lots[index].get('expires')
            limit = Decimal(preferred[str(index)]) if str(index) in preferred else remaining
            if expiry and proposal_rows:
                if not needs:
                    if not (entry.get('approval_basis') and entry.get('review_required')
                            and str(request.pk) in reviewed_request_ids):
                        raise ValueError('Nema pouzdanog datiranog rasporeda za raspodjelu serije sa rokom. Provjerite protokol i termine prije zaduženja.')
                else:
                    dated_capacity = sum((quantity for day, quantity in needs if day <= expiry), Decimal(0))
                    # Review of an unknown schedule cannot bypass a known
                    # later therapy date or an expiry's dated hard limit.
                    limit = min(limit, (dated_capacity / package).to_integral_value(rounding=ROUND_CEILING) * package)
            allocated = min(remaining, budgets[index], limit)
            if allocated > 0:
                result[request.pk].append((index, allocated))
                budgets[index] -= allocated
                remaining -= allocated
                coverage = allocated
                for need in needs:
                    if expiry and need[0] > expiry:
                        continue
                    used = min(coverage, need[1])
                    need[1] -= used
                    coverage -= used
                    if coverage <= 0:
                        break
            if remaining <= 0:
                break
        if remaining > 0:
            known_need = sum((Decimal(str(quantity)) for _, quantity in entry.get('needs', [])), Decimal(0))
            known_limit = (known_need / package).to_integral_value(rounding=ROUND_CEILING) * package
            if entry.get('needs') and Decimal(str(quantities[request.pk])) > known_limit:
                raise ValueError('Dodjela prelazi provjerenu potrebu u planskom periodu. Provjerite terapijski raspored prije povećanja količine.')
            raise ValueError('Raspodjela nema dovoljnu količinu odgovarajuće serije prije roka. Ponovo pregledajte raspodjelu.')
    return result


def received_commission_quantity(request):
    """Physical capacity used, keeping the legacy allocated counter intact.

    Administrative links refer to stock already posted. Include only the part
    not already allocated to this request through that same receipt source.
    Corrections use the canonical receipt/allocation ledger calculations.
    Callers applying a receipt must hold the existing request/cycle locks.
    """
    from .models import UnlinkedStockReceipt
    from .inventory_corrections import receipt_quantity, allocation_quantity

    received = Decimal(request.zaprimljene_doze or 0)
    links = getattr(request, '_prefetched_objects_cache', {}).get('unlinkedstockreceipt_set')
    if links is None:
        links = UnlinkedStockReceipt.objects.filter(request_id=request.pk).select_related('movement')
    for link in links:
        allocated = sum((allocation_quantity(evidence) for evidence in
            EvidencijaSaglasnostiZaprimanja.objects.filter(
                trebovanje_id=request.pk, fizicka_transakcija_id=link.movement_id)), Decimal(0))
        received += max(Decimal(0), receipt_quantity(link.movement) - allocated)
    return received


@dataclass(frozen=True)
class ReceiptApprovalContext:
    approval_date: date | None
    approval_number: str
    source: str
    source_label: str


@dataclass(frozen=True)
class PatientAgreementSuggestion:
    number: str
    valid_from: date | None
    source: str
    persisted: PacijentSaglasnost | None = None

    @property
    def exists(self):
        return bool(self.number)


def normalize_agreement_number(value):
    return " ".join(str(value or "").strip().split())


def validate_agreement_number(value):
    number = normalize_agreement_number(value)
    if not number:
        raise ValueError("Unesite prvi broj saglasnosti.")
    if len(number) > 100:
        raise ValueError("Broj saglasnosti može sadržavati najviše 100 znakova.")
    if any(not (character.isalnum() or character in " /-.") for character in number):
        raise ValueError(
            "Broj saglasnosti može sadržavati slova, brojeve, razmake, "
            "kose crte, crtice i tačke."
        )
    return number


def validate_receipt_agreement_number(request, value):
    """An absent printed label is valid only with an exact shared document item."""
    number = normalize_agreement_number(value)
    approval = request_receipt_approval(request, agreement_number=number)
    if approval.get('shared_document') and approval['blocked']:
        raise ValueError(approval['warning'])
    if not number:
        if (not approval['blocked'] and approval.get('external_number_required', True) is False
                and approval.get('document_id') and approval.get('document_line_id')):
            return ''
    return validate_agreement_number(number)


def patient_agreement_suggestion(patient):
    """Return current patient agreement, falling back to legacy patient data."""

    current = (
        PacijentSaglasnost.objects.filter(
            pacijent=patient,
            trenutno_vazeca=True,
        )
        .order_by("-vazi_od", "-pk")
        .first()
    )
    if current:
        return PatientAgreementSuggestion(
            number=current.broj_saglasnosti,
            valid_from=current.vazi_od,
            source="PATIENT_AGREEMENT",
            persisted=current,
        )

    legacy_commission = (
        Komisija.objects.filter(pacijent=patient)
        .exclude(broj_saglasnosti__isnull=True)
        .exclude(broj_saglasnosti="")
        .order_by("-datum_odobrenja", "-pk")
        .first()
    )
    phase_three = (
        KomisijskaSaglasnost.objects.filter(
            komisijski_zahtjev__pacijent=patient,
            odluka__in=(
                KomisijskaSaglasnost.Odluka.ODOBRENO,
                KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
            ),
        )
        .exclude(broj_saglasnosti__isnull=True)
        .exclude(broj_saglasnosti="")
        .order_by("-datum_saglasnosti", "-pk")
        .first()
    )
    candidates = []
    if legacy_commission:
        candidates.append(
            (
                legacy_commission.datum_odobrenja,
                legacy_commission.pk,
                legacy_commission.broj_saglasnosti,
                "LEGACY_COMMISSION",
            )
        )
    if phase_three:
        candidates.append(
            (
                phase_three.datum_saglasnosti,
                phase_three.pk,
                phase_three.broj_saglasnosti,
                "PHASE_THREE",
            )
        )
    if not candidates:
        return PatientAgreementSuggestion("", None, "MISSING")
    valid_from, _, number, source = max(candidates, key=lambda item: item[:2])
    return PatientAgreementSuggestion(
        normalize_agreement_number(number),
        valid_from,
        source,
    )


def agreement_number_conflicts(number, *, patient):
    """Other patients currently or historically associated with this number."""

    normalized = normalize_agreement_number(number)
    if not normalized:
        return []
    patient_ids = set(
        PacijentSaglasnost.objects.filter(
            broj_saglasnosti__iexact=normalized,
        )
        .exclude(pacijent=patient)
        .values_list("pacijent_id", flat=True)
    )
    patient_ids.update(
        Komisija.objects.filter(broj_saglasnosti__iexact=normalized)
        .exclude(pacijent=patient)
        .values_list("pacijent_id", flat=True)
    )
    phase_three_ids = KomisijskaSaglasnost.objects.filter(
        broj_saglasnosti__iexact=normalized,
    ).exclude(
        komisijski_zahtjev__pacijent=patient,
    ).values_list("komisijski_zahtjev__pacijent_id", flat=True)
    patient_ids.update(phase_three_ids)
    from .models import Pacijent

    return list(Pacijent.objects.filter(pk__in=patient_ids).order_by(
        "prezime", "ime", "pk"
    ))


def agreement_number_owners():
    """Small client-side warning map; duplicate values are warnings, not locks."""

    owners = {}
    rows = PacijentSaglasnost.objects.filter(trenutno_vazeca=True).select_related(
        "pacijent"
    )
    for row in rows:
        key = normalize_agreement_number(row.broj_saglasnosti).casefold()
        owners.setdefault(key, []).append(
            {"id": row.pacijent_id, "name": str(row.pacijent)}
        )
    for row in Komisija.objects.exclude(broj_saglasnosti__isnull=True).exclude(
        broj_saglasnosti=""
    ).select_related("pacijent").order_by("-datum_odobrenja", "-pk"):
        key = normalize_agreement_number(row.broj_saglasnosti).casefold()
        owner = {"id": row.pacijent_id, "name": str(row.pacijent)}
        if owner not in owners.setdefault(key, []):
            owners[key].append(owner)
    phase_three_rows = KomisijskaSaglasnost.objects.exclude(
        broj_saglasnosti__isnull=True
    ).exclude(broj_saglasnosti="").select_related("komisijski_zahtjev__pacijent")
    for row in phase_three_rows:
        patient = row.komisijski_zahtjev.pacijent
        key = normalize_agreement_number(row.broj_saglasnosti).casefold()
        owner = {"id": patient.pk, "name": str(patient)}
        if owner not in owners.setdefault(key, []):
            owners[key].append(owner)
    return owners


@transaction.atomic
def update_patient_agreement(
    *,
    patient,
    number,
    user=None,
    source_commission=None,
):
    """Evidentiraj ili verzioniraj saglasnost direktno iz kartona pacijenta."""

    from .models import Pacijent
    patient = Pacijent.objects.select_for_update().get(pk=patient.pk)
    number = validate_agreement_number(number)
    if source_commission and source_commission.pacijent_id != patient.pk:
        raise ValueError("Odobrenje ne pripada ovom pacijentu.")
    suggestion = patient_agreement_suggestion(patient)
    current = (
        PacijentSaglasnost.objects.select_for_update()
        .filter(pacijent=patient, trenutno_vazeca=True)
        .order_by("-vazi_od", "-pk")
        .first()
    )
    if (
        current
        and normalize_agreement_number(current.broj_saglasnosti).casefold()
        == number.casefold()
        and current.izvorna_komisija_id == getattr(source_commission, "pk", None)
    ):
        return current, False

    today = timezone.localdate()
    old_number = suggestion.number
    if current:
        current.trenutno_vazeca = False
        current.vazi_do = today
        current.save(update_fields=["trenutno_vazeca", "vazi_do", "izmijenjeno"])
    elif suggestion.exists and suggestion.number.casefold() != number.casefold():
        legacy_source = (
            Komisija.objects.filter(
                pacijent=patient,
                broj_saglasnosti__iexact=suggestion.number,
            )
            .order_by("-datum_odobrenja", "-pk")
            .first()
        )
        PacijentSaglasnost.objects.create(
            pacijent=patient,
            broj_saglasnosti=suggestion.number,
            vazi_od=suggestion.valid_from or today,
            vazi_do=today,
            trenutno_vazeca=False,
            izvorna_komisija=legacy_source,
        )

    agreement = PacijentSaglasnost.objects.create(
        pacijent=patient,
        broj_saglasnosti=number,
        vazi_od=today,
        trenutno_vazeca=True,
        izmijenio=user if getattr(user, "is_authenticated", False) else None,
        izvorna_komisija=source_commission,
    )
    from .utils import upisi_log

    upisi_log(
        user,
        "Promjena broja saglasnosti pacijenta",
        pacijent=patient,
        objekat=agreement,
        opis=(
            f"Broj saglasnosti ažuriran sa {old_number} na {number}."
            if old_number else
            f"Evidentiran prvi broj saglasnosti {number}."
        ),
    )
    return agreement, True


@transaction.atomic
def use_patient_agreement_for_receipt(
    *, patient, number, request, quantity, user=None, return_evidence=False
):
    """Version a changed number and snapshot exactly what one receipt used."""

    from .models import Pacijent
    if patient.pk != request.pacijent_id:
        raise ValueError('Odobrenje ne pripada ovom pacijentu.')
    patient = Pacijent.objects.select_for_update().get(pk=patient.pk)
    number = validate_receipt_agreement_number(request, number)
    if not number:
        approval = request_receipt_approval(request, agreement_number='')
        # The unnamed document has its own concrete request provenance. It must
        # neither erase a previous printed number nor become a global number.
        agreement = PacijentSaglasnost.objects.select_for_update().filter(
            pacijent=patient, izvorno_trebovanje=request,
            izvorni_ciklus=request.komisijski_ciklus, izvorna_komisija_id=request.komisija_id,
            broj_saglasnosti='', trenutno_vazeca=False).order_by('pk').first()
        if agreement is None:
            agreement = PacijentSaglasnost.objects.create(
                pacijent=patient, broj_saglasnosti='', trenutno_vazeca=False,
                vazi_od=date.fromisoformat(approval['approval_date']),
                izmijenio=user if user and user.is_authenticated else None,
                izvorni_ciklus=request.komisijski_ciklus, izvorno_trebovanje=request,
                izvorna_komisija_id=request.komisija_id)
        evidence = EvidencijaSaglasnostiZaprimanja.objects.create(
            saglasnost=agreement, pacijent=patient, trebovanje=request,
            komisijski_ciklus=request.komisijski_ciklus, broj_saglasnosti_snapshot='',
            zaprimljena_kolicina=Decimal(str(quantity)),
            korisnik=user if user and user.is_authenticated else None)
        from .utils import upisi_log
        upisi_log(user, 'Prijem povezan sa zajedničkim dokumentom bez broja',
            pacijent=patient, objekat=evidence,
            opis=(f"Dokument ID {approval['document_id']}, stavka ID {approval['document_line_id']}; "
                  f"zahtjev {request.pk}, odobrenje {request.komisija_id}, količina {quantity}."))
        return (agreement, evidence) if return_evidence else agreement
    suggestion = patient_agreement_suggestion(patient)
    current = (
        PacijentSaglasnost.objects.select_for_update()
        .filter(pacijent=patient, trenutno_vazeca=True)
        .order_by("-vazi_od", "-pk")
        .first()
    )
    today = timezone.localdate()
    old_number = suggestion.number

    unchanged_current = (
        current
        and normalize_agreement_number(current.broj_saglasnosti).casefold()
        == number.casefold()
    )
    unchanged_legacy = (
        not current
        and suggestion.exists
        and suggestion.number.casefold() == number.casefold()
    )
    if unchanged_current:
        agreement = current
    elif unchanged_legacy:
        agreement = PacijentSaglasnost.objects.create(
            pacijent=patient,
            broj_saglasnosti=number,
            vazi_od=suggestion.valid_from or today,
            trenutno_vazeca=True,
            izmijenio=user if user and user.is_authenticated else None,
            izvorni_ciklus=request.komisijski_ciklus,
            izvorno_trebovanje=request,
        )
    else:
        if current:
            current.trenutno_vazeca = False
            current.vazi_do = today
            current.save(update_fields=["trenutno_vazeca", "vazi_do", "izmijenjeno"])
        elif suggestion.exists:
            # Preserve a legacy number before creating the first explicit
            # patient-centric version with a different number.
            PacijentSaglasnost.objects.create(
                pacijent=patient,
                broj_saglasnosti=suggestion.number,
                vazi_od=suggestion.valid_from or today,
                vazi_do=today,
                trenutno_vazeca=False,
            )

        agreement = PacijentSaglasnost.objects.create(
            pacijent=patient,
            broj_saglasnosti=number,
            vazi_od=(suggestion.valid_from or today) if not suggestion.exists else today,
            trenutno_vazeca=True,
            izmijenio=user if user and user.is_authenticated else None,
            izvorni_ciklus=request.komisijski_ciklus,
            izvorno_trebovanje=request,
        )

        from .utils import upisi_log

        if old_number:
            description = (
                f"Broj saglasnosti ažuriran sa {old_number} na {number} kroz "
                f"zaprimanje pošiljke {request.komisijski_ciklus}."
            )
        else:
            description = (
                f"Evidentiran prvi broj saglasnosti {number} kroz zaprimanje "
                f"pošiljke {request.komisijski_ciklus}."
            )
        upisi_log(
            user,
            "Promjena broja saglasnosti pacijenta",
            pacijent=patient,
            objekat=agreement,
            opis=description,
        )

    evidence = EvidencijaSaglasnostiZaprimanja.objects.create(
        saglasnost=agreement,
        pacijent=patient,
        trebovanje=request,
        komisijski_ciklus=request.komisijski_ciklus,
        broj_saglasnosti_snapshot=number,
        zaprimljena_kolicina=Decimal(str(quantity)),
        korisnik=user if user and user.is_authenticated else None,
    )
    return (agreement, evidence) if return_evidence else agreement


def resolve_receipt_approval_context(cycle, *, requests=None):
    """Resolve the shipment approval date; agreement numbers are per patient."""

    requests = list(
        requests
        if requests is not None
        else Trebovanje.objects.filter(komisijski_ciklus=cycle).select_related(
            "komisija"
        )
    )
    linked_approvals = sorted(
        (
            request.komisija
            for request in requests
            if request.komisija_id
            and request.komisija
            and request.komisija.datum_odobrenja
            and request.komisija.status != "PONISTENA"
        ),
        key=lambda approval: (approval.datum_odobrenja, approval.pk),
        reverse=True,
    )
    agreement = (
        KomisijskaSaglasnost.objects.filter(
            komisijski_zahtjev__komisijski_ciklus=cycle,
            odluka__in=(
                KomisijskaSaglasnost.Odluka.ODOBRENO,
                KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
            ),
        )
        .order_by("-datum_saglasnosti", "-pk")
        .first()
    )

    if cycle.datum_odobrenja:
        return ReceiptApprovalContext(
            approval_date=cycle.datum_odobrenja,
            approval_number="",
            source="CYCLE",
            source_label="Automatski preuzeto iz komisijskog ciklusa.",
        )
    if linked_approvals:
        return ReceiptApprovalContext(
            approval_date=linked_approvals[0].datum_odobrenja,
            approval_number="",
            source="PATIENT_APPROVAL",
            source_label="Automatski preuzeto iz odobrenog zahtjeva.",
        )
    if agreement:
        return ReceiptApprovalContext(
            approval_date=agreement.datum_saglasnosti,
            approval_number="",
            source="AGREEMENT",
            source_label="Automatski preuzeto iz komisijske saglasnosti.",
        )
    return ReceiptApprovalContext(
        approval_date=None,
        approval_number="",
        source="MISSING",
        source_label="Datum odobrenja nije pronađen u komisijskim podacima.",
    )
