"""A confirmed clinical IV event can anchor a doctor-confirmed SC plan.

Accounting status is deliberately not an eligibility condition. This changes
the existing protocol and appointments, never the administration or its debit.
"""
from datetime import date, time, timedelta
from decimal import Decimal
import uuid

from django.core import signing
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone

from . import models as m
from .correction_protocol import correction_transaction
from .data_corrections import require, serial, digest, captured_rows, backup_before_correction
from .medication_groups import medicine_group_key, medicine_presentation_key
from .phased_protocols import phased_protocol_for_patient, configure_ustekinumab_protocol, protocol_state_snapshot
from .therapy_history import actually_administered_therapy_query

SALT = 'theraflow.ustekinumab-clinical-transition.v1'
PENDING = [m.Termin.STATUS_PLANIRANA, m.Termin.STATUS_ODGODJENA, m.Termin.STATUS_PAUSIRANA]


def induction_candidates(patient):
    return actually_administered_therapy_query(patient.terapija_set).filter(
        lijek__put_primjene='IV', lijek__jacina_mg=130).select_related('lijek').order_by('-datum', '-pk')


def recognized_inductions(patient):
    return [t for t in induction_candidates(patient) if medicine_group_key(t.lijek) == 'ustekinumab']


def transition_offer(patient):
    state = phased_protocol_for_patient(patient)
    if not state and (not patient.lijek_id or medicine_group_key(patient.lijek) != 'ustekinumab'):
        return None
    events = recognized_inductions(patient)
    if not events or (state and state.faza == state.FAZA_ODRZAVANJE):
        return None
    latest = events[0]
    if (latest.workflow_snapshot or {}).get('sc_transition'):
        return None
    return {'therapy': latest, 'date': latest.datum,
            'needs_plan': not state or state.faza == state.FAZA_CEKA_IV}


def future_iv_appointments(patient, when):
    return m.Termin.objects.filter(pacijent=patient, status__in=PENDING,
        datum__gte=timezone.localdate(), datum__gt=when, lijek__put_primjene='IV').select_related('lijek').order_by('datum','pk')


def authorize(user):
    from dashboard.permissions import je_doktor_ili_admin
    require(je_doktor_ili_admin(user), 'SC plan potvrđuje doktor ili administrator prema nalogu ljekara.')


def plan(patient, data, user):
    authorize(user)
    therapy = next((t for t in recognized_inductions(patient) if t.pk == int(data['therapy_id'])), None)
    require(therapy is not None, 'Odaberite postojeću potvrđenu IV primjenu ustekinumaba iz ovog kartona.')
    require(therapy.datum <= timezone.localdate(), 'Stvarna primjena ne može biti u budućnosti.')
    require(not (therapy.workflow_snapshot or {}).get('sc_transition'), 'SC plan za ovu indukciju je već potvrđen.')
    later = [t for t in actually_administered_therapy_query(patient.terapija_set).select_related('lijek')
             if medicine_group_key(t.lijek) == 'ustekinumab' and
             (t.datum > therapy.datum or (t.datum == therapy.datum and t.pk != therapy.pk))]
    require(not later, 'Postoji druga ili kasnija stvarna primjena ustekinumaba. Provjerite kliničku historiju; ranija indukcija ne smije prepisati kasniji tok.')
    state = phased_protocol_for_patient(patient)
    require(state is not None or (patient.lijek_id and medicine_group_key(patient.lijek)=='ustekinumab'),
        'Trenutna terapija pacijenta nije ustekinumab. Historijska indukcija ne smije prepisati kasniju promjenu lijeka.')
    require(not state or (state.faza in (state.FAZA_CEKA_IV,state.FAZA_CEKA_PRVU_SC) and
        state.datum_prve_sc_primjene is None and
        (not state.datum_posljednje_primjene or state.datum_posljednje_primjene <= therapy.datum)),
        'Protokol već sadrži kasniju SC fazu ili primjenu. Ne vraćajte ga na prvu SC dozu.')
    require(not state or medicine_presentation_key(state.iv_lijek) == medicine_presentation_key(therapy.lijek),
        'Primjena ne pripada IV prezentaciji aktivnog protokola.')
    require(not patient.na_aktivnoj_pauzi(), 'Pacijent je na pauzi; najprije potvrdite nastavak terapije.')
    sc = m.Lijek.objects.filter(pk=data['sc_id'], aktivan=True).first()
    require(sc is not None and medicine_presentation_key(sc) == 'ustekinumab:SC:90',
        'Odaberite aktivnu SC prezentaciju ustekinumaba 90 mg iz kataloga.')
    require(str(data['dose_mg']) == '90', 'Za ovaj postojeći fazni protokol potvrdite 90 mg SC, jednu SC jedinicu; IV doza se ne prenosi.')
    interval = int(data['interval']);require(interval in (8,12), 'Potvrdite interval održavanja 8 ili 12 sedmica.')
    when = date.fromisoformat(str(data['date']));at = time.fromisoformat(str(data['time']))
    require(when > therapy.datum, 'SC termin mora biti poslije stvarne IV primjene.')
    from .scheduling import validate_new_active_appointment_date, validate_therapy_date
    validate_new_active_appointment_date(when)
    validate_therapy_date(when, lijek=sc, protokol=patient.aktivni_protokol())
    reason = str(data['reason']).strip();require(5 <= len(reason) <= 1000, 'Unesite potvrđeni plan ljekara i razlog (5–1000 znakova).')
    expected = therapy.datum + timedelta(weeks=8)
    deviation = str(data.get('date_reason','')).strip()
    require(when == expected or 5 <= len(deviation) <= 500,
        f'Plan računa prvu SC dozu od stvarne IV primjene: {expected:%d.%m.%Y.}. Za drugi datum unesite obrazloženje plana ljekara.')
    appointments = [t for t in future_iv_appointments(patient, therapy.datum) if medicine_group_key(t.lijek)=='ustekinumab']
    require(sorted(int(n) for n in data['replace_ids']) == sorted(t.pk for t in appointments),
        'Pregledajte i potvrdite sve prikazane buduće IV termine za zamjenu; nijedan se ne mijenja prešutno.')
    linked = list(m.PacijentRezervacija.objects.filter(termin_id__in=[t.pk for t in appointments], aktivno=True).order_by('pk'))
    require(all(r.pacijent_id==patient.pk and medicine_presentation_key(r.lijek)=='ustekinumab:IV:130' for r in linked),
        'Rezervacija starog termina ima neusklađenog pacijenta ili proizvod; potrebno je razjasniti vezu.')
    action = data.get('iv_reservations','')
    require(not linked or action in ('keep','release'), 'Odaberite šta uraditi s prikazanim IV rezervacijama. Ne prenose se na SC.')
    existing = list(m.Termin.objects.filter(pacijent=patient,status__in=PENDING,datum__gte=timezone.localdate(),
        lijek__put_primjene='SC').select_related('lijek'))
    existing = [t for t in existing if medicine_group_key(t.lijek)=='ustekinumab']
    require(len(existing)<=1 and all(t.lijek_id==sc.pk and t.datum==when and t.vrijeme==at and
        t.status==m.Termin.STATUS_PLANIRANA and t.kolicina_po_terapiji==1 for t in existing),
        'Već postoji drugačiji budući SC termin. Prvo razjasnite njegov datum/proizvod; ne kreira se duplikat.')
    reservation = None
    if data.get('sc_reservation_id'):
        reservation=m.PacijentRezervacija.objects.filter(pk=data['sc_reservation_id'],pacijent=patient,
            lijek=sc,aktivno=True,kolicina__gte=1).first()
        require(reservation is not None and (reservation.termin_id is None or (existing and reservation.termin_id==existing[0].pk)),
            'Odaberite postojeću SC rezervaciju ovog pacijenta koja nije vezana za drugi termin.')
    total = m.Zaliha.objects.filter(lijek=sc).aggregate(n=Sum('u_frizideru'))['n'] or Decimal(0)
    all_reserved = m.PacijentRezervacija.objects.filter(lijek=sc,aktivno=True).aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
    if reservation:
        require(total>=all_reserved, 'SC rezervacije trenutno nemaju potpuno fizičko pokriće. Plan možete potvrditi bez povezivanja rezervacije, uz vidljiv manjak.')
    warnings=[]
    if not reservation: warnings.append('SC termin se zakazuje bez nove dodjele zalihe. Postojeće SC količine ostaju iste; fizičko pokriće treba provjeriti prije primjene.')
    warnings.append('Komisijska prava i fizičke količine se ne troše. Administrativno usklađivanje ranije IV primjene ostaje zasebno.')
    return serial(dict(data=data,therapy_id=therapy.pk,actual_date=therapy.datum,iv_name=str(therapy.lijek),
        iv_quantity=therapy.kolicina,sc_name=str(sc),dose_mg=90,quantity=1,date=when,time=at,
        expected_date=expected,interval=interval,appointments=[dict(id=t.pk,date=t.datum,medicine=str(t.lijek),quantity=t.kolicina_po_terapiji) for t in appointments],
        reservations=[dict(id=r.pk,medicine=str(r.lijek),quantity=r.kolicina,action=action) for r in linked],
        existing_sc_id=existing[0].pk if existing else None,sc_reservation_id=reservation.pk if reservation else None,
        sc_stock=total,sc_reserved=all_reserved,warnings=warnings))


@transaction.atomic
def preview(patient,data,user):
    before=digest(captured_rows());result=plan(patient,data,user)
    require(before==digest(captured_rows()), 'Podaci su promijenjeni. Ponovite pregled.')
    token=signing.dumps(dict(patient_id=patient.pk,user_id=user.pk,data=data,fingerprint=before,
        operation_id=str(uuid.uuid4())),salt=SALT,compress=True)
    return result,token


def commit(patient,token,user):
    authorize(user)
    try: payload=signing.loads(token,salt=SALT,max_age=1800)
    except signing.BadSignature: raise ValueError('Pregled je istekao ili nije ispravan. Ponovite pregled.') from None
    require(payload['patient_id']==patient.pk and payload['user_id']==user.pk, 'Pregled ne pripada ovom korisniku i pacijentu.')
    with correction_transaction():
        therapy=m.Terapija.objects.select_for_update().get(pk=payload['data']['therapy_id'],pacijent=patient)
        previous=(therapy.workflow_snapshot or {}).get('sc_transition')
        if previous and previous['operation_id']==payload['operation_id']:
            return m.Termin.objects.get(pk=previous['appointment_id']),False
        require(payload['fingerprint']==digest(captured_rows()), 'Podaci su izmijenjeni nakon pregleda. Ništa nije sačuvano; ponovite pregled.')
        result=plan(patient,payload['data'],user);data=result['data']
        backup=backup_before_correction(payload['operation_id'])
        return apply_reviewed_plan(patient, result, user, payload['operation_id'], backup)


def apply_reviewed_plan(patient, result, user, operation, backup):
    """Existing transition writes; caller owns the reviewed atomic transaction."""
    data=result['data']
    therapy=m.Terapija.objects.get(pk=result['therapy_id'],pacijent=patient)
    before=captured_rows();oldstate=phased_protocol_for_patient(patient)
    from .therapy_workflow import cancel_therapy,schedule_therapy_appointment
    for item in result['appointments']:
        cancel_therapy(termin=m.Termin.objects.get(pk=item['id']),reason='Zamjena IV termina SC planom: '+data['reason'],user=user)
    for item in result['reservations']:
        reservation=m.PacijentRezervacija.objects.get(pk=item['id'])
        # A retained IV bottle is still IV stock for this patient, unlinked
        # from the cancelled appointment; never converted into an SC unit.
        reservation.termin=None
        if item['action']=='release':
            reservation.aktivno=False
            m.ZalihaTransakcija.objects.create(lijek=reservation.lijek,pacijent=patient,
                tip=m.ZalihaTransakcija.TIP_OSLOBADJANJE_U_SLOBODNU_ZALIHU,kolicina=reservation.kolicina,
                promjena_salda=0,datum=timezone.localdate(),korisnik=user,rezervacija=reservation,
                promjena_rezervacije=-reservation.kolicina,referenca_tip='SC plan',referenca_id=therapy.pk,
                napomena=data['reason'],lokacija='FRIZIDER',operation_id=operation)
        reservation.napomena=(reservation.napomena+'\nSC plan: '+data['reason']+'; IV rezervacija '+item['action']).strip()
        reservation.save(update_fields=['termin','aktivno','napomena'])
    state=configure_ustekinumab_protocol(patient=patient,iv_medicine=therapy.lijek,
        sc_medicine=m.Lijek.objects.get(pk=data['sc_id']),phase=m.FazniProtokolPacijenta.FAZA_CEKA_PRVU_SC,
        maintenance_interval=data['interval'],user=user,allow_missing_iv_dose=True,
        last_actual_date=therapy.datum)
    appointment,created=schedule_therapy_appointment(pacijent=state.pacijent,lijek=state.sc_lijek,
        datum=date.fromisoformat(data['date']),vrijeme=time.fromisoformat(data['time']),user=user,
        kolicina_po_terapiji=Decimal(1),reason='SC plan poslije potvrđene IV primjene: '+data['reason'])
    if result['sc_reservation_id']:
        m.PacijentRezervacija.objects.filter(pk=result['sc_reservation_id']).update(termin=appointment)
    state.sljedeci_datum=appointment.datum;state.save(update_fields=['sljedeci_datum','izmijenjeno'])
    after=captured_rows()
    # This clinical transition must not debit any stock, right or home balance.
    for model in (m.Zaliha,m.Komisija,m.PacijentZaduzenje):
        require(before[model._meta.db_table]==after[model._meta.db_table], 'Promjena faze ne smije promijeniti fizičku zalihu ili odobreno pravo.')
    audit=dict(operation_id=operation,appointment_id=appointment.pk,user_id=user.pk,
        created_at=timezone.now().isoformat(),preview=result,backup=backup,
        state_before=before[m.FazniProtokolPacijenta._meta.db_table].get(str(oldstate.pk)) if oldstate else None,
        state_after=protocol_state_snapshot(state))
    therapy.workflow_snapshot={**(therapy.workflow_snapshot or {}),'sc_transition':serial(audit)}
    therapy.faza_terapije=m.Terapija.UstekinumabFaza.IV_INDUKCIJA
    therapy.workflow_snapshot['faza_terapije_label']='IV indukcija'
    therapy.save(update_fields=['workflow_snapshot','faza_terapije'])
    from .utils import upisi_log
    upisi_log(user,'Potvrđen SC plan iz stvarne IV primjene',pacijent=patient,objekat=state,
        opis=f'IV #{therapy.pk} od {therapy.datum}; SC termin #{appointment.pk}. {data["reason"]}. {data.get("date_reason", "")}')
    return appointment,created
