"""Reclassify a proven count loss as a real late outflow; never skip stock."""
from decimal import Decimal
from django.db.models import Sum
from django.utils import timezone
from . import models as m
from .data_corrections import require, serial


def unresolved_counts(medicine,when):
    """A known later count loss is ambiguous until attributed to an event."""
    from .retrospective_events import day
    result=[]
    for correction in m.PhysicalStockCorrection.objects.filter(lijek=medicine,razlika__lt=0,pregled__cause='COUNT_UNKNOWN'):
        if day(correction.pregled['event_date']) < when:continue
        if m.PhysicalStockCorrection.objects.filter(pregled__previous_correction_id=correction.pk).exists():continue
        used=correction.retrospective_events.filter(reversed_at__isnull=True).aggregate(n=Sum('quantity'))['n'] or Decimal(0)
        if used < -correction.razlika:result.append(correction)
    return result


def proof(data):
    from .retrospective_events import day, amount
    correction = m.PhysicalStockCorrection.objects.filter(pk=data.get('stock_correction_id')).first()
    require(data['kind'] in ('therapy','home') and correction is not None,
        'Povežite konkretno ranije fizičko brojanje za propuštenu primjenu ili izdavanje.')
    require(correction.lijek_id == data['medicine_id'] and correction.razlika < 0
        and correction.pregled.get('cause') == 'COUNT_UNKNOWN',
        'Odabrana korekcija nije dokumentovani manjak istog proizvoda s prvobitno nepoznatim uzrokom.')
    quantity = amount(data['quantity']); when = day(data['event_date'])
    require(when <= day(correction.pregled['event_date'])
        and str(correction.pregled.get('batch') or '') == data.get('batch','')
        and str(correction.pregled.get('expires') or '') == data.get('expires',''),
        'Datum događaja, serija ili rok ne odgovaraju odabranom popisu.')
    require(data.get('count_link_confirmed') is True and len(str(data.get('count_link_reason','')).strip()) >= 10,
        'Potvrdite da ovaj konkretni događaj objašnjava dio ranijeg manjka i navedite dokument ili provjeru koja to dokazuje.')
    used = correction.retrospective_events.filter(reversed_at__isnull=True).aggregate(n=Sum('quantity'))['n'] or Decimal(0)
    require(used + quantity <= -correction.razlika,
        'Raniji manjak je već objašnjen povezanim događajima ili je manji od unesene količine.')
    rows = m.ZalihaTransakcija.objects.filter(lijek_id=data['medicine_id'],
        referenca_tip='PhysicalStockCorrection', referenca_id=correction.pk)
    require(rows.count() == 1 and rows.get().frizider_delta() == correction.razlika,
        'Ranijem popisu nedostaje jednoznačan, neizmijenjen fizički promet.')
    require(not m.PhysicalStockCorrection.objects.filter(pregled__previous_correction_id=correction.pk).exists(),
        'Odabrano brojanje je naknadno ispravljeno. Odaberite provjereni posljednji izvor.')
    source = rows.get()
    require(source.datum >= when, 'Izvorni fizički promet prethodi stvarnom događaju.')
    return correction, source, quantity


def apply(data, patient, user, operation_id, backup):
    correction, source, quantity = proof(data)
    stock = m.Zaliha.objects.get(lijek_id=source.lijek_id)
    before = stock.u_frizideru
    reason = str(data['count_link_reason']).strip()
    audit = m.PatientDataCorrection.objects.create(operation_id=operation_id, pacijent=patient, korisnik=user,
        izvorna_transakcija=source, datum_dogadjaja=source.datum, scope='retro_count_link', razlog=reason,
        posljedice=serial({'physical_count_id':correction.pk, 'quantity':quantity, 'kind':data['kind'],
            'shortfall_before':shortfall(stock), 'home_before':stock.kod_pacijenata,
            'event_date':data['event_date'], 'rows':[{'label':'Razjašnjenje ranijeg manjka',
            'before':before, 'after':before+quantity}]}), backup=backup)
    # Compensate exactly the documented part at its original booking date. The
    # normal clinical/issuance service still posts the complete actual outflow.
    stock.u_frizideru += quantity
    # A partial explanation can leave another genuine shortfall. Restore only
    # this proven part and retain all other reservations and discrepancies.
    m.Zaliha.objects.filter(pk=stock.pk).update(u_frizideru=stock.u_frizideru,ukupno=stock.u_frizideru)
    movement = m.ZalihaTransakcija.objects.create(lijek=source.lijek, pacijent=patient, korisnik=user,
        tip='KOREKCIJA', datum=source.datum, kolicina=quantity, promjena_salda=quantity,
        izvorna_transakcija=source, korekcija=audit, operation_id=operation_id,
        referenca_tip='PatientDataCorrection', referenca_id=audit.pk, serija=source.serija,
        rok_trajanja=source.rok_trajanja, lokacija='FRIZIDER', napomena=reason)
    return correction, audit, movement


def shortfall(stock):
    from .medication_groups import strict_equivalent_medicine_ids
    ids=strict_equivalent_medicine_ids(stock.lijek)
    others=m.Zaliha.objects.filter(lijek_id__in=ids).exclude(pk=stock.pk).aggregate(n=Sum('u_frizideru'))['n'] or Decimal(0)
    reserved=m.PacijentRezervacija.objects.filter(lijek_id__in=ids,aktivno=True).aggregate(n=Sum('kolicina'))['n'] or Decimal(0)
    return max(Decimal(0),reserved-others-stock.u_frizideru)


def save_reconciled_stock(stock,audit_id,patient,user,when,quantity):
    """Complete a proven count reclassification, preserving a remaining loss."""
    audit=m.PatientDataCorrection.objects.get(pk=audit_id,pacijent=patient,korisnik=user,scope='retro_count_link')
    proof=audit.posljedice
    require(str(when)==proof['event_date'] and Decimal(proof['quantity'])==quantity
        and audit.izvorna_transakcija.lijek_id==stock.lijek_id,
        'Razjašnjenje popisa ne pripada ovoj stvarnoj potrošnji.')
    require(not m.RetrospectiveEvent.objects.filter(effects__count_link__audit_id=audit.pk).exists(),
        'Razjašnjenje popisa je već iskorišteno.')
    expected_home=Decimal(proof['home_before'])+(quantity if proof['kind']=='home' else 0)
    require(stock.u_frizideru==Decimal(proof['rows'][0]['before']) and stock.u_frizideru>=0
        and stock.kod_pacijenata==expected_home and shortfall(stock)<=Decimal(proof['shortfall_before']),
        'Razjašnjenje ne smije dodatno smanjiti fizičku zalihu niti povećati postojeći manjak.')
    m.Zaliha.objects.filter(pk=stock.pk).update(u_frizideru=stock.u_frizideru,
        ukupno=stock.u_frizideru,kod_pacijenata=stock.kod_pacijenata)


def reverse_link(event, reason, user, backup):
    link = event.effects.get('count_link')
    if not link:
        return
    original = m.PatientDataCorrection.objects.get(pk=link['audit_id'])
    require(not original.naknadne_ispravke.exists(), 'Veza s ranijim brojanjem već je ispravljena.')
    source = m.ZalihaTransakcija.objects.get(pk=link['movement_id'], korekcija=original)
    stock = m.Zaliha.objects.get(lijek=event.medicine)
    require(stock.u_frizideru >= event.quantity, 'Nema dovoljno fizičke zalihe za povrat razjašnjenja popisa.')
    audit = m.PatientDataCorrection.objects.create(pacijent=event.patient, korisnik=user, ponistava=original,
        izvorna_transakcija=source, datum_dogadjaja=timezone.localdate(), scope='retro_count_link', razlog=reason,
        posljedice={'reverse_event_id':event.pk, 'rows':[]}, backup=backup)
    stock.u_frizideru -= event.quantity
    # Restore the documented count shortfall; do not erase patients' rights or
    # reservations to make a physical discrepancy disappear.
    m.Zaliha.objects.filter(pk=stock.pk).update(u_frizideru=stock.u_frizideru,ukupno=stock.u_frizideru)
    m.ZalihaTransakcija.objects.create(lijek=event.medicine,pacijent=event.patient,korisnik=user,
        tip='KOREKCIJA',datum=timezone.localdate(),kolicina=-event.quantity,promjena_salda=-event.quantity,
        izvorna_transakcija=source,korekcija=audit,operation_id=audit.operation_id,
        referenca_tip='PatientDataCorrection',referenca_id=audit.pk,serija=source.serija,
        rok_trajanja=source.rok_trajanja,lokacija='FRIZIDER',napomena=reason)


def dated_movements(query):
    """A proven count reclassification belongs to the original count instant.

    This only nets append-only, audited parts of that specific count, not an
    arbitrary later receipt that would hide an actual intervening shortage.
    """
    rows=query if isinstance(query,list) else list(query.select_related('korekcija','izvorna_transakcija').order_by('datum','pk'))
    by_id={tx.pk:tx for tx in rows};offsets={};linked=set()
    for tx in rows:
        source=by_id.get(tx.izvorna_transakcija_id)
        checkpoint = (tx.korekcija_id and tx.korekcija.scope=='retro_checkpoint'
                      and not tx.korekcija.posljedice.get('reversed'))
        if (source and tx.korekcija_id and (tx.korekcija.scope=='retro_count_link' or checkpoint)
            and source.referenca_tip=='PhysicalStockCorrection' and source.datum==tx.datum
            and (checkpoint or tx.frizider_delta()>0 and source.frizider_delta()<0)
            and tx.korekcija.posljedice.get('physical_count_id')==source.referenca_id):
            offsets[source.pk]=offsets.get(source.pk,Decimal(0))+tx.frizider_delta()
            linked.add(tx.pk)
    return [(tx,tx.frizider_delta()+offsets.get(tx.pk,Decimal(0))) for tx in rows if tx.pk not in linked]

