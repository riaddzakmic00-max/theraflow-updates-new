"""Dated, read-only context for the existing late-event services."""
from copy import copy
from decimal import Decimal
from django.db.models import Q
from django.utils import timezone
from . import models as m
from .data_corrections import require
from .medicine_registry import patient_product_for_selection


def patient_at(patient, when):
    if getattr(patient, '_retrospective_date', None) == when:
        return patient
    result = copy(patient)
    result._state = copy(patient._state)
    result._state.fields_cache = patient._state.fields_cache.copy()
    changes = list(patient.promjene_terapije.select_related('stari_lijek', 'novi_lijek',
        'stari_protokol', 'novi_protokol').order_by('-datum_pocetka_nove_terapije', '-pk'))
    proof = []
    for change in changes:
        if when >= change.datum_pocetka_nove_terapije:
            break
        require(result.lijek_id == change.novi_lijek_id,
            'Historija promjene terapije nije povezana s trenutnim proizvodom. Provjerite zapis promjene terapije.')
        require(when <= change.datum_zavrsetka_stare_terapije,
            'Datum događaja je između završetka stare i početka nove terapije. Potrebna je provjera liječničkog naloga.')
        result.lijek = change.stari_lijek
        result.terapijski_program = change.stari_lijek.terapijski_program
        result.terapijski_protokol = change.stari_protokol
        proof.append(change.pk)
    result._retrospective_date = when
    result._retrospective_changes = proof
    if proof:
        # This is an unsaved historical read copy. Today's pending order must
        # not invalidate the preserved previous course.
        result.protokol_za_potvrdu = False
        require(result.terapijski_protokol_id,
            'Historijskoj terapiji nedostaje sačuvan protokol. Potrebno je razjasniti izvorni nalog; današnji protokol nije zamjena.')
        from .therapy_history import actually_administered_therapy_query
        previous = actually_administered_therapy_query(m.Terapija.objects.filter(
            pacijent=patient, lijek=result.lijek, datum__lte=when)).order_by('-datum', '-pk').first()
        require(previous is not None or not result.terapijski_protokol.koraci.filter(faza='INDUKCIJA',aktivan=True).exists(),
            'Sačuvani stari protokol ima više faza, a faza na datum događaja nije dokazana. '
            'Potrebno je razjasniti historijski nalog; održavanje se ne smije pretpostaviti.')
        # A known previous application proves the historical phase; otherwise ask
        # for an explicit confirmation of the saved standard protocol in the form.
        result._retrospective_phase_proven = bool(previous)
        phase = str(previous.faza_terapije).upper() if previous else 'ODRZAVANJE'
        result.pocetna_faza_terapije = 'INDUKCIJA' if phase=='INDUKCIJA' else 'ODRZAVANJE'
        result.interval_sedmica = previous.interval_sedmica if previous else result.terapijski_protokol.interval_odrzavanja_sedmica
        result.kolicina_po_terapiji = previous.kolicina if previous else None
    return result


def product_at(patient, selected, when):
    return patient_product_for_selection(patient_at(patient, when), selected)


def validate_pause(patient, when):
    require(not m.PauzaTerapije.objects.filter(pacijent=patient, datum_pocetka__lte=when)
        .filter(Q(datum_nastavka__isnull=True) | Q(datum_nastavka__gt=when)).exists(),
        'Na stvarni datum događaja evidentirana je pauza terapije. Razjasnite izvorni zapis pauze.')


def proven_therapy_context(appointment, when):
    """Fail closed for the guided flow; never infer a historical phase from today.

    Dated regimen orders already overlay the shared protocol resolver. Mutable
    individual protocols without a proven version at the requested date are
    deliberately left for manual review instead of rebuilding a clinical order.
    """
    from .appointment_plan import appointment_plan
    from .individual_protocols import get_effective_protocol, get_current_step, get_units_per_application, PROTOCOL_SOURCE_INDIVIDUAL
    patient = patient_at(appointment.pacijent, when)
    require(patient.lijek_id == appointment.lijek_id, 'Termin i dokazani historijski lijek se razlikuju.')
    require(not patient.aktivni_fazni_protokol(), 'Historijska IV/SC faza nije dovoljno dokazana za automatsku potvrdu.')
    protocol = get_effective_protocol(patient, when)
    require(protocol is not None and not protocol.warning, 'Nedostaje jednoznačan historijski terapijski protokol.')
    if protocol.source == PROTOCOL_SOURCE_INDIVIDUAL:
        original = patient.individualni_protokol
        require(timezone.localdate(original.datum_kreiranja) <= when and
                timezone.localdate(original.datum_izmjene) <= when and
                not original.historija_izmjena.filter(datum_odluke__gt=when).exists(),
                'Individualni protokol je nastao ili izmijenjen poslije stvarnog datuma. Potrebna je provjera izvornog naloga.')
    step = get_current_step(patient, when)
    require(step is not None and step.broj_jedinica and step.broj_jedinica > 0 and
            step.doza_mg and step.doza_mg > 0 and step.nacin_primjene_koraka == m.Lijek.NACIN_AMBULANTA,
            'Nije dokazana doza, faza ili ambulantno mjesto primjene na stvarni datum.')
    from .therapy_history import actually_administered_therapy_query
    prior = actually_administered_therapy_query(m.Terapija.objects.filter(pacijent=patient,
        lijek_id__in=patient.lijek.equivalent_ids(), datum__lt=when)).order_by('-datum', '-pk').first()
    if prior and prior.faza_terapije.upper() == 'INDUKCIJA' and step.faza == 'ODRZAVANJE':
        from .retrospective_schedule import application_number_at
        require(application_number_at(patient, when) > len(protocol.indukcijski_koraci()),
                'Današnja faza održavanja nije dokaz završene indukcije na stvarni datum.')
    require(not m.PatientDataCorrection.objects.filter(pacijent=patient, scope__in=['regimen', 'protocol'],
            kreirano__date__gt=when).exists(), 'Postoji kasnija ispravka plana; potrebno je provjeriti izvorni nalog.')
    plan = appointment_plan(appointment, fresh=True, retrospective=True, historical_date=when)
    require(not plan['conflict'] and plan['source'] != 'MANUAL', 'Termin ima posebnu količinu ili konflikt s historijskim nalogom.')
    units = get_units_per_application(patient, when)
    require(units and units > 0 and plan['interval'] and plan['interval'] > 0,
            'Nedostaje dokazana količina ili interval.')
    require(appointment.kolicina_po_terapiji is None or plan['source'] == 'REGIMEN' or
            appointment.kolicina_po_terapiji == units, 'Količina termina se razlikuje od historijskog naloga.')
    if when < timezone.localdate():
        from .regimen_changes import regimen_override
        dated = regimen_override(patient, when)
        complete_order = all(dated.get(key) is not None for key in
            ('doza_mg', 'broj_jedinica', 'interval_sedmica'))
        prior_phase = str(prior.faza_terapije).upper().replace('Ž', 'Z') if prior else ''
        prior_proof = bool(prior and prior.kolicina == units and
            prior.doza_mg == plan['dose_mg'] and prior.interval_sedmica == plan['interval'] and
            prior_phase == step.faza)
        require(complete_order or prior_proof or protocol.source == PROTOCOL_SOURCE_INDIVIDUAL,
                'Nema datiranog naloga ili sačuvane historijske primjene koja potvrđuje dozu, količinu, interval i fazu. '
                'Današnji standardni protokol nije dokaz historijskog naloga.')
        require(prior is not None or not protocol.indukcijski_koraci() or
                protocol.source == PROTOCOL_SOURCE_INDIVIDUAL,
                'Početak i tok historijske indukcije nisu dokazani; današnja faza nije dovoljan dokaz.')
    if prior and step.faza == 'ODRZAVANJE' and prior.faza_terapije.upper().replace('Ž', 'Z') == 'ODRZAVANJE':
        dated_order = m.BrzaIzmjenaPacijenta.objects.filter(pacijent=patient, lijek=patient.lijek,
            vrsta__in=['dose', 'interval'], vrijedi_od__gt=prior.datum, vrijedi_od__lte=when).exists()
        if not dated_order:
            require((not prior.doza_mg or prior.doza_mg == plan['dose_mg']) and
                    (not prior.interval_sedmica or prior.interval_sedmica == plan['interval']),
                    'Historijska primjena i današnji protokol imaju različitu dozu ili interval bez dokazanog datiranog naloga.')
    plan['quantity'] = units
    return patient, plan


def period_overview(patient, start, end):
    from .inventory_corrections import allocation_quantity, receipt_date
    from .therapy_history import actually_administered_therapy_query
    records = []
    pending = list(m.RetrospectiveEvent.objects.filter(patient=patient,event_date__range=(start,end),
        effects__reconciliation_status='PENDING',reversed_at__isnull=True).select_related('medicine'))
    pending_therapies = {e.therapy_id for e in pending if e.therapy_id}
    for event in pending:
        if event.kind == 'receipt':
            records.append(dict(date=event.event_date,type='Pristigli lijek',quantity=event.quantity,
                medicine=event.medicine,id=event.pk,kind='receipt',status='Čeka usklađivanje'))
    for claim in m.EvidencijaSaglasnostiZaprimanja.objects.filter(pacijent=patient).select_related('fizicka_transakcija', 'trebovanje__lijek'):
        if claim.fizicka_transakcija_id:
            when = receipt_date(claim.fizicka_transakcija)
            if start <= when <= end:
                records.append(dict(date=when, type='Prijem', quantity=allocation_quantity(claim),
                    medicine=claim.fizicka_transakcija.lijek, id=claim.pk, kind='receipt', status='Evidentirano'))
    for therapy in actually_administered_therapy_query(m.Terapija.objects.filter(pacijent=patient, datum__range=(start,end))).select_related('lijek'):
        records.append(dict(date=therapy.datum, type='Primjena', medicine=therapy.lijek, quantity=therapy.kolicina,
            id=therapy.pk, kind='therapy', status='Čeka usklađivanje' if therapy.pk in pending_therapies else 'Evidentirano'))
    for issue in m.KucnoIzdavanje.objects.filter(pacijent=patient, datum__range=(start,end)).exclude(
            terapija__workflow_status=m.Terapija.STATUS_PONISTENA).select_related('lijek'):
        records.append(dict(date=issue.datum, type='Kućno izdavanje — nije primjena', medicine=issue.lijek,
            quantity=issue.kolicina, id=issue.pk, kind='issue', status='Evidentirano'))
    for issue in m.IzdavanjeOralneTerapije.objects.filter(pacijent=patient,
            datum_izdavanja__range=(start, end), status=m.IzdavanjeOralneTerapije.STATUS_AKTIVNO).select_related('lijek'):
        records.append(dict(date=issue.datum_izdavanja, type='Oralno kućno izdavanje — nije primjena',
            medicine=issue.lijek, quantity=issue.kolicina_tableta, id=issue.pk, kind='oral', status='Evidentirano'))
    for term in m.Termin.objects.filter(pacijent=patient, datum__range=(start,end),
            status__in=[m.Termin.STATUS_PLANIRANA,m.Termin.STATUS_ODGODJENA]).select_related('lijek'):
        records.append(dict(date=term.datum, type='Termin bez zabilježenog ishoda', medicine=term.lijek,
            quantity=term.kolicina_po_terapiji, id=term.pk, kind='appointment', status='Potrebno provjeriti'))
    return sorted(records, key=lambda x:(x['date'],x['type'],x['id']))
