"""A resumable period review over existing atomic domain operations.

Session JSON stores observations and review capabilities, never a stock ledger.
Every write/preview uses the existing correction lock for one event only.
"""
from datetime import timedelta
from decimal import Decimal
import uuid

from django.core import signing
from django.db import transaction
from django.db.models import F, Q, Sum
from django.utils import timezone

from . import models as m, smart_reconciliation as smart, retrospective_events as events
from .correction_protocol import correction_transaction
from .data_corrections import require, serial, digest, backup_before_correction
from .request_cache import begin_request_cache, end_request_cache

SALT = 'theraflow.absence-reconciliation.v1'
STEPS = [(1, 'Terapije'), (2, 'Zaprimanja'), (3, 'Zaduženja'), (4, 'Fizičko stanje'), (5, 'Pregled')]
UNLINKED = 'Naknadno evidentiran stvarni prijem – komisijska veza nije pronađena.'


def own(session_id, user, lock=False):
    session = smart.own_session(session_id, user, lock=lock)
    require(session.workflow == 'absence', 'Ovo nije usklađivanje perioda odsustva.')
    return session


def editable(session):
    require(session.status not in ('cancelled', 'aligned', 'completed'), 'Ovaj postupak je završen.')


def scope(session, medicine, patient=None):
    require(not session.medicine_id or medicine.pk in session.medicine.equivalent_ids(), 'Lijek nije dio odabranog obuhvata.')
    require(not patient or not session.patient_id or patient.pk == session.patient_id, 'Pacijent nije dio odabranog obuhvata.')


def receipt_scan(session):
    from .commission_exclusions import visible_commission_requests
    requests = visible_commission_requests(m.Trebovanje.objects.filter(
        Q(komisija__datum_odobrenja__lte=session.period_end) | Q(komisijski_ciklus__datum_odobrenja__lte=session.period_end),
        Q(odobrene_doze__gt=F('zaprimljene_doze')) | Q(evidencije_saglasnosti_zaprimanja__fizicka_transakcija__datum__range=(session.period_start, session.period_end)),
        status__in=['ODOBRENO', 'CEKA_ISPORUKU', 'DJELOMICNO_ODOBRENO', 'ZAPRIMLJENO'],
    )).select_related('pacijent', 'lijek', 'komisijski_ciklus', 'komisija').distinct()
    if session.patient_id: requests = requests.filter(pacijent_id=session.patient_id)
    if session.medicine_id: requests = requests.filter(lijek_id__in=session.medicine.equivalent_ids())
    require(requests.count() <= 500, 'Pregled zaprimanja nije kompletan. Sužite period ili filter pacijenta/lijeka (najviše 500 stavki).')
    return [receipt_card(r) for r in requests.order_by('pk').prefetch_related('unlinkedstockreceipt_set__movement')]


def request_state(request):
    from .commission_receiving import received_commission_quantity
    return serial(dict(approved=request.odobrene_doze, received=request.zaprimljene_doze,
        physically_received=received_commission_quantity(request),
        status=request.status, approval=request.komisija_id, cycle=request.komisijski_ciklus_id))


def receipt_card(request):
    from .commission_receiving import received_commission_quantity
    received = received_commission_quantity(request)
    approved = request.odobrene_doze or Decimal(0)
    return serial(dict(id=request.pk, patient_id=request.pacijent_id, medicine_id=request.lijek_id,
        patient=str(request.pacijent), medicine=str(request.lijek), approved=approved,
        received=received, remaining=max(Decimal(0), approved-received),
        cycle=str(request.komisijski_ciklus or 'Komisijska veza nije potpuna'),
        status=request.get_status_display(), state=request_state(request),
        can_receive=bool(request.komisija_id and request.komisijski_ciklus_id and approved > received),
        package=request.lijek.nabavna_jedinica if hasattr(request.lijek, 'nabavna_jedinica') else request.lijek.jedinica_zalihe))


def start_session(**kwargs):
    with transaction.atomic():
        session = smart.start_session(**kwargs, workflow='absence')
        session.receipt_findings = receipt_scan(session)
        session.save(update_fields=['receipt_findings', 'updated_at'])
        return session


def refresh(session_id, user):
    """Union discovered items, refresh current facts; retain confirmed audit history."""
    with correction_transaction():
        session = own(session_id, user, lock=True)
        current = smart.scan(session.period_start, session.period_end, patient=session.patient, medicine=session.medicine)
        key = lambda r: (r['id'],) if r.get('id') else (None, r['patient_id'], r['medicine_id'], r['date'])
        merged = {key(r): r for r in session.findings}
        merged.update({key(r): r for r in current})
        receipts = {r['id']: r for r in session.receipt_findings}
        receipts.update({r['id']: r for r in receipt_scan(session)})
        fresh = serial(list(merged.values())), serial(list(receipts.values()))
        if fresh != (session.findings, session.receipt_findings):
            session.findings, session.receipt_findings = fresh
            session.save(update_fields=['findings', 'receipt_findings', 'updated_at'])
        if session.status == 'aligned' and summary(session)['unresolved']:
            session.status = 'needs_review'; session.current_step = 5; session.revision += 1
            session.save(update_fields=['status', 'current_step', 'revision', 'updated_at'])
        return session


def relevant_medicines(session):
    ids = {r['medicine_id'] for r in session.findings + session.receipt_findings}
    ids.update(int(k) for k in session.physical_counts)
    for a in session.actions.all():
        data = a.summary.get('data', {})
        if data.get('medicine_id'): ids.add(int(data['medicine_id']))
    if session.medicine_id:
        ids.add(session.medicine_id)
        ids.update(m.Zaliha.objects.filter(lijek_id__in=session.medicine.equivalent_ids()).exclude(u_frizideru=0).values_list('lijek_id', flat=True))
    else:
        patients = m.Pacijent.objects.filter(pk=session.patient_id) if session.patient_id else m.Pacijent.objects.all()
        ids.update(patients.exclude(lijek_id=None).values_list('lijek_id', flat=True))
        tx = m.ZalihaTransakcija.objects.filter(datum__range=(session.period_start, session.period_end))
        if session.patient_id: tx = tx.filter(pacijent_id=session.patient_id)
        ids.update(tx.values_list('lijek_id', flat=True))
        if not session.patient_id: ids.update(m.Zaliha.objects.exclude(u_frizideru=0).values_list('lijek_id', flat=True))
    return list(m.Lijek.objects.filter(pk__in=ids).order_by('naziv', 'pk'))


def stock_state(medicine):
    stock = m.Zaliha.objects.filter(lijek=medicine).first()
    transactions = list(m.ZalihaTransakcija.objects.filter(lijek=medicine).order_by('pk').values())
    return serial(dict(expected=stock.u_frizideru if stock else 0, ledger=transactions))


def count_card(session, medicine, *, state=None, allowed_movements=None):
    # Read-only displays may bulk-load the same native facts. The existing
    # comparison and freshness rules remain authoritative for both displays.
    if state is None:
        state = stock_state(medicine)
    observation = session.physical_counts.get(str(medicine.pk))
    result = dict(id=medicine.pk, medicine=str(medicine), expected=state['expected'], observation=observation,
        counted=None, difference=None, aligned=False, stale=False, explained=False)
    if observation:
        previous = observation['state']
        old_ids = {r['id'] for r in previous['ledger']}
        current_old = [r for r in state['ledger'] if r['id'] in old_ids]
        new = [r for r in state['ledger'] if r['id'] not in old_ids]
        allowed = set(allowed_movements or ())
        if allowed_movements is None:
            for a in session.actions.select_related('event', 'unlinked_receipt', 'physical_correction'):
                if a.event_id: allowed.update(a.event.movements.values_list('pk', flat=True))
                if a.unlinked_receipt_id: allowed.add(a.unlinked_receipt.movement_id)
                if a.physical_correction_id:
                    allowed.update(m.ZalihaTransakcija.objects.filter(referenca_tip='PhysicalStockCorrection',
                        referenca_id=a.physical_correction_id).values_list('pk', flat=True))
        changed = previous != state
        # A period event entered through this session can explain an existing count.
        # Changes outside it or edits of old ledger rows require a fresh observation.
        stale = changed and (current_old != previous['ledger'] or not new or any(r['id'] not in allowed for r in new))
        difference = Decimal(observation['counted']) - Decimal(str(state['expected']))
        result.update(counted=observation['counted'], difference=str(difference), stale=stale,
            aligned=not stale and difference == 0,
            explained=not stale and changed and difference == 0 and not any(r['referenca_tip'] == 'PhysicalStockCorrection' for r in new) and Decimal(observation['counted']) != Decimal(str(previous['expected'])),
            manually_corrected=not stale and difference == 0 and any(r['referenca_tip'] == 'PhysicalStockCorrection' for r in new),
            can_correct=not stale and difference != 0 and observation.get('explained_fingerprint') == digest(state))
    return serial(result)


def reservation_findings(session):
    """Investigate remaining evidence, never infer a target balance from one therapy."""
    from .inventory import inventory_position, patient_reservation_breakdown
    medicines = relevant_medicines(session)
    result = []
    for medicine in medicines:
        position = inventory_position(medicine, include_planned_need=False)
        reservations = m.PacijentRezervacija.objects.filter(lijek=medicine, aktivno=True, kolicina__gt=0).select_related('pacijent', 'komisija', 'termin', 'trebovanje')
        if session.patient_id: reservations = reservations.filter(pacijent_id=session.patient_id)
        for r in reservations:
            issues = []
            if r.termin_id and r.termin.status == m.Termin.STATUS_POTVRDJENA:
                issues.append('Aktivna rezervacija vezana je za već obavljen termin; provjerite potrošnju i eventualni kasniji prijem.')
            if r.termin_id and r.termin.status in ('OTKAZAN', m.Termin.STATUS_PAUSIRANA):
                issues.append('Rezervacija uz otkazan ili pauziran termin; provjerite odluku prije oslobađanja.')
            if r.pacijent.lijek_id != medicine.pk:
                issues.append('Potrebna provjera terapijskog plana / naloga ljekara; rezervacija je na drugom proizvodu.')
            if r.komisija_id and not r.komisija.je_vazeca():
                issues.append('Rezervacija ima nevažeću komisijsku osnovu.')
            documented_assignment = m.ZalihaTransakcija.objects.filter(rezervacija=r,
                tip=m.ZalihaTransakcija.TIP_DODJELA_SLOBODNE_ZALIHE).exists() or m.BrzaIzmjenaPacijenta.objects.filter(odredisna_rezervacija=r, vrsta='transfer').exists()
            if not r.komisija_id and not r.trebovanje_id and not documented_assignment:
                issues.append('Rezervacija bez dokumentovane komisijske veze; provjerite izvor stvarne dodjele.')
            if issues:
                result.append(dict(id=r.pk, patient_id=r.pacijent_id, medicine_id=medicine.pk,
                    patient=str(r.pacijent), medicine=str(medicine), quantity=str(r.kolicina), reasons=issues,
                    state=digest(serial(m.PacijentRezervacija.objects.filter(pk=r.pk).values().get()))))
        if Decimal(str(position['in_fridge'])) < Decimal(str(position['reserved_in_fridge'])):
            result.append(dict(id=None, medicine_id=medicine.pk, patient_id=None, patient='Zajednička zaliha',
                medicine=str(medicine), quantity=str(position['reserved_in_fridge']),
                reasons=['Rezervisano je više nego što postoji fizički. Provjerite događaje i popis; zaduženja se ne mijenjaju radi poravnanja broja.']))
        # Missing coverage is a candidate only for an actual future appointment.
        terms = m.Termin.objects.filter(lijek=medicine, datum__gte=timezone.localdate(), status=m.Termin.STATUS_PLANIRANA).select_related('pacijent')
        if session.patient_id: terms = terms.filter(pacijent_id=session.patient_id)
        seen = set()
        for term in terms:
            if term.pacijent_id in seen: continue
            seen.add(term.pacijent_id)
            needed = term.kolicina_po_terapiji or term.pacijent.kolicina_po_terapiji
            covered = patient_reservation_breakdown(term.pacijent, medicine_ids=[medicine.pk])['total_effective']
            if covered < needed:
                result.append(dict(id=None, patient_id=term.pacijent_id, medicine_id=medicine.pk,
                    patient=str(term.pacijent), medicine=str(medicine), quantity=str(needed-covered),
                    reasons=['Naredni planirani termin nema dovoljno zaduženja; provjerite treba li dodijeliti postojeću slobodnu dozu.']))
    return result


def therapy_cards(session):
    done, changed = set(), set()
    for action in session.actions.filter(appointment__isnull=False).exclude(decision='skip').select_related('appointment', 'event', 'event__therapy'):
        term = action.appointment
        data = action.summary.get('data', {})
        valid = True
        if action.decision == 'therapy':
            valid = bool(action.event_id and not action.event.reversed_at and action.event.therapy_id
                and action.event.therapy.workflow_status == m.Terapija.STATUS_POTVRDJENA and term.status == m.Termin.STATUS_POTVRDJENA
                and action.event.therapy.pacijent_id == data.get('patient_id')
                and action.event.therapy.lijek_id == data.get('medicine_id')
                and str(action.event.therapy.datum) == data.get('event_date')
                and action.event.therapy.kolicina == Decimal(data.get('quantity', '0')))
        elif action.decision == 'no_show': valid = term.status == m.Termin.STATUS_NIJE_DOSAO
        elif action.decision == 'postpone':
            valid = (str(term.datum) == data.get('new_date') and term.status == m.Termin.STATUS_PLANIRANA) if data.get('new_date') else term.status == m.Termin.STATUS_ODGODJENA
        if valid: done.add(term.pk)
        else: changed.add(term.pk)
    result = []
    for finding in session.findings:
        if finding.get('id') in done: continue
        term = m.Termin.objects.select_related('pacijent', 'lijek').filter(pk=finding.get('id')).first()
        item = smart.card(term) if term else finding
        if finding.get('id') in changed:
            item.update(can_apply=False, can_status=False, warning='Ranije potvrđena evidencija je promijenjena; potrebna provjera povezanog događaja u auditu.')
        # A definitive change outside this process remains visible for review.
        if term and term.datum != events.day(finding['date']): item['warning'] = 'Podaci termina su promijenjeni; provjerite novu evidenciju.'
        result.append(item)
    return result


def receipt_cards(session, *, include_reviewed=False):
    result = []
    for finding in session.receipt_findings:
        request = m.Trebovanje.objects.filter(pk=finding['id']).select_related('pacijent', 'lijek', 'komisijski_ciklus', 'komisija').first()
        if not request:
            result.append(dict(**finding, warning='Komisijska stavka više nije dostupna; potrebna provjera.'))
            continue
        item = receipt_card(request)
        last = session.actions.filter(request=request).order_by('-pk').first()
        if last and last.decision != 'receipt_skip' and not (last.event_id and last.event.reversed_at) and last.summary.get('request_state') == request_state(request):
            if not include_reviewed: continue
            item['reviewed'] = True
        item['warning'] = 'Podaci su promijenjeni nakon prethodne provjere.' if last and not item.get('reviewed') else ''
        result.append(item)
    return result


def summary(session):
    token = begin_request_cache(enabled=False)
    try:
        therapies, receipts = therapy_cards(session), receipt_cards(session)
        reservations = reservation_findings(session)
        counts = [count_card(session, med) for med in relevant_medicines(session)]
        decisions = {}
        for a in session.actions.exclude(event__reversed_at__isnull=False): decisions[a.decision] = decisions.get(a.decision, 0) + 1
        receipts_by_medicine = {}
        automatically_released = 0
        for action in session.actions.exclude(event__reversed_at__isnull=False).select_related('event', 'unlinked_receipt'):
            if action.decision == 'receipt' and action.event_id:
                label, amount = str(action.event.medicine), action.event.quantity
                receipts_by_medicine[label] = receipts_by_medicine.get(label, Decimal(0)) + amount
            elif action.unlinked_receipt_id:
                label, amount = str(action.unlinked_receipt.medicine), action.unlinked_receipt.quantity
                receipts_by_medicine[label] = receipts_by_medicine.get(label, Decimal(0)) + amount
            if action.decision == 'therapy':
                automatically_released += sum(r['label'] == 'Zaduženje u frižideru' for r in action.summary.get('rows', []))
        unresolved = len(therapies) + len(receipts) + len(reservations) + sum(not c['aligned'] for c in counts)
        return dict(therapies=therapies, receipts=receipts, reservations=reservations, counts=counts,
            unresolved=unresolved, decisions=decisions, found=len(session.findings),
            resolved=session.actions.filter(appointment__isnull=False).exclude(decision='skip').exclude(event__reversed_at__isnull=False).count(),
            no_show=decisions.get('no_show', 0), postponed=decisions.get('postpone', 0), applied=decisions.get('therapy', 0),
            receipts_by_medicine=receipts_by_medicine, automatically_released=automatically_released,
            manual=decisions.get('physical', 0), actions=session.actions.select_related('event', 'user', 'unlinked_receipt', 'physical_correction'))
    finally:
        end_request_cache(token)


def advance(session_id, user, step, *, save_later=False):
    require(str(step) in {'1', '2', '3', '4', '5'}, 'Nepoznat korak.')
    with correction_transaction():
        session = own(session_id, user, lock=True); editable(session)
        session.current_step = int(step)
        session.preview = {}; session.preview_fingerprint = ''; session.revision += 1
        session.status = 'in_progress'
        session.save(update_fields=['current_step', 'preview', 'preview_fingerprint', 'revision', 'status', 'updated_at'])
        return session


def finish(session_id, user, *, cancel=False):
    with correction_transaction():
        session = refresh(session_id, user); session = own(session_id, user, lock=True)
        if session.status == 'cancelled': return session
        if cancel: session.status = 'cancelled'
        else: session.status = 'needs_review' if summary(session)['unresolved'] else 'aligned'
        session.current_step = 5; session.preview = {}; session.preview_fingerprint = ''; session.revision += 1
        session.save(update_fields=['status', 'current_step', 'preview', 'preview_fingerprint', 'revision', 'updated_at'])
        return session


def duplicate_receipts(data):
    medicine = m.Lijek.objects.get(pk=data['medicine_id'])
    when, quantity = events.day(data['event_date']), Decimal(data['quantity'])
    from .inventory_corrections import receipt_quantity, receipt_date
    found = []
    for tx in m.ZalihaTransakcija.objects.filter(lijek_id__in=medicine.equivalent_ids(), tip='ZAPRIMANJE').order_by('pk'):
        if receipt_date(tx) == when and (receipt_quantity(tx) == quantity or data.get('batch') and tx.serija == data['batch']):
            found.append(dict(id=tx.pk, date=str(receipt_date(tx)), quantity=str(receipt_quantity(tx)), batch=tx.serija,
                source=f'{tx.referenca_tip} #{tx.referenca_id or tx.pk}'))
    return found


def normalize(session, raw):
    editable(session)
    kind = raw.get('kind')
    if kind in ('physical', 'allocate', 'release', 'transfer', 'record'):
        from .correction_center import authorize
        authorize(session.user)
    require(kind in ('receipt', 'receipt_no', 'receipt_skip', 'unlinked', 'physical', 'allocate', 'release', 'transfer', 'record', 'home'), 'Odaberite podržanu radnju.')
    note = str(raw.get('note') or raw.get('reason') or '').strip()
    require(len(note) <= 2000, 'Napomena može imati najviše 2000 znakova.')
    data = dict(kind=kind, note=note)
    if kind in ('receipt', 'receipt_no', 'receipt_skip'):
        request = events.chosen(m.Trebovanje, raw.get('request_id'), 'komisijsku stavku')
        require(any(r['id'] == request.pk for r in session.receipt_findings), 'Stavka nije dio ovog perioda.')
        scope(session, request.lijek, request.pacijent)
        data.update(request_id=request.pk, medicine_id=request.lijek_id, patient_id=request.pacijent_id)
        if kind != 'receipt': return data
    else:
        medicine = events.chosen(m.Lijek, raw.get('medicine_id'), 'lijek / prezentaciju'); scope(session, medicine)
        data['medicine_id'] = medicine.pk
    if kind in ('receipt', 'unlinked', 'home'):
        when = events.day(raw.get('event_date'))
        require(session.period_start <= when <= session.period_end, 'Stvarni datum mora biti unutar perioda odsustva.')
        quantity = events.amount(raw.get('quantity'))
        data.update(event_date=str(when), quantity=str(quantity), batch=str(raw.get('batch') or '').strip(),
            expires=str(events.day(raw.get('expires'), optional=True) or ''),
            delivery_reference=str(raw.get('delivery_reference') or '').strip().casefold(),
            duplicate_ack=raw.get('duplicate_ack') in (True, 'yes'), partial=raw.get('partial') in (True, 'yes'))
        require(len(data['batch']) <= 100, 'Serija može imati najviše 100 znakova.')
        require(not data['expires'] or data['batch'] and events.day(data['expires']) >= when, 'Rok zahtijeva seriju i ne smije prethoditi prijemu.')
        if kind in ('receipt', 'unlinked'):
            require(2 <= len(data['delivery_reference']) <= 120, 'Unesite oznaku stvarne isporuke / otpremnice (2–120 znakova).')
            from .package_sizes import validate_package_multiple
            validate_package_multiple(quantity, m.Lijek.objects.get(pk=data['medicine_id']), label='Stvarni prijem')
            duplicates = duplicate_receipts(data)
            require(not duplicates or data['duplicate_ack'] and len(note) >= 5,
                'Moguće je da je ovaj prijem već evidentiran. '+ '; '.join(f"Promet #{d['id']}: {d['date']}, {d['quantity']}, {d['source']}" for d in duplicates)+'. Za zasebnu stvarnu isporuku potvrdite razliku i navedite dokaz u napomeni.')
        if kind == 'unlinked':
            require(len(note) >= 5, 'Prijem bez komisijske veze zahtijeva razlog / napomenu.')
            require(not m.UnlinkedStockReceipt.objects.filter(medicine_id=data['medicine_id'], delivery_reference=data['delivery_reference']).exists(), 'Oznaka ove isporuke već je evidentirana bez komisijske veze.')
            require(not m.RetrospectiveEvent.objects.filter(kind='receipt', medicine_id=data['medicine_id'], delivery_reference=data['delivery_reference'], reversed_at__isnull=True).exists(), 'Ova isporuka već je povezana sa komisijskim prijemom.')
        elif kind == 'receipt':
            require(not m.UnlinkedStockReceipt.objects.filter(medicine_id__in=request.lijek.equivalent_ids(),
                delivery_reference=data['delivery_reference']).exists(),
                'Ova isporuka već je evidentirana bez komisijske veze. Potrebna je provjera povezivanja postojećeg prijema; fizička zaliha se ne smije povećati ponovo.')
            from .commission_receiving import received_commission_quantity
            remaining = request.odobrene_doze-received_commission_quantity(request) if request.odobrene_doze is not None else 0
            require(data['partial'] or quantity == remaining, 'Za djelimičan prijem odaberite Djelimično je stigao.')
        else:
            patient = events.chosen(m.Pacijent, raw.get('patient_id'), 'pacijenta'); scope(session, medicine, patient)
            data.update(patient_id=patient.pk, commission_id=raw.get('commission_id'), history_confirmed=True)
    elif kind == 'physical':
        medicine = m.Lijek.objects.get(pk=data['medicine_id'])
        count = count_card(session, medicine)
        require(count.get('can_correct'), 'Prvo fizički prebrojite lijek i pregledajte moguće uzroke kroz Objasni razliku. Promijenjene podatke ponovo provjerite.')
        require(raw.get('unexplained_confirmed') in (True, 'yes'), 'Potvrdite da ste fizički prebrojali lijek i da nije moguće utvrditi događaj koji objašnjava razliku.')
        require(5 <= len(note) <= 500, 'Ručna korekcija zahtijeva razlog (5–500 znakova).')
        data.update(counted=count['counted'], quantity=str(raw.get('quantity') or count['counted']),
            scope=raw.get('scope') or 'TOTAL', batch=str(raw.get('batch') or '').strip(),
            expires=str(raw.get('expires') or ''), unexplained_confirmed=True)
    else:
        patient = events.chosen(m.Pacijent, raw.get('patient_id'), 'pacijenta'); scope(session, medicine, patient)
        require(any(r['patient_id'] == patient.pk and r['medicine_id'] == medicine.pk for r in reservation_findings(session)), 'Nije pronađeno preostalo neslaganje zaduženja za ovu radnju. Osvježite obračun.')
        target_kind, target_id = raw.get('target_kind'), raw.get('target_id')
        if raw.get('record_target'):
            parts = str(raw['record_target']).split(':')
            require(len(parts) == 2, 'Odaberite konkretan zapis.')
            target_kind, target_id = parts
        data.update(patient_id=patient.pk, quantity=str(raw.get('quantity') or ''), reservation_id=raw.get('reservation_id'),
            recipient_id=raw.get('recipient_id'), target_id=target_id, target_kind=target_kind,
            approval=raw.get('approval'), source_movement=raw.get('source_movement'),
            acknowledge_appointment=raw.get('acknowledge_appointment') in (True, 'yes'))
    return serial(data)


def reservation_totals():
    result = {}
    for r in m.PacijentRezervacija.objects.filter(aktivno=True).select_related('pacijent', 'lijek'):
        key = (r.pacijent_id, r.lijek_id, r.komisija_id, r.trebovanje_id, r.termin_id)
        row = result.setdefault(key, dict(label=f'{r.pacijent} · {r.lijek} · komisija #{r.komisija_id or "bez veze"}', quantity=Decimal(0)))
        row['quantity'] += r.kolicina
    return result


def physical_plan(data):
    from dashboard.stock_correction_forms import PhysicalStockCorrectionForm
    from .physical_stock_corrections import preview
    form = PhysicalStockCorrectionForm(dict(lijek=data['medicine_id'], kolicina=data['quantity'], razlog=data['note'],
        obuhvat=data['scope'], serija=data['batch'], rok_trajanja=data['expires'], datum_dogadjaja=str(timezone.localdate())))
    require(form.is_valid(), '; '.join(str(v) for v in form.errors.values()))
    plan = preview(form.cleaned_data)
    require(Decimal(str(plan['total_after'])) == Decimal(data['counted']), 'Korekcija serije mora odgovarati ukupnom fizičkom popisu. Provjerite količinu izabrane serije.')
    return plan


def execute(session, data, user, operation_id, backup, *, simulate=False):
    """Return a deterministic business preview and links to existing audit receipts."""
    kind = data['kind']; medicine = m.Lijek.objects.get(pk=data['medicine_id'])
    if kind in ('physical', 'allocate', 'release', 'transfer', 'record'):
        from .correction_center import authorize
        authorize(user)
    links = {}; rows = []; before = stock_state(medicine)['expected']
    request = m.Trebovanje.objects.get(pk=data['request_id']) if data.get('request_id') else None
    plan = dict(data=data, medicine=str(medicine), patient=str(request.pacijent) if request else '',
        decision='', reason=data['note'] or session.reason, rows=rows)
    def row(label, left, right, why='Potvrđen stvarni događaj prema postojećim pravilima.'):
        if str(left) != str(right): rows.append(dict(label=label, before=str(left), after=str(right), why=why))
    if kind in ('receipt_no', 'receipt_skip'):
        plan['decision'] = 'Nije stigao' if kind == 'receipt_no' else 'Ne znam / preskoči'
        row('Provjera prijema', 'Potrebna potvrda', plan['decision'], 'Fizička zaliha, pravo i rezervacije ostaju neizmijenjeni.')
    elif kind in ('receipt', 'home'):
        raw = dict(data, kind='receipt' if kind == 'receipt' else 'home', note=data['note'] or session.reason)
        event_plan = events.preview(raw, user, guided_session=session.pk)
        prior = reservation_totals()
        from .commission_receiving import received_commission_quantity
        received = received_commission_quantity(request) if request else None
        status = request.get_status_display() if request else None
        event = events.apply_plan(event_plan, user, operation_id, backup, guided_session=session.pk)
        links['event'] = event
        plan['decision'] = 'Djelimično zaprimanje' if data.get('partial') else 'Komisijsko zaprimanje' if kind == 'receipt' else 'Naknadno kućno izdavanje'
        row('Fizičko stanje u frižideru', before, stock_state(medicine)['expected'])
        if request:
            request.refresh_from_db()
            row('Komisijski zapis — zaprimljeno / odobreno', f'{received}/{request.odobrene_doze}', f'{received_commission_quantity(request)}/{request.odobrene_doze}')
            row('Status komisijske stavke', status, request.get_status_display())
        else:
            plan['patient'] = str(event.patient)
            rows.extend(dict(r, why='Postojeći servis kućnog izdavanja; datum primjene kod kuće nije upisan.') for r in event_plan['rows'] if 'Fizička' not in r['label'])
        after = reservation_totals()
        for key in sorted(set(prior) | set(after), key=str):
            left, right = prior.get(key, {}), after.get(key, {})
            row('Zaduženje: '+(right or left)['label'], left.get('quantity', 0), right.get('quantity', 0))
        plan['duplicates'] = duplicate_receipts(data) if kind == 'receipt' else []
        # Newly simulated receipt is not itself a duplicate warning.
        if kind == 'receipt': plan['duplicates'] = [d for d in plan['duplicates'] if d['id'] not in event.movements.values_list('pk', flat=True)]
    elif kind == 'unlinked':
        from dashboard.views import promijeni_zalihu
        from .inventory_trace import stock_action
        from .retrospective_inventory import check_history
        from .inventory import izracunaj_frizider_iz_transakcija
        check_history(medicine, events.day(data['event_date']), Decimal(data['quantity']), batch=data['batch'], expires=events.day(data['expires'], optional=True))
        plan['duplicates'] = duplicate_receipts(data)
        with stock_action(operation_id=operation_id):
            stock, movement = promijeni_zalihu(lijek=medicine, kolicina=data['quantity'], frizider_delta=data['quantity'],
                korisnik=user, akcija=UNLINKED, opis=UNLINKED+' '+data['note'], datum=events.day(data['event_date']),
                vrati_transakciju=True, tip_transakcije='ZAPRIMANJE', serija=data['batch'], rok_trajanja=events.day(data['expires'], optional=True))
        receipt = m.UnlinkedStockReceipt.objects.create(operation_id=operation_id, user=user, medicine=medicine,
            event_date=events.day(data['event_date']), quantity=data['quantity'], batch=data['batch'],
            expires=events.day(data['expires'], optional=True), note=data['note'], delivery_reference=data['delivery_reference'], movement=movement, backup=backup)
        movement.referenca_tip = 'UnlinkedStockReceipt'; movement.referenca_id = receipt.pk
        movement.save(update_fields=['referenca_tip', 'referenca_id'])
        require(izracunaj_frizider_iz_transakcija(medicine) == stock.u_frizideru, 'Kontrola prometa prijema nije prošla; cijeli događaj je vraćen.')
        links['unlinked_receipt'] = receipt; plan['decision'] = UNLINKED
        row('Fizičko stanje u frižideru', before, stock.u_frizideru)
        plan['warnings'] = ['Komisijsko pravo i odobrenja ostaju neizmijenjeni. Lijek se ne dodjeljuje pacijentu.']
    elif kind == 'physical':
        from .physical_stock_corrections import apply_plan
        count_plan = physical_plan(data)
        receipt, _ = apply_plan(count_plan, user, operation_id, backup)
        links['physical_correction'] = receipt; plan['decision'] = 'Ispravka prema fizičkom popisu'
        row('Fizičko stanje u frižideru', count_plan['total_before'], count_plan['total_after'], data['note'])
        row('Razlika', '0', count_plan['delta_display'], data['note'])
        plan['warnings'] = count_plan['warnings']
    else:
        patient = m.Pacijent.objects.get(pk=data['patient_id']); plan['patient'] = str(patient)
        if kind in ('allocate', 'release'):
            from .correction_center import allocation_plan, apply_allocation_plan
            p = allocation_plan(patient, medicine, dict(kind=kind, quantity=data['quantity'], reason=data['note'], reservation_id=data['reservation_id'], acknowledge_appointment=data['acknowledge_appointment']), user)
            receipt, _ = apply_allocation_plan(p, user, operation_id, backup)
            links['data_correction'] = receipt
            plan['decision'] = p['title']; rows.extend(p['rows']); plan['warnings'] = p['warnings']
        elif kind == 'transfer':
            from . import quick_changes
            raw = dict(primalac=data['recipient_id'], rezervacija=data['reservation_id'], kolicina=data['quantity'], razlog=data['note'])
            require(patient.lijek_id == medicine.pk, 'Potrebna provjera terapijskog plana / naloga ljekara: prijenos mora koristiti istu prezentaciju pacijenta.')
            p = quick_changes.preview(patient, 'transfer', raw, user)
            plan['decision'] = 'Prenesi zaduženje'; rows.extend(p['rows'])
            if not simulate:
                _, token = quick_changes.make_preview(patient, 'transfer', raw, user)
                receipt, _ = quick_changes.confirm(token, patient, user); links['quick_change'] = receipt
        else:
            from . import inventory_corrections
            raw = dict(quantity=data['quantity'], reason=data['note'], event_date=str(timezone.localdate()), context_patient_id=patient.pk)
            require(data['target_kind'] in ('allocation', 'patient_stock'), 'Odaberite raspodjelu prijema ili konkretno pacijentovo zaduženje.')
            target, _ = inventory_corrections.target_context(data['target_kind'], data['target_id'])
            if data['target_kind'] == 'allocation' and target.fizicka_transakcija_id:
                raw['event_date'] = str(inventory_corrections.receipt_date(target.fizicka_transakcija))
            if data['target_kind'] == 'patient_stock':
                raw.update(source_mode='EXISTING', approval=data['approval'], source_movement=data['source_movement'])
            p = inventory_corrections.preview(data['target_kind'], data['target_id'], raw, user)
            require(p.get('patient_id') == patient.pk and p.get('medicine_id') == medicine.pk, 'Konkretan zapis nije dio odabranog zaduženja.')
            plan['decision'] = 'Ispravi konkretan zapis'; rows.extend(p['rows'])
            if not simulate:
                _, token = inventory_corrections.make_preview(data['target_kind'], data['target_id'], raw, user)
                receipt, _ = inventory_corrections.confirm(token, user, kind=data['target_kind'], target_id=data['target_id'])
                links['data_correction'] = receipt
    if request: plan['request_state'] = request_state(request)
    return serial(plan), links


def prepare(session_id, raw, user):
    with correction_transaction():
        session = own(session_id, user, lock=True); data = normalize(session, raw)
        fingerprint = digest(smart.domain_snapshot()); operation_id = uuid.uuid4()
        with transaction.atomic():
            plan, _ = execute(session, data, user, operation_id, {}, simulate=True)
            transaction.set_rollback(True)
        require(fingerprint == digest(smart.domain_snapshot()), 'Preview nije prošao kontrolu; ništa nije primijenjeno.')
        session.preview = dict(source='absence', plan=plan, operation_id=str(operation_id), prepared_at=timezone.now().isoformat())
        session.preview_fingerprint = fingerprint; session.revision += 1; session.status = 'in_progress'
        session.save(update_fields=['preview', 'preview_fingerprint', 'revision', 'status', 'updated_at'])
        return plan, preview_token(session, user)


def preview_token(session, user):
    require(session.user_id == user.pk and session.preview.get('source') == 'absence', smart.STALE)
    return signing.dumps(dict(session=session.pk, revision=session.revision, operation_id=session.preview['operation_id'],
        fingerprint=session.preview_fingerprint, user=user.pk), salt=SALT, compress=True)


def confirm(token, user, *, session_id):
    smart.authorize(user)
    try: payload = signing.loads(token, salt=SALT)
    except signing.BadSignature: raise events.CorrectionBlocked('Pregled nije važeći; ponovite provjeru.') from None
    require(payload.get('user') == user.pk and payload.get('session') == session_id, 'Potvrda ne pripada ovom korisniku i sessionu.')
    with correction_transaction():
        session = own(session_id, user, lock=True)
        existing = session.actions.filter(operation_id=payload['operation_id']).first()
        if existing: return existing, False
        try: signing.loads(token, salt=SALT, max_age=1800)
        except signing.BadSignature: raise events.CorrectionBlocked('Pregled je istekao; ponovite provjeru.') from None
        editable(session)
        require(session.revision == payload['revision'] and session.preview.get('source') == 'absence'
            and session.preview.get('operation_id') == payload['operation_id']
            and digest(smart.domain_snapshot()) == payload['fingerprint'], smart.STALE)
        data = normalize(session, session.preview['plan']['data'])
        backup = backup_before_correction(payload['operation_id']) if data['kind'] not in ('receipt_no', 'receipt_skip') else {}
        plan, links = execute(session, data, user, payload['operation_id'], backup)
        require(plan == session.preview['plan'], smart.STALE)
        if 'quick_change' in links:
            plan = dict(plan, backup=backup)
        action = m.ReconciliationAction.objects.create(session=session, user=user, operation_id=payload['operation_id'],
            decision=data['kind'], request_id=data.get('request_id'), summary=plan, **links)
        if data['kind'] in ('receipt_no', 'receipt_skip'):
            from .utils import upisi_log
            upisi_log(user, 'Provjera stvarnog prijema', objekat=action, opis=f'Period #{session.pk}: {plan["decision"]}. {plan["reason"]}')
        session.preview = {}; session.preview_fingerprint = ''; session.revision += 1; session.status = 'in_progress'
        session.save(update_fields=['preview', 'preview_fingerprint', 'revision', 'status', 'updated_at'])
        return action, True


def record_count(session_id, medicine_id, counted, user, *, operation_id):
    with correction_transaction():
        session = own(session_id, user, lock=True); editable(session)
        existing = session.actions.filter(operation_id=operation_id).first()
        if existing: return existing, False
        medicine = events.chosen(m.Lijek, medicine_id, 'lijek'); scope(session, medicine)
        require(medicine.pk in {med.pk for med in relevant_medicines(session)}, 'Lijek nije relevantan za ovaj session.')
        try: value = Decimal(str(counted))
        except Exception: raise events.CorrectionBlocked('Unesite fizički prebrojanu količinu.') from None
        require(value.is_finite() and 0 <= value <= 999999 and value == value.to_integral_value(), 'Popis zahtijeva nenegativan cijeli broj pojedinačnih jedinica.')
        state = stock_state(medicine)
        observation = serial(dict(counted=str(value), state=state, created_at=timezone.now().isoformat(), user_id=user.pk))
        session.physical_counts[str(medicine.pk)] = observation
        session.preview = {}; session.preview_fingerprint = ''; session.revision += 1; session.status = 'in_progress'
        session.save(update_fields=['physical_counts', 'preview', 'preview_fingerprint', 'revision', 'status', 'updated_at'])
        plan = dict(decision='Fizička kontrola', medicine=str(medicine), reason=session.reason,
            data=dict(medicine_id=medicine.pk), rows=[dict(label='TheraFlow / fizički prebrojano', before=str(state['expected']), after=str(value), why='Samo kontrola; zaliha nije izmijenjena.')])
        action = m.ReconciliationAction.objects.create(session=session, user=user, operation_id=operation_id, decision='count', summary=plan)
        from .utils import upisi_log
        upisi_log(user, 'Fizička kontrola tokom usklađivanja', objekat=action, opis=f'Period #{session.pk}: {medicine}, {state["expected"]}/{value}. Bez korekcije zalihe.')
        return action, True


def explanations(session, medicine):
    """Evidence-based investigation candidates, never a diagnosis or clinical edit."""
    scope(session, medicine)
    info = summary(session); result = []
    for t in info['therapies']:
        if t['medicine_id'] == medicine.pk:
            result.append(dict(category='Moguća neevidentirana terapija', label=f"Mogući uzrok: {t['patient']} · {t['date_label']} · {t['warning'] or 'stvarna primjena nije potvrđena'}", step=1))
    home_patients = m.Pacijent.objects.filter(lijek=medicine)
    if session.patient_id: home_patients = home_patients.filter(pk=session.patient_id)
    if medicine.kucna_terapija:
        for p in home_patients:
            has_issue = m.KucnoIzdavanje.objects.filter(pacijent=p, lijek=medicine, datum__range=(session.period_start, session.period_end)).exists()
            if not has_issue:
                result.append(dict(category='Moguće neevidentirano kućno izdavanje', label=f'Mogući uzrok: {p} nema evidentirano kućno izdavanje u periodu; provjerite stvarnu predaju.', step=4, patient_id=p.pk))
    for r in info['receipts']:
        if r['medicine_id'] == medicine.pk:
            result.append(dict(category='Moguće neevidentirano zaprimanje', label=f"Mogući uzrok: {r['cycle']} · {r['patient']} · zaprimljeno {r['received']}/{r['approved']}", step=2))
    for r in info['reservations']:
        if r['medicine_id'] == medicine.pk:
            category = 'Rezervacija bez odgovarajućeg događaja' if any('bez dokumentovane' in x for x in r['reasons']) else 'Aktivno/pogrešno zaduženje'
            result.append(dict(category=category, label='Mogući uzrok: '+r['patient']+' · '+' '.join(r['reasons']), step=3))
    for tx in m.ZalihaTransakcija.objects.filter(lijek=medicine, datum__range=(session.period_start, session.period_end), tip__in=['OTPIS', 'KOREKCIJA']):
        result.append(dict(category='Otpis/korekcija', label=f'Mogući uzrok: promet #{tx.pk} · {tx.datum} · {tx.kolicina} · {tx.napomena}', step=4))
    result.append(dict(category='Neobjašnjena razlika', label='Mogući uzrok nije potvrđen. Provjerite stvarne prijeme, izdavanja i dokumentaciju prije ručne korekcije.', step=4))
    return result


def explain(session_id, medicine_id, user):
    with correction_transaction():
        session = own(session_id, user, lock=True); editable(session)
        medicine = events.chosen(m.Lijek, medicine_id, 'lijek'); scope(session, medicine)
        count = count_card(session, medicine)
        require(count['observation'] and not count['stale'] and not count['aligned'], 'Prvo unesite važeći fizički popis koji pokazuje razliku.')
        result = explanations(session, medicine)
        session.physical_counts[str(medicine.pk)]['explained_fingerprint'] = digest(stock_state(medicine))
        session.save(update_fields=['physical_counts', 'updated_at'])
        return result
