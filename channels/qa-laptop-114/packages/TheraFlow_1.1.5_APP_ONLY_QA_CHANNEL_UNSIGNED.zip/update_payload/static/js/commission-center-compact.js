/* Keep the original confirmation count; show its cycle's readable label. */
(() => {
    const page = document.querySelector('.cc-page');
    const id = page?.dataset.ccCycleId;
    const name = page?.dataset.ccCycleInternalName;
    if (!/^\d+$/.test(id || '') || !/^KC-[0-9a-f]{32}$/.test(name || '')) return;
    const prefix = `Prijedlog komisije je sačuvan kao ${name}. Kreirano trebovanja: `;
    document.querySelectorAll('.tf-toast.success .tf-toast-body').forEach(toast => {
        const text = toast.textContent.trim();
        if (!text.startsWith(prefix)) return;
        const count = text.slice(prefix.length).match(/^(\d+)\.$/);
        if (count) toast.textContent = `Prijedlog komisije #${id} je sačuvan. Kreirano trebovanja: ${count[1]}.`;
    });
})();

/* Cycle selection is a full navigation: never retain hidden row selections. */
(() => {
    const page = document.querySelector('.cc-page');
    if (!page) return;
    const checks = [...page.querySelectorAll('.trebovanje-check')];
    const all = page.querySelector('#select-all');
    const update = () => {
        const selected = checks.filter(input => input.checked);
        page.querySelectorAll('[data-selection-count]').forEach(node => { node.textContent = selected.length; });
        const print = page.querySelector('[data-batch-print]');
        const send = page.querySelector('[data-batch-send]');
        if (print) print.disabled = !selected.length;
        if (send) send.disabled = !selected.length || selected.some(input => input.dataset.sendable !== 'true');
        if (all) {
            all.checked = checks.length > 0 && selected.length === checks.length;
            all.indeterminate = selected.length > 0 && selected.length < checks.length;
        }
    };
    const clear = () => { checks.forEach(input => { input.checked = false; }); update(); };
    if (all) all.addEventListener('change', () => { checks.forEach(input => { input.checked = all.checked; }); update(); });
    checks.forEach(input => input.addEventListener('change', update));
    page.querySelectorAll('[data-cycle-picker]').forEach(select => select.addEventListener('change', () => {
        clear();
        select.form.requestSubmit();
    }));
    window.addEventListener('pageshow', clear); // Includes history/back-forward cache.
    clear();
    page.addEventListener('invalid', event => {
        let parent = event.target.parentElement;
        while (parent && parent !== page) {
            if (parent.tagName === 'DETAILS') parent.open = true;
            parent = parent.parentElement;
        }
    }, true);
})();

/* Refresh live proposals without discarding a review or a manual edit. */
(() => {
    const page = document.querySelector('[data-live-commission]');
    if (!page) return;
    let busy = false, dirty = false;
    page.addEventListener('input', event => {
        if (event.target.closest('[data-commission-confirmation], .cc-manual-form')) dirty = true;
    });
    const paused = () => !page.isConnected || dirty || document.hidden || page.querySelector('dialog[open]') || page.contains(document.activeElement) && document.activeElement.matches('input, textarea, select');
    const refresh = async () => {
        if (busy || paused()) return;
        busy = true;
        try {
            const response = await fetch(window.location.href, {credentials: 'same-origin', cache: 'no-store', headers: {'X-Requested-With': 'XMLHttpRequest'}});
            if (!response.ok || response.redirected) return;
            const fresh = new DOMParser().parseFromString(await response.text(), 'text/html');
            const next = fresh.querySelector('[data-live-commission]');
            // A review may have opened or changed while the GET was in flight.
            if (!next || paused()) return;
            // Delegated modal handlers and form submission survive replacement.
            for (const selector of ['[data-commission-actions]', '[data-commission-summary]', '[data-commission-confirmation]', '.commission-filters', '.commission-table-wrap', '.commission-summary-card']) {
                const current = page.querySelector(selector), updated = next.querySelector(selector);
                if (current && updated) current.replaceWith(updated);
            }
        } catch (_) { /* Keep the current reviewed data; confirmation revalidates it. */ }
        finally { busy = false; }
    };
    window.addEventListener('focus', refresh);
    window.setInterval(refresh, 60000);
})();

/* Each decision editor opens on demand; selected requests share a real full decision. */
(() => {
    const page = document.querySelector('.cc-page');
    if (!page) return;
    const setExpanded = (id, open, focus = false) => {
        const editor = document.getElementById(id);
        if (!editor) return;
        editor.hidden = !open;
        page.querySelectorAll('[data-commission-row-toggle]').forEach(button => {
            if (button.getAttribute('aria-controls') === id) button.setAttribute('aria-expanded', String(open));
        });
        if (focus && open) editor.querySelector('select, input:not([type="hidden"]), button')?.focus();
    };
    page.addEventListener('click', event => {
        const toggle = event.target.closest('[data-commission-row-toggle]');
        if (!toggle) return;
        const id = toggle.getAttribute('aria-controls');
        const editor = document.getElementById(id);
        if (editor) setExpanded(id, editor.hidden, true);
    });
    page.addEventListener('invalid', event => {
        const editor = event.target.closest('.cc-editor-row');
        if (editor) setExpanded(editor.id, true);
    }, true);

    const choices = [...page.querySelectorAll('[data-decision-check]')];
    const selectAll = page.querySelector('[data-decision-select-all]');
    const confirmation = page.querySelector('[data-full-decision-confirmed]');
    const submit = page.querySelector('[data-batch-decision-submit]');
    const updateSelection = () => {
        const selected = choices.filter(input => input.checked);
        page.querySelectorAll('[data-decision-selection-count]').forEach(node => { node.textContent = selected.length; });
        if (submit) submit.disabled = !selected.length || !confirmation?.checked;
        if (selectAll) {
            selectAll.checked = choices.length > 0 && selected.length === choices.length;
            selectAll.indeterminate = selected.length > 0 && selected.length < choices.length;
        }
    };
    choices.forEach(input => input.addEventListener('change', updateSelection));
    selectAll?.addEventListener('change', () => { choices.forEach(input => { input.checked = selectAll.checked; }); updateSelection(); });
    confirmation?.addEventListener('change', updateSelection);
    window.addEventListener('pageshow', () => {
        choices.forEach(input => { input.checked = false; });
        if (confirmation) confirmation.checked = false;
        updateSelection();
    });
    updateSelection();

    const syncDecision = (decision, changed = false) => {
        const form = decision.form;
        if (!form) return;
        const pending = decision.value === 'ceka';
        const partial = decision.value === 'djelimicno_odobreno';
        [...form.elements].forEach(input => {
            if (input.matches('[data-approved-quantity]')) {
                input.disabled = pending;
                input.readOnly = !partial;
                input.required = partial;
                if (decision.value === 'odobreno') input.value = input.dataset.requested || '0';
                else if (decision.value === 'odbijeno') input.value = '0';
                else if (partial && changed) input.value = '';
            } else if (input.name.endsWith('-datum_saglasnosti')) {
                input.disabled = pending;
                input.required = !pending;
            } else if (input.name.endsWith('-broj_saglasnosti')) {
                input.disabled = pending;
                input.required = decision.value === 'odobreno' || partial;
            }
        });
    };
    page.querySelectorAll('[data-agreement-decision]').forEach(decision => {
        syncDecision(decision);
        decision.addEventListener('change', () => syncDecision(decision, true));
    });
})();

/* Render the existing authorized GET editor in a drawer. Its POST stays native. */
(() => {
    const page = document.querySelector('.cc-page');
    if (!page || typeof HTMLDialogElement === 'undefined' || !HTMLDialogElement.prototype.showModal) return;
    const drawer = document.createElement('dialog');
    drawer.className = 'cc-drawer cc-request-edit-drawer';
    drawer.setAttribute('aria-labelledby', 'cc-request-edit-title');
    drawer.innerHTML = '<div class="commission-why-modal" tabindex="-1"><header><div><span>Komisijski zahtjev</span><h2 id="cc-request-edit-title">Uredi zahtjev</h2></div><button type="button" class="commission-why-close" data-edit-drawer-close aria-label="Zatvori uređivanje"><i class="bi bi-x-lg" aria-hidden="true"></i></button></header><div data-edit-drawer-content></div></div>';
    page.append(drawer);
    const content = drawer.querySelector('[data-edit-drawer-content]');
    const close = drawer.querySelector('[data-edit-drawer-close]');
    let controller, opener, editURL, loadNumber = 0;
    drawer.addEventListener('click', event => {
        if (event.target === drawer || event.target.closest('[data-edit-drawer-close]')) drawer.close();
    });
    drawer.addEventListener('close', () => {
        loadNumber++;
        controller?.abort();
        content.replaceChildren();
        const available = opener?.isConnected && !opener.closest('dialog:not([open])');
        const fallback = [...page.querySelectorAll('a[data-commission-edit-drawer]')].find(link => link.href === editURL && !link.closest('dialog:not([open])'));
        (available ? opener : fallback)?.focus({preventScroll: true});
    });
    page.addEventListener('click', async event => {
        const link = event.target.closest('a[data-commission-edit-drawer]');
        if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        const target = new URL(link.href, window.location.href);
        if (target.origin !== window.location.origin) return;
        event.preventDefault();
        controller?.abort();
        controller = new AbortController();
        const signal = controller.signal;
        const number = ++loadNumber;
        opener = link;
        editURL = target.href;
        link.closest('dialog[open]')?.close();
        content.innerHTML = '<p class="cc-drawer-loading" role="status">Učitavanje zahtjeva…</p>';
        if (!drawer.open) drawer.showModal();
        close.focus({preventScroll: true});
        try {
            const response = await fetch(target.href, {credentials: 'same-origin', cache: 'no-store', signal});
            if (!response.ok || response.redirected || new URL(response.url).pathname !== target.pathname) throw new Error('Editor unavailable');
            const documentCopy = new DOMParser().parseFromString(await response.text(), 'text/html');
            const editor = documentCopy.querySelector('.commission-request-edit-page');
            const form = editor?.querySelector('form.commission-request-edit-form[method="post"]');
            if (!form || !form.querySelector('[name="csrfmiddlewaretoken"]')) throw new Error('Editor missing');
            // Older template snapshots omit action: posting the drawer must use its own endpoint.
            form.action = target.href;
            editor.querySelectorAll('script').forEach(script => script.remove());
            if (signal.aborted || number !== loadNumber || !drawer.open) return;
            content.replaceChildren(editor);
            editor.querySelector('.errorlist + input, .errorlist + select')?.focus({preventScroll: true});
        } catch (error) {
            if (signal.aborted || number !== loadNumber || !drawer.open) return;
            const message = document.createElement('p');
            message.setAttribute('role', 'alert');
            message.textContent = 'Zahtjev nije moguće učitati u panel. Otvorite postojeću stranicu za uređivanje.';
            const fallback = document.createElement('a');
            fallback.className = 'tf-btn-secondary';
            fallback.href = target.href;
            fallback.textContent = 'Otvori zahtjev';
            content.replaceChildren(message, fallback);
        }
    });
})();
