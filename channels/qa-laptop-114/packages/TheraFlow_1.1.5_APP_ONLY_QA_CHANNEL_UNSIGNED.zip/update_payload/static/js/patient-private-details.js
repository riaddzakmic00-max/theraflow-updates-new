/* Keep the patient disclosure within the visible area, including short screens. */
(() => {
    const details = document.querySelector('.tf-patient-private-details');
    if (!details) return;
    const panel = details.querySelector('dl');
    const summary = details.querySelector('summary');
    const topbar = document.querySelector('.tf-topbar');
    panel.tabIndex = 0; // Keyboard users can scroll a height-constrained panel.

    function positionPanel() {
        if (!details.open) return;
        const viewport = window.visualViewport;
        const viewportLeft = viewport?.offsetLeft || 0;
        const viewportTop = viewport?.offsetTop || 0;
        const width = viewport?.width || document.documentElement.clientWidth;
        const height = viewport?.height || window.innerHeight;
        const margin = 12;
        const gap = 8;
        const bottom = viewportTop + height - margin;
        const top = Math.min(bottom, Math.max(viewportTop + margin,
            (topbar?.getBoundingClientRect().bottom || 0) + gap));
        panel.style.maxWidth = `${Math.max(0, width - 2 * margin)}px`;
        const anchor = details.getBoundingClientRect();
        const trigger = summary.getBoundingClientRect();
        const panelWidth = panel.getBoundingClientRect().width;
        const preferredLeft = window.matchMedia('(max-width: 760px)').matches
            ? anchor.left : anchor.right - panelWidth;
        const left = Math.max(viewportLeft + margin,
            Math.min(preferredLeft, viewportLeft + width - margin - panelWidth));
        const below = Math.max(0, bottom - Math.max(top, trigger.bottom + gap));
        const above = Math.max(0, Math.min(bottom, trigger.top - gap) - top);
        const naturalHeight = panel.scrollHeight + 2; // Includes the two border pixels.
        const openBelow = naturalHeight <= below || below >= above;
        const available = openBelow ? below : above;
        const panelHeight = Math.min(naturalHeight, available);
        const y = openBelow ? Math.max(top, trigger.bottom + gap)
            : Math.min(bottom, trigger.top - gap) - panelHeight;
        panel.style.setProperty('--patient-private-left', `${left - anchor.left}px`);
        panel.style.setProperty('--patient-private-right', 'auto');
        panel.style.setProperty('--patient-private-top', `${y - anchor.top}px`);
        panel.style.setProperty('--patient-private-height', `${available}px`);
    }

    details.addEventListener('toggle', positionPanel);
    window.addEventListener('resize', positionPanel);
    window.addEventListener('scroll', positionPanel, {capture: true, passive: true});
    window.visualViewport?.addEventListener('resize', positionPanel);
    window.visualViewport?.addEventListener('scroll', positionPanel);
    details.addEventListener('keydown', event => {
        if (event.key === 'Escape' && details.open) {
            details.open = false;
            summary.focus();
            event.preventDefault();
        }
    });
    positionPanel();
})();
