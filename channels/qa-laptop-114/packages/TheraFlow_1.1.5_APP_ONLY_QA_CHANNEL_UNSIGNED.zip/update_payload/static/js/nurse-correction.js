document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('[data-nurse-form]');
  if (!form) return;
  const show = (group, visible) => {
    group.hidden = !visible;
    group.querySelectorAll('input,select,textarea').forEach(input => {
      input.disabled = !visible;
      if (['reservation_id','skip_reason','commission_id'].includes(input.name)) input.required = visible;
    });
  };
  const update = () => {
    form.querySelectorAll('[data-depends]').forEach(group => show(group, !!form.elements[group.dataset.depends]?.checked));
    const choice = form.querySelector('[name="accounting_choice"]:checked')?.value;
    form.querySelectorAll('[data-effects]').forEach(group => show(group, group.dataset.effects.split(' ').includes(choice)));
    const approval = form.elements.approval_action?.value;
    form.querySelectorAll('[data-approval]').forEach(group => show(group, ['consume','already'].includes(approval)));
    form.querySelectorAll('[data-iv-dose]').forEach(group => show(group,
      group.dataset.programs.split(',').includes(form.elements.nova_terapija?.value)));
  };
  form.addEventListener('change', update);
  const catalogue = document.getElementById('late-event-catalogue');
  if (catalogue) {
    const products = JSON.parse(catalogue.textContent);
    const medicine = form.elements.medicine_id;
    const route = form.elements.route;
    const refresh = form.querySelector('[data-refresh-sources]');
    const clearSources = () => {
      ['reservation_id', 'commission_id', 'source_id', 'approval_source'].forEach(name => {
        if (form.elements[name]) form.elements[name].value = '';
      });
    };
    medicine?.addEventListener('change', () => {
      const product = products.find(item => item.id === medicine.value);
      if (route) route.value = product?.route || '';
      clearSources();
      if (refresh) form.requestSubmit(refresh);
    });
    route?.addEventListener('change', () => {
      const selected = products.find(item => item.id === medicine.value);
      if (selected?.route !== route.value) medicine.value = '';
      Array.from(medicine.options).forEach(option => {
        const product = products.find(item => item.id === option.value);
        option.hidden = !!option.value && product?.route !== route.value;
        option.disabled = option.hidden;
      });
      clearSources();
    });
    form.elements.event_date?.addEventListener('change', () => {
      clearSources();
      if (refresh) form.requestSubmit(refresh);
    });
  }
  update();
});
