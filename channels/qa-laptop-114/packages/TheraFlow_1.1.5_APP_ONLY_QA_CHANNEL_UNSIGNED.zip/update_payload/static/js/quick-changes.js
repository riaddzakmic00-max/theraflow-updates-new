(() => {
    const dialog = document.getElementById('tf-quick-dialog');
    if (!dialog || dialog.dataset.quickInitialized) return;
    dialog.dataset.quickInitialized = 'true';
    const body = dialog.querySelector('[data-quick-body]');
    const notice = dialog.querySelector('[data-quick-error]');
    const progress = dialog.querySelector('[data-quick-status]');
    const storageKey = 'theraflow.quick.pending.' + dialog.dataset.quickOwner;
    let pending = false, serial = 0, controller, retry, draft, currentUrl, uncertain, checkedToken;
    try { uncertain = JSON.parse(sessionStorage.getItem(storageKey) || 'null'); } catch (_) {}
    function remember(value) {
        uncertain = value;
        checkedToken = null;
        try {
            if (value) sessionStorage.setItem(storageKey, JSON.stringify(value));
            else sessionStorage.removeItem(storageKey);
        } catch (_) { /* In-memory recovery remains available. */ }
    }
    function clearError() { notice.replaceChildren(); notice.hidden = true; }
    function error(message, task) {
        retry = task;
        const text = document.createElement('p'); text.textContent = message;
        const button = document.createElement('button'); button.type = 'button';
        button.className = 'tf-btn-secondary'; button.dataset.quickRetry = '';
        button.textContent = uncertain ? 'Provjeri spremanje' : 'Pokušaj ponovo';
        notice.replaceChildren(text, button); notice.hidden = false;
    }
    function post(action, token) {
        const data = new FormData(); data.set('action', action); data.set('token', token);
        data.set('csrfmiddlewaretoken', document.querySelector('[name="csrfmiddlewaretoken"]')?.value || '');
        return data;
    }
    function show(html) {
        body.innerHTML = html; body.scrollTop = 0;
        body.querySelector('h2')?.focus({preventScroll:true});
    }
    function close() {
        // Dismissal cannot undo a submitted save; retain its operation for recovery.
        if (pending && uncertain) return;
        serial++; controller?.abort(); pending = false;
        progress.hidden = true; dialog.removeAttribute('aria-busy'); dialog.close();
    }
    async function load(task) {
        if (pending) return;
        const requestId = ++serial;
        pending = true; clearError();
        if (!dialog.open) dialog.showModal();
        const disabled = [...dialog.querySelectorAll('input,select,textarea,button[type="submit"]')].filter(el => !el.disabled);
        disabled.forEach(el => el.disabled = true);
        const saving = task.action === 'confirm' || task.action === 'status';
        dialog.querySelectorAll('[data-quick-close]').forEach(el => el.disabled = saving);
        progress.textContent = {open:'Učitavanje obrasca…',preview:'Priprema pregleda…',confirm:'Spremanje promjene…',status:'Provjeravam je li promjena sačuvana…'}[task.action];
        progress.hidden = false; dialog.setAttribute('aria-busy','true');
        controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000);
        if (task.action === 'confirm') remember({url:task.url, token:task.data.get('token')});
        const method = task.action === 'open' ? 'GET' : 'POST';
        let keepStatus = false;
        try {
            const url = new URL(task.url, location.href);
            if (url.origin !== location.origin) throw new Error('InvalidOrigin');
            const response = await fetch(url.href, {method, body:method === 'POST' ? task.data : undefined,
                credentials:'same-origin', cache:'no-store', signal:controller.signal,
                headers:{'X-Requested-With':'TheraFlowQuickChange'}});
            if (requestId !== serial) return;
            if (response.redirected || response.status === 401 || response.status === 403) throw new Error('Prijava');
            if (response.status !== 422 && !response.ok) throw new Error('HTTP ' + response.status);
            if (task.action === 'status') {
                const result = await response.json();
                if (requestId !== serial) return;
                if (!['saved','not_saved','review_required'].includes(result.state) || !result.html) throw new Error('Odgovor');
                show(result.html);
                if (result.state !== 'not_saved') remember(null);
                else {
                    checkedToken = uncertain.token;
                    progress.textContent = 'Provjera završena: promjena nije sačuvana. Možete ponoviti istu potvrdu.';
                    keepStatus = true;
                }
            } else {
                const html = await response.text();
                if (requestId !== serial) return;
                if (!response.headers.get('X-TheraFlow-Quick-Result')) throw new Error('Odgovor');
                if (task.action === 'preview') {
                    disabled.forEach(el => el.disabled = false);
                    draft = [...body.childNodes];
                }
                show(html);
                if (task.action === 'confirm') remember(null);
            }
        } catch (err) {
            if (requestId !== serial) return;
            console.error('TheraFlow brze izmjene', task.action, method, task.url, err.name, err.message);
            const label = {open:'Otvaranje obrasca',preview:'Pregled promjene',confirm:'Spremanje promjene',status:'Provjera spremanja'}[task.action];
            const message = err.message === 'Prijava' ? label + ': prijava je istekla ili nemate ovlaštenje. Prijavite se ponovo; unos je sačuvan u ovom prozoru.' :
                uncertain ? 'Odgovor o spremanju nije primljen. Prvo provjerite je li promjena sačuvana. Nova promjena neće biti poslana tokom provjere.' :
                'Radnja nije uspjela (' + label.toLowerCase() + '). Veza s aplikacijom je prekinuta ili server nije dostupan. Unesene vrijednosti su sačuvane; pokušajte ponovo.';
            error(message, task);
        } finally {
            clearTimeout(timeout);
            // Detached old controls also need restoring for an unsaved draft.
            disabled.forEach(el => el.disabled = false);
            if (requestId === serial) {
                pending = false; dialog.removeAttribute('aria-busy'); progress.hidden = !keepStatus;
                dialog.querySelectorAll('[data-quick-close]').forEach(el => el.disabled = false);
            }
        }
    }
    function recover() {
        currentUrl = uncertain.url;
        return load({url:uncertain.url, action:'status', data:post('status', uncertain.token)});
    }
    document.addEventListener('click', event => {
        const link = event.target.closest('[data-quick-open]');
        if (link) {
            event.preventDefault();
            if (pending) return;
            if (uncertain) { recover(); return; }
            if (currentUrl !== link.href) body.replaceChildren();
            currentUrl = link.href; draft = null;
            load({url:currentUrl, action:'open'});
        }
        if (event.target.closest('[data-quick-close]')) { event.preventDefault(); close(); }
        if (event.target.closest('[data-quick-retry]')) {
            event.preventDefault();
            if (uncertain) recover(); else if (retry) load(retry);
        }
        if (event.target.closest('[data-quick-back]')) {
            event.preventDefault();
            if (pending) return;
            if (uncertain) { recover(); return; }
            clearError();
            if (draft) { body.replaceChildren(...draft); body.scrollTop = 0; }
            else load({url:currentUrl, action:'open'});
        }
    });
    dialog.addEventListener('cancel', event => { event.preventDefault(); close(); });
    dialog.addEventListener('submit', event => {
        const form = event.target.closest('[data-quick-form]');
        if (!form) return;
        event.preventDefault();
        if (pending) return;
        const data = new FormData(form);
        const task = {url:form.getAttribute('action'), action:data.get('action'), data};
        if (uncertain && (task.action !== 'confirm' || checkedToken !== uncertain.token || data.get('token') !== uncertain.token)) { recover(); return; }
        load(task);
    });
})();
