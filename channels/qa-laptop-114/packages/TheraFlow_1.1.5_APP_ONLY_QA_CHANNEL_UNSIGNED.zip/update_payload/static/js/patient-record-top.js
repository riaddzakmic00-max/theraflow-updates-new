/* Display-only allocation disclosure; all links retain their existing workflows. */
(() => {
    const menus = [...document.querySelectorAll('[data-allocation-menu]')];
    function position(menu) {
        if (!menu.open) return;
        const panel = menu.querySelector('.tf-allocation-menu-panel');
        const rect = menu.querySelector('summary').getBoundingClientRect();
        const gap = 8, margin = 12;
        const below = Math.max(0, window.innerHeight - margin - rect.bottom - gap);
        const above = Math.max(0, rect.top - margin - gap);
        const naturalHeight = panel.scrollHeight + 2;
        const openBelow = naturalHeight <= below || below >= above;
        panel.style.maxHeight = `${openBelow ? below : above}px`;
        panel.style.top = openBelow ? 'calc(100% + 8px)' : 'auto';
        panel.style.bottom = openBelow ? 'auto' : 'calc(100% + 8px)';
    }
    for (const menu of menus) {
        const summary = menu.querySelector('summary');
        menu.addEventListener('keydown', event => {
            if (event.key === 'Escape' && menu.open) {
                menu.open = false;
                summary.focus();
                event.preventDefault();
            }
        });
        menu.addEventListener('toggle', () => {
            if (menu.open) {
                for (const other of menus) if (other !== menu) other.open = false;
                position(menu);
            }
        });
        menu.addEventListener('click', event => {
            if (event.target.closest('a')) menu.open = false;
        });
    }
    document.addEventListener('click', event => {
        for (const menu of menus) if (!menu.contains(event.target)) menu.open = false;
    });
    window.addEventListener('resize', () => menus.forEach(position));
    window.addEventListener('scroll', () => menus.forEach(position), {capture: true, passive: true});
})();
