(() => {
  document.querySelectorAll('.diag-inventory').forEach(inventory => {
    if (inventory.dataset.detailsBound) return;
    inventory.dataset.detailsBound = '1';
    inventory.addEventListener('click', event => {
      const button = event.target.closest('[data-diag-details]');
      if (!button || !inventory.contains(button)) return;
      const panel = document.getElementById(button.dataset.diagDetails);
      if (!panel || !inventory.contains(panel)) return;
      const opening = button.getAttribute('aria-expanded') !== 'true';
      button.setAttribute('aria-expanded', String(opening));
      panel.hidden = !opening;
    });
    inventory.addEventListener('keydown', event => {
      if (event.key !== 'Escape') return;
      const panel = event.target.closest('.diag-stock-details');
      if (!panel) return;
      const button = inventory.querySelector(`[aria-controls="${panel.id}"]`);
      if (button) { panel.hidden = true; button.setAttribute('aria-expanded', 'false'); button.focus(); }
    });
  });
  document.querySelectorAll('[data-diag-submit]').forEach(form => {
    form.addEventListener('submit', event => {
      if (form.dataset.pending) { event.preventDefault(); return; }
      form.dataset.pending = '1';
      const button = form.querySelector('button[type="submit"]');
      if (button) button.disabled = true;
      const status = form.querySelector('[role="status"]');
      if (status) status.hidden = false;
    });
  });
  window.addEventListener('pageshow', () => {
    document.querySelectorAll('[data-diag-submit]').forEach(form => {
      delete form.dataset.pending;
      const button = form.querySelector('button[type="submit"]');
      if (button) button.disabled = false;
      const status = form.querySelector('[role="status"]');
      if (status) status.hidden = true;
    });
  });
})();
