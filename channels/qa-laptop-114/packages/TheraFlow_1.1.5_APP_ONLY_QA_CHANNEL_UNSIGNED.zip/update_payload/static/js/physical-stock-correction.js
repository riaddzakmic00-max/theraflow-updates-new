(() => {
    const form = document.getElementById('physical-stock-form');
    if (!form) return;
    const quantity = form.querySelector('[name="kolicina"]');
    const delta = document.getElementById('physical-delta');
    const scopeCurrent = document.getElementById('physical-scope-current');
    const scope = form.querySelector('[name="obuhvat"]');
    const batch = form.querySelector('[name="serija"]');
    const expiry = form.querySelector('[name="rok_trajanja"]');
    const lots = JSON.parse(document.getElementById('physical-stock-lots').textContent);
    const update = () => {
        let current = Number(form.dataset.current);
        if (scope.value === 'LOT') {
            const lot = lots.find(item => item.batch === batch.value.trim() && item.expiry === expiry.value);
            if (!lot || !batch.value.trim()) {
                scopeCurrent.textContent = 'Odaberite dokumentovanu seriju i rok.';
                delta.textContent = '—';
                return;
            }
            current = Number(lot.quantity);
        }
        scopeCurrent.textContent = current.toLocaleString('bs-BA');
        const value = quantity.valueAsNumber;
        if (!Number.isFinite(value) || value < 0 || !Number.isInteger(value)) {
            delta.textContent = '—';
            return;
        }
        const difference = value - current;
        delta.textContent = (difference >= 0 ? '+' : '') + difference.toLocaleString('bs-BA');
    };
    quantity.addEventListener('input', update);
    [scope, batch, expiry].forEach(field => field.addEventListener('input', update));
    update();
})();
