/* One shared document; bulk preparation copies requested amounts only on explicit click. */
(() => {
    const form = document.querySelector('[data-zzo-form]');
    if (!form) return;
    const rows = [...form.querySelectorAll('[data-zzo-editable]')];
    const all = form.querySelector('[data-zzo-select-all]');
    const approveSelected = form.querySelector('[data-zzo-approve-selected]');
    const preparationState = form.querySelector('[data-zzo-preparation-state]');
    const confirmation = form.querySelector('[data-zzo-confirmed]');
    const submit = form.querySelector('[data-zzo-submit]');
    const choices = rows.map(row => row.querySelector('[data-zzo-include]')).filter(Boolean);
    const numberOfSelected = () => choices.filter(input => input.checked).length;
    const syncRow = row => {
        const selected = Boolean(row.querySelector('[data-zzo-include]')?.checked);
        const decision = row.querySelector('[data-zzo-decision]');
        const quantityRequired = selected && ['odobreno', 'djelimicno_odobreno'].includes(decision?.value);
        if (decision) decision.disabled = !selected;
        row.querySelectorAll('[data-zzo-quantity]').forEach(input => {
            if (selected && decision?.value === 'ceka') {
                input.value = '';
                input.placeholder = 'Čeka odluku';
            } else if (selected && decision?.value === 'odbijeno') {
                input.value = '0';
                input.placeholder = 'Nije odobreno';
            } else {
                input.placeholder = 'Unesi količinu';
            }
            input.disabled = !quantityRequired;
            input.required = quantityRequired;
            input.setCustomValidity('');
            if (quantityRequired && input.value !== '' && decision.value === 'odobreno' && input.dataset.requested !== undefined && Number(input.value) !== Number(input.dataset.requested)) {
                input.setCustomValidity('Za potpuno odobrenje unesite cijelu traženu količinu iz dokumenta. Za manju količinu odaberite djelimično odobreno.');
            }
        });
        const label = row.querySelector('[data-zzo-row-state]');
        if (label) label.textContent = !selected ? 'Nije označen' : decision?.value === 'ceka' ? 'U dokumentu; bez odobrenja lijeka' : 'U ovom dokumentu';
    };
    const sync = () => {
        rows.forEach(syncRow);
        const count = numberOfSelected();
        form.querySelectorAll('[data-zzo-selection-count]').forEach(node => { node.textContent = String(count); });
        if (all) {
            all.disabled = !choices.length;
            all.checked = choices.length > 0 && count === choices.length;
            all.indeterminate = count > 0 && count < choices.length;
        }
        if (submit) submit.disabled = !count || !confirmation?.checked;
        if (approveSelected) approveSelected.disabled = !count;
    };
    const invalidateConfirmation = () => {
        if (confirmation) confirmation.checked = false;
        if (preparationState) preparationState.textContent = '';
    };
    approveSelected?.addEventListener('click', () => {
        invalidateConfirmation();
        let prepared = 0;
        rows.forEach(row => {
            if (!row.querySelector('[data-zzo-include]')?.checked) return;
            const decision = row.querySelector('[data-zzo-decision]');
            if (!decision) return;
            decision.value = 'odobreno';
            row.querySelectorAll('[data-zzo-quantity]').forEach(input => {
                const requested = input.dataset.requested;
                input.value = requested !== undefined && requested.trim() !== ''
                    && Number.isFinite(Number(requested)) && Number(requested) >= 0 ? requested : '';
            });
            prepared += 1;
        });
        sync();
        if (preparationState && prepared) preparationState.textContent = 'Puno odobrenje je pripremljeno za ' + prepared
            + ' označenih zahtjeva. Provjerite odluke i količine prije spremanja.';
    });
    all?.addEventListener('change', () => {
        choices.forEach(input => { input.checked = all.checked; });
        invalidateConfirmation();
        sync();
    });
    form.addEventListener('input', event => {
        if (event.target === all) return;
        if (event.target !== confirmation && event.target !== all) invalidateConfirmation();
        sync();
    });
    form.addEventListener('change', event => {
        if (event.target !== confirmation && event.target !== all) invalidateConfirmation();
        sync();
    });
    form.addEventListener('invalid', event => {
        let parent = event.target.parentElement;
        while (parent && parent !== form) {
            if (parent.tagName === 'DETAILS') parent.open = true;
            parent = parent.parentElement;
        }
    }, true);
    form.addEventListener('submit', event => {
        sync();
        if (!numberOfSelected() || !confirmation?.checked || !form.reportValidity()) event.preventDefault();
    });
    // Browser back navigation can restore stale field choices; demand a fresh document review.
    window.addEventListener('pageshow', event => {
        if (event.persisted) invalidateConfirmation();
        sync();
    });
    sync();
    document.querySelector('[data-zzo-errors]')?.focus();
})();
