(() => {
  let pending;
  let sequence = 0;
  const getDialog = () => {
    let dialog = document.getElementById('tf-balance-dialog');
    if (dialog) return dialog;
    dialog = document.createElement('dialog');
    dialog.id = 'tf-balance-dialog';
    dialog.className = 'tf-balance-dialog';
    dialog.setAttribute('aria-labelledby', 'be-dialog-title');
    dialog.innerHTML = '<header class="be-dialog-header"><strong id="be-dialog-title">Objašnjenje stanja</strong><form method="dialog"><button class="tf-btn-secondary" aria-label="Zatvori objašnjenje"><i class="bi bi-x-lg" aria-hidden="true"></i>Zatvori</button></form></header><div data-explanation-content aria-live="polite"></div>';
    dialog.addEventListener('close', () => { if (pending) pending.abort(); sequence++; });
    document.body.append(dialog);
    return dialog;
  };
  document.addEventListener('click', async event => {
    const link = event.target.closest('[data-balance-explanation], #tf-balance-dialog [data-balance-page]');
    if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    const dialog = getDialog();
    const content = dialog.querySelector('[data-explanation-content]');
    const paginating = link.hasAttribute('data-balance-page');
    const expanded = paginating ? [...content.querySelectorAll('details[open][data-balance-section]')].map(x => x.dataset.balanceSection) : [];
    const scroll = paginating ? content.scrollTop : 0;
    const focusSection = paginating ? link.closest('[data-balance-section]')?.dataset.balanceSection : null;
    if (pending) pending.abort();
    pending = new AbortController();
    const current = ++sequence;
    content.setAttribute('aria-busy', 'true');
    if (!paginating) content.textContent = 'Provjerava se trenutno stanje…';
    if (!dialog.open) dialog.showModal();
    try {
      const response = await fetch(link.href, {headers: {'X-TheraFlow-Explanation': '1'}, signal: pending.signal});
      if (!response.ok || response.redirected) throw new Error('unavailable');
      const html = await response.text();
      if (current !== sequence || !dialog.open) return;
      content.innerHTML = html;
      for (const detail of content.querySelectorAll('details[data-balance-section]')) {
        detail.open = expanded.includes(detail.dataset.balanceSection);
        if (detail.dataset.balanceSection === focusSection) detail.querySelector('summary').focus({preventScroll: true});
      }
      content.scrollTop = scroll;
    } catch (error) {
      if (error.name !== 'AbortError' && current === sequence) content.textContent = 'Objašnjenje trenutno nije dostupno. Zatvorite prozor i pokušajte ponovo.';
    } finally {
      if (current === sequence) content.removeAttribute('aria-busy');
    }
  });
})();
