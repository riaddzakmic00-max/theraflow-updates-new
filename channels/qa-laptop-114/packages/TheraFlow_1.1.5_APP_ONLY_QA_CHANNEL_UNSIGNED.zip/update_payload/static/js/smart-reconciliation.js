document.querySelectorAll('.sr-event-form').forEach(form => {
  const decision = form.querySelector('[data-sr-decision]');
  function showFields() {
    [['therapy', '[data-sr-therapy]'], ['pause', '[data-sr-pause]'], ['postpone', '[data-sr-postpone]']].forEach(([value, selector]) => {
      const group = form.querySelector(selector);
      group.hidden = decision.value !== value;
      group.querySelectorAll('input').forEach(input => { input.disabled = group.hidden; });
    });
  }
  decision.addEventListener('change', showFields);
  showFields();
});
