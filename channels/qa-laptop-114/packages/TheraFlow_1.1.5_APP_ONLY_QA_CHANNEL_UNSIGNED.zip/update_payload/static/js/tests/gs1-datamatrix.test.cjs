'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {parse} = require('../gs1-datamatrix.js');
const now = new Date(2026, 9, 10, 12);
const gtin = '09504000059118'; // Published GS1 sample; no medication mapping.
const otherGTIN = '03453120000011';
const GS = '\x1d';
const fields = [['01', gtin], ['17', '281231'], ['10', 'SYNTHETIC-LOT'], ['21', 'QA-SERIAL-17']];
const hri = values => values.map(([ai, value]) => '(' + ai + ')' + value).join('');
const raw = values => values.map(([ai, value], index) => ai + value
    + ((ai === '10' || ai === '21') && index < values.length - 1 ? GS : '')).join('');
const check = (value, extra = {}) => parse(value, now, extra);
function permutations(values) {
    if (values.length < 2) return [values];
    return values.flatMap((value, index) => permutations(values.filter((_, i) => i !== index))
        .map(rest => [value, ...rest]));
}

test('all 24 field orders work in raw/FNC1 and parenthesized HRI', () => {
    for (const permutation of permutations(fields)) {
        for (const code of [']d2' + raw(permutation), hri(permutation)]) {
            const decoded = check(code);
            assert.equal(decoded.ok, true, code);
            assert.equal(decoded.complete, true);
            assert.equal(decoded.gtin, gtin);
            assert.equal(decoded.batch, 'SYNTHETIC-LOT');
            assert.equal(decoded.serial, 'QA-SERIAL-17');
            assert.equal(decoded.expiry, '2028-12-31');
            assert.equal(decoded.expiryISO, decoded.expiry);
            assert.equal(decoded.canApplyBatch, true);
            assert.equal(decoded.canApplyExpiry, true);
            assert.equal(decoded.productMatch, null);
        }
    }
});

test('raw no-prefix, FNC1 start, and scanner Enter suffix preserve exact data', () => {
    for (const prefix of ['', GS, ']d2', ']d2' + GS]) {
        const decoded = check(prefix + raw(fields) + '\r\n');
        assert.equal(decoded.ok, true);
        assert.equal(decoded.batch, 'SYNTHETIC-LOT');
    }
});

test('predefined-length 01 and 17 concatenate without separators', () => {
    const decoded = check('01' + gtin + '1728123110LOT');
    assert.equal(decoded.ok, true);
    assert.equal(decoded.batch, 'LOT');
    assert.equal(decoded.serial, '');
});

test('HRI presentation spaces do not change the batch or serial', () => {
    const decoded = check('(01)' + gtin + ' (10)LOT(A) (17)281231 (21)000045');
    assert.equal(decoded.ok, true);
    assert.equal(decoded.batch, 'LOT(A)');
    assert.equal(decoded.serial, '000045');
});

test('maximum-length variable field still requires a separator before the next AI', () => {
    const batch = 'ABCDEFGHIJKLMNOPQRST';
    assert.equal(check('01' + gtin + '10' + batch + GS + '17281231').ok, true);
    const invalid = check('01' + gtin + '10' + batch + '17281231');
    assert.equal(invalid.ok, false);
    assert.equal(invalid.canApplyBatch, false);
});

test('AI-looking digits inside a legitimate final batch are never split heuristically', () => {
    const decoded = check('01' + gtin + '1728123110LOT1729013121SER');
    assert.equal(decoded.ok, true);
    assert.equal(decoded.batch, 'LOT1729013121SER');
    assert.equal(decoded.serial, '');
});

test('all 82 GS1 variable characters are accepted, while excluded characters are rejected', () => {
    const allowed = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!"%&\'()*+,-./:;<=>?_';
    assert.equal(new Set(allowed).size, 82);
    for (const character of allowed) {
        const decoded = check('01' + gtin + '1728123110A' + character);
        assert.equal(decoded.ok, true, JSON.stringify(character));
        assert.equal(decoded.batch, 'A' + character);
    }
    for (const character of [' ', '#', '$', '@', '[', ']', '\\', '^', '`', '{', '|', '}', '~', 'č', '\t', '\x00']) {
        const decoded = check('01' + gtin + '1728123110A' + character);
        assert.equal(decoded.ok, false, JSON.stringify(character));
        assert.equal(decoded.canApplyBatch, false);
    }
});

test('unknown AI cannot produce partially applied metadata', () => {
    for (const code of [hri(fields) + '(240)OTHER', raw(fields) + GS + '240OTHER']) {
        const decoded = check(code);
        assert.equal(decoded.ok, false);
        assert.equal(decoded.canApplyBatch, false);
        assert.equal(decoded.canApplyExpiry, false);
    }
});

test('duplicate known AI cannot apply even equal duplicate values', () => {
    for (const code of [hri(fields) + '(17)281231', raw(fields) + GS + '17281231']) {
        const decoded = check(code);
        assert.equal(decoded.code, 'duplicate');
        assert.equal(decoded.canApplyBatch, false);
        assert.equal(decoded.canApplyExpiry, false);
    }
});

test('checksum, truncated/non-digit GTIN, and all-zero ID cannot apply any metadata', () => {
    for (const value of [gtin.slice(0, 13) + '9', gtin.slice(1), '09504000ABC118', '00000000000000']) {
        const decoded = check(hri([['01', value], ['17', '281231'], ['10', 'LOT']]));
        assert.equal(decoded.ok, false);
        assert.equal(decoded.canApplyBatch, false);
        assert.equal(decoded.canApplyExpiry, false);
    }
});

test('missing GTIN is not a safely identified GS1 payload', () => {
    const decoded = check('(17)281231(10)LOT');
    assert.equal(decoded.code, 'missing-gtin');
    assert.equal(decoded.canApplyBatch, false);
});

test('a valid partial scan without expiry can populate its batch only', () => {
    const decoded = check('(01)' + gtin + '(10)LOT');
    assert.equal(decoded.ok, true);
    assert.equal(decoded.partial, true);
    assert.equal(decoded.complete, false);
    assert.equal(decoded.batch, 'LOT');
    assert.equal(decoded.canApplyBatch, true);
    assert.equal(decoded.canApplyExpiry, false);
    assert.equal(decoded.expiry, '');
    assert.ok(decoded.warnings.some(warning => warning.includes('AI 17')));
});

test('a valid partial scan without batch can populate the expiry only', () => {
    const decoded = check('(01)' + gtin + '(17)281231');
    assert.equal(decoded.ok, true);
    assert.equal(decoded.partial, true);
    assert.equal(decoded.canApplyBatch, false);
    assert.equal(decoded.canApplyExpiry, true);
});

test('GTIN-only is parsed but never invents lot, serial, expiry, or quantity', () => {
    const decoded = check('(01)' + gtin);
    assert.equal(decoded.ok, true);
    assert.equal(decoded.partial, true);
    assert.equal(decoded.batch, '');
    assert.equal(decoded.expiry, '');
    assert.equal(decoded.serial, '');
    assert.equal(decoded.canApplyBatch, false);
    assert.equal(decoded.canApplyExpiry, false);
    assert.equal('quantity' in decoded, false);
});

test('invalid calendar date leaves the valid batch available without a bogus expiry', () => {
    for (const value of ['270229', '271332', '270431']) {
        const decoded = check('(01)' + gtin + '(17)' + value + '(10)LOT');
        assert.equal(decoded.ok, false);
        assert.equal(decoded.partial, true);
        assert.equal(decoded.canApplyBatch, true);
        assert.equal(decoded.canApplyExpiry, false);
        assert.equal(decoded.expiry, '');
        assert.ok(decoded.fieldErrors.expiry);
    }
    assert.equal(check('(01)' + gtin + '(17)280229(10)LOT').expiry, '2028-02-29');
});

test('healthcare DD00 is a clear error but does not discard a valid known batch', () => {
    const decoded = check('(01)' + gtin + '(17)280200(10)LOT');
    assert.equal(decoded.ok, false);
    assert.equal(decoded.code, 'month-only');
    assert.equal(decoded.expiryDayUnspecified, true);
    assert.equal(decoded.canApplyBatch, true);
    assert.equal(decoded.canApplyExpiry, false);
    assert.equal(decoded.expiry, '');
    assert.match(decoded.error, /2025/);
    assert.match(decoded.error, /01–31/);
});

test('explicit generic GS1 month-only mode computes the actual end of month', () => {
    for (const [value, expected] of [['280200', '2028-02-29'], ['270200', '2027-02-28'], ['270400', '2027-04-30']]) {
        const decoded = check('(01)' + gtin + '(17)' + value + '(10)LOT', {allowMonthOnly: true});
        assert.equal(decoded.ok, true);
        assert.equal(decoded.expiry, expected);
        assert.equal(decoded.expiryDayUnspecified, true);
        assert.ok(decoded.warnings.some(warning => warning.includes('posljednji dan')));
    }
});

test('GS1 two-digit year spans 49 years past to 50 years future, including century rollover', () => {
    assert.equal(check('(01)' + gtin + '(17)760101(10)LOT').expiry, '2076-01-01');
    assert.equal(check('(01)' + gtin + '(17)770101(10)LOT').expiry, '1977-01-01');
    assert.equal(parse('(01)' + gtin + '(17)300101(10)LOT', new Date(2080, 9, 10)).expiry, '2130-01-01');
    assert.equal(parse('(01)' + gtin + '(17)310101(10)LOT', new Date(2080, 9, 10)).expiry, '2031-01-01');
});

test('an expired but real date is parsed with warning; receipt chronology is a separate guard', () => {
    const decoded = check('(01)' + gtin + '(17)251231(10)LOT');
    assert.equal(decoded.ok, true);
    assert.equal(decoded.isExpired, true);
    assert.equal(decoded.canApplyExpiry, true);
    assert.ok(decoded.warnings.some(warning => warning.includes('prošao')));
});

test('unknown mapping does not claim a product match or block valid metadata', () => {
    const decoded = check(hri(fields));
    assert.equal(decoded.productMatch, null);
    assert.equal(decoded.canApplyBatch, true);
    assert.ok(decoded.warnings.some(warning => warning.includes('nije potvrđen')));
});

test('trusted mapped GTIN matches exactly, including a normalized GTIN-13', () => {
    for (const expectedGTIN of [gtin, gtin.slice(1)]) {
        const decoded = check(hri(fields), {expectedGTIN});
        assert.equal(decoded.productMatch, true);
        assert.equal(decoded.canApplyBatch, true);
        assert.equal(decoded.canApplyExpiry, true);
    }
});

test('wrong trusted GTIN blocks both metadata fields', () => {
    const decoded = check(hri(fields), {expectedGTIN: otherGTIN});
    assert.equal(decoded.ok, false);
    assert.equal(decoded.code, 'gtin-mismatch');
    assert.equal(decoded.productMatch, false);
    assert.equal(decoded.canApplyBatch, false);
    assert.equal(decoded.canApplyExpiry, false);
});

test('invalid catalogue mapping cannot masquerade as a verified match', () => {
    const decoded = check(hri(fields), {expectedGTIN: 'INVALID-MAPPING'});
    assert.equal(decoded.code, 'catalogue-gtin');
    assert.equal(decoded.productMatch, null);
    assert.equal(decoded.canApplyBatch, false);
});

test('malformed input, other symbology, control separators, and overlong values never apply metadata', () => {
    for (const value of [null, undefined, '', '\r\n', 123, GS, GS + GS + raw(fields),
                        ']d1' + raw(fields), ']Q3' + raw(fields), raw(fields) + GS + GS,
                        '(01)' + gtin + '(17)2812(10)LOT', '(01)' + gtin + '(10)' + 'X'.repeat(21),
                        '(01)' + gtin + '(10)', 'x'.repeat(513), 'https://example.test/01/' + gtin]) {
        const decoded = check(value);
        assert.equal(decoded.ok, false, JSON.stringify(value));
        assert.equal(decoded.canApplyBatch, false);
        assert.equal(decoded.canApplyExpiry, false);
    }
});

test('invalid reference date is a field error without an invented century', () => {
    const decoded = parse(hri(fields), new Date(NaN));
    assert.equal(decoded.ok, false);
    assert.equal(decoded.canApplyBatch, true);
    assert.equal(decoded.canApplyExpiry, false);
    assert.equal(decoded.expiry, '');
});
