document.querySelectorAll('[data-patient-correction-context]').forEach((form) => {
  form.querySelectorAll('select').forEach((select) => select.addEventListener('change', () => form.requestSubmit()));
});
document.querySelectorAll('a[href^="#calculation-"]').forEach((link) => {
  link.addEventListener('click', () => {
    const details = document.getElementById(link.hash.slice(1));
    if (details) details.open = true;
  });
});
if (location.hash.startsWith('#calculation-')) {
  const details = document.getElementById(location.hash.slice(1));
  if (details) details.open = true;
}
document.querySelectorAll('.pcw-entry').forEach((form) => {
  const mode = form.querySelector('[name="source_mode"]');
  if (!mode) return;
  const refresh = () => {
    const unrecorded = mode.value === 'UNRECORDED';
    for (const name of ['counted_total', 'actual_count', 'batch', 'expires']) {
      const field = form.querySelector(`[name="${name}"]`);
      if (field) {
        field.closest('.pcw-field').hidden = !unrecorded;
        field.disabled = !unrecorded;
      }
    }
    const source = form.querySelector('[name="source_movement"]');
    source.closest('.pcw-field').hidden = mode.value !== 'EXISTING';
    source.disabled = mode.value !== 'EXISTING';
  };
  mode.addEventListener('change', refresh);
  refresh();
});
