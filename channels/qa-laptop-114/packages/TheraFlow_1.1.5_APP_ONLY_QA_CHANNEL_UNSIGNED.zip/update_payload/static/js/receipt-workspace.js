(() => {
    'use strict';

    const parseGS1 = (raw, expectedGTIN) => window.TheraFlowGS1?.parse(raw, new Date(), expectedGTIN ? {expectedGTIN} : {}) || {
        ok: false, error: 'Skener nije dostupan. Podatke možete unijeti ručno ili ostaviti prazne.'
    };
    if (window.TheraFlowGS1) window.TheraFlowReceiptGS1 = window.TheraFlowGS1;

    function planScannerUpdate(parsed, batchValue, expiryValue) {
        const canApplyBatch = parsed?.canApplyBatch ?? Boolean(parsed?.ok && parsed.batch);
        const canApplyExpiry = parsed?.canApplyExpiry ?? Boolean(parsed?.ok && parsed.expiry);
        if (!canApplyBatch && !canApplyExpiry) return {ok: false, changes: [], conflicts: []};
        const changes = [], conflicts = [];
        [['batch', parsed.batch, batchValue, canApplyBatch], ['expiry', parsed.expiry, expiryValue, canApplyExpiry]].forEach(([field, scanned, current, allowed]) => {
            if (!allowed || typeof scanned !== 'string' || !scanned || scanned === String(current || '').trim()) return;
            changes.push({field, value: scanned});
            if (String(current || '').trim()) conflicts.push(field);
        });
        return {ok: true, changes, conflicts};
    }
    window.TheraFlowReceiptScanner = Object.freeze({plan: planScannerUpdate});

    const form = document.querySelector('form[data-receipt-workspace]');
    if (!form) return;
    const medicines = [...form.querySelectorAll('[data-receipt-medicine]')];
    const confirm = form.querySelector('#confirm-selected'), propose = form.querySelector('[data-propose]');
    const token = form.querySelector('[name=proposal_token]'), proposal = form.querySelector('#receipt-proposal');
    const confirmation = form.querySelector('[data-receipt-confirmation]');
    const shipment = form.querySelector('[data-shipment-section]');
    const state = form.querySelector('[data-receipt-state]') || form.querySelector('#receipt-proposal-state');
    const footer = form.querySelector('[data-receipt-footer]');
    const counts = form.querySelector('[data-final-counts]'), complete = form.querySelector('[data-allocation-complete]');
    const expiryWarning = form.querySelector('[data-missing-expiry-warning]'), expiryDetails = form.querySelector('[data-missing-expiry-details]');
    const edit = form.querySelector('[data-edit-allocation]'), reference = form.querySelector('#shipment-reference');
    const owners = JSON.parse(document.getElementById('agreement-number-owners')?.textContent || '{}');
    const scans = new WeakMap();
    let proposalStale = false;
    const numeric = input => !input || input.value.trim() === '' ? null : Number(input.value.replace(',', '.'));
    const format = n => new Intl.NumberFormat('bs-BA', {maximumFractionDigits: 2}).format(n);
    const units = (medicine, n) => {
        if (n === null || !Number.isFinite(n)) return 'Nije uneseno';
        const last = Math.abs(n) % 10, rest = Math.abs(n) % 100;
        const word = Number.isInteger(n) && !(rest >= 11 && rest <= 14)
            ? last === 1 ? medicine.dataset.unitOne : last >= 2 && last <= 4 ? medicine.dataset.unitFew : medicine.dataset.unitMany
            : medicine.dataset.unitMany;
        const packs = n / Number(medicine.dataset.packageSize);
        const packWord = packs % 10 === 1 && packs % 100 !== 11 ? 'pakovanje' : 'pakovanja';
        return format(n) + ' ' + word + (medicine.dataset.packages === 'true' ? ' · ' + format(packs) + ' ' + packWord : '');
    };
    const byMedicine = (attribute, medicine) => form.querySelector('[' + attribute + '="' + medicine.dataset.receiptMedicine + '"]');
    const lotSection = medicine => byMedicine('data-series-medicine', medicine);
    const allocationSection = medicine => byMedicine('data-allocation-medicine', medicine);
    const exceptionSection = medicine => byMedicine('data-free-exception-medicine', medicine);
    const reasonValid = input => input.value.trim().length >= 5 && input.value.trim().length <= 1000 && input.checkValidity();
    const isoDate = input => {
        if (!input?.value) return '';
        if (window.TheraFlowDates?.toISODate) return window.TheraFlowDates.toISODate(input.value) || '';
        return /^\d{4}-\d{2}-\d{2}$/.test(input.value) ? input.value : '';
    };
    function validateDate(input) {
        input.setCustomValidity(input.value && !isoDate(input) ? 'Unesite ispravan datum.' : '');
        return input.checkValidity();
    }
    function updateSeries(section, active) {
        const multiple = section.querySelectorAll('[data-series-row]').length > 1;
        section.hidden = !active;
        section.querySelectorAll('input, button').forEach(input => { input.disabled = !active; });
        const primary = section.querySelector('[data-series-primary-quantity]');
        primary.hidden = !multiple;
        const quantity = primary.querySelector('input');
        quantity.disabled = !active || !multiple;
        quantity.required = multiple;
        section.querySelectorAll('[name^=serija_lijek_], [name^=rok_lijek_]').forEach(input => { input.required = false; });
        section.querySelector('[data-series-hint]').hidden = !multiple;
        section.querySelectorAll('[data-series-row]').forEach(row => {
            const pending = scans.get(row)?.pendingOverwrite;
            const apply = row.querySelector('[data-scan-apply]');
            apply.hidden = !pending;
            apply.disabled = !active || !pending;
        });
    }
    function update() {
        let valid = true, hasArrival = false, canEditAllocation = false;
        const totals = [];
        medicines.forEach(medicine => {
            const arrival = medicine.querySelector('.received-input');
            if (!arrival) return;
            const amount = numeric(arrival), active = Number.isFinite(amount) && amount > 0;
            hasArrival ||= active;
            medicine.querySelector('[data-arrived-unit]').textContent = amount === null ? medicine.dataset.unitOne : units(medicine, amount);
            let groupValid = arrival.checkValidity() && (amount === null || Number.isFinite(amount));
            const exception = exceptionSection(medicine);
            const exceptionChoice = exception?.querySelector('[data-free-exception-choice]');
            const freeAuthorized = exception?.dataset.freeExceptionAuthorized === 'true';
            if (exceptionChoice) exceptionChoice.disabled = !active || !freeAuthorized;
            const freeMode = Boolean(active && exceptionChoice?.checked), freeReason = exception?.querySelector('[data-free-exception-reason]');
            let missingFreeReason = false;
            if (exception) {
                exception.hidden = !active;
                exception.querySelector('[data-free-exception-reason-section]').hidden = !freeMode;
                freeReason.required = freeMode;
                freeReason.disabled = !freeMode;
                missingFreeReason = freeMode && !reasonValid(freeReason);
                if (freeMode) groupValid &&= freeAuthorized && !missingFreeReason;
            }
            const lots = lotSection(medicine);
            if (lots) {
                updateSeries(lots, active);
                if (active) {
                    lots.querySelectorAll('[name^=serija_lijek_]').forEach(input => {
                        input.setCustomValidity('');
                        groupValid &&= input.checkValidity();
                    });
                    lots.querySelectorAll('[name^=rok_lijek_]').forEach(input => {
                        validateDate(input);
                        const expires = isoDate(input), received = isoDate(form.querySelector('#physical-receipt-date'));
                        if (expires && received && expires < received) input.setCustomValidity('Rok trajanja ne može biti prije datuma prijema.');
                        groupValid &&= input.checkValidity();
                    });
                    const quantities = [...lots.querySelectorAll('.lot-quantity-input:not(:disabled)')];
                    if (quantities.length) {
                        const sum = quantities.reduce((total, input) => total + (numeric(input) || 0), 0);
                        groupValid &&= quantities.every(input => input.checkValidity() && numeric(input) > 0) && Math.abs(sum - amount) < 0.000001;
                    }
                }
            }
            let assigned = 0, changedAllocation = false, missingReviewReason = false;
            const patients = new Set(), section = allocationSection(medicine);
            if (section) section.hidden = !active || !token.value;
            const idle = medicine.querySelector('[data-allocation-idle]');
            if (idle) {
                idle.hidden = active && Boolean(token.value);
                idle.textContent = proposalStale ? 'Prijedlog treba osvježiti' : 'Prijedlog još nije prikazan';
            }
            section?.querySelectorAll('[data-pending]').forEach(row => {
                const agreement = row.querySelector('.agreement-submit-value'), quantity = row.querySelector('.allocation-input'), choice = row.querySelector('.receipt-checkbox');
                quantity.disabled = !active || freeMode || quantity.dataset.blocked === 'true';
                quantity.readOnly = freeMode || proposal.dataset.editing !== 'true';
                agreement.disabled = !active; agreement.readOnly = freeMode || row.dataset.optionalAgreementNumber === 'true';
                if (freeMode) { quantity.value = '0'; choice.checked = false; }
                const value = numeric(quantity), step = Number(quantity.step);
                const quantityValid = Number.isFinite(value) && value >= 0 && value <= Number(quantity.max)
                    && Math.abs(value / step - Math.round(value / step)) < 0.000001;
                const hasApprovalLabel = Boolean(agreement.value.trim()) || row.dataset.optionalAgreementNumber === 'true';
                const possible = active && !freeMode && hasApprovalLabel && quantity.dataset.blocked !== 'true' && quantityValid && value > 0;
                canEditAllocation ||= active && !freeMode && quantity.dataset.blocked !== 'true';
                choice.disabled = !possible;
                if (active && !possible) choice.checked = false;
                if (possible && choice.checked) {
                    assigned += value;
                    patients.add(row.dataset.patient || row);
                }
                if (!quantity.disabled && !quantityValid) groupValid = false;
                row.querySelector('[data-allocation-display]').textContent = units(medicine, possible && choice.checked ? value : 0);
                const rowChanged = active && Math.abs((choice.checked ? value : 0) - Number(row.dataset.proposedQuantity || 0)) > 0.000001;
                changedAllocation ||= rowChanged;
                const original = row.dataset.originalNumber || '';
                const conflicts = (owners[agreement.value.trim().toLocaleLowerCase()] || []).filter(owner => String(owner.id) !== row.dataset.patient);
                const unchangedNumber = original.trim().toLocaleLowerCase() === agreement.value.trim().toLocaleLowerCase();
                const documentedShared = row.dataset.documentedSharedNumber === 'true' && unchangedNumber;
                const provenShared = row.dataset.sharedNumber === 'true' && unchangedNumber && quantity.dataset.blocked !== 'true';
                row.querySelector('[data-agreement-notice]').textContent = documentedShared || provenShared ? '' : conflicts.length
                    ? 'Isti broj postoji kod drugog pacijenta: ' + conflicts.map(owner => owner.name).join(', ') + '. Provjerite dokument.'
                    : original && original !== agreement.value.trim() ? 'Pri potvrdi: ' + original + ' → ' + (agreement.value.trim() || 'nije uneseno') + '.' : '';
                const reason = row.querySelector('[data-review-reason]');
                if (reason) {
                    // Omitting a positive proposal is a manual change too.
                    const required = active && !freeMode && quantity.dataset.blocked !== 'true' && (rowChanged || (choice.checked && row.dataset.reviewRequired === 'true'));
                    reason.required = required; reason.disabled = !required;
                    row.querySelector('[data-review-reason-section]').hidden = !required;
                    if (required) {
                        const acceptable = reasonValid(reason);
                        missingReviewReason ||= !acceptable; groupValid &&= acceptable;
                    }
                }
            });
            const free = amount === null ? null : amount - assigned;
            groupValid &&= !(free < 0 || (amount === null && assigned));
            if (section) {
                section.dataset.freeException = String(freeMode);
                if (active) {
                    groupValid &&= section.dataset.physicalBlocked !== 'true' || (freeMode && freeAuthorized);
                    if (!freeMode) groupValid &&= !section.dataset.maximumPhysical || amount <= Number(section.dataset.maximumPhysical);
                }
                // A manual change invalidates FEFO details for every patient.
                section.querySelectorAll('[data-proposed-series]').forEach(line => { line.hidden = changedAllocation || freeMode; });
                section.querySelectorAll('[data-manual-series-note]').forEach((note, index) => { note.hidden = !changedAllocation || freeMode || index > 0; });
                section.querySelector('[data-review-arrived]').textContent = units(medicine, amount);
                section.querySelector('[data-review-allocated]').textContent = units(medicine, assigned);
                section.querySelector('[data-review-free]').textContent = free < 0 ? 'Prekoračeno ' + units(medicine, -free) : units(medicine, free);
                const freeRow = section.querySelector('[data-review-free-row]');
                if (freeRow) freeRow.hidden = !active || !token.value || !(free > 0);
                const message = section.querySelector('[data-distribution]');
                message.textContent = freeMode && !freeAuthorized ? 'Kontrolisani slobodni prijem zahtijeva ovlaštenu sestru ili administratora.'
                    : missingFreeReason ? 'Unesite razlog slobodnog prijema: 5–1000 znakova.'
                    : freeMode && groupValid ? 'Cijela pristigla količina ostaje u slobodnoj zalihi. Pacijentima se ne dodjeljuje lijek.'
                    : active && section.dataset.physicalBlocked === 'true' && !freeMode ? 'Prijem zahtijeva usklađivanje odobrenja ili kontrolisani slobodni prijem uz razlog.'
                    : missingReviewReason ? ''
                    : !groupValid ? 'Provjerite pristiglu količinu, podatke serija i raspodjelu.'
                    : free > 0 ? 'Neraspoređeni ostatak ostaje u slobodnoj zalihi nakon potvrde.' : '';
                message.classList.toggle('is-warning', !groupValid);
            }
            const unknownExpiryLots = lots ? [...lots.querySelectorAll('[data-series-row]')]
                .filter(row => !isoDate(row.querySelector('[name^=rok_lijek_]')))
                .map(row => row.querySelector('[name^=serija_lijek_]')?.value.trim() || 'Nije evidentirano') : [];
            if (active) totals.push({medicine, amount, free, patients, unknownExpiryLots});
            valid &&= groupValid;
        });
        form.querySelectorAll('[data-shipment-metadata-status]').forEach(status => {
            const input = document.getElementById(status.dataset.metadataFor);
            status.textContent = input?.value.trim() ? '' : 'Nije evidentirano';
        });
        shipment.hidden = !hasArrival;
        shipment.querySelectorAll('.rw-document-fields input, .rw-document-fields button').forEach(input => { input.disabled = !hasArrival; });
        edit.disabled = !canEditAllocation;
        form.querySelectorAll('[data-required-date]:not(:disabled)').forEach(input => { valid &&= validateDate(input); });
        valid &&= reference.disabled || reference.checkValidity();
        const hasProposal = Boolean(token.value) && hasArrival, ready = hasProposal && valid;
        confirmation.hidden = !hasProposal;
        state.hidden = !hasProposal;
        if (footer) footer.hidden = !hasProposal;
        edit.hidden = !hasProposal;
        form.querySelector('[data-confirmation-idle]')?.toggleAttribute('hidden', ready);
        state.textContent = proposalStale ? 'Prijedlog treba osvježiti'
            : !hasProposal ? 'Prijedlog još nije prikazan'
            : ready ? 'Prijedlog je spreman za potvrdu.' : 'Provjerite upozorenja i obavezne razloge prije potvrde.';
        if (counts) {
            counts.hidden = !ready;
            const patientIDs = new Set(totals.flatMap(total => [...total.patients]));
            counts.textContent = ready ? 'Broj lijekova za prijem: ' + new Set(totals.map(total => total.medicine.dataset.receiptMedicine)).size
                + ' · Broj pacijenata za zaduženje: ' + patientIDs.size : '';
        }
        if (complete) complete.hidden = !ready || !totals.every(total => Math.abs(total.free) < 0.000001);
        if (expiryWarning && expiryDetails) {
            const missing = hasProposal ? totals.filter(total => total.unknownExpiryLots.length) : [];
            expiryWarning.hidden = !missing.length;
            if (!missing.length) expiryWarning.open = false;
            const list = document.createElement('ul');
            missing.forEach(total => total.unknownExpiryLots.forEach(batch => {
                const item = document.createElement('li');
                item.textContent = total.medicine.dataset.medicineName + ' · serija: ' + batch;
                list.append(item);
            }));
            expiryDetails.replaceChildren(list);
        }
        propose.disabled = !hasArrival || form.dataset.submitting === 'true';
        confirm.disabled = !ready || form.dataset.submitting === 'true';
    }
    function setEditing(active) {
        proposal.dataset.editing = String(active); edit.setAttribute('aria-expanded', String(active));
        edit.textContent = active ? 'Završi izmjene' : 'Izmijeni raspodjelu';
        proposal.querySelectorAll('.allocation-input').forEach(input => { input.readOnly = !active || input.disabled; });
    }
    function invalidate() {
        proposalStale ||= Boolean(token.value);
        token.value = ''; confirmation.hidden = true;
        state.textContent = proposalStale ? 'Prijedlog treba osvježiti' : 'Prijedlog još nije prikazan';
    }
    function scannerPlan(row, parsed) {
        const batch = row.querySelector('[name^=serija_lijek_]'), expiry = row.querySelector('[name^=rok_lijek_]');
        return planScannerUpdate(parsed, batch.value, isoDate(expiry) || expiry.value);
    }
    function parsedScanner(row) {
        const raw = row.querySelector('[data-scan-input]').value;
        const expectedGTIN = row.closest('[data-series-medicine]')?.dataset.expectedGtin || '';
        const cached = scans.get(row);
        return cached?.raw === raw && cached.expectedGTIN === expectedGTIN ? cached.parsed : parseGS1(raw, expectedGTIN);
    }
    function rememberScan(row, parsed, pendingOverwrite) {
        scans.set(row, {parsed, pendingOverwrite, raw: row.querySelector('[data-scan-input]').value,
            expectedGTIN: row.closest('[data-series-medicine]')?.dataset.expectedGtin || ''});
    }
    function scannerDescription(parsed) {
        const displayDate = parsed.expiry ? parsed.expiry.slice(8, 10) + '/' + parsed.expiry.slice(5, 7) + '/' + parsed.expiry.slice(0, 4) : 'Nije evidentirano';
        const warnings = [...new Set([...(Array.isArray(parsed.warnings) ? parsed.warnings : []), ...Object.values(parsed.fieldErrors || {})])]
            .filter(warning => !(parsed.productMatch !== true && warning.startsWith('Lijek nije potvrđen GTIN vezom'))).join(' ');
        return 'GTIN ' + (parsed.gtin || 'Nije evidentirano') + ' · serija ' + (parsed.batch || 'Nije evidentirano')
            + ' · rok ' + displayDate + (parsed.serial ? ' · serijski broj ' + parsed.serial : '')
            + (parsed.productMatch === true ? '. GTIN odgovara evidentiranom lijeku.'
                : '. GTIN nije povezan s katalogom lijekova. Provjerite naziv, jačinu i oblik na pakovanju.') + (warnings ? ' ' + warnings : '');
    }
    function applyScanner(row, parsed, overwrite = false) {
        const plan = scannerPlan(row, parsed);
        if (!plan.ok) return false;
        const changes = overwrite ? plan.changes : plan.changes.filter(change => !plan.conflicts.includes(change.field));
        const pendingOverwrite = !overwrite && plan.conflicts.length > 0;
        changes.forEach(change => {
            const input = row.querySelector(change.field === 'batch' ? '[name^=serija_lijek_]' : '[name^=rok_lijek_]');
            if (change.field === 'expiry' && window.TheraFlowDates?.setDateInputValue) window.TheraFlowDates.setDateInputValue(input, change.value);
            else input.value = change.value;
            input.dispatchEvent(new Event(change.field === 'expiry' ? 'change' : 'input', {bubbles: true}));
        });
        rememberScan(row, parsed, pendingOverwrite);
        row.querySelector('[data-scan-notice]').textContent = scannerDescription(parsed) + (pendingOverwrite
            ? (changes.length ? ' Prazni podaci pakovanja su popunjeni.' : '')
                + ' Postojeći podaci nisu promijenjeni. Zamjenu potvrdite dugmetom ispod.'
            : changes.length
            ? overwrite ? ' Uneseni podaci su zamijenjeni nakon vaše potvrde.' : ' Podaci pakovanja su popunjeni.'
            : ' Podaci pakovanja već odgovaraju ovom kodu.');
        update();
        return true;
    }
    function parseScanner(row, apply = false) {
        const parsed = parsedScanner(row);
        const plan = scannerPlan(row, parsed), pendingOverwrite = plan.ok && plan.conflicts.length > 0;
        rememberScan(row, parsed, pendingOverwrite);
        const notice = row.querySelector('[data-scan-notice]');
        notice.classList.toggle('rw-error', !parsed.ok && apply);
        notice.textContent = plan.ok || parsed.ok ? scannerDescription(parsed) + (pendingOverwrite
            ? ' Postojeći podaci nisu promijenjeni. Ako želite zamjenu, potvrdite dugmetom ispod.'
            : apply ? '' : ' Završite skeniranje pritiskom na Enter.')
            : apply ? parsed.error || parsed.message || 'Kod nema primjenjive podatke. Podatke možete unijeti ručno.'
                : 'Skener čeka cijeli GS1 kod. Završite pritiskom na Enter.';
        if (apply && plan.ok) applyScanner(row, parsed);
        else update();
    }
    function addScanner(row, id, index) {
        const scanner = document.createElement('div'); scanner.className = 'rw-scan';
        const toggle = document.createElement('button');
        toggle.type = 'button'; toggle.className = 'tf-btn-secondary'; toggle.dataset.scanButton = '';
        toggle.textContent = 'Skeniraj lijek'; toggle.setAttribute('aria-expanded', 'false'); toggle.setAttribute('aria-controls', 'scan-panel-' + id + '-' + index);
        const panel = document.createElement('div'); panel.className = 'rw-scan-panel'; panel.dataset.scanPanel = '';
        panel.id = 'scan-panel-' + id + '-' + index; panel.hidden = true;
        const label = document.createElement('label'); label.htmlFor = 'scan-' + id + '-' + index; label.textContent = 'Skenirajte kod s pakovanja';
        const input = document.createElement('input'); input.id = label.htmlFor; input.type = 'text'; input.dataset.scanInput = '';
        input.maxLength = 512; input.autocomplete = 'off'; input.placeholder = 'Kod sa 2D skenera';
        const apply = document.createElement('button'); apply.type = 'button'; apply.className = 'tf-btn-secondary';
        apply.dataset.scanApply = ''; apply.hidden = true; apply.disabled = true; apply.textContent = 'Zamijeni unesene podatke';
        const notice = document.createElement('small'); notice.dataset.scanNotice = ''; notice.setAttribute('role', 'status');
        const hint = document.createElement('small'); hint.textContent = 'Pošaljite kod skenerom i završite tipkom Enter ili Tab. Skeniranje ne mijenja količinu lijeka.';
        panel.append(label, input, hint, notice, apply); scanner.append(toggle, panel); row.append(scanner);
    }
    edit.addEventListener('click', () => { setEditing(proposal.dataset.editing !== 'true'); update(); });
    form.addEventListener('click', event => {
        const detailsButton = event.target.closest('[data-open-receipt-details]');
        if (detailsButton) {
            const details = document.getElementById(detailsButton.getAttribute('aria-controls'));
            if (details?.tagName === 'DETAILS') { details.open = true; details.querySelector('summary').focus(); }
            return;
        }
        const scanToggle = event.target.closest('[data-scan-button]'), scanApply = event.target.closest('[data-scan-apply]');
        if (scanToggle) {
            const row = scanToggle.closest('[data-series-row]'), panel = row.querySelector('[data-scan-panel]');
            panel.hidden = !panel.hidden; scanToggle.setAttribute('aria-expanded', String(!panel.hidden));
            if (!panel.hidden) row.querySelector('[data-scan-input]').focus();
            return;
        }
        if (scanApply) {
            const row = scanApply.closest('[data-series-row]'), parsed = parsedScanner(row);
            if (scanApply.disabled) return;
            applyScanner(row, parsed, true); return;
        }
        const add = event.target.closest('[data-add-series]'), remove = event.target.closest('[data-remove-series]');
        if (!add && !remove) return;
        const section = event.target.closest('[data-series-medicine]');
        const medicine = medicines.find(item => item.dataset.receiptMedicine === section.dataset.seriesMedicine);
        if (remove) remove.closest('[data-series-row]').remove();
        else {
            const container = section.querySelector('[data-series-container]');
            const used = new Set([...container.querySelectorAll('[data-series-row]')].map(row => Number(row.dataset.seriesRow)));
            let index = 1; while (used.has(index)) index += 1;
            if (index >= 20) { state.textContent = 'Najviše 20 serija u jednoj potvrdi.'; return; }
            const firstQuantity = section.querySelector('[data-series-primary-quantity] input');
            if (firstQuantity.disabled) firstQuantity.value = medicine.querySelector('.received-input').value;
            const id = medicine.dataset.receiptMedicine;
            const row = document.createElement('div'); row.className = 'rw-series-row'; row.dataset.seriesRow = String(index);
            [['Serija', 'serija_lijek_' + id + '_' + index, 'text'], ['Rok trajanja', 'rok_lijek_' + id + '_' + index, 'date'], ['Količina serije', 'lot_quantity_' + id + '_' + index, 'number']].forEach(([caption, name, type]) => {
                const cell = document.createElement('div'), label = document.createElement('label'), input = document.createElement('input');
                label.textContent = caption; label.htmlFor = name; input.name = name; input.id = name; input.type = type; input.required = type === 'number';
                if (type === 'number') { input.min = '0'; input.step = medicine.dataset.packageSize; input.className = 'lot-quantity-input'; }
                if (type === 'text') { input.maxLength = 100; input.placeholder = 'Nije evidentirano'; }
                cell.append(label, input);
                if (type !== 'number') {
                    const status = document.createElement('small'); status.dataset.shipmentMetadataStatus = ''; status.dataset.metadataFor = name;
                    status.dataset.missingLabel = 'Nije evidentirano';
                    status.textContent = status.dataset.missingLabel; status.setAttribute('aria-live', 'polite'); cell.append(status);
                }
                row.append(cell);
            });
            const removeButton = document.createElement('button'); removeButton.type = 'button'; removeButton.className = 'rw-link-button rw-remove';
            removeButton.dataset.removeSeries = ''; removeButton.textContent = 'Ukloni'; removeButton.setAttribute('aria-label', 'Ukloni dodatnu seriju');
            row.append(removeButton); addScanner(row, id, index); container.append(row);
            window.TheraFlowDates?.enhanceDateInputs(row); row.querySelector('input').focus();
        }
        invalidate(); update();
    });
    form.addEventListener('keydown', event => {
        if (!event.target.matches('[data-scan-input]')) return;
        if (event.ctrlKey && !event.altKey && !event.metaKey && (event.key === ']' || event.code === 'BracketRight')) {
            event.preventDefault();
            const input = event.target, start = input.selectionStart ?? input.value.length, end = input.selectionEnd ?? start;
            input.setRangeText('\x1d', start, end, 'end');
            input.dispatchEvent(new Event('input', {bubbles: true}));
            return;
        }
        if (event.key !== 'Enter' && event.key !== 'Tab') return;
        if (event.key === 'Enter') event.preventDefault();
        parseScanner(event.target.closest('[data-series-row]'), true);
    });
    const metadata = '.received-input, .lot-quantity-input, #shipment-reference, [data-required-date], [name^=serija_lijek_], [name^=rok_lijek_], .agreement-submit-value, [data-free-exception-choice]';
    function changed(event) {
        if (event.target.matches('[data-scan-input]')) { parseScanner(event.target.closest('[data-series-row]'), event.type === 'change' || event.inputType === 'insertFromPaste'); return; }
        if (event.target.matches('.allocation-input')) event.target.closest('[data-pending]').querySelector('.receipt-checkbox').checked = numeric(event.target) > 0;
        if (event.target.matches(metadata)) invalidate();
        update();
    }
    form.addEventListener('input', changed); form.addEventListener('change', changed);
    form.addEventListener('invalid', event => {
        if (event.target.matches('.allocation-input')) setEditing(true);
        let parent = event.target.parentElement;
        while (parent && parent !== form) { if (parent.tagName === 'DETAILS') parent.open = true; parent = parent.parentElement; }
    }, true);
    form.addEventListener('submit', event => {
        const action = event.submitter?.value || 'propose_distribution';
        form.querySelector('[name=bulk_action]').value = action; update();
        if (action === 'propose_distribution') {
            const fields = [reference, ...form.querySelectorAll('[data-required-date], .received-input, [name^=serija_lijek_], [name^=rok_lijek_], .lot-quantity-input, [data-free-exception-reason]')];
            for (const input of fields) {
                if (!input.disabled && !input.checkValidity()) { event.preventDefault(); input.reportValidity(); return; }
            }
            if (propose.disabled) { event.preventDefault(); return; }
            const incorrectSum = medicines.some(medicine => {
                const amount = numeric(medicine.querySelector('.received-input'));
                const inputs = [...(lotSection(medicine)?.querySelectorAll('.lot-quantity-input:not(:disabled)') || [])];
                return amount > 0 && inputs.length && (inputs.some(input => !(numeric(input) > 0)) || Math.abs(inputs.reduce((sum, input) => sum + (numeric(input) || 0), 0) - amount) > 0.000001);
            });
            if (incorrectSum) { event.preventDefault(); state.textContent = 'Zbir količina serija mora odgovarati polju „Stiglo sada“.'; return; }
            return;
        }
        if (confirm.disabled) { event.preventDefault(); return; }
        form.dataset.submitting = 'true'; confirm.disabled = true; propose.disabled = true;
        confirm.setAttribute('aria-busy', 'true'); confirm.textContent = 'Potvrđujem prijem…';
    });
    window.addEventListener('pageshow', () => {
        form.dataset.submitting = 'false'; confirm.removeAttribute('aria-busy');
        confirm.textContent = 'Potvrdi prijem i zaduženja'; update();
    });
    if (proposal.querySelector('[aria-invalid=true]')) setEditing(true);
    // The shared date enhancer creates its picker controls at DOM ready.
    // Reapply the arrival state so initially hidden lots stay disabled too.
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', update, {once: true});
    update();
})();
