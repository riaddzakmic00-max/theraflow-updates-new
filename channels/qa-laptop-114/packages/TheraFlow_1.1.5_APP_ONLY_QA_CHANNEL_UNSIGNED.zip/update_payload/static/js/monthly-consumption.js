(() => {
  const details = [...document.querySelectorAll('.monthly-details')];
  function showHash() {
    const selected = details.find(item => '#' + item.id === location.hash);
    if (selected) { selected.open = true; selected.scrollIntoView({block: 'start'}); }
  }
  window.addEventListener('hashchange', showHash);
  showHash();
  let previouslyOpen = [];
  window.addEventListener('beforeprint', () => {
    previouslyOpen = details.map(item => item.open);
    details.forEach(item => { item.open = true; });
  });
  window.addEventListener('afterprint', () => details.forEach((item, index) => { item.open = previouslyOpen[index]; }));
})();
