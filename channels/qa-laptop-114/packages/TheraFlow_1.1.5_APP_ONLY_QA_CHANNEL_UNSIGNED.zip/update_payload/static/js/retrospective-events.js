(() => {
  const appointment = document.getElementById('id_appointment_id');
  if (appointment) {
    ['id_patient_id', 'id_medicine_id', 'id_event_date'].forEach(id => {
      const field = document.getElementById(id);
      const clearAppointment = () => {
        // A choice loaded for another patient/product/date must not survive.
        appointment.replaceChildren(new Option('Osvježite termine za odabrani datum', ''));
      };
      field?.addEventListener('change', clearAppointment);
      // The shared date widget formats its text on blur. Clear while typing too.
      if (id === 'id_event_date') field?.addEventListener('input', clearAppointment);
    });
  }
  const add = document.getElementById('retro-add-lot');
  if (!add) return;
  add.addEventListener('click', () => {
    const total = document.getElementById('id_lots-TOTAL_FORMS');
    const count = Number(total.value);
    if (count >= 20) return;
    document.getElementById('retro-lots').insertAdjacentHTML('beforeend',
      document.getElementById('retro-empty-lot').innerHTML.replaceAll('__prefix__', String(count)));
    total.value = count + 1;
    if (window.TheraFlowDates) window.TheraFlowDates.enhanceDateInputs(document.getElementById('retro-lots'));
    add.disabled = count + 1 >= 20;
  });
})();
