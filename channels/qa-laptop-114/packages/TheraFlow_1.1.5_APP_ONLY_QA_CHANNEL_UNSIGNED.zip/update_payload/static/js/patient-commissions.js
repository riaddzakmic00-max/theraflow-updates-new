/* Open only the selected request; keep the existing patient-tab URL intact. */
(() => {
    const panel = document.getElementById('komisije');
    if (!panel || panel.dataset.commissionDetailsBound) return;
    panel.dataset.commissionDetailsBound = 'true';
    // A link beside an approval reuses the existing server-side selection.
    // Only open its editor; do not submit or change any form values here.
    const params = new URLSearchParams(window.location.search);
    if (params.get('dopuna_saglasnosti') === '1' && params.get('tab') === 'komisije' &&
        (!window.location.hash || window.location.hash === '#komisije')) {
        const editor = panel.querySelector('#patient-agreement-editor');
        if (editor) {
            editor.open = true;
            const showEditor = () => requestAnimationFrame(() => {
                editor.scrollIntoView({block: 'start'});
                editor.querySelector('summary')?.focus({preventScroll: true});
            });
            if (document.readyState === 'complete') showEditor();
            else window.addEventListener('load', showEditor, {once: true});
        }
    }
    panel.addEventListener('click', event => {
        const sectionLink = event.target.closest('[data-commission-target]');
        if (sectionLink && panel.contains(sectionLink)) {
            const target = document.getElementById(sectionLink.dataset.commissionTarget);
            if (target && panel.contains(target)) {
                event.preventDefault();
                target.scrollIntoView({block: 'start', behavior: 'auto'});
                const heading = target.querySelector('h3');
                if (heading) {
                    heading.tabIndex = -1;
                    heading.focus({preventScroll: true});
                }
            }
            return;
        }
        const link = event.target.closest('[data-commission-request]');
        if (!link || !panel.contains(link)) return;
        const details = document.getElementById(link.dataset.commissionRequest);
        if (!details || !panel.contains(details) || details.tagName !== 'DETAILS') return;
        event.preventDefault();
        details.open = true;
        details.querySelector('summary')?.focus({preventScroll: true});
        details.scrollIntoView({block: 'center'});
    });
})();
