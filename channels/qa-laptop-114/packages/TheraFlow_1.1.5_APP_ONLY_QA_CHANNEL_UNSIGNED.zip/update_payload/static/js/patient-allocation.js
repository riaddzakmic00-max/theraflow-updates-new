(() => {
    const form = document.getElementById('patient-allocation-form');
    if (!form) return;
    const rows = JSON.parse(document.getElementById('patient-allocation-presentations').textContent);
    const medicine = form.querySelector('[name="medicine"]');
    const quantity = form.querySelector('[name="quantity"]');
    const submit = document.getElementById('allocation-submit');
    const update = () => {
        const row = rows.find(item => String(item.id) === medicine.value);
        document.getElementById('allocation-route').textContent = row?.route || 'Nije evidentiran';
        document.getElementById('allocation-free').textContent = row?.free_label || 'Nema podataka';
        const available = row ? Number(row.free) : 0;
        quantity.max = String(available);
        document.getElementById('allocation-unavailable').hidden = available > 0;
        submit.disabled = available < 1;
        const sources = document.getElementById('allocation-sources');
        sources.replaceChildren();
        for (const source of row?.sources || []) {
            const item = document.createElement('li');
            item.textContent = `${source.quantity} · ${source.known ? source.label : 'Porijeklo nije utvrđeno'}`;
            sources.append(item);
        }
        quantity.setCustomValidity('');
    };
    medicine.addEventListener('change', update);
    window.addEventListener('pageshow', update);
    quantity.addEventListener('input', () => {
        quantity.setCustomValidity(Number(quantity.value) > Number(quantity.max)
            ? 'Nema dovoljno slobodne fizičke zalihe za ovu prezentaciju.' : '');
    });
    form.addEventListener('submit', () => { submit.disabled = true; });
    update();
})();
