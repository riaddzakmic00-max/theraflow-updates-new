(() => {
    const form = document.getElementById('bulk-receipt-form');
    if (!form) return;
    const groups = [...form.querySelectorAll('[data-receipt-medicine]')];
    const button = form.querySelector('#confirm-selected');
    if (!button) return;
    const verified = form.querySelector('#receipt-verified');
    const proposal = form.querySelector('[name=proposal_token]');
    const owners = JSON.parse(document.getElementById('agreement-number-owners')?.textContent || '{}');
    const number = input => input.value.trim() === '' ? null : Number(input.value.replace(',', '.'));
    const format = n => new Intl.NumberFormat('bs-BA', {maximumFractionDigits:2}).format(n);
    const text = (g, n) => {
        if (n === null || !Number.isFinite(n)) return 'Nije uneseno';
        const rest = Math.abs(n) % 100, last = Math.abs(n) % 10;
        const unit = Number.isInteger(n) && !(rest >= 11 && rest <= 14) ? (last === 1 ? g.dataset.unitOne : last >= 2 && last <= 4 ? g.dataset.unitFew : g.dataset.unitMany) : g.dataset.unitMany;
        const packCount = n / Number(g.dataset.packageSize);
        const packLabel = packCount % 10 === 1 && packCount % 100 !== 11 ? 'pakovanje' : 'pakovanja';
        const packages = g.dataset.packages === 'true' ? ` · ${format(packCount)} ${packLabel}` : '';
        return `${format(n)} ${unit}${packages}`;
    };
    function update() {
        let valid = true, selected = 0;
        groups.forEach(g => {
            const arrived = g.querySelector('.received-input');
            if (!arrived) return;
            const value = number(arrived);
            let allocated = 0;
            const rows = [...g.querySelectorAll('.allocation-row[data-pending]')];
            rows.forEach(row => {
                const agreement = row.querySelector('.agreement-submit-value');
                const qty = row.querySelector('.allocation-input');
                const choice = row.querySelector('.receipt-checkbox');
                const present = Boolean(agreement.value.trim());
                const possible = present && qty.dataset.blocked !== 'true' && qty.checkValidity() && number(qty) > 0;
                choice.disabled = !possible;
                if (!possible) { choice.checked = false; }
                if (choice.checked) { allocated += number(qty); selected += 1; }
                row.querySelector('[data-allocation-unit]').textContent = text(g, number(qty));
                const original = row.dataset.originalNumber;
                const state = row.querySelector('[data-agreement-state]');
                if (state && !original) {
                    state.textContent = present ? 'Broj će se sačuvati uz potvrdu raspodjele.' : 'Saglasnost nedostaje — raspodjela nije spremna.';
                    row.querySelector('summary').textContent = present ? 'Unesena saglasnost · Pregledaj' : 'Unesi broj saglasnosti';
                }
                const other = (owners[agreement.value.trim().toLocaleLowerCase()] || []).filter(o => String(o.id) !== row.dataset.patient);
                row.querySelector('[data-agreement-notice]').textContent = other.length
                    ? `Isti broj postoji kod drugog pacijenta: ${other.map(o=>o.name).join(', ')}. Provjerite dokument; zapisi neće biti spojeni.`
                    : original && original !== agreement.value.trim() ? `Pri potvrdi: ${original} → ${agreement.value.trim() || 'nije uneseno'}.` : '';
            });
            const remaining = value === null ? null : value - allocated;
            let message = value === null || value === 0 ? 'Unesite fizički prebrojanu količinu.' : 'Raspodjela odgovara ovoj pošiljci.';
            let groupValid = true;
            if (!arrived.checkValidity()) { message = 'Količina prelazi očekivano ili nije u cijelim pakovanjima.'; groupValid = false; }
            const lotInputs = [...g.querySelectorAll('.lot-quantity-input:not(:disabled)')];
            if (lotInputs.length && value > 0) {
                const lotTotal = lotInputs.reduce((sum, input) => sum + (number(input) || 0), 0);
                if (lotInputs.some(input => !input.checkValidity() || !(number(input) > 0)) || Math.abs(lotTotal - value) > 0.000001) {
                    message = 'Zbir pozitivnih količina svih serija mora biti jednak količini „Stiglo sada“.';
                    groupValid = false;
                }
            }
            if (remaining < 0 || (value === null && allocated)) { message = 'Raspodijeljeno je više nego što je stiglo.'; groupValid = false; }
            else if (groupValid && remaining > 0) { message = 'Neraspoređeni ostatak će ostati u slobodnoj fizičkoj zalihi nakon potvrde.'; }
            if (value > 0 && !proposal.value) message = 'Kliknite „Predloži raspodjelu“ i pregledajte prijedlog.';
            g.querySelector('[data-distribution]').textContent = message;
            g.querySelector('[data-distribution]').classList.toggle('is-warning', !groupValid);
            g.querySelector('[data-arrived-unit]').textContent = text(g, value);
            const review = form.querySelector(`[data-review-medicine="${g.dataset.receiptMedicine}"]`);
            review.hidden = !(value || allocated);
            review.querySelector('[data-review-arrived]').textContent = text(g,value);
            review.querySelector('[data-review-allocated]').textContent = text(g,allocated);
            review.querySelector('[data-review-free]').textContent = remaining !== null && remaining < 0 ? `Prekoračeno: ${text(g,-remaining)}` : text(g,remaining);
            valid = valid && groupValid;
        });
        form.querySelector('[data-review-empty]').hidden = selected > 0 || groups.some(g=>Number(g.querySelector('.received-input')?.value)>0);
        form.querySelector('[data-selected-count]').textContent = selected;
        form.querySelectorAll('[data-required-date]').forEach(input=> { valid = valid && input.checkValidity(); });
        const hasArrival = groups.some(g=>number(g.querySelector('.received-input') || {value:''}) > 0);
        const reference = form.querySelector('#shipment-reference');
        button.disabled = !valid || !hasArrival || !proposal.value || !reference.checkValidity() || !verified.checked || form.dataset.submitting === 'true';
    }
    function invalidateProposal() {
        proposal.value=''; verified.checked=false;
        form.querySelectorAll('[data-proposal-summary]').forEach(el=>{el.hidden=true;});
    }
    function updateSeries(group) {
        const multiple = group.querySelectorAll('[data-series-row]').length > 1;
        const primary = group.querySelector('[data-series-primary-quantity]');
        primary.hidden = !multiple;
        primary.querySelector('input').disabled = !multiple;
        primary.querySelector('input').required = multiple;
        group.querySelector('[data-series-hint]').hidden = !multiple;
    }
    form.addEventListener('click', event => {
        const add = event.target.closest('[data-add-series]');
        const remove = event.target.closest('[data-remove-series]');
        if (!add && !remove) return;
        const group = event.target.closest('[data-receipt-medicine]');
        if (remove) remove.closest('[data-series-row]').remove();
        else {
            const container = group.querySelector('[data-series-container]');
            const used = new Set([...container.querySelectorAll('[data-series-row]')].map(row => Number(row.dataset.seriesRow)));
            let index = 1;
            while (used.has(index)) index += 1;
            if (index >= 20) return;
            const primaryQuantity = group.querySelector('[data-series-primary-quantity] input');
            if (primaryQuantity.disabled) primaryQuantity.value = group.querySelector('.received-input').value;
            const medicine = group.dataset.receiptMedicine;
            const row = document.createElement('div');
            row.className = 'receipt-dates';
            row.dataset.seriesRow = String(index);
            const fields = [
                ['Dodatna serija', `serija_lijek_${medicine}_${index}`, 'text'],
                ['Rok trajanja serije', `rok_lijek_${medicine}_${index}`, 'date'],
                ['Količina ove serije', `lot_quantity_${medicine}_${index}`, 'number']
            ];
            fields.forEach(([caption, name, type]) => {
                const cell = document.createElement('div');
                const label = document.createElement('label');
                const input = document.createElement('input');
                label.textContent = caption; label.htmlFor = name;
                input.name = name; input.id = name; input.type = type;
                if (type === 'number') {
                    input.min = '0'; input.step = group.dataset.packageSize;
                    input.required = true; input.className = 'lot-quantity-input';
                } else if (type === 'text') input.maxLength = 100;
                cell.append(label, input);
                if (type === 'number') {
                    const button = document.createElement('button');
                    button.type = 'button'; button.className = 'tf-btn-secondary';
                    button.dataset.removeSeries = ''; button.textContent = 'Ukloni seriju';
                    cell.append(button);
                }
                row.append(cell);
            });
            container.append(row);
            row.querySelector('input').focus();
        }
        updateSeries(group); invalidateProposal(); update();
    });
    form.querySelector('#receipt-medicine-choice')?.addEventListener('change', e=> {
        groups.forEach(g=> {
            const hidden = e.target.value && e.target.value !== g.dataset.receiptMedicine;
            g.hidden=Boolean(hidden);
            if(hidden) {
                const input=g.querySelector('.received-input');if(input)input.value='';
                g.querySelectorAll('.receipt-checkbox').forEach(c=>{c.checked=false;});
            }
        });
        invalidateProposal();update();
    });
    form.addEventListener('input',e=>{
        if(e.target!==verified) verified.checked=false;
        if(e.target.matches('.received-input, .lot-quantity-input, #shipment-reference, [data-required-date], [name^=serija_lijek_], [name^=rok_lijek_], .agreement-submit-value')) invalidateProposal();
        update();
    });
    form.addEventListener('change',e=>{ if(e.target!==verified) verified.checked=false;update(); });
    form.addEventListener('invalid', e => { let p=e.target.parentElement;while(p&&p!==form){if(p.tagName==='DETAILS')p.open=true;p=p.parentElement;} },true);
    form.addEventListener('submit',e=> {
        form.querySelector('[name=bulk_action]').value=e.submitter?.value || 'confirm_selected';
        if (e.submitter?.value === 'propose_distribution') {
            verified.checked=false;
            return;
        }
        update();
        if (button.disabled) {e.preventDefault();return;}
        form.dataset.submitting='true';button.disabled=true;button.setAttribute('aria-busy','true');
        button.textContent='Potvrđujem fizički prijem…';
    });
    window.addEventListener('pageshow',()=>{form.dataset.submitting='false';button.removeAttribute('aria-busy');button.textContent='Potvrdi zaprimanje i raspodjelu';verified.checked=false;update();});
    update();
})();
