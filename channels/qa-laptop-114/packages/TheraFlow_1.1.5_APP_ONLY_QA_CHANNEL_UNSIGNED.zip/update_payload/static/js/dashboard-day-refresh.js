(() => {
    "use strict";
    const page = document.querySelector("[data-dashboard-day-refresh]");
    if (!page) return;
    // The server computes the remaining time until Sarajevo midnight, including
    // daylight saving. Browser timezone and a fixed 24-hour interval are irrelevant.
    const remaining = Number(page.dataset.dashboardDayRefresh);
    if (!Number.isFinite(remaining) || remaining < 0) return;
    const deadline = Date.now() + remaining;
    let refreshing = false;
    const refreshAfterMidnight = () => {
        if (!refreshing && Date.now() >= deadline) {
            refreshing = true;
            window.location.reload();
        }
    };
    window.setTimeout(refreshAfterMidnight, remaining + 50);
    // Recheck after browser sleep, a background tab or restoration from history.
    window.setInterval(refreshAfterMidnight, 60000);
    document.addEventListener("visibilitychange", refreshAfterMidnight);
    window.addEventListener("pageshow", refreshAfterMidnight);
})();
