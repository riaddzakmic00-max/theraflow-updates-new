document.addEventListener('DOMContentLoaded', () => {
  const shell = document.querySelector('#correction-center');
  if (!shell) return;
  const forms = [...document.querySelectorAll('main form[method="post"]')];
  const entry = forms.find(f => f.matches('[data-correction-entry],.pcw-entry')) || forms.find(f => f.querySelector('textarea')) || forms.find(f => f.querySelector('input[name="action"][value="preview"]'));
  const restore = JSON.parse(document.querySelector('#correction-restore').textContent);
  if (restore && entry) {
    for (const [name,values] of Object.entries(restore)) {
      [...entry.elements].filter(el => el.name === name).forEach(el => {
        if (['checkbox','radio'].includes(el.type)) el.checked = values.includes(el.value);
        else if (el.tagName === 'SELECT' && el.multiple) [...el.options].forEach(o => o.selected=values.includes(o.value));
        else if (el.dataset.theraflowDateEnhanced === 'true') window.TheraFlowDates.setDateInputValue(el, values[0] || '');
        else el.value = values[0] || '';
      });
    }
    const note=document.createElement('p');note.className='cc-warning';note.textContent='Unos je vraćen. Povezani podaci su možda promijenjeni; ponovo pregledajte posljedice prije potvrde.';entry.prepend(note);
  }
  shell.querySelectorAll('[data-correction-switch]').forEach(button => button.addEventListener('click', async () => {
    const error=shell.querySelector('[data-draft-error]');error.textContent='';
    const submitted=JSON.parse(document.querySelector('#correction-last-input').textContent);
    if (!entry && !submitted) {error.textContent='Otvorite novi unos; već potvrđena radnja se ne ponavlja.';return;}
    const values=submitted || {};
    if (entry) for (const [key,value] of new FormData(entry).entries()) if (typeof value==='string') values[key]=new FormData(entry).getAll(key).filter(v => typeof v==='string');
    const csrf=document.querySelector('main [name="csrfmiddlewaretoken"]');button.disabled=true;
    try {
      const response=await fetch(shell.dataset.draftUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRFToken':csrf.value},body:JSON.stringify({current:location.pathname+location.search,destination:button.dataset.correctionSwitch,values})});
      const data=await response.json();if (!response.ok) throw new Error(data.error);
      location.assign(data.url);
    } catch (exc) {error.textContent=exc.message || 'Unos nije sačuvan. Ostanite na obrascu i ponovite pokušaj.';button.disabled=false;}
  }));
});
