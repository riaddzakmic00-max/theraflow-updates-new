/* Read-only GS1 element-string parser; it never identifies a catalogue product.
 * Primary references:
 * https://ref.gs1.org/guidelines/datamatrix/ (2.2, 2.3, 3.3)
 * https://github.com/gs1/gs1-syntax-dictionary (AI 01/10/17/21)
 * https://ref.gs1.org/guidelines/2d-in-retail/1.0.0/ (healthcare DD rule)
 */
(function (root, factory) {
    'use strict';
    const api = factory();
    if (typeof module === 'object' && module.exports) module.exports = api;
    if (root) root.TheraFlowGS1 = api;
})(typeof window === 'undefined' ? globalThis : window, function () {
    'use strict';
    const GS = '\x1d';
    const LENGTHS = Object.freeze({'01': 14, '10': null, '17': 6, '21': null});
    const VARIABLE = /^[!"%&'()*+,\-./0-9:;<=>?A-Z_a-z]{1,20}$/;
    const owns = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
    const two = number => String(number).padStart(2, '0');

    function validGTIN(gtin) {
        if (!/^\d{14}$/.test(gtin) || /^0{14}$/.test(gtin)) return false;
        let sum = 0;
        for (let i = 0; i < 13; i += 1) sum += Number(gtin[i]) * (i % 2 === 0 ? 3 : 1);
        return (10 - sum % 10) % 10 === Number(gtin[13]);
    }

    function result(changes = {}) {
        return Object.freeze(Object.assign({
            ok: false, partial: false, complete: false, code: '', error: '', message: '',
            gtin: '', batch: '', expiry: '', expiryISO: '', expiryRaw: '', serial: '',
            expiryDayUnspecified: false, isExpired: null, productMatch: null,
            canApplyBatch: false, canApplyExpiry: false,
            warnings: Object.freeze([]), fieldErrors: Object.freeze({}), fields: Object.freeze({}),
        }, changes));
    }

    function fail(code, error, fields) {
        return result({code, error, message: error, fields: Object.freeze(Object.assign({}, fields))});
    }

    function expiryDate(raw, now, allowMonthOnly) {
        const currentYear = now && typeof now.getFullYear === 'function' ? now.getFullYear() : NaN;
        if (!Number.isFinite(currentYear))
            return {code: 'date', error: 'Nije moguće provjeriti godinu roka. Provjerite datum na pakovanju.'};
        const shortYear = Number(raw.slice(0, 2)), month = Number(raw.slice(2, 4));
        let day = Number(raw.slice(4, 6));
        // GS1 dates use the rolling window: 49 years past, 50 years future.
        let year = Math.floor(currentYear / 100) * 100 + shortYear;
        if (year > currentYear + 50) year -= 100;
        else if (year < currentYear - 49) year += 100;
        if (month < 1 || month > 12)
            return {code: 'date', error: 'Mjesec roka iz koda nije ispravan. Provjerite pakovanje.'};
        const unspecified = day === 0;
        const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
        if (unspecified && !allowMonthOnly)
            return {code: 'month-only', unspecified: true,
                error: 'Kod ima DD00 (opšti GS1: kraj mjeseca). Farmaceutski kod od 2025. mora imati dan 01–31; provjerite pakovanje i unesite tačan rok.'};
        if (unspecified) day = lastDay;
        if (day < 1 || day > lastDay)
            return {code: 'date', error: 'Rok iz koda nije ispravan kalendarski datum. Provjerite pakovanje.'};
        const iso = year + '-' + two(month) + '-' + two(day);
        const today = currentYear + '-' + two(now.getMonth() + 1) + '-' + two(now.getDate());
        return {iso, unspecified, expired: iso < today};
    }

    function parse(value, now = new Date(), options = {}) {
        if (typeof value !== 'string' || !value || value.length > 512)
            return fail('empty', 'Skenirajte GS1 kod ili unesite podatke s pakovanja ručno.');
        // A keyboard-wedge scanner can append Enter; never trim meaningful data.
        let code = value.replace(/[\r\n]+$/, '');
        if (!code) return fail('empty', 'Kod je prazan. Ponovo skenirajte.');
        const fields = Object.create(null);
        const add = (ai, data) => {
            if (!owns(LENGTHS, ai))
                return fail('unsupported', 'Kod sadrži nepodržani AI ' + ai + '. Provjerite podatke ručno.');
            if (owns(fields, ai))
                return fail('duplicate', 'AI ' + ai + ' je naveden više puta. Ponovo skenirajte ili provjerite pakovanje.');
            if (LENGTHS[ai] !== null && !new RegExp('^\\d{' + LENGTHS[ai] + '}$').test(data))
                return fail('length', 'AI ' + ai + ' nema ispravan broj cifara. Ponovo skenirajte.');
            if (LENGTHS[ai] === null && !VARIABLE.test(data))
                return fail('variable', 'AI ' + ai + ' mora imati 1–20 dozvoljenih znakova. Provjerite FNC1 razdvajanje.');
            fields[ai] = data;
            return null;
        };
        if (code.startsWith('(')) {
            const markers = Array.from(code.matchAll(/\((\d{2,4})\)/g));
            if (!markers.length || markers[0].index !== 0)
                return fail('format', 'Kod nije u podržanom GS1 formatu. Provjerite podatke ručno.');
            for (let i = 0; i < markers.length; i += 1) {
                const marker = markers[i];
                // Spaces between HRI fields are presentation, not encoded data.
                const data = code.slice(marker.index + marker[0].length,
                    i + 1 < markers.length ? markers[i + 1].index : code.length).replace(/^ +| +$/g, '');
                const error = add(marker[1], data);
                if (error) return error;
            }
        } else {
            if (code.startsWith(']d2')) code = code.slice(3);
            else if (code.startsWith(']'))
                return fail('symbology', 'Skener nije poslao podržani GS1 DataMatrix kod. Provjerite podatke ručno.');
            let position = code.startsWith(GS) ? 1 : 0;
            if (position === code.length) return fail('empty', 'Kod ne sadrži podatke. Ponovo skenirajte.');
            while (position < code.length) {
                const ai = code.slice(position, position + 2);
                if (!owns(LENGTHS, ai))
                    return fail('unsupported', 'Kod sadrži nepoznati ili nepodržani AI. Provjerite FNC1 razdvajanje i podatke ručno.');
                position += 2;
                let data;
                if (LENGTHS[ai] !== null) {
                    data = code.slice(position, position + LENGTHS[ai]);
                    position += LENGTHS[ai];
                } else {
                    const end = code.indexOf(GS, position);
                    data = code.slice(position, end < 0 ? code.length : end);
                    position = end < 0 ? code.length : end;
                }
                const error = add(ai, data);
                if (error) return error;
                if (position < code.length && code[position] === GS) {
                    position += 1;
                    if (code[position] === GS)
                        return fail('separator', 'FNC1 razdvajanje nije ispravno. Ponovo skenirajte.');
                }
            }
        }
        if (!fields['01'])
            return fail('missing-gtin', 'Nedostaje GTIN (AI 01). Provjerite da je skeniran GS1 kod.', fields);
        if (!validGTIN(fields['01']))
            return fail('checksum', 'GTIN nema ispravnu kontrolnu cifru. Ponovo skenirajte ili provjerite podatke ručno.', fields);

        let productMatch = null;
        const expected = options && options.expectedGTIN;
        if (expected !== undefined && expected !== null && expected !== '') {
            const rawExpected = typeof expected === 'string' ? expected.trim() : '';
            const normalized = /^(?:\d{8}|\d{12}|\d{13}|\d{14})$/.test(rawExpected) ? rawExpected.padStart(14, '0') : '';
            if (!validGTIN(normalized))
                return fail('catalogue-gtin', 'GTIN veza u katalogu nije pouzdana. Provjerite lijek i podatke ručno.', fields);
            productMatch = normalized === fields['01'];
            if (!productMatch)
                return result({code: 'gtin-mismatch', error: 'Skenirani GTIN ne odgovara odabranom lijeku.',
                    message: 'Skenirani GTIN ne odgovara odabranom lijeku.', gtin: fields['01'], productMatch,
                    fields: Object.freeze(Object.assign({}, fields))});
        }
        const warnings = [];
        if (productMatch === null)
            warnings.push('Lijek nije potvrđen GTIN vezom u katalogu. Provjerite naziv, jačinu i oblik na pakovanju.');
        const batch = fields['10'] || '', serial = fields['21'] || '', expiryRaw = fields['17'] || '';
        const decoded = expiryRaw ? expiryDate(expiryRaw, now, Boolean(options && options.allowMonthOnly)) : {};
        const fieldErrors = decoded.error ? {expiry: decoded.error} : {};
        if (!batch) warnings.push('Kod nema seriju (AI 10). Unesite je ručno kada je poznata.');
        if (!expiryRaw) warnings.push('Kod nema rok (AI 17). Unesite ga ručno kada je poznat.');
        if (decoded.error) warnings.push(decoded.error);
        if (decoded.unspecified && decoded.iso)
            warnings.push('DD00 je protumačen kao posljednji dan mjeseca prema opštem GS1 pravilu.');
        if (decoded.expired) warnings.push('Rok iz koda je prošao. Provjerite datum stvarnog prijema.');
        const expiry = decoded.iso || '';
        return result({ok: !decoded.error, partial: !batch || !expiry, complete: Boolean(batch && expiry),
            code: decoded.code || '', error: decoded.error || '', message: decoded.error || '',
            gtin: fields['01'], batch, expiry, expiryISO: expiry, expiryRaw, serial,
            expiryDayUnspecified: Boolean(decoded.unspecified), isExpired: expiry ? Boolean(decoded.expired) : null,
            productMatch, canApplyBatch: Boolean(batch), canApplyExpiry: Boolean(expiry),
            warnings: Object.freeze(warnings), fieldErrors: Object.freeze(fieldErrors),
            fields: Object.freeze(Object.assign({}, fields))});
    }
    return Object.freeze({parse});
});
