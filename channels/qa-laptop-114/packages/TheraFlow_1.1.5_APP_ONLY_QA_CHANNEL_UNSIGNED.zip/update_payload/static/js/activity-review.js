/* Progressive GET-only panels; the complete review remains available as a link. */
(() => {
  const load = async node => {
    if (node.dataset.activityLoaded) return;
    node.dataset.activityLoaded = '1';
    node.setAttribute('aria-busy', 'true');
    try {
      const response = await fetch(node.dataset.activityUrl, {credentials: 'same-origin', headers: {'Accept': 'text/html'}});
      if (!response.ok || response.redirected) throw new Error('Review unavailable');
      node.innerHTML = await response.text();
    } catch (_) {
      node.textContent = 'Pregled trenutno nije dostupan. Otvorite puni pregled putem linka iznad ili osvježite ekran.';
    } finally { node.removeAttribute('aria-busy'); }
  };
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) { observer.unobserve(entry.target); load(entry.target); }
  }));
  document.querySelectorAll('[data-activity-url]').forEach(node => observer.observe(node));
})();
