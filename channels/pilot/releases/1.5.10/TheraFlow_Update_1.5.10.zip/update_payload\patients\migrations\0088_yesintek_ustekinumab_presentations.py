from decimal import Decimal

from django.db import migrations


def rename_ustekinumab_presentations(apps, schema_editor):
    """Preimenuj kanonske SKU redove bez promjene PK/FK odnosa."""
    Lijek = apps.get_model("patients", "Lijek")
    TerapijskiProtokol = apps.get_model("patients", "TerapijskiProtokol")

    presentations = (
        (
            {"naziv": "Stelara 130 mg IV"},
            {
                "naziv": "Yesintek 130 mg IV",
                "zasticeno_ime": "Yesintek",
            },
        ),
        (
            {"naziv": "Uzpruvo 90 mg SC"},
            {
                "naziv": "Yesintek 90 mg/1 mL SC",
                "zasticeno_ime": "Yesintek",
            },
        ),
    )
    for lookup, values in presentations:
        sources = Lijek.objects.filter(
            genericki_naziv__iexact="Ustekinumab",
            **lookup,
        )
        # Migration compatibility tests (and interrupted legacy upgrades) can
        # legitimately contain the target presentation already. ``naziv`` is
        # unique, so a bulk rename must not collide with that canonical row.
        target = Lijek.objects.filter(naziv=values["naziv"]).first()
        if target:
            Lijek.objects.filter(pk=target.pk).update(
                zasticeno_ime=values["zasticeno_ime"]
            )
            sources = sources.exclude(pk=target.pk)
            continue
        sources.update(**values)

    # Aktivna master-konfiguracija nije historijski/audit tekst.
    TerapijskiProtokol.objects.filter(
        naziv="Stelara održavanje",
        lijek__genericki_naziv__iexact="Ustekinumab",
    ).update(naziv="Yesintek održavanje")


class Migration(migrations.Migration):
    dependencies = [("patients", "0087_commission_request_classification")]

    operations = [
        migrations.RunPython(
            rename_ustekinumab_presentations,
            migrations.RunPython.noop,
        ),
    ]
