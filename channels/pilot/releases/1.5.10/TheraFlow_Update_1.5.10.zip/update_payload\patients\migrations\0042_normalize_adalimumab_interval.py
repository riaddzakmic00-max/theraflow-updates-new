from decimal import Decimal

from django.db import migrations
from django.db.models import Q


ADALIMUMAB_ALIASES = (
    "adalimumab",
    "hyrimoz",
    "humira",
    "amgevita",
    "imraldi",
    "yuflyma",
)


def _adalimumab_query():
    query = Q()
    for alias in ADALIMUMAB_ALIASES:
        query |= Q(genericki_naziv__icontains=alias)
        query |= Q(naziv__icontains=alias)
        query |= Q(zasticeno_ime__icontains=alias)
    return query


def normalize_adalimumab_interval(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    Pacijent = apps.get_model("patients", "Pacijent")
    Terapija = apps.get_model("patients", "Terapija")
    TerapijskiProtokol = apps.get_model("patients", "TerapijskiProtokol")
    TerapijskiKorak = apps.get_model("patients", "TerapijskiKorakProtokola")

    lijek_ids = list(
        Lijek.objects.filter(_adalimumab_query()).values_list("id", flat=True)
    )
    if not lijek_ids:
        return

    Lijek.objects.filter(id__in=lijek_ids).update(
        kucna_primjena=True,
        nacin_primjene="KUCNA_TERAPIJA",
    )
    Pacijent.objects.filter(lijek_id__in=lijek_ids).update(interval_sedmica=2)
    TerapijskiProtokol.objects.filter(lijek_id__in=lijek_ids).update(
        interval_odrzavanja_sedmica=2,
    )
    TerapijskiKorak.objects.filter(
        protokol__lijek_id__in=lijek_ids,
        faza="ODRZAVANJE",
    ).update(
        interval_sedmica=2,
        nacin_primjene_koraka="KUCNA_TERAPIJA",
    )
    Terapija.objects.filter(
        Q(lijek_id__in=lijek_ids),
        Q(tip_evidencije="IZDAVANJE_KUCNE_TERAPIJE")
        | Q(terapijski_korak__faza="ODRZAVANJE"),
    ).update(interval_sedmica=2)

    standardni = TerapijskiProtokol.objects.filter(
        lijek_id__in=lijek_ids,
        naziv__iexact="Odrzavanje kucne terapije",
    )
    for protokol in standardni:
        protokol.tip_terapije = "ODRZAVANJE"
        protokol.indukcijske_sedmice = ""
        protokol.interval_odrzavanja_sedmica = 2
        protokol.doza_po_aplikaciji = 1
        protokol.napomena = "Default protokol: kucna terapija svakih 2 sedmice."
        protokol.aktivan = True
        protokol.save()

        korak = TerapijskiKorak.objects.filter(
            protokol=protokol,
            naziv_koraka__iexact="Odrzavanje kuci",
        ).order_by("id").first()
        if not korak:
            korak = TerapijskiKorak.objects.filter(
                protokol=protokol,
                faza="ODRZAVANJE",
            ).order_by("id").first()
        if not korak:
            korak = TerapijskiKorak(protokol=protokol)

        korak.naziv_koraka = "Odrzavanje kuci"
        korak.faza = "ODRZAVANJE"
        korak.sedmica_od_pocetka = 0
        korak.redoslijed = 1
        korak.doza_mg = Decimal("40")
        korak.broj_jedinica = Decimal("1")
        korak.interval_sedmica = 2
        korak.nacin_primjene_koraka = "KUCNA_TERAPIJA"
        korak.aktivan = True
        korak.save()
        TerapijskiKorak.objects.filter(protokol=protokol).exclude(
            id=korak.id
        ).update(aktivan=False)


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0041_zalihatransakcija"),
    ]

    operations = [
        migrations.RunPython(
            normalize_adalimumab_interval,
            migrations.RunPython.noop,
        ),
    ]
