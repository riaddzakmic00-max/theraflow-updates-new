from decimal import Decimal

from django.conf import settings
from django.db.models import Q
from django.utils import timezone

from .models import Pacijent, TerapijaStatusHistorija


VIDEO_DEMO_MARKER = "VIDEO DEMO TERMIN"
VIDEO_DEMO_NOTE = "VIDEO DEMO TERMIN — privremeno kreiran za snimanje."


def video_demo_environment_allowed():
    """Dozvoli komande samo u DEBUG ili lokalnom desktop okruženju."""

    return bool(
        getattr(settings, "DEBUG", False)
        or not getattr(settings, "PRODUCTION_MODE", False)
    )


def find_demo_patient(identifier):
    identifier = (identifier or "").strip()
    if not identifier:
        raise ValueError("Obavezan je JMBG ili demo identifikator.")

    queryset = Pacijent.objects.select_related("lijek", "terapijski_protokol")
    exact = list(queryset.filter(jmbg__iexact=identifier)[:2])
    if exact:
        matches = exact
    else:
        matches_query = queryset
        for token in identifier.split():
            matches_query = matches_query.filter(
                Q(ime__icontains=token)
                | Q(prezime__icontains=token)
                | Q(jmbg__icontains=token)
            )
        matches = list(matches_query.order_by("id")[:3])

    if not matches:
        raise ValueError(f"Pacijent '{identifier}' nije pronađen.")
    if len(matches) > 1:
        raise ValueError(
            "Demo identifikator odgovara više pacijenata. Koristite tačan JMBG."
        )

    patient = matches[0]
    demo_text = " ".join(
        (patient.ime or "", patient.prezime or "", patient.jmbg or "")
    ).casefold()
    if "demo" not in demo_text:
        raise ValueError(
            "Komanda je dozvoljena samo pacijentu koji u imenu, prezimenu "
            "ili JMBG-u ima oznaku DEMO."
        )
    return patient


def validate_demo_patient_for_appointment(patient):
    if not patient.aktivan:
        raise ValueError("Demo pacijent nije aktivan.")
    if not patient.lijek_id or not patient.lijek.aktivan:
        raise ValueError("Demo pacijent mora imati aktivan lijek.")

    protocol = patient.aktivni_protokol()
    if protocol is None or not getattr(protocol, "aktivan", True):
        raise ValueError("Demo pacijent mora imati aktivan terapijski protokol.")

    quantity = patient.kolicina_po_terapiji
    if quantity is None or Decimal(str(quantity)) <= 0:
        raise ValueError("Demo pacijent nema unesenu količinu po terapiji.")
    return protocol, Decimal(str(quantity))


def tagged_video_demo_appointment_ids(*, start_date=None, end_date=None):
    queryset = TerapijaStatusHistorija.objects.filter(
        termin_id__isnull=False,
        razlog__startswith=VIDEO_DEMO_MARKER,
    )
    if start_date is not None:
        queryset = queryset.filter(termin__datum__gte=start_date)
    if end_date is not None:
        queryset = queryset.filter(termin__datum__lte=end_date)
    return set(queryset.values_list("termin_id", flat=True))


def today():
    return timezone.localdate()
