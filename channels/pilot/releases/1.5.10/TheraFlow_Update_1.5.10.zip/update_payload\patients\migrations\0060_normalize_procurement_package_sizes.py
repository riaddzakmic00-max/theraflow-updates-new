from django.db import migrations
from django.db.models import Q


GROUPS = (
    (
        2,
        ("adalimumab",),
        ("Hyrimoz", "Humira", "Amgevita", "Imraldi", "Yuflyma"),
    ),
    (
        1,
        ("vedolizumab",),
        ("Entyvio",),
    ),
    (
        1,
        ("infliximab", "infliksimab"),
        ("Remsima", "Remicade", "Inflectra", "Flixabi", "Zessly"),
    ),
)


def normalize_procurement_package_sizes(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    for package_size, generic_names, aliases in GROUPS:
        query = Q()
        for generic_name in generic_names:
            query |= Q(genericki_naziv__icontains=generic_name)
        for alias in aliases:
            query |= Q(naziv__icontains=alias)
            query |= Q(zasticeno_ime__icontains=alias)
        Lijek.objects.filter(query).update(package_size_in_doses=package_size)


class Migration(migrations.Migration):
    dependencies = [("patients", "0059_extraordinary_commission_requests")]

    operations = [
        migrations.RunPython(
            normalize_procurement_package_sizes,
            migrations.RunPython.noop,
        ),
    ]
