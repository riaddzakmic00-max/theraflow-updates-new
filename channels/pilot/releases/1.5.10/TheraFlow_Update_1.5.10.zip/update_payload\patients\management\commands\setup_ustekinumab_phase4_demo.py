from datetime import date, time
from decimal import Decimal
from pathlib import Path

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from patients.models import (
    FazniProtokolPacijenta,
    Komisija,
    KomisijskiCiklus,
    KomisijskiZahtjev,
    Lijek,
    Pacijent,
    TerapijskiProgram,
    Termin,
    Zaliha,
)
from patients.phased_protocols import (
    configure_ustekinumab_protocol,
    create_ustekinumab_commission_proposal,
    ensure_phase_reservation,
)
from patients.services import confirm_therapy_arrival
from patients.therapy_workflow import schedule_therapy_appointment


DEMO_JMBG = "9904000000004"
DEMO_USERNAME = "phase4-demo"
DEMO_PASSWORD = "Phase4Demo!2026"
IV_DATE = date(2026, 9, 7)
SC_DATE = date(2026, 11, 2)


class Command(BaseCommand):
    help = "Priprema lokalni Phase 4 ustekinumab demo kroz tri kontrolisana koraka."

    def add_arguments(self, parser):
        parser.add_argument(
            "--stage",
            choices=("activation", "iv", "sc"),
            default="activation",
        )

    def _assert_test_database(self):
        database_name = str(settings.DATABASES["default"]["NAME"])
        if Path(database_name).name != ".test_theraflow.sqlite3":
            raise CommandError(
                "Demo komanda je dozvoljena samo nad .test_theraflow.sqlite3 bazom."
            )

    def _user(self):
        user, _created = get_user_model().objects.get_or_create(
            username=DEMO_USERNAME,
            defaults={
                "email": "phase4-demo@theraflow.local",
                "is_staff": True,
                "is_superuser": True,
            },
        )
        user.is_staff = True
        user.is_superuser = True
        user.set_password(DEMO_PASSWORD)
        user.save()
        return user

    def _medicine(self, *, program, name, brand, strength, route, singular, plural):
        medicine, _created = Lijek.objects.update_or_create(
            naziv=name,
            defaults={
                "genericki_naziv": "Ustekinumab",
                "zasticeno_ime": brand,
                "jacina_mg": strength,
                "put_primjene": route,
                "nacin_primjene": Lijek.NACIN_AMBULANTA,
                "jedinica_terapije": singular,
                "jedinica_terapije_mnozina": plural,
                "jedinica_zalihe": singular,
                "jedinica_zalihe_mnozina": plural,
                "aktivan": True,
                "terapijski_program": program,
            },
        )
        return medicine

    def _objects(self):
        patient = Pacijent.objects.filter(jmbg=DEMO_JMBG).first()
        if not patient:
            raise CommandError("Prvo pokrenite demo sa --stage activation.")
        state = FazniProtokolPacijenta.objects.select_related(
            "iv_lijek", "sc_lijek"
        ).get(pacijent=patient)
        user = get_user_model().objects.get(username=DEMO_USERNAME)
        return patient, state, user

    @transaction.atomic
    def _activation(self):
        user = self._user()
        program = TerapijskiProgram.objects.get(kljuc="ustekinumab")
        existing = Pacijent.objects.filter(jmbg=DEMO_JMBG).first()
        if existing:
            KomisijskiZahtjev.objects.filter(pacijent=existing).delete()
            existing.delete()

        iv = self._medicine(
            program=program,
            name="Yesintek Phase 4 Demo 130 mg IV",
            brand="Yesintek",
            strength=Decimal("130"),
            route=Lijek.PUT_IV,
            singular="bočica",
            plural="bočice",
        )
        sc = self._medicine(
            program=program,
            name="Yesintek Phase 4 Demo 90 mg/1 mL SC",
            brand="Yesintek",
            strength=Decimal("90"),
            route=Lijek.PUT_SC,
            singular="SC jedinica",
            plural="SC jedinice",
        )
        Zaliha.objects.update_or_create(
            lijek=iv,
            defaults={"u_frizideru": Decimal("8"), "kod_pacijenata": 0},
        )
        Zaliha.objects.update_or_create(
            lijek=sc,
            terapijski_program=program,
            defaults={"u_frizideru": Decimal("4"), "kod_pacijenata": 0},
        )
        cycle, _created = KomisijskiCiklus.objects.update_or_create(
            naziv="KOM-PHASE4-DEMO-2026-08",
            defaults={
                "mjesec": 8,
                "godina": 2026,
                "datum_komisije": date(2026, 8, 20),
                "status": "nacrt",
            },
        )
        patient = Pacijent.objects.create(
            ime="Lejla",
            prezime="Ustekinumab Demo",
            jmbg=DEMO_JMBG,
            dijagnoza="Morbus Crohn",
            mkb_sifra="K50.9",
            lijek=sc,
            interval_sedmica=8,
            aktivan=True,
        )
        state = configure_ustekinumab_protocol(
            patient=patient,
            iv_medicine=iv,
            sc_medicine=sc,
            phase=FazniProtokolPacijenta.FAZA_CEKA_IV,
            maintenance_interval=8,
            user=user,
            prescribed_iv_dose_mg=Decimal("390"),
        )
        create_ustekinumab_commission_proposal(
            state=state,
            cycle=cycle,
            request_type=KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_NOVI,
            include_first_sc=True,
            user=user,
        )
        Komisija.objects.create(
            pacijent=patient,
            lijek=iv,
            datum_odobrenja=date(2026, 8, 21),
            broj_odobrenih_doza=Decimal("3"),
            preostale_doze=Decimal("3"),
            broj_saglasnosti="PH4-IV-2026",
            status="AKTIVNA",
        )
        Komisija.objects.create(
            pacijent=patient,
            lijek=sc,
            datum_odobrenja=date(2026, 8, 21),
            broj_odobrenih_doza=Decimal("4"),
            preostale_doze=Decimal("4"),
            broj_saglasnosti="PH4-SC-2026",
            status="AKTIVNA",
        )
        appointment, _created = schedule_therapy_appointment(
            pacijent=patient,
            lijek=iv,
            datum=IV_DATE,
            vrijeme=time(9, 0),
            user=user,
            kolicina_po_terapiji=Decimal("3"),
        )
        ensure_phase_reservation(state=state, appointment=appointment, user=user)
        return patient

    @transaction.atomic
    def _iv(self):
        patient, state, user = self._objects()
        if state.faza != state.FAZA_CEKA_IV:
            return patient
        appointment = Termin.objects.get(
            pacijent=patient,
            lijek=state.iv_lijek,
            datum=IV_DATE,
            status=Termin.STATUS_PLANIRANA,
        )
        confirm_therapy_arrival(
            termin=appointment,
            primljene_doze=Decimal("3"),
            interval_sedmica=8,
            korisnik=user,
        )
        return patient

    @transaction.atomic
    def _sc(self):
        patient, state, user = self._objects()
        if state.faza == state.FAZA_CEKA_IV:
            self._iv()
            patient, state, user = self._objects()
        if state.faza != state.FAZA_CEKA_PRVU_SC:
            return patient
        appointment = Termin.objects.get(
            pacijent=patient,
            lijek=state.sc_lijek,
            datum=SC_DATE,
            status=Termin.STATUS_PLANIRANA,
        )
        confirm_therapy_arrival(
            termin=appointment,
            primljene_doze=Decimal("1"),
            interval_sedmica=8,
            korisnik=user,
        )
        return patient

    def handle(self, *args, **options):
        self._assert_test_database()
        stage = options["stage"]
        patient = {
            "activation": self._activation,
            "iv": self._iv,
            "sc": self._sc,
        }[stage]()
        state = FazniProtokolPacijenta.objects.get(pacijent=patient)
        iv_stock = Zaliha.objects.get(lijek=state.iv_lijek).u_frizideru
        sc_stock = Zaliha.objects.get(lijek=state.sc_lijek).u_frizideru
        self.stdout.write(
            self.style.SUCCESS(
                f"Phase 4 demo: stage={stage}; patient_id={patient.pk}; "
                f"phase={state.faza}; IV stock={iv_stock}; SC stock={sc_stock}."
            )
        )
        self.stdout.write(
            f"Login: {DEMO_USERNAME} / {DEMO_PASSWORD}"
        )
