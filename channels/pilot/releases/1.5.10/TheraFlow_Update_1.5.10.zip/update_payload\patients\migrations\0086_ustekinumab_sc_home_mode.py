from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0085_ustekinumab_prescribed_iv_dose"),
    ]

    operations = [
        migrations.AddField(
            model_name="fazniprotokolpacijenta",
            name="sc_nacin_primjene",
            field=models.CharField(
                choices=[
                    ("AMBULANTA", "SC primjena u ambulanti"),
                    ("KUCNA_TERAPIJA", "Kućna terapija"),
                ],
                default="AMBULANTA",
                max_length=24,
            ),
        ),
        migrations.AddField(
            model_name="fazniprotokolpacijenta",
            name="kucna_terapija_od",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="fazniprotokolpacijenta",
            name="kucna_terapija_potvrdio",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="potvrdjeni_ustekinumab_kucni_prijelazi",
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AddField(
            model_name="fazniprotokolpacijenta",
            name="zadnji_povratak_u_ambulantu_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="fazniprotokolpacijenta",
            name="zadnji_povratak_u_ambulantu_evidentirao",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="evidentirani_ustekinumab_povratci_u_ambulantu",
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AddConstraint(
            model_name="fazniprotokolpacijenta",
            constraint=models.CheckConstraint(
                condition=(
                    models.Q(sc_nacin_primjene="AMBULANTA")
                    | models.Q(faza="ODRZAVANJE")
                ),
                name="fazni_sc_kucna_samo_odrzavanje",
            ),
        ),
    ]
