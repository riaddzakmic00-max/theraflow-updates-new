import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0061_migration_snapshot_remaining_dose_status"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="AdaptiveDecisionRecord",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("decision_type", models.CharField(choices=[("COMMISSION", "Komisijski prijedlog"), ("PROCUREMENT", "Nabavni prijedlog")], max_length=24)),
                ("system_proposal_json", models.JSONField(default=dict)),
                ("final_decision_json", models.JSONField(default=dict)),
                ("difference_json", models.JSONField(default=dict)),
                ("override_reason", models.CharField(blank=True, choices=[("DELIVERY_DELAY", "Očekivano kašnjenje isporuke"), ("EXTRA_RESERVE", "Dodatna sigurnosna rezerva"), ("THERAPY_PLAN", "Promjena plana terapije"), ("PATIENT_DELAYED", "Pacijent privremeno odgođen"), ("SECURED_ELSEWHERE", "Lijek već osiguran drugim putem"), ("INCOMPLETE_DATA", "Greška ili nepotpun podatak"), ("DOCTOR_AGREEMENT", "Dogovor sa ljekarom"), ("OTHER", "Drugo")], max_length=32)),
                ("override_note", models.TextField(blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("algorithm_version", models.CharField(max_length=100)),
                ("data_snapshot_hash", models.CharField(db_index=True, max_length=64)),
                ("is_test_data", models.BooleanField(db_index=True, default=False)),
                ("commission_cycle", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="adaptive_decisions", to="patients.komisijskiciklus")),
                ("medicine", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="adaptive_decisions", to="patients.lijek")),
                ("patient", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="adaptive_decisions", to="patients.pacijent")),
                ("protocol", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="adaptive_decisions", to="patients.terapijskiprotokol")),
                ("user", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="adaptive_decisions", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-created_at", "-id"]},
        ),
        migrations.CreateModel(
            name="OperationalOutcome",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("commission_date", models.DateField(blank=True, null=True)),
                ("expected_delivery_date", models.DateField(blank=True, null=True)),
                ("actual_delivery_date", models.DateField(blank=True, null=True)),
                ("planned_lead_time_days", models.IntegerField(blank=True, null=True)),
                ("actual_lead_time_days", models.IntegerField(blank=True, null=True)),
                ("delivery_variance_days", models.IntegerField(blank=True, null=True)),
                ("receipt_date", models.DateField(blank=True, null=True)),
                ("first_scheduled_therapy_after_receipt", models.DateField(blank=True, null=True)),
                ("postponed_therapy_count", models.PositiveIntegerField(default=0)),
                ("no_show_count", models.PositiveIntegerField(default=0)),
                ("postponement_reasons_json", models.JSONField(blank=True, default=list)),
                ("safety_reserve_consumed", models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ("shortage_risk_observed", models.BooleanField(default=False)),
                ("algorithm_version", models.CharField(max_length=100)),
                ("is_test_data", models.BooleanField(db_index=True, default=False)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("commission_cycle", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="adaptive_outcomes", to="patients.komisijskiciklus")),
                ("medicine", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="adaptive_outcomes", to="patients.lijek")),
            ],
            options={"ordering": ["-updated_at", "-id"]},
        ),
        migrations.CreateModel(
            name="AdaptiveInsight",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("insight_type", models.CharField(max_length=50)),
                ("title", models.CharField(max_length=200)),
                ("explanation", models.TextField()),
                ("sample_size", models.PositiveIntegerField(default=0)),
                ("confidence_level", models.CharField(choices=[("INSUFFICIENT", "Nedovoljno podataka"), ("PRELIMINARY", "Preliminarni uvid"), ("STABLE", "Stabilniji uvid")], default="INSUFFICIENT", max_length=20)),
                ("calculated_value", models.JSONField(blank=True, default=dict)),
                ("current_configured_value", models.JSONField(blank=True, default=dict)),
                ("status", models.CharField(choices=[("NEW", "Novi"), ("REVIEWED", "Pregledan"), ("DISMISSED", "Odbačen")], default="NEW", max_length=20)),
                ("algorithm_version", models.CharField(max_length=100)),
                ("generated_at", models.DateTimeField(auto_now_add=True)),
                ("reviewed_at", models.DateTimeField(blank=True, null=True)),
                ("is_test_data", models.BooleanField(db_index=True, default=False)),
                ("medicine", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="adaptive_insights", to="patients.lijek")),
                ("reviewed_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="reviewed_adaptive_insights", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-generated_at", "-id"]},
        ),
        migrations.AddIndex(
            model_name="adaptivedecisionrecord",
            index=models.Index(fields=["decision_type", "created_at"], name="adapt_dec_type_date_idx"),
        ),
        migrations.AddIndex(
            model_name="adaptivedecisionrecord",
            index=models.Index(fields=["medicine", "created_at"], name="adapt_dec_drug_date_idx"),
        ),
        migrations.AddConstraint(
            model_name="operationaloutcome",
            constraint=models.UniqueConstraint(fields=("medicine", "commission_cycle"), name="unique_adaptive_outcome_drug_cycle"),
        ),
        migrations.AddIndex(
            model_name="adaptiveinsight",
            index=models.Index(fields=["insight_type", "medicine", "generated_at"], name="adapt_ins_scope_date_idx"),
        ),
    ]
