from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0063_scope_commission_manual_overrides"),
    ]

    operations = [
        migrations.AddField(
            model_name="pacijent",
            name="broj_kartona",
            field=models.CharField(blank=True, max_length=50),
        ),
    ]
