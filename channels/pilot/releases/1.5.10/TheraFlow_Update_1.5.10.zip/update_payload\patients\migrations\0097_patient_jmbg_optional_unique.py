from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0096_ustekinumab_iv_to_sc_protocol"),
    ]

    operations = [
        migrations.AlterField(
            model_name="pacijent",
            name="jmbg",
            field=models.CharField(
                blank=True,
                max_length=13,
                null=True,
                unique=True,
            ),
        ),
    ]
