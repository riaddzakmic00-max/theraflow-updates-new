import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0081_standard_oral_regimens"),
    ]

    operations = [
        migrations.CreateModel(
            name="PotrebaFizickogPokrica",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("trazena_kolicina", models.DecimalField(decimal_places=2, max_digits=8)),
                ("preostala_kolicina", models.DecimalField(decimal_places=2, max_digits=8)),
                (
                    "status",
                    models.CharField(
                        choices=[
                            ("CEKA_FIZICKO_POKRICE", "Čeka fizičko pokriće"),
                            ("POKRIVENA", "Fizički pokrivena"),
                            ("OTKAZANA", "Otkazana"),
                        ],
                        db_index=True,
                        default="CEKA_FIZICKO_POKRICE",
                        max_length=24,
                    ),
                ),
                ("prioritet_datum", models.DateField(blank=True, db_index=True, null=True)),
                ("napomena", models.TextField(blank=True)),
                ("kreirano", models.DateTimeField(auto_now_add=True)),
                ("izmijenjeno", models.DateTimeField(auto_now=True)),
                (
                    "komisija",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="potrebe_fizickog_pokrica",
                        to="patients.komisija",
                    ),
                ),
                (
                    "lijek",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="potrebe_fizickog_pokrica",
                        to="patients.lijek",
                    ),
                ),
                (
                    "migracijski_snapshot",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="potrebe_fizickog_pokrica",
                        to="patients.migracijskisnapshotpacijenta",
                    ),
                ),
                (
                    "pacijent",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="potrebe_fizickog_pokrica",
                        to="patients.pacijent",
                    ),
                ),
                (
                    "termin",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="potrebe_fizickog_pokrica",
                        to="patients.termin",
                    ),
                ),
                (
                    "trebovanje",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="potrebe_fizickog_pokrica",
                        to="patients.trebovanje",
                    ),
                ),
            ],
            options={
                "verbose_name": "Potreba fizičkog pokrića",
                "verbose_name_plural": "Potrebe fizičkog pokrića",
                "ordering": ["prioritet_datum", "kreirano", "id"],
            },
        ),
        migrations.AddConstraint(
            model_name="potrebafizickogpokrica",
            constraint=models.CheckConstraint(
                condition=models.Q(("trazena_kolicina__gt", 0)),
                name="fiz_potreba_trazeno_gt_0",
            ),
        ),
        migrations.AddConstraint(
            model_name="potrebafizickogpokrica",
            constraint=models.CheckConstraint(
                condition=models.Q(("preostala_kolicina__gte", 0)),
                name="fiz_potreba_preostalo_gte_0",
            ),
        ),
        migrations.AddConstraint(
            model_name="potrebafizickogpokrica",
            constraint=models.CheckConstraint(
                condition=models.Q(
                    ("preostala_kolicina__lte", models.F("trazena_kolicina"))
                ),
                name="fiz_potreba_preostalo_lte_trazeno",
            ),
        ),
        migrations.AddField(
            model_name="pacijentrezervacija",
            name="potreba_fizickog_pokrica",
            field=models.OneToOneField(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="fizicka_rezervacija",
                to="patients.potrebafizickogpokrica",
            ),
        ),
        migrations.AddField(
            model_name="pacijentrezervacija",
            name="potrosena_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="pacijentrezervacija",
            name="termin",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="fizicke_rezervacije",
                to="patients.termin",
            ),
        ),
        migrations.AddConstraint(
            model_name="pacijentrezervacija",
            constraint=models.CheckConstraint(
                condition=models.Q(("kolicina__gte", 0)),
                name="fiz_rezervacija_kolicina_gte_0",
            ),
        ),
        migrations.AddConstraint(
            model_name="pacijentrezervacija",
            constraint=models.UniqueConstraint(
                condition=models.Q(("aktivno", True), ("termin__isnull", False)),
                fields=("termin",),
                name="jedna_aktivna_fiz_rez_po_terminu",
            ),
        ),
    ]
