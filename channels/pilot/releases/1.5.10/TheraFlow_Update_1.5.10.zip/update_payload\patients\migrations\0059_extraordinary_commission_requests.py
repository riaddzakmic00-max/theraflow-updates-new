import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0058_normalize_adalimumab_package_size"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AddField(
            model_name="komisijskiciklus",
            name="tip_ciklusa",
            field=models.CharField(
                choices=[("REDOVNI", "Redovni"), ("VANREDNI", "Vanredni")],
                db_index=True,
                default="REDOVNI",
                max_length=20,
            ),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="tip_zahtjeva",
            field=models.CharField(
                choices=[("REDOVNI", "Redovni"), ("VANREDNI", "Vanredni")],
                db_index=True,
                default="REDOVNI",
                max_length=20,
            ),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="razlog_vanrednog",
            field=models.CharField(
                blank=True,
                choices=[
                    (
                        "NEDOVOLJNO_DO_REDOVNE",
                        "Nedovoljna količina do naredne redovne komisije",
                    ),
                    ("NOVI_PACIJENT", "Uvođenje novog pacijenta"),
                    ("PROMJENA_TERAPIJE", "Promjena terapije"),
                    (
                        "RANIJE_ODOBRENJE_NEDOVOLJNO",
                        "Ranije odobrena količina nije dovoljna",
                    ),
                    ("KASNJENJE_ISPORUKE", "Kašnjenje isporuke"),
                    ("DRUGI", "Drugi razlog"),
                ],
                max_length=40,
            ),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="razlog_objasnjenje",
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="kratka_napomena",
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="faza_terapije",
            field=models.CharField(blank=True, max_length=50),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="sistemski_prijedlog",
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                max_digits=8,
                null=True,
            ),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="sljedeca_zakazana_terapija",
            field=models.DateField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="ocekivana_najranija_isporuka",
            field=models.DateField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="rizik_dostave_pri_kreiranju",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="kreirao",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="kreirana_trebovanja",
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="protokol",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="trebovanja",
                to="patients.terapijskiprotokol",
            ),
        ),
        migrations.AlterField(
            model_name="trebovanje",
            name="status",
            field=models.CharField(
                choices=[
                    ("U_PRIPREMI", "U pripremi"),
                    ("PREDATO", "Predato Zavodu"),
                    ("NACRT", "Nacrt"),
                    ("SPREMAN", "Spreman za predaju"),
                    ("POSLAN_KOMISIJI", "Poslan komisiji"),
                    ("ODOBRENO", "Odobreno"),
                    ("DJELOMICNO_ODOBRENO", "Djelimično odobren"),
                    ("CEKA_ISPORUKU", "Čeka isporuku"),
                    ("ZAPRIMLJENO", "Lijek zaprimljen"),
                    ("ODBIJENO", "Odbijeno"),
                    ("OTKAZANO", "Otkazan"),
                ],
                default="U_PRIPREMI",
                max_length=20,
            ),
        ),
        migrations.AddIndex(
            model_name="trebovanje",
            index=models.Index(
                fields=["tip_zahtjeva", "status", "datum_kreiranja"],
                name="request_type_status_date_idx",
            ),
        ),
    ]
