from decimal import Decimal

from django.db import migrations, models


def nadogradi_adalimumab_protokol(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    TerapijskiProtokol = apps.get_model("patients", "TerapijskiProtokol")
    TerapijskiKorakProtokola = apps.get_model("patients", "TerapijskiKorakProtokola")

    lijekovi = Lijek.objects.filter(naziv__icontains="adalimumab")
    for lijek in lijekovi:
        protokol = TerapijskiProtokol.objects.filter(
            lijek=lijek,
            naziv__icontains="standard",
        ).first()
        if not protokol:
            protokol = TerapijskiProtokol.objects.filter(lijek=lijek, aktivan=True).first()
        if not protokol:
            continue

        protokol.tip_terapije = "KOMBINOVANO"
        protokol.indukcijske_sedmice = "0,2"
        protokol.interval_odrzavanja_sedmica = 2
        protokol.doza_po_aplikaciji = 1
        protokol.aktivan = True
        protokol.save()

        koraci = [
            ("Indukcija 1", "INDUKCIJA", 0, 1, Decimal("160"), Decimal("4"), None, "AMBULANTA"),
            ("Indukcija 2", "INDUKCIJA", 2, 2, Decimal("80"), Decimal("2"), None, "AMBULANTA"),
            ("Prva doza održavanja", "ODRZAVANJE", 4, 3, Decimal("40"), Decimal("1"), None, "AMBULANTA"),
            ("Održavanje kući", "ODRZAVANJE", 6, 4, Decimal("40"), Decimal("1"), 2, "KUCNA_TERAPIJA"),
        ]

        for naziv, faza, sedmica, redoslijed, doza_mg, broj_jedinica, interval, nacin in koraci:
            korak, _ = TerapijskiKorakProtokola.objects.get_or_create(
                protokol=protokol,
                redoslijed=redoslijed,
                defaults={"naziv_koraka": naziv, "faza": faza},
            )
            korak.naziv_koraka = naziv
            korak.faza = faza
            korak.sedmica_od_pocetka = sedmica
            korak.doza_mg = doza_mg
            korak.broj_jedinica = broj_jedinica
            korak.interval_sedmica = interval
            korak.nacin_primjene_koraka = nacin
            korak.aktivan = True
            korak.save()


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0022_terapija_interval_sedmica"),
    ]

    operations = [
        migrations.AddField(
            model_name="terapijskikorakprotokola",
            name="nacin_primjene_koraka",
            field=models.CharField(
                choices=[
                    ("AMBULANTA", "Ambulanta"),
                    ("KUCNA_TERAPIJA", "Kućna terapija"),
                ],
                default="AMBULANTA",
                max_length=20,
            ),
        ),
        migrations.RunPython(nadogradi_adalimumab_protokol, migrations.RunPython.noop),
    ]
