"""Kanonska projekcija i atomsko izdavanje kućne terapije."""

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal

from django.db import transaction
from django.db.models import Max, Sum
from django.utils import timezone


def _decimal(value):
    return Decimal(str(value or 0))


def format_stock_quantity(lijek, quantity):
    """Formatiraj količinu bez .00 i sa medicinski prirodnom jedinicom."""

    value = _decimal(quantity)
    number = (
        str(int(value))
        if value == value.to_integral_value()
        else format(value.normalize(), "f").rstrip("0").rstrip(".")
    )
    if lijek and lijek.therapeutic_group_key == "adalimumab":
        absolute = abs(value)
        if absolute == 1:
            unit = "pen"
        elif absolute == absolute.to_integral_value() and 2 <= int(absolute) <= 4:
            unit = "pena"
        else:
            unit = "penova"
    else:
        unit = lijek.jedinica_zalihe_za_kolicinu(value) if lijek else "doza"
    return f"{number} {unit}"


def _move_to_previous_ambulatory_workday(candidate, patient):
    if candidate is None:
        return None
    from .scheduling import adjust_to_allowed_therapy_date

    return adjust_to_allowed_therapy_date(
        candidate,
        lijek=patient.lijek,
        protokol=patient.aktivni_protokol(),
        direction=-1,
    ).datum


@dataclass(frozen=True)
class HomeTherapyProjection:
    patient_quantity: Decimal
    reserved_quantity: Decimal
    free_fridge_quantity: Decimal
    total_fridge_quantity: Decimal
    fridge_quantity: Decimal
    unused_approved_quantity: Decimal
    administered_quantity: Decimal
    last_administered_on: date | None
    units_per_application: Decimal
    interval_weeks: int
    next_dose_date: date | None
    patient_covered_until: date | None
    physical_covered_until: date | None
    additional_approved_quantity: Decimal
    planned_covered_until: date | None
    first_uncovered_therapy: date | None
    delivery_risk: bool
    expected_delivery: date | None
    next_dispensing: date | None
    date_plan_reliable: bool
    patient_quantity_display: str
    reserved_quantity_display: str
    free_fridge_quantity_display: str
    total_fridge_quantity_display: str
    fridge_quantity_display: str
    unused_approved_display: str
    administered_quantity_display: str


@dataclass(frozen=True)
class HomeTherapyIssueAvailability:
    """Jedini source of truth za akciju izdavanja kućne terapije.

    Capability lijeka određuje da li se akcija uopšte odnosi na terapiju,
    dok trenutni korak protokola, odobrenje i fizička zaliha određuju da li
    se izdavanje sada može potvrditi. Naziv proizvoda namjerno nije dio
    odluke: Hyrimoz i drugi adalimumab SKU-ovi koriste konfiguraciju lijeka.
    """

    visible: bool
    enabled: bool
    reason: str
    status_label: str
    medicine: object | None
    commission_medicine_ids: tuple[int, ...]
    approved_quantity: Decimal
    fridge_quantity: Decimal
    package_size: int
    activates_ustekinumab_home_mode: bool


def home_therapy_issue_availability(patient):
    from .models import Komisija, Zaliha
    from .phased_protocols import (
        commission_authorization_medicine_ids,
        phased_protocol_for_patient,
        ustekinumab_home_issuance_available,
    )

    medicine = getattr(patient, "lijek", None)
    phased_state = phased_protocol_for_patient(patient)
    phased_home_available = ustekinumab_home_issuance_available(phased_state)
    supports_home = bool(
        medicine
        and (medicine.kucna_terapija or phased_home_available)
    )

    if not supports_home or not getattr(patient, "aktivan", False):
        return HomeTherapyIssueAvailability(
            visible=False,
            enabled=False,
            reason="",
            status_label="",
            medicine=medicine,
            commission_medicine_ids=(),
            approved_quantity=Decimal("0"),
            fridge_quantity=Decimal("0"),
            package_size=1,
            activates_ustekinumab_home_mode=False,
        )

    commission_medicine_ids = tuple(
        commission_authorization_medicine_ids(phased_state, medicine)
        if phased_home_available
        else medicine.equivalent_ids()
    )
    approved_quantity = _decimal(
        patient.komisija_set.filter(
            lijek_id__in=commission_medicine_ids,
            status__in=Komisija.VAZECI_STATUSI,
            preostale_doze__gt=0,
        ).aggregate(total=Sum("preostale_doze"))["total"]
    )
    stock = Zaliha.objects.filter(lijek=medicine).first()
    fridge_quantity = _decimal(stock.u_frizideru if stock else 0)
    package_size = (
        int(medicine.effective_package_size)
        if medicine.izdavanje_cijelih_pakovanja else 1
    )
    phase_allows_issue = bool(
        patient.trenutni_korak_je_kucna_terapija()
        or phased_home_available
    )
    status_label = (
        "Komisijski pokriven – čeka izdavanje"
        if approved_quantity > 0
        else ""
    )

    if not phase_allows_issue:
        reason = "Pacijent je još u ambulantnoj fazi terapije."
    elif approved_quantity <= 0:
        reason = "Nema preostalih odobrenih doza."
    elif approved_quantity < package_size:
        reason = (
            "Nema dovoljno preostalih odobrenih doza za cijelo pakovanje "
            f"({package_size} pena)."
        )
    elif fridge_quantity <= 0:
        stock_unit = medicine.jedinica_zalihe_u_recenici(Decimal("0"))
        reason = f"Nema raspoloživih {stock_unit} u frižideru."
    elif fridge_quantity < package_size:
        reason = (
            "Nema dovoljno raspoloživih penova u frižideru za cijelo "
            f"pakovanje ({package_size} pena)."
        )
    elif patient.na_aktivnoj_pauzi():
        reason = "Pacijent je na privremenoj pauzi terapije."
    else:
        reason = ""

    return HomeTherapyIssueAvailability(
        visible=True,
        enabled=not reason,
        reason=reason,
        status_label=status_label,
        medicine=medicine,
        commission_medicine_ids=commission_medicine_ids,
        approved_quantity=approved_quantity,
        fridge_quantity=fridge_quantity,
        package_size=package_size,
        activates_ustekinumab_home_mode=bool(
            phased_home_available
            and phased_state
            and not phased_state.sc_je_kucna_terapija
        ),
    )


@dataclass(frozen=True)
class HomeTherapyContinuityAssessment:
    """Operativna provjera praznine između fizičkog pokrića i isporuke.

    Slobodna zaliha je samo mogući izvor. Dok je korisnik izričito ne dodijeli
    pacijentu, ona ne zatvara fizičku prazninu niti mijenja sigurno pokriće.
    """

    status_code: str
    status_label: str
    risk: bool
    date_plan_reliable: bool
    safely_covered_until: date | None
    coverable_with_free_stock_until: date | None
    expected_covered_after_delivery_until: date | None
    first_physically_uncovered_therapy: date | None
    first_uncovered_therapy: date | None
    planned_commission_date: date | None
    expected_delivery: date | None
    expected_delivery_confirmed: bool
    uncovered_therapy_dates: tuple[date, ...]
    uncovered_quantity: Decimal
    free_stock_quantity: Decimal
    free_stock_bridge_quantity: Decimal
    free_stock_bridge_dates: tuple[date, ...]
    earlier_safe_cycle: object | None
    regular_cycle_too_late: bool
    recommended_action_code: str
    recommended_action_label: str


def _therapy_dates_before(first_date, limit_date, interval_weeks):
    if not first_date or not limit_date or interval_weeks <= 0:
        return ()
    dates = []
    current = first_date
    while current < limit_date:
        dates.append(current)
        current += timedelta(weeks=interval_weeks)
    return tuple(dates)


def _coverage_milestones_from_timeline(
    details,
    *,
    today,
    confirmed_delivery=None,
):
    """Izvedi A/B/C datume iz iste raspodjele koja crta plan doza.

    Sažetak nikada ne smije koristiti datum narednog termina kao kraj
    prethodnog statusa. Zato pamtimo posljednji uzastopni događaj svakog
    nivoa, dok potvrđenu dolaznu količinu priznajemo samo kada postoji
    konkretan potvrđeni datum isporuke.
    """

    from .commission_demand import (
        SOURCE_APPROVED_WAITING,
        SOURCE_AT_PATIENT,
        SOURCE_FREE_FRIDGE,
        SOURCE_RESERVED,
    )

    secure_until = None
    assignable_until = None
    first_physically_uncovered = None
    first_without_available_source = None
    free_bridge_dates = []
    secure_prefix_open = True
    assignable_prefix_open = True

    for detail in sorted(details or (), key=lambda item: item.datum_terapije):
        if detail.datum_terapije < today:
            continue
        required = _decimal(detail.potrebna_kolicina)
        allocations = {
            source: sum(
                (
                    _decimal(item.quantity)
                    for item in detail.izvori_pokrica
                    if item.source == source
                ),
                Decimal("0"),
            )
            for source in (
                SOURCE_AT_PATIENT,
                SOURCE_RESERVED,
                SOURCE_FREE_FRIDGE,
                SOURCE_APPROVED_WAITING,
            )
        }
        physically_assigned = (
            allocations[SOURCE_AT_PATIENT] + allocations[SOURCE_RESERVED]
        )
        free_quantity = allocations[SOURCE_FREE_FRIDGE]
        confirmed_incoming = (
            allocations[SOURCE_APPROVED_WAITING]
            if confirmed_delivery
            and detail.datum_terapije >= confirmed_delivery
            else Decimal("0")
        )
        physically_covered = physically_assigned >= required
        assignable = physically_assigned + free_quantity >= required
        has_available_source = (
            physically_assigned + free_quantity + confirmed_incoming >= required
        )

        if secure_prefix_open and physically_covered:
            secure_until = detail.datum_terapije
        else:
            secure_prefix_open = False
        if first_physically_uncovered is None and not physically_covered:
            first_physically_uncovered = detail.datum_terapije

        if assignable_prefix_open and assignable:
            assignable_until = detail.datum_terapije
            if free_quantity > 0:
                free_bridge_dates.append(detail.datum_terapije)
        else:
            assignable_prefix_open = False

        if first_without_available_source is None and not has_available_source:
            first_without_available_source = detail.datum_terapije

    return {
        "secure_until": secure_until,
        "assignable_until": assignable_until,
        "first_physically_uncovered": first_physically_uncovered,
        "first_without_available_source": first_without_available_source,
        "free_bridge_dates": tuple(free_bridge_dates),
    }


def _earlier_safe_open_cycle(*, today, planned_date, first_uncovered):
    """Nađi raniji ciklus koji još prima pacijente i stiže na vrijeme."""

    if not planned_date or not first_uncovered:
        return None
    from .commission_service import expected_delivery_for_cycle
    from .models import KomisijskiCiklus

    candidates = KomisijskiCiklus.objects.filter(
        tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI,
        datum_komisije__gte=today,
        datum_komisije__lt=planned_date,
        status__in=("nacrt", "spremno_za_stampu", "SIMULACIJA"),
    ).order_by("datum_komisije", "id")
    for cycle in candidates:
        delivery = expected_delivery_for_cycle(cycle)
        if delivery and delivery <= first_uncovered:
            return cycle
    return None


def calculate_home_therapy_continuity(
    patient,
    *,
    projection,
    planned_commission_window=None,
    estimated_delivery=None,
    confirmed_delivery=None,
    confirmed_incoming_quantity=Decimal("0"),
    available_free_quantity=None,
    coverage_details=None,
    usable_active_approval_quantity=Decimal("0"),
    extraordinary_in_progress=False,
    today=None,
):
    """Izračunaj stvarne nepokrivene kućne doze do očekivane isporuke."""

    today = today or timezone.localdate()
    first_uncovered = projection.first_uncovered_therapy
    interval = int(projection.interval_weeks or 0)
    units = _decimal(projection.units_per_application)
    # Centralni planner već deterministički dijeli zajednički slobodni pool
    # među pacijentima. Kada je ta raspodjela dostupna, ne nudimo isti pen
    # istovremeno većem broju pacijenata.
    free_quantity = _decimal(
        projection.free_fridge_quantity
        if available_free_quantity is None
        else available_free_quantity
    )
    planned_date = getattr(planned_commission_window, "datum_komisije", None)
    delivery = confirmed_delivery or estimated_delivery
    delivery_confirmed = bool(confirmed_delivery)

    milestones = (
        _coverage_milestones_from_timeline(
            coverage_details,
            today=today,
            confirmed_delivery=confirmed_delivery,
        )
        if coverage_details is not None else None
    )
    if milestones:
        safely_covered_until = (
            milestones["secure_until"] or projection.physical_covered_until
        )
        first_uncovered = (
            milestones["first_physically_uncovered"] or first_uncovered
        )
        free_bridge_dates = milestones["free_bridge_dates"]
        coverable_with_free_until = (
            milestones["assignable_until"]
            if free_bridge_dates else None
        )
        first_without_available_source = (
            milestones["first_without_available_source"]
        )
    else:
        safely_covered_until = projection.physical_covered_until
        free_applications = int(free_quantity // units) if units > 0 else 0
        free_bridge_dates = tuple(
            first_uncovered + timedelta(weeks=index * interval)
            for index in range(free_applications)
        ) if first_uncovered and interval > 0 else ()
        coverable_with_free_until = (
            free_bridge_dates[-1]
            if free_bridge_dates
            else None
        )
        first_without_available_source = (
            first_uncovered + timedelta(weeks=free_applications * interval)
            if first_uncovered and interval > 0
            else first_uncovered
        )

    expected_after_delivery_until = None
    incoming_applications = (
        int(_decimal(confirmed_incoming_quantity) // units)
        if units > 0 else 0
    )
    if (
        delivery_confirmed
        and first_without_available_source
        and interval > 0
        and incoming_applications > 0
    ):
        first_after_delivery = first_without_available_source
        while first_after_delivery < confirmed_delivery:
            first_after_delivery += timedelta(weeks=interval)
        expected_after_delivery_until = (
            first_after_delivery
            + timedelta(weeks=(incoming_applications - 1) * interval)
        )

    if not projection.date_plan_reliable or not first_uncovered or interval <= 0 or units <= 0:
        action_code = "REVIEW_PLAN" if not projection.date_plan_reliable else "NONE"
        return HomeTherapyContinuityAssessment(
            status_code="REVIEW" if action_code == "REVIEW_PLAN" else "COVERED",
            status_label=(
                "Potrebna provjera plana"
                if action_code == "REVIEW_PLAN" else "Kontinuitet osiguran"
            ),
            risk=False,
            date_plan_reliable=projection.date_plan_reliable,
            safely_covered_until=safely_covered_until,
            coverable_with_free_stock_until=coverable_with_free_until,
            expected_covered_after_delivery_until=expected_after_delivery_until,
            first_physically_uncovered_therapy=first_uncovered,
            first_uncovered_therapy=first_without_available_source,
            planned_commission_date=planned_date,
            expected_delivery=delivery,
            expected_delivery_confirmed=delivery_confirmed,
            uncovered_therapy_dates=(),
            uncovered_quantity=Decimal("0"),
            free_stock_quantity=free_quantity,
            free_stock_bridge_quantity=units * len(free_bridge_dates),
            free_stock_bridge_dates=free_bridge_dates,
            earlier_safe_cycle=None,
            regular_cycle_too_late=False,
            recommended_action_code=action_code,
            recommended_action_label=(
                "Provjeri termin terapije"
                if action_code == "REVIEW_PLAN" else "Nije potrebna trenutna akcija"
            ),
        )

    regular_cycle_too_late = bool(
        planned_date
        and first_without_available_source
        and first_without_available_source < planned_date
    )
    delivery_too_late = bool(
        delivery
        and first_without_available_source
        and first_without_available_source < delivery
    )
    risk = bool(regular_cycle_too_late or delivery_too_late)

    # Kada datum isporuke nije poznat, možemo dokazati najmanje prazninu do
    # datuma komisije. Procjena se nikada ne pretvara u sigurno pokriće.
    horizon = delivery
    if (
        horizon is None
        and planned_date
        and first_without_available_source
        and first_without_available_source <= planned_date
    ):
        horizon = planned_date + timedelta(days=1)
    uncovered_dates = (
        _therapy_dates_before(first_without_available_source, horizon, interval)
        if risk else ()
    )
    if risk and not uncovered_dates:
        uncovered_dates = (first_without_available_source,)
    uncovered_quantity = units * len(uncovered_dates)

    earlier_cycle = _earlier_safe_open_cycle(
        today=today,
        planned_date=planned_date,
        first_uncovered=first_without_available_source,
    ) if risk else None

    usable_active_approval_quantity = _decimal(usable_active_approval_quantity)
    if extraordinary_in_progress and risk:
        action_code = "MONITOR_EXTRAORDINARY"
        action_label = "Prati vanredni zahtjev"
    elif risk and usable_active_approval_quantity > 0:
        action_code = "ORDER_EXISTING_APPROVAL"
        action_label = "Naruči iz postojećeg odobrenja"
    elif risk and free_quantity >= units:
        action_code = "ASSIGN_FREE_STOCK"
        action_label = "Dodijeli slobodnu dozu"
    elif risk and earlier_cycle is not None:
        action_code = "INCLUDE_EARLIER_CYCLE"
        action_label = "Uključi u raniji otvoreni ciklus"
    elif risk:
        action_code = "EXTRAORDINARY_REQUEST"
        action_label = "Pokreni vanredni zahtjev"
    else:
        action_code = "NONE"
        action_label = "Nije potrebna trenutna akcija"

    return HomeTherapyContinuityAssessment(
        status_code="RISK" if risk else "COVERED",
        status_label="Rizik prekida terapije" if risk else "Kontinuitet osiguran",
        risk=risk,
        date_plan_reliable=True,
        safely_covered_until=safely_covered_until,
        coverable_with_free_stock_until=coverable_with_free_until,
        expected_covered_after_delivery_until=expected_after_delivery_until,
        first_physically_uncovered_therapy=first_uncovered,
        first_uncovered_therapy=first_without_available_source,
        planned_commission_date=planned_date,
        expected_delivery=delivery,
        expected_delivery_confirmed=delivery_confirmed,
        uncovered_therapy_dates=uncovered_dates,
        uncovered_quantity=uncovered_quantity,
        free_stock_quantity=free_quantity,
        free_stock_bridge_quantity=units * len(free_bridge_dates),
        free_stock_bridge_dates=free_bridge_dates,
        earlier_safe_cycle=earlier_cycle,
        regular_cycle_too_late=regular_cycle_too_late,
        recommended_action_code=action_code,
        recommended_action_label=action_label,
    )


def calculate_home_therapy_projection(
    patient,
    *,
    today=None,
    reference_date=None,
    expected_delivery=None,
):
    """Jedini presjek fizičke zalihe, prava i vremenske pokrivenosti.

    Odobreno pravo nije fizička doza. U planski horizont ulazi tek nakon
    količine koja je već kod pacijenta i samo kada poznata isporuka stiže
    najkasnije do prve nepokrivene primjene.
    """

    from .commission_service import patient_commission_coverage
    from .individual_protocols import get_home_therapy_regimen
    from .inventory import inventory_position, inventory_position_for_patient
    from .models import Terapija

    today = today or timezone.localdate()
    reference_date_was_explicit = reference_date is not None
    equivalent_ids = set(patient.lijek.equivalent_ids())
    prefetched_therapies = getattr(patient, "_planning_therapies", None)
    if prefetched_therapies is None:
        prefetched_therapies = getattr(patient, "_workflow_therapies", None)
    if prefetched_therapies is not None:
        administered_items = [
            item
            for item in prefetched_therapies
            if item.lijek_id in equivalent_ids
            and item.workflow_status == Terapija.STATUS_POTVRDJENA
            and not item.is_migration
            and item.tip_evidencije == Terapija.TIP_AMBULANTA
        ]
        administered_queryset = None
        last_administered_on = max(
            (item.datum for item in administered_items),
            default=None,
        )
    else:
        administered_items = None
        administered_queryset = Terapija.objects.filter(
            pacijent=patient,
            lijek_id__in=equivalent_ids,
            workflow_status=Terapija.STATUS_POTVRDJENA,
            is_migration=False,
            kucno_izdavanje__isnull=True,
        )
        last_administered_on = administered_queryset.aggregate(
            last_date=Max("datum")
        )["last_date"]
    phased_next_dose = None
    if reference_date is None:
        phased_state = patient.aktivni_fazni_protokol()
        if (
            phased_state
            and phased_state.sc_je_kucna_terapija
            and phased_state.sljedeci_datum
        ):
            phased_next_dose = phased_state.sljedeci_datum
            reference_date = phased_next_dose
        else:
            # Kućni interval nastavlja se od posljednje stvarno primljene
            # terapije. Dan otvaranja ekrana nije kliničko sidro i ne smije
            # pomjerati ``pokriven do`` pri svakom novom datumu.
            reference_date = last_administered_on or today
    medicine = patient.lijek
    patient_position = inventory_position_for_patient(patient)
    medicine_position = inventory_position(
        medicine,
        today=today,
        include_planned_need=False,
    )
    at_patient = _decimal(patient_position["at_patient"])
    reserved = _decimal(patient_position["reserved_in_fridge"])
    in_fridge = _decimal(medicine_position["in_fridge"])
    free_fridge = _decimal(medicine_position["freely_available"])
    coverage = patient_commission_coverage(patient)
    # KuÄ‡ni plan smije kao buduÄ‡u administrativnu rezervu koristiti samo
    # dio prava koji joĹˇ nije fiziÄŤki kod pacijenta ili rezervisan za njega.
    # ``approved_remaining`` je ukupan ostatak prava (ukljuÄŤuje te fiziÄŤke
    # jedinice), dok je ``unused_approved`` nenaruÄŤeni/neizdati dio.
    unused_approved = _decimal(coverage["unused_approved"])
    administered = (
        sum(
            (_decimal(item.kolicina) for item in administered_items),
            Decimal("0"),
        )
        if administered_items is not None
        else _decimal(
            administered_queryset.aggregate(total=Sum("kolicina"))["total"]
        )
    )
    units, interval = get_home_therapy_regimen(patient)
    units = _decimal(units)
    interval = int(interval or 0)
    # Fazni protokol čuva datum prve naredne SC doze. Kućni coverage engine
    # inače polazi od početka prvog intervala, pa za ovaj slučaj pomjeramo
    # bazu jedan interval unazad: N izdatih jedinica tada pokriva tačno N
    # budućih doza (prvu na ``sljedeci_datum``), bez fantomskog intervala.
    coverage_origin = reference_date
    if phased_next_dose and interval > 0:
        coverage_origin = phased_next_dose - timedelta(weeks=interval)
    patient_applications = int(at_patient // units) if units > 0 else 0
    physical_applications = (
        int((at_patient + reserved) // units) if units > 0 else 0
    )
    # Budući protokolarni raspored je kanonski izvor datuma i za komisijski
    # planner i za karton pacijenta. Aritmetički fallback ostaje samo za
    # eksplicitne/migracijske projekcije bez kliničkog sidra.
    future_dose_dates = []
    if not reference_date_was_explicit and interval > 0:
        from .future_therapy_planning import generate_future_therapies

        projection_days = max(
            365,
            (physical_applications + 2) * interval * 7,
        )
        future_dose_dates = [
            item.datum_terapije
            for item in generate_future_therapies(
                patient,
                start_date=today,
                target_date=today + timedelta(days=projection_days),
            )
        ]
    next_dose_date = future_dose_dates[0] if future_dose_dates else (
        phased_next_dose
        if phased_next_dose else
        last_administered_on + timedelta(weeks=interval)
        if last_administered_on and interval > 0 else None
    )
    patient_covered_until = (
        future_dose_dates[patient_applications - 1]
        if patient_applications > 0
        and len(future_dose_dates) >= patient_applications
        else coverage_origin + timedelta(weeks=patient_applications * interval)
        if patient_applications > 0 and interval > 0
        else None
    )
    if physical_applications > 0 and len(future_dose_dates) >= physical_applications:
        physical_until = future_dose_dates[physical_applications - 1]
    elif physical_applications > 0 and interval > 0:
        physical_until = coverage_origin + timedelta(
            weeks=physical_applications * interval
        )
    elif last_administered_on and not phased_next_dose:
        # Kada nema nijedne buduće fizički dodijeljene doze, posljednja
        # primljena terapija je kraj dokazanog niza. Slobodna zaliha ga ne
        # smije pomjeriti unaprijed.
        physical_until = last_administered_on
    else:
        physical_until = None
    # ``physical_until`` je datum posljednje primjene koju pokriva količina
    # fizički kod pacijenta. Prva nepokrivena primjena dolazi jedan puni
    # protokolarni interval kasnije.
    first_uncovered = (
        future_dose_dates[physical_applications]
        if len(future_dose_dates) > physical_applications
        else phased_next_dose
        if phased_next_dose and physical_applications <= 0
        else physical_until + timedelta(weeks=interval)
        if physical_until and interval > 0
        else next_dose_date
    )
    delivery_risk = bool(
        unused_approved > 0
        and first_uncovered
        and (expected_delivery is None or expected_delivery > first_uncovered)
    )
    additional = Decimal("0")
    if (
        unused_approved > 0
        and first_uncovered
        and expected_delivery is not None
        and expected_delivery <= first_uncovered
    ):
        additional = unused_approved
    additional_applications = int(additional // units) if units > 0 else 0
    planned_until = (
        physical_until + timedelta(weeks=additional_applications * interval)
        if physical_until and additional_applications > 0
        else physical_until
    )
    next_dispensing = (
        _move_to_previous_ambulatory_workday(
            patient_covered_until - timedelta(days=7),
            patient,
        )
        if patient_covered_until and patient_covered_until > today else None
    )
    return HomeTherapyProjection(
        patient_quantity=at_patient,
        reserved_quantity=reserved,
        free_fridge_quantity=free_fridge,
        total_fridge_quantity=in_fridge,
        # U pacijentskoj projekciji "frižider" uvijek znači samo fizičku
        # rezervaciju tog pacijenta, nikada globalni saldo lijeka.
        fridge_quantity=reserved,
        unused_approved_quantity=unused_approved,
        administered_quantity=administered,
        last_administered_on=last_administered_on,
        units_per_application=units,
        interval_weeks=interval,
        next_dose_date=next_dose_date,
        patient_covered_until=patient_covered_until,
        physical_covered_until=physical_until,
        additional_approved_quantity=additional,
        planned_covered_until=planned_until,
        first_uncovered_therapy=first_uncovered,
        delivery_risk=delivery_risk,
        expected_delivery=expected_delivery,
        next_dispensing=next_dispensing,
        date_plan_reliable=bool(
            reference_date_was_explicit
            or last_administered_on
            or phased_next_dose
            or future_dose_dates
        ),
        patient_quantity_display=format_stock_quantity(medicine, at_patient),
        reserved_quantity_display=format_stock_quantity(medicine, reserved),
        free_fridge_quantity_display=format_stock_quantity(medicine, free_fridge),
        total_fridge_quantity_display=format_stock_quantity(medicine, in_fridge),
        fridge_quantity_display=format_stock_quantity(medicine, reserved),
        unused_approved_display=format_stock_quantity(medicine, unused_approved),
        administered_quantity_display=format_stock_quantity(medicine, administered),
    )


@transaction.atomic
def issue_home_therapy(
    *,
    patient,
    commission,
    quantity,
    issued_on,
    idempotency_key,
    batch="",
    expires_on=None,
    note="",
    user=None,
    snapshot_factory=None,
):
    """Atomski premjesti lijek iz frižidera pacijentu i knjiži pravo jednom."""

    from .individual_protocols import persistable_standard_step
    from .models import (
        Komisija,
        KucnoIzdavanje,
        Lijek,
        Pacijent,
        PacijentRezervacija,
        PacijentZaduzenje,
        PauzaTerapije,
        Terapija,
        TerapijaStatusHistorija,
        Zaliha,
        ZalihaTransakcija,
    )
    from .therapy_workflow import record_status_history
    from .utils import upisi_log

    # Zaključavamo isključivo osnovni red pacijenta. ``Pacijent.lijek`` je
    # nullable FK, pa bi select_related("lijek") ovdje proizveo LEFT OUTER
    # JOIN nad kojim PostgreSQL ne dozvoljava FOR UPDATE.
    patient = Pacijent.objects.select_for_update().get(pk=patient.pk)

    # Pacijentov lock serijalizuje dva klika/POST-a za istog primaoca. Tek
    # nakon njega ponovo provjeravamo idempotency ključ nad svježim stanjem.
    existing = KucnoIzdavanje.objects.select_for_update().filter(
        idempotency_key=idempotency_key
    ).first()
    if existing:
        return existing, False

    if not patient.aktivan:
        raise ValueError("Neaktivnom pacijentu nije moguće izdati kućnu terapiju.")
    active_pause_ids = list(
        PauzaTerapije.objects.select_for_update().filter(
            pacijent_id=patient.pk,
            aktivna=True,
        ).values_list("pk", flat=True)
    )
    if active_pause_ids:
        raise ValueError("Pacijent je na privremenoj pauzi. Kućna terapija se ne može izdati.")
    if not patient.lijek_id:
        raise ValueError("Pacijent nema evidentiran lijek za kućnu terapiju.")
    medicine = Lijek.objects.get(pk=patient.lijek_id)
    from .phased_protocols import (
        commission_authorization_medicine_ids,
        transition_ustekinumab_sc_to_home,
        ustekinumab_home_issuance_available,
    )

    phased_state = patient.aktivni_fazni_protokol()
    if not medicine.kucna_terapija and not ustekinumab_home_issuance_available(
        phased_state
    ):
        raise ValueError("Ovaj lijek ne podržava kućnu terapiju.")
    if not patient.trenutni_korak_je_kucna_terapija():
        if not ustekinumab_home_issuance_available(phased_state):
            raise ValueError("Pacijent trenutno nije na koraku kućne terapije.")
        # Samo stvarno izdavanje koje je korisnik potvrdio aktivira kućni
        # SC način. Promjena je u istoj transakciji, pa se vraća ako bilo
        # koji naredni korak izdavanja ne uspije.
        phased_state, _cancelled = transition_ustekinumab_sc_to_home(
            state=phased_state,
            user=user,
        )
        patient.refresh_from_db()
    from .scheduling import is_allowed_therapy_date

    if not is_allowed_therapy_date(
        issued_on,
        lijek=medicine,
        protokol=patient.aktivni_protokol(),
    ):
        raise ValueError(
            "Izdavanje lijeka u ambulanti mora biti evidentirano na radni dan."
        )
    quantity = _decimal(quantity)
    if quantity <= 0:
        raise ValueError("Broj izdanih doza mora biti veći od nule.")
    if quantity != quantity.to_integral_value():
        raise ValueError("Količina za izdavanje mora biti cijeli broj jedinica.")
    from .package_sizes import package_count, validate_package_multiple

    if medicine.izdavanje_cijelih_pakovanja:
        try:
            validate_package_multiple(
                quantity,
                medicine,
                label="Količina kućnog izdavanja",
            )
        except ValueError as exc:
            raise ValueError(str(exc)) from exc
    issued_package_count = package_count(quantity, medicine)

    commission = Komisija.objects.select_for_update().get(pk=commission.pk)
    commission_medicine_ids = (
        commission_authorization_medicine_ids(phased_state, medicine)
        if phased_state else medicine.equivalent_ids()
    )
    if (
        commission.pacijent_id != patient.pk
        or commission.lijek_id not in commission_medicine_ids
    ):
        raise ValueError("Izabrana komisija ne pripada pacijentu i lijeku.")
    if not commission.je_vazeca() or _decimal(commission.preostale_doze) < quantity:
        raise ValueError("Komisija nema dovoljno preostalih odobrenih doza.")

    stock = Zaliha.objects.select_for_update().filter(lijek=medicine).first()
    if stock is None or _decimal(stock.u_frizideru) < quantity:
        available = _decimal(stock.u_frizideru) if stock else Decimal("0")
        raise ValueError(
            f"Nema dovoljno fizičke zalihe u frižideru. Dostupno {available:g}, "
            f"traženo {quantity:g}."
        )

    reservation_changes = []
    remaining_to_unreserve = quantity
    reservations = PacijentRezervacija.objects.select_for_update().filter(
        pacijent=patient,
        lijek_id__in=medicine.equivalent_ids(),
        aktivno=True,
        kolicina__gt=0,
    ).order_by("datum_rezervacije", "id")
    for reservation in reservations:
        if remaining_to_unreserve <= 0:
            break
        removed = min(_decimal(reservation.kolicina), remaining_to_unreserve)
        reservation.kolicina = _decimal(reservation.kolicina) - removed
        reservation.aktivno = reservation.kolicina > 0
        reservation.save(update_fields=["kolicina", "aktivno"])
        reservation_changes.append((reservation, removed))
        remaining_to_unreserve -= removed

    # Agregatni SELECT nije pouzdan način zaključavanja. Materijalizujemo
    # konkretne redove koje možemo sabrati i eventualno izmijeniti.
    locked_assignments = list(
        PacijentZaduzenje.objects.select_for_update().filter(
            pacijent=patient,
            lijek_id__in=medicine.equivalent_ids(),
            komisija=commission,
        ).order_by("datum_zaduzenja", "id")
    )
    assigned_total = sum(
        (_decimal(item.ukupno_zaduzeno) for item in locked_assignments),
        Decimal("0"),
    )
    if assigned_total + quantity > _decimal(commission.broj_odobrenih_doza):
        raise ValueError("Ukupno izdavanje ne smije preći količinu odobrenu komisijom.")
    assignment = next((item for item in locked_assignments if item.aktivno), None)
    if assignment:
        assignment.ukupno_zaduzeno = _decimal(assignment.ukupno_zaduzeno) + quantity
        assignment.preostalo = _decimal(assignment.preostalo) + quantity
        assignment.save(update_fields=["ukupno_zaduzeno", "preostalo"])
    else:
        assignment = PacijentZaduzenje.objects.create(
            pacijent=patient,
            lijek=medicine,
            komisija=commission,
            ukupno_zaduzeno=quantity,
            preostalo=quantity,
        )

    before_fridge = _decimal(stock.u_frizideru)
    before_at_patients = _decimal(stock.kod_pacijenata)
    stock.u_frizideru = before_fridge - quantity
    stock.kod_pacijenata = before_at_patients + quantity
    stock.save(update_fields=["u_frizideru", "kod_pacijenata", "ukupno"])
    commission.preostale_doze = _decimal(commission.preostale_doze) - quantity
    if commission.preostale_doze <= 0:
        commission.preostale_doze = Decimal("0")
        commission.status = "POTROSENA"
    commission.save(update_fields=["preostale_doze", "status"])

    step = patient.trenutni_korak_terapije()
    therapy_phase = (
        phased_state.faza if phased_state else patient.terapijska_faza()
    )
    therapy_dose_mg = (
        Decimal("90") if phased_state else step.doza_mg if step else None
    )
    therapy_interval = (
        phased_state.interval_odrzavanja_sedmica
        if phased_state else
        patient.sedmica_do_sljedece_aplikacije()
        or patient.interval_sedmica
        or 8
    )
    therapy = Terapija.objects.create(
        pacijent=patient,
        lijek=medicine,
        terapijski_korak=persistable_standard_step(step),
        datum=issued_on,
        kolicina=quantity,
        doza_mg=therapy_dose_mg,
        faza_terapije=therapy_phase,
        interval_sedmica=therapy_interval,
        serija=batch,
        nuspojave=note,
        tip_evidencije=Terapija.TIP_KUCNA_TERAPIJA,
        finansijski_status=Terapija.FINANSIJSKI_NIJE_KREIRAN,
        evidentirao=user if getattr(user, "is_authenticated", False) else None,
    )
    issuance = KucnoIzdavanje.objects.create(
        pacijent=patient,
        lijek=medicine,
        komisija=commission,
        pacijent_zaduzenje=assignment,
        terapija=therapy,
        datum=issued_on,
        kolicina=quantity,
        serija=batch,
        rok_trajanja=expires_on,
        napomena=note,
        korisnik_koji_je_izdao=user if getattr(user, "is_authenticated", False) else None,
        idempotency_key=idempotency_key,
    )
    if snapshot_factory:
        issuance.razduzenje_snapshot = snapshot_factory(issuance)
        issuance.save(update_fields=["razduzenje_snapshot"])
    transaction_record = ZalihaTransakcija.objects.create(
        lijek=medicine,
        tip=ZalihaTransakcija.TIP_KUCNO_IZDAVANJE,
        kolicina=quantity,
        datum=issued_on,
        pacijent=patient,
        komisija=commission,
        referenca_tip="KucnoIzdavanje",
        referenca_id=issuance.pk,
        korisnik=user if getattr(user, "is_authenticated", False) else None,
        napomena=f"{medicine.naziv}: izdato {format_stock_quantity(medicine, quantity)} za kućnu terapiju.",
    )
    therapy.workflow_snapshot = {
        "vrsta": "KUCNO_IZDAVANJE",
        "fazni_protokol_id": phased_state.pk if phased_state else None,
        "faza_terapije_label": (
            Terapija.UstekinumabFaza.SC_ODRZAVANJE.label
            if phased_state else therapy.faza_terapije
        ),
        "kucno_izdavanje_id": issuance.pk,
        "zaliha_transakcija_id": transaction_record.pk,
        "komisijske_promjene": [{"komisija_id": commission.pk, "kolicina": str(quantity)}],
        "zaduzenje_izdavanje": {"zaduzenje_id": assignment.pk, "kolicina": str(quantity)},
        "rezervacijske_promjene": [
            {"rezervacija_id": item.pk, "kolicina": str(removed)}
            for item, removed in reservation_changes
        ],
    }
    therapy.save(update_fields=["workflow_snapshot"])
    record_status_history(
        pacijent=patient,
        terapija=therapy,
        new_status=Terapija.STATUS_POTVRDJENA,
        reason=f"Kućna terapija izdata pacijentu: {format_stock_quantity(medicine, quantity)}.",
        user=user,
        event_type=TerapijaStatusHistorija.DOGADJAJ_KUCNO_IZDAVANJE,
        new_state={
            "kucno_izdavanje_id": issuance.pk,
            "kolicina": str(quantity),
            "broj_pakovanja": issued_package_count,
            "frizider_promjena": str(-quantity),
            "kod_pacijenta_promjena": str(quantity),
        },
    )
    actor_label = (
        user.get_username()
        if getattr(user, "is_authenticated", False)
        else "Sistem"
    )
    audit_timestamp = timezone.localtime().strftime("%d/%m/%Y %H:%M")
    upisi_log(
        user,
        "Izdata kućna terapija",
        pacijent=patient,
        objekat=issuance,
        opis=(
            f"Izdano: {format_stock_quantity(medicine, quantity)} / "
            f"{issued_package_count} "
            f"{'pakovanje' if issued_package_count == 1 else 'pakovanja'}; "
            f"Frižider: -{format_stock_quantity(medicine, quantity)}; "
            f"Kod pacijenta: +{format_stock_quantity(medicine, quantity)}; "
            f"Korisnik: {actor_label}; Datum i vrijeme: {audit_timestamp}."
        ),
    )
    from .commission_planning import recalculate_patient_commission_drafts

    recalculate_patient_commission_drafts(
        patient,
        user=user,
        today=issued_on,
        reason=(
            "Komisijski prijedlog preračunat nakon izdavanja kućne terapije."
        ),
    )
    return issuance, True
