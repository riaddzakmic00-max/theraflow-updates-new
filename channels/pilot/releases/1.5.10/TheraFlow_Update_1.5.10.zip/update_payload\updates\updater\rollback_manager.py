import json
import os
from datetime import datetime, timezone
from pathlib import Path

from . import config_restore, database_restore, django_commands, health_check, history_writer, service_manager, snapshot_restore
from .plan_loader import read_version
from .state_writer import read_state, safe_message, write_state


class RollbackError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def rollback_type_for(plan, state):
    started = state.get("migration_started")
    completed = state.get("migration_completed")
    # Stvarno izvršeno stanje je autoritativno. Updater uvijek poziva
    # ``migrate --noinput`` čak i kada manifest tvrdi da migracija nije
    # potrebna, pa se nakon započete migracije mora vratiti i baza.
    if started is True or completed is True:
        return "full"
    if started is False and completed is False:
        return "file-only"
    if started is None and completed is None:
        # Phase 3 writes both explicit false values before changing files.
        return "full"
    return "full"


def should_rollback(state):
    return bool(state.get("files_changed")) and not state.get("rollback_started_at")


def _recovery_report(plan, state, code, service_state="UNKNOWN"):
    report = {
        "session_id": plan.get("session_id"),
        "source_version": plan.get("current_version"),
        "target_version": plan.get("target_version"),
        "last_successful_step": state.get("last_successful_step"),
        "service_state": service_state,
        "application_version": None,
        "database_backup_status": "validated" if Path(plan.get("database_backup_path", "")).is_file() else "missing",
        "snapshot_status": "available" if (Path(plan.get("backup_root", "")) / "application_snapshot_manifest.json").is_file() else "missing",
        "config_backup_status": "available" if Path(plan.get("config_backup_path", "")).is_file() else "missing",
        "emergency_backup_status": "available" if (Path(plan.get("backup_root", "")) / "pre_rollback_database.dump").is_file() else "missing",
        "recommended_next_step": "Pregledati sačuvane rollback artefakte prije ručnog oporavka.",
        "error_codes": [code],
    }
    try:
        report["application_version"] = read_version(Path(plan["application_root"]) / "theraflow" / "version.py")
    except Exception:
        report["application_version"] = "unknown"
    destination = Path(plan["backup_root"]) / "recovery_report.json"
    destination.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


def execute(plan, state_path, trigger="automatic", reason="update_failed"):
    state_path = Path(state_path).resolve()
    state = read_state(state_path)
    sessions_root = state_path.parent
    lock = sessions_root / "rollback.lock"
    if state.get("rollback_completed_at"):
        return state
    if trigger == "manual" and lock.is_file():
        try:
            if lock.read_text(encoding="utf-8").strip() == plan["session_id"]:
                lock.unlink()
        except OSError:
            pass
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(descriptor, str(plan["session_id"]).encode("ascii"))
        os.close(descriptor)
    except FileExistsError as exc:
        raise RollbackError("rollback_locked", "Rollback je već pokrenut.") from exc

    rollback_type = rollback_type_for(plan, state)
    started_at = datetime.now(timezone.utc).isoformat()
    write_state(
        state_path, status="rollback_starting", current_step="Pokretanje sigurnog oporavka",
        rollback_type=rollback_type, rollback_reason=safe_message(reason), rollback_trigger=trigger,
        rollback_started_at=started_at, manual_action_required=False, progress_percent=10,
    )
    service_state = "UNKNOWN"
    database_context = None
    try:
        write_state(state_path, status="rollback_validating", current_step="Provjera rollback artefakata", progress_percent=15)
        snapshot_restore.validate_snapshot(plan)
        if rollback_type == "full":
            database_context = database_restore.validate_original_backup(plan)

        write_state(state_path, status="rollback_service_stopping", current_step="Zaustavljanje servisa", progress_percent=20)
        service_manager.stop(plan["service_name"])
        service_state = "STOPPED"

        write_state(state_path, status="rollback_files_restoring", current_step="Vraćanje aplikacijskih fajlova", progress_percent=35)
        snapshot_restore.restore_snapshot(plan)
        write_state(state_path, files_restored=True, previous_version_restored=plan["current_version"], last_successful_step="application_files_restored")

        write_state(state_path, status="rollback_config_restoring", current_step="Provjera lokalne konfiguracije", progress_percent=50)
        config_report = config_restore.restore_config(plan)
        write_state(state_path, config_restored=bool(config_report["restored"]), last_successful_step="configuration_validated")

        if rollback_type == "full":
            write_state(state_path, status="rollback_database_backing_up", current_step="Emergency backup baze", progress_percent=58)
            dump, _metadata, database = database_context
            emergency = database_restore.create_emergency_backup(plan, database)
            write_state(
                state_path, status="rollback_database_restoring", current_step="Vraćanje baze prije ažuriranja",
                emergency_backup_path=str(emergency), progress_percent=64,
            )
            database_restore.restore_original_database(plan, dump, database)
            write_state(state_path, database_restored=True, progress_percent=72, last_successful_step="database_restored")
        else:
            write_state(state_path, database_restored=False)

        write_state(state_path, status="rollback_application_check", current_step="Provjera prethodne verzije", progress_percent=80)
        if read_version(Path(plan["application_root"]) / "theraflow" / "version.py") != plan["current_version"]:
            raise RollbackError("rollback_version_mismatch", "Prethodna verzija nije ispravno vraćena.")
        django_commands.django_check(plan)
        if plan.get("collectstatic_required"):
            django_commands.collectstatic(plan)

        write_state(state_path, status="rollback_service_starting", current_step="Pokretanje prethodne verzije", progress_percent=90)
        service_manager.start(plan["service_name"])
        service_state = "RUNNING"
        write_state(state_path, status="rollback_health_check", current_step="Provjera prethodne verzije", progress_percent=95, service_status="RUNNING")
        health_check.check(plan["health_check_url"], plan["current_version"])
        completed_at = datetime.now(timezone.utc).isoformat()
        final = write_state(
            state_path, status="rollback_completed", current_step="Prethodna verzija je sigurno vraćena",
            rollback_completed_at=completed_at, completed_at=completed_at, progress_percent=100,
            health_check_status="health_check_passed", rollback_error_code="",
            rollback_error_message="", manual_action_required=False, service_status="RUNNING",
        )
        history_writer.write_history_event(plan, final, "failed_rolled_back")
        lock.unlink(missing_ok=True)
        return final
    except Exception as exc:
        completed_at = datetime.now(timezone.utc).isoformat()
        latest_state = read_state(state_path)
        code = getattr(exc, "code", None) or (
            "rollback_files_failed" if isinstance(exc, snapshot_restore.SnapshotRestoreError)
            else "database_restore_failed" if isinstance(exc, database_restore.DatabaseRestoreError)
            else "rollback_failed"
        )
        state = write_state(
            state_path, status="manual_recovery_required", current_step="Potrebna ručna intervencija",
            rollback_error_code=code, rollback_error_message=str(exc), error_code=code,
            error_message=str(exc), manual_action_required=True, service_status=service_state,
            failed_step=latest_state.get("last_attempted_step") or latest_state.get("status") or "rollback",
            completed_at=completed_at, step_completed_at=completed_at,
        )
        history_writer.write_history_event(plan, state, "failed_manual_recovery")
        _recovery_report(plan, state, code, service_state)
        raise RollbackError(code, str(exc)) from exc
