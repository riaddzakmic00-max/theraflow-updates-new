from decimal import Decimal

import django.db.models.deletion
from django.db import migrations, models


VERIFIED_STANDARD_REGIMENS = (
    (
        "Xeljanz 5 mg",
        "Standardni Xeljanz 5 mg režim",
        Decimal("1"),
        2,
        "INDUKCIJA",
    ),
    (
        "Entecavir 0.5 mg",
        "Standardni Entecavir 0,5 mg režim",
        Decimal("1"),
        1,
        "ODRZAVANJE",
    ),
    (
        "Tenofovir 245 mg",
        "Standardni Tenofovir 245 mg režim",
        Decimal("1"),
        1,
        "ODRZAVANJE",
    ),
)


def seed_verified_oral_regimens(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    StandardniOralniRezim = apps.get_model("patients", "StandardniOralniRezim")
    for medicine_name, name, tablets_per_intake, intakes_per_day, phase in (
        VERIFIED_STANDARD_REGIMENS
    ):
        medicine = Lijek.objects.filter(naziv=medicine_name).first()
        if not medicine:
            # 0080 bi trebao kreirati zapis, ali nad parcijalnom legacy bazom
            # nedostajući lijek nije razlog za izmišljanje ili prepisivanje.
            continue
        StandardniOralniRezim.objects.get_or_create(
            lijek=medicine,
            naziv=name,
            defaults={
                "tableta_po_uzimanju": tablets_per_intake,
                "uzimanja_dnevno": intakes_per_day,
                "faza": phase,
                "aktivan": True,
                "izvor_konfiguracije": (
                    "Postojeća TheraFlow Phase 5 demo konfiguracija"
                ),
            },
        )


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0080_seed_supported_medicine_registry"),
    ]

    operations = [
        migrations.CreateModel(
            name="StandardniOralniRezim",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("naziv", models.CharField(max_length=150)),
                (
                    "tableta_po_uzimanju",
                    models.DecimalField(decimal_places=2, max_digits=6),
                ),
                ("uzimanja_dnevno", models.PositiveSmallIntegerField()),
                (
                    "faza",
                    models.CharField(
                        choices=[
                            ("INDUKCIJA", "Indukcija"),
                            ("ODRZAVANJE", "Održavanje"),
                            ("PRILAGODJENO", "Prilagođeno"),
                        ],
                        default="ODRZAVANJE",
                        max_length=20,
                    ),
                ),
                ("aktivan", models.BooleanField(default=True)),
                ("izvor_konfiguracije", models.CharField(blank=True, max_length=200)),
                ("napomena", models.TextField(blank=True)),
                ("kreirano", models.DateTimeField(auto_now_add=True)),
                ("izmijenjeno", models.DateTimeField(auto_now=True)),
                (
                    "lijek",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="standardni_oralni_rezimi",
                        to="patients.lijek",
                    ),
                ),
            ],
            options={
                "ordering": ["lijek__naziv", "naziv", "id"],
                "indexes": [
                    models.Index(
                        fields=["lijek", "aktivan"],
                        name="std_oral_drug_active_idx",
                    )
                ],
                "constraints": [
                    models.CheckConstraint(
                        condition=models.Q(("tableta_po_uzimanju__gt", 0)),
                        name="std_oral_tablets_gt0",
                    ),
                    models.CheckConstraint(
                        condition=models.Q(("uzimanja_dnevno__gt", 0)),
                        name="std_oral_intakes_gt0",
                    ),
                    models.UniqueConstraint(
                        fields=("lijek", "naziv"),
                        name="uniq_std_oral_regimen_name",
                    ),
                ],
            },
        ),
        migrations.AddField(
            model_name="pacijent",
            name="predlozeni_oralni_rezim",
            field=models.ForeignKey(
                blank=True,
                help_text=(
                    "Konfiguracijski prijedlog; ne predstavlja doktorsku potvrdu režima."
                ),
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="pacijenti_sa_prijedlogom",
                to="patients.standardnioralnirezim",
            ),
        ),
        migrations.AddField(
            model_name="oralniterapijskirezim",
            name="standardni_rezim",
            field=models.ForeignKey(
                blank=True,
                help_text="Standardni predložak iz kojeg je potvrđen ovaj snapshot.",
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="potvrdjeni_rezimi",
                to="patients.standardnioralnirezim",
            ),
        ),
        migrations.RunPython(
            seed_verified_oral_regimens,
            migrations.RunPython.noop,
        ),
    ]
