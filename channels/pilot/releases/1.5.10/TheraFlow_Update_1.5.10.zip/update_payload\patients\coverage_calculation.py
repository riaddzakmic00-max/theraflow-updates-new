"""Kanonski rezultat pokrivenosti za karton, liste i Komisijski centar.

Ovaj modul ne čita template niti donosi zasebnu komisijsku odluku. Prima
normalizovani demand timeline i jednom razdvaja fizičke, incoming,
administrativne i nove komisijske izvore. Svi UI potrošači zatim čitaju isti
``PatientCoverageCalculation`` objekat.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from .commission_demand import (
    SOURCE_ACTIVE_COMMISSION,
    SOURCE_APPROVED_WAITING,
    SOURCE_AT_PATIENT,
    SOURCE_FREE_FRIDGE,
    SOURCE_NEW_COMMISSION,
    SOURCE_RESERVED,
)
from .home_therapy import format_stock_quantity


PATIENT_STOCK = "PATIENT_STOCK"
FRIDGE_RESERVED = "FRIDGE_RESERVED"
CONFIRMED_DELIVERY = "CONFIRMED_DELIVERY"
APPROVED_NOT_ORDERED = "APPROVED_NOT_ORDERED"
EXISTING_REQUEST_PENDING = "EXISTING_REQUEST_PENDING"
APPROVED_AWAITING_RECEIPT = "APPROVED_AWAITING_RECEIPT"
FREE_STOCK = "FREE_STOCK"
UNSECURED = "UNSECURED"

ALLOWED_COVERAGE_SOURCE_TYPES = frozenset({
    PATIENT_STOCK,
    FRIDGE_RESERVED,
    CONFIRMED_DELIVERY,
    APPROVED_NOT_ORDERED,
    EXISTING_REQUEST_PENDING,
    APPROVED_AWAITING_RECEIPT,
    FREE_STOCK,
    UNSECURED,
})


@dataclass(frozen=True)
class CoverageAllocation:
    """Jedna doza, jedan izvor i količina potrošena iz tog izvora."""

    dose_date: date
    source_type: str
    source_id: int | str | None
    source_status: str
    quantity: Decimal


def _decimal(value):
    return Decimal(str(value or 0))


@dataclass(frozen=True)
class PatientCoverageCalculation:
    patient_id: int
    is_home_therapy: bool
    at_patient_quantity: Decimal
    reserved_quantity: Decimal
    confirmed_delivery_quantity: Decimal
    confirmed_delivery_used: Decimal
    approved_not_ordered_quantity: Decimal
    new_commission_quantity: Decimal
    physically_secured_until: date | None
    first_without_available_source: date | None
    first_commission_calculation_dose: date | None
    expected_delivery: date | None
    expected_delivery_confirmed: bool
    commission_window: object | None
    commission_date: date | None
    preparation_date: date | None
    next_dispensing_date: date | None
    immediate_risk: bool
    first_risk_dose: date | None
    first_risk_missing_quantity: Decimal
    uncovered_before_delivery_dates: tuple[date, ...]
    uncovered_before_delivery_quantity: Decimal
    status_label: str
    current_action: str
    warning_text: str
    immediate_action_text: str
    action_options: tuple[str, ...]
    allocations: tuple[CoverageAllocation, ...]
    dose_plan: tuple[dict, ...]


_SOURCE_PRESENTATION = {
    PATIENT_STOCK: {
        "legacy": SOURCE_AT_PATIENT,
        "source_status": "ALLOCATED",
        "status_label": "Osigurano",
        "status_code": "covered",
        "status_description": "Kod pacijenta",
    },
    FRIDGE_RESERVED: {
        "legacy": SOURCE_RESERVED,
        "source_status": "RESERVED",
        "status_label": "Osigurano",
        "status_code": "covered",
        "status_description": "Fizički rezervisano u frižideru",
    },
    FREE_STOCK: {
        "legacy": SOURCE_FREE_FRIDGE,
        "source_status": "AVAILABLE_FOR_ASSIGNMENT",
        "status_label": "Može se dodijeliti",
        "status_code": "available",
        "status_description": "Fizička slobodna zaliha",
    },
    CONFIRMED_DELIVERY: {
        "legacy": SOURCE_APPROVED_WAITING,
        "source_status": "CONFIRMED",
        "status_label": "Očekuje se isporukom",
        "status_code": "planned",
        "status_description": "Potvrđena isporuka",
    },
    APPROVED_NOT_ORDERED: {
        "legacy": SOURCE_ACTIVE_COMMISSION,
        "source_status": "APPROVED_NOT_ORDERED",
        "status_label": "Odobreno – nije naručeno",
        "status_code": "approved",
        "status_description": "Odobreno – nije naručeno",
    },
    EXISTING_REQUEST_PENDING: {
        "legacy": EXISTING_REQUEST_PENDING,
        "source_status": "EXISTING_REQUEST_PENDING",
        "status_label": "Obuhvaćeno postojećim zahtjevom",
        "status_code": "existing-request-pending",
        "status_description": "Zahtjev potvrđen – čeka slanje komisiji",
    },
    APPROVED_AWAITING_RECEIPT: {
        "legacy": APPROVED_AWAITING_RECEIPT,
        "source_status": "APPROVED_AWAITING_RECEIPT",
        "status_label": "Odobreno – čeka zaprimanje",
        "status_code": "approved-awaiting-receipt",
        "status_description": (
            "Obuhvaćeno odobrenim zahtjevom, ali još nije fizički zaprimljeno."
        ),
    },
    UNSECURED: {
        "legacy": SOURCE_NEW_COMMISSION,
        "source_status": "MISSING",
        "status_label": "Nije osigurano",
        "status_code": "uncovered",
        "status_description": "Nije osigurano",
    },
}


def _allocate_administrative_request_source(
    dose_plan,
    *,
    request_quantity,
    request_id=None,
    source_type,
):
    remaining = max(Decimal("0"), _decimal(request_quantity))
    rendered = []
    for original in dose_plan or ():
        item = dict(original)
        required = max(
            Decimal("0"), _decimal(item.get("potrebna_kolicina"))
        )
        if (
            item.get("status_kod") == "uncovered"
            and required > 0
            and remaining >= required
        ):
            remaining -= required
            presentation = _SOURCE_PRESENTATION[source_type]
            allocation = CoverageAllocation(
                dose_date=item["datum"],
                source_type=source_type,
                source_id=request_id,
                source_status=presentation["source_status"],
                quantity=required,
            )
            item.update(
                status_oznaka=presentation["status_label"],
                status_kod=presentation["status_code"],
                status_opis=presentation["status_description"],
                fizicki_pokriveno=False,
                incoming_kolicina=Decimal("0"),
                coverage_allocation=allocation,
                izvori=({
                    "izvor": presentation["legacy"],
                    "oznaka": presentation["status_description"],
                    "kolicina": required,
                    "source_type": source_type,
                    "source_id": request_id,
                    "source_status": presentation["source_status"],
                },),
            )
        rendered.append(item)
    return tuple(rendered)


def allocate_existing_request_pending(
    dose_plan,
    *,
    request_quantity,
    request_id=None,
):
    """Veži doze za potvrđeni zahtjev koji još čeka slanje."""

    return _allocate_administrative_request_source(
        dose_plan,
        request_quantity=request_quantity,
        request_id=request_id,
        source_type=EXISTING_REQUEST_PENDING,
    )


def allocate_approved_awaiting_receipt(
    dose_plan,
    *,
    request_quantity,
    request_id=None,
):
    """Veži doze za odobrenu količinu koja još nije fizički zaprimljena."""

    return _allocate_administrative_request_source(
        dose_plan,
        request_quantity=request_quantity,
        request_id=request_id,
        source_type=APPROVED_AWAITING_RECEIPT,
    )


def _consume_whole_dose(pool, required):
    """Potroši cijelu dozu ili ništa; jedna doza ne dobija dva izvora."""

    if required > 0 and pool["remaining"] >= required:
        pool["remaining"] -= required
        return True
    return False


def _normalise_home_dose_plan(
    *,
    medicine,
    patient_id,
    patient_quantity,
    reserved_quantity,
    free_stock_quantity,
    dose_plan,
    confirmed_delivery_date,
    confirmed_delivery_quantity,
    approved_not_ordered_quantity,
    confirmed_delivery_source_id=None,
    approved_not_ordered_source_id=None,
):
    """Dodijeli svakoj kućnoj dozi jedan operativni izvor.

    Demand servis već radi količinsku alokaciju. Ovdje dodatno primjenjujemo
    tvrdu granicu pošiljke kako ni stari/pogrešno pripremljeni red ne bi mogao
    označiti više doza kao incoming od stvarno najavljene količine.
    """

    pools = {
        PATIENT_STOCK: {
            "remaining": max(Decimal("0"), _decimal(patient_quantity)),
            "source_id": patient_id,
        },
        FRIDGE_RESERVED: {
            "remaining": max(Decimal("0"), _decimal(reserved_quantity)),
            "source_id": patient_id,
        },
        FREE_STOCK: {
            "remaining": max(Decimal("0"), _decimal(free_stock_quantity)),
            "source_id": getattr(medicine, "pk", None),
        },
        CONFIRMED_DELIVERY: {
            "remaining": max(
                Decimal("0"), _decimal(confirmed_delivery_quantity)
            ),
            "source_id": confirmed_delivery_source_id,
        },
        APPROVED_NOT_ORDERED: {
            "remaining": max(
                Decimal("0"), _decimal(approved_not_ordered_quantity)
            ),
            "source_id": approved_not_ordered_source_id,
        },
    }
    normalised = []
    allocations = []
    incoming_used = Decimal("0")

    for original in sorted(dose_plan or (), key=lambda item: item["datum"]):
        item = dict(original)
        required = _decimal(item.get("potrebna_kolicina"))
        source_type = UNSECURED
        for candidate in (PATIENT_STOCK, FRIDGE_RESERVED, FREE_STOCK):
            if _consume_whole_dose(pools[candidate], required):
                source_type = candidate
                break
        if (
            source_type == UNSECURED
            and confirmed_delivery_date
            and item["datum"] >= confirmed_delivery_date
            and _consume_whole_dose(pools[CONFIRMED_DELIVERY], required)
        ):
            source_type = CONFIRMED_DELIVERY
            incoming_used += required
        # Nenaručeno odobrenje nije rješenje za dozu prije već potvrđene
        # isporuke. Poslije tog datuma nastavlja hronološki tamo gdje je
        # količinski ograničena pošiljka potrošena.
        if (
            source_type == UNSECURED
            and (
                confirmed_delivery_date is None
                or item["datum"] >= confirmed_delivery_date
            )
            and _consume_whole_dose(
                pools[APPROVED_NOT_ORDERED], required
            )
        ):
            source_type = APPROVED_NOT_ORDERED

        presentation = _SOURCE_PRESENTATION[source_type]
        description = presentation["status_description"]
        if source_type == CONFIRMED_DELIVERY and confirmed_delivery_date:
            description = (
                f"Potvrđena isporuka {confirmed_delivery_date:%d/%m/%Y}"
            )
        source_id = (
            pools[source_type]["source_id"]
            if source_type in pools else None
        )
        allocation = CoverageAllocation(
            dose_date=item["datum"],
            source_type=source_type,
            source_id=source_id,
            source_status=presentation["source_status"],
            quantity=required,
        )
        allocations.append(allocation)
        item.update(
            status_oznaka=presentation["status_label"],
            status_kod=presentation["status_code"],
            status_opis=description,
            fizicki_dodijeljeno=(
                required
                if source_type in {PATIENT_STOCK, FRIDGE_RESERVED}
                else Decimal("0")
            ),
            slobodna_zaliha_dostupna=(
                required if source_type == FREE_STOCK else Decimal("0")
            ),
            fizicki_pokriveno=(
                source_type in {PATIENT_STOCK, FRIDGE_RESERVED}
            ),
            incoming_kolicina=(
                required if source_type == CONFIRMED_DELIVERY else Decimal("0")
            ),
            coverage_allocation=allocation,
            izvori=({
                "izvor": presentation["legacy"],
                "oznaka": description,
                "kolicina": required,
                "source_type": source_type,
                "source_id": source_id,
                "source_status": presentation["source_status"],
            },),
        )
        normalised.append(item)

    return tuple(normalised), tuple(allocations), incoming_used


def build_home_coverage_calculation(
    *,
    patient,
    projection,
    dose_plan,
    confirmed_delivery_date=None,
    estimated_delivery_date=None,
    confirmed_delivery_quantity=Decimal("0"),
    approved_not_ordered_quantity=Decimal("0"),
    new_commission_quantity=Decimal("0"),
    calculation_period_start=None,
    current_window=None,
    next_window=None,
    planned_window=None,
    risk_action="Pokreni vanredni zahtjev",
    confirmed_delivery_source_id=None,
    approved_not_ordered_source_id=None,
):
    """Vrati jedan backend ugovor za sva četiri prikaza pokrivenosti."""

    confirmed_quantity = max(Decimal("0"), _decimal(confirmed_delivery_quantity))
    approved_quantity = max(Decimal("0"), _decimal(approved_not_ordered_quantity))
    normalised_plan, allocations, incoming_used = _normalise_home_dose_plan(
        medicine=patient.lijek,
        patient_id=patient.pk,
        patient_quantity=projection.patient_quantity,
        reserved_quantity=projection.reserved_quantity,
        # Slobodna zaliha nije pacijentov izvor dok je sestra izričito ne
        # dodijeli. Nakon dodjele ulazi kao FRIDGE_RESERVED; zato se ovdje ne
        # troši samo zato što fizički postoji u kabinetu.
        free_stock_quantity=Decimal("0"),
        dose_plan=dose_plan,
        confirmed_delivery_date=confirmed_delivery_date,
        confirmed_delivery_quantity=confirmed_quantity,
        approved_not_ordered_quantity=approved_quantity,
        confirmed_delivery_source_id=confirmed_delivery_source_id,
        approved_not_ordered_source_id=approved_not_ordered_source_id,
    )
    expected_delivery = confirmed_delivery_date or estimated_delivery_date

    physical_prefix = []
    for item in normalised_plan:
        if item["status_kod"] != "covered":
            break
        physical_prefix.append(item)
    physically_secured_until = (
        physical_prefix[-1]["datum"]
        if physical_prefix else projection.physical_covered_until
    )
    first_without_source = next(
        (
            allocation.dose_date
            for allocation in allocations
            if allocation.source_type in {
                APPROVED_NOT_ORDERED,
                UNSECURED,
            }
        ),
        None,
    )
    risk_items = tuple(
        item
        for item in normalised_plan
        if expected_delivery
        and item["datum"] < expected_delivery
        and item["coverage_allocation"].source_type in {
            APPROVED_NOT_ORDERED,
            UNSECURED,
        }
    )
    first_risk_item = risk_items[0] if risk_items else None
    immediate_risk = first_risk_item is not None
    first_risk_dose = first_risk_item["datum"] if first_risk_item else None
    risk_missing = (
        max(
            Decimal("0"),
            _decimal(first_risk_item.get("potrebna_kolicina"))
            - _decimal(first_risk_item.get("fizicki_dodijeljeno"))
            - _decimal(first_risk_item.get("slobodna_zaliha_dostupna"))
            - _decimal(first_risk_item.get("incoming_kolicina")),
        )
        if first_risk_item else Decimal("0")
    )
    uncovered_before_delivery_quantity = sum(
        (
            max(
                Decimal("0"),
                _decimal(item.get("potrebna_kolicina"))
                - _decimal(item.get("fizicki_dodijeljeno"))
                - _decimal(item.get("slobodna_zaliha_dostupna"))
                - _decimal(item.get("incoming_kolicina")),
            )
            for item in risk_items
        ),
        Decimal("0"),
    )

    # Najavljena količina iz ranijeg odobrenja rješava logistiku do isporuke,
    # ali ne pripada novom redovnom zahtjevu. Redovni plan zato ide u prvi
    # ciklus nakon trenutnog; eventualni jaz prije isporuke ostaje hitna akcija.
    regular_window = planned_window
    if (
        confirmed_delivery_date
        and confirmed_quantity > 0
        and next_window is not None
        and getattr(planned_window, "datum_komisije", None)
        and getattr(planned_window, "datum_komisije", None)
        <= confirmed_delivery_date
        and getattr(next_window, "datum_komisije", None)
        != getattr(planned_window, "datum_komisije", None)
    ):
        regular_window = next_window
    commission_date = getattr(regular_window, "datum_komisije", None)
    preparation_date = getattr(regular_window, "rok_pripreme", None)

    new_quantity = max(Decimal("0"), _decimal(new_commission_quantity))
    if immediate_risk:
        status_label = "Rizik prekida terapije"
        current_action = risk_action
        missing_display = format_stock_quantity(patient.lijek, risk_missing)
        warning_text = (
            "Kontinuitet terapije je ugrožen – za dozu "
            f"{first_risk_dose:%d/%m/%Y} nedostaje {missing_display}. "
            "Osigurati raniju isporuku, slobodnu zalihu ili pokrenuti "
            "vanredni zahtjev."
        )
        immediate_action_text = (
            "Potrebna akcija: osigurati "
            f"{missing_display} za dozu {first_risk_dose:%d/%m/%Y}."
        )
        action_options = (
            "Osiguraj iz slobodne zalihe",
            "Evidentiraj raniju isporuku",
            "Pokreni vanredni zahtjev",
        )
    elif new_quantity > 0 and commission_date:
        status_label = f"Planirati komisiju {commission_date:%d/%m/%Y}"
        current_action = "Nije potrebna trenutna akcija"
        warning_text = ""
        immediate_action_text = ""
        action_options = ()
    else:
        status_label = "Nije potrebna trenutna komisija"
        current_action = "Nije potrebna trenutna akcija"
        warning_text = ""
        immediate_action_text = ""
        action_options = ()

    return PatientCoverageCalculation(
        patient_id=patient.pk,
        is_home_therapy=True,
        at_patient_quantity=_decimal(projection.patient_quantity),
        reserved_quantity=_decimal(projection.reserved_quantity),
        confirmed_delivery_quantity=confirmed_quantity,
        confirmed_delivery_used=incoming_used,
        approved_not_ordered_quantity=approved_quantity,
        new_commission_quantity=new_quantity,
        physically_secured_until=physically_secured_until,
        first_without_available_source=first_without_source,
        first_commission_calculation_dose=calculation_period_start,
        expected_delivery=expected_delivery,
        expected_delivery_confirmed=bool(confirmed_delivery_date),
        commission_window=regular_window,
        commission_date=commission_date,
        preparation_date=preparation_date,
        next_dispensing_date=projection.next_dispensing,
        immediate_risk=immediate_risk,
        first_risk_dose=first_risk_dose,
        first_risk_missing_quantity=risk_missing,
        uncovered_before_delivery_dates=tuple(
            item["datum"] for item in risk_items
        ),
        uncovered_before_delivery_quantity=(
            uncovered_before_delivery_quantity
        ),
        status_label=status_label,
        current_action=current_action,
        warning_text=warning_text,
        immediate_action_text=immediate_action_text,
        action_options=action_options,
        allocations=allocations,
        dose_plan=normalised_plan,
    )
