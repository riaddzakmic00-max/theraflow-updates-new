from django.contrib import admin

from .models import UpdateHistory, UpdateSession


@admin.register(UpdateSession)
class UpdateSessionAdmin(admin.ModelAdmin):
    list_display = ("target_version", "status", "is_active", "created_at")
    readonly_fields = ("id", "created_at", "updated_at")


@admin.register(UpdateHistory)
class UpdateHistoryAdmin(admin.ModelAdmin):
    list_display = ("source_version", "target_version", "status", "started_at", "final_active_version")
    list_filter = ("status", "rollback_executed")
    readonly_fields = tuple(field.name for field in UpdateHistory._meta.fields)
