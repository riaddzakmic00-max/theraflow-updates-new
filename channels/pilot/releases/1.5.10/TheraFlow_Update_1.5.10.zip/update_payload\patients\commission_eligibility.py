"""Kanonska odluka na koji komisijski ciklus pacijent mora biti uključen.

Modul ne računa pokriće ponovo. Koristi raspodjelu izvora i projekcije koje
već proizvodi ``commission_demand`` te im dodaje zajednički administrativni
kalendar komisija.
"""

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal

from django.utils import timezone

from .commission_demand import (
    APPROVED_WAITING_AVAILABLE_ON,
    SOURCE_APPROVED_WAITING,
    quantity_breakdown_for_horizon,
)
from .commission_service import (
    add_calendar_months,
    get_commission_schedule,
    get_settings,
    next_workday,
    subtract_workdays,
)
from .models import KomisijskiCiklus, Termin, Trebovanje
from .future_therapy_planning import is_new_patient_before_first_therapy
from .individual_protocols import get_effective_protocol
from .package_sizes import package_count, round_up_to_package
from .phased_protocols import phased_planning_configuration


STATUS_MORA_TRENUTNA = "MORA_NA_OVU_KOMISIJU"
STATUS_MOZE_PRESKOCITI = "MOZE_PRESKOCITI"
STATUS_PLANIRATI_KASNIJE = "PLANIRATI_KASNIJE"
STATUS_RIZIK_PREKIDA = "RIZIK_PREKIDA_TERAPIJE"

WORKFLOW_NEW_AWAITING_INITIAL_COMMISSION = "NEW_AWAITING_INITIAL_COMMISSION"
WORKFLOW_MAINTENANCE = "MAINTENANCE"
WORKFLOW_MISSING_CONFIGURATION = "MISSING_CONFIGURATION"
WORKFLOW_AWAITING_DELIVERY = "AWAITING_DELIVERY"
WORKFLOW_READY_TO_SCHEDULE = "READY_TO_SCHEDULE"
WORKFLOW_AWAITING_COMMISSION_DECISION = "AWAITING_COMMISSION_DECISION"

STATUS_LABELS = {
    STATUS_MORA_TRENUTNA: "Mora na ovu komisiju",
    STATUS_MOZE_PRESKOCITI: "Može preskočiti ovu komisiju",
    STATUS_PLANIRATI_KASNIJE: "Planirati za kasniju komisiju",
    STATUS_RIZIK_PREKIDA: "Rizik prekida terapije",
}


@dataclass(frozen=True)
class CommissionWindow:
    datum_komisije: date
    rok_pripreme: date
    najranija_isporuka: date
    najkasnija_isporuka: date
    izvor: str
    ciklus: object | None = None


@dataclass(frozen=True)
class CommissionEligibility:
    status: str
    status_label: str
    trenutna_komisija: CommissionWindow | None
    posljednja_sigurna_komisija: CommissionWindow | None
    planirati_za_komisiju: CommissionWindow | None
    prva_nepokrivena_terapija: date | None
    pokriven_do: date | None
    treba_na_trenutnu_komisiju: bool
    moze_preskociti_trenutnu: bool
    preporucena_kolicina: Decimal
    buduca_preporucena_kolicina: Decimal
    broj_pakovanja: int
    razlog: str
    nivo_rizika: str
    ukupan_deficit_do_sljedece_isporuke: Decimal
    hitna_kolicina_prije_isporuke: Decimal
    kolicina_za_sljedecu_komisiju: Decimal
    rok_propusten: bool
    minimalna_potrebna_kolicina: Decimal = Decimal("0")
    sigurnosna_rezerva_kolicina: Decimal = Decimal("0")
    vec_pokriveno: Decimal = Decimal("0")
    preporucena_kolicina_za_komisiju: Decimal = Decimal("0")
    pouzdana_isporuka_trenutne_komisije: date | None = None
    naredna_komisija: CommissionWindow | None = None
    pouzdana_isporuka_naredne_komisije: date | None = None
    obracunski_period_pocetak: date | None = None
    obracunski_period_kraj: date | None = None
    obracunski_prikaz_period_kraj: date | None = None
    obracunski_ciljni_datum: date | None = None
    obracunski_razlog: str = ""


@dataclass(frozen=True)
class PatientTherapyWorkflowState:
    code: str
    label: str
    reason: str = ""


def _window_for_date(
    commission_date,
    *,
    settings,
    cycle=None,
    source="PROCJENA",
):
    preparation = (
        cycle.rok_pripreme_dokumentacije
        if cycle and cycle.rok_pripreme_dokumentacije
        else subtract_workdays(
            commission_date,
            settings.priprema_zahtjeva_radnih_dana,
        )
    )
    earliest = (
        cycle.najraniji_ocekivani_datum_isporuke
        if cycle and cycle.najraniji_ocekivani_datum_isporuke
        else next_workday(
            commission_date + timedelta(days=settings.vrijeme_isporuke_dana)
        )
    )
    latest = (
        cycle.najkasniji_ocekivani_datum_isporuke
        if cycle and cycle.najkasniji_ocekivani_datum_isporuke
        else next_workday(
            commission_date
            + timedelta(
                days=(
                    settings.vrijeme_isporuke_dana
                    + settings.sigurnosna_rezerva_dana
                )
            )
        )
    )
    return CommissionWindow(
        datum_komisije=next_workday(commission_date),
        rok_pripreme=preparation,
        najranija_isporuka=next_workday(earliest),
        najkasnija_isporuka=next_workday(latest),
        izvor=source,
        ciklus=cycle,
    )


def commission_windows(*, today=None, count=8, settings=None):
    """Vrati zajedničke cikluse iz istog izvora kao Komisijski centar.

    Aktivni ciklus ostaje dostupan dok je operativno relevantan. Za prvi
    *sljedeći* ciklus potvrđeni datum iz postavki ima prednost nad starijim
    nacrtima; interval je fallback kada potvrđeni datum ne postoji.
    """

    today = today or timezone.localdate()
    settings = settings or get_settings()
    schedule = get_commission_schedule(today=today, settings=settings)
    planned_next_date = schedule.effective_next_date
    active_cycle = schedule.active_cycle
    explicit_cycles = list(
        KomisijskiCiklus.objects.filter(
            datum_komisije__gte=today,
            tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI,
        )
        .exclude(status__in=("ZAPRIMLJENO", "ZAVRSENO", "zavrseno"))
        .order_by("datum_komisije", "id")
    )
    explicit_cycles = [
        cycle
        for cycle in explicit_cycles
        if (
            (active_cycle is not None and cycle.pk == active_cycle.pk)
            or
            not planned_next_date
            or next_workday(cycle.datum_komisije) >= planned_next_date
        )
    ]
    explicit_by_date = {
        next_workday(cycle.datum_komisije): cycle for cycle in explicit_cycles
    }
    dates = set(explicit_by_date)
    cursor = planned_next_date
    while cursor and cursor < today:
        cursor = add_calendar_months(
            cursor,
            settings.komisijski_ciklus_mjeseci,
        )
    if cursor:
        dates.add(next_workday(cursor))

    # Evidentirani budući ciklusi su administrativni source of truth. Kada
    # postoji npr. potvrđeni ciklus 03/09 i stvarno planirani ciklus 19/10,
    # ne smijemo između njih ubaciti izvedeni ciklus 05/10 samo zato što je
    # konfigurirani interval jedan mjesec. Automatski interval je isključivo
    # nastavak nakon posljednjeg poznatog ciklusa (ili potpuni fallback kada
    # nijedan ciklus nije evidentiran).
    cursor = max(dates) if dates else cursor
    if cursor:
        cursor = add_calendar_months(
            cursor,
            settings.komisijski_ciklus_mjeseci,
        )
    while cursor and len(dates) < count:
        cursor = next_workday(cursor)
        dates.add(cursor)
        cursor = add_calendar_months(
            cursor,
            settings.komisijski_ciklus_mjeseci,
        )
    windows = []
    for commission_date in sorted(dates)[:count]:
        cycle = explicit_by_date.get(commission_date)
        windows.append(_window_for_date(
            commission_date,
            settings=settings,
            cycle=cycle,
            source="UNESENI_CIKLUS" if cycle else "PROCJENA_IZ_CIKLUSA",
        ))
    return tuple(windows)


def _covered_until(demand):
    covered = [
        item.datum_terapije
        for item in demand.detalji
        if item.nedostatak <= 0
    ]
    return covered[-1] if covered else None


def _shortage_until(demand, target_date):
    return sum(
        (
            Decimal(str(item.nedostatak or 0))
            for item in demand.detalji
            if item.datum_terapije <= target_date
        ),
        Decimal("0"),
    )


def _shortage_before_delivery(demand, delivery_date):
    if not delivery_date:
        return Decimal("0")
    return sum(
        (
            Decimal(str(item.nedostatak or 0))
            for item in demand.detalji
            if (
                getattr(item, "termin_postoji", False)
                and item.datum_terapije < delivery_date
            )
        ),
        Decimal("0"),
    )


def _patient_has_submitted_request(patient, window=None):
    requests = list(getattr(patient, "_workflow_requests", ()))
    for request in requests:
        if request.status not in {
            "PREDATO",
            "ODOBRENO",
            "ZAPRIMLJENO",
            Trebovanje.STATUS_POSLAN_KOMISIJI,
            Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
            Trebovanje.STATUS_CEKA_ISPORUKU,
        }:
            continue
        if not window:
            return True
        if window.ciklus and request.komisijski_ciklus_id == window.ciklus.pk:
            return True
        request_cycle = getattr(request, "komisijski_ciklus", None)
        if (
            request_cycle
            and next_workday(request_cycle.datum_komisije)
            == window.datum_komisije
        ):
            return True
    return False


def _format_date(value):
    return value.strftime("%d/%m/%Y") if value else "nije utvrđeno"


def _home_quantity_horizon(demand, projection, target_date):
    """Objasni zaključani količinski horizont kućne terapije."""

    first_physically_uncovered = projection.first_uncovered_therapy
    units = Decimal(str(projection.units_per_application or 0))
    interval = int(projection.interval_weeks or 0)
    if (
        not first_physically_uncovered
        or not target_date
        or units <= 0
        or interval <= 0
    ):
        return None

    free_quantity = Decimal(str(
        getattr(demand, "kolicina_slobodne_zalihe", 0) or 0
    ))
    free_applications = int(free_quantity // units)
    first_without_available_source = (
        first_physically_uncovered
        + timedelta(weeks=free_applications * interval)
    )
    # Komisijski period namjerno uključuje jednu dozu neposredno prije prvog
    # stvarnog manjka. Ta granična doza može biti pokrivena slobodnim penom,
    # ali slobodna zaliha nije pacijentovo komisijsko pravo i mora se obnoviti
    # u narednom planskom periodu.
    period_start = max(
        first_physically_uncovered,
        first_without_available_source - timedelta(weeks=interval),
    )

    # Jedan komisijski ciklus predstavlja osnovnu potrebu. Pouzdani datum
    # naredne isporuke i dalje odlučuje mora li pacijent u trenutni ciklus,
    # ali se količina ne širi na više ciklusa i time ne skriva rezervu.
    settings = get_settings()
    cycle_horizon = add_calendar_months(
        period_start,
        settings.komisijski_ciklus_mjeseci,
    )
    quantity_horizon = min(target_date, cycle_horizon)
    covered_days = max((quantity_horizon - period_start).days, 0)
    # Period je inkluzivan: doza na početku obračuna je prva doza, a svaka
    # naredna protokolarna doza koja pada do ciljnog datuma također ulazi u
    # potrebu. Bez ``+ 1`` period 07/10–06/11 pogrešno bi brojao samo dvije
    # umjesto doza 07/10, 21/10 i 04/11.
    applications = max(1, covered_days // (interval * 7))
    if target_date <= cycle_horizon:
        # Kada cilj pada unutar osnovnog ciklusa, uključuje se i doza na
        # početku perioda. Kod produženja izvan ciklusa postojeći broj punih
        # dodatnih intervala već predstavlja poslovno definisanu ekstenziju i
        # ne smije dobiti još jednu fantomsku dozu.
        applications += 1
    # Ako neradni dan pomjeri pouzdanu isporuku za najmanje još jedan puni
    # terapijski interval izvan ciklusa, ta dodatna primjena ulazi u osnovu.
    delayed_days = max((target_date - cycle_horizon).days, 0)
    delayed_applications = delayed_days // (interval * 7)
    applications += delayed_applications
    canonical_dose_dates = tuple(
        detail.datum_terapije
        for detail in sorted(
            getattr(demand, "detalji", ()) or (),
            key=lambda item: item.datum_terapije,
        )
        if detail.datum_terapije >= period_start
    )[:applications]
    period_end = (
        canonical_dose_dates[-1]
        if canonical_dose_dates else
        period_start + timedelta(weeks=(applications - 1) * interval)
    )
    # Domenski kraj obračunskog horizonta i datum posljednje doze nisu ista
    # stvar. Ako pouzdana isporuka/cilj pada između dvije protokolarne doze,
    # UI mora prikazati puni horizont (npr. 07/10–06/11), dok ``period_end``
    # ostaje 04/11 kao posljednja doza stvarno uključena u računicu.
    display_period_end = (
        quantity_horizon
        if target_date <= cycle_horizon
        else period_end
    )
    if delayed_applications > 0:
        delayed_dose_label = (
            "protokolarnu dozu"
            if delayed_applications == 1
            else "protokolarne doze"
            if 2 <= delayed_applications <= 4
            else "protokolarnih doza"
        )
        reason = (
            f"Osnovni horizont je konfigurirani komisijski ciklus od "
            f"{settings.komisijski_ciklus_mjeseci} mjeseca. Produžen je za "
            f"{delayed_applications} {delayed_dose_label} zbog razmaka do "
            f"pouzdane isporuke narednog ciklusa {target_date:%d/%m/%Y}; "
            f"posljednja doza ovog obračuna je {period_end:%d/%m/%Y}."
        )
    else:
        reason = (
            f"Ciljni kraj planskog perioda je pouzdani datum isporuke "
            f"{display_period_end:%d/%m/%Y}; posljednja protokolarna doza "
            f"unutar tog perioda je {period_end:%d/%m/%Y}."
        )
    return {
        "period_start": period_start,
        "period_end": period_end,
        "display_period_end": display_period_end,
        "target_date": target_date,
        "applications": applications,
        "dose_dates": canonical_dose_dates,
        "delayed_applications": delayed_applications,
        "reason": reason,
    }


def _home_quantity_breakdown(demand, projection, target_date):
    """Home-potreba do horizonta, uz odvojeno administrativno pravo."""

    horizon = _home_quantity_horizon(demand, projection, target_date)
    if horizon is None:
        return quantity_breakdown_for_horizon(demand, target_date)

    units = Decimal(str(projection.units_per_application or 0))
    applications = horizon["applications"]
    minimum = units * applications
    # Vremenska rezerva određuje konzervativni datum isporuke, a klinička
    # rezerva je zasebna fizička količina. Za adalimumab je postojeći
    # centralni policy pretvara u cijelo pakovanje od dva pena.
    reserve = Decimal(str(
        getattr(demand, "sigurnosna_rezerva_kolicina", 0) or 0
    ))
    # Do prve nepokrivene primjene već su potrošene sve cijele primjene iz
    # zajedničkog pacijentskog fizičkog poola (kod pacijenta + rezervisano).
    # U buduću komisijsku osnovu smije se prenijeti samo necjelobrojni ostatak
    # tog poola. Ponovno dodavanje cijele rezervacije bi iste doze prvo
    # koristilo za produženje ``pokriven do``, a zatim još jednom za umanjenje
    # komisijske preporuke.
    physically_available = (
        Decimal(str(projection.patient_quantity or 0))
        + Decimal(str(projection.reserved_quantity or 0))
    ) % units
    # Samo stvarno najavljena količina sa poznatim datumom može umanjiti novi
    # zahtjev. Preostalo pravo iz aktivne komisije bez takve isporuke ne ulazi
    # u ovu formulu. ``demand_for_reliable_delivery_planning`` je prije ovog
    # koraka već uklonio nepouzdane izvore i ostavio samo doze čija isporuka
    # stiže na vrijeme za konkretan događaj.
    available = getattr(demand, "dostupno_po_izvoru", {}) or {}
    incoming_available_on = available.get(APPROVED_WAITING_AVAILABLE_ON)
    incoming_total = Decimal(str(
        getattr(demand, "kolicina_odobrena_nedostavljena", 0) or 0
    ))
    pre_delivery_required = sum(
        (
            Decimal(str(detail.potrebna_kolicina or 0))
            for detail in demand.detalji
            if horizon["period_start"] <= detail.datum_terapije <= horizon["period_end"]
            and (
                incoming_available_on is None
                or detail.datum_terapije < incoming_available_on
            )
        ),
        Decimal("0"),
    )
    usable_active_approval = Decimal(str(
        getattr(demand, "kolicina_pokrivena_aktivnom_komisijom", 0) or 0
    ))
    existing_before_delivery = physically_available + usable_active_approval
    uncovered_before_delivery = max(
        Decimal("0"),
        pre_delivery_required - existing_before_delivery,
    )
    remaining_requirement = max(
        Decimal("0"),
        minimum + reserve - uncovered_before_delivery,
    )
    confirmed_incoming = (
        min(incoming_total, remaining_requirement)
        if incoming_available_on
        and incoming_available_on <= horizon["display_period_end"]
        else Decimal("0")
    )
    already_covered = min(
        minimum + reserve,
        existing_before_delivery + confirmed_incoming,
    )
    raw = max(Decimal("0"), minimum + reserve - already_covered)
    recommended = round_up_to_package(raw, demand.lijek)
    from .commission_demand import CommissionQuantityBreakdown

    return CommissionQuantityBreakdown(
        minimal_required=minimum,
        safety_reserve=reserve,
        already_covered=already_covered,
        raw_recommendation=raw,
        recommended_quantity=recommended,
    )


class CommissionEligibilityService:
    """Spaja postojeći klinički obračun s administrativnim ciklusima."""

    def __init__(self, *, today=None, settings=None):
        self.today = today or timezone.localdate()
        self.settings = settings or get_settings()
        self.windows = commission_windows(
            today=self.today,
            settings=self.settings,
        )
        schedule = get_commission_schedule(today=self.today, settings=self.settings)
        scheduled_date = schedule.effective_next_date
        self.missed_window = None
        if scheduled_date:
            candidate = _window_for_date(
                scheduled_date,
                settings=self.settings,
                source="PROPUSTENI_CIKLUS",
            )
            if candidate.rok_pripreme < self.today:
                self.missed_window = candidate

    def _evaluate_home(self, demand, available_windows, current):
        if not current or not getattr(demand.lijek, "kucna_terapija", False):
            return None
        from .home_therapy import calculate_home_therapy_projection

        projection = calculate_home_therapy_projection(
            demand.pacijent,
            today=self.today,
        )
        first_uncovered = projection.first_uncovered_therapy
        if not first_uncovered:
            return None
        try:
            current_index = available_windows.index(current)
        except ValueError:
            current_index = 0
        next_window = (
            available_windows[current_index + 1]
            if len(available_windows) > current_index + 1
            else current
        )
        following_window = (
            available_windows[current_index + 2]
            if len(available_windows) > current_index + 2
            else next_window
        )
        current_delivery = current.najkasnija_isporuka
        next_delivery = next_window.najkasnija_isporuka
        must_current = bool(next_delivery and first_uncovered < next_delivery)
        current_request_exists = _patient_has_submitted_request(
            demand.pacijent,
            current,
        )
        current_cycle_is_committed = bool(
            getattr(current, "ciklus", None)
            and str(getattr(current.ciklus, "status", "") or "").upper()
            not in {"", "SIMULACIJA", "PLANIRAN"}
        )
        has_separate_orderable_approval = (
            Decimal(str(
                getattr(
                    demand,
                    "kolicina_pokrivena_aktivnom_komisijom",
                    0,
                )
                or 0
            ))
            > 0
        )

        if (
            must_current
            and current_request_exists
            and current_cycle_is_committed
            and has_separate_orderable_approval
        ):
            # Pacijent je već obuhvaćen trenutnim ciklusom. Taj postojeći
            # zahtjev i eventualni fizički jaz do njegove isporuke ostaju
            # zasebna operativna tema; novi redovni prijedlog pripada narednom
            # ciklusu i mora pokriti period do isporuke ciklusa poslije njega.
            quantity_target = following_window.najkasnija_isporuka
            quantity_horizon = _home_quantity_horizon(
                demand,
                projection,
                quantity_target,
            )
            future_breakdown = _home_quantity_breakdown(
                demand,
                projection,
                quantity_target,
            )
            delivery_risk = bool(
                current_delivery and current_delivery > first_uncovered
            )
            status = (
                STATUS_RIZIK_PREKIDA
                if delivery_risk else STATUS_PLANIRATI_KASNIJE
            )
            return CommissionEligibility(
                status=status,
                status_label=STATUS_LABELS[status],
                trenutna_komisija=current,
                posljednja_sigurna_komisija=next_window,
                planirati_za_komisiju=next_window,
                prva_nepokrivena_terapija=first_uncovered,
                pokriven_do=projection.physical_covered_until,
                treba_na_trenutnu_komisiju=False,
                moze_preskociti_trenutnu=True,
                preporucena_kolicina=future_breakdown.recommended_quantity,
                buduca_preporucena_kolicina=(
                    future_breakdown.recommended_quantity
                ),
                broj_pakovanja=package_count(
                    future_breakdown.recommended_quantity,
                    demand.lijek,
                ),
                razlog=(
                    "Postojeći zahtjev već pripada ciklusu "
                    f"{_format_date(current.datum_komisije)}. "
                    + (
                        "Prva fizički nepokrivena doza nastupa prije njegove "
                        "isporuke i zahtijeva zasebnu hitnu akciju. "
                        if delivery_risk else ""
                    )
                    + "Redovni novi prijedlog pripada ciklusu "
                    f"{_format_date(next_window.datum_komisije)}."
                ),
                nivo_rizika="KRITICAN" if delivery_risk else "NIZAK",
                ukupan_deficit_do_sljedece_isporuke=(
                    projection.units_per_application
                    if delivery_risk else Decimal("0")
                ),
                hitna_kolicina_prije_isporuke=(
                    projection.units_per_application
                    if delivery_risk else Decimal("0")
                ),
                kolicina_za_sljedecu_komisiju=(
                    future_breakdown.recommended_quantity
                ),
                rok_propusten=False,
                minimalna_potrebna_kolicina=(
                    future_breakdown.minimal_required
                ),
                sigurnosna_rezerva_kolicina=(
                    future_breakdown.safety_reserve
                ),
                vec_pokriveno=future_breakdown.already_covered,
                preporucena_kolicina_za_komisiju=(
                    future_breakdown.recommended_quantity
                ),
                pouzdana_isporuka_trenutne_komisije=current_delivery,
                naredna_komisija=next_window,
                pouzdana_isporuka_naredne_komisije=next_delivery,
                obracunski_period_pocetak=(
                    quantity_horizon["period_start"]
                    if quantity_horizon else None
                ),
                obracunski_period_kraj=(
                    quantity_horizon["period_end"]
                    if quantity_horizon else None
                ),
                obracunski_prikaz_period_kraj=(
                    quantity_horizon["display_period_end"]
                    if quantity_horizon else None
                ),
                obracunski_ciljni_datum=(
                    quantity_horizon["target_date"]
                    if quantity_horizon else quantity_target
                ),
                obracunski_razlog=(
                    quantity_horizon["reason"] if quantity_horizon else ""
                ),
            )

        if must_current:
            quantity_horizon = _home_quantity_horizon(
                demand,
                projection,
                next_delivery,
            )
            breakdown = _home_quantity_breakdown(
                demand,
                projection,
                next_delivery,
            )
            recommendation = breakdown.recommended_quantity
            delivery_risk = bool(
                current_delivery and current_delivery > first_uncovered
            )
            status = (
                STATUS_RIZIK_PREKIDA
                if delivery_risk else STATUS_MORA_TRENUTNA
            )
            reason = (
                "Rizik prekida terapije – potrebna ranija isporuka, "
                "postojeća zaliha ili vanredni zahtjev."
                if delivery_risk else (
                    f"Ako se preskoči komisija {_format_date(current.datum_komisije)}, "
                    f"prva terapija bez pokrića {_format_date(first_uncovered)} "
                    "nastupa prije pouzdane isporuke nakon naredne komisije "
                    f"({_format_date(next_delivery)})."
                )
            )
            urgent = _home_quantity_breakdown(
                demand,
                projection,
                current_delivery,
            ).minimal_required if delivery_risk else Decimal("0")
            return CommissionEligibility(
                status=status,
                status_label=STATUS_LABELS[status],
                trenutna_komisija=current,
                posljednja_sigurna_komisija=(
                    current if current_delivery and current_delivery <= first_uncovered else None
                ),
                planirati_za_komisiju=current,
                prva_nepokrivena_terapija=first_uncovered,
                pokriven_do=projection.physical_covered_until,
                treba_na_trenutnu_komisiju=True,
                moze_preskociti_trenutnu=False,
                preporucena_kolicina=recommendation,
                buduca_preporucena_kolicina=Decimal("0"),
                broj_pakovanja=package_count(recommendation, demand.lijek),
                razlog=reason,
                nivo_rizika="KRITICAN" if delivery_risk else "VISOK",
                ukupan_deficit_do_sljedece_isporuke=urgent,
                hitna_kolicina_prije_isporuke=urgent,
                kolicina_za_sljedecu_komisiju=recommendation,
                rok_propusten=False,
                minimalna_potrebna_kolicina=breakdown.minimal_required,
                sigurnosna_rezerva_kolicina=breakdown.safety_reserve,
                vec_pokriveno=breakdown.already_covered,
                preporucena_kolicina_za_komisiju=recommendation,
                pouzdana_isporuka_trenutne_komisije=current_delivery,
                naredna_komisija=next_window,
                pouzdana_isporuka_naredne_komisije=next_delivery,
                obracunski_period_pocetak=(
                    quantity_horizon["period_start"]
                    if quantity_horizon else None
                ),
                obracunski_period_kraj=(
                    quantity_horizon["period_end"]
                    if quantity_horizon else None
                ),
                obracunski_prikaz_period_kraj=(
                    quantity_horizon["display_period_end"]
                    if quantity_horizon else None
                ),
                obracunski_ciljni_datum=(
                    quantity_horizon["target_date"]
                    if quantity_horizon else next_delivery
                ),
                obracunski_razlog=(
                    quantity_horizon["reason"] if quantity_horizon else ""
                ),
            )

        quantity_horizon = _home_quantity_horizon(
            demand,
            projection,
            following_window.najkasnija_isporuka,
        )
        future_breakdown = _home_quantity_breakdown(
            demand,
            projection,
            following_window.najkasnija_isporuka,
        )
        return CommissionEligibility(
            status=STATUS_PLANIRATI_KASNIJE,
            status_label=STATUS_LABELS[STATUS_PLANIRATI_KASNIJE],
            trenutna_komisija=current,
            posljednja_sigurna_komisija=next_window,
            planirati_za_komisiju=next_window,
            prva_nepokrivena_terapija=first_uncovered,
            pokriven_do=projection.physical_covered_until,
            treba_na_trenutnu_komisiju=False,
            moze_preskociti_trenutnu=True,
            preporucena_kolicina=Decimal("0"),
            buduca_preporucena_kolicina=future_breakdown.recommended_quantity,
            broj_pakovanja=0,
            razlog=(
                f"Pacijent može preskočiti komisiju {_format_date(current.datum_komisije)}; "
                f"pouzdana isporuka nakon naredne komisije {_format_date(next_delivery)} "
                f"prethodi prvoj nepokrivenoj terapiji {_format_date(first_uncovered)}."
            ),
            nivo_rizika="NIZAK",
            ukupan_deficit_do_sljedece_isporuke=Decimal("0"),
            hitna_kolicina_prije_isporuke=Decimal("0"),
            kolicina_za_sljedecu_komisiju=future_breakdown.recommended_quantity,
            rok_propusten=False,
            minimalna_potrebna_kolicina=future_breakdown.minimal_required,
            sigurnosna_rezerva_kolicina=future_breakdown.safety_reserve,
            vec_pokriveno=future_breakdown.already_covered,
            preporucena_kolicina_za_komisiju=future_breakdown.recommended_quantity,
            pouzdana_isporuka_trenutne_komisije=current_delivery,
            naredna_komisija=next_window,
            pouzdana_isporuka_naredne_komisije=next_delivery,
            obracunski_period_pocetak=(
                quantity_horizon["period_start"]
                if quantity_horizon else None
            ),
            obracunski_period_kraj=(
                quantity_horizon["period_end"]
                if quantity_horizon else None
            ),
            obracunski_prikaz_period_kraj=(
                quantity_horizon["display_period_end"]
                if quantity_horizon else None
            ),
            obracunski_ciljni_datum=(
                quantity_horizon["target_date"]
                if quantity_horizon else following_window.najkasnija_isporuka
            ),
            obracunski_razlog=(
                quantity_horizon["reason"] if quantity_horizon else ""
            ),
        )

    def evaluate(self, demand):
        skipped_windows = tuple(
            window
            for window in self.windows
            if (
                window.rok_pripreme < self.today
                and not _patient_has_submitted_request(
                    getattr(demand, "pacijent", None),
                    window,
                )
            )
        )
        available_windows = tuple(
            window
            for window in self.windows
            if (
                window.rok_pripreme >= self.today
                or _patient_has_submitted_request(
                    getattr(demand, "pacijent", None),
                    window,
                )
            )
        )
        current = available_windows[0] if available_windows else None
        first_uncovered = demand.datum_prve_nepokrivene_terapije
        covered_until = _covered_until(demand)
        next_after_current = (
            available_windows[1] if len(available_windows) > 1 else current
        )
        timeline = {
            "pouzdana_isporuka_trenutne_komisije": (
                current.najkasnija_isporuka if current else None
            ),
            "naredna_komisija": next_after_current,
            "pouzdana_isporuka_naredne_komisije": (
                next_after_current.najkasnija_isporuka
                if next_after_current else None
            ),
        }
        home_result = self._evaluate_home(demand, available_windows, current)
        if home_result is not None:
            return home_result
        quantity_horizon = (
            next_after_current.najkasnija_isporuka
            if next_after_current else demand.ciljni_datum
        )
        current_breakdown = quantity_breakdown_for_horizon(
            demand,
            quantity_horizon,
        )
        if (
            not current
            or (
                not first_uncovered
                and current_breakdown.recommended_quantity <= 0
            )
        ):
            return CommissionEligibility(
                status=STATUS_MOZE_PRESKOCITI,
                status_label=STATUS_LABELS[STATUS_MOZE_PRESKOCITI],
                trenutna_komisija=current,
                posljednja_sigurna_komisija=None,
                planirati_za_komisiju=None,
                prva_nepokrivena_terapija=first_uncovered,
                pokriven_do=covered_until,
                treba_na_trenutnu_komisiju=False,
                moze_preskociti_trenutnu=True,
                preporucena_kolicina=Decimal("0"),
                buduca_preporucena_kolicina=Decimal("0"),
                broj_pakovanja=0,
                razlog=(
                    "Pacijent nema nepokrivenu terapiju u pouzdanom planskom "
                    "horizontu i ne treba ga uključiti u trenutnu komisiju."
                ),
                nivo_rizika="NIZAK",
                ukupan_deficit_do_sljedece_isporuke=Decimal("0"),
                hitna_kolicina_prije_isporuke=Decimal("0"),
                kolicina_za_sljedecu_komisiju=Decimal("0"),
                rok_propusten=False,
                minimalna_potrebna_kolicina=(
                    current_breakdown.minimal_required
                ),
                sigurnosna_rezerva_kolicina=(
                    current_breakdown.safety_reserve
                ),
                vec_pokriveno=current_breakdown.already_covered,
                preporucena_kolicina_za_komisiju=Decimal("0"),
                **timeline,
            )

        if not first_uncovered:
            recommendation = current_breakdown.recommended_quantity
            return CommissionEligibility(
                status=STATUS_MORA_TRENUTNA,
                status_label=STATUS_LABELS[STATUS_MORA_TRENUTNA],
                trenutna_komisija=current,
                posljednja_sigurna_komisija=current,
                planirati_za_komisiju=current,
                prva_nepokrivena_terapija=None,
                pokriven_do=covered_until,
                treba_na_trenutnu_komisiju=True,
                moze_preskociti_trenutnu=False,
                preporucena_kolicina=recommendation,
                buduca_preporucena_kolicina=Decimal("0"),
                broj_pakovanja=package_count(recommendation, demand.lijek),
                razlog=(
                    "Planirane terapije su trenutno pokrivene, ali bi "
                    "projektovano stanje do naredne sigurne isporuke palo "
                    "ispod podešene sigurnosne rezerve."
                ),
                nivo_rizika="VISOK",
                ukupan_deficit_do_sljedece_isporuke=Decimal("0"),
                hitna_kolicina_prije_isporuke=Decimal("0"),
                kolicina_za_sljedecu_komisiju=recommendation,
                rok_propusten=False,
                minimalna_potrebna_kolicina=(
                    current_breakdown.minimal_required
                ),
                sigurnosna_rezerva_kolicina=(
                    current_breakdown.safety_reserve
                ),
                vec_pokriveno=current_breakdown.already_covered,
                preporucena_kolicina_za_komisiju=recommendation,
                **timeline,
            )

        # Ciklus je siguran kada njegova konzervativna (najkasnija) isporuka
        # stigne najkasnije na datum terapije. Ovo je isti <= invariant koji
        # koristi odluka o preskakanju trenutnog ciklusa.
        safe = [
            window
            for window in available_windows
            if window.najkasnija_isporuka <= first_uncovered
        ]
        last_safe = safe[-1] if safe else None
        current_quantity = current_breakdown.recommended_quantity
        urgent_quantity = _shortage_before_delivery(
            demand,
            current.najkasnija_isporuka,
        )
        missed_candidate = (
            skipped_windows[-1]
            if skipped_windows
            else self.missed_window
        )
        missed_deadline = bool(
            missed_candidate
            and not _patient_has_submitted_request(
                getattr(demand, "pacijent", None),
                missed_candidate,
            )
            and first_uncovered < current.najkasnija_isporuka
        )

        if current.najkasnija_isporuka > first_uncovered:
            status = STATUS_RIZIK_PREKIDA
            reason = (
                f"Prva terapija bez pokrića je {_format_date(first_uncovered)}, "
                f"a najkasnija očekivana isporuka s komisije "
                f"{_format_date(current.datum_komisije)} je "
                f"{_format_date(current.najkasnija_isporuka)} Potrebna je hitna "
                "provjera postojeće zalihe ili ranije nabavke."
            )
            selected = current
            must_current = True
            future_quantity = Decimal("0")
            risk = "KRITICAN"
        elif last_safe and last_safe.datum_komisije == current.datum_komisije:
            status = STATUS_MORA_TRENUTNA
            reason = (
                f"Pacijent je pokriven do {_format_date(covered_until)} "
                f"Komisija {_format_date(current.datum_komisije)} je posljednja "
                "sigurna komisija čija isporuka može stići prije prve "
                f"nepokrivene terapije {_format_date(first_uncovered)}"
            )
            selected = current
            must_current = True
            future_quantity = Decimal("0")
            risk = "VISOK"
        else:
            selected = last_safe
            status = (
                STATUS_PLANIRATI_KASNIJE
                if selected
                else STATUS_MOZE_PRESKOCITI
            )
            selected_label = (
                f" Planirati komisiju {_format_date(selected.datum_komisije)}"
                if selected else ""
            )
            reason = (
                f"Pacijent je pokriven do {_format_date(covered_until)} i može "
                f"preskočiti komisiju {_format_date(current.datum_komisije)}"
                f"{selected_label}"
            )
            must_current = False
            future_horizon = (
                available_windows[
                    min(
                        available_windows.index(selected) + 1,
                        len(available_windows) - 1,
                    )
                ].najkasnija_isporuka
                if selected else quantity_horizon
            )
            future_breakdown = quantity_breakdown_for_horizon(
                demand,
                future_horizon,
            )
            future_quantity = future_breakdown.recommended_quantity
            current_quantity = Decimal("0")
            selected_breakdown = future_breakdown
            risk = "NIZAK" if selected else "SREDNJI"

        if status != STATUS_PLANIRATI_KASNIJE:
            selected_breakdown = current_breakdown

        if missed_deadline:
            status = STATUS_RIZIK_PREKIDA
            selected = current
            must_current = True
            risk = "KRITICAN"
            reason = (
                "Rok za prethodnu komisiju je propušten. "
                f"Sljedeća stvarno dostupna komisija je "
                f"{_format_date(current.datum_komisije)}, a njena najkasnija "
                f"očekivana isporuka je "
                f"{_format_date(current.najkasnija_isporuka)} "
                f"Prva terapija bez pokrića je {_format_date(first_uncovered)}"
            )
            selected_breakdown = current_breakdown

        return CommissionEligibility(
            status=status,
            status_label=STATUS_LABELS[status],
            trenutna_komisija=current,
            posljednja_sigurna_komisija=last_safe,
            planirati_za_komisiju=selected,
            prva_nepokrivena_terapija=first_uncovered,
            pokriven_do=covered_until,
            treba_na_trenutnu_komisiju=must_current,
            moze_preskociti_trenutnu=not must_current,
            preporucena_kolicina=current_quantity,
            buduca_preporucena_kolicina=future_quantity,
            broj_pakovanja=package_count(current_quantity, demand.lijek),
            razlog=reason,
            nivo_rizika=risk,
            ukupan_deficit_do_sljedece_isporuke=urgent_quantity,
            hitna_kolicina_prije_isporuke=urgent_quantity,
            kolicina_za_sljedecu_komisiju=(
                current_quantity if must_current else future_quantity
            ),
            rok_propusten=missed_deadline,
            minimalna_potrebna_kolicina=(
                selected_breakdown.minimal_required
            ),
            sigurnosna_rezerva_kolicina=(
                selected_breakdown.safety_reserve
            ),
            vec_pokriveno=selected_breakdown.already_covered,
            preporucena_kolicina_za_komisiju=(
                selected_breakdown.recommended_quantity
            ),
            **timeline,
        )


def patient_therapy_workflow_state(
    patient,
    *,
    planning_possible=None,
    planning_reason="",
):
    """Kanonsko stanje pacijenta za prvi komisijski i klinički korak.

    Stanje prvog uključivanja zahtijeva validan, eksplicitno konfigurisan
    protokol. Sam nedostatak Terapije ili Termina nije dovoljan.
    """

    configuration = phased_planning_configuration(patient)
    if configuration is not None and not configuration.planning_possible:
        return PatientTherapyWorkflowState(
            WORKFLOW_MISSING_CONFIGURATION,
            "Potrebna provjera",
            configuration.reason,
        )
    if planning_possible is False:
        return PatientTherapyWorkflowState(
            WORKFLOW_MISSING_CONFIGURATION,
            "Potrebna provjera",
            planning_reason or "Terapijski protokol nije kompletno definisan.",
        )

    therapies = tuple(getattr(patient, "_planning_therapies", ()))
    if therapies:
        return PatientTherapyWorkflowState(
            WORKFLOW_MAINTENANCE,
            "Terapija u toku",
        )

    requests = list(getattr(patient, "_workflow_requests", ()))
    request = (
        sorted(requests, key=lambda item: (item.datum_kreiranja, item.pk))[-1]
        if requests else None
    )
    if request is not None:
        approved = Decimal(str(request.odobrene_doze or 0))
        received = Decimal(str(request.zaprimljene_doze or 0))
        if request.status in {
            "ODOBRENO",
            Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
            Trebovanje.STATUS_CEKA_ISPORUKU,
        } and received < approved:
            return PatientTherapyWorkflowState(
                WORKFLOW_AWAITING_DELIVERY,
                "Čeka isporuku",
                "Početna količina je odobrena, ali nije u cijelosti fizički zaprimljena.",
            )
        if received >= approved > 0:
            reservations = getattr(patient, "_workflow_reservations", None)
            assignments = getattr(patient, "_workflow_assignments", None)
            if reservations is None:
                reservations = patient.rezervacije_lijeka.filter(
                    aktivno=True,
                    kolicina__gt=0,
                )
            if assignments is None:
                assignments = patient.pacijentzaduzenje_set.filter(
                    aktivno=True,
                    preostalo__gt=0,
                )
            appointments = getattr(patient, "_planning_appointments", ())
            has_active_appointment = any(
                item.status == Termin.STATUS_PLANIRANA
                for item in appointments
            )
            if (bool(reservations) or bool(assignments)) and not has_active_appointment:
                return PatientTherapyWorkflowState(
                    WORKFLOW_READY_TO_SCHEDULE,
                    "Spreman za zakazivanje",
                    "Početni lijek je fizički zaprimljen i povezan s pacijentom.",
                )
            if not bool(reservations) and not bool(assignments):
                return PatientTherapyWorkflowState(
                    WORKFLOW_AWAITING_DELIVERY,
                    "Čeka povezivanje zaprimanja",
                    "Lijek je zaprimljen, ali fizička količina još nije povezana s pacijentom.",
                )
        if request.status in {
            "PREDATO",
            Trebovanje.STATUS_POSLAN_KOMISIJI,
        }:
            return PatientTherapyWorkflowState(
                WORKFLOW_AWAITING_COMMISSION_DECISION,
                "Čeka odluku komisije",
            )

    explicitly_initial = bool(
        configuration is not None
        and configuration.relative_initial_projection
        and configuration.planning_possible
    )
    if (
        configuration is None
        and planning_possible is not False
        and getattr(patient, "pocetna_faza_terapije", "") == "INDUKCIJA"
        and get_effective_protocol(patient) is not None
        and is_new_patient_before_first_therapy(patient)
    ):
        explicitly_initial = True
    if explicitly_initial:
        return PatientTherapyWorkflowState(
            WORKFLOW_NEW_AWAITING_INITIAL_COMMISSION,
            "Za prvo uključivanje",
            "Početna faza i ljekarski propisana doza su kompletno konfigurirane.",
        )

    return PatientTherapyWorkflowState(
        WORKFLOW_MAINTENANCE,
        "Terapija u toku",
    )


def new_patient_workflow_status(patient):
    """Izvedi samo operativni status zahtjeva, bez dokumentacijskog workflowa."""

    therapies = getattr(patient, "_planning_therapies", ())
    if therapies:
        return None
    requests = list(getattr(patient, "_workflow_requests", ()))
    if not requests:
        return None
    request = sorted(requests, key=lambda item: (item.datum_kreiranja, item.pk))[-1]
    approved = Decimal(str(request.odobrene_doze or 0))
    received = Decimal(str(request.zaprimljene_doze or 0))
    if request.status == "ODBIJENO":
        return "ODBIJEN", "Odbijen"
    if request.status == "U_PRIPREMI":
        return None
    if request.status == "PREDATO":
        return "PREDAT_KOMISIJI", "Predat komisiji"
    if request.status == Trebovanje.STATUS_POSLAN_KOMISIJI:
        return "PREDAT_KOMISIJI", "Poslan komisiji"
    if request.status in {
        "ODOBRENO",
        Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
        Trebovanje.STATUS_CEKA_ISPORUKU,
    } and received <= 0:
        return "ODOBREN_CEKA_ISPORUKU", "Odobren, čeka isporuku"
    if approved > received > 0:
        return "DJELOMICNO_ZAPRIMLJENO", "Djelimično zaprimljeno"
    if received >= approved > 0:
        reservations = getattr(patient, "_workflow_reservations", None)
        assignments = getattr(patient, "_workflow_assignments", None)
        if reservations is None:
            reservations = patient.rezervacije_lijeka.filter(
                aktivno=True,
                kolicina__gt=0,
            )
        if assignments is None:
            assignments = patient.pacijentzaduzenje_set.filter(
                aktivno=True,
                preostalo__gt=0,
            )
        if not bool(reservations) and not bool(assignments):
            return "ODOBREN_CEKA_ISPORUKU", "Odobren, čeka povezivanje zaprimanja"
        appointments = getattr(patient, "_planning_appointments", ())
        has_active = any(
            item.status == Termin.STATUS_PLANIRANA
            for item in appointments
        )
        if not has_active:
            return (
                "LIJEK_ZAPRIMLJEN_CEKA_ZAKAZIVANJE",
                "Lijek zaprimljen – čeka zakazivanje",
            )
    return None
