from django.db import migrations


def disable_ustekinumab_weight_requirement(apps, schema_editor):
    TerapijskiProgram = apps.get_model("patients", "TerapijskiProgram")
    TerapijskaFaza = apps.get_model("patients", "TerapijskaFaza")

    program = TerapijskiProgram.objects.filter(kljuc="ustekinumab").first()
    if not program:
        return
    TerapijskiProgram.objects.filter(pk=program.pk).update(
        zahtijeva_tezinu_za_pocetak=False
    )
    TerapijskaFaza.objects.filter(program_id=program.pk).update(
        zahtijeva_tezinu=False
    )


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0084_oral_dispensing_migration_snapshot"),
    ]

    operations = [
        migrations.RunPython(
            disable_ustekinumab_weight_requirement,
            migrations.RunPython.noop,
        ),
    ]
