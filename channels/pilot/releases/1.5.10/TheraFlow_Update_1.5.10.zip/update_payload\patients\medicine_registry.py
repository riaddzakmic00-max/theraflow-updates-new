"""Canonical therapy and physical-product registry queries.

``TerapijskiProgram`` is the selectable clinical therapy; ``Lijek`` remains the
physical product/SKU used by stock, dispensing and therapy records.
"""

from django.db.models import Count, F, Q
from django.db.models.functions import Coalesce

from .models import Lijek, Pacijent, TerapijskaFaza, TerapijskiProgram


def ensure_program_for_product(product):
    """Link a newly added/legacy SKU to its canonical therapy exactly once."""

    if not product or not product.pk:
        return None
    if product.terapijski_program_id:
        return product.terapijski_program
    from .medication_groups import medicine_group_label

    key = product.therapeutic_group_key[:80]
    label = medicine_group_label(product)[:120]
    program, _ = TerapijskiProgram.objects.get_or_create(
        kljuc=key,
        defaults={
            "naziv": label,
            "aktivan": product.aktivan,
            # A newly discovered therapy must be explicitly assigned to an
            # administrative program before commission documents are created.
            "commission_program_type": (
                TerapijskiProgram.KomisijskiProgramTip.UNCONFIGURED
            ),
        },
    )
    Lijek.objects.filter(pk=product.pk, terapijski_program__isnull=True).update(
        terapijski_program=program
    )
    product.terapijski_program_id = program.pk
    if product.aktivan and not program.default_lijek_id:
        TerapijskiProgram.objects.filter(
            pk=program.pk,
            default_lijek__isnull=True,
        ).update(default_lijek=product)
        program.default_lijek_id = product.pk
    return program


def active_therapy_programs(*, include_ids=()):
    """Return each selectable therapy exactly once, regardless of SKU count."""

    included = tuple(pk for pk in include_ids if pk)
    selectable = Q(aktivan=True, proizvodi__aktivan=True)
    if included:
        selectable |= Q(pk__in=included)
    return (
        TerapijskiProgram.objects.filter(selectable)
        .select_related("default_lijek")
        .distinct()
        .order_by("naziv", "pk")
    )


def active_patient_therapy_summary():
    """Broj aktivnih pacijenata po canonical terapiji, ne po SKU-u.

    Patient-level program je autoritativan. Veza proizvoda je siguran fallback
    za legacy pacijente nastale prije uvođenja ``terapijski_program`` FK-a.
    """

    rows = (
        Pacijent.objects.filter(aktivan=True, lijek__isnull=False)
        .annotate(
            canonical_program_id=Coalesce(
                F("terapijski_program_id"),
                F("lijek__terapijski_program_id"),
            ),
            canonical_program_name=Coalesce(
                F("terapijski_program__naziv"),
                F("lijek__terapijski_program__naziv"),
            ),
        )
        .exclude(canonical_program_id__isnull=True)
        .values("canonical_program_id", "canonical_program_name")
        .annotate(broj_pacijenata=Count("pk"))
        .order_by("canonical_program_name", "canonical_program_id")
    )
    return tuple({
        "program_id": row["canonical_program_id"],
        "naziv": row["canonical_program_name"],
        "broj_pacijenata": row["broj_pacijenata"],
    } for row in rows)


def active_therapy_medicines(*, include_ids=()):
    """Return medicines available for a new selection.

    ``include_ids`` is intentionally limited to edit forms: an inactive medicine
    already referenced by a legacy row remains renderable, but it is not offered
    for any new patient, migration, switch or commission item.
    """

    included = tuple(pk for pk in include_ids if pk)
    selectable = Q(aktivan=True)
    if included:
        selectable |= Q(pk__in=included)
    return Lijek.objects.filter(selectable).distinct().order_by("naziv", "pk")


def active_products_for_program(program, *, include_ids=()):
    if not program:
        return Lijek.objects.none()
    included = tuple(pk for pk in include_ids if pk)
    selectable = Q(aktivan=True, terapijski_program=program)
    if included:
        selectable |= Q(pk__in=included, terapijski_program=program)
    return Lijek.objects.filter(selectable).distinct().order_by(
        "put_primjene", "jacina_mg", "naziv", "pk"
    )


def default_product_for_program(program, *, phase=None):
    """Resolve the current SKU without duplicating product rules in forms/views."""

    if not program:
        return None
    if phase:
        if phase.program_id != program.pk:
            return None
        return phase.lijek
    if program.default_lijek_id and program.default_lijek.aktivan:
        return program.default_lijek
    return active_products_for_program(program).first()


def initial_phase_for_program(program):
    if not program:
        return None
    return (
        TerapijskaFaza.objects.filter(program=program, aktivna=True)
        .select_related("lijek", "program")
        .order_by("redoslijed", "pk")
        .first()
    )


def uses_specialized_protocol_engine(selection):
    """Whether a therapy is configured outside the legacy interval protocol."""

    if not selection:
        return False
    if isinstance(selection, TerapijskiProgram):
        if selection.protokol_kljuc:
            return True
        product = default_product_for_program(selection)
        return bool(product and product.oralna_terapija)
    program = getattr(selection, "terapijski_program", None)
    return bool(
        (program and program.protokol_kljuc)
        or getattr(selection, "oralna_terapija", False)
    )
