from django.db import migrations, models


def popuni_pdf_postavke(apps, schema_editor):
    PostavkeSistema = apps.get_model("patients", "PostavkeSistema")
    postavke, _ = PostavkeSistema.objects.get_or_create(id=1)
    if not postavke.zdravstvena_ustanova:
        postavke.zdravstvena_ustanova = "JU Opća bolnica prim.dr. Abdulah Nakaš"
    if not postavke.podnosilac_zahtjeva:
        postavke.podnosilac_zahtjeva = "Mr. Sc. Nijaz Tucaković"
    postavke.save()


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0024_lijek_genericki_zasticeno"),
    ]

    operations = [
        migrations.AddField(
            model_name="postavkesistema",
            name="zdravstvena_ustanova",
            field=models.CharField(blank=True, max_length=200),
        ),
        migrations.AddField(
            model_name="postavkesistema",
            name="podnosilac_zahtjeva",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.RunPython(popuni_pdf_postavke, migrations.RunPython.noop),
    ]
