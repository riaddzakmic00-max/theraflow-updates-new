"""Jedinstvena identifikacija terapijske grupe lijeka.

Poslovni zapisi i dalje zadrzavaju konkretan ``Lijek`` (brand/proizvod), dok se
brojanje, grupisanje i citanje povezanog workflowa mogu raditi na nivou
generickog lijeka. Ovo je posebno vazno za biosimilare adalimumaba.
"""

from dataclasses import dataclass
import re
import unicodedata
from decimal import Decimal, InvalidOperation

from django.db.models import Q


@dataclass(frozen=True)
class TherapeuticGroup:
    key: str
    label: str
    css_class: str
    aliases: tuple[str, ...]


THERAPEUTIC_GROUPS = (
    TherapeuticGroup(
        "adalimumab",
        "Adalimumab",
        "lijek-adalimumab",
        ("adalimumab", "hyrimoz", "humira", "amgevita", "imraldi", "yuflyma"),
    ),
    TherapeuticGroup(
        "vedolizumab",
        "Vedolizumab",
        "lijek-entyvio",
        ("vedolizumab", "entyvio"),
    ),
    TherapeuticGroup(
        "infliximab",
        "Infliximab",
        "lijek-remsima",
        ("infliximab", "infliksimab", "remsima", "remicade", "inflectra", "flixabi", "zessly"),
    ),
    TherapeuticGroup(
        "ustekinumab",
        "Ustekinumab",
        "lijek-yesintek",
        ("ustekinumab", "yesintek", "stelara", "uzpruvo", "upruva"),
    ),
    TherapeuticGroup(
        "risankizumab",
        "Risankizumab",
        "lijek-skyrizi",
        ("risankizumab", "skyrizi"),
    ),
)

_GROUP_BY_KEY = {group.key: group for group in THERAPEUTIC_GROUPS}

THERAPY_GROUP_ENTYVIO = "ENTYVIO"
THERAPY_GROUP_REMSIMA = "REMSIMA"
THERAPY_GROUP_ADALIMUMAB = "ADALIMUMAB"
THERAPY_GROUP_OSTALI = "OSTALI"

THERAPY_GROUP_LABELS = {
    THERAPY_GROUP_ENTYVIO: "Entyvio",
    THERAPY_GROUP_REMSIMA: "Remsima",
    THERAPY_GROUP_ADALIMUMAB: "Adalimumab",
    THERAPY_GROUP_OSTALI: "Ostali",
}

THERAPY_MAINTENANCE_INTERVAL_WEEKS = {
    THERAPY_GROUP_ADALIMUMAB: 2,
}

_MEDICINE_KEY_TO_THERAPY_GROUP = {
    "vedolizumab": THERAPY_GROUP_ENTYVIO,
    "infliximab": THERAPY_GROUP_REMSIMA,
    "adalimumab": THERAPY_GROUP_ADALIMUMAB,
}

_THERAPY_GROUP_TO_MEDICINE_KEY = {
    value: key for key, value in _MEDICINE_KEY_TO_THERAPY_GROUP.items()
}


def normalize_medicine_name(value):
    value = unicodedata.normalize("NFKD", str(value or ""))
    value = "".join(character for character in value if not unicodedata.combining(character))
    return re.sub(r"[^a-z0-9]+", " ", value.casefold()).strip()


def _known_group(value):
    normalized = normalize_medicine_name(value)
    if not normalized:
        return None
    for group in THERAPEUTIC_GROUPS:
        if any(alias == normalized or alias in normalized.split() for alias in group.aliases):
            return group
    return None


def medicine_group(lijek):
    if not lijek:
        return None

    # Genericki naziv je autoritativan. Alias komercijalnog naziva je fallback za
    # starije zapise kod kojih genericki_naziv jos nije popunjen.
    group = _known_group(getattr(lijek, "genericki_naziv", ""))
    if group:
        return group
    for value in (getattr(lijek, "naziv", ""), getattr(lijek, "zasticeno_ime", "")):
        group = _known_group(value)
        if group:
            return group

    generic = (
        getattr(lijek, "genericki_naziv", "")
        or getattr(lijek, "naziv", "")
        or getattr(lijek, "zasticeno_ime", "")
    )
    key = normalize_medicine_name(generic).replace(" ", "-") or f"lijek-{getattr(lijek, 'pk', 'unknown')}"
    label = str(generic).strip() or "Ostali"
    return TherapeuticGroup(key, label, "lijek-ostalo", (normalize_medicine_name(generic),))


def medicine_group_key(lijek):
    group = medicine_group(lijek)
    return group.key if group else "bez-lijeka"


def get_therapy_group(lijek):
    """Vrati stabilnu UI/izvjestajnu grupu za konkretan Lijek zapis."""
    return _MEDICINE_KEY_TO_THERAPY_GROUP.get(
        medicine_group_key(lijek),
        THERAPY_GROUP_OSTALI,
    )


def maintenance_interval_weeks(lijek, fallback=None):
    """Vrati obavezni interval odrzavanja za poznatu terapijsku grupu."""
    return THERAPY_MAINTENANCE_INTERVAL_WEEKS.get(
        get_therapy_group(lijek),
        fallback,
    )


def therapy_group_bucket_key(lijek):
    """Poznate terapije grupisi stabilno, a nepovezane 'ostale' lijekove ne spajaj."""
    if medicine_group_key(lijek) == "ustekinumab":
        return medicine_presentation_key(lijek)
    therapy_group = get_therapy_group(lijek)
    if therapy_group != THERAPY_GROUP_OSTALI:
        return therapy_group
    return f"{THERAPY_GROUP_OSTALI}:{medicine_group_key(lijek)}"


def therapy_group_label(lijek_or_group):
    group = (
        lijek_or_group
        if isinstance(lijek_or_group, str) and lijek_or_group in THERAPY_GROUP_LABELS
        else get_therapy_group(lijek_or_group)
    )
    return THERAPY_GROUP_LABELS[group]


def therapy_group_q(therapy_group, prefix=""):
    medicine_key = _THERAPY_GROUP_TO_MEDICINE_KEY.get(str(therapy_group or "").upper())
    if not medicine_key:
        return Q(pk__isnull=True)
    return medicine_group_q(medicine_key, prefix=prefix)


def medicine_group_label(lijek):
    group = medicine_group(lijek)
    return group.label if group else "Bez lijeka"


def medicine_group_css(lijek):
    group = medicine_group(lijek)
    return group.css_class if group else "lijek-ostalo"


def medicine_group_q(lijek_or_key, prefix=""):
    """Q izraz za sve Lijek zapise koji pripadaju istoj terapijskoj grupi."""
    if isinstance(lijek_or_key, str):
        group = _GROUP_BY_KEY.get(lijek_or_key)
        if group is None:
            normalized = normalize_medicine_name(lijek_or_key)
            group = _known_group(normalized)
            if group is None:
                group = TherapeuticGroup(
                    normalized.replace(" ", "-"),
                    lijek_or_key,
                    "lijek-ostalo",
                    (normalized,),
                )
    else:
        group = medicine_group(lijek_or_key)

    if group is None:
        return Q(pk__isnull=True)

    field_prefix = f"{prefix}__" if prefix else ""
    query = Q()
    for alias in tuple(alias for alias in group.aliases if alias):
        query |= Q(**{f"{field_prefix}genericki_naziv__icontains": alias})
        query |= Q(**{f"{field_prefix}naziv__icontains": alias})
        query |= Q(**{f"{field_prefix}zasticeno_ime__icontains": alias})
    return query


def equivalent_medicine_ids(lijek):
    if not lijek:
        return []
    from .models import Lijek
    from .request_cache import get_or_set

    group_key = medicine_group_key(lijek)
    return get_or_set(
        "equivalent_medicine_ids",
        group_key,
        lambda: list(
            Lijek.objects.filter(medicine_group_q(lijek)).values_list("id", flat=True)
        ),
    )


def medicine_presentation_key(lijek):
    """Fizički identitet prezentacije; klinička grupa ostaje generička."""

    if not lijek:
        return "bez-lijeka"
    group_key = medicine_group_key(lijek)
    if group_key != "ustekinumab":
        return group_key

    identity = normalize_medicine_name(
        " ".join(
            str(value or "")
            for value in (
                getattr(lijek, "genericki_naziv", ""),
                getattr(lijek, "naziv", ""),
                getattr(lijek, "zasticeno_ime", ""),
            )
        )
    )
    strength = getattr(lijek, "jacina_mg", None)
    if strength is None:
        match = re.search(r"\b(90|130)(?:[.,]0+)?\s*mg\b", identity)
        strength = match.group(1) if match else None
    route = (getattr(lijek, "put_primjene", "") or "").upper()
    if not route:
        if str(strength or "").split(".")[0] == "130":
            route = "IV"
        elif str(strength or "").split(".")[0] == "90":
            route = "SC"
    try:
        strength_decimal = Decimal(str(strength))
        strength_text = format(strength_decimal.normalize(), "f")
    except (InvalidOperation, TypeError, ValueError):
        strength_text = "nepoznata"
    return f"ustekinumab:{route or 'NEPOZNAT'}:{strength_text}"


def strict_equivalent_medicine_ids(lijek):
    """Ekvivalenti fizičke zalihe bez miješanja različitih prezentacija."""
    if not lijek:
        return []
    from .models import Lijek
    from .request_cache import get_or_set

    presentation_key = medicine_presentation_key(lijek)
    return get_or_set(
        "strict_equivalent_medicine_ids",
        presentation_key,
        lambda: [
            candidate.pk
            for candidate in Lijek.objects.filter(medicine_group_q(lijek)).only(
                "id",
                "naziv",
                "genericki_naziv",
                "zasticeno_ime",
                "jacina_mg",
                "put_primjene",
            )
            if medicine_presentation_key(candidate) == presentation_key
        ],
    )
