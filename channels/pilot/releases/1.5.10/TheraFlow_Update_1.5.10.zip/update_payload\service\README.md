# TheraFlow Windows Service

Ovaj folder sadrzi NSSM skripte za pokretanje TheraFlow aplikacije kao pravi Windows servis na Windows 10/11.

Servis koristi:

- NSSM kao Windows Service wrapper
- `.venv\Scripts\python.exe`
- `run_theraflow.py`
- Waitress WSGI server na `http://127.0.0.1:8000/`

Sve putanje su citirane tako da ispravno rade i kada folder sadrži razmake.

## Preduslovi

1. Pokrenuti Command Prompt ili PowerShell kao Administrator.
2. `nssm.exe` mora biti dostupan u `PATH`.
3. Virtualno okruzenje mora postojati u projektu na:

```text
.venv\Scripts\python.exe
```

4. Servisni entry point mora postojati u root folderu projekta:

```text
run_theraflow.py
```

Skripte automatski izracunavaju root folder projekta iz lokacije `service` foldera, zatim NSSM-u upisuju apsolutne putanje.

## Instalacija ili azuriranje servisa

Iz root foldera projekta pokrenuti:

```bat
service\install_service.bat
```

Ako servis `TheraFlow` ne postoji, skripta ga instalira. Ako vec postoji, skripta azurira NSSM konfiguraciju i ponovo ga pokrece.

Nakon instalacije skripta provjerava da li je servis u `SERVICE_RUNNING` stanju.

## Restart servisa

```bat
service\restart_service.bat
```

## Deinstalacija servisa

```bat
service\uninstall_service.bat
```

## Logovi

Servis pise logove u:

```text
logs\service_output.log
logs\service_error.log
```

Ako servis ne udje u `SERVICE_RUNNING` stanje, prvo provjeriti ove logove.

## Otvaranje aplikacije

Kada je servis pokrenut:

```text
http://127.0.0.1:8000/
```
