"""PostgreSQL integration-test settings.

`DB_TEST_NAME` may point to an explicitly provisioned disposable database.
Without it Django keeps its normal `test_<database>` behaviour.
"""

from .settings import *  # noqa: F403


_explicit_test_database = env("DB_TEST_NAME", "").strip()  # noqa: F405
if _explicit_test_database:
    DATABASES["default"]["TEST"] = {  # noqa: F405
        "NAME": _explicit_test_database,
    }
