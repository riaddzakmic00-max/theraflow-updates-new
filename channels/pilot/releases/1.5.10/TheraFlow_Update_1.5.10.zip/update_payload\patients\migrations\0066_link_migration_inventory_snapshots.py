from django.db import migrations, models
from django.db.models import Max
import django.db.models.deletion


def link_existing_migration_inventory(apps, schema_editor):
    InitialStock = apps.get_model(
        "patients", "MigracijskoPocetnoStanjeZalihe"
    )
    PatientSnapshot = apps.get_model(
        "patients", "MigracijskiSnapshotPacijenta"
    )
    Reservation = apps.get_model("patients", "PacijentRezervacija")
    Stock = apps.get_model("patients", "Zaliha")
    StockTransaction = apps.get_model("patients", "ZalihaTransakcija")

    medicine_ids = (
        PatientSnapshot.objects.order_by()
        .values_list("lijek_id", flat=True)
        .distinct()
    )
    for medicine_id in medicine_ids:
        stock = Stock.objects.filter(lijek_id=medicine_id).first()
        physical_quantity = stock.u_frizideru if stock is not None else 0
        checkpoint = (
            StockTransaction.objects.filter(lijek_id=medicine_id)
            .aggregate(last_id=Max("id"))["last_id"]
        )
        initial_stock, created = InitialStock.objects.get_or_create(
            lijek_id=medicine_id,
            defaults={
                "kolicina": physical_quantity,
                "ledger_checkpoint_id": checkpoint,
            },
        )
        if not created and initial_stock.ledger_checkpoint_id is None:
            initial_stock.ledger_checkpoint_id = checkpoint
            initial_stock.save(update_fields=["ledger_checkpoint_id"])

        reservations = Reservation.objects.filter(
            lijek_id=medicine_id,
            aktivno=True,
            kolicina__gt=0,
            pacijent_id__in=PatientSnapshot.objects.filter(
                lijek_id=medicine_id
            ).values("pacijent_id"),
        ).order_by("id")
        for reservation in reservations:
            update_fields = []
            if reservation.migracijsko_pocetno_stanje_id is None:
                reservation.migracijsko_pocetno_stanje_id = initial_stock.id
                update_fields.append("migracijsko_pocetno_stanje")

            if reservation.migracijski_snapshot_id is None:
                snapshot = PatientSnapshot.objects.filter(
                    pacijent_id=reservation.pacijent_id,
                    lijek_id=medicine_id,
                ).first()
                if (
                    snapshot is not None
                    and not Reservation.objects.filter(
                        migracijski_snapshot_id=snapshot.id
                    ).exclude(pk=reservation.pk).exists()
                ):
                    reservation.migracijski_snapshot_id = snapshot.id
                    update_fields.append("migracijski_snapshot")

            if update_fields:
                reservation.save(update_fields=update_fields)


def unlink_migration_inventory(apps, schema_editor):
    Reservation = apps.get_model("patients", "PacijentRezervacija")
    Reservation.objects.update(migracijsko_pocetno_stanje=None)


class Migration(migrations.Migration):
    # PostgreSQL mora potvrditi FK kolonu i njen deferred indeks prije nego
    # RunPython ažurira iste redove; inače ostaju pending trigger events.
    atomic = False

    dependencies = [
        ("patients", "0065_migration_inventory_reconciliation"),
    ]

    operations = [
        migrations.AddField(
            model_name="migracijskopocetnostanjezalihe",
            name="ledger_checkpoint_id",
            field=models.PositiveIntegerField(
                blank=True,
                help_text=(
                    "Posljednja transakcija obuhvaćena potvrđenim početnim stanjem."
                ),
                null=True,
            ),
        ),
        migrations.AddField(
            model_name="pacijentrezervacija",
            name="migracijsko_pocetno_stanje",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="rezervacije_pacijenata",
                to="patients.migracijskopocetnostanjezalihe",
            ),
        ),
        migrations.RunPython(
            link_existing_migration_inventory,
            unlink_migration_inventory,
        ),
    ]
