import json
import logging
import re
import socket
from datetime import date
from urllib import error, request
from urllib.parse import urlparse

from django.conf import settings
from django.core.cache import cache
from packaging.version import InvalidVersion

from theraflow.version import __version__, parse_version, validate_version_identifier
from updates.updater.state_writer import trace_update_step


logger = logging.getLogger(__name__)
CACHE_KEY = "theraflow:update-check:v1"
SUCCESS_TTL = 30 * 60
ERROR_TTL = 5 * 60
SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")
REQUIRED_FIELDS = {
    "version", "release_date", "mandatory", "download_url", "sha256",
    "min_supported_version", "release_notes",
}


class ManifestValidationError(ValueError):
    pass


def validate_manifest(payload):
    if not isinstance(payload, dict):
        raise ManifestValidationError("Manifest mora biti JSON objekat.")
    missing = REQUIRED_FIELDS - payload.keys()
    if missing:
        raise ManifestValidationError("Manifest nema sva obavezna polja.")
    try:
        validate_version_identifier(payload["version"])
        validate_version_identifier(payload["min_supported_version"])
    except InvalidVersion as exc:
        raise ManifestValidationError("Verzija u manifestu nije ispravna.") from exc
    try:
        date.fromisoformat(str(payload["release_date"]))
    except ValueError as exc:
        raise ManifestValidationError("Datum izdanja nije ispravan.") from exc
    if type(payload["mandatory"]) is not bool:
        raise ManifestValidationError("Polje mandatory mora biti boolean.")
    if urlparse(str(payload["download_url"])).scheme.lower() != "https":
        raise ManifestValidationError("Download URL mora koristiti HTTPS.")
    if not SHA256_RE.fullmatch(str(payload["sha256"])):
        raise ManifestValidationError("SHA-256 mora imati 64 heksadecimalna znaka.")
    notes = payload["release_notes"]
    if not isinstance(notes, list) or any(not isinstance(note, str) for note in notes):
        raise ManifestValidationError("Release notes moraju biti lista tekstova.")
    return {
        "version": str(payload["version"]),
        "release_date": str(payload["release_date"]),
        "mandatory": payload["mandatory"],
        "download_url": str(payload["download_url"]),
        "sha256": str(payload["sha256"]).lower(),
        "min_supported_version": str(payload["min_supported_version"]),
        "release_notes": notes,
    }


def _result(status, message, manifest=None):
    data = {
        "status": status,
        "version": manifest["version"] if manifest else None,
        "current_version": __version__,
        "latest_version": manifest["version"] if manifest else None,
        "release_date": manifest["release_date"] if manifest else None,
        "mandatory": manifest["mandatory"] if manifest else False,
        "release_notes": manifest["release_notes"] if manifest else [],
        "download_url": manifest["download_url"] if manifest else None,
        "sha256": manifest["sha256"] if manifest else None,
        "min_supported_version": manifest["min_supported_version"] if manifest else None,
        "message": message,
    }
    return data


def check_for_updates(*, force=False, manifest_url=None, current_version=None):
    manifest_url = manifest_url or getattr(settings, "THERAFLOW_UPDATE_MANIFEST_URL", "")
    current_version = current_version or __version__
    if not manifest_url:
        exc = ManifestValidationError("URL manifesta za ažuriranje nije konfigurisan.")
        trace_update_step(1, "FAIL", function_name="check_for_updates", exception=exc, exit_code=1)
        result = _result("not_configured", "URL manifesta za ažuriranje nije konfigurisan.")
        result["current_version"] = str(current_version)
        return result
    if not force:
        cached = cache.get(CACHE_KEY)
        if cached:
            trace_update_step(1, "PASS", function_name="check_for_updates", message="Manifest loaded from cache", paths={"manifest_url": manifest_url}, exit_code=0)
            trace_update_step(2, "PASS", function_name="check_for_updates", message=f"cached result={cached.get('status')}", exit_code=0)
            return cached
    logger.info("Početak provjere TheraFlow ažuriranja.")
    active_step = 1
    trace_update_step(1, "START", function_name="check_for_updates", paths={"manifest_url": manifest_url})
    try:
        req = request.Request(manifest_url, headers={"Accept": "application/json"})
        with request.urlopen(req, timeout=5) as response:
            if getattr(response, "status", 200) != 200:
                raise error.HTTPError(manifest_url, response.status, "HTTP greška", response.headers, None)
            payload = json.loads(response.read().decode("utf-8"))
        manifest = validate_manifest(payload)
        trace_update_step(1, "PASS", function_name="check_for_updates", paths={"manifest_url": manifest_url}, exit_code=0)
        active_step = 2
        trace_update_step(2, "START", function_name="check_for_updates")
        installed = parse_version(current_version)
        latest = parse_version(manifest["version"])
        minimum = parse_version(manifest["min_supported_version"])
        if installed < minimum:
            result = _result("unsupported_version", "Instalirana verzija je ispod minimalno podržane verzije.", manifest)
        elif latest > installed:
            result = _result("update_available", "Dostupna je nova verzija.", manifest)
        else:
            result = _result("up_to_date", "Sistem je ažuriran.", manifest)
        result["current_version"] = str(current_version)
        trace_update_step(
            2,
            "PASS",
            function_name="check_for_updates",
            message=f"current={current_version} target={manifest['version']} result={result['status']}",
            exit_code=0,
        )
        cache.set(CACHE_KEY, result, SUCCESS_TTL)
        logger.info("Provjera ažuriranja završena: %s.", result["status"])
        return result
    except ManifestValidationError as exc:
        trace_update_step(active_step, "FAIL", function_name="check_for_updates", paths={"manifest_url": manifest_url}, exception=exc, exit_code=1)
        result = _result("invalid_manifest", str(exc))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        trace_update_step(active_step, "FAIL", function_name="check_for_updates", paths={"manifest_url": manifest_url}, exception=exc, exit_code=1)
        result = _result("invalid_json", "Server je odgovorio, ali manifest nije validan JSON dokument.")
    except error.HTTPError as exc:
        trace_update_step(active_step, "FAIL", function_name="check_for_updates", paths={"manifest_url": manifest_url}, exception=exc, exit_code=1)
        if exc.code == 404:
            result = _result("manifest_not_found", "Manifest nije pronađen na serveru (HTTP 404). Provjerite branch i putanju update kanala.")
        elif exc.code == 403:
            result = _result("manifest_forbidden", "Pristup manifestu je odbijen (HTTP 403). Manifest mora biti javno dostupan bez prijave.")
        else:
            result = _result("manifest_http_error", f"Server manifesta vratio je HTTP {exc.code}.")
    except (TimeoutError, socket.timeout) as exc:
        trace_update_step(active_step, "FAIL", function_name="check_for_updates", paths={"manifest_url": manifest_url}, exception=exc, exit_code=1)
        result = _result("manifest_timeout", "Isteklo je vrijeme čekanja na server manifesta.")
    except error.URLError as exc:
        trace_update_step(active_step, "FAIL", function_name="check_for_updates", paths={"manifest_url": manifest_url}, exception=exc, exit_code=1)
        if isinstance(exc.reason, (TimeoutError, socket.timeout)):
            result = _result("manifest_timeout", "Isteklo je vrijeme čekanja na server manifesta.")
        else:
            result = _result("network_error", "Server manifesta nije dostupan zbog mrežne ili DNS greške.")
    except (InvalidVersion, ValueError) as exc:
        trace_update_step(active_step, "FAIL", function_name="check_for_updates", paths={"manifest_url": manifest_url}, exception=exc, exit_code=1)
        result = _result("invalid_manifest", str(exc))
    except Exception as exc:
        trace_update_step(active_step, "FAIL", function_name="check_for_updates", paths={"manifest_url": manifest_url}, exception=exc, exit_code=1)
        logger.exception("Neočekivana greška pri provjeri ažuriranja.")
        result = _result("error", "Provjera ažuriranja nije uspjela.")
    result["current_version"] = str(current_version)
    cache.set(CACHE_KEY, result, ERROR_TTL)
    logger.warning("Provjera ažuriranja završena greškom: %s.", result["status"])
    return result
