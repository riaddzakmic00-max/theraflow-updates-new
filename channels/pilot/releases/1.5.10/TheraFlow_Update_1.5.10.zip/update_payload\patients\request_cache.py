from contextvars import ContextVar


_request_cache = ContextVar("theraflow_request_computation_cache", default=None)
_MISSING = object()


def begin_request_cache(*, enabled=True):
    """Pokreni izolovani cache samo za trajanje jednog read-only requesta."""
    return _request_cache.set({} if enabled else None)


def end_request_cache(token):
    _request_cache.reset(token)


def get_or_set(namespace, key, factory):
    cache = _request_cache.get()
    if cache is None:
        return factory()
    cache_key = (namespace, key)
    value = cache.get(cache_key, _MISSING)
    if value is _MISSING:
        value = factory()
        cache[cache_key] = value
    return value


def set_cached(namespace, key, value):
    cache = _request_cache.get()
    if cache is not None:
        cache[(namespace, key)] = value
