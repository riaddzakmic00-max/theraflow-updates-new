import json

from django.core.management.base import BaseCommand, CommandError

from patients.schema_gate import ADMIN_SCHEMA_MESSAGE, run_schema_gate


class Command(BaseCommand):
    help = "Provjeri migration graph/history i fizičku shemu svih managed modela."

    def add_arguments(self, parser):
        parser.add_argument("--database", default="default")
        parser.add_argument("--json", action="store_true", dest="as_json")
        parser.add_argument(
            "--full",
            action="store_true",
            help="Ispiši MODEL/TABLE zapis i za tabele bez odstupanja.",
        )

    def handle(self, *args, **options):
        result = run_schema_gate(using=options["database"])
        if options["as_json"]:
            self.stdout.write(
                json.dumps(result.as_dict(), indent=2, sort_keys=True, ensure_ascii=False)
            )
        else:
            reports = result.model_reports if options["full"] else result.issue_reports
            for report in reports:
                self.stdout.write(f"MODEL: {report.model}")
                self.stdout.write(f"TABLE: {report.table}")
                self.stdout.write(
                    "MISSING_COLUMNS: " + (", ".join(report.missing_columns) or "-")
                )
                self.stdout.write(
                    "UNEXPECTED_COLUMNS: "
                    + (", ".join(report.unexpected_columns) or "-")
                )
                if report.nullable_mismatches:
                    self.stdout.write(
                        "NULLABILITY: " + " | ".join(report.nullable_mismatches)
                    )
                if report.foreign_key_mismatches:
                    self.stdout.write(
                        "FOREIGN_KEYS: " + " | ".join(report.foreign_key_mismatches)
                    )
                if report.constraint_mismatches:
                    self.stdout.write(
                        "CONSTRAINTS: " + " | ".join(report.constraint_mismatches)
                    )
                if report.index_mismatches:
                    self.stdout.write("INDEXES: " + " | ".join(report.index_mismatches))

            migration_status = (
                "CLEAN"
                if not result.pending_migrations
                else "PENDING: " + ", ".join(result.pending_migrations)
            )
            self.stdout.write(f"MIGRATION STATE: {migration_status}")
            model_state = (
                "CLEAN"
                if not result.model_state_changes
                else "UNMIGRATED: " + ", ".join(result.model_state_changes)
            )
            self.stdout.write(f"MODEL/MIGRATION STATE: {model_state}")
            self.stdout.write(
                f"MANAGED TABLES AUDITED: {len(result.model_reports)}"
            )
            self.stdout.write(
                "SCHEMA STATE: " + ("CLEAN" if not result.issue_reports else "DRIFT")
            )
            if result.migration_conflicts:
                self.stdout.write(
                    "MIGRATION CONFLICTS: " + " | ".join(result.migration_conflicts)
                )
            if result.history_without_files:
                self.stdout.write(
                    "HISTORY WITHOUT FILES: "
                    + " | ".join(result.history_without_files)
                )
            if result.error:
                self.stdout.write("GATE ERROR: " + result.error)

        if not result.clean:
            raise CommandError(ADMIN_SCHEMA_MESSAGE)
        self.stdout.write(self.style.SUCCESS("SCHEMA GATE: PASS"))
