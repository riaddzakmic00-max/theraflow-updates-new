import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

from .file_installer import _atomic_copy, _target
from .plan_loader import PlanValidationError, safe_relative, sha256_file


class SnapshotRestoreError(RuntimeError):
    pass


def _json(path, label):
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError) as exc:
        raise SnapshotRestoreError(f"{label} nije validan.") from exc
    if not isinstance(value, dict):
        raise SnapshotRestoreError(f"{label} nije validan.")
    return value


def validate_snapshot(plan):
    backup = Path(plan["backup_root"]).resolve()
    snapshot = backup / "application_snapshot"
    manifest_path = backup / "application_snapshot_manifest.json"
    if not snapshot.is_dir() or snapshot.is_symlink():
        raise SnapshotRestoreError("Application snapshot nije dostupan.")
    manifest = _json(manifest_path, "Snapshot manifest")
    if manifest.get("session_id") != plan["session_id"] or manifest.get("source_version") != plan["current_version"]:
        raise SnapshotRestoreError("Snapshot ne pripada ovom update sessionu i verziji.")
    entries = manifest.get("files")
    if not isinstance(entries, list):
        raise SnapshotRestoreError("Snapshot manifest nema listu fajlova.")
    validated = []
    seen = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise SnapshotRestoreError("Snapshot zapis nije validan.")
        original = str(safe_relative(entry.get("original_path"), "snapshot original putanja"))
        stored = str(safe_relative(entry.get("snapshot_path"), "snapshot backup putanja"))
        if original in seen:
            raise SnapshotRestoreError("Snapshot sadrži duplu putanju.")
        seen.add(original)
        source = (snapshot / Path(*PurePosixPath(stored).parts)).resolve()
        if snapshot not in source.parents or not source.is_file() or source.is_symlink():
            raise SnapshotRestoreError("Snapshot fajl nije siguran.")
        if sha256_file(source) != entry.get("sha256") or source.stat().st_size != entry.get("size_bytes"):
            raise SnapshotRestoreError("Snapshot hash validacija nije uspjela.")
        _target(plan["application_root"], original, "Rollback cilj")
        validated.append((original, source))
    return manifest, validated


def _payload_files(plan):
    payload = Path(plan["payload_root"]).resolve()
    if not payload.is_dir() or payload.is_symlink():
        raise SnapshotRestoreError("Update payload nije dostupan za rollback provjeru.")
    return [path.relative_to(payload).as_posix() for path in payload.rglob("*") if path.is_file()]


def restore_snapshot(plan):
    manifest, entries = validate_snapshot(plan)
    app = Path(plan["application_root"]).resolve()
    preserved = {PurePosixPath(item).parts[0] for item in plan["preserve_paths"]}
    snapshot_paths = {relative for relative, _source in entries}
    restored, removed, quarantined = [], [], []
    try:
        for relative, source in entries:
            if PurePosixPath(relative).parts[0] in preserved:
                continue
            target = _target(app, relative, "Rollback cilj")
            _atomic_copy(source, target)
            if sha256_file(target) != sha256_file(source):
                raise SnapshotRestoreError("Vraćeni fajl nije prošao hash provjeru.")
            restored.append(relative)

        # Uklanjaju se samo fajlovi koje je validirani payload dokazano dodao.
        for relative in _payload_files(plan):
            if relative in snapshot_paths or PurePosixPath(relative).parts[0] in preserved:
                continue
            target = _target(app, relative, "Novi update fajl")
            if target.is_file() and not target.is_symlink():
                target.unlink()
                removed.append(relative)

        quarantine_root = Path(plan["backup_root"]).resolve() / "quarantine"
        quarantine_manifest = quarantine_root / "quarantine_manifest.json"
        if quarantine_manifest.is_file():
            for entry in _json(quarantine_manifest, "Quarantine manifest").get("files", []):
                original = str(safe_relative(entry.get("original_path"), "quarantine original putanja"))
                stored = str(safe_relative(entry.get("quarantine_path"), "quarantine backup putanja"))
                source = (quarantine_root / Path(*PurePosixPath(stored).parts)).resolve()
                if quarantine_root not in source.parents or not source.exists() or source.is_symlink():
                    raise SnapshotRestoreError("Quarantine sadržaj nije siguran.")
                target = _target(app, original, "Quarantine restore cilj")
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    raise SnapshotRestoreError("Quarantine restore cilj već postoji.")
                shutil.move(str(source), str(target))
                quarantined.append(original)
    except (OSError, PlanValidationError) as exc:
        raise SnapshotRestoreError("Vraćanje aplikacijskih fajlova nije uspjelo.") from exc

    report = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "session_id": plan["session_id"],
        "files_restored": restored,
        "update_added_files_removed": removed,
        "quarantine_restored": quarantined,
    }
    destination = Path(plan["backup_root"]) / "rollback_file_report.json"
    temporary = destination.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, destination)
    return report
