"""Siguran, relativno datiran i idempotentan TheraFlow demo dataset.

Naziv modula je zadržan zbog postojećih admin ruta i lokalnih skripti. Nova
specifikacija je dataset od 28 aktivnih pacijenata. Kliničke doze, intervali,
prezentacije i pakovanja uvijek se čitaju iz canonical registra aplikacije.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, time, timedelta
from decimal import Decimal
import uuid

from django.db import transaction
from django.db.models import Count, Sum
from django.utils import timezone

from dashboard.commission_phase2 import sync_commission_request_from_planning

from .commission_planning import commission_planning_rows
from .commission_receiving import patient_agreement_suggestion
from .commission_request_types import classify_commission_request
from .demo_reset import delete_demo_dataset
from .integrity import run_database_integrity_check
from .inventory import (
    free_stock_quantity,
    inventory_position,
    release_patient_reservations_to_free_stock,
    reserve_physical_stock,
)
from .medicine_registry import default_product_for_program
from .models import (
    AktivnostLog,
    EvidencijaSaglasnostiZaprimanja,
    FazniProtokolPacijenta,
    IzdavanjeOralneTerapije,
    Komisija,
    KomisijskiCiklus,
    KomisijskiZahtjev,
    KucnoIzdavanje,
    Lijek,
    OralniTerapijskiRezim,
    Pacijent,
    PacijentRezervacija,
    PacijentSaglasnost,
    PacijentZaduzenje,
    PromjenaTerapije,
    StandardniOralniRezim,
    Terapija,
    TerapijskaFaza,
    TerapijskiProgram,
    Termin,
    Trebovanje,
    Zaliha,
    ZalihaTransakcija,
)
from .oral_therapy import confirm_oral_regimen, issue_oral_therapy
from .package_sizes import round_up_to_package
from .phased_protocols import (
    configure_ustekinumab_protocol,
    current_phase_details,
    ensure_phase_reservation,
)
from .scheduling import adjust_to_allowed_therapy_date
from .schema_gate import assert_schema_gate
from .services import confirm_therapy_arrival
from .therapy_workflow import pause_patient_therapy, postpone_therapy


# Fiksni datum postoji isključivo kao eksplicitni test fixture. Produkcijski
# poziv bez parametra koristi timezone.localdate().
DEMO_REFERENCE_DATE = date(2026, 8, 10)
DEMO_V2_MARKER = "[THERAFLOW-DEMO-V2]"
DEMO_V2_CARD_PREFIX = "DEMO-V2-"
DEMO_EDGE_JMBG = "DEMOEDGE00001"


@dataclass(frozen=True)
class DemoScenario:
    key: str
    first_name: str
    last_name: str
    program_key: str
    state: str
    sex: str


_SCENARIO_INPUTS = (
    # 8 Remsima / infliximab
    ("remsima_stable_1", "Amela", "Hadžić", "infliximab", "stable", "Ž"),
    ("remsima_stable_2", "Faris", "Kovač", "infliximab", "stable", "M"),
    ("remsima_stable_3", "Irma", "Delić", "infliximab", "stable", "Ž"),
    ("remsima_stable_4", "Kenan", "Begić", "infliximab", "stable", "M"),
    ("remsima_received", "Ena", "Selimović", "infliximab", "received", "Ž"),
    ("remsima_delivery", "Mirza", "Mehić", "infliximab", "approved_wait", "M"),
    ("remsima_new", "Hana", "Karić", "infliximab", "new", "Ž"),
    ("remsima_paused", "Omer", "Đulić", "infliximab", "paused", "M"),
    # 6 Entyvio / vedolizumab
    ("entyvio_stable_1", "Aida", "Ramić", "vedolizumab", "stable", "Ž"),
    ("entyvio_stable_2", "Vedad", "Latić", "vedolizumab", "stable", "M"),
    ("entyvio_stable_3", "Lamija", "Alić", "vedolizumab", "stable", "Ž"),
    ("entyvio_postponed", "Nermin", "Šabić", "vedolizumab", "postponed", "M"),
    ("entyvio_induction", "Dalila", "Husić", "vedolizumab", "induction", "Ž"),
    ("entyvio_new", "Alen", "Softić", "vedolizumab", "new", "M"),
    # 6 Hyrimoz / adalimumab
    ("hyrimoz_home_1", "Merima", "Čengić", "adalimumab", "home", "Ž"),
    ("hyrimoz_home_2", "Armin", "Zukić", "adalimumab", "home", "M"),
    ("hyrimoz_home_3", "Lejla", "Spahić", "adalimumab", "home", "Ž"),
    ("hyrimoz_home_4", "Denis", "Bašić", "adalimumab", "home", "M"),
    ("hyrimoz_delivery", "Ajla", "Muminović", "adalimumab", "approved_wait", "Ž"),
    ("hyrimoz_switch", "Tarik", "Suljić", "adalimumab", "switch", "M"),
    # 5 Yesintek / ustekinumab
    ("ustek_new_iv", "Naida", "Hrnjić", "ustekinumab", "new_iv", "Ž"),
    ("ustek_delivery_iv", "Ismar", "Hodžić", "ustekinumab", "approved_wait_iv", "M"),
    ("ustek_received_iv", "Dženana", "Bećirović", "ustekinumab", "received_iv", "Ž"),
    ("ustek_sc_training", "Amer", "Pašić", "ustekinumab", "sc_training", "M"),
    ("ustek_home", "Sara", "Kurtović", "ustekinumab", "ustek_home", "Ž"),
    # Oralne terapije
    ("tenofovir_stable_1", "Samir", "Rizvić", "tenofovir-disoproxil", "oral", "M"),
    ("tenofovir_stable_2", "Elma", "Zahirović", "tenofovir-disoproxil", "oral", "Ž"),
    ("xeljanz_stable", "Damir", "Brkić", "tofacitinib", "oral", "M"),
)

DEMO_V2_SCENARIOS = tuple(DemoScenario(*row) for row in _SCENARIO_INPUTS)
DEMO_V2_JMBGS = tuple(f"DEMO{index:09d}" for index in range(1, 29))
DEMO_ALL_JMBGS = DEMO_V2_JMBGS + (DEMO_EDGE_JMBG,)
SCENARIO_KEYS = tuple(item.key for item in DEMO_V2_SCENARIOS)


class DemoDatasetConfigurationError(ValueError):
    pass


class DemoDatasetIntegrityError(ValueError):
    pass


def _decimal(value):
    return Decimal(str(value or 0))


def _demo_patients():
    """Zatvoren tehnički skup; nikada se ne filtrira po imenu osobe."""

    return Pacijent.objects.filter(
        jmbg__in=DEMO_ALL_JMBGS,
        broj_kartona__startswith=DEMO_V2_CARD_PREFIX,
    )


def _active_demo_patients():
    return _demo_patients().filter(jmbg__in=DEMO_V2_JMBGS, aktivan=True)


def existing_demo_v2_patients_count():
    return _active_demo_patients().count()


def _canonical_registry():
    required = {
        "infliximab",
        "vedolizumab",
        "adalimumab",
        "ustekinumab",
        "tenofovir-disoproxil",
        "tofacitinib",
    }
    programs = {
        item.kljuc: item
        for item in TerapijskiProgram.objects.filter(kljuc__in=required)
        .select_related("default_lijek")
        .prefetch_related("proizvodi", "faze__lijek")
    }
    missing = sorted(required - set(programs))
    inactive = sorted(key for key, item in programs.items() if not item.aktivan)
    if missing or inactive:
        details = []
        if missing:
            details.append("nedostaju programi: " + ", ".join(missing))
        if inactive:
            details.append("neaktivni programi: " + ", ".join(inactive))
        raise DemoDatasetConfigurationError(
            "Canonical therapy registry nije spreman (" + "; ".join(details) + ")."
        )

    products = {}
    protocols = {}
    maintenance = {}
    for key in ("infliximab", "vedolizumab", "adalimumab"):
        product = default_product_for_program(programs[key])
        protocol = product.aktivni_protokol() if product else None
        step = protocol.korak_odrzavanja() if protocol else None
        units = _decimal(step.broj_jedinica if step else 0)
        interval = int(
            (step.interval_sedmica if step else None)
            or (protocol.interval_odrzavanja_sedmica if protocol else 0)
            or 0
        )
        if not product or not product.aktivan or not protocol or not step:
            raise DemoDatasetConfigurationError(
                f"Program {key} nema aktivni proizvod, protokol i korak održavanja."
            )
        if units <= 0 or interval <= 0:
            raise DemoDatasetConfigurationError(
                f"Program {key} nema validnu canonical količinu/interval."
            )
        products[key] = product
        protocols[key] = protocol
        maintenance[key] = {"step": step, "units": units, "interval": interval}

    oral_regimens = {}
    for key in ("tenofovir-disoproxil", "tofacitinib"):
        regimen = (
            StandardniOralniRezim.objects.filter(
                lijek__terapijski_program=programs[key],
                lijek__aktivan=True,
                aktivan=True,
            )
            .select_related("lijek")
            .order_by("id")
            .first()
        )
        product = regimen.lijek if regimen else None
        if (
            not product
            or not product.oralna_terapija
            or not regimen
            or _decimal(regimen.tableta_po_uzimanju) <= 0
            or int(regimen.uzimanja_dnevno or 0) <= 0
            or not product.broj_tableta_u_pakovanju
        ):
            raise DemoDatasetConfigurationError(
                f"Program {key} nema potpune podatke o oralnom lijeku, režimu i pakovanju."
            )
        products[key] = product
        oral_regimens[key] = regimen

    phases = {
        item.kljuc: item
        for item in TerapijskaFaza.objects.filter(
            program=programs["ustekinumab"], aktivna=True
        ).select_related("lijek")
    }
    required_phases = {
        FazniProtokolPacijenta.FAZA_CEKA_IV,
        FazniProtokolPacijenta.FAZA_CEKA_PRVU_SC,
        FazniProtokolPacijenta.FAZA_ODRZAVANJE,
    }
    if required_phases - set(phases):
        raise DemoDatasetConfigurationError(
            "Ustekinumab program nema sve canonical IV/SC faze."
        )
    iv = phases[FazniProtokolPacijenta.FAZA_CEKA_IV].lijek
    sc = phases[FazniProtokolPacijenta.FAZA_ODRZAVANJE].lijek
    transition = phases[FazniProtokolPacijenta.FAZA_CEKA_PRVU_SC]
    if (
        iv.put_primjene != Lijek.PUT_IV
        or sc.put_primjene != Lijek.PUT_SC
        or transition.lijek_id != sc.pk
        or iv.terapijski_program_id != sc.terapijski_program_id
    ):
        raise DemoDatasetConfigurationError(
            "Ustekinumab IV i SC prezentacije nisu povezane istim canonical programom."
        )
    products["ustek_iv"] = iv
    products["ustek_sc"] = sc

    hyrimoz = products["adalimumab"]
    if (
        not hyrimoz.kucna_terapija
        or hyrimoz.put_primjene != Lijek.PUT_SC
        or Decimal(str(hyrimoz.effective_package_size)) != Decimal("2")
        or hyrimoz.izdavanje_cijelih_pakovanja
    ):
        raise DemoDatasetConfigurationError(
            "Canonical Hyrimoz prezentacija mora podržavati kućnu SC terapiju, "
            "imati 2 pena u nabavnom pakovanju i dozvoliti izdavanje jednog pena."
        )

    return {
        "programs": programs,
        "products": products,
        "protocols": protocols,
        "maintenance": maintenance,
        "oral_regimens": oral_regimens,
        "phases": phases,
    }


def _safe_date(raw_date, medicine, protocol=None, direction=1):
    return adjust_to_allowed_therapy_date(
        raw_date,
        lijek=medicine,
        protokol=protocol,
        direction=direction,
    ).datum


def _workdays_before(value, count):
    result = value
    remaining = int(count)
    while remaining:
        result -= timedelta(days=1)
        if result.weekday() < 5:
            remaining -= 1
    return result


def _weekday_after(value, weekday, minimum_days):
    result = value + timedelta(days=minimum_days)
    while result.weekday() != weekday:
        result += timedelta(days=1)
    return result


def _weekday_before(value, weekday):
    result = value
    while result.weekday() != weekday:
        result -= timedelta(days=1)
    return result


def _future_slots(reference_date, count):
    """Primarno pon/sri/čet, najviše dvije stavke po datumu."""

    primary = (0, 2, 3)
    overflow = (1, 4)
    rows = []
    cursor = reference_date + timedelta(days=2)
    while len(rows) < count:
        if cursor.weekday() in primary:
            capacity = 2
        elif cursor.weekday() in overflow:
            capacity = 1
        else:
            capacity = 0
        rows.extend([cursor] * min(capacity, count - len(rows)))
        cursor += timedelta(days=1)
    return rows


def _create_patient(index, spec, registry):
    program = registry["programs"][spec.program_key]
    if spec.program_key == "ustekinumab":
        product = registry["products"]["ustek_iv"]
        protocol = None
        phase = Pacijent.FAZA_INDUKCIJA
        quantity = None
        interval = int(
            registry["phases"][FazniProtokolPacijenta.FAZA_ODRZAVANJE]
            .interval_sedmica
            or 8
        )
    elif spec.program_key in registry["oral_regimens"]:
        product = registry["products"][spec.program_key]
        protocol = None
        phase = Pacijent.FAZA_ODRZAVANJE
        quantity = None
        interval = 1
    else:
        product = registry["products"][spec.program_key]
        protocol = registry["protocols"][spec.program_key]
        phase = (
            Pacijent.FAZA_INDUKCIJA
            if spec.state in {
                "induction", "new", "received", "approved_wait", "switch"
            }
            else Pacijent.FAZA_ODRZAVANJE
        )
        quantity = registry["maintenance"][spec.program_key]["units"]
        interval = registry["maintenance"][spec.program_key]["interval"]

    if spec.program_key == "tenofovir-disoproxil":
        diagnosis, code = "Hronični hepatitis B", "B18.1"
    elif index % 2:
        diagnosis, code = "Crohnova bolest", "K50.9"
    else:
        diagnosis, code = "Ulcerozni kolitis", "K51.9"

    patient = Pacijent.objects.create(
        ime=spec.first_name,
        prezime=spec.last_name,
        jmbg=DEMO_V2_JMBGS[index - 1],
        broj_kartona=f"{DEMO_V2_CARD_PREFIX}{index:02d}",
        spol=spec.sex,
        datum_rodenja=date(1966 + index, ((index + 2) % 12) + 1, 8 + (index % 18)),
        adresa=f"Rezervisani demo zapis {index}",
        kanton="Kanton Sarajevo",
        telefon=f"DEMO-TEL-{index:03d}",
        dijagnoza=diagnosis,
        mkb_sifra=code,
        terapijski_program=program,
        lijek=product,
        terapijski_protokol=protocol,
        predlozeni_oralni_rezim=registry["oral_regimens"].get(spec.program_key),
        pocetna_faza_terapije=phase,
        interval_sedmica=interval,
        kolicina_po_terapiji=quantity,
        aktivan=True,
    )
    return patient


def _create_cycles(reference_date):
    previous_date = _weekday_before(reference_date - timedelta(days=62), 3)
    current_date = _weekday_after(reference_date, 3, 17)
    next_date = _weekday_after(current_date, 3, 49)
    previous = KomisijskiCiklus.objects.create(
        naziv=f"DEMO-PRETHODNI-{previous_date:%Y%m%d}",
        mjesec=previous_date.month,
        godina=previous_date.year,
        datum_pripreme=_workdays_before(previous_date, 5),
        rok_pripreme_dokumentacije=_workdays_before(previous_date, 5),
        datum_slanja=_workdays_before(previous_date, 3),
        datum_komisije=previous_date,
        datum_odobrenja=previous_date + timedelta(days=7),
        datum_zaprimanja=previous_date + timedelta(days=20),
        status="ZAPRIMLJENO",
        napomena=f"{DEMO_V2_MARKER} Prethodni završeni ciklus: odobreno, zaprimljeno i raspodijeljeno.",
    )
    current = KomisijskiCiklus.objects.create(
        naziv=f"DEMO-OTVORENI-{current_date:%Y%m%d}",
        mjesec=current_date.month,
        godina=current_date.year,
        datum_pripreme=_workdays_before(current_date, 5),
        rok_pripreme_dokumentacije=_workdays_before(current_date, 5),
        datum_komisije=current_date,
        najraniji_ocekivani_datum_isporuke=current_date + timedelta(days=14),
        najkasniji_ocekivani_datum_isporuke=current_date + timedelta(days=21),
        status="nacrt",
        napomena=f"{DEMO_V2_MARKER} Otvoreni ciklus u pripremi; sastav izvodi centralni planner.",
    )
    upcoming = KomisijskiCiklus.objects.create(
        naziv=f"DEMO-SLJEDECI-{next_date:%Y%m%d}",
        mjesec=next_date.month,
        godina=next_date.year,
        datum_pripreme=_workdays_before(next_date, 5),
        rok_pripreme_dokumentacije=_workdays_before(next_date, 5),
        datum_komisije=next_date,
        najraniji_ocekivani_datum_isporuke=next_date + timedelta(days=14),
        najkasniji_ocekivani_datum_isporuke=next_date + timedelta(days=21),
        status="nacrt",
        napomena=f"{DEMO_V2_MARKER} Sljedeći planirani ciklus bez preuranjenih zahtjeva.",
    )
    return {"previous": previous, "current": current, "next": upcoming}


def _create_agreements(patients, reference_date, user):
    agreements = {}
    changed_indices = {5, 22}
    for index, patient in enumerate(patients, start=1):
        if index in changed_indices:
            PacijentSaglasnost.objects.create(
                pacijent=patient,
                broj_saglasnosti=f"DEMO-2025-{index:04d}",
                vazi_od=reference_date - timedelta(days=460),
                vazi_do=reference_date - timedelta(days=121),
                trenutno_vazeca=False,
                izmijenio=user if getattr(user, "is_authenticated", False) else None,
            )
        agreements[patient.pk] = PacijentSaglasnost.objects.create(
            pacijent=patient,
            broj_saglasnosti=f"DEMO-2026-{index:04d}",
            vazi_od=reference_date - timedelta(days=120),
            trenutno_vazeca=True,
            izmijenio=user if getattr(user, "is_authenticated", False) else None,
        )
    return agreements


def _create_approval(patient, medicine, quantity, sequence, reference_date, agreement):
    quantity = round_up_to_package(_decimal(quantity), medicine)
    return Komisija.objects.create(
        pacijent=patient,
        lijek=medicine,
        datum_odobrenja=reference_date - timedelta(days=55 + (sequence % 9)),
        broj_odobrenih_doza=quantity,
        preostale_doze=quantity,
        status="AKTIVNA",
        broj_saglasnosti=agreement.broj_saglasnosti,
        napomena=f"{DEMO_V2_MARKER} Pacijent-centrično odobrenje.",
    )


def _receive_stock(
    *, patient, medicine, commission, quantity, received_on, user, requisition=None
):
    from .demo_data import _record_demo_delivery

    _record_demo_delivery(
        patient=patient,
        medicine=medicine,
        commission=commission,
        quantity=_decimal(quantity),
        datum=received_on,
        user=user,
    )
    if requisition is not None:
        requisition.zaprimljene_doze = _decimal(quantity)
        requisition.status = "ZAPRIMLJENO"
        requisition.save(update_fields=["zaprimljene_doze", "status"])


def _create_received_requisition(
    *, patient, medicine, commission, quantity, cycle, agreement, user
):
    quantity = _decimal(quantity)
    request = Trebovanje.objects.create(
        pacijent=patient,
        lijek=medicine,
        broj_doza=quantity,
        odobrene_doze=quantity,
        zaprimljene_doze=Decimal("0"),
        status="ODOBRENO",
        komisijski_ciklus=cycle,
        komisija=commission,
        protokol=patient.terapijski_protokol,
        dokumentacija_kompletna=True,
        napomena=f"{DEMO_V2_MARKER} Prethodni ciklus i fizička isporuka za pacijenta.",
    )
    EvidencijaSaglasnostiZaprimanja.objects.create(
        saglasnost=agreement,
        pacijent=patient,
        trebovanje=request,
        komisijski_ciklus=cycle,
        broj_saglasnosti_snapshot=agreement.broj_saglasnosti,
        zaprimljena_kolicina=quantity,
        korisnik=user if getattr(user, "is_authenticated", False) else None,
    )
    return request


def _assign_and_reserve(
    *, patient, medicine, commission, quantity, reference_date, user, termin=None
):
    from dashboard.views import dodijeli_doze_pacijentu

    quantity = _decimal(quantity)
    assignment = dodijeli_doze_pacijentu(
        patient,
        medicine,
        quantity,
        komisija=commission,
        korisnik=user,
    )
    if assignment:
        assignment.datum_zaduzenja = reference_date
        assignment.save(update_fields=["datum_zaduzenja"])
    result = reserve_physical_stock(
        pacijent=patient,
        lijek=medicine,
        quantity=quantity,
        komisija=commission,
        termin=termin,
        priority_date=getattr(termin, "datum", None),
        user=user,
        note=f"{DEMO_V2_MARKER} Fizički dodijeljeno konkretnom pacijentu.",
    )
    if result["allocated"] != quantity or result["waiting"]:
        raise DemoDatasetIntegrityError(
            f"Demo raspodjela nije fizički pokrivena za {patient}: "
            f"traženo {quantity}, alocirano {result['allocated']}."
        )
    return result["reservation"]


def _next_induction_interval(patient):
    try:
        first = patient.terapijski_korak_za_redni_broj(1)
        second = patient.terapijski_korak_za_redni_broj(2)
        first_week = int(first.sedmica_od_pocetka or 0)
        second_week = int(second.sedmica_od_pocetka or 0)
        return max(1, second_week - first_week)
    except Exception:
        return max(1, int(patient.interval_sedmica or 8))


def _create_completed_and_future(
    *, patient, medicine, commission, agreement, cycle, target_date, registry,
    reference_date, user, induction=False, postponed=False, paused=False
):
    program_key = patient.terapijski_program.kljuc
    quantity = registry["maintenance"][program_key]["units"]
    interval = (
        _next_induction_interval(patient)
        if induction
        else registry["maintenance"][program_key]["interval"]
    )
    previous_date = _safe_date(
        target_date - timedelta(weeks=interval),
        medicine,
        patient.aktivni_protokol(),
        direction=-1,
    )
    # Šest fizičkih aplikacija (jedna historijski potrošena + pet budućih)
    # drži stabilnog pacijenta kontinuirano pokrivenim do realnog pouzdanog
    # datuma isporuke centralnog plannera.
    received = quantity * Decimal("6")
    request = _create_received_requisition(
        patient=patient,
        medicine=medicine,
        commission=commission,
        quantity=received,
        cycle=cycle,
        agreement=agreement,
        user=user,
    )
    _receive_stock(
        patient=patient,
        medicine=medicine,
        commission=commission,
        quantity=received,
        received_on=previous_date - timedelta(days=10),
        user=user,
        requisition=request,
    )
    previous = Termin.objects.create(
        pacijent=patient,
        lijek=medicine,
        datum=previous_date,
        vrijeme=time(8 + (patient.pk % 6), 0),
        kolicina_po_terapiji=quantity,
        status=Termin.STATUS_PLANIRANA,
    )
    confirm_therapy_arrival(
        termin=previous,
        primljene_doze=quantity,
        interval_sedmica=interval,
        korisnik=user,
        scheduling_validation_today=reference_date,
    )
    future = (
        Termin.objects.filter(
            pacijent=patient,
            lijek=medicine,
            status=Termin.STATUS_PLANIRANA,
            datum__gt=previous_date,
        )
        .order_by("datum", "id")
        .first()
    )
    if not future:
        raise DemoDatasetIntegrityError(
            f"Canonical workflow nije kreirao naredni termin za {patient}."
        )
    # Očekivani target je ulaz za raspored; canonical engine ostaje konačni
    # source of truth i može pomjeriti datum na dozvoljeni radni dan.
    _assign_and_reserve(
        patient=patient,
        medicine=medicine,
        commission=commission,
        quantity=quantity,
        reference_date=reference_date,
        user=user,
        termin=future,
    )
    _assign_and_reserve(
        patient=patient,
        medicine=medicine,
        commission=commission,
        quantity=quantity * Decimal("4"),
        reference_date=reference_date,
        user=user,
    )

    if postponed:
        postponed_term = postpone_therapy(
            termin=future,
            reason=f"{DEMO_V2_MARKER} Kratka odgoda zbog prolazne infekcije.",
            user=user,
        )
        replacement_date = _safe_date(
            postponed_term.datum + timedelta(days=7),
            medicine,
            patient.aktivni_protokol(),
        )
        replacement = Termin.objects.create(
            pacijent=patient,
            lijek=medicine,
            datum=replacement_date,
            vrijeme=postponed_term.vrijeme,
            kolicina_po_terapiji=quantity,
            status=Termin.STATUS_PLANIRANA,
        )
        reservation = PacijentRezervacija.objects.filter(
            pacijent=patient, termin=postponed_term, aktivno=True
        ).first()
        if reservation:
            reservation.termin = replacement
            reservation.save(update_fields=["termin"])
        future = replacement

    if paused:
        pause_patient_therapy(
            pacijent=patient,
            start_date=reference_date - timedelta(days=1),
            planned_end_date=reference_date + timedelta(days=20),
            reason=f"{DEMO_V2_MARKER} Privremena klinička pauza uz planiranu kontrolu.",
            user=user,
        )
        # Pauza ostaje source of truth. Budući ambulantni red se ne čuva u
        # demo kalendaru; fizička dodjela ostaje pacijentu bez termina.
        Termin.objects.filter(pacijent=patient, datum__gt=reference_date).delete()
    return previous, future


def _configure_oral_patient(patient, registry, reference_date, user):
    standard = registry["oral_regimens"][patient.terapijski_program.kljuc]
    return confirm_oral_regimen(
        patient=patient,
        medicine=patient.lijek,
        tablets_per_intake=standard.tableta_po_uzimanju,
        intakes_per_day=standard.uzimanja_dnevno,
        effective_from=reference_date - timedelta(days=180),
        phase=standard.faza,
        standard_regimen=standard,
        doctor_note=f"{DEMO_V2_MARKER} Potvrđeni canonical oralni režim.",
        user=user,
    )


def _create_waiting_delivery(
    *, patient, medicine, commission, quantity, reference_date, user
):
    return Trebovanje.objects.create(
        pacijent=patient,
        lijek=medicine,
        broj_doza=quantity,
        odobrene_doze=quantity,
        zaprimljene_doze=Decimal("0"),
        status=Trebovanje.STATUS_CEKA_ISPORUKU,
        komisija=commission,
        protokol=patient.terapijski_protokol,
        ocekivana_najranija_isporuka=reference_date + timedelta(days=8),
        dokumentacija_kompletna=True,
        kreirao=user if getattr(user, "is_authenticated", False) else None,
        napomena=f"{DEMO_V2_MARKER} Odobreno; fizička pošiljka još nije zaprimljena.",
    )


def _planner_map(reference_date):
    return {
        row["pacijent"].broj_kartona: row
        for row in commission_planning_rows(today=reference_date)
        if row["pacijent"].broj_kartona.startswith(DEMO_V2_CARD_PREFIX)
        and row["pacijent"].jmbg in DEMO_V2_JMBGS
    }


def _create_current_cycle_requests(cycle, reference_date, user):
    created = []
    warnings = []
    for row in _planner_map(reference_date).values():
        quantity = _decimal(row.get("kolicina_za_komisiju"))
        if quantity <= 0:
            continue
        patient = row["pacijent"]
        medicine = row.get("potreban_proizvod") or row.get("lijek") or patient.lijek
        quantity = round_up_to_package(quantity, medicine)
        classification = classify_commission_request(patient)
        request_type = classification.legacy_request_type
        if classification.requires_confirmation or not request_type:
            warnings.append(
                f"{patient}: planner je izračunao potrebu, ali vrsta zahtjeva nema konfiguriran službeni paket."
            )
            continue
        request, _ = sync_commission_request_from_planning(
            cycle=cycle,
            patient=patient,
            medicine=medicine,
            request_type=request_type,
            system_quantity=quantity,
            doctor_quantity=quantity,
            user=user,
            note=f"{DEMO_V2_MARKER} Zahtjev izveden iz centralnog coverage plannera.",
            classification=classification,
        )
        created.append(request)
    return created, warnings


def _create_free_stock_edge_case(
    *, registry, cycles, reference_date, user
):
    entyvio = registry["products"]["vedolizumab"]
    remsima = registry["products"]["infliximab"]
    patient = Pacijent.objects.create(
        ime="Mina",
        prezime="Vuković",
        jmbg=DEMO_EDGE_JMBG,
        broj_kartona=f"{DEMO_V2_CARD_PREFIX}EDGE-01",
        spol="Ž",
        datum_rodenja=date(1978, 5, 14),
        adresa="Rezervisani rubni demo zapis",
        kanton="Kanton Sarajevo",
        telefon="DEMO-TEL-EDGE",
        dijagnoza="Crohnova bolest",
        mkb_sifra="K50.9",
        terapijski_program=registry["programs"]["vedolizumab"],
        lijek=entyvio,
        terapijski_protokol=registry["protocols"]["vedolizumab"],
        pocetna_faza_terapije=Pacijent.FAZA_ODRZAVANJE,
        interval_sedmica=registry["maintenance"]["vedolizumab"]["interval"],
        kolicina_po_terapiji=registry["maintenance"]["vedolizumab"]["units"],
        aktivan=False,
    )
    agreement = PacijentSaglasnost.objects.create(
        pacijent=patient,
        broj_saglasnosti="DEMO-2026-EDGE",
        vazi_od=reference_date - timedelta(days=90),
        trenutno_vazeca=True,
        izmijenio=user if getattr(user, "is_authenticated", False) else None,
    )
    quantity = Decimal("1")
    commission = _create_approval(
        patient, entyvio, quantity, 99, reference_date, agreement
    )
    request = _create_received_requisition(
        patient=patient,
        medicine=entyvio,
        commission=commission,
        quantity=quantity,
        cycle=cycles["previous"],
        agreement=agreement,
        user=user,
    )
    _receive_stock(
        patient=patient,
        medicine=entyvio,
        commission=commission,
        quantity=quantity,
        received_on=reference_date - timedelta(days=12),
        user=user,
        requisition=request,
    )
    reservation = reserve_physical_stock(
        pacijent=patient,
        lijek=entyvio,
        quantity=quantity,
        komisija=commission,
        user=user,
        note=f"{DEMO_V2_MARKER} Dodijeljena doza prije evidentiranog switcha.",
    )["reservation"]
    change = PromjenaTerapije.objects.create(
        pacijent=patient,
        stari_lijek=entyvio,
        novi_lijek=remsima,
        stari_protokol=registry["protocols"]["vedolizumab"],
        novi_protokol=registry["protocols"]["infliximab"],
        datum_odluke=reference_date - timedelta(days=3),
        datum_zavrsetka_stare_terapije=reference_date - timedelta(days=3),
        datum_pocetka_nove_terapije=reference_date + timedelta(days=7),
        razlog=PromjenaTerapije.RAZLOG_GUBITAK_ODGOVORA,
        napomena=(
            f"{DEMO_V2_MARKER} Switch prije primjene; Entyvio je ostao u ustanovi "
            "uz očuvan hladni lanac."
        ),
        preostale_doze=quantity,
        postupanje_sa_preostalim_dozama=PromjenaTerapije.POSTUPANJE_OSTAVI_U_FRIZIDERU,
        nova_terapija_pocinje=PromjenaTerapije.NOVA_FAZA_INDUKCIJA,
        izvrsio=user if getattr(user, "is_authenticated", False) else None,
    )
    released = release_patient_reservations_to_free_stock(
        pacijent=patient,
        lijek=entyvio,
        user=user,
        reason=(
            f"{DEMO_V2_MARKER} Promjena lijeka; neprimijenjena doza ostala je u "
            "ustanovi uz očuvan hladni lanac."
        ),
        reason_code=ZalihaTransakcija.RAZLOG_PROMJENA_LIJEKA,
        reference=change,
        event_date=reference_date - timedelta(days=2),
    )
    if released != quantity:
        raise DemoDatasetIntegrityError("Rubni scenario nije oslobodio tačno 1 Entyvio dozu.")
    reservation.refresh_from_db()
    if reservation.aktivno or reservation.kolicina != 0:
        raise DemoDatasetIntegrityError("Rubna rezervacija nije pravilno poništena.")
    return patient


def demo_inventory_summary(*, patients=None):
    patients = list(patients or _demo_patients())
    patient_ids = [patient.pk for patient in patients]
    medicine_ids = set(
        ZalihaTransakcija.objects.filter(pacijent_id__in=patient_ids)
        .values_list("lijek_id", flat=True)
    )
    rows = []
    for medicine in Lijek.objects.filter(pk__in=medicine_ids).order_by("naziv", "pk"):
        movements = ZalihaTransakcija.objects.filter(
            pacijent_id__in=patient_ids, lijek=medicine
        )
        received = _decimal(
            movements.filter(tip=ZalihaTransakcija.TIP_ZAPRIMANJE)
            .aggregate(total=Sum("kolicina"))["total"]
        )
        consumed = _decimal(
            movements.filter(tip=ZalihaTransakcija.TIP_AMBULANTNA_POTROSNJA)
            .aggregate(total=Sum("kolicina"))["total"]
        )
        issued = _decimal(
            movements.filter(
                tip__in=(
                    ZalihaTransakcija.TIP_KUCNO_IZDAVANJE,
                    ZalihaTransakcija.TIP_ORALNO_IZDAVANJE,
                )
            ).aggregate(total=Sum("kolicina"))["total"]
        )
        institution = received - consumed - issued
        reserved = _decimal(
            PacijentRezervacija.objects.filter(
                pacijent_id__in=patient_ids,
                lijek=medicine,
                aktivno=True,
            ).aggregate(total=Sum("kolicina"))["total"]
        )
        assigned = _decimal(
            PacijentZaduzenje.objects.filter(
                pacijent_id__in=patient_ids,
                lijek=medicine,
                aktivno=True,
            ).aggregate(total=Sum("preostalo"))["total"]
        )
        rows.append(
            {
                "medicine_id": medicine.pk,
                "medicine": medicine.prikaz_naziv,
                "received": received,
                "assigned": assigned,
                "institution": institution,
                "at_patient": issued,
                "reserved": reserved,
                "consumed": consumed,
                "free": max(Decimal("0"), institution - reserved),
                "balanced": received == institution + issued + consumed,
            }
        )
    return rows


def demo_clinical_summary(*, patients=None):
    patients = list(patients or _active_demo_patients().select_related("terapijski_program"))
    medicines = Counter(patient.terapijski_program.kljuc for patient in patients)
    included_jmbgs = {patient.jmbg for patient in patients}
    states = Counter(
        spec.state
        for index, spec in enumerate(DEMO_V2_SCENARIOS)
        if DEMO_V2_JMBGS[index] in included_jmbgs
    )
    return {"by_program": dict(sorted(medicines.items())), "by_state": dict(sorted(states.items()))}


def _http_smoke_check(user):
    if not getattr(user, "is_authenticated", False):
        return {}
    from django.contrib.messages.storage.fallback import FallbackStorage
    from django.test import RequestFactory
    from dashboard.views import dashboard, komisijski_centar, lista_pacijenata, lista_zaliha

    factory = RequestFactory()
    statuses = {}
    for label, path, view in (
        ("dashboard", "/", dashboard),
        ("patients", "/pacijenti/", lista_pacijenata),
        ("inventory", "/zalihe/", lista_zaliha),
        ("commission", "/komisijski-centar/", komisijski_centar),
    ):
        request = factory.get(path)
        request.user = user
        request.session = {}
        request._messages = FallbackStorage(request)
        statuses[label] = view(request).status_code
    return statuses


def validate_demo_dataset_v2(
    *, patients=None, http_user=None, reference_date=None,
    include_free_stock_edge_case=None
):
    reference_date = reference_date or timezone.localdate()
    supplied_ids = [item.pk for item in patients] if patients is not None else None
    query = _active_demo_patients().select_related("lijek", "terapijski_program")
    if supplied_ids is not None:
        query = query.filter(pk__in=supplied_ids)
    patients = list(query)
    patient_ids = [item.pk for item in patients]
    errors = []

    if len(patients) != 28:
        errors.append(f"Očekivano 28 aktivnih demo pacijenata, pronađeno {len(patients)}.")
    if any("demo" in patient.ime.casefold() or "demo" in patient.prezime.casefold() for patient in patients):
        errors.append("Generator je upisao riječ Demo u ime ili prezime pacijenta.")
    if len({patient.jmbg for patient in patients}) != len(patients):
        errors.append("Demo dataset sadrži dupli tehnički identifikator.")

    distribution = Counter(patient.terapijski_program.kljuc for patient in patients)
    expected = {
        "infliximab": 8,
        "vedolizumab": 6,
        "adalimumab": 6,
        "ustekinumab": 5,
        "tenofovir-disoproxil": 2,
        "tofacitinib": 1,
    }
    if distribution != expected:
        errors.append(f"Raspodjela programa nije ispravna: {dict(distribution)}.")

    if PacijentSaglasnost.objects.filter(
        pacijent_id__in=patient_ids, trenutno_vazeca=True
    ).count() != 28:
        errors.append("Svaki aktivni demo pacijent mora imati tačno jednu aktivnu saglasnost.")
    changed_history = (
        PacijentSaglasnost.objects.filter(pacijent_id__in=patient_ids)
        .values("pacijent_id")
        .annotate(total=Count("id"))
        .filter(total=2)
        .count()
    )
    if changed_history != 2:
        errors.append(f"Očekivane su tačno 2 historije promjene saglasnosti; pronađeno {changed_history}.")
    for patient in patients:
        suggestion = patient_agreement_suggestion(patient)
        active = PacijentSaglasnost.objects.filter(
            pacijent=patient, trenutno_vazeca=True
        ).first()
        if not active or suggestion.number != active.broj_saglasnosti:
            errors.append(f"Aktivna saglasnost nije automatski izabrana za {patient}.")

    oral_ids = [
        patient.pk for patient in patients
        if patient.lijek and patient.lijek.oralna_terapija
    ]
    home_ids = set(
        KucnoIzdavanje.objects.filter(pacijent_id__in=patient_ids)
        .values_list("pacijent_id", flat=True)
    )
    no_calendar_ids = set(oral_ids) | home_ids
    if Termin.objects.filter(pacijent_id__in=no_calendar_ids).exists():
        errors.append("Oralni ili stabilni kućni pacijent ima ambulantni Termin.")
    if Terapija.objects.filter(
        pacijent_id__in=oral_ids,
        tip_evidencije=Terapija.TIP_AMBULANTA,
    ).exists():
        errors.append("Oralni pacijent ima ambulantnu Terapiju.")

    future_forbidden_states = {
        "new", "approved_wait", "received", "paused",
        "new_iv", "approved_wait_iv", "received_iv", "home", "oral", "ustek_home",
    }
    forbidden_cards = [
        f"{DEMO_V2_CARD_PREFIX}{index:02d}"
        for index, spec in enumerate(DEMO_V2_SCENARIOS, start=1)
        if spec.state in future_forbidden_states
    ]
    if Termin.objects.filter(
        pacijent__broj_kartona__in=forbidden_cards,
        datum__gt=reference_date,
        status__in=(Termin.STATUS_PLANIRANA, Termin.STATUS_ODGODJENA),
    ).exists():
        errors.append("Pacijent koji čeka/pauzira ili je na kućnoj/oralnoj terapiji ima budući termin.")

    appointments = Termin.objects.filter(pacijent_id__in=patient_ids)
    if appointments.filter(datum__week_day__in=(1, 7)).exists():
        errors.append("Demo termin je kreiran tokom vikenda.")
    over_capacity = (
        appointments.values("datum").annotate(total=Count("id")).filter(total__gt=3)
    )
    if over_capacity.exists():
        errors.append("Više od 3 demo pacijenta zakazano je istog dana.")

    for medicine_id in set(patient.lijek_id for patient in patients if patient.lijek_id):
        medicine = Lijek.objects.get(pk=medicine_id)
        position = inventory_position(medicine, include_planned_need=False)
        if position["reserved_in_fridge"] > position["in_fridge"]:
            errors.append(
                f"Rezervacije prelaze fizičko stanje za {medicine}: "
                f"{position['reserved_in_fridge']} > {position['in_fridge']}."
            )

    summaries = demo_inventory_summary(patients=_demo_patients())
    for row in summaries:
        if not row["balanced"]:
            errors.append(f"Demo ledger nije izbalansiran za {row['medicine']}.")
        if row["reserved"] > row["institution"]:
            errors.append(f"Demo rezervacija nije pokrivena za {row['medicine']}.")

    edge_exists = _demo_patients().filter(jmbg=DEMO_EDGE_JMBG).exists()
    if include_free_stock_edge_case is None:
        include_free_stock_edge_case = edge_exists
    free_total = sum((row["free"] for row in summaries), Decimal("0"))
    if include_free_stock_edge_case:
        entyvio_rows = [row for row in summaries if "Entyvio" in row["medicine"]]
        entyvio_free = sum((row["free"] for row in entyvio_rows), Decimal("0"))
        if free_total != 1 or entyvio_free != 1:
            errors.append(f"Rubni scenario mora imati tačno 1 slobodnu Entyvio dozu; stanje {free_total}.")
        release = ZalihaTransakcija.objects.filter(
            pacijent__jmbg=DEMO_EDGE_JMBG,
            tip=ZalihaTransakcija.TIP_OSLOBADJANJE_U_SLOBODNU_ZALIHU,
            kolicina=1,
            razlog_kod=ZalihaTransakcija.RAZLOG_PROMJENA_LIJEKA,
        )
        if not release.exists() or not AktivnostLog.objects.filter(
            pacijent__jmbg=DEMO_EDGE_JMBG,
            akcija="Oslobađanje doza u slobodnu zalihu",
        ).exists():
            errors.append("Rubni scenario nema potpun transfer/audit trag.")
    elif free_total != 0:
        free_rows = [
            f"{row['medicine']}={row['free']}"
            for row in summaries
            if row["free"] > 0
        ]
        errors.append(
            f"Standardni demo mora imati 0 slobodnih doza; pronađeno {free_total} "
            f"({', '.join(free_rows)})."
        )

    approved_without_assignment = Pacijent.objects.filter(
        pk__in=patient_ids,
        broj_kartona__in=(
            f"{DEMO_V2_CARD_PREFIX}06",
            f"{DEMO_V2_CARD_PREFIX}19",
            f"{DEMO_V2_CARD_PREFIX}22",
        ),
    )
    if PacijentZaduzenje.objects.filter(pacijent__in=approved_without_assignment).exists():
        errors.append("Samo odobrenje/čekanje isporuke je pogrešno povećalo PacijentZaduzenje.")

    hyrimoz = next((patient.lijek for patient in patients if patient.terapijski_program.kljuc == "adalimumab"), None)
    if not hyrimoz or _decimal(hyrimoz.effective_package_size) != 2:
        errors.append("Hyrimoz nema canonical pakovanje od 2 pena.")
    if hyrimoz:
        for quantity in Komisija.objects.filter(
            pacijent_id__in=patient_ids, lijek=hyrimoz
        ).values_list("broj_odobrenih_doza", flat=True):
            if _decimal(quantity) % 2:
                errors.append("Hyrimoz odobrenje nije cijeli broj pakovanja od 2 pena.")
                break

    ustek_patients = [
        patient for patient in patients
        if patient.terapijski_program.kljuc == "ustekinumab"
    ]
    if len({patient.terapijski_program_id for patient in ustek_patients}) != 1:
        errors.append("Ustekinumab IV i SC pacijenti nisu u jednom terapijskom programu.")
    for patient in ustek_patients:
        state = getattr(patient, "fazni_protokol", None)
        if not state or state.iv_lijek.terapijski_program_id != state.sc_lijek.terapijski_program_id:
            errors.append(f"Ustekinumab fazni protokol nije povezan za {patient}.")

    try:
        planner = _planner_map(reference_date)
    except Exception as exc:
        planner = {}
        errors.append(f"Komisijski planner nije izračunljiv: {exc}")
    # Centralni planner namjerno izostavlja pacijenta na aktivnoj kliničkoj
    # pauzi: za njega nema operativne komisijske akcije dok pauza traje.
    expected_planner_cards = {
        patient.broj_kartona
        for patient in patients
        if not patient.na_aktivnoj_pauzi()
    }
    if set(planner) != expected_planner_cards:
        missing = sorted(expected_planner_cards - set(planner))
        extra = sorted(set(planner) - expected_planner_cards)
        errors.append(
            f"Planner skup nije usklađen; nedostaju={missing}, višak={extra}."
        )

    try:
        http_statuses = _http_smoke_check(http_user)
    except Exception as exc:
        http_statuses = {}
        errors.append(f"HTTP smoke provjera nije izvršiva: {exc}")
    if http_statuses and any(status != 200 for status in http_statuses.values()):
        errors.append(f"HTTP smoke provjera nije prošla: {http_statuses}.")

    if errors:
        raise DemoDatasetIntegrityError("Demo dataset integrity FAIL: " + " | ".join(errors))
    return {
        "status": "PASS",
        "checks": 16,
        "planner_rows": len(planner),
        "free_stock": str(free_total),
        "oral_and_home_without_appointments": True,
        "inventory_balanced": True,
        "http_statuses": http_statuses,
    }


@transaction.atomic
def reset_demo_dataset_v2():
    return delete_demo_dataset(
        patient_queryset=_demo_patients(),
        cycle_queryset=KomisijskiCiklus.objects.filter(
            napomena__startswith=DEMO_V2_MARKER
        ),
        event_marker=DEMO_V2_MARKER,
    )


@transaction.atomic
def generate_demo_dataset_v2(
    *, user=None, reference_date=None, include_free_stock_edge_case=False
):
    """Resetuj i kreiraj 28 aktivnih scenarija relativno prema datumu poziva."""

    assert_schema_gate()
    integrity_preflight = run_database_integrity_check()
    if integrity_preflight["critical_count"]:
        raise DemoDatasetIntegrityError(
            "Provjera integriteta baze nije prošla; demo podaci nisu izmijenjeni."
        )
    reference_date = reference_date or timezone.localdate()
    if not isinstance(reference_date, date):
        raise DemoDatasetConfigurationError("Referentni datum mora biti datum.")

    conflicts = Pacijent.objects.filter(jmbg__in=DEMO_ALL_JMBGS).exclude(
        broj_kartona__startswith=DEMO_V2_CARD_PREFIX
    )
    if conflicts.exists():
        raise DemoDatasetConfigurationError(
            "Rezervisani DEMO identifikator koristi zapis bez tehničkog demo markera."
        )

    registry = _canonical_registry()
    reset_stats = reset_demo_dataset_v2()
    cycles = _create_cycles(reference_date)
    patients = [
        _create_patient(index, spec, registry)
        for index, spec in enumerate(DEMO_V2_SCENARIOS, start=1)
    ]
    by_key = {spec.key: patient for spec, patient in zip(DEMO_V2_SCENARIOS, patients)}
    agreements = _create_agreements(patients, reference_date, user)
    approvals = {}

    # Ustekinumab stanja se konfiguriraju prije izračuna količina i prava.
    iv = registry["products"]["ustek_iv"]
    sc = registry["products"]["ustek_sc"]
    maintenance_interval = int(
        registry["phases"][FazniProtokolPacijenta.FAZA_ODRZAVANJE]
        .interval_sedmica
        or 8
    )
    ustek_states = {}
    for key in ("ustek_new_iv", "ustek_delivery_iv", "ustek_received_iv", "ustek_sc_training"):
        ustek_states[key] = configure_ustekinumab_protocol(
            patient=by_key[key],
            iv_medicine=iv,
            sc_medicine=sc,
            phase=FazniProtokolPacijenta.FAZA_CEKA_IV,
            maintenance_interval=maintenance_interval,
            prescribed_iv_dose_mg=Decimal("390"),
            user=user,
        )
    home_last = _safe_date(reference_date - timedelta(days=35), sc, direction=-1)
    ustek_states["ustek_home"] = configure_ustekinumab_protocol(
        patient=by_key["ustek_home"],
        iv_medicine=iv,
        sc_medicine=sc,
        phase=FazniProtokolPacijenta.FAZA_ODRZAVANJE,
        maintenance_interval=maintenance_interval,
        last_actual_date=home_last,
        user=user,
    )
    home_state = ustek_states["ustek_home"]
    home_state.sc_nacin_primjene = home_state.SC_NACIN_KUCNA
    home_state.kucna_terapija_od = timezone.now()
    home_state.kucna_terapija_potvrdio = user if getattr(user, "is_authenticated", False) else None
    home_state.save(update_fields=["sc_nacin_primjene", "kucna_terapija_od", "kucna_terapija_potvrdio"])
    by_key["ustek_home"].lijek = sc
    by_key["ustek_home"].save(update_fields=["lijek"])

    # Stabilni/indukcijski ambulantni scenariji koriste stvarnu potvrdu dolaska.
    scheduled_specs = [
        spec for spec in DEMO_V2_SCENARIOS
        if spec.state in {"stable", "induction", "postponed", "paused"}
    ]
    slots = iter(_future_slots(reference_date, len(scheduled_specs) + 2))
    for sequence, spec in enumerate(scheduled_specs, start=1):
        patient = by_key[spec.key]
        medicine = patient.lijek
        # Administrativno pravo pokriva više budućih isporuka; fizički se niže
        # zaprima samo trenutna isporuka od tri aplikacije.
        quantity = registry["maintenance"][spec.program_key]["units"] * 12
        agreement = agreements[patient.pk]
        approval = _create_approval(
            patient, medicine, quantity, sequence, reference_date, agreement
        )
        approvals[spec.key] = approval
        _create_completed_and_future(
            patient=patient,
            medicine=medicine,
            commission=approval,
            agreement=agreement,
            cycle=cycles["previous"],
            target_date=next(slots),
            registry=registry,
            reference_date=reference_date,
            user=user,
            induction=spec.state == "induction",
            postponed=spec.state == "postponed",
            paused=spec.state == "paused",
        )

    # Zaprimljen lijek koji još nema prvi termin.
    for offset, key in enumerate(("remsima_received",), start=1):
        patient = by_key[key]
        received_quantity = registry["maintenance"]["infliximab"]["units"] * 2
        approved_quantity = registry["maintenance"]["infliximab"]["units"] * 12
        agreement = agreements[patient.pk]
        approval = _create_approval(patient, patient.lijek, approved_quantity, 20 + offset, reference_date, agreement)
        approvals[key] = approval
        request = _create_received_requisition(
            patient=patient, medicine=patient.lijek, commission=approval,
            quantity=received_quantity, cycle=cycles["previous"], agreement=agreement, user=user
        )
        _receive_stock(
            patient=patient, medicine=patient.lijek, commission=approval,
            quantity=received_quantity, received_on=reference_date - timedelta(days=4),
            user=user, requisition=request
        )
        _assign_and_reserve(
            patient=patient, medicine=patient.lijek, commission=approval,
            quantity=received_quantity, reference_date=reference_date, user=user
        )

    # Odobreno, ali fizička isporuka još nije stigla. Nema zaduženja ni termina.
    for offset, key in enumerate(("remsima_delivery", "hyrimoz_delivery", "ustek_delivery_iv"), start=1):
        patient = by_key[key]
        medicine = iv if key == "ustek_delivery_iv" else patient.lijek
        if key == "ustek_delivery_iv":
            quantity = _decimal(current_phase_details(ustek_states[key])["units"])
        elif patient.terapijski_program.kljuc == "adalimumab":
            quantity = Decimal("14")
        else:
            quantity = registry["maintenance"][patient.terapijski_program.kljuc]["units"] * 12
        agreement = agreements[patient.pk]
        approval = _create_approval(patient, medicine, quantity, 30 + offset, reference_date, agreement)
        approvals[key] = approval
        _create_waiting_delivery(
            patient=patient, medicine=medicine, commission=approval,
            quantity=round_up_to_package(quantity, medicine),
            reference_date=reference_date, user=user
        )

    # Hyrimoz kućna terapija: puna pakovanja (3 pakovanja / 6 penova).
    from .demo_data import _record_demo_home_issue

    for sequence, key in enumerate(("hyrimoz_home_1", "hyrimoz_home_2", "hyrimoz_home_3", "hyrimoz_home_4"), start=1):
        patient = by_key[key]
        issued_quantity = Decimal("10")
        approved_quantity = Decimal("14")
        agreement = agreements[patient.pk]
        approval = _create_approval(patient, patient.lijek, approved_quantity, 40 + sequence, reference_date, agreement)
        approvals[key] = approval
        request = _create_received_requisition(
            patient=patient, medicine=patient.lijek, commission=approval,
            quantity=issued_quantity, cycle=cycles["previous"], agreement=agreement, user=user
        )
        _receive_stock(
            patient=patient, medicine=patient.lijek, commission=approval,
            quantity=issued_quantity, received_on=reference_date - timedelta(days=15 + sequence),
            user=user, requisition=request
        )
        _record_demo_home_issue(
            patient=patient, medicine=patient.lijek, commission=approval,
            quantity=issued_quantity, datum=reference_date - timedelta(days=5 + sequence),
            sequence=sequence, user=user
        )

    # Switch pacijent još nema fizičko pokriće novog lijeka.
    switch_patient = by_key["hyrimoz_switch"]
    old_medicine = registry["products"]["vedolizumab"]
    PromjenaTerapije.objects.create(
        pacijent=switch_patient,
        stari_lijek=old_medicine,
        novi_lijek=switch_patient.lijek,
        stari_protokol=registry["protocols"]["vedolizumab"],
        novi_protokol=registry["protocols"]["adalimumab"],
        datum_odluke=reference_date - timedelta(days=6),
        datum_zavrsetka_stare_terapije=reference_date - timedelta(days=7),
        datum_pocetka_nove_terapije=reference_date + timedelta(days=7),
        razlog=PromjenaTerapije.RAZLOG_NEDOVOLJAN_ODGOVOR,
        napomena=f"{DEMO_V2_MARKER} Evidentiran canonical switch Entyvio → Hyrimoz.",
        preostale_doze=Decimal("0"),
        postupanje_sa_preostalim_dozama=PromjenaTerapije.POSTUPANJE_NEISKORISTENE,
        nova_terapija_pocinje=PromjenaTerapije.NOVA_FAZA_INDUKCIJA,
        izvrsio=user if getattr(user, "is_authenticated", False) else None,
    )

    # Ustekinumab: zaprimljena IV indukcija bez termina.
    patient = by_key["ustek_received_iv"]
    iv_units = _decimal(current_phase_details(ustek_states["ustek_received_iv"])["units"])
    agreement = agreements[patient.pk]
    approval = _create_approval(patient, iv, iv_units, 51, reference_date, agreement)
    approvals["ustek_received_iv"] = approval
    request = _create_received_requisition(
        patient=patient, medicine=iv, commission=approval, quantity=iv_units,
        cycle=cycles["previous"], agreement=agreement, user=user
    )
    _receive_stock(
        patient=patient, medicine=iv, commission=approval, quantity=iv_units,
        received_on=reference_date - timedelta(days=3), user=user, requisition=request
    )
    _assign_and_reserve(
        patient=patient, medicine=iv, commission=approval, quantity=iv_units,
        reference_date=reference_date, user=user
    )

    # Ustekinumab SC obuka: IV i prva SC su stvarno potvrđene u faznom workflowu.
    training = by_key["ustek_sc_training"]
    training_state = ustek_states["ustek_sc_training"]
    iv_units = _decimal(current_phase_details(training_state)["units"])
    sc_quantity = Decimal("5")
    agreement = agreements[training.pk]
    approval = _create_approval(training, iv, iv_units + Decimal("9"), 52, reference_date, agreement)
    approvals["ustek_sc_training"] = approval
    iv_request = _create_received_requisition(
        patient=training, medicine=iv, commission=approval, quantity=iv_units,
        cycle=cycles["previous"], agreement=agreement, user=user
    )
    sc_request = _create_received_requisition(
        patient=training, medicine=sc, commission=approval, quantity=sc_quantity,
        cycle=cycles["previous"], agreement=agreement, user=user
    )
    first_sc_date = _safe_date(reference_date - timedelta(days=5), sc, direction=-1)
    iv_date = _safe_date(first_sc_date - timedelta(weeks=8), iv, direction=-1)
    _receive_stock(
        patient=training, medicine=iv, commission=approval, quantity=iv_units,
        received_on=iv_date - timedelta(days=8), user=user, requisition=iv_request
    )
    _receive_stock(
        patient=training, medicine=sc, commission=approval, quantity=sc_quantity,
        received_on=first_sc_date - timedelta(days=8), user=user, requisition=sc_request
    )
    iv_term = Termin.objects.create(
        pacijent=training, lijek=iv, datum=iv_date, vrijeme=time(10, 0),
        kolicina_po_terapiji=iv_units, status=Termin.STATUS_PLANIRANA
    )
    ensure_phase_reservation(state=training_state, appointment=iv_term, user=user)
    confirm_therapy_arrival(
        termin=iv_term, primljene_doze=iv_units, interval_sedmica=8,
        # IV i prva SC su historijski događaji. Validacija rasporeda se zato
        # veže za datum IV događaja, ne za datum generisanja dataseta.
        korisnik=user, scheduling_validation_today=iv_date
    )
    training_state.refresh_from_db()
    sc_term = Termin.objects.filter(
        pacijent=training, lijek=sc, status=Termin.STATUS_PLANIRANA
    ).order_by("datum", "id").first()
    if not sc_term:
        raise DemoDatasetIntegrityError("Fazni workflow nije kreirao prvu SC obuku.")
    confirm_therapy_arrival(
        termin=sc_term, primljene_doze=Decimal("1"),
        interval_sedmica=maintenance_interval, korisnik=user,
        scheduling_validation_today=reference_date
    )
    training_state.refresh_from_db()
    remaining_sc = Decimal("4")
    existing_reserved = _decimal(
        PacijentRezervacija.objects.filter(
            pacijent=training, lijek=sc, aktivno=True
        ).aggregate(total=Sum("kolicina"))["total"]
    )
    from dashboard.views import dodijeli_doze_pacijentu
    assignment = dodijeli_doze_pacijentu(
        training, sc, remaining_sc, komisija=approval, korisnik=user
    )
    if assignment:
        assignment.datum_zaduzenja = reference_date
        assignment.save(update_fields=["datum_zaduzenja"])
    if existing_reserved < remaining_sc:
        reserve_physical_stock(
            pacijent=training, lijek=sc, quantity=remaining_sc - existing_reserved,
            komisija=approval, user=user,
            note=f"{DEMO_V2_MARKER} SC obuka i naredna održavajuća doza."
        )

    # Ustekinumab stabilna kućna SC terapija bez budućeg ambulantnog termina.
    home_patient = by_key["ustek_home"]
    agreement = agreements[home_patient.pk]
    quantity = Decimal("4")
    approval = _create_approval(home_patient, sc, quantity, 53, reference_date, agreement)
    approvals["ustek_home"] = approval
    request = _create_received_requisition(
        patient=home_patient, medicine=sc, commission=approval, quantity=quantity,
        cycle=cycles["previous"], agreement=agreement, user=user
    )
    _receive_stock(
        patient=home_patient, medicine=sc, commission=approval, quantity=quantity,
        received_on=reference_date - timedelta(days=12), user=user, requisition=request
    )
    _record_demo_home_issue(
        patient=home_patient, medicine=sc, commission=approval, quantity=quantity,
        datum=reference_date - timedelta(days=4), sequence=25, user=user
    )
    Termin.objects.filter(pacijent=home_patient, datum__gt=reference_date).delete()

    # Oralni lijekovi: samo odobrenje, zaprimanje i izdavanje; bez Termina.
    for sequence, key in enumerate(("tenofovir_stable_1", "tenofovir_stable_2", "xeljanz_stable"), start=1):
        patient = by_key[key]
        regimen = _configure_oral_patient(patient, registry, reference_date, user)
        package = Decimal(patient.lijek.broj_tableta_u_pakovanju)
        quantity = package * Decimal("6")
        agreement = agreements[patient.pk]
        approval = _create_approval(patient, patient.lijek, quantity, 60 + sequence, reference_date, agreement)
        approvals[key] = approval
        request = _create_received_requisition(
            patient=patient, medicine=patient.lijek, commission=approval,
            quantity=quantity, cycle=cycles["previous"], agreement=agreement, user=user
        )
        _receive_stock(
            patient=patient, medicine=patient.lijek, commission=approval,
            quantity=quantity, received_on=reference_date - timedelta(days=18 + sequence),
            user=user, requisition=request
        )
        issue_oral_therapy(
            patient=patient,
            regimen=regimen,
            approval_source=f"komisija:{approval.pk}",
            quantity=int(quantity),
            issued_on=reference_date - timedelta(days=10 + sequence),
            idempotency_key=uuid.uuid5(
                uuid.NAMESPACE_URL, f"theraflow-demo-28-{key}-{reference_date.isoformat()}"
            ),
            batch=f"DEMO-ORAL-{sequence:02d}",
            note=f"{DEMO_V2_MARKER} Stabilno oralno izdavanje bez kalendarskih termina.",
            user=user,
        )

    if include_free_stock_edge_case:
        _create_free_stock_edge_case(
            registry=registry, cycles=cycles, reference_date=reference_date, user=user
        )

    current_requests, request_warnings = _create_current_cycle_requests(
        cycles["current"], reference_date, user
    )
    integrity = validate_demo_dataset_v2(
        patients=patients,
        http_user=user,
        reference_date=reference_date,
        include_free_stock_edge_case=include_free_stock_edge_case,
    )
    planner = _planner_map(reference_date)
    inventory = demo_inventory_summary(patients=_demo_patients())
    clinical = {
        "by_program": dict(
            sorted(Counter(patient.terapijski_program.kljuc for patient in patients).items())
        ),
        "by_state": dict(sorted(Counter(spec.state for spec in DEMO_V2_SCENARIOS).items())),
    }
    return {
        "dataset_version": "V2-28",
        "reference_date": reference_date,
        "include_free_stock_edge_case": bool(include_free_stock_edge_case),
        "pacijenti": len(patients),
        "tehnicki_demo_zapisi": _demo_patients().count(),
        "termini": Termin.objects.filter(pacijent__in=_demo_patients()).count(),
        "terapije": Terapija.objects.filter(pacijent__in=_demo_patients()).count(),
        "komisije": Komisija.objects.filter(pacijent__in=_demo_patients()).count(),
        "zaduzenja": PacijentZaduzenje.objects.filter(pacijent__in=_demo_patients()).count(),
        "oralna_izdavanja": IzdavanjeOralneTerapije.objects.filter(pacijent__in=patients).count(),
        "trenutni_zahtjevi": len(current_requests),
        "ciklusi": {
            key: {
                "id": cycle.pk,
                "date": cycle.datum_komisije,
                "preparation": cycle.datum_pripreme,
                "status": cycle.status,
                "expected_delivery": cycle.najraniji_ocekivani_datum_isporuke,
            }
            for key, cycle in cycles.items()
        },
        "clinical_summary": clinical,
        "inventory_summary": inventory,
        "zalihe_promijenjene": True,
        "reset": reset_stats,
        "integrity": integrity,
        "planner_statuses": {
            card: {
                "status": row.get("status_oznaka"),
                "action_quantity": str(row.get("kolicina_za_komisiju", 0)),
                "next_action": row.get("sljedeci_korak"),
            }
            for card, row in planner.items()
        },
        "warnings": request_warnings,
        "info": [
            "Kreirano je tačno 28 aktivnih tehnički označenih demo pacijenata.",
            "Svi datumi su izvedeni relativno iz referentnog datuma generisanja.",
            "Komisijski zahtjevi otvorenog ciklusa izvedeni su centralnim coverage plannerom.",
            "Standardna slobodna zaliha je 0; rubni Entyvio slučaj postoji samo kada je opcija uključena.",
        ],
    }
