import logging
import os
import sys
import time
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path

from . import (
    django_commands,
    file_installer,
    health_check,
    history_writer,
    rollback_manager,
    service_manager,
)
from .plan_loader import (
    PlanValidationError,
    dependency_diagnostics,
    dependencies_supported,
    load_and_validate,
    read_version,
    validate_database_backup,
)
from .state_writer import process_step_label, trace_update_step, write_state


def _logger(plan_path):
    log_path = Path(plan_path).resolve().parent / "update_install.log"
    logger = logging.getLogger("theraflow-updater")
    logger.setLevel(logging.INFO)
    handler = RotatingFileHandler(
        log_path,
        maxBytes=5 * 1024 * 1024,
        backupCount=2,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.handlers[:] = [handler]
    return logger


def _utc_now():
    return datetime.now(timezone.utc).isoformat()


def run(plan_path, dry_run=False, initial_delay=2):
    plan_path = Path(plan_path).resolve()
    logger = _logger(plan_path)
    sessions_root = plan_path.parent.parent
    trace_data_root = sessions_root.parent.parent
    lock_path = sessions_root / "install.lock"
    state_path = sessions_root / f"{plan_path.parent.name}.json"
    service_stopped = False
    files_changed = False
    plan = None
    current_step_code = "launcher_delay"

    def step_started(code, label, status, progress, **extra):
        nonlocal current_step_code
        current_step_code = code
        logger.info("STEP START code=%s label=%s", code, label)
        trace_update_step(
            code,
            "START",
            session_id=plan_path.parent.name,
            function_name="updates.updater.runner.run",
            paths={"install_plan": plan_path},
            data_root=trace_data_root,
        )
        return write_state(
            state_path,
            status=status,
            current_step=label,
            progress_percent=progress,
            last_attempted_step=code,
            step_started_at=_utc_now(),
            step_completed_at=None,
            **extra,
        )

    def step_completed(code, status, progress, **extra):
        logger.info("STEP COMPLETE code=%s", code)
        trace_update_step(
            code,
            "PASS",
            session_id=plan_path.parent.name,
            function_name="updates.updater.runner.run",
            paths={
                "application_root": plan.get("application_root") if plan else None,
                "payload_root": plan.get("payload_root") if plan else None,
            },
            exit_code=0,
            data_root=trace_data_root,
        )
        return write_state(
            state_path,
            status=status,
            progress_percent=progress,
            last_successful_step=code,
            step_completed_at=_utc_now(),
            **extra,
        )

    def terminal_failure(code, message, status=None, exception=None, exit_code=1, **extra):
        completed_at = _utc_now()
        logger.error(
            "STEP FAIL code=%s error_code=%s error=%s",
            current_step_code,
            code,
            str(message)[:1000],
        )
        trace_update_step(
            current_step_code,
            "FAIL",
            session_id=plan_path.parent.name,
            function_name="updates.updater.runner.run",
            paths={
                "install_plan": plan_path,
                "application_root": plan.get("application_root") if plan else None,
                "payload_root": plan.get("payload_root") if plan else None,
                "backup_root": plan.get("backup_root") if plan else None,
            },
            exception=exception or RuntimeError(str(message)),
            exit_code=exit_code,
            data_root=trace_data_root,
        )
        return write_state(
            state_path,
            status=status or code,
            error_code=code,
            error_message=message,
            rollback_reason=message,
            rollback_trigger="automatic",
            failed_step=current_step_code,
            failed_step_label=process_step_label(current_step_code),
            completed_at=completed_at,
            step_completed_at=completed_at,
            **extra,
        )

    def fail_with_optional_rollback(code, message, return_code, exception=None, **extra):
        terminal_failure(
            code,
            message,
            status="rollback_required" if files_changed else code,
            exception=exception,
            exit_code=getattr(exception, "exit_code", None) or return_code,
            **extra,
        )
        if files_changed and plan:
            try:
                logger.info("STEP START code=rollback label=Automatski rollback")
                rollback_manager.execute(
                    plan,
                    state_path,
                    trigger="automatic",
                    reason=message,
                )
                logger.info("STEP COMPLETE code=rollback")
            except rollback_manager.RollbackError:
                logger.exception("Automatski rollback nije završen.")
        return return_code

    try:
        logger.info("Updater process started pid=%s plan=%s", os.getpid(), plan_path.name)
        if initial_delay:
            time.sleep(initial_delay)

        step_started(
            "plan_validation",
            "Završna provjera install plana",
            "validating_plan",
            5,
            updater_pid=os.getpid(),
        )
        plan, _state = load_and_validate(plan_path)
        if (
            not lock_path.is_file()
            or lock_path.read_text(encoding="utf-8").strip() != plan["session_id"]
        ):
            raise PlanValidationError("Install lock ne odgovara update sessionu.")
        dependency_report = dependency_diagnostics(plan)
        logger.info(
            "DEPENDENCY CHECK current_path=%s current_exists=%s current_raw_sha256=%s "
            "current_fingerprint=%s target_path=%s target_exists=%s "
            "target_raw_sha256=%s target_fingerprint=%s",
            dependency_report["current"]["path"],
            dependency_report["current"]["exists"],
            dependency_report["current"]["raw_sha256"],
            dependency_report["current"]["fingerprint"],
            dependency_report["target"]["path"],
            dependency_report["target"]["exists"],
            dependency_report["target"]["raw_sha256"],
            dependency_report["target"]["fingerprint"],
        )
        logger.info(
            "DEPENDENCY DIFF added=%s removed=%s changed=%s current_errors=%s "
            "target_errors=%s",
            dependency_report["added"],
            dependency_report["removed"],
            dependency_report["changed"],
            dependency_report["current"]["errors"],
            dependency_report["target"]["errors"],
        )
        logger.info(
            "OFFLINE DEPENDENCIES expected_path=%s exists=%s wheel_count=%s sha256=%s",
            dependency_report["offline"]["expected_path"],
            dependency_report["offline"]["exists"],
            dependency_report["offline"]["wheel_count"],
            dependency_report["offline"]["sha256"],
        )
        logger.info("DEPENDENCY DECISION supported=%s reason=%s", dependency_report["supported"], dependency_report["reason"])
        if not dependency_report["supported"]:
            dependency_error = RuntimeError(dependency_report["reason"])
            terminal_failure(
                "dependency_update_unsupported",
                dependency_report["reason"],
                exception=dependency_error,
                exit_code=2,
            )
            return 2
        step_completed("plan_validation", "plan_validated", 10)

        if dry_run:
            simulated = [
                path.relative_to(plan["payload_root"]).as_posix()
                for path in Path(plan["payload_root"]).rglob("*")
                if path.is_file()
            ]
            logger.info(
                "Dry-run validiran; %s fajlova bi bilo instalirano. "
                "Komande: check, migrate=always, collectstatic=%s "
                "(manifest migration_required=%s).",
                len(simulated),
                plan["collectstatic_required"],
                plan["migration_required"],
            )
            write_state(
                state_path,
                status="dry_run_completed",
                current_step="Dry-run završen",
                progress_percent=100,
                completed_at=_utc_now(),
                last_successful_step="dry_run",
                step_completed_at=_utc_now(),
            )
            return 0

        service_info = service_manager.query(plan["service_name"])
        try:
            service_config = service_manager.configuration(plan["service_name"])
        except service_manager.ServiceError:
            service_config = service_info.get("raw", "")

        step_started(
            "service_stop",
            "Zaustavljanje TheraFlow servisa",
            "service_stopping",
            15,
            service_status=service_info["state"],
        )
        service_manager.stop(plan["service_name"])
        service_stopped = True
        step_completed("service_stop", "service_stopped", 22, service_status="STOPPED")

        step_started(
            "application_backup",
            "Sigurnosna kopija aplikacijskih fajlova",
            "creating_snapshot",
            28,
        )
        snapshot, _manifest = file_installer.create_snapshot(plan, service_config)
        step_completed(
            "application_backup",
            "snapshot_completed",
            36,
            snapshot_path=str(snapshot),
            migration_started=False,
            migration_completed=False,
            files_changed=False,
        )

        step_started("install", "Instalacija nove verzije", "files_installing", 42)
        files_changed = True
        write_state(state_path, files_changed=True)
        file_installer.install_payload(plan)
        installed_version = read_version(
            Path(plan["application_root"]) / "theraflow" / "version.py"
        )
        if installed_version != plan["target_version"]:
            raise RuntimeError("Instalirana verzija ne odgovara install planu.")
        step_completed("install", "files_installed", 55)

        step_started("django_check", "Provjera aplikacije", "django_check_running", 60)
        django_commands.django_check(plan)
        step_completed("django_check", "django_check_passed", 66)

        # ``migrate --noinput`` je namjerno obavezan za svaki update. Django
        # ga sigurno tretira kao no-op kada nema novih migracija, a time se
        # izbjegava kritično stanje u kojem manifest pogrešno navede
        # ``migration_required=false`` dok novi kod već očekuje novu kolonu.
        validate_database_backup(plan)
        step_started(
            "migrate",
            "Migracija baze",
            "migrations_running",
            70,
            migration_started=True,
        )
        django_commands.migrate(plan, sessions_root / "migration.lock")
        step_completed(
            "migrate",
            "migrations_completed",
            78,
            migration_completed=True,
        )

        if plan["collectstatic_required"]:
            step_started(
                "collectstatic",
                "Priprema statičkih fajlova",
                "collectstatic_running",
                81,
            )
            django_commands.collectstatic(plan)
            step_completed("collectstatic", "collectstatic_completed", 86)
        else:
            logger.info("STEP SKIP code=collectstatic reason=collectstatic_required_false")
            trace_update_step(10, "SKIP", session_id=plan["session_id"], function_name="updates.updater.runner.run", paths={"application_root": plan["application_root"]}, message="collectstatic_required=false", exit_code=0, data_root=trace_data_root)

        step_started(
            "backup_scheduler_service",
            "Priprema servisa automatskog backupa",
            "backup_scheduler_starting",
            88,
        )
        service_manager.install_backup_scheduler(plan["application_root"])
        step_completed(
            "backup_scheduler_service",
            "backup_scheduler_running",
            89,
            backup_scheduler_status="RUNNING",
        )

        step_started(
            "restart",
            "Pokretanje TheraFlow servisa",
            "service_starting",
            90,
            service_status="STARTING",
        )
        service_manager.start(plan["service_name"])
        service_stopped = False
        step_completed("restart", "service_running", 94, service_status="RUNNING")

        step_started(
            "health_check",
            "Završna health provjera",
            "health_check_running",
            96,
        )
        health_check.check(plan["health_check_url"], plan["target_version"])
        step_completed(
            "health_check",
            "health_check_passed",
            98,
            health_check_status="health_check_passed",
        )

        step_started("finalize", "Završavanje update sessiona", "finalizing", 99)
        final_state = step_completed(
            "finalize",
            "update_completed",
            100,
            current_step="Ažuriranje završeno",
            completed_at=_utc_now(),
            health_check_status="health_check_passed",
            service_status="RUNNING",
            error_code="",
            error_message="",
        )
        history_writer.write_history_event(plan, final_state, "successful")
        logger.info(
            "TheraFlow je uspješno ažuriran na verziju %s.",
            plan["target_version"],
        )
        return 0
    except PlanValidationError as exc:
        logger.warning("Validacija install plana nije uspjela: %s", type(exc).__name__)
        terminal_failure("validation_failed", str(exc), exception=exc, exit_code=2)
        return 2
    except service_manager.ServiceError as exc:
        status = "service_start_failed" if files_changed else "service_stop_failed"
        return fail_with_optional_rollback(
            status,
            str(exc),
            3,
            exception=exc,
            service_status="STOPPED" if service_stopped else "UNKNOWN",
        )
    except file_installer.SnapshotError as exc:
        if service_stopped:
            try:
                service_manager.start(load_and_validate(plan_path)[0]["service_name"])
            except Exception:
                logger.exception("Servis nije ponovo pokrenut nakon snapshot greške.")
        terminal_failure("snapshot_failed", str(exc), exception=exc, exit_code=4)
        return 4
    except django_commands.DjangoCommandError as exc:
        return fail_with_optional_rollback(exc.code, str(exc), 5, exception=exc)
    except health_check.HealthCheckError as exc:
        return fail_with_optional_rollback(
            exc.code,
            str(exc),
            6,
            exception=exc,
            health_check_status=exc.code,
        )
    except Exception as exc:
        logger.exception("Updater je zaustavljen na kritičnoj grešci.")
        return fail_with_optional_rollback("install_failed", str(exc), 7, exception=exc)
    finally:
        lock_path.unlink(missing_ok=True)
        trace_update_step(13, "PASS", session_id=plan_path.parent.name, function_name="updates.updater.runner.run.finally", paths={"install_lock": lock_path}, message="Updater lock cleanup completed", exit_code=0, data_root=trace_data_root)
        logger.info(
            "Updater process finished pid=%s last_attempted_step=%s",
            os.getpid(),
            current_step_code,
        )
        for handler in list(logger.handlers):
            handler.close()
            logger.removeHandler(handler)


def run_rollback(plan_path, initial_delay=2):
    plan_path = Path(plan_path).resolve()
    if initial_delay:
        time.sleep(initial_delay)
    plan, _state = load_and_validate(plan_path, rollback=True)
    state_path = Path(plan["_state_path"])
    try:
        rollback_manager.execute(
            plan,
            state_path,
            trigger="manual",
            reason="Administrator je pokrenuo kontrolisani rollback.",
        )
        return 0
    except rollback_manager.RollbackError:
        return 8


def main():
    if len(sys.argv) != 2:
        return 64
    dry_run = os.environ.get("THERAFLOW_UPDATER_DRY_RUN") == "1"
    if os.environ.get("THERAFLOW_UPDATER_MODE") == "rollback":
        return run_rollback(sys.argv[1])
    return run(sys.argv[1], dry_run=dry_run)


if __name__ == "__main__":
    raise SystemExit(main())
