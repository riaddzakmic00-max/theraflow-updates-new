from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from patients.models import Terapija, Termin
from patients.utils import upisi_log
from patients.video_demo import (
    VIDEO_DEMO_MARKER,
    find_demo_patient,
    today,
    video_demo_environment_allowed,
)


class Command(BaseCommand):
    help = "Uklanja samo današnji neobrađeni termin označen kao VIDEO DEMO TERMIN."

    def add_arguments(self, parser):
        parser.add_argument("--jmbg", required=True)

    @transaction.atomic
    def handle(self, *args, **options):
        if not video_demo_environment_allowed():
            raise CommandError(
                "Video demo komanda je dozvoljena samo lokalno ili uz DEBUG=True."
            )
        try:
            patient = find_demo_patient(options["jmbg"])
        except ValueError as exc:
            raise CommandError(str(exc)) from exc

        appointment_date = today()
        matches = list(
            Termin.objects.select_for_update()
            .filter(
                pacijent=patient,
                datum=appointment_date,
                historija_statusa__razlog__startswith=VIDEO_DEMO_MARKER,
            )
            .distinct()
            .order_by("id")
        )
        if not matches:
            raise CommandError(
                "Današnji termin sa oznakom VIDEO DEMO TERMIN nije pronađen."
            )
        if len(matches) > 1:
            raise CommandError(
                "Pronađeno je više označenih termina. Ništa nije obrisano; "
                "potrebna je ručna provjera."
            )

        appointment = matches[0]
        confirmed_therapy_exists = Terapija.objects.filter(
            pacijent=patient,
            lijek=appointment.lijek,
            datum=appointment_date,
            workflow_status=Terapija.STATUS_POTVRDJENA,
        ).exists()
        if appointment.status == Termin.STATUS_POTVRDJENA or confirmed_therapy_exists:
            raise CommandError(
                "VIDEO DEMO TERMIN je već potvrđen. Ne pokušavajte automatsko "
                "poništavanje medicinskih ili zalihovnih transakcija; vratite "
                "prethodno napravljeni backup demo baze."
            )
        if appointment.status != Termin.STATUS_PLANIRANA:
            raise CommandError(
                f"VIDEO DEMO TERMIN ima status '{appointment.get_status_display()}'. "
                "Automatsko uklanjanje nije dozvoljeno; provjerite demo bazu ručno."
            )

        appointment_id = appointment.pk
        appointment_time = appointment.vrijeme
        appointment.delete()
        upisi_log(
            None,
            "Uklonjen video demo termin",
            pacijent=patient,
            opis=(
                f"{VIDEO_DEMO_MARKER} #{appointment_id} za "
                f"{appointment_date:%d.%m.%Y.} u {appointment_time:%H:%M} je uklonjen."
            ),
        )
        self.stdout.write(
            self.style.SUCCESS(
                f"Uklonjen VIDEO DEMO TERMIN za {patient}: "
                f"{appointment_date:%d.%m.%Y.} u {appointment_time:%H:%M}."
            )
        )
