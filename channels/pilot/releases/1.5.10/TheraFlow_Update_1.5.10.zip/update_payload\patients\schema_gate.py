"""Read-only migration and physical database schema reconciliation checks."""

from __future__ import annotations

from dataclasses import asdict, dataclass

from django.apps import apps as django_apps
from django.db import connections, models
from django.db.migrations.autodetector import MigrationAutodetector
from django.db.migrations.executor import MigrationExecutor
from django.db.migrations.questioner import MigrationQuestioner
from django.db.migrations.recorder import MigrationRecorder
from django.db.migrations.state import ProjectState


ADMIN_SCHEMA_MESSAGE = "Potrebno je ažurirati strukturu baze prije nastavka."


class SchemaGateError(ValueError):
    """Raised before a write workflow when the migration/schema gate is not clean."""


@dataclass(frozen=True)
class ModelSchemaReport:
    model: str
    table: str
    missing_table: bool = False
    missing_columns: tuple[str, ...] = ()
    unexpected_columns: tuple[str, ...] = ()
    nullable_mismatches: tuple[str, ...] = ()
    foreign_key_mismatches: tuple[str, ...] = ()
    constraint_mismatches: tuple[str, ...] = ()
    index_mismatches: tuple[str, ...] = ()

    @property
    def clean(self):
        return not any(
            (
                self.missing_table,
                self.missing_columns,
                self.unexpected_columns,
                self.nullable_mismatches,
                self.foreign_key_mismatches,
                self.constraint_mismatches,
                self.index_mismatches,
            )
        )


@dataclass(frozen=True)
class SchemaGateResult:
    database: str
    vendor: str
    pending_migrations: tuple[str, ...] = ()
    model_state_changes: tuple[str, ...] = ()
    migration_conflicts: tuple[str, ...] = ()
    history_without_files: tuple[str, ...] = ()
    model_reports: tuple[ModelSchemaReport, ...] = ()
    error: str = ""

    @property
    def issue_reports(self):
        return tuple(report for report in self.model_reports if not report.clean)

    @property
    def clean(self):
        return not any(
            (
                self.pending_migrations,
                self.model_state_changes,
                self.migration_conflicts,
                self.history_without_files,
                self.issue_reports,
                self.error,
            )
        )

    def as_dict(self):
        data = asdict(self)
        data["clean"] = self.clean
        data["managed_tables_audited"] = len(self.model_reports)
        data["schema_issue_count"] = len(self.issue_reports)
        return data


def _columns_match(constraint, expected_columns):
    return tuple(constraint.get("columns") or ()) == tuple(expected_columns)


def _detect_unmigrated_model_changes(executor, *, app_registry=None):
    """Return model changes that are not represented by migration files."""

    registry = app_registry or django_apps
    changes = MigrationAutodetector(
        executor.loader.project_state(),
        ProjectState.from_apps(registry),
        MigrationQuestioner(dry_run=True),
    ).changes(graph=executor.loader.graph)
    return tuple(
        f"{app_label}.{migration.name}"
        for app_label in sorted(changes)
        for migration in changes[app_label]
    )


def audit_managed_models(*, using="default", app_registry=None):
    """Compare every managed model table with the physical database schema."""

    connection = connections[using]
    registry = app_registry or django_apps
    introspection = connection.introspection
    reports = []
    seen_tables = set()

    with connection.cursor() as cursor:
        table_names = set(introspection.table_names(cursor))
        for model in registry.get_models(include_auto_created=True):
            opts = model._meta
            if not opts.managed or opts.proxy or opts.db_table in seen_tables:
                continue
            seen_tables.add(opts.db_table)
            expected_fields = {
                field.column: field for field in opts.local_concrete_fields
            }

            if opts.db_table not in table_names:
                reports.append(
                    ModelSchemaReport(
                        model=opts.label,
                        table=opts.db_table,
                        missing_table=True,
                        missing_columns=tuple(sorted(expected_fields)),
                    )
                )
                continue

            description = {
                column.name: column
                for column in introspection.get_table_description(cursor, opts.db_table)
            }
            constraints = introspection.get_constraints(cursor, opts.db_table)
            actual_columns = set(description)
            nullable_mismatches = []
            foreign_key_mismatches = []
            constraint_mismatches = []
            index_mismatches = []

            for column, field in expected_fields.items():
                if column not in description:
                    continue
                expected_null = bool(field.null)
                actual_null = bool(description[column].null_ok)
                if expected_null != actual_null:
                    nullable_mismatches.append(
                        f"{column}: model null={expected_null}, db null={actual_null}"
                    )

                if field.remote_field and getattr(field.remote_field, "model", None):
                    target = field.remote_field.model._meta
                    target_column = field.target_field.column
                    has_expected_fk = any(
                        data.get("foreign_key") == (target.db_table, target_column)
                        and column in (data.get("columns") or ())
                        for data in constraints.values()
                    )
                    if not has_expected_fk:
                        foreign_key_mismatches.append(
                            f"{column} -> {target.db_table}.{target_column}"
                        )

                if field.primary_key:
                    if not any(
                        data.get("primary_key")
                        and _columns_match(data, (column,))
                        for data in constraints.values()
                    ):
                        constraint_mismatches.append(f"primary key: {column}")
                elif field.unique:
                    if not any(
                        data.get("unique") and _columns_match(data, (column,))
                        for data in constraints.values()
                    ):
                        constraint_mismatches.append(f"unique field: {column}")

                if field.db_index and not field.unique:
                    if not any(
                        (data.get("index") or data.get("unique"))
                        and _columns_match(data, (column,))
                        for data in constraints.values()
                    ):
                        index_mismatches.append(f"indexed field: {column}")

            for fields in opts.unique_together:
                columns = tuple(opts.get_field(name).column for name in fields)
                if not any(
                    data.get("unique") and _columns_match(data, columns)
                    for data in constraints.values()
                ):
                    constraint_mismatches.append(
                        "unique_together: " + ", ".join(columns)
                    )

            for constraint in opts.constraints:
                actual = constraints.get(constraint.name)
                if actual is None:
                    constraint_mismatches.append(constraint.name)
                elif isinstance(constraint, models.CheckConstraint) and not actual.get(
                    "check"
                ):
                    constraint_mismatches.append(f"{constraint.name}: expected CHECK")
                elif isinstance(constraint, models.UniqueConstraint) and not actual.get(
                    "unique"
                ):
                    constraint_mismatches.append(f"{constraint.name}: expected UNIQUE")

            for index in opts.indexes:
                actual = constraints.get(index.name)
                if actual is None or not actual.get("index"):
                    index_mismatches.append(index.name)
                    continue
                if index.fields:
                    expected_columns = tuple(
                        opts.get_field(field_name.lstrip("-")).column
                        for field_name in index.fields
                    )
                    if not _columns_match(actual, expected_columns):
                        index_mismatches.append(
                            f"{index.name}: expected columns {', '.join(expected_columns)}"
                        )

            reports.append(
                ModelSchemaReport(
                    model=opts.label,
                    table=opts.db_table,
                    missing_columns=tuple(
                        sorted(set(expected_fields) - actual_columns)
                    ),
                    unexpected_columns=tuple(
                        sorted(actual_columns - set(expected_fields))
                    ),
                    nullable_mismatches=tuple(sorted(nullable_mismatches)),
                    foreign_key_mismatches=tuple(sorted(foreign_key_mismatches)),
                    constraint_mismatches=tuple(sorted(set(constraint_mismatches))),
                    index_mismatches=tuple(sorted(set(index_mismatches))),
                )
            )

    return tuple(reports)


def run_schema_gate(*, using="default"):
    """Return migration graph/history and physical-schema status without writes."""

    connection = connections[using]
    try:
        connection.ensure_connection()
        executor = MigrationExecutor(connection)
        pending = tuple(
            f"{migration.app_label}.{migration.name}"
            for migration, backwards in executor.migration_plan(
                executor.loader.graph.leaf_nodes()
            )
            if not backwards
        )
        model_state_changes = _detect_unmigrated_model_changes(executor)
        conflicts = tuple(
            sorted(
                f"{app}: {', '.join(sorted(names))}"
                for app, names in executor.loader.detect_conflicts().items()
            )
        )
        applied = set(MigrationRecorder(connection).applied_migrations())
        migration_files = set(executor.loader.disk_migrations)
        history_without_files = tuple(
            sorted(f"{app}.{name}" for app, name in applied - migration_files)
        )
        reports = audit_managed_models(using=using)
        return SchemaGateResult(
            database=using,
            vendor=connection.vendor,
            pending_migrations=pending,
            model_state_changes=model_state_changes,
            migration_conflicts=conflicts,
            history_without_files=history_without_files,
            model_reports=reports,
        )
    except Exception as exc:  # Fail closed; callers show the stable admin message.
        return SchemaGateResult(
            database=using,
            vendor=getattr(connection, "vendor", "unknown"),
            error=f"{type(exc).__name__}: {exc}",
        )


def assert_schema_gate(*, using="default"):
    result = run_schema_gate(using=using)
    if not result.clean:
        raise SchemaGateError(ADMIN_SCHEMA_MESSAGE)
    return result


def startup_schema_gate_message(result):
    """Build an actionable startup error without exposing database credentials."""

    details = []
    if result.pending_migrations:
        details.append("pending migracije: " + ", ".join(result.pending_migrations))
    if result.model_state_changes:
        details.append(
            "model izmjene bez migracije: " + ", ".join(result.model_state_changes)
        )
    if result.migration_conflicts:
        details.append("migration konflikti: " + " | ".join(result.migration_conflicts))
    if result.history_without_files:
        details.append(
            "migration historija bez fajla: "
            + ", ".join(result.history_without_files)
        )
    if result.issue_reports:
        affected = []
        for report in result.issue_reports:
            problems = []
            if report.missing_table:
                problems.append("nedostaje tabela")
            if report.missing_columns:
                problems.append("nedostaju kolone " + ", ".join(report.missing_columns))
            if report.unexpected_columns:
                problems.append(
                    "neočekivane kolone " + ", ".join(report.unexpected_columns)
                )
            if report.nullable_mismatches:
                problems.append("nullability mismatch")
            if report.foreign_key_mismatches:
                problems.append("foreign-key mismatch")
            if report.constraint_mismatches:
                problems.append("constraint mismatch")
            if report.index_mismatches:
                problems.append("index mismatch")
            affected.append(f"{report.table} ({'; '.join(problems)})")
        details.append("fizička schema: " + " | ".join(affected))
    if result.error:
        details.append("provjera nije izvršena: " + result.error)
    suffix = "; ".join(details) or "nepoznato odstupanje"
    return (
        f"{ADMIN_SCHEMA_MESSAGE} Detalji: {suffix}. "
        "Pokrenite 'python manage.py migrate --noinput', zatim "
        "'python manage.py check_schema_gate'."
    )


def assert_startup_schema_gate(*, using="default"):
    """Stop WSGI startup before a request can hit an incompatible schema."""

    result = run_schema_gate(using=using)
    if not result.clean:
        raise SchemaGateError(startup_schema_gate_message(result))
    return result
