(function () {
    "use strict";

    function pad(value) {
        return String(value).padStart(2, "0");
    }

    function validDateParts(day, month, year) {
        if (!Number.isInteger(day) || !Number.isInteger(month) || !Number.isInteger(year)) {
            return false;
        }
        const candidate = new Date(year, month - 1, day, 12, 0, 0);
        return (
            candidate.getFullYear() === year
            && candidate.getMonth() === month - 1
            && candidate.getDate() === day
        );
    }

    function parseDateParts(value) {
        if (value instanceof Date && !Number.isNaN(value.getTime())) {
            return {
                day: value.getDate(),
                month: value.getMonth() + 1,
                year: value.getFullYear()
            };
        }
        if (value === null || value === undefined || value === "") return null;

        const text = String(value).trim();
        let match = text.match(/^(\d{4})-(\d{2})-(\d{2})(?:[T\s]|$)/);
        let day;
        let month;
        let year;
        if (match) {
            year = Number(match[1]);
            month = Number(match[2]);
            day = Number(match[3]);
        } else {
            match = text.match(/^(\d{1,2})[/.](\d{1,2})[/.](\d{4})(?:\s|$)/);
            if (!match) return null;
            day = Number(match[1]);
            month = Number(match[2]);
            year = Number(match[3]);
        }
        return validDateParts(day, month, year) ? {day, month, year} : null;
    }

    function formatTheraFlowDate(value, emptyValue) {
        const parts = parseDateParts(value);
        if (!parts) return emptyValue === undefined ? "" : emptyValue;
        return `${pad(parts.day)}/${pad(parts.month)}/${parts.year}`;
    }

    function toISODate(value) {
        const parts = parseDateParts(value);
        if (!parts) return "";
        return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}`;
    }

    function parseTimeParts(value) {
        if (value instanceof Date && !Number.isNaN(value.getTime())) {
            return {
                hour: value.getHours(),
                minute: value.getMinutes(),
                second: value.getSeconds()
            };
        }
        const text = String(value || "").trim();
        const match = text.match(/[T\s](\d{1,2}):(\d{2})(?::(\d{2}))?/);
        if (!match) return null;
        const hour = Number(match[1]);
        const minute = Number(match[2]);
        const second = Number(match[3] || 0);
        if (hour > 23 || minute > 59 || second > 59) return null;
        return {hour, minute, second};
    }

    function formatTheraFlowDateTime(value, options) {
        if (value === null || value === undefined || value === "") return "";
        const settings = options || {};
        let dateValue = value;
        if (
            typeof value === "string"
            && /(?:Z|[+-]\d{2}:\d{2})$/.test(value)
        ) {
            const parsed = new Date(value);
            if (!Number.isNaN(parsed.getTime())) dateValue = parsed;
        }
        const dateParts = parseDateParts(dateValue);
        const timeParts = parseTimeParts(dateValue);
        if (!dateParts || !timeParts) return "";
        const seconds = settings.seconds ? `:${pad(timeParts.second)}` : "";
        return (
            `${pad(dateParts.day)}/${pad(dateParts.month)}/${dateParts.year} `
            + `${pad(timeParts.hour)}:${pad(timeParts.minute)}${seconds}`
        );
    }

    function datePartsToLocalDate(value) {
        const parts = parseDateParts(value);
        return parts
            ? new Date(parts.year, parts.month - 1, parts.day, 12, 0, 0)
            : null;
    }

    function setDateInputValue(input, value) {
        if (!input) return;
        const formatted = formatTheraFlowDate(value);
        input.value = formatted || "";
        input.dataset.isoValue = formatted ? toISODate(formatted) : "";
        input.setCustomValidity("");
        const picker = input.parentElement?.querySelector(".tf-date-native-picker");
        if (picker) picker.value = input.dataset.isoValue;
    }

    function autoInsertSlashes(value) {
        const digits = value.replace(/\D/g, "").slice(0, 8);
        if (digits.length !== 8) return value;
        return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
    }

    function enhanceDateInput(input) {
        if (input.dataset.theraflowDateEnhanced === "true") return;
        const initial = input.getAttribute("value") || input.value;
        const wasRequired = input.required;
        const minimum = input.min;
        const maximum = input.max;
        input.type = "text";
        input.placeholder = "DD/MM/YYYY";
        input.inputMode = "numeric";
        input.autocomplete = "off";
        input.dataset.theraflowDateEnhanced = "true";
        setDateInputValue(input, initial);

        const wrapper = document.createElement("span");
        wrapper.className = "tf-date-input";
        input.parentNode.insertBefore(wrapper, input);
        wrapper.appendChild(input);

        const picker = document.createElement("input");
        picker.type = "date";
        picker.className = "tf-date-native-picker";
        picker.tabIndex = -1;
        picker.setAttribute("aria-hidden", "true");
        picker.value = input.dataset.isoValue || "";
        if (minimum) picker.min = minimum;
        if (maximum) picker.max = maximum;

        const button = document.createElement("button");
        button.type = "button";
        button.className = "tf-date-picker-button";
        button.setAttribute("aria-label", "Odaberi datum");
        button.innerHTML = '<i class="bi bi-calendar3"></i>';
        wrapper.appendChild(button);
        wrapper.appendChild(picker);

        input.addEventListener("input", function () {
            input.setCustomValidity("");
            const formatted = autoInsertSlashes(input.value);
            if (formatted !== input.value) input.value = formatted;
        });
        input.addEventListener("blur", function () {
            if (!input.value.trim() && !wasRequired) {
                input.dataset.isoValue = "";
                return;
            }
            const iso = toISODate(input.value);
            if (!iso) {
                input.setCustomValidity(
                    input.value.trim()
                        ? "Datum nije ispravan."
                        : "Unesite datum u formatu DD/MM/YYYY."
                );
                return;
            }
            setDateInputValue(input, iso);
        });
        picker.addEventListener("change", function () {
            setDateInputValue(input, picker.value);
            input.dispatchEvent(new Event("change", {bubbles: true}));
        });
        button.addEventListener("click", function () {
            picker.value = toISODate(input.value);
            if (typeof picker.showPicker === "function") picker.showPicker();
            else picker.click();
        });
    }

    function prepareDateInputsForSubmit(form, event) {
        if (event.defaultPrevented) return;
        const inputs = form.querySelectorAll(
            'input[data-theraflow-date-enhanced="true"]'
        );
        const prepared = [];
        for (const input of inputs) {
            if (!input.value.trim() && !input.required) continue;
            const iso = toISODate(input.value);
            if (!iso) {
                event.preventDefault();
                input.setCustomValidity(
                    input.value.trim()
                        ? "Datum nije ispravan."
                        : "Unesite datum u formatu DD/MM/YYYY."
                );
                input.reportValidity();
                input.focus();
                return;
            }
            prepared.push({input, iso});
        }
        for (const item of prepared) {
            item.input.dataset.displayValue = item.input.value;
            item.input.value = item.iso;
        }
    }

    function enhanceDateInputs(root) {
        (root || document).querySelectorAll('input[type="date"]').forEach(enhanceDateInput);
        (root || document).querySelectorAll("form").forEach(function (form) {
            if (form.dataset.theraflowDateSubmit === "true") return;
            form.dataset.theraflowDateSubmit = "true";
            form.addEventListener("submit", function (event) {
                prepareDateInputsForSubmit(form, event);
            });
        });
    }

    window.TheraFlowDates = {
        parseDateParts,
        datePartsToLocalDate,
        formatDate: formatTheraFlowDate,
        formatDateTime: formatTheraFlowDateTime,
        toISODate,
        setDateInputValue,
        enhanceDateInputs
    };
    window.formatTheraFlowDate = formatTheraFlowDate;
    window.formatTheraFlowDateTime = formatTheraFlowDateTime;

    document.addEventListener("DOMContentLoaded", function () {
        enhanceDateInputs(document);
    });
})();
