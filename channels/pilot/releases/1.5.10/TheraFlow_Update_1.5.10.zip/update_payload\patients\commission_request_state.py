"""Jedinstveno operativno stanje komisijskog zahtjeva.

TheraFlow trenutno čuva pripremu zahtjeva u ``KomisijskiZahtjev`` zapisu, a
odobrenje, zaprimanje i fizičku raspodjelu u kompatibilnom ``Trebovanje``
zapisu.  Ovaj modul je jedino mjesto koje ta dva sloja prevodi u stanje koje
smiju prikazivati karton, modal, Zalihe i Zaprimanje.
"""

from dataclasses import dataclass
from decimal import Decimal

from django.core.exceptions import ObjectDoesNotExist


DRAFT = "DRAFT"
CONFIRMED = "CONFIRMED"
SENT = "SENT"
APPROVED = "APPROVED"
PARTIALLY_RECEIVED = "PARTIALLY_RECEIVED"
RECEIVED = "RECEIVED"
REJECTED = "REJECTED"


@dataclass(frozen=True)
class CommissionRequestState:
    code: str
    title: str
    status_label: str
    badge_label: str
    next_action: str
    tone: str
    request_quantity: Decimal
    approved_quantity: Decimal
    received_quantity: Decimal
    awaiting_receipt_quantity: Decimal

    @property
    def display_quantity(self):
        if self.code in {APPROVED, PARTIALLY_RECEIVED, RECEIVED}:
            return self.approved_quantity or self.request_quantity
        return self.request_quantity

    @property
    def blocks_duplicate_request(self):
        return self.code not in {REJECTED, RECEIVED}

    @property
    def is_approved_awaiting_receipt(self):
        return (
            self.code in {APPROVED, PARTIALLY_RECEIVED}
            and self.awaiting_receipt_quantity > 0
        )


_PRESENTATION = {
    DRAFT: (
        "Prijedlog u pripremi",
        "Prijedlog u pripremi",
        "U pripremi",
        "Dovršiti pripremu zahtjeva",
        "amber",
    ),
    CONFIRMED: (
        "Zahtjev je spreman za komisiju",
        "Zahtjev potvrđen – čeka slanje",
        "Čeka slanje",
        "Poslati komisiji",
        "amber",
    ),
    SENT: (
        "Zahtjev je poslan komisiji",
        "Poslano komisiji – čeka odluku",
        "Čeka odluku",
        "Pratiti odluku komisije",
        "blue",
    ),
    APPROVED: (
        "Zahtjev je odobren",
        "Odobreno – čeka zaprimanje",
        "Čeka zaprimanje",
        "Zaprimiti isporuku",
        "amber",
    ),
    PARTIALLY_RECEIVED: (
        "Pošiljka je djelimično zaprimljena",
        "Djelimično zaprimljeno",
        "Djelimično zaprimljeno",
        "Zaprimiti preostalu količinu",
        "amber",
    ),
    RECEIVED: (
        "Zahtjev je realizovan",
        "Zaprimljeno i fizički raspoređeno",
        "Zaprimljeno",
        "Nije potrebna trenutna akcija",
        "green",
    ),
    REJECTED: (
        "Zahtjev nije odobren",
        "Zahtjev nije odobren",
        "Odbijeno",
        "Pregledati odluku komisije",
        "red",
    ),
}


def _decimal(value):
    return max(Decimal("0"), Decimal(str(value or 0)))


def _phase2_requested_quantity(request, medicine_ids=()):
    if request is None:
        return Decimal("0")
    items = tuple(
        item
        for item in request.stavke_lijeka.all()
        if not medicine_ids or item.lijek_id in medicine_ids
    )
    item_quantity = sum(
        (_decimal(item.kolicina) for item in items),
        Decimal("0"),
    )
    return item_quantity or _decimal(
        request.finalna_kolicina
        if request.finalna_kolicina is not None
        else request.ljekar_trazi
        if request.ljekar_trazi is not None
        else request.sistem_predlozio
    )


def _phase2_approved_quantity(request, medicine_ids=()):
    if request is None:
        return Decimal("0")
    return sum(
        (
            _decimal(item.odobrena_kolicina)
            for item in request.stavke_lijeka.all()
            if (not medicine_ids or item.lijek_id in medicine_ids)
            and item.odobrena_kolicina is not None
        ),
        Decimal("0"),
    )


def resolve_commission_request_state(
    *,
    phase2_request=None,
    legacy_request=None,
    medicine_ids=(),
):
    """Vrati najnaprednije stvarno stanje jednog pacijentovog zahtjeva.

    ``Trebovanje`` ima prednost za odobrenje i zaprimanje jer je upravo taj
    zapis zaključan i ažuriran u fizičkom receipt toku. Phase‑2 status ostaje
    izvor za pripremu/slanje dok operativni zapis nije napredovao dalje.
    """

    medicine_ids = frozenset(medicine_ids or ())
    requested = _phase2_requested_quantity(phase2_request, medicine_ids)
    if legacy_request is not None:
        requested = _decimal(
            legacy_request.broj_doza
            or legacy_request.sistemski_prijedlog
            or requested
        )

    approved = _phase2_approved_quantity(phase2_request, medicine_ids)
    received = Decimal("0")
    legacy_status = str(getattr(legacy_request, "status", "") or "")
    phase2_status = str(getattr(phase2_request, "status", "") or "")
    if legacy_request is not None:
        received = _decimal(legacy_request.zaprimljene_doze)
        if legacy_request.odobrene_doze is not None:
            approved = _decimal(legacy_request.odobrene_doze)
        elif legacy_status in {
            "ODOBRENO",
            "DJELOMICNO_ODOBRENO",
            "CEKA_ISPORUKU",
            "ZAPRIMLJENO",
        }:
            approved = requested

    # Fizički incoming može obuhvatiti samo stvarno naručenu količinu.
    # Više odobreno komisijsko pravo ostaje administrativni izvor i ne smije
    # se drugi put računati kao roba na putu.
    ordered_for_delivery = min(approved, requested)
    awaiting = max(Decimal("0"), ordered_for_delivery - received)

    agreement_decision = ""
    if phase2_request is not None:
        try:
            agreement_decision = str(phase2_request.saglasnost.odluka or "")
        except (AttributeError, ObjectDoesNotExist):
            agreement_decision = ""

    if legacy_status in {"ODBIJENO", "OTKAZANO"} or agreement_decision == "odbijeno":
        code = REJECTED
    elif legacy_status == "ZAPRIMLJENO" or (
        approved > 0 and received >= approved
    ):
        code = RECEIVED
    elif received > 0:
        code = PARTIALLY_RECEIVED
    elif legacy_status in {
        "ODOBRENO",
        "DJELOMICNO_ODOBRENO",
        "CEKA_ISPORUKU",
    } or agreement_decision in {"odobreno", "djelimicno_odobreno"}:
        code = APPROVED
    elif legacy_status in {"PREDATO", "POSLAN_KOMISIJI"} or phase2_status in {
        "poslan",
        "ceka_saglasnost",
    }:
        code = SENT
    elif legacy_status == "SPREMAN" or phase2_status == "potvrdjen":
        code = CONFIRMED
    else:
        code = DRAFT

    title, status_label, badge, action, tone = _PRESENTATION[code]
    return CommissionRequestState(
        code=code,
        title=title,
        status_label=status_label,
        badge_label=badge,
        next_action=action,
        tone=tone,
        request_quantity=requested,
        approved_quantity=approved,
        received_quantity=received,
        awaiting_receipt_quantity=awaiting,
    )
