"""Minimalni generički fazni engine; prva konfiguracija je ustekinumab."""

from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal, InvalidOperation, ROUND_CEILING

from django.core.exceptions import ValidationError
from django.db import connection, transaction
from django.db.models import Sum
from django.utils import timezone

from .medication_groups import (
    medicine_group_key,
    medicine_presentation_key,
    strict_equivalent_medicine_ids,
)
from .models import (
    FazniProtokolPacijenta,
    Komisija,
    KomisijskaStavkaLijeka,
    KomisijskiZahtjev,
    Pacijent,
    PacijentRezervacija,
    TerapijskaFaza,
    Terapija,
    TerapijskiProtokol,
    Zaliha,
)
from .utils import upisi_log


PHASED_PROTOCOLS = {
    FazniProtokolPacijenta.PROTOKOL_USTEKINUMAB: {
        "generic_name": "Ustekinumab",
        "induction": {
            "route": "IV",
            "presentation_mg": Decimal("130"),
        },
        "first_sc": {
            "route": "SC",
            "presentation_mg": Decimal("90"),
            "dose_mg": Decimal("90"),
            "units": 1,
            "after_weeks": 8,
        },
        "maintenance": {
            "route": "SC",
            "presentation_mg": Decimal("90"),
            "dose_mg": Decimal("90"),
            "units": 1,
            "allowed_intervals": (8, 12),
        },
    }
}

USTEKINUMAB_IV_TO_SC_PROTOCOL_NAME = (
    "Ustekinumab – IV indukcija → SC održavanje"
)


def ustekinumab_iv_to_sc_protocol(iv_medicine):
    """Vrati aktivni legacy mapping za fazni Ustekinumab protokol.

    Fazni engine ostaje klinički source-of-truth. Ovaj zapis daje formi i
    Pacijent.terapijski_protokol stabilan FK umjesto praznog dropdowna.
    """

    if not iv_medicine:
        return None
    return (
        TerapijskiProtokol.objects.filter(
            lijek=iv_medicine,
            naziv=USTEKINUMAB_IV_TO_SC_PROTOCOL_NAME,
            aktivan=True,
        )
        .order_by("pk")
        .first()
    )


def _decimal(value, label):
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValidationError(f"{label} mora biti broj.") from exc
    if result <= 0:
        raise ValidationError(f"{label} mora biti veća od nule.")
    return result


def ustekinumab_iv_logistics(prescribed_dose_mg, iv_medicine):
    """Pretvori ljekarski propisanu dozu u fizičke jedinice, bez kliničkog izračuna."""

    prescribed_dose = _decimal(
        prescribed_dose_mg,
        "Početna IV doza određena od ljekara",
    )
    if not iv_medicine or iv_medicine.put_primjene != "IV":
        raise ValidationError(
            "Logistički broj bočica nije moguće izračunati: "
            "Podaci o IV lijeku nisu potpuni."
        )
    try:
        presentation_mg = Decimal(str(iv_medicine.jacina_mg))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValidationError(
            "Logistički broj bočica nije moguće izračunati: "
            "jačina IV lijeka nije konfigurisana."
        ) from exc
    if presentation_mg <= 0:
        raise ValidationError(
            "Logistički broj bočica nije moguće izračunati: "
            "jačina IV lijeka mora biti veća od nule."
        )
    units = int(
        (prescribed_dose / presentation_mg).to_integral_value(
            rounding=ROUND_CEILING
        )
    )
    return {
        "prescribed_dose_mg": prescribed_dose,
        "presentation_mg": presentation_mg,
        "units": units,
        "route": iv_medicine.put_primjene,
    }


def _validate_presentation(medicine, *, strength, route, label):
    if not medicine or medicine_group_key(medicine) != "ustekinumab":
        raise ValidationError(f"{label} mora pripadati generičkom lijeku ustekinumab.")
    expected = f"ustekinumab:{route}:{Decimal(str(strength)):g}"
    if medicine_presentation_key(medicine) != expected:
        raise ValidationError(
            f"{label} mora biti ustekinumab {Decimal(str(strength)):g} mg {route}."
        )


def _select_for_update_self(queryset):
    """Zaključaj state red, ne read-only redove učitane kroz select_related."""

    if connection.features.has_select_for_update_of:
        return queryset.select_for_update(of=("self",))
    return queryset.select_for_update()


def phased_protocol_for_patient(patient, *, lock=False):
    if not patient or not getattr(patient, "pk", None):
        return None
    queryset = FazniProtokolPacijenta.objects.filter(
        pacijent=patient,
        aktivan=True,
    ).select_related(
        "pacijent",
        "iv_lijek",
        "sc_lijek",
        "terapijski_program",
        "trenutna_faza",
        "pocetni_komisijski_zahtjev",
    )
    if lock:
        # PostgreSQL ne dopušta FOR UPDATE nad nullable stranom LEFT OUTER
        # JOIN-a. Ovdje mijenjamo samo FazniProtokolPacijenta, pa zaključavamo
        # isključivo njegov red; povezani nullable zapisi ostaju read-only.
        if connection.features.has_select_for_update_of:
            queryset = _select_for_update_self(queryset)
        else:
            locked_pk = (
                FazniProtokolPacijenta.objects.select_for_update()
                .filter(pacijent=patient, aktivan=True)
                .values_list("pk", flat=True)
                .first()
            )
            if locked_pk is None:
                return None
            return queryset.get(pk=locked_pk)
    return queryset.first()


def protocol_state_snapshot(state):
    return {
        "faza": state.faza,
        "tezina_kg": str(state.tezina_kg) if state.tezina_kg is not None else None,
        "tezina_izmjerena_at": (
            state.tezina_izmjerena_at.isoformat()
            if state.tezina_izmjerena_at else None
        ),
        "indukcijska_doza_mg": (
            str(state.indukcijska_doza_mg)
            if state.indukcijska_doza_mg is not None else None
        ),
        "indukcijski_broj_jedinica": state.indukcijski_broj_jedinica,
        "interval_odrzavanja_sedmica": state.interval_odrzavanja_sedmica,
        "sc_nacin_primjene": state.sc_nacin_primjene,
        "kucna_terapija_od": (
            state.kucna_terapija_od.isoformat()
            if state.kucna_terapija_od else None
        ),
        "kucna_terapija_potvrdio_id": state.kucna_terapija_potvrdio_id,
        "zadnji_povratak_u_ambulantu_at": (
            state.zadnji_povratak_u_ambulantu_at.isoformat()
            if state.zadnji_povratak_u_ambulantu_at else None
        ),
        "zadnji_povratak_u_ambulantu_evidentirao_id": (
            state.zadnji_povratak_u_ambulantu_evidentirao_id
        ),
        "datum_iv_primjene": (
            state.datum_iv_primjene.isoformat() if state.datum_iv_primjene else None
        ),
        "datum_prve_sc_primjene": (
            state.datum_prve_sc_primjene.isoformat()
            if state.datum_prve_sc_primjene else None
        ),
        "datum_posljednje_primjene": (
            state.datum_posljednje_primjene.isoformat()
            if state.datum_posljednje_primjene else None
        ),
        "sljedeci_datum": (
            state.sljedeci_datum.isoformat() if state.sljedeci_datum else None
        ),
    }


def current_phase_details(state):
    configured_label = (
        state.trenutna_faza.naziv if state.trenutna_faza_id else None
    )
    if state.faza == state.FAZA_CEKA_IV:
        return {
            "phase": state.faza,
            "label": configured_label or "IV indukcija",
            "medicine": state.iv_lijek,
            "dose_mg": state.indukcijska_doza_mg,
            "units": Decimal(str(state.indukcijski_broj_jedinica or 0)),
            "interval_weeks": None,
        }
    if state.faza == state.FAZA_CEKA_PRVU_SC:
        return {
            "phase": state.faza,
            "label": configured_label or "Prijelaz — čeka prvu SC nakon indukcije",
            "medicine": state.sc_lijek,
            "dose_mg": Decimal("90"),
            "units": Decimal("1"),
            "interval_weeks": 8,
        }
    return {
        "phase": state.faza,
        "label": configured_label or "SC održavanje",
        "medicine": state.sc_lijek,
        "dose_mg": Decimal("90"),
        "units": Decimal("1"),
        "interval_weeks": state.interval_odrzavanja_sedmica,
    }


def phase_scheduling_readiness(state):
    """Provjeri administrativnu i fizičku spremnost trenutne faze.

    Za IV indukciju datum nije uslov: spremnost određuju potvrđena količina,
    pacijentovo preostalo pravo i već dodijeljena fizička rezervacija. Slobodna
    zaliha drugog pacijenta ne pretvara se automatski u rezervaciju.
    """

    if not state:
        return {
            "ready": False,
            "required": Decimal("0"),
            "reserved": Decimal("0"),
            "approved_remaining": Decimal("0"),
            "available": Decimal("0"),
            "reason": "Pacijent nema aktivan fazni protokol.",
        }
    details = current_phase_details(state)
    medicine = details["medicine"]
    required = Decimal(str(details["units"] or 0))
    medicine_ids = strict_equivalent_medicine_ids(medicine)
    reserved = Decimal(str(
        PacijentRezervacija.objects.filter(
            pacijent=state.pacijent,
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
        ).aggregate(total=Sum("kolicina"))["total"] or 0
    ))
    approved_remaining = Decimal(str(
        Komisija.objects.filter(
            pacijent=state.pacijent,
            lijek_id__in=medicine_ids,
            status__in=Komisija.VAZECI_STATUSI,
            preostale_doze__gt=0,
        ).aggregate(total=Sum("preostale_doze"))["total"] or 0
    ))
    available = min(reserved, approved_remaining)
    ready = bool(required > 0 and reserved >= required and approved_remaining >= required)
    if required <= 0:
        reason = "Unesite odobrenu količinu IV indukcije."
    elif not ready and state.faza == state.FAZA_CEKA_IV:
        reason = (
            f"Za IV indukciju potrebno {required:g}, dostupno {available:g} "
            f"{medicine.jedinica_zalihe_za_kolicinu(available)}."
        )
    else:
        reason = ""
    return {
        "ready": ready,
        "required": required,
        "reserved": reserved,
        "approved_remaining": approved_remaining,
        "available": available,
        "reason": reason,
    }


def therapy_event_phase_label(details):
    """Label završenog terapijskog događaja, ne stanje prije potvrde."""

    if details["phase"] == FazniProtokolPacijenta.FAZA_CEKA_PRVU_SC:
        return Terapija.UstekinumabFaza.IV_U_SC_PRIJELAZ.label
    if details["phase"] == FazniProtokolPacijenta.FAZA_ODRZAVANJE:
        return Terapija.UstekinumabFaza.SC_ODRZAVANJE.label
    return details["label"]


def phase_confirmation_description(details):
    """Siguran opis faznog koraka za ekran potvrde dolaska.

    Kod migriranih IV indukcija broj bočica može biti potvrđen bez historijske
    mg doze. ``None`` je tada stvarno "nije evidentirano", a ne nula.
    """

    label = details["label"]
    dose_mg = details.get("dose_mg")
    units = Decimal(str(details.get("units") or 0))
    medicine = details.get("medicine")
    unit_label = (
        medicine.jedinica_zalihe_za_kolicinu(units)
        if medicine and units > 0
        else "jedinica"
    )
    if dose_mg is None:
        return (
            f"{label} — {units:g} {unit_label}; doza u mg: Nije evidentirano"
            if units > 0
            else f"{label} — količina: Nije evidentirano"
        )
    if units <= 0:
        return f"{label} — {dose_mg:g} mg; količina: Nije evidentirano"
    return f"{label} — {dose_mg:g} mg / {units:g} {unit_label}"


def ustekinumab_home_issuance_available(state):
    """Kućno izdavanje je opcija tek nakon evidentirane prve SC doze."""

    return bool(
        state
        and state.aktivan
        and state.protokol_kljuc
        == FazniProtokolPacijenta.PROTOKOL_USTEKINUMAB
        and state.faza == state.FAZA_ODRZAVANJE
        and state.datum_prve_sc_primjene
    )


def commission_authorization_medicine_ids(state, medicine):
    """Vrati SKU-e koji mogu nositi pravo za trenutnu faznu primjenu.

    Fizička zaliha i rezervacija uvijek ostaju vezane za tačnu prezentaciju.
    Jedini most prava je aktivni ustekinumab protokol nakon IV indukcije: važeće
    pravo evidentirano na IV prezentaciji može pokriti planiranu SC primjenu istog
    protokola. Time se ne proglašavaju IV bočice fizičkim SC ekvivalentom.
    """

    current_ids = set(strict_equivalent_medicine_ids(medicine))
    if (
        not state
        or not state.aktivan
        or state.protokol_kljuc != FazniProtokolPacijenta.PROTOKOL_USTEKINUMAB
        or state.faza == state.FAZA_CEKA_IV
        or not state.sc_lijek_id
        or medicine.pk != state.sc_lijek_id
    ):
        return tuple(sorted(current_ids))

    current_ids.update(strict_equivalent_medicine_ids(state.iv_lijek))
    current_ids.update(strict_equivalent_medicine_ids(state.sc_lijek))
    return tuple(sorted(current_ids))


@dataclass(frozen=True)
class PhasedPlanningConfiguration:
    """Read-only ugovor između faznog protokola i logističkog planera."""

    state: object
    planning_possible: bool
    reason: str
    phase: str
    phase_label: str
    medicine: object | None
    prescribed_dose_mg: Decimal | None
    units: Decimal
    interval_weeks: int | None
    relative_initial_projection: bool


def phased_planning_configuration(patient):
    """Validiraj autoritativno fazno stanje bez izmišljanja kliničkih podataka.

    ``None`` znači da pacijent nema aktivni fazni protokol i da ga treba
    obraditi legacy protocol engine. Nevalidno postojeće fazno stanje vraća
    strukturiran razlog za ekran "Potrebna provjera".
    """

    try:
        state = patient.fazni_protokol
    except FazniProtokolPacijenta.DoesNotExist:
        return None
    if not state.aktivan:
        return None

    details = current_phase_details(state)

    def invalid(reason):
        return PhasedPlanningConfiguration(
            state=state,
            planning_possible=False,
            reason=reason,
            phase=state.faza,
            phase_label=details["label"],
            medicine=details["medicine"],
            prescribed_dose_mg=details["dose_mg"],
            units=Decimal(str(details["units"] or 0)),
            interval_weeks=details["interval_weeks"],
            relative_initial_projection=(state.faza == state.FAZA_CEKA_IV),
        )

    if state.protokol_kljuc not in PHASED_PROTOCOLS:
        return invalid(
            f"Fazni engine '{state.protokol_kljuc}' nije konfigurisan."
        )
    if not state.terapijski_program_id:
        return invalid("Terapijski program faznog protokola nije konfigurisan.")
    if patient.terapijski_program_id != state.terapijski_program_id:
        return invalid("Terapijski program pacijenta i faznog protokola nisu usklađeni.")
    if not state.trenutna_faza_id:
        return invalid("Trenutna faza terapijskog programa nije konfigurirana.")
    if (
        state.trenutna_faza.program_id != state.terapijski_program_id
        or state.trenutna_faza.kljuc != state.faza
        or not state.trenutna_faza.aktivna
    ):
        return invalid("Trenutna faza ne pripada aktivnoj fazi terapijskog programa.")

    medicine = details["medicine"]
    if not medicine:
        return invalid("Podaci o lijeku trenutne faze nisu potpuni.")
    if patient.lijek_id != medicine.pk:
        return invalid("Lijek pacijenta ne odgovara lijeku trenutne faze.")
    if state.trenutna_faza.lijek_id != medicine.pk:
        return invalid("Faza terapijskog programa koristi drugi lijek i pakovanje.")

    if state.faza == state.FAZA_CEKA_IV:
        try:
            logistics = ustekinumab_iv_logistics(
                state.indukcijska_doza_mg,
                medicine,
            )
        except ValidationError as exc:
            return invalid(" ".join(exc.messages))
        stored_units = Decimal(str(state.indukcijski_broj_jedinica or 0))
        if stored_units != Decimal(str(logistics["units"])):
            return invalid(
                "Sačuvani broj IV bočica ne odgovara propisanoj dozi i jačini lijeka."
            )
    else:
        try:
            _validate_presentation(
                medicine,
                strength=90,
                route="SC",
                label="SC prezentacija",
            )
        except ValidationError as exc:
            return invalid(" ".join(exc.messages))
        if Decimal(str(details["units"] or 0)) <= 0:
            return invalid("Količina trenutne faze mora biti veća od nule.")
        if not state.sljedeci_datum:
            return invalid("Datum sljedeće primjene faznog protokola nije konfigurisan.")
        if int(details["interval_weeks"] or 0) <= 0:
            return invalid("Interval trenutne faze nije konfigurisan.")

    return PhasedPlanningConfiguration(
        state=state,
        planning_possible=True,
        reason="",
        phase=state.faza,
        phase_label=details["label"],
        medicine=medicine,
        prescribed_dose_mg=details["dose_mg"],
        units=Decimal(str(details["units"])),
        interval_weeks=details["interval_weeks"],
        relative_initial_projection=(state.faza == state.FAZA_CEKA_IV),
    )


@transaction.atomic
def configure_ustekinumab_protocol(
    *,
    patient,
    iv_medicine,
    sc_medicine,
    phase,
    maintenance_interval,
    user=None,
    prescribed_iv_dose_mg=None,
    induction_units=None,
    allow_missing_iv_dose=False,
    last_actual_date=None,
):
    patient = Pacijent.objects.select_for_update().get(pk=patient.pk)
    logistics = None
    if prescribed_iv_dose_mg not in (None, ""):
        logistics = ustekinumab_iv_logistics(
            prescribed_iv_dose_mg,
            iv_medicine,
        )
    manual_induction_units = None
    if induction_units not in (None, ""):
        parsed_units = _decimal(
            induction_units,
            "Odobrena količina za IV indukciju",
        )
        if parsed_units != parsed_units.to_integral_value():
            raise ValidationError(
                "Odobrena količina za IV indukciju mora biti cijeli broj bočica."
            )
        manual_induction_units = int(parsed_units)
    _validate_presentation(
        iv_medicine,
        strength=130,
        route="IV",
        label="IV prezentacija",
    )
    _validate_presentation(
        sc_medicine,
        strength=90,
        route="SC",
        label="SC prezentacija",
    )
    if phase not in dict(FazniProtokolPacijenta.FAZE):
        raise ValidationError("Odaberite ispravnu fazu protokola.")
    maintenance_interval = int(maintenance_interval)
    if maintenance_interval not in (8, 12):
        raise ValidationError("Interval održavanja mora biti 8 ili 12 sedmica.")

    if phase == FazniProtokolPacijenta.FAZA_CEKA_IV:
        if logistics is None and not allow_missing_iv_dose:
            raise ValidationError(
                "Unesite početnu IV dozu koju je odredio ljekar."
            )

    existing = phased_protocol_for_patient(patient, lock=True)
    previous = protocol_state_snapshot(existing) if existing else None
    state = existing or FazniProtokolPacijenta(
        pacijent=patient,
        kreirao=user if getattr(user, "is_authenticated", False) else None,
    )
    state.protokol_kljuc = state.PROTOKOL_USTEKINUMAB
    state.faza = phase
    state.terapijski_program = patient.terapijski_program
    state.trenutna_faza = TerapijskaFaza.objects.filter(
        program=patient.terapijski_program,
        kljuc=phase,
        aktivna=True,
    ).first()
    state.iv_lijek = iv_medicine
    state.sc_lijek = sc_medicine
    state.interval_odrzavanja_sedmica = maintenance_interval
    if phase != state.FAZA_ODRZAVANJE:
        state.sc_nacin_primjene = state.SC_NACIN_AMBULANTA
    if logistics is not None:
        state.indukcijska_doza_mg = logistics["prescribed_dose_mg"]
        state.indukcijski_broj_jedinica = logistics["units"]
    elif manual_induction_units is not None:
        # Migracija zatečenog pacijenta čuva ručno potvrđenu fizičku količinu
        # IV prezentacije. Ne izmišlja mg dozu niti radi kalkulator težine.
        state.indukcijska_doza_mg = None
        state.indukcijski_broj_jedinica = manual_induction_units
    elif not existing:
        state.indukcijska_doza_mg = None
        state.indukcijski_broj_jedinica = None
    state.aktivan = True
    state.izmijenio = user if getattr(user, "is_authenticated", False) else None

    if phase == state.FAZA_CEKA_IV:
        state.datum_iv_primjene = None
        state.datum_prve_sc_primjene = None
        state.datum_posljednje_primjene = None
        state.sljedeci_datum = None
    elif phase == state.FAZA_CEKA_PRVU_SC:
        if not last_actual_date:
            raise ValidationError(
                "Za fazu 'čeka prvu SC' unesite datum stvarne IV primjene."
            )
        state.datum_iv_primjene = last_actual_date
        state.datum_prve_sc_primjene = None
        state.datum_posljednje_primjene = last_actual_date
        state.sljedeci_datum = last_actual_date + timedelta(weeks=8)
    else:
        if not last_actual_date:
            raise ValidationError(
                "Za održavanje unesite datum zadnje stvarne SC doze."
            )
        state.datum_posljednje_primjene = last_actual_date
        state.sljedeci_datum = last_actual_date + timedelta(
            weeks=maintenance_interval
        )
    state.full_clean()
    state.save()

    # Legacy/current-SKU FK prati proizvod trenutne faze. Autoritativni identitet
    # terapije ostaje Pacijent.terapijski_program i ne mijenja se pri IV -> SC.
    current_product = current_phase_details(state)["medicine"]
    if patient.lijek_id != current_product.pk:
        patient.lijek = current_product
        patient.interval_sedmica = maintenance_interval
        patient.save(update_fields=["lijek", "interval_sedmica"])

    current = protocol_state_snapshot(state)
    upisi_log(
        user,
        "Postavljeno stanje faznog protokola",
        pacijent=patient,
        objekat=state,
        opis=(
            "Ljekar potvrđuje ustekinumab protokol. "
            f"Prije: {previous}; poslije: {current}."
        ),
    )
    return state


@transaction.atomic
def change_maintenance_interval(*, state, interval_weeks, user=None, reason=""):
    state = _select_for_update_self(
        FazniProtokolPacijenta.objects.select_related("pacijent")
    ).get(pk=state.pk)
    interval_weeks = int(interval_weeks)
    if interval_weeks not in (8, 12):
        raise ValidationError("Interval održavanja mora biti 8 ili 12 sedmica.")
    if state.faza != state.FAZA_ODRZAVANJE:
        raise ValidationError("Interval se mijenja tek u fazi SC održavanja.")
    reason = (reason or "").strip()
    if not reason:
        raise ValidationError("Razlog promjene intervala je obavezan.")
    previous = protocol_state_snapshot(state)
    state.interval_odrzavanja_sedmica = interval_weeks
    state.izmijenio = user if getattr(user, "is_authenticated", False) else None
    if state.datum_posljednje_primjene:
        state.sljedeci_datum = state.datum_posljednje_primjene + timedelta(
            weeks=interval_weeks
        )
    state.save(
        update_fields=[
            "interval_odrzavanja_sedmica",
            "sljedeci_datum",
            "izmijenio",
            "izmijenjeno",
        ]
    )
    state.pacijent.interval_sedmica = interval_weeks
    state.pacijent.save(update_fields=["interval_sedmica"])
    upisi_log(
        user,
        "Promjena intervala faznog protokola",
        pacijent=state.pacijent,
        objekat=state,
        opis=(
            f"Razlog: {reason}. Prije: {previous}; "
            f"poslije: {protocol_state_snapshot(state)}."
        ),
    )
    return state


def ustekinumab_sc_transition_summary(state):
    """Read-only sažetak potreban prije odluke o mjestu SC primjene."""

    if not state:
        return None
    from .medication_groups import strict_equivalent_medicine_ids

    sc_ids = strict_equivalent_medicine_ids(state.sc_lijek)
    ambulatory_sc = Terapija.objects.filter(
        pacijent=state.pacijent,
        lijek_id__in=sc_ids,
        tip_evidencije=Terapija.TIP_AMBULANTA,
        workflow_status=Terapija.STATUS_POTVRDJENA,
        is_migration=False,
    ).order_by("-datum", "-pk")
    return {
        "therapy": "Ustekinumab",
        "product": state.sc_lijek,
        "ambulatory_sc_count": ambulatory_sc.count(),
        "last_ambulatory_sc": ambulatory_sc.first(),
        "next_expected_dose": state.sljedeci_datum,
        "current_mode": state.sc_nacin_primjene,
        "current_mode_label": state.get_sc_nacin_primjene_display(),
    }


def _record_sc_mode_change(*, state, previous_mode, new_mode, user, reason):
    from .models import TerapijaStatusHistorija
    from .therapy_workflow import record_status_history

    event_type = (
        TerapijaStatusHistorija.DOGADJAJ_SC_KUCNA_TERAPIJA
        if new_mode == state.SC_NACIN_KUCNA
        else TerapijaStatusHistorija.DOGADJAJ_SC_AMBULANTNA_TERAPIJA
    )
    return record_status_history(
        pacijent=state.pacijent,
        previous_status=previous_mode,
        new_status=new_mode,
        reason=reason,
        user=user,
        previous_state={
            "tip_dogadjaja": event_type,
            "terapija": "Ustekinumab",
            "faza": state.faza,
            "nacin_primjene": previous_mode,
        },
        new_state={
            "tip_dogadjaja": event_type,
            "terapija": "Ustekinumab",
            "faza": state.faza,
            "nacin_primjene": new_mode,
            "lijek_naziv": state.sc_lijek.prikaz_naziv,
        },
        event_type=event_type,
    )


@transaction.atomic
def transition_ustekinumab_sc_to_home(*, state, user=None):
    """Prebaci jednog pacijenta na kućnu SC primjenu i ugasi buduće termine."""

    from .models import Pacijent, Termin
    from .therapy_workflow import cancel_therapy

    patient = Pacijent.objects.select_for_update().get(pk=state.pacijent_id)
    state = _select_for_update_self(
        FazniProtokolPacijenta.objects.select_related("sc_lijek", "pacijent")
    ).get(pk=state.pk, pacijent=patient, aktivan=True)
    if state.faza != state.FAZA_ODRZAVANJE:
        raise ValidationError(
            "Kućna terapija je dostupna tek u fazi SC održavanja."
        )
    if state.sc_je_kucna_terapija:
        return state, 0

    previous_mode = state.sc_nacin_primjene
    changed_at = timezone.now()
    state.sc_nacin_primjene = state.SC_NACIN_KUCNA
    state.kucna_terapija_od = changed_at
    state.kucna_terapija_potvrdio = (
        user if getattr(user, "is_authenticated", False) else None
    )
    state.izmijenio = state.kucna_terapija_potvrdio
    state.full_clean()
    state.save(update_fields=[
        "sc_nacin_primjene",
        "kucna_terapija_od",
        "kucna_terapija_potvrdio",
        "izmijenio",
        "izmijenjeno",
    ])

    future_appointments = list(
        Termin.objects.filter(
            pacijent=patient,
            lijek_id__in=strict_equivalent_medicine_ids(state.sc_lijek),
            status=Termin.STATUS_PLANIRANA,
            datum__gte=timezone.localdate(),
        ).order_by("datum", "vrijeme", "pk")
    )
    reason = (
        "Pacijent je nakon edukacije prebačen na samostalnu SC primjenu kod kuće."
    )
    for appointment in future_appointments:
        cancel_therapy(
            termin=appointment,
            reason=(
                "Otkazano zbog prelaska sa SC primjene u ambulanti na kućnu terapiju."
            ),
            user=user,
        )
    _record_sc_mode_change(
        state=state,
        previous_mode=previous_mode,
        new_mode=state.SC_NACIN_KUCNA,
        user=user,
        reason=reason,
    )
    upisi_log(
        user,
        "Ustekinumab SC – prelazak na kućnu terapiju",
        pacijent=patient,
        objekat=state,
        opis=(
            f"Datum prelaska {changed_at:%d/%m/%Y %H:%M}; "
            f"{state.get_sc_nacin_primjene_display()}; otkazano budućih "
            f"ambulantnih termina: {len(future_appointments)}."
        ),
    )
    return state, len(future_appointments)


@transaction.atomic
def return_ustekinumab_sc_to_ambulatory(*, state, user=None):
    """Vrati način primjene bez brisanja izdavanja ili automatskog termina."""

    from .models import Pacijent

    patient = Pacijent.objects.select_for_update().get(pk=state.pacijent_id)
    state = _select_for_update_self(
        FazniProtokolPacijenta.objects.select_related("sc_lijek", "pacijent")
    ).get(pk=state.pk, pacijent=patient, aktivan=True)
    if state.faza != state.FAZA_ODRZAVANJE:
        raise ValidationError(
            "Ambulantni SC režim se mijenja samo u fazi održavanja."
        )
    if not state.sc_je_kucna_terapija:
        return state, False

    previous_mode = state.sc_nacin_primjene
    returned_at = timezone.now()
    state.sc_nacin_primjene = state.SC_NACIN_AMBULANTA
    state.zadnji_povratak_u_ambulantu_at = returned_at
    state.zadnji_povratak_u_ambulantu_evidentirao = (
        user if getattr(user, "is_authenticated", False) else None
    )
    state.izmijenio = state.zadnji_povratak_u_ambulantu_evidentirao
    state.full_clean()
    state.save(update_fields=[
        "sc_nacin_primjene",
        "zadnji_povratak_u_ambulantu_at",
        "zadnji_povratak_u_ambulantu_evidentirao",
        "izmijenio",
        "izmijenjeno",
    ])
    reason = (
        "Pacijent je vraćen na SC primjenu u ambulanti; novi termin nije automatski kreiran."
    )
    _record_sc_mode_change(
        state=state,
        previous_mode=previous_mode,
        new_mode=state.SC_NACIN_AMBULANTA,
        user=user,
        reason=reason,
    )
    upisi_log(
        user,
        "Ustekinumab SC – povratak u ambulantu",
        pacijent=patient,
        objekat=state,
        opis=(
            f"Datum povratka {returned_at:%d/%m/%Y %H:%M}; kućna izdavanja "
            "i historija su sačuvani; novi termin nije kreiran."
        ),
    )
    return state, True


@transaction.atomic
def create_ustekinumab_commission_proposal(
    *,
    state,
    cycle,
    request_type,
    include_first_sc,
    user=None,
    previous_medicine=None,
):
    state = _select_for_update_self(
        FazniProtokolPacijenta.objects.select_related(
            "pacijent", "iv_lijek", "sc_lijek"
        )
    ).get(pk=state.pk)
    if state.faza != state.FAZA_CEKA_IV or not state.indukcijski_broj_jedinica:
        raise ValidationError(
            "Komisijski indukcijski prijedlog je dostupan prije IV indukcije."
        )
    if request_type not in {
        KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_NOVI,
        KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH,
    }:
        raise ValidationError("Ustekinumab početni prijedlog mora biti novi ili switch.")

    total = Decimal(str(state.indukcijski_broj_jedinica))
    if include_first_sc:
        total += Decimal("1")
    request, _created = KomisijskiZahtjev.objects.update_or_create(
        komisijski_ciklus=cycle,
        pacijent=state.pacijent,
        defaults={
            "vrsta_zahtjeva": request_type,
            "status": KomisijskiZahtjev.Status.NACRT,
            "sistem_predlozio": total,
            "ljekar_trazi": total,
            "finalna_kolicina": total,
            "prethodni_lijek": (
                previous_medicine
                if request_type
                == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH
                else None
            ),
            "novi_lijek": state.sc_lijek,
            "napomena": (
                "Sistem predlaže prema aktivnom ustekinumab protokolu; "
                "ljekar potvrđuje količine po prezentaciji."
            ),
        },
    )
    request.stavke_lijeka.all().delete()
    KomisijskaStavkaLijeka.objects.create(
        komisijski_zahtjev=request,
        lijek=state.iv_lijek,
        jacina="130 mg",
        oblik="IV bočica",
        kolicina=Decimal(str(state.indukcijski_broj_jedinica)),
        jedinica=KomisijskaStavkaLijeka.Jedinica.FLAKON,
        redoslijed=1,
    )
    if include_first_sc:
        KomisijskaStavkaLijeka.objects.create(
            komisijski_zahtjev=request,
            lijek=state.sc_lijek,
            jacina="90 mg",
            oblik="SC prezentacija",
            kolicina=Decimal("1"),
            jedinica=KomisijskaStavkaLijeka.Jedinica.FLAKON,
            redoslijed=2,
        )
    state.pocetni_komisijski_zahtjev = request
    state.izmijenio = user if getattr(user, "is_authenticated", False) else None
    state.save(
        update_fields=[
            "pocetni_komisijski_zahtjev",
            "izmijenio",
            "izmijenjeno",
        ]
    )
    upisi_log(
        user,
        "Kreiran ustekinumab komisijski prijedlog",
        pacijent=state.pacijent,
        objekat=request,
        opis=(
            f"Ljekar potvrđuje prijedlog: {state.indukcijski_broj_jedinica} × "
            f"130 mg IV{' + 1 × 90 mg SC' if include_first_sc else ''}."
        ),
    )
    return request


def _reservation_total(patient, medicine_ids):
    return Decimal(
        str(
            PacijentRezervacija.objects.filter(
                pacijent=patient,
                lijek_id__in=medicine_ids,
                aktivno=True,
                kolicina__gt=0,
            ).aggregate(total=Sum("kolicina"))["total"]
            or 0
        )
    )


@transaction.atomic
def ensure_phase_reservation(*, state, appointment, user=None):
    state = _select_for_update_self(
        FazniProtokolPacijenta.objects.select_related(
            "pacijent", "iv_lijek", "sc_lijek"
        )
    ).get(pk=state.pk)
    details = current_phase_details(state)
    medicine = details["medicine"]
    if appointment.lijek_id != medicine.pk:
        raise ValidationError("Termin ne koristi prezentaciju trenutne faze.")
    if state.sljedeci_datum != appointment.datum:
        state.sljedeci_datum = appointment.datum
        state.izmijenio = user if getattr(user, "is_authenticated", False) else None
        state.save(
            update_fields=["sljedeci_datum", "izmijenio", "izmijenjeno"]
        )
    required = Decimal(str(details["units"]))
    medicine_ids = strict_equivalent_medicine_ids(medicine)
    existing = _reservation_total(state.pacijent, medicine_ids)
    missing = max(Decimal("0"), required - existing)
    if missing <= 0:
        return None, False
    from .inventory import reserve_physical_stock

    result = reserve_physical_stock(
        pacijent=state.pacijent,
        lijek=medicine,
        quantity=missing,
        termin=appointment,
        priority_date=appointment.datum,
        user=user,
        note=(
            f"Fazni ustekinumab protokol; termin #{appointment.pk}; "
            f"{details['label']}."
        ),
    )
    return result["reservation"], bool(result["allocated"])


def consume_phase_reservations(*, patient, medicine, quantity):
    quantity = Decimal(str(quantity))
    medicine_ids = strict_equivalent_medicine_ids(medicine)
    reservations = list(
        PacijentRezervacija.objects.select_for_update()
        .filter(
            pacijent=patient,
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
        )
        .order_by("datum_rezervacije", "id")
    )
    available = sum(
        (Decimal(str(item.kolicina or 0)) for item in reservations),
        Decimal("0"),
    )
    if available < quantity:
        raise ValidationError(
            f"Nema dovoljno rezervisanih jedinica. Rezervisano {available:g}, "
            f"potrebno {quantity:g}."
        )
    remaining = quantity
    changes = []
    for reservation in reservations:
        if remaining <= 0:
            break
        before = Decimal(str(reservation.kolicina or 0))
        consumed = min(before, remaining)
        reservation.kolicina = before - consumed
        reservation.aktivno = reservation.kolicina > 0
        reservation.save(update_fields=["kolicina", "aktivno"])
        changes.append(
            {"rezervacija_id": reservation.pk, "kolicina": str(consumed)}
        )
        remaining -= consumed
    return changes


@transaction.atomic
def advance_protocol_after_therapy(*, state, therapy, user=None):
    state = _select_for_update_self(
        FazniProtokolPacijenta.objects.select_related(
            "pacijent",
            "iv_lijek",
            "sc_lijek",
            "terapijski_program",
            "trenutna_faza",
        )
    ).get(pk=state.pk)
    details = current_phase_details(state)
    if therapy.lijek_id != details["medicine"].pk:
        raise ValidationError("Primijenjena je pogrešna prezentacija za trenutnu fazu.")
    if Decimal(str(therapy.kolicina)) != Decimal(str(details["units"])):
        raise ValidationError("Primijenjena količina ne odgovara potvrđenoj fazi protokola.")
    previous = protocol_state_snapshot(state)

    # Terapija čuva kratki, stabilni kod; display label se zapisuje u njen
    # workflow snapshot i nikada se ne upisuje u VARCHAR(20) kolonu.
    therapy.faza_terapije = details["phase"]
    therapy.workflow_snapshot = {
        **(therapy.workflow_snapshot or {}),
        "fazni_protokol_id": state.pk,
        "faza_terapije_label": therapy_event_phase_label(details),
    }
    therapy.doza_mg = details["dose_mg"]
    if state.faza == state.FAZA_CEKA_IV:
        state.datum_iv_primjene = therapy.datum
        state.datum_posljednje_primjene = therapy.datum
        state.faza = state.FAZA_CEKA_PRVU_SC
        state.sljedeci_datum = therapy.datum + timedelta(weeks=8)
    elif state.faza == state.FAZA_CEKA_PRVU_SC:
        state.datum_prve_sc_primjene = therapy.datum
        state.datum_posljednje_primjene = therapy.datum
        state.faza = state.FAZA_ODRZAVANJE
        state.sljedeci_datum = therapy.datum + timedelta(
            weeks=state.interval_odrzavanja_sedmica
        )
    else:
        state.datum_posljednje_primjene = therapy.datum
        state.sljedeci_datum = therapy.datum + timedelta(
            weeks=state.interval_odrzavanja_sedmica
        )
    state.trenutna_faza = TerapijskaFaza.objects.filter(
        program=state.terapijski_program,
        kljuc=state.faza,
        aktivna=True,
    ).first()
    state.izmijenio = user if getattr(user, "is_authenticated", False) else None
    state.save()
    next_product = current_phase_details(state)["medicine"]
    if state.pacijent.lijek_id != next_product.pk:
        state.pacijent.lijek = next_product
        state.pacijent.save(update_fields=["lijek"])
    therapy.interval_sedmica = (
        8
        if previous["faza"] == state.FAZA_CEKA_IV
        else state.interval_odrzavanja_sedmica
    )
    therapy.save(
        update_fields=[
            "faza_terapije",
            "workflow_snapshot",
            "doza_mg",
            "interval_sedmica",
        ]
    )
    current = protocol_state_snapshot(state)
    upisi_log(
        user,
        "Napredovanje faznog protokola",
        pacijent=state.pacijent,
        objekat=state,
        opis=f"Stvarna primjena #{therapy.pk}. Prije: {previous}; poslije: {current}.",
    )
    return {
        "state_before": previous,
        "state_after": current,
        "next": current_phase_details(state),
        "next_date": state.sljedeci_datum,
    }


@transaction.atomic
def restore_protocol_state(*, state_id, snapshot, user=None, reason=""):
    state = _select_for_update_self(
        FazniProtokolPacijenta.objects.select_related(
            "pacijent",
            "terapijski_program",
            "trenutna_faza",
            "iv_lijek",
            "sc_lijek",
        )
    ).get(pk=state_id)
    from datetime import datetime

    date_fields = (
        "datum_iv_primjene",
        "datum_prve_sc_primjene",
        "datum_posljednje_primjene",
        "sljedeci_datum",
    )
    state.faza = snapshot["faza"]
    state.trenutna_faza = TerapijskaFaza.objects.filter(
        program=state.terapijski_program,
        kljuc=state.faza,
        aktivna=True,
    ).first()
    state.tezina_kg = snapshot.get("tezina_kg")
    state.indukcijska_doza_mg = snapshot.get("indukcijska_doza_mg")
    state.indukcijski_broj_jedinica = snapshot.get("indukcijski_broj_jedinica")
    state.interval_odrzavanja_sedmica = snapshot[
        "interval_odrzavanja_sedmica"
    ]
    state.sc_nacin_primjene = snapshot.get(
        "sc_nacin_primjene",
        state.SC_NACIN_AMBULANTA,
    )
    measured = snapshot.get("tezina_izmjerena_at")
    state.tezina_izmjerena_at = datetime.fromisoformat(measured) if measured else None
    home_started = snapshot.get("kucna_terapija_od")
    state.kucna_terapija_od = (
        datetime.fromisoformat(home_started) if home_started else None
    )
    state.kucna_terapija_potvrdio_id = snapshot.get(
        "kucna_terapija_potvrdio_id"
    )
    returned_at = snapshot.get("zadnji_povratak_u_ambulantu_at")
    state.zadnji_povratak_u_ambulantu_at = (
        datetime.fromisoformat(returned_at) if returned_at else None
    )
    state.zadnji_povratak_u_ambulantu_evidentirao_id = snapshot.get(
        "zadnji_povratak_u_ambulantu_evidentirao_id"
    )
    for field in date_fields:
        value = snapshot.get(field)
        setattr(state, field, datetime.fromisoformat(value).date() if value else None)
    state.izmijenio = user if getattr(user, "is_authenticated", False) else None
    state.save()
    restored_product = current_phase_details(state)["medicine"]
    if state.pacijent.lijek_id != restored_product.pk:
        state.pacijent.lijek = restored_product
        state.pacijent.save(update_fields=["lijek"])
    upisi_log(
        user,
        "Vraćeno stanje faznog protokola",
        pacijent=state.pacijent,
        objekat=state,
        opis=f"Kontrolisano poništavanje: {reason}.",
    )
    return state


def _configure_ustekinumab_program(
    *,
    patient,
    program,
    phase,
    current_product=None,
    maintenance_interval=8,
    user=None,
    prescribed_iv_dose_mg=None,
    induction_units=None,
    allow_missing_iv_dose=False,
    last_actual_date=None,
):
    phases = {
        item.kljuc: item
        for item in TerapijskaFaza.objects.filter(
            program=program,
            aktivna=True,
        ).select_related("lijek")
    }
    iv_phase = phases.get(FazniProtokolPacijenta.FAZA_CEKA_IV)
    first_sc_phase = phases.get(FazniProtokolPacijenta.FAZA_CEKA_PRVU_SC)
    maintenance_phase = phases.get(FazniProtokolPacijenta.FAZA_ODRZAVANJE)
    if not iv_phase or not first_sc_phase or not maintenance_phase:
        raise ValidationError("Terapijski program nema kompletno konfigurirane faze.")

    iv_medicine = iv_phase.lijek
    sc_medicine = maintenance_phase.lijek
    if current_product:
        if current_product.put_primjene == "IV":
            iv_medicine = current_product
        elif current_product.put_primjene == "SC":
            sc_medicine = current_product
    return configure_ustekinumab_protocol(
        patient=patient,
        iv_medicine=iv_medicine,
        sc_medicine=sc_medicine,
        phase=phase.kljuc,
        maintenance_interval=maintenance_interval,
        user=user,
        prescribed_iv_dose_mg=prescribed_iv_dose_mg,
        induction_units=induction_units,
        allow_missing_iv_dose=allow_missing_iv_dose,
        last_actual_date=last_actual_date,
    )


PHASED_PROGRAM_HANDLERS = {
    "ustekinumab": _configure_ustekinumab_program,
}


def configure_program_protocol(
    *,
    patient,
    program,
    phase=None,
    current_product=None,
    maintenance_interval=8,
    user=None,
    prescribed_iv_dose_mg=None,
    induction_units=None,
    allow_missing_iv_dose=False,
    last_actual_date=None,
):
    """Generički ulaz: registry bira engine, forma ne poznaje konkretan lijek."""

    if not program or not program.protokol_kljuc:
        return None
    handler = PHASED_PROGRAM_HANDLERS.get(program.protokol_kljuc)
    if not handler:
        raise ValidationError(
            f"Nije registriran fazni engine '{program.protokol_kljuc}'."
        )
    if phase is None:
        phase = (
            TerapijskaFaza.objects.filter(program=program, aktivna=True)
            .select_related("lijek")
            .order_by("redoslijed", "pk")
            .first()
        )
    if not phase:
        raise ValidationError("Terapijski program nema aktivnu početnu fazu.")
    return handler(
        patient=patient,
        program=program,
        phase=phase,
        current_product=current_product,
        maintenance_interval=maintenance_interval,
        user=user,
        prescribed_iv_dose_mg=prescribed_iv_dose_mg,
        induction_units=induction_units,
        allow_missing_iv_dose=allow_missing_iv_dose,
        last_actual_date=last_actual_date,
    )


def protocol_display_data(state):
    if not state:
        return None
    details = current_phase_details(state)
    iv_stock = Zaliha.objects.filter(lijek=state.iv_lijek).first()
    sc_stock = Zaliha.objects.filter(lijek=state.sc_lijek).first()
    last_therapy = (
        Terapija.objects.filter(
            pacijent=state.pacijent,
            workflow_status=Terapija.STATUS_POTVRDJENA,
            tip_evidencije=Terapija.TIP_AMBULANTA,
            lijek_id__in=(state.iv_lijek_id, state.sc_lijek_id),
        )
        .order_by("-datum", "-id")
        .first()
    )
    if state.faza == state.FAZA_ODRZAVANJE:
        active_regimen = (
            f"Ustekinumab 90 mg SC / {state.interval_odrzavanja_sedmica} sedmica"
        )
    elif details["dose_mg"] is None and details["units"]:
        active_regimen = (
            f"{details['medicine'].brand_name} "
            f"{details['medicine'].presentation_strength_label} IV · "
            f"odobrena IV doza: {details['units']:g} "
            f"{details['medicine'].jedinica_zalihe_za_kolicinu(details['units'])}"
        )
    elif details["dose_mg"] is None:
        active_regimen = "IV indukcija — odobrena količina nije evidentirana"
    elif not details["units"]:
        active_regimen = (
            f"{details['dose_mg']:g} mg IV — logistički obračun nije moguć"
        )
    else:
        active_regimen = (
            f"{details['dose_mg']:g} mg {details['medicine'].put_primjene}"
        )
    transition_summary = ustekinumab_sc_transition_summary(state)
    is_home = state.sc_je_kucna_terapija
    is_waiting_iv = state.faza == state.FAZA_CEKA_IV
    is_waiting_first_sc = state.faza == state.FAZA_CEKA_PRVU_SC
    is_maintenance = state.faza == state.FAZA_ODRZAVANJE
    current_medicine = details["medicine"]
    scheduling_readiness = phase_scheduling_readiness(state)
    current_stock = (
        sc_stock
        if current_medicine and current_medicine.pk == state.sc_lijek_id
        else iv_stock
    )
    phase_label = (
        "SC terapija održavanja"
        if state.faza == state.FAZA_ODRZAVANJE
        else details["label"]
    )
    return {
        "state": state,
        "phase": details,
        "phase_label": phase_label,
        "is_waiting_iv": is_waiting_iv,
        "is_waiting_first_sc": is_waiting_first_sc,
        "is_maintenance": is_maintenance,
        "current_product": current_medicine,
        "current_quantity": details["units"],
        "maintenance_interval": state.interval_odrzavanja_sedmica,
        "active_regimen": active_regimen,
        "last_therapy": last_therapy,
        "next_date": None if is_home else state.sljedeci_datum,
        "next_expected_dose": state.sljedeci_datum,
        "is_home_sc": is_home,
        "current_location": (
            "Ambulanta — IV primjena"
            if is_waiting_iv else
            "Kućna terapija"
            if is_home else
            "Ambulanta — SC primjena"
        ),
        "can_issue_home": ustekinumab_home_issuance_available(state),
        "administration_mode": state.get_sc_nacin_primjene_display(),
        "education_status": (
            "Samostalna primjena potvrđena"
            if is_home else
            "Edukacija za samostalnu primjenu u toku"
            if state.faza == state.FAZA_ODRZAVANJE else
            "Nije primjenjivo u trenutnoj fazi"
        ),
        "transition_summary": transition_summary,
        "iv_stock": Decimal(str(iv_stock.u_frizideru or 0)) if iv_stock else Decimal("0"),
        "sc_stock": Decimal(str(sc_stock.u_frizideru or 0)) if sc_stock else Decimal("0"),
        "current_stock": (
            Decimal(str(current_stock.u_frizideru or 0))
            if current_stock else Decimal("0")
        ),
        "patient_reserved": scheduling_readiness["reserved"],
        "approved_remaining": scheduling_readiness["approved_remaining"],
        "scheduling_readiness": scheduling_readiness,
        "commission_request": state.pocetni_komisijski_zahtjev,
    }
