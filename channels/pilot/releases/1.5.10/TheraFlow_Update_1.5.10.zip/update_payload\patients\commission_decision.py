"""Finalna komisijska odluka za sve UI potrošače.

Coverage i eligibility servisi računaju kliničku potrebu i siguran ciklus.
Ovaj modul ih pretvara u jednu, nedvosmislenu odluku koju karton, modal i
Komisijski centar smiju prikazati bez ponovnog tumačenja količina.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from .package_sizes import procurement_breakdown
from .commission_request_state import (
    APPROVED,
    CONFIRMED,
    DRAFT,
    PARTIALLY_RECEIVED,
    RECEIVED,
    REJECTED,
    SENT,
)


INCLUDE_IN_COMMISSION = "INCLUDE_IN_COMMISSION"
ALREADY_PLANNED = "ALREADY_PLANNED"
REQUEST_CONFIRMED = "REQUEST_CONFIRMED"
REQUEST_SUBMITTED = "REQUEST_SUBMITTED"
REQUEST_DECIDED = "REQUEST_DECIDED"
REQUEST_APPROVED = "REQUEST_APPROVED"
REQUEST_PARTIALLY_RECEIVED = "REQUEST_PARTIALLY_RECEIVED"
REQUEST_RECEIVED = "REQUEST_RECEIVED"
REQUEST_REJECTED = "REQUEST_REJECTED"
FORECAST_NEXT_CYCLE = "FORECAST_NEXT_CYCLE"
NOT_REQUIRED = "NOT_REQUIRED"


_DRAFT_STATUSES = frozenset({
    "NACRT",
    "SPREMAN",
    "U_PRIPREMI",
    "nacrt",
})
_CONFIRMED_STATUSES = frozenset({
    "POTVRDJEN",
    "potvrdjen",
})
_SUBMITTED_STATUSES = frozenset({
    "PREDATO",
    "POSLAN_KOMISIJI",
    "poslan",
    "ceka_saglasnost",
})
_DECIDED_STATUSES = frozenset({
    "ODOBRENO",
    "DJELOMICNO_ODOBRENO",
    "CEKA_ISPORUKU",
    "ZAPRIMLJENO",
    "odluceno",
})


def _decimal(value):
    return Decimal(str(value or 0))


@dataclass(frozen=True)
class CommissionDecision:
    minimum_required_quantity: Decimal
    gross_required_quantity: Decimal
    physically_covered_quantity: Decimal
    confirmed_delivery_quantity: Decimal
    existing_request_quantity: Decimal
    existing_request_cycle: date | None
    existing_request_status: str | None
    existing_request_status_label: str
    existing_request_state_code: str
    existing_request_approved_quantity: Decimal
    existing_request_received_quantity: Decimal
    existing_request_awaiting_receipt_quantity: Decimal
    usable_existing_approval_quantity: Decimal
    additional_quantity_current_cycle: Decimal
    forecast_quantity_next_cycle: Decimal
    forecast_cycle: date | None
    safety_reserve_quantity: Decimal
    calculated_quantity: Decimal
    rounded_quantity: Decimal
    existing_proposal_quantity: Decimal | None
    displayed_quantity: Decimal
    decision_status: str
    cycle_date: date | None
    period_start: date | None
    period_end: date | None
    first_uncovered_dose: date | None
    reasons: tuple[str, ...]
    base_period_end: date | None
    effective_period_end: date | None
    period_extension_reason: str
    doses_used_in_calculation: tuple[date, ...]
    procurement: dict
    existing_request_procurement: dict
    additional_procurement: dict
    forecast_procurement: dict
    status_label: str
    action_label: str
    recommendation_text: str
    badge_label: str
    current_status_label: str
    status_tone: str
    subject_label: str
    why_button_label: str

    def __post_init__(self):
        if self.period_start is not None and self.period_end is not None:
            assert self.period_start <= self.period_end, (
                "Komisijski period ne može završiti prije svog početka: "
                f"{self.period_start} > {self.period_end}."
            )
        if self.period_end is not None:
            assert all(
                dose_date <= self.period_end
                for dose_date in self.doses_used_in_calculation
            ), (
                "Doza korištena u komisijskom obračunu izlazi izvan "
                f"efektivnog kraja perioda {self.period_end}."
            )
        if self.displayed_quantity == 0:
            assert self.rounded_quantity == 0, (
                "Prikazana količina smije biti 0 samo kada je zaokružena "
                "potreba 0 i nema aktivnog prijedloga ili zahtjeva."
            )
            assert not self.existing_proposal_quantity, (
                "Aktivni prijedlog ili zahtjev ne smije biti prikazan kao 0."
            )
        assert self.additional_quantity_current_cycle >= 0
        assert self.forecast_quantity_next_cycle >= 0
        if (
            self.existing_request_cycle is not None
            and self.forecast_cycle == self.existing_request_cycle
        ):
            assert self.forecast_quantity_next_cycle == 0, (
                "Isti zahtjev ne smije biti prikazan i kao postojeći zahtjev "
                "i kao buduća procjena."
            )

    @property
    def is_action_required(self):
        return self.decision_status in {
            INCLUDE_IN_COMMISSION,
            REQUEST_CONFIRMED,
        }

    @property
    def is_already_planned(self):
        return self.decision_status in {
            ALREADY_PLANNED,
            REQUEST_CONFIRMED,
            REQUEST_SUBMITTED,
            REQUEST_DECIDED,
            REQUEST_APPROVED,
            REQUEST_PARTIALLY_RECEIVED,
            REQUEST_RECEIVED,
            REQUEST_REJECTED,
        }


def build_commission_decision(
    *,
    medicine,
    calculated_quantity,
    rounded_quantity,
    cycle_date,
    period_start,
    base_period_end,
    calculated_period_end,
    first_uncovered_dose,
    doses_used_in_calculation=(),
    existing_proposal_quantity=None,
    existing_request_quantity=None,
    existing_request_status=None,
    existing_cycle_date=None,
    existing_status_label="",
    existing_request_state=None,
    existing_request_approved_quantity=0,
    existing_request_received_quantity=0,
    existing_request_awaiting_receipt_quantity=0,
    minimum_required_quantity=None,
    gross_required_quantity=None,
    physically_covered_quantity=0,
    confirmed_delivery_quantity=0,
    usable_existing_approval_quantity=0,
    additional_quantity_current_cycle=None,
    forecast_quantity_next_cycle=0,
    forecast_cycle=None,
    safety_reserve_quantity=0,
    reasons=(),
):
    """Spoji izračun i postojeći zahtjev u jednu finalnu UI odluku."""

    calculated = max(Decimal("0"), _decimal(calculated_quantity))
    rounded = max(Decimal("0"), _decimal(rounded_quantity))
    existing_input = (
        existing_request_quantity
        if existing_request_quantity is not None
        else existing_proposal_quantity
    )
    existing = (
        max(Decimal("0"), _decimal(existing_input))
        if existing_input is not None
        else None
    )
    existing_quantity = existing or Decimal("0")
    minimum_required = max(
        Decimal("0"),
        _decimal(
            minimum_required_quantity
            if minimum_required_quantity is not None
            else calculated
        ),
    )
    gross_required = max(
        Decimal("0"),
        _decimal(
            gross_required_quantity
            if gross_required_quantity is not None
            else calculated
        ),
    )
    physically_covered = max(
        Decimal("0"), _decimal(physically_covered_quantity)
    )
    confirmed_delivery = max(
        Decimal("0"), _decimal(confirmed_delivery_quantity)
    )
    usable_approval = max(
        Decimal("0"), _decimal(usable_existing_approval_quantity)
    )
    safety_reserve = max(
        Decimal("0"), _decimal(safety_reserve_quantity)
    )
    additional = max(
        Decimal("0"),
        _decimal(
            additional_quantity_current_cycle
            if additional_quantity_current_cycle is not None
            else max(Decimal("0"), rounded - existing_quantity)
        ),
    )
    forecast_quantity = max(
        Decimal("0"), _decimal(forecast_quantity_next_cycle)
    )
    if existing_cycle_date is not None and forecast_cycle == existing_cycle_date:
        forecast_quantity = Decimal("0")
        forecast_cycle = None
    dose_dates = tuple(sorted(set(doses_used_in_calculation or ())))
    effective_candidates = tuple(
        value
        for value in (
            base_period_end,
            calculated_period_end,
            dose_dates[-1] if dose_dates else None,
        )
        if value is not None
    )
    effective_end = max(effective_candidates) if effective_candidates else None

    extension_reason = ""
    if (
        base_period_end is not None
        and effective_end is not None
        and effective_end > base_period_end
    ):
        extension_reason = (
            f"Osnovni kraj perioda {base_period_end:%d/%m/%Y} produžen je do "
            f"{effective_end:%d/%m/%Y} jer protokolarne doze korištene u "
            "obračunu moraju ostati unutar prikazanog perioda."
        )

    status = str(existing_request_status or "") or None
    request_state_code = str(
        getattr(existing_request_state, "code", "") or ""
    )
    request_approved = max(
        Decimal("0"), _decimal(existing_request_approved_quantity)
    )
    request_received = max(
        Decimal("0"), _decimal(existing_request_received_quantity)
    )
    request_awaiting = max(
        Decimal("0"), _decimal(existing_request_awaiting_receipt_quantity)
    )
    if existing_quantity > 0 and status:
        displayed = existing_quantity
        effective_cycle_date = existing_cycle_date or cycle_date
        existing_status_display = existing_status_label or status
        existing_procurement = procurement_breakdown(existing_quantity, medicine)
        if request_state_code:
            status_label = existing_request_state.title
            action_label = existing_request_state.next_action
            badge_label = existing_request_state.badge_label
            current_status_label = existing_request_state.status_label
            status_tone = existing_request_state.tone
            if request_state_code == DRAFT:
                decision_status = ALREADY_PLANNED
            elif request_state_code == CONFIRMED:
                decision_status = REQUEST_CONFIRMED
            elif request_state_code == SENT:
                decision_status = REQUEST_SUBMITTED
            elif request_state_code == APPROVED:
                decision_status = REQUEST_APPROVED
            elif request_state_code == PARTIALLY_RECEIVED:
                decision_status = REQUEST_PARTIALLY_RECEIVED
            elif request_state_code == RECEIVED:
                decision_status = REQUEST_RECEIVED
            elif request_state_code == REJECTED:
                decision_status = REQUEST_REJECTED
            else:
                decision_status = REQUEST_DECIDED
            if request_state_code == APPROVED:
                recommendation_text = (
                    f"Zahtjev za {existing_procurement['display_text']} je "
                    "odobren i čeka fizičko zaprimanje."
                )
            elif request_state_code == PARTIALLY_RECEIVED:
                recommendation_text = (
                    f"Zahtjev za {existing_procurement['display_text']} je "
                    "djelimično zaprimljen; preostalu količinu treba zaprimiti."
                )
            elif request_state_code == RECEIVED:
                recommendation_text = (
                    f"Zahtjev za {existing_procurement['display_text']} je "
                    "zaprimljen i fizički raspoređen."
                )
            elif request_state_code == REJECTED:
                recommendation_text = (
                    f"Zahtjev za {existing_procurement['display_text']} nije odobren."
                )
            else:
                recommendation_text = (
                    f"{existing_request_state.status_label}: "
                    f"{existing_procurement['display_text']}."
                )
        elif status in _DRAFT_STATUSES:
            decision_status = ALREADY_PLANNED
            status_label = "Već planirano za komisiju"
            action_label = "Dovršite pripremu zahtjeva"
            recommendation_text = (
                f"Zahtjev za {existing_procurement['display_text']} već je "
                "pripremljen u nacrtu."
            )
            badge_label = "U pripremi"
            current_status_label = "Zahtjev je u pripremi"
            status_tone = "amber"
        elif status in _CONFIRMED_STATUSES:
            decision_status = REQUEST_CONFIRMED
            status_label = "Zahtjev je spreman za komisiju"
            action_label = "Poslati komisiji"
            recommendation_text = (
                f"Zahtjev za {existing_procurement['display_text']} je "
                "potvrđen i čeka slanje komisiji."
            )
            badge_label = "Čeka slanje"
            current_status_label = "Čeka slanje komisiji"
            status_tone = "amber"
        elif status in _SUBMITTED_STATUSES:
            decision_status = REQUEST_SUBMITTED
            status_label = existing_status_label or "Zahtjev poslan komisiji"
            action_label = "Čeka odluku"
            recommendation_text = (
                f"Zahtjev za {existing_procurement['display_text']} je poslan "
                "komisiji i čeka odluku."
            )
            badge_label = "Čeka odluku"
            current_status_label = "Čeka odluku komisije"
            status_tone = "blue"
        else:
            decision_status = REQUEST_DECIDED
            status_label = existing_status_label or "Komisijska odluka evidentirana"
            action_label = "Pratiti realizaciju zahtjeva"
            recommendation_text = (
                f"Komisijska odluka za {existing_procurement['display_text']} "
                "je evidentirana."
            )
            badge_label = "Odluka evidentirana"
            current_status_label = "Komisijska odluka je evidentirana"
            status_tone = "blue"
        subject_label = "Zahtjev za komisiju"
    elif additional > 0:
        displayed = additional
        effective_cycle_date = cycle_date
        decision_status = INCLUDE_IN_COMMISSION
        status_label = "Uključiti u komisiju"
        action_label = "Uključite pacijenta u komisiju"
        displayed_procurement = procurement_breakdown(displayed, medicine)
        recommendation_text = (
            f"Uključiti u komisiju – {displayed_procurement['display_text']}."
        )
        badge_label = "Akcija potrebna"
        current_status_label = "Potrebno uključiti u komisiju"
        status_tone = "amber"
        subject_label = "Komisijski plan"
    elif forecast_quantity > 0:
        displayed = forecast_quantity
        effective_cycle_date = forecast_cycle or cycle_date
        decision_status = FORECAST_NEXT_CYCLE
        status_label = "Buduća procjena"
        action_label = "Trenutno nije potrebna nova komisija"
        displayed_procurement = procurement_breakdown(displayed, medicine)
        recommendation_text = (
            f"Buduća procjena za ciklus "
            f"{effective_cycle_date:%d/%m/%Y}: "
            f"{displayed_procurement['display_text']}. Sistem će upozoriti "
            "kada dođe vrijeme za pripremu zahtjeva."
            if effective_cycle_date
            else (
                f"Buduća procjena iznosi "
                f"{displayed_procurement['display_text']}."
            )
        )
        badge_label = "Budući ciklus"
        current_status_label = "Buduća procjena"
        status_tone = "blue"
        subject_label = "Buduća procjena"
    else:
        displayed = Decimal("0")
        effective_cycle_date = cycle_date
        decision_status = NOT_REQUIRED
        status_label = "Trenutno nije potrebna nova komisija"
        action_label = "Nije potrebna trenutna akcija"
        recommendation_text = "Trenutno nije potrebna nova komisija."
        badge_label = "Nije potrebna"
        current_status_label = "Trenutno nije potrebna nova komisija"
        status_tone = "green"
        subject_label = "Komisijski plan"

    decision_reasons = list(reasons or ())
    if extension_reason:
        decision_reasons.append(extension_reason)

    displayed_procurement = procurement_breakdown(displayed, medicine)
    why_button_label = (
        f"Zašto {displayed_procurement['display_text']}?"
        if displayed > 0
        else "Zašto nije potrebna dodatna količina?"
    )

    return CommissionDecision(
        minimum_required_quantity=minimum_required,
        gross_required_quantity=gross_required,
        physically_covered_quantity=physically_covered,
        confirmed_delivery_quantity=confirmed_delivery,
        existing_request_quantity=existing_quantity,
        existing_request_cycle=existing_cycle_date,
        existing_request_status=status,
        existing_request_status_label=(existing_status_label or status or ""),
        existing_request_state_code=request_state_code,
        existing_request_approved_quantity=request_approved,
        existing_request_received_quantity=request_received,
        existing_request_awaiting_receipt_quantity=request_awaiting,
        usable_existing_approval_quantity=usable_approval,
        additional_quantity_current_cycle=additional,
        forecast_quantity_next_cycle=forecast_quantity,
        forecast_cycle=forecast_cycle,
        safety_reserve_quantity=safety_reserve,
        calculated_quantity=calculated,
        rounded_quantity=rounded,
        existing_proposal_quantity=existing,
        displayed_quantity=displayed,
        decision_status=decision_status,
        cycle_date=effective_cycle_date,
        period_start=period_start,
        period_end=effective_end,
        first_uncovered_dose=first_uncovered_dose,
        reasons=tuple(decision_reasons),
        base_period_end=base_period_end,
        effective_period_end=effective_end,
        period_extension_reason=extension_reason,
        doses_used_in_calculation=dose_dates,
        procurement=displayed_procurement,
        existing_request_procurement=procurement_breakdown(
            existing_quantity, medicine
        ),
        additional_procurement=procurement_breakdown(additional, medicine),
        forecast_procurement=procurement_breakdown(forecast_quantity, medicine),
        status_label=status_label,
        action_label=action_label,
        recommendation_text=recommendation_text,
        badge_label=badge_label,
        current_status_label=current_status_label,
        status_tone=status_tone,
        subject_label=subject_label,
        why_button_label=why_button_label,
    )
