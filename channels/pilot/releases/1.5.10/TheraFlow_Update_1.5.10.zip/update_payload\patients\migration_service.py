import hashlib
import json
from collections import defaultdict
from datetime import time
from decimal import Decimal

from django.core import signing
from django.db import transaction
from django.db.models import Q, Sum
from django.utils import timezone

from .transaction_locking import select_for_update_self

from .individual_protocols import create_migrated_individual_protocol
from .migration_calculations import calculate_next_therapy_date
from .medicine_registry import active_therapy_medicines
from .models import (
    Komisija,
    Lijek,
    MigracijskoPocetnoStanjeZalihe,
    MigracijskiSnapshotPacijenta,
    Pacijent,
    PacijentRezervacija,
    PacijentZaduzenje,
    PotrebaFizickogPokrica,
    Terapija,
    Termin,
    Trebovanje,
    Zaliha,
    ZalihaTransakcija,
)
from .scheduling import adjust_to_allowed_therapy_date
from .utils import upisi_log


SNAPSHOT_SIGNING_SALT = "theraflow.migration.snapshot.v1"


def _decimal_text(value):
    return format(Decimal(str(value or 0)), "f")


def _reserved_quantity(cleaned_data):
    value = cleaned_data.get("rezervisano_za_pacijenta")
    if value is None:
        value = cleaned_data.get("fizicki_u_frizideru")
    return Decimal(str(value or 0))


def _selected_product(cleaned_data):
    """Return the physical SKU which the migration actually records.

    Since migration 0083, ``lijek`` contains the canonical therapy program.
    Legacy service callers may still pass a direct ``Lijek`` in that field.
    """
    product = (
        cleaned_data.get("odabrani_proizvod")
        or cleaned_data.get("trenutni_proizvod")
    )
    if product is not None:
        return product
    legacy_value = cleaned_data.get("lijek")
    return legacy_value if isinstance(legacy_value, Lijek) else None


def canonical_snapshot_payload(cleaned_data):
    program = cleaned_data.get("lijek")
    product = _selected_product(cleaned_data)
    phase = cleaned_data.get("fazna_faza")
    """Vrati stabilan, neosjetljiv sažetak za potvrdu neizmijenjene forme."""
    return {
        "ime": cleaned_data.get("ime") or "",
        "prezime": cleaned_data.get("prezime") or "",
        "jmbg": cleaned_data.get("jmbg") or "",
        "broj_kartona": cleaned_data.get("broj_kartona") or "",
        "aktivan": bool(cleaned_data.get("aktivan", True)),
        "trenutna_faza": cleaned_data.get("trenutna_faza_pacijenta") or "",
        "terapijski_program_id": (
            program.pk
            if program is not None and not isinstance(program, Lijek)
            else None
        ),
        "lijek_id": product.pk if product is not None else None,
        "fazna_faza_id": phase.pk if phase is not None else None,
        "faza": cleaned_data.get("pocetna_faza_terapije") or "",
        "interval": int(cleaned_data.get("interval_sedmica") or 0),
        "kolicina_po_terapiji": _decimal_text(
            cleaned_data.get("kolicina_po_terapiji")
        ),
        "zadnja": (
            cleaned_data["datum_zadnje_terapije"].isoformat()
            if cleaned_data.get("datum_zadnje_terapije")
            else None
        ),
        "oralni_rezim_potvrdjen": bool(
            cleaned_data.get("oralni_rezim_potvrdjen")
        ),
        "oralni_rezim_id": getattr(
            cleaned_data.get("predlozeni_oralni_rezim"), "pk", None
        ),
        "individualni_oralni_rezim": bool(
            cleaned_data.get("individualni_oralni_rezim")
        ),
        "oralne_tablete_po_uzimanju": _decimal_text(
            cleaned_data.get("oralne_tablete_po_uzimanju")
        ),
        "oralna_uzimanja_dnevno": int(
            cleaned_data.get("oralna_uzimanja_dnevno") or 0
        ),
        "oralna_napomena_rezima": (
            cleaned_data.get("oralna_napomena_rezima") or ""
        ).strip(),
        "oralno_posljednje_izdavanje": (
            cleaned_data["datum_posljednjeg_oralnog_izdavanja"].isoformat()
            if cleaned_data.get("datum_posljednjeg_oralnog_izdavanja")
            else None
        ),
        "oralno_posljednje_izdavanje_kolicina": int(
            cleaned_data.get("kolicina_posljednjeg_oralnog_izdavanja") or 0
        ),
        "oralno_preostalo_odobreno": _decimal_text(
            cleaned_data.get("oralno_preostalo_odobreno")
        ),
        "oralni_direktan_unos_tableta": bool(
            cleaned_data.get("oralni_direktan_unos_tableta")
        ),
        "broj_pakovanja_posljednjeg_izdavanja": int(
            cleaned_data.get("broj_pakovanja_posljednjeg_izdavanja") or 0
        ),
        "broj_pakovanja_preostalog_prava": int(
            cleaned_data.get("broj_pakovanja_preostalog_prava") or 0
        ),
        "odobreno": _decimal_text(cleaned_data.get("broj_odobrenih_doza")),
        "iskoristeno": _decimal_text(cleaned_data.get("broj_iskoristenih_doza")),
        "status_preostalih": (
            cleaned_data.get("status_preostalih_odobrenih_doza") or ""
        ),
        "rezervisano_iz_fizicke_zalihe": _decimal_text(
            _reserved_quantity(cleaned_data)
        ),
        "kod_pacijenta": _decimal_text(cleaned_data.get("kod_pacijenta")),
    }


def _snapshot_digest(cleaned_data):
    raw = json.dumps(
        canonical_snapshot_payload(cleaned_data),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def create_snapshot_confirmation_token(cleaned_data):
    return signing.dumps(
        {"digest": _snapshot_digest(cleaned_data)},
        salt=SNAPSHOT_SIGNING_SALT,
        compress=True,
    )


def snapshot_confirmation_is_valid(cleaned_data, token):
    try:
        signed = signing.loads(token, salt=SNAPSHOT_SIGNING_SALT, max_age=1800)
    except signing.BadSignature:
        return False
    return signed.get("digest") == _snapshot_digest(cleaned_data)


def snapshot_for_display(cleaned_data):
    product = _selected_product(cleaned_data)
    program = cleaned_data.get("lijek")
    phase = cleaned_data.get("fazna_faza")
    oral = bool(product and product.oralna_terapija)
    approved = Decimal(str(cleaned_data.get("broj_odobrenih_doza") or 0))
    used = Decimal(str(cleaned_data.get("broj_iskoristenih_doza") or 0))
    interval = cleaned_data.get("interval_sedmica")
    last_date = cleaned_data.get("datum_zadnje_terapije")
    is_ustekinumab_iv = bool(
        program
        and not isinstance(program, Lijek)
        and program.protokol_kljuc == "ustekinumab"
        and phase
        and phase.kljuc == "CEKA_IV_INDUKCIJU"
        and product
        and product.put_primjene == Lijek.PUT_IV
    )
    required_iv_quantity = Decimal(str(
        cleaned_data.get("kolicina_po_terapiji") or 0
    ))
    remaining_approved = max(Decimal("0"), approved - used)
    reserved_quantity = Decimal(str(_reserved_quantity(cleaned_data)))
    iv_ready_to_schedule = bool(
        is_ustekinumab_iv
        and required_iv_quantity > 0
        and remaining_approved >= required_iv_quantity
        and reserved_quantity >= required_iv_quantity
    )
    if is_ustekinumab_iv:
        migration_readiness = (
            "Spremno za migraciju – lijek je zaprimljen, potrebno je zakazati "
            "prvu IV indukciju."
            if iv_ready_to_schedule else
            "Pacijent se može sačuvati, ali nema dovoljno lijeka za zakazivanje."
        )
    else:
        migration_readiness = ""
    raw_next_date = (
        calculate_next_therapy_date(last_date, interval)
        if last_date and interval
        else None
    )
    schedule = (
        adjust_to_allowed_therapy_date(
            raw_next_date,
            lijek=product,
            protokol=cleaned_data.get("terapijski_protokol"),
        )
        if raw_next_date
        else None
    )
    return {
        "pacijent": f"{cleaned_data.get('ime', '')} {cleaned_data.get('prezime', '')}".strip(),
        "terapijski_program": cleaned_data.get("lijek"),
        "lijek": product,
        "interval": None if is_ustekinumab_iv else interval,
        "maintenance_interval": 8 if is_ustekinumab_iv else interval,
        "protocol_label": (
            "Ustekinumab – IV indukcija → SC održavanje"
            if is_ustekinumab_iv else
            str(cleaned_data.get("terapijski_protokol") or "")
        ),
        "is_ustekinumab_iv": is_ustekinumab_iv,
        "iv_ready_to_schedule": iv_ready_to_schedule,
        "migration_readiness": migration_readiness,
        "required_iv_quantity": required_iv_quantity,
        "available_iv_quantity": min(remaining_approved, reserved_quantity),
        "kolicina_po_terapiji": Decimal(
            str(cleaned_data.get("kolicina_po_terapiji") or 0)
        ),
        "jedinica_po_terapiji": (
            product.jedinica_za_kolicinu(
                cleaned_data.get("kolicina_po_terapiji")
            )
            if product
            else "jedinica"
        ),
        "posljednja_terapija": last_date,
        "izracunata_sljedeca_terapija": raw_next_date,
        "sljedeca_terapija": schedule.datum if schedule else None,
        "odabrana_sljedeca_terapija": (
            cleaned_data.get("datum_sljedece_terapije")
            or (schedule.datum if schedule else None)
        ),
        "kreiraj_sljedeci_termin": bool(
            not oral
            and cleaned_data.get("kreiraj_sljedeci_termin")
            and last_date
        ),
        "datum_prilagodjen": bool(schedule and schedule.prilagodjen),
        "upozorenje_datuma": schedule.razlog if schedule else "",
        "odobreno": approved,
        "iskoristeno": used,
        "preostalo": approved - used,
        "status_preostalih_odobrenih_doza": cleaned_data.get(
            "status_preostalih_odobrenih_doza"
        ),
        "status_preostalih_odobrenih_doza_oznaka": dict(
            MigracijskiSnapshotPacijenta.STATUSI_PREOSTALIH_DOZA
        ).get(
            cleaned_data.get("status_preostalih_odobrenih_doza"),
            "Odobrene, čekaju isporuku",
        ),
        "rezervisano_iz_fizicke_zalihe": Decimal(
            str(_reserved_quantity(cleaned_data))
        ),
        "kod_pacijenta": Decimal(str(cleaned_data.get("kod_pacijenta") or 0)),
        "jedinica_kod_pacijenta": (
            product.jedinica_zalihe_za_kolicinu(
                cleaned_data.get("kod_pacijenta") or 0
            )
            if product
            else "doze"
        ),
        "oralni_workflow": oral,
        "oralni_rezim": (
            "Individualni režim: "
            f"{cleaned_data.get('oralne_tablete_po_uzimanju'):g} tableta, "
            f"{cleaned_data.get('oralna_uzimanja_dnevno')} puta dnevno"
            if cleaned_data.get("individualni_oralni_rezim")
            and cleaned_data.get("oralne_tablete_po_uzimanju")
            and cleaned_data.get("oralna_uzimanja_dnevno")
            else cleaned_data.get("predlozeni_oralni_rezim")
        ),
        "oralno_posljednje_izdavanje": cleaned_data.get(
            "datum_posljednjeg_oralnog_izdavanja"
        ),
        "oralno_posljednje_izdavanje_kolicina": cleaned_data.get(
            "kolicina_posljednjeg_oralnog_izdavanja"
        ),
        "oralno_preostalo_odobreno": Decimal(
            str(cleaned_data.get("oralno_preostalo_odobreno") or 0)
        ),
        "oralno_velicina_pakovanja": int(
            product.broj_tableta_u_pakovanju
            or product.effective_package_size
            or 1
        ) if product else 1,
        "oralno_posljednje_izdavanje_pakovanja": (
            Decimal(str(
                cleaned_data.get("kolicina_posljednjeg_oralnog_izdavanja") or 0
            ))
            / Decimal(str(
                product.broj_tableta_u_pakovanju
                or product.effective_package_size
                or 1
            ))
            if product else Decimal("0")
        ),
        "oralno_preostalo_pakovanja": (
            Decimal(str(cleaned_data.get("oralno_preostalo_odobreno") or 0))
            / Decimal(str(
                product.broj_tableta_u_pakovanju
                or product.effective_package_size
                or 1
            ))
            if product else Decimal("0")
        ),
    }


@transaction.atomic
def uskladi_pocetno_stanje_zalihe(*, lijek, kolicina, user):
    """Potvrdi globalni saldo i evidentiraj samo stvarnu delta-korekciju."""
    kolicina = Decimal(str(kolicina or 0))
    if kolicina < 0:
        raise ValueError("Početno fizičko stanje ne može biti negativno.")

    stock, _ = Zaliha.objects.select_for_update().get_or_create(lijek=lijek)
    previous_stock = Decimal(str(stock.u_frizideru or 0))
    reserved = Decimal(str(
        PacijentRezervacija.objects.select_for_update().filter(
            lijek=lijek,
            aktivno=True,
            kolicina__gt=0,
        ).aggregate(total=Sum("kolicina"))["total"] or 0
    ))
    if kolicina < reserved:
        missing = reserved - kolicina
        raise ValueError(
            f"Rezervisano je {reserved:g}, a stvarno fizičko stanje je "
            f"{kolicina:g}. Nedostaje {missing:g} doza. Odaberite koje "
            "rezervacije nisu fizički raspoložive ili ih označite kao još "
            "nezaprimljene."
        )
    initial_state = (
        MigracijskoPocetnoStanjeZalihe.objects.select_for_update()
        .filter(lijek=lijek)
        .first()
    )
    previous_confirmed = (
        Decimal(str(initial_state.kolicina))
        if initial_state is not None
        else None
    )
    authenticated_user = (
        user if getattr(user, "is_authenticated", False) else None
    )

    if initial_state is None:
        last_transaction = (
            ZalihaTransakcija.objects.filter(lijek=lijek)
            .order_by("-id")
            .first()
        )
        initial_state = MigracijskoPocetnoStanjeZalihe.objects.create(
            lijek=lijek,
            kolicina=previous_stock,
            ledger_checkpoint_id=(
                last_transaction.pk if last_transaction is not None else None
            ),
            kreirao=authenticated_user,
            izmijenio=authenticated_user,
        )

    correction = None
    if previous_stock != kolicina:
        delta = kolicina - previous_stock
        stock.u_frizideru = kolicina
        stock.save(update_fields=["u_frizideru", "ukupno"])
        correction = ZalihaTransakcija.objects.create(
            lijek=lijek,
            tip=ZalihaTransakcija.TIP_KOREKCIJA,
            kolicina=delta,
            datum=timezone.localdate(),
            referenca_tip=initial_state.__class__.__name__,
            referenca_id=initial_state.pk,
            korisnik=authenticated_user,
            napomena=(
                "Delta korekcija globalnog početnog stanja kroz migraciju: "
                f"{previous_stock} → {kolicina} ({delta:+g})."
            ),
        )

    checkpoint_id = initial_state.ledger_checkpoint_id
    if correction is not None:
        checkpoint_id = correction.pk
    elif previous_confirmed != kolicina:
        last_transaction = (
            ZalihaTransakcija.objects.filter(lijek=lijek)
            .order_by("-id")
            .first()
        )
        checkpoint_id = (
            last_transaction.pk if last_transaction is not None else None
        )

    if (
        previous_confirmed != kolicina
        or initial_state.ledger_checkpoint_id != checkpoint_id
    ):
        initial_state.kolicina = kolicina
        initial_state.ledger_checkpoint_id = checkpoint_id
        initial_state.izmijenio = authenticated_user
        initial_state.save(
            update_fields=[
                "kolicina",
                "ledger_checkpoint_id",
                "izmijenio",
                "izmijenjeno",
            ]
        )

    # Identičan ponovljeni POST ne proizvodi novi audit događaj.
    if previous_confirmed != kolicina or previous_stock != kolicina:
        upisi_log(
            user,
            "Usklađeno početno stanje zalihe",
            objekat=initial_state,
            opis=(
                f"{lijek.naziv}: globalno fizičko stanje u frižideru "
                f"{previous_stock} → {kolicina}. Komisijska odobrenja i "
                "zaduženja nisu mijenjani; eventualne potrebe na čekanju "
                "alociraju se zasebnim audit događajem."
            ),
        )
    if kolicina > previous_stock:
        from .inventory import cover_pending_physical_needs

        cover_pending_physical_needs(lijek=lijek, user=user)
    return initial_state


@transaction.atomic
def record_migration_opening_stock(
    *, snapshot, commission, kolicina, user=None
):
    """Kompatibilni ulaz koji više nikada ne povećava fizički saldo.

    Stari helper je iz migracijskog snapshot-a dopunjavao ``Zaliha`` i tako
    pretvarao pacijentovo pravo u nepostojeću fizičku robu. Poziv se zadržava
    radi kompatibilnosti, ali sada samo alocira već evidentirano stanje; višak
    prelazi u ``PotrebaFizickogPokrica``. Parametar ``commission`` ostaje dio
    starog potpisa, dok komisiju određuje canonical snapshot workflow.
    """
    del commission
    return set_migration_reservation(
        snapshot=snapshot,
        kolicina=kolicina,
        user=user,
    )


@transaction.atomic
def ensure_migration_opening_transaction(
    *, snapshot, user=None, stock_delta=Decimal("0"), backfill=False
):
    """Evidentiraj jedan dokaz početnog fizičkog stanja po snapshotu.

    ``kolicina`` opisuje količinu deklarisanu snapshotom, dok
    ``promjena_salda`` opisuje samo stvarnu promjenu centralnog salda. Kod
    naknadnog povezivanja historijskog zapisa delta je nula: time dobijamo
    porijeklo bez dvostrukog povećavanja zalihe.

    Kombinacija tipa, reference snapshot-a i lokacije je stabilni
    idempotency ključ. Snapshot se zaključava prije provjere kako paralelna
    migracija ne bi kreirala dvije početne transakcije.
    """
    snapshot = select_for_update_self(
        MigracijskiSnapshotPacijenta.objects.select_related("pacijent", "lijek")
    ).get(pk=snapshot.pk)
    quantity = Decimal(str(snapshot.fizicki_u_frizideru or 0))
    if quantity <= 0:
        return None, False

    lookup = {
        "lijek": snapshot.lijek,
        "tip": ZalihaTransakcija.TIP_POCETNO_STANJE_MIGRACIJE,
        "referenca_tip": "MigracijskiSnapshotPacijenta",
        "referenca_id": snapshot.pk,
        "lokacija": ZalihaTransakcija.LOKACIJA_FRIZIDER,
    }
    existing = (
        ZalihaTransakcija.objects.select_for_update()
        .filter(**lookup)
        .order_by("id")
        .first()
    )
    if existing is not None:
        return existing, False

    authenticated_user = (
        user if getattr(user, "is_authenticated", False) else None
    )
    transaction_row = ZalihaTransakcija.objects.create(
        **lookup,
        kolicina=quantity,
        promjena_salda=Decimal(str(stock_delta or 0)),
        datum=snapshot.kreirano.date() if snapshot.kreirano else timezone.localdate(),
        pacijent=snapshot.pacijent,
        korisnik=authenticated_user,
        rezervisana_pacijentu=True,
        napomena=(
            "Migracija podataka — naknadno povezan dokaz početnog fizičkog "
            "stanja; centralni saldo nije promijenjen."
            if backfill
            else "Migracija podataka — zatečena fizička količina evidentirana "
            "snapshotom; ne povećava komisijsko pravo."
        ),
    )
    return transaction_row, True


def register_declared_migration_physical_stock(*, snapshot, user=None):
    """Osiguraj da novi migracijski fizicki unos postoji u globalnom saldu.

    Pacijentova kolicina u ustanovi nije novo komisijsko pravo, ali jeste
    zatecena fizicka roba. Globalni saldo se povecava samo za dokazani manjak
    do zbira svih migracijskih fizickih unosa, i samo pri prvom snapshotu.
    """

    active_reserved = Decimal(str(
        PacijentRezervacija.objects.filter(
            lijek=snapshot.lijek,
            aktivno=True,
            kolicina__gt=0,
        ).aggregate(total=Sum("kolicina"))["total"] or 0
    ))
    pending_declared = Decimal(str(
        PotrebaFizickogPokrica.objects.filter(
            lijek=snapshot.lijek,
            migracijski_snapshot__isnull=False,
            status=PotrebaFizickogPokrica.STATUS_CEKA,
            preostala_kolicina__gt=0,
        ).aggregate(total=Sum("preostala_kolicina"))["total"] or 0
    ))
    current_represented = bool(
        PacijentRezervacija.objects.filter(
            migracijski_snapshot=snapshot,
            aktivno=True,
            kolicina__gt=0,
        ).exists()
        or PotrebaFizickogPokrica.objects.filter(
            migracijski_snapshot=snapshot,
            status=PotrebaFizickogPokrica.STATUS_CEKA,
            preostala_kolicina__gt=0,
        ).exists()
    )
    current_extra = (
        Decimal("0")
        if current_represented
        else Decimal(str(snapshot.fizicki_u_frizideru or 0))
    )
    required_floor = active_reserved + pending_declared + current_extra
    stock, _ = Zaliha.objects.select_for_update().get_or_create(
        lijek=snapshot.lijek
    )
    current = Decimal(str(stock.u_frizideru or 0))
    delta = max(Decimal("0"), required_floor - current)
    if delta > 0:
        stock.u_frizideru = current + delta
        stock.save(update_fields=["u_frizideru", "ukupno"])
    ensure_migration_opening_transaction(
        snapshot=snapshot,
        user=user,
        stock_delta=delta,
    )
    return delta


@transaction.atomic
def set_migration_reservation(*, snapshot, kolicina, user=None):
    """Alociraj migracijsku potrebu samo do potvrđene fizičke zalihe.

    ``snapshot.fizicki_u_frizideru`` je tražena pacijentska alokacija iz
    migracije. Stvarna fizička rezervacija je isključivo
    ``PacijentRezervacija``; nepokriveni dio ostaje u
    ``PotrebaFizickogPokrica`` i nikada ne povećava globalni saldo.
    """
    from .inventory import reserve_physical_stock
    from .models import PotrebaFizickogPokrica

    kolicina = Decimal(str(kolicina or 0))
    if kolicina < 0:
        raise ValueError("Rezervisana količina ne može biti negativna.")

    snapshot = (
        select_for_update_self(
            MigracijskiSnapshotPacijenta.objects.select_related("pacijent", "lijek")
        )
        .get(pk=snapshot.pk)
    )
    if kolicina > snapshot.preostalo_po_komisiji:
        raise ValueError(
            "Rezervacija ne može biti veća od preostalih odobrenih doza."
        )
    initial_state = (
        MigracijskoPocetnoStanjeZalihe.objects.select_for_update()
        .filter(lijek=snapshot.lijek)
        .first()
    )
    reservation = (
        PacijentRezervacija.objects.select_for_update()
        .filter(migracijski_snapshot=snapshot)
        .first()
    )
    if reservation is None:
        commission = (
            Komisija.objects.select_for_update()
            .filter(
                pacijent=snapshot.pacijent,
                lijek=snapshot.lijek,
                napomena__startswith="Migracijski početni snapshot.",
            )
            .order_by("-id")
            .first()
        )
        legacy_candidates = list(
            PacijentRezervacija.objects.select_for_update()
            .filter(
                pacijent=snapshot.pacijent,
                lijek=snapshot.lijek,
                komisija=commission,
                migracijski_snapshot__isnull=True,
                trebovanje__isnull=True,
            )
            .order_by("id")
        )
        if len(legacy_candidates) > 1:
            raise ValueError(
                f"Pacijent {snapshot.pacijent} ima više starih migracijskih "
                "rezervacija. Potrebna je ručna provjera prije usklađivanja."
            )
        reservation = legacy_candidates[0] if legacy_candidates else None
        if reservation is not None:
            reservation.migracijski_snapshot = snapshot
            reservation.migracijsko_pocetno_stanje = initial_state
            reservation.save(update_fields=[
                "migracijski_snapshot",
                "migracijsko_pocetno_stanje",
            ])
    else:
        commission = reservation.komisija

    previous = (
        Decimal(str(reservation.kolicina or 0))
        if reservation is not None
        else Decimal("0")
    )
    pending = (
        PotrebaFizickogPokrica.objects.select_for_update()
        .filter(
            migracijski_snapshot=snapshot,
            status=PotrebaFizickogPokrica.STATUS_CEKA,
            preostala_kolicina__gt=0,
        )
        .order_by("id")
        .first()
    )
    previous_waiting = (
        Decimal(str(pending.preostala_kolicina or 0))
        if pending is not None else Decimal("0")
    )
    previous_total = previous + previous_waiting

    # Smanjenje prvo uklanja nealocirani dio, a tek zatim oslobađa fizičku
    # rezervaciju. Globalni fizički saldo se ni u jednom slučaju ne mijenja.
    if kolicina < previous_total:
        reduction = previous_total - kolicina
        if pending is not None:
            pending_reduction = min(reduction, previous_waiting)
            pending.preostala_kolicina = previous_waiting - pending_reduction
            pending.trazena_kolicina = max(
                pending.preostala_kolicina,
                Decimal(str(pending.trazena_kolicina or 0)) - pending_reduction,
            )
            if pending.preostala_kolicina <= 0:
                pending.preostala_kolicina = Decimal("0")
                pending.status = PotrebaFizickogPokrica.STATUS_OTKAZANA
            pending.save(update_fields=[
                "trazena_kolicina",
                "preostala_kolicina",
                "status",
                "izmijenjeno",
            ])
            reduction -= pending_reduction
        if reservation is not None and reduction > 0:
            reservation.kolicina = max(
                Decimal("0"), Decimal(str(reservation.kolicina or 0)) - reduction
            )
            reservation.aktivno = reservation.kolicina > 0
            reservation.save(update_fields=["kolicina", "aktivno"])

    if kolicina > previous_total:
        increment = kolicina - previous_total
        reserve_physical_stock(
            pacijent=snapshot.pacijent,
            lijek=snapshot.lijek,
            quantity=increment,
            komisija=commission,
            migracijski_snapshot=snapshot,
            migracijsko_pocetno_stanje=initial_state,
            priority_date=snapshot.sljedeca_terapija,
            user=user,
            note=(
                "Iz postojećeg fizičkog stanja alocirano migracijom "
                "pacijenta; nepokriveni dio ostaje na čekanju."
            ),
        )

    reservation = (
        PacijentRezervacija.objects.filter(migracijski_snapshot=snapshot)
        .order_by("id")
        .first()
    )

    if snapshot.fizicki_u_frizideru != kolicina:
        snapshot.fizicki_u_frizideru = kolicina
        snapshot.save(update_fields=["fizicki_u_frizideru"])

    current_reserved = (
        Decimal(str(reservation.kolicina or 0))
        if reservation is not None and reservation.aktivno else Decimal("0")
    )
    current_waiting = Decimal(str(
        PotrebaFizickogPokrica.objects.filter(
            migracijski_snapshot=snapshot,
            status=PotrebaFizickogPokrica.STATUS_CEKA,
            preostala_kolicina__gt=0,
        ).aggregate(total=Sum("preostala_kolicina"))["total"] or 0
    ))
    if previous_total != kolicina:
        upisi_log(
            user,
            "Usklađena migracijska rezervacija",
            pacijent=snapshot.pacijent,
            objekat=reservation or snapshot,
            opis=(
                f"{snapshot.lijek.naziv}: tražena migracijska alokacija "
                f"{previous_total} → {kolicina}; fizički rezervisano "
                f"{current_reserved}; čeka fizičko pokriće {current_waiting}. "
                "Globalna fizička zaliha nije mijenjana."
            ),
        )
    return reservation


@transaction.atomic
def potvrdi_historijske_migracijske_rezervacije(*, lijek, user):
    """Eksplicitno pretvori stare pacijentske unose u označene rezervacije."""
    snapshots = list(
        select_for_update_self(
            MigracijskiSnapshotPacijenta.objects.filter(
            lijek=lijek,
            fizicki_u_frizideru__gt=0,
            rezervacija_fizicke_zalihe__isnull=True,
            ).select_related("pacijent", "lijek")
        )
        .order_by("id")
    )
    for snapshot in snapshots:
        set_migration_reservation(
            snapshot=snapshot,
            kolicina=snapshot.fizicki_u_frizideru,
            user=user,
        )
    return len(snapshots)


def _legacy_migration_inventory_summary():
    """Sažetak globalnog fizičkog stanja i aktivnih rezervacija po lijeku."""
    medicines = list(active_therapy_medicines())
    medicine_ids = [medicine.pk for medicine in medicines]
    stocks = {
        stock.lijek_id: stock
        for stock in Zaliha.objects.filter(lijek_id__in=medicine_ids)
    }
    confirmed_ids = set(
        MigracijskoPocetnoStanjeZalihe.objects.filter(
            lijek_id__in=medicine_ids
        ).values_list("lijek_id", flat=True)
    )
    reserved = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in PacijentRezervacija.objects.filter(
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
        )
        .values("lijek_id")
        .annotate(total=Sum("kolicina"))
    }
    at_patient = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in PacijentZaduzenje.objects.filter(
            lijek_id__in=medicine_ids,
            aktivno=True,
            preostalo__gt=0,
        ).filter(
            Q(lijek__nacin_primjene=Lijek.NACIN_KUCNA_TERAPIJA)
            | Q(lijek__kucna_primjena=True)
        )
        .values("lijek_id")
        .annotate(total=Sum("preostalo"))
    }
    remaining_approved = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in Komisija.objects.filter(
            lijek_id__in=medicine_ids,
            status__in=Komisija.VAZECI_STATUSI,
            preostale_doze__gt=0,
        )
        .values("lijek_id")
        .annotate(total=Sum("preostale_doze"))
    }
    pending_snapshots = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in MigracijskiSnapshotPacijenta.objects.filter(
            lijek_id__in=medicine_ids,
            fizicki_u_frizideru__gt=0,
            rezervacija_fizicke_zalihe__isnull=True,
        ).exclude(
            potrebe_fizickog_pokrica__status=(
                PotrebaFizickogPokrica.STATUS_CEKA
            ),
            potrebe_fizickog_pokrica__preostala_kolicina__gt=0,
        )
        .values("lijek_id")
        .annotate(total=Sum("fizicki_u_frizideru"))
    }
    awaiting_coverage = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in PotrebaFizickogPokrica.objects.filter(
            lijek_id__in=medicine_ids,
            status=PotrebaFizickogPokrica.STATUS_CEKA,
            preostala_kolicina__gt=0,
        )
        .values("lijek_id")
        .annotate(total=Sum("preostala_kolicina"))
    }
    snapshot_medicine_ids = set(
        MigracijskiSnapshotPacijenta.objects.filter(
            lijek_id__in=medicine_ids
        ).values_list("lijek_id", flat=True)
    )
    reservations = list(
        PacijentRezervacija.objects.filter(
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
        ).select_related(
            "pacijent",
            "lijek",
            "komisija",
            "migracijski_snapshot",
            "migracijsko_pocetno_stanje__kreirao",
        ).order_by("lijek_id", "pacijent__prezime", "pacijent__ime", "id")
    )
    snapshot_ids = [
        item.migracijski_snapshot_id
        for item in reservations
        if item.migracijski_snapshot_id
    ]
    at_patient_by_snapshot = {
        row["migracijski_snapshot_id"]: Decimal(str(row["preostalo"] or 0))
        for row in PacijentZaduzenje.objects.filter(
            migracijski_snapshot_id__in=snapshot_ids,
            aktivno=True,
        ).values("migracijski_snapshot_id", "preostalo")
    }
    migration_transactions = {
        item.referenca_id: item
        for item in ZalihaTransakcija.objects.filter(
            tip=ZalihaTransakcija.TIP_POCETNO_STANJE_MIGRACIJE,
            referenca_tip="MigracijskiSnapshotPacijenta",
            referenca_id__in=snapshot_ids,
            lokacija=ZalihaTransakcija.LOKACIJA_FRIZIDER,
        ).order_by("id")
    }
    reservation_details_by_medicine = {}
    for reservation in reservations:
        snapshot = reservation.migracijski_snapshot
        transaction = (
            migration_transactions.get(snapshot.pk) if snapshot else None
        )
        commission = reservation.komisija
        at_patient_quantity = (
            at_patient_by_snapshot.get(snapshot.pk, Decimal("0"))
            if snapshot else Decimal("0")
        )
        remaining_right = Decimal(str(
            getattr(commission, "preostale_doze", 0) or 0
        ))
        physically_distributed = (
            Decimal(str(reservation.kolicina or 0)) + at_patient_quantity
        )
        exceeds_right = bool(
            commission and physically_distributed > remaining_right
        )
        if reservation.trebovanje_id:
            reservation_source = f"Trebovanje #{reservation.trebovanje_id}"
        elif commission:
            reservation_source = f"Komisija #{commission.pk}"
        elif snapshot:
            reservation_source = "Migracijski unos bez komisijske veze"
        else:
            reservation_source = "Ručna/nepovezana rezervacija"
        creator = (
            transaction.korisnik
            if transaction and transaction.korisnik_id
            else (
                reservation.migracijsko_pocetno_stanje.kreirao
                if reservation.migracijsko_pocetno_stanje_id
                else None
            )
        )
        reservation_details_by_medicine.setdefault(
            reservation.lijek_id, []
        ).append({
            "pacijent": reservation.pacijent,
            "lijek": reservation.lijek,
            "kolicina": Decimal(str(reservation.kolicina or 0)),
            "izvor": reservation_source,
            "korisnik": creator,
            "migracijski_unos": bool(snapshot),
            "nepovezana_rezervacija": not bool(snapshot),
            "ima_migracijski_snapshot": bool(snapshot),
            "ima_fizicku_transakciju": transaction is not None,
            "fizicka_transakcija": transaction,
            "komisija": commission,
            "preostalo_odobreno": remaining_right,
            "datum_migracije": (
                snapshot.kreirano.date()
                if snapshot else reservation.datum_rezervacije
            ),
            "fizicki_rasporedjeno": physically_distributed,
            "prekoraceno_pravo": exceeds_right,
            "status_osnove": (
                "Početno fizičko stanje bez povezane komisijske osnove"
                if exceeds_right or not commission
                else "Povezana komisijska osnova"
            ),
        })

    rows = []
    for medicine in medicines:
        physical = Decimal(
            str(getattr(stocks.get(medicine.pk), "u_frizideru", 0) or 0)
        )
        allocated = reserved.get(medicine.pk, Decimal("0"))
        pending = pending_snapshots.get(medicine.pk, Decimal("0"))
        awaiting = awaiting_coverage.get(medicine.pk, Decimal("0"))
        reservation_details = reservation_details_by_medicine.get(
            medicine.pk, []
        )
        missing_transactions = [
            item for item in reservation_details
            if item["migracijski_unos"]
            and not item["ima_fizicku_transakciju"]
        ]
        unlinked_reservations = [
            item for item in reservation_details
            if item["nepovezana_rezervacija"]
        ]
        right_overruns = [
            item for item in reservation_details if item["prekoraceno_pravo"]
        ]
        quantity_warnings = []
        source_warnings = []
        # Kompatibilni legacy prikaz ne izvodi nove provjere. Kanonska
        # implementacija ispod koristi stvarne vrijednosti.
        oral_workflow = False
        invalid_sources = []
        declared_total = Decimal("0")
        current_physical_total = Decimal("0")
        duplicate_sources = []
        if allocated > physical:
            quantity_warnings.append(
                f"Rezervisano je {allocated:g}, ali je fizički evidentirano "
                f"samo {physical:g}."
            )
        if pending > 0:
            source_warnings.append(
                f"Stari migracijski unosi sadrže {pending:g} nepotvrđenih "
                "pacijentskih rezervacija."
            )
        if awaiting > 0:
            quantity_warnings.append(
                f"Još nije fizički osigurano: {awaiting:g}; ova količina nije "
                "fizička rezervacija i zahtijeva usklađivanje ili novu "
                "isporuku."
            )
        if unlinked_reservations:
            source_warnings.append(
                f"Pronađeno je {len(unlinked_reservations)} rezervacija bez "
                "veze s migracijskim snapshotom."
            )
        if (
            not oral_workflow
            and invalid_sources
            and declared_total > 0
            and current_physical_total != declared_total
        ):
            source_warnings.append(
                f"Migracijom je potvrđeno {declared_total:g} fizičkih jedinica, "
                f"a trenutno je na svim lokacijama evidentirano "
                f"{current_physical_total:g} (odstupanje "
                f"{current_physical_total - declared_total:+g})."
            )
        if duplicate_sources:
            source_warnings.append(
                f"Pronađeno je {len(duplicate_sources)} povezanih duplikata; "
                "isti fizički osnov ne smije biti aktivan više puta."
            )
        if right_overruns:
            source_warnings.append(
                f"Kod {len(right_overruns)} pacijenata fizički raspoređena "
                "količina premašuje preostalo komisijsko pravo."
            )
        if medicine.pk in snapshot_medicine_ids and medicine.pk not in confirmed_ids:
            quantity_warnings.append(
                "Globalno početno stanje još nije administratorski potvrđeno."
            )
        quantity_aligned = (
            True if oral_workflow else
            medicine.pk in confirmed_ids and not quantity_warnings
        )
        source_integrity_aligned = True if oral_workflow else not source_warnings
        warnings = quantity_warnings + source_warnings
        rows.append({
                "lijek": medicine,
                "fizicki": physical,
                "rezervisano": allocated,
                "slobodno": max(Decimal("0"), physical - allocated),
                "kod_pacijenata": at_patient.get(
                    medicine.pk, Decimal("0")
                ),
                "preostalo_odobreno": remaining_approved.get(
                    medicine.pk, Decimal("0")
                ),
                "potvrdjeno": medicine.pk in confirmed_ids,
                "uskladjeno": quantity_aligned and source_integrity_aligned,
                "kolicinski_uskladjeno": quantity_aligned,
                "integritet_izvora_uskladjen": source_integrity_aligned,
                "broj_zapisa_za_povezivanje": len(unlinked_reservations),
                "quantity_warnings": quantity_warnings,
                "source_warnings": source_warnings,
                "nepotvrdjene_rezervacije": pending,
                "ceka_fizicko_pokrice": awaiting,
                "reservation_details": reservation_details,
                "problem_count": len(warnings),
                "warnings": warnings,
            })
    return rows


def _positive_receipt_quantity(transaction_row):
    return max(Decimal("0"), Decimal(str(transaction_row.frizider_delta())))


def _receipt_budget_pools(transactions):
    """Potrošivi fizički ulazi, odvojeni od administrativnog Trebovanja."""
    direct = defaultdict(list)
    cycles = defaultdict(list)
    for transaction_row in transactions:
        remaining = _positive_receipt_quantity(transaction_row)
        if remaining <= 0:
            continue
        item = {"transaction": transaction_row, "remaining": remaining}
        if transaction_row.referenca_tip == "Trebovanje":
            direct[(transaction_row.lijek_id, transaction_row.referenca_id)].append(item)
        elif transaction_row.referenca_tip == "KomisijskiCiklus":
            cycles[(transaction_row.lijek_id, transaction_row.referenca_id)].append(item)
    return direct, cycles


def _consume_receipt_budget(pool, quantity):
    quantity = Decimal(str(quantity or 0))
    if quantity <= 0:
        return None
    if sum((item["remaining"] for item in pool), Decimal("0")) < quantity:
        return None
    first_transaction = None
    remaining = quantity
    for item in pool:
        if remaining <= 0:
            break
        used = min(item["remaining"], remaining)
        if used > 0 and first_transaction is None:
            first_transaction = item["transaction"]
        item["remaining"] -= used
        remaining -= used
    return first_transaction


def _reservation_physical_source(
    reservation, *, migration_transactions, direct_receipts, cycle_receipts
):
    """Vrati jedan dokaz fizičkog izvora i potroši njegov raspoloživi saldo."""
    quantity = Decimal(str(reservation.kolicina or 0))
    snapshot = reservation.migracijski_snapshot
    if snapshot is not None:
        transaction_row = migration_transactions.get(snapshot.pk)
        valid = bool(
            transaction_row
            and quantity <= Decimal(str(snapshot.fizicki_u_frizideru or 0))
        )
        return transaction_row if valid else None, (
            "Migracijski snapshot i početna fizička transakcija"
            if valid
            else "Migracijski snapshot nema početnu fizičku transakciju"
        )

    request = reservation.trebovanje
    if request is not None:
        received = Decimal(str(request.zaprimljene_doze or 0))
        if request.status != "ZAPRIMLJENO" or received < quantity:
            return None, "Trebovanje nije dokaz zaprimanja fizičke količine"
        transaction_row = _consume_receipt_budget(
            direct_receipts.get((reservation.lijek_id, request.pk), []), quantity
        )
        if transaction_row is None and request.komisijski_ciklus_id:
            transaction_row = _consume_receipt_budget(
                cycle_receipts.get(
                    (reservation.lijek_id, request.komisijski_ciklus_id), []
                ),
                quantity,
            )
        cycle = request.komisijski_ciklus
        if (
            transaction_row is not None
            and cycle is not None
            and cycle.datum_komisije
            and transaction_row.datum < cycle.datum_komisije
        ):
            return None, (
                "Zaprimanje je evidentirano prije datuma komisijskog ciklusa; "
                "ne može biti potvrđeno porijeklo fizičke količine"
            )
        return transaction_row, (
            "Potvrđeno fizičko zaprimanje i raspodjela po zahtjevu"
            if transaction_row
            else "Zahtjev je označen zaprimljenim, ali nema povezanu fizičku transakciju"
        )

    return None, "Rezervacija nema snapshot ni potvrđenu fizičku transakciju"


def _reservation_integrity_key(reservation, transaction_row):
    """Stabilni ključ jedne fizičke dodjele.

    Povezivanje svakog reda sa nekim objektom nije dovoljno: dva reda mogu
    pokazivati na isti fizički događaj ili isto pravo. Ključ zato uključuje
    pacijenta, lijek, osnov, lokaciju i namjenu dodjele.
    """

    if reservation.migracijski_snapshot_id:
        basis = ("MIGRATION", reservation.migracijski_snapshot_id)
    elif reservation.trebovanje_id:
        basis = (
            "RECEIPT",
            reservation.komisija_id or reservation.trebovanje_id,
            getattr(transaction_row, "pk", None),
        )
    elif reservation.komisija_id:
        basis = ("COMMISSION", reservation.komisija_id)
    else:
        basis = ("RESERVATION", reservation.pk)
    purpose = "APPOINTMENT" if reservation.termin_id else "PATIENT_ASSIGNMENT"
    return (
        reservation.pacijent_id,
        reservation.lijek_id,
        basis,
        ZalihaTransakcija.LOKACIJA_FRIZIDER,
        purpose,
    )


def migration_inventory_summary():
    """Sažetak salda i porijekla svake aktivne fizičke rezervacije."""
    medicines = list(active_therapy_medicines())
    medicine_ids = [medicine.pk for medicine in medicines]
    stocks = {
        stock.lijek_id: stock
        for stock in Zaliha.objects.filter(lijek_id__in=medicine_ids)
    }
    confirmed_ids = set(
        MigracijskoPocetnoStanjeZalihe.objects.filter(
            lijek_id__in=medicine_ids
        ).values_list("lijek_id", flat=True)
    )
    raw_reserved = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in PacijentRezervacija.objects.filter(
            lijek_id__in=medicine_ids, aktivno=True, kolicina__gt=0
        ).values("lijek_id").annotate(total=Sum("kolicina"))
    }
    assigned_without_appointment = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in PacijentRezervacija.objects.filter(
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
            termin__isnull=True,
        ).values("lijek_id").annotate(total=Sum("kolicina"))
    }
    reserved_for_appointment = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in PacijentRezervacija.objects.filter(
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
            termin__isnull=False,
        ).values("lijek_id").annotate(total=Sum("kolicina"))
    }
    at_patient = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in PacijentZaduzenje.objects.filter(
            lijek_id__in=medicine_ids, aktivno=True, preostalo__gt=0
        ).filter(
            Q(lijek__nacin_primjene=Lijek.NACIN_KUCNA_TERAPIJA)
            | Q(lijek__kucna_primjena=True)
        ).values("lijek_id").annotate(total=Sum("preostalo"))
    }
    remaining_approved = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in Komisija.objects.filter(
            lijek_id__in=medicine_ids,
            status__in=Komisija.VAZECI_STATUSI,
            preostale_doze__gt=0,
        ).values("lijek_id").annotate(total=Sum("preostale_doze"))
    }
    pending_snapshots = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in MigracijskiSnapshotPacijenta.objects.filter(
            lijek_id__in=medicine_ids,
            fizicki_u_frizideru__gt=0,
            rezervacija_fizicke_zalihe__isnull=True,
        ).exclude(
            potrebe_fizickog_pokrica__status=PotrebaFizickogPokrica.STATUS_CEKA,
            potrebe_fizickog_pokrica__preostala_kolicina__gt=0,
        ).values("lijek_id").annotate(total=Sum("fizicki_u_frizideru"))
    }
    awaiting_coverage = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in PotrebaFizickogPokrica.objects.filter(
            lijek_id__in=medicine_ids,
            status=PotrebaFizickogPokrica.STATUS_CEKA,
            preostala_kolicina__gt=0,
        ).values("lijek_id").annotate(total=Sum("preostala_kolicina"))
    }
    snapshot_medicine_ids = set(
        MigracijskiSnapshotPacijenta.objects.filter(
            lijek_id__in=medicine_ids
        ).values_list("lijek_id", flat=True)
    )
    migration_declared_total = {
        row["lijek_id"]: Decimal(str(row["total"] or 0))
        for row in MigracijskiSnapshotPacijenta.objects.filter(
            lijek_id__in=medicine_ids,
            pacijent__aktivan=True,
        ).values("lijek_id").annotate(
            total=Sum("fizicki_u_frizideru") + Sum("kod_pacijenta")
        )
    }
    reservations = list(
        PacijentRezervacija.objects.filter(
            lijek_id__in=medicine_ids, aktivno=True, kolicina__gt=0
        ).select_related(
            "pacijent", "lijek", "komisija", "migracijski_snapshot",
            "migracijsko_pocetno_stanje__kreirao", "trebovanje",
            "trebovanje__komisijski_ciklus",
        ).order_by("lijek_id", "datum_rezervacije", "id")
    )
    snapshot_ids = [
        item.migracijski_snapshot_id
        for item in reservations if item.migracijski_snapshot_id
    ]
    at_patient_by_snapshot = {
        row["migracijski_snapshot_id"]: Decimal(str(row["total"] or 0))
        for row in PacijentZaduzenje.objects.filter(
            migracijski_snapshot_id__in=snapshot_ids, aktivno=True
        ).values("migracijski_snapshot_id").annotate(total=Sum("preostalo"))
    }
    migration_transactions = {
        item.referenca_id: item
        for item in ZalihaTransakcija.objects.filter(
            tip=ZalihaTransakcija.TIP_POCETNO_STANJE_MIGRACIJE,
            referenca_tip="MigracijskiSnapshotPacijenta",
            referenca_id__in=snapshot_ids,
            lokacija=ZalihaTransakcija.LOKACIJA_FRIZIDER,
        ).order_by("id")
    }
    receipt_transactions = list(
        ZalihaTransakcija.objects.filter(
            lijek_id__in=medicine_ids,
            tip=ZalihaTransakcija.TIP_ZAPRIMANJE,
            referenca_tip__in=("Trebovanje", "KomisijskiCiklus"),
            referenca_id__isnull=False,
        ).order_by("datum", "id")
    )
    direct_receipts, cycle_receipts = _receipt_budget_pools(receipt_transactions)

    details_by_medicine = defaultdict(list)
    valid_reserved = defaultdict(lambda: Decimal("0"))
    seen_integrity_keys = set()
    for reservation in reservations:
        snapshot = reservation.migracijski_snapshot
        transaction_row, provenance_status = _reservation_physical_source(
            reservation,
            migration_transactions=migration_transactions,
            direct_receipts=direct_receipts,
            cycle_receipts=cycle_receipts,
        )
        integrity_key = _reservation_integrity_key(
            reservation, transaction_row
        )
        duplicate_allocation = integrity_key in seen_integrity_keys
        seen_integrity_keys.add(integrity_key)
        provenance_valid = transaction_row is not None and not duplicate_allocation
        if duplicate_allocation:
            provenance_status = (
                "Dupla aktivna rezervacija predstavlja isti fizički osnov, "
                "lokaciju i namjenu."
            )
        quantity = Decimal(str(reservation.kolicina or 0))
        if provenance_valid:
            valid_reserved[reservation.lijek_id] += quantity
        commission = reservation.komisija
        at_patient_quantity = (
            at_patient_by_snapshot.get(snapshot.pk, Decimal("0"))
            if snapshot else Decimal("0")
        )
        remaining_right = Decimal(str(
            getattr(commission, "preostale_doze", 0) or 0
        ))
        physically_distributed = quantity + at_patient_quantity
        exceeds_right = bool(commission and physically_distributed > remaining_right)
        if reservation.trebovanje_id:
            source = f"Zaprimanje po zahtjevu #{reservation.trebovanje_id}"
        elif snapshot:
            source = f"Migracijski snapshot #{snapshot.pk}"
        elif commission:
            source = f"Komisija #{commission.pk}"
        else:
            source = "Nepovezana rezervacija"
        creator = (
            transaction_row.korisnik
            if transaction_row and transaction_row.korisnik_id
            else reservation.migracijsko_pocetno_stanje.kreirao
            if reservation.migracijsko_pocetno_stanje_id
            else None
        )
        details_by_medicine[reservation.lijek_id].append({
            "rezervacija": reservation,
            "pacijent": reservation.pacijent,
            "lijek": reservation.lijek,
            "kolicina": quantity,
            "izvor": source,
            "korisnik": creator,
            "migracijski_unos": bool(snapshot),
            "nepovezana_rezervacija": not provenance_valid,
            "ima_migracijski_snapshot": bool(snapshot),
            "ima_fizicku_transakciju": transaction_row is not None,
            "fizicka_transakcija": transaction_row,
            "porijeklo_potvrdjeno": provenance_valid,
            "duplikat_fizickog_osnova": duplicate_allocation,
            "komisija": commission,
            "preostalo_odobreno": remaining_right,
            "datum_migracije": (
                snapshot.kreirano.date() if snapshot else reservation.datum_rezervacije
            ),
            "fizicki_rasporedjeno": physically_distributed,
            "prekoraceno_pravo": exceeds_right,
            "status_osnove": provenance_status,
            "preporucena_radnja": (
                "Spojiti kao duplikat"
                if duplicate_allocation else
                "Zadržati"
                if provenance_valid else
                "Povezati sa snapshotom"
                if snapshot else
                "Ukloniti iz fizičkog stanja"
            ),
        })

    from .models import IzdavanjeOralneTerapije
    from .oral_therapy import oral_issue_quantity_remaining

    oral_details_by_medicine = defaultdict(list)
    oral_patients = Pacijent.objects.filter(
        lijek_id__in=medicine_ids,
        lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA,
        aktivan=True,
    ).select_related("lijek").order_by("lijek_id", "prezime", "ime", "id")
    for patient in oral_patients:
        last_issue = (
            IzdavanjeOralneTerapije.objects.filter(
                pacijent=patient,
                lijek=patient.lijek,
                status=IzdavanjeOralneTerapije.STATUS_AKTIVNO,
            ).order_by("-datum_izdavanja", "-pk").first()
        )
        patient_right = Decimal(str(
            Komisija.objects.filter(
                pacijent=patient,
                lijek=patient.lijek,
                status__in=Komisija.VAZECI_STATUSI,
                preostale_doze__gt=0,
            ).aggregate(total=Sum("preostale_doze"))["total"] or 0
        ))
        oral_details_by_medicine[patient.lijek_id].append({
            "pacijent": patient,
            "posljednje_izdavanje": (
                last_issue.datum_izdavanja if last_issue else None
            ),
            "izdato": Decimal(str(
                last_issue.kolicina_tableta if last_issue else 0
            )),
            "kod_pacijenta": (
                oral_issue_quantity_remaining(last_issue)
                if last_issue else Decimal("0")
            ),
            "pokriveno_do": (
                last_issue.pokrivenost_do if last_issue else None
            ),
            "preostalo_odobreno": patient_right,
        })

    rows = []
    for medicine in medicines:
        physical = Decimal(str(
            getattr(stocks.get(medicine.pk), "u_frizideru", 0) or 0
        ))
        allocated = raw_reserved.get(medicine.pk, Decimal("0"))
        validated = valid_reserved.get(medicine.pk, Decimal("0"))
        pending = pending_snapshots.get(medicine.pk, Decimal("0"))
        awaiting = awaiting_coverage.get(medicine.pk, Decimal("0"))
        details = details_by_medicine.get(medicine.pk, [])
        oral_workflow = medicine.nacin_primjene == Lijek.NACIN_ORALNA_TERAPIJA
        oral_details = oral_details_by_medicine.get(medicine.pk, [])
        invalid_sources = [item for item in details if not item["porijeklo_potvrdjeno"]]
        duplicate_sources = [
            item for item in details if item["duplikat_fizickog_osnova"]
        ]
        right_overruns = [item for item in details if item["prekoraceno_pravo"]]
        quantity_warnings = []
        source_warnings = []
        current_physical_total = physical + at_patient.get(
            medicine.pk, Decimal("0")
        )
        declared_total = migration_declared_total.get(
            medicine.pk, Decimal("0")
        )
        if (
            not oral_workflow
            and invalid_sources
            and declared_total > 0
            and current_physical_total != declared_total
        ):
            source_warnings.append(
                f"Migracijom je potvrđeno {declared_total:g} fizičkih jedinica, "
                f"a trenutno je na svim lokacijama evidentirano "
                f"{current_physical_total:g} (odstupanje "
                f"{current_physical_total - declared_total:+g})."
            )
        if duplicate_sources:
            source_warnings.append(
                f"Pronađeno je {len(duplicate_sources)} povezanih duplikata; "
                "isti fizički osnov ne smije biti aktivan više puta."
            )
        if allocated > physical:
            quantity_warnings.append(
                f"Rezervisano je {allocated:g}, ali je fizički evidentirano samo {physical:g}."
            )
        if pending > 0:
            source_warnings.append(
                f"Stari migracijski unosi sadrže {pending:g} nepotvrđenih rezervacija."
            )
        if awaiting > 0:
            quantity_warnings.append(
                f"Još nije fizički osigurano: {awaiting:g}; ta količina nije fizička rezervacija."
            )
        if invalid_sources:
            source_warnings.append(
                f"Količine se podudaraju, ali {len(invalid_sources)} rezervacija "
                "nema potvrđeno porijeklo."
            )
        if right_overruns:
            source_warnings.append(
                f"Kod {len(right_overruns)} pacijenata raspoređena količina "
                "premašuje preostalo komisijsko pravo."
            )
        if medicine.pk in snapshot_medicine_ids and medicine.pk not in confirmed_ids:
            quantity_warnings.append(
                "Globalno početno stanje još nije administratorski potvrđeno."
            )
        quantity_aligned = medicine.pk in confirmed_ids and not quantity_warnings
        source_integrity_aligned = not source_warnings
        warnings = quantity_warnings + source_warnings
        rows.append({
            "lijek": medicine,
            "fizicki": physical,
            "rezervisano": allocated,
            "dodijeljeno_pacijentima": assigned_without_appointment.get(
                medicine.pk, Decimal("0")
            ),
            "rezervisano_za_termin": reserved_for_appointment.get(
                medicine.pk, Decimal("0")
            ),
            "validno_rezervisano": validated,
            "slobodno": max(Decimal("0"), physical - allocated),
            "slobodno_nakon_provjere": max(Decimal("0"), physical - validated),
            "kod_pacijenata": at_patient.get(medicine.pk, Decimal("0")),
            "preostalo_odobreno": remaining_approved.get(medicine.pk, Decimal("0")),
            "migracijom_uneseno_fizicki": declared_total,
            "trenutno_fizicki_na_svim_lokacijama": current_physical_total,
            "odstupanje_od_migracijskog_unosa": (
                current_physical_total - declared_total
            ),
            "oralni_workflow": oral_workflow,
            "oralni_detalji": oral_details,
            "potvrdjeno": medicine.pk in confirmed_ids,
            "uskladjeno": quantity_aligned and source_integrity_aligned,
            "kolicinski_uskladjeno": quantity_aligned,
            "integritet_izvora_uskladjen": source_integrity_aligned,
            "broj_zapisa_za_povezivanje": len(invalid_sources),
            "broj_duplikata": len(duplicate_sources),
            "quantity_warnings": quantity_warnings,
            "source_warnings": source_warnings,
            "nepotvrdjene_rezervacije": pending,
            "ceka_fizicko_pokrice": awaiting,
            "reservation_details": details,
            "problem_count": len(warnings),
            "warnings": warnings,
        })
    return rows


def migration_inventory_reconciliation_preview(lijek):
    """Read-only plan: poveži dokaze, a nedokazane rezervacije deaktiviraj."""
    stock = Zaliha.objects.filter(lijek=lijek).first()
    physical = Decimal(str(getattr(stock, "u_frizideru", 0) or 0))
    reservations = list(
        PacijentRezervacija.objects.filter(
            lijek=lijek, aktivno=True, kolicina__gt=0
        ).select_related(
            "pacijent", "migracijski_snapshot", "trebovanje",
            "trebovanje__komisijski_ciklus", "komisija",
        ).order_by("datum_rezervacije", "id")
    )
    snapshots = list(
        MigracijskiSnapshotPacijenta.objects.filter(
            lijek=lijek,
            pacijent__aktivan=True,
            fizicki_u_frizideru__gt=0,
        ).select_related("pacijent").order_by("kreirano", "id")
    )
    existing_opening_ids = set(
        ZalihaTransakcija.objects.filter(
            lijek=lijek,
            tip=ZalihaTransakcija.TIP_POCETNO_STANJE_MIGRACIJE,
            referenca_tip="MigracijskiSnapshotPacijenta",
            referenca_id__in=[item.pk for item in snapshots],
            lokacija=ZalihaTransakcija.LOKACIJA_FRIZIDER,
        ).values_list("referenca_id", flat=True)
    )
    opening_to_create = [
        item for item in snapshots if item.pk not in existing_opening_ids
    ]

    receipt_transactions = list(
        ZalihaTransakcija.objects.filter(
            lijek=lijek, tip=ZalihaTransakcija.TIP_ZAPRIMANJE
        ).order_by("datum", "id")
    )
    linked_receipts = [
        item for item in receipt_transactions
        if item.referenca_tip in ("Trebovanje", "KomisijskiCiklus")
        and item.referenca_id
    ]
    reversed_receipt_ids = set(
        ZalihaTransakcija.objects.filter(
            lijek=lijek,
            tip=ZalihaTransakcija.TIP_KOREKCIJA,
            referenca_tip="ZalihaTransakcija",
            referenca_id__isnull=False,
        ).values_list("referenca_id", flat=True)
    )
    unlinked_receipts = [
        item for item in receipt_transactions
        if not item.referenca_tip and item.referenca_id is None
        and _positive_receipt_quantity(item) > 0
    ]

    request_groups = defaultdict(list)
    for reservation in reservations:
        request = reservation.trebovanje
        if request and request.komisijski_ciklus_id:
            request_groups[request.komisijski_ciklus_id].append(reservation)

    cycles_by_id = {
        reservation.trebovanje.komisijski_ciklus_id:
            reservation.trebovanje.komisijski_ciklus
        for reservation in reservations
        if reservation.trebovanje_id
        and reservation.trebovanje.komisijski_ciklus_id
    }
    requests_by_id = {
        reservation.trebovanje_id: reservation.trebovanje
        for reservation in reservations if reservation.trebovanje_id
    }
    invalid_receipts = []
    valid_linked_receipts = []
    for transaction_row in linked_receipts:
        if transaction_row.pk in reversed_receipt_ids:
            continue
        cycle = None
        if transaction_row.referenca_tip == "KomisijskiCiklus":
            cycle = cycles_by_id.get(transaction_row.referenca_id)
        elif transaction_row.referenca_tip == "Trebovanje":
            request = requests_by_id.get(transaction_row.referenca_id)
            cycle = request.komisijski_ciklus if request else None
        if (
            cycle is not None
            and cycle.datum_komisije
            and transaction_row.datum < cycle.datum_komisije
        ):
            invalid_receipts.append({
                "transaction": transaction_row,
                "cycle": cycle,
                "quantity": _positive_receipt_quantity(transaction_row),
                "reason": (
                    "Zaprimanje je evidentirano prije datuma komisijskog "
                    "ciklusa i ne može predstavljati fizičku isporuku iz tog "
                    "ciklusa."
                ),
            })
        else:
            valid_linked_receipts.append(transaction_row)

    already_linked_cycles = {
        item.referenca_id
        for item in linked_receipts
        if item.referenca_tip == "KomisijskiCiklus"
    }
    receipt_links = []
    used_cycle_ids = set(already_linked_cycles)
    for transaction_row in unlinked_receipts:
        transaction_quantity = _positive_receipt_quantity(transaction_row)
        candidates = []
        for cycle_id, group in request_groups.items():
            if cycle_id in used_cycle_ids:
                continue
            group_quantity = sum(
                (Decimal(str(item.kolicina or 0)) for item in group), Decimal("0")
            )
            all_received = all(
                item.trebovanje.status == "ZAPRIMLJENO"
                and Decimal(str(item.trebovanje.zaprimljene_doze or 0))
                >= Decimal(str(item.kolicina or 0))
                and transaction_row.datum >= item.trebovanje.datum_kreiranja
                for item in group
            )
            if all_received and group_quantity == transaction_quantity:
                candidates.append(cycle_id)
        if len(candidates) == 1:
            cycle_id = candidates[0]
            used_cycle_ids.add(cycle_id)
            receipt_links.append({
                "transaction": transaction_row,
                "cycle_id": cycle_id,
                "quantity": transaction_quantity,
                "reservations": request_groups[cycle_id],
            })

    direct_receipts, cycle_receipts = _receipt_budget_pools(
        valid_linked_receipts
    )
    for link in receipt_links:
        cycle_receipts[(lijek.pk, link["cycle_id"])].append({
            "transaction": link["transaction"],
            "remaining": link["quantity"],
        })

    existing_migration_transactions = {
        item.referenca_id: item
        for item in ZalihaTransakcija.objects.filter(
            lijek=lijek,
            tip=ZalihaTransakcija.TIP_POCETNO_STANJE_MIGRACIJE,
            referenca_tip="MigracijskiSnapshotPacijenta",
            referenca_id__in=[item.pk for item in snapshots],
            lokacija=ZalihaTransakcija.LOKACIJA_FRIZIDER,
        )
    }
    proposed_opening_ids = {item.pk for item in opening_to_create}
    kept = []
    deactivated = []
    duplicate_keys = set()
    for reservation in reservations:
        quantity = Decimal(str(reservation.kolicina or 0))
        if reservation.migracijski_snapshot_id:
            key = ("snapshot", reservation.migracijski_snapshot_id)
            valid = (
                reservation.migracijski_snapshot_id in existing_migration_transactions
                or reservation.migracijski_snapshot_id in proposed_opening_ids
            ) and quantity <= Decimal(str(
                reservation.migracijski_snapshot.fizicki_u_frizideru or 0
            ))
        elif reservation.trebovanje_id:
            key = ("request", reservation.trebovanje_id)
            transaction_row, _status = _reservation_physical_source(
                reservation,
                migration_transactions=existing_migration_transactions,
                direct_receipts=direct_receipts,
                cycle_receipts=cycle_receipts,
            )
            valid = transaction_row is not None
        else:
            key = ("unsupported", reservation.pk)
            valid = False
        if key in duplicate_keys:
            valid = False
        else:
            duplicate_keys.add(key)
        (kept if valid else deactivated).append(reservation)

    kept_quantity = sum(
        (Decimal(str(item.kolicina or 0)) for item in kept), Decimal("0")
    )
    invalid_receipt_quantity = sum(
        (item["quantity"] for item in invalid_receipts), Decimal("0")
    )
    new_physical = max(Decimal("0"), physical - invalid_receipt_quantity)
    source_actions = []
    kept_ids = {item.pk for item in kept}
    for reservation in reservations:
        if reservation.pk in kept_ids:
            recommendation = (
                "Povezati sa snapshotom"
                if reservation.migracijski_snapshot_id
                and reservation.migracijski_snapshot_id in proposed_opening_ids
                else "Zadržati"
            )
        else:
            recommendation = (
                "Spojiti kao duplikat"
                if (
                    reservation.migracijski_snapshot_id
                    and sum(
                        1 for other in reservations
                        if other.migracijski_snapshot_id
                        == reservation.migracijski_snapshot_id
                    ) > 1
                ) else "Ukloniti iz fizičkog stanja"
            )
        source_actions.append({
            "reservation": reservation,
            "recommendation": recommendation,
        })

    # Ako je jedini fizički prijem nekog zahtjeva proglašen nevažećim,
    # zahtjev više ne smije ostati u stanju ZAPRIMLJENO.  Ovo su isključivo
    # zahtjevi čije se fizičke rezervacije upravo uklanjaju iz salda; sama
    # komisijska prava ostaju sačuvana kao administrativna prava.
    invalid_cycle_ids = {
        item["cycle"].pk for item in invalid_receipts if item.get("cycle")
    }
    requests_to_reopen = {}
    for reservation in deactivated:
        request = reservation.trebovanje
        if (
            request
            and request.status == "ZAPRIMLJENO"
            and request.komisijski_ciklus_id in invalid_cycle_ids
        ):
            requests_to_reopen[request.pk] = {
                "request": request,
                "quantity": Decimal(str(reservation.kolicina or 0)),
            }
    return {
        "lijek": lijek,
        "current_physical": physical,
        "new_physical": new_physical,
        "kept": kept,
        "kept_quantity": kept_quantity,
        "deactivated": deactivated,
        "deactivated_quantity": sum(
            (Decimal(str(item.kolicina or 0)) for item in deactivated), Decimal("0")
        ),
        "opening_transactions": opening_to_create,
        "receipt_links": receipt_links,
        "invalid_receipts": invalid_receipts,
        "requests_to_reopen": list(requests_to_reopen.values()),
        "source_actions": source_actions,
        "free_after": max(Decimal("0"), new_physical - kept_quantity),
        "has_changes": bool(
            opening_to_create or receipt_links or deactivated or invalid_receipts
        ),
    }


@transaction.atomic
def reconcile_migration_inventory_provenance(*, lijek, user):
    """Primijeni prethodno objašnjiv plan bez mijenjanja fizičkog salda."""
    stock = Zaliha.objects.select_for_update().filter(lijek=lijek).first()
    list(
        PacijentRezervacija.objects.select_for_update().filter(
            lijek=lijek, aktivno=True
        ).order_by("id")
    )
    list(
        ZalihaTransakcija.objects.select_for_update().filter(lijek=lijek).order_by("id")
    )
    list(
        MigracijskiSnapshotPacijenta.objects.select_for_update().filter(
            lijek=lijek
        ).order_by("id")
    )
    plan = migration_inventory_reconciliation_preview(lijek)
    physical_before = plan["current_physical"]

    for link in plan["receipt_links"]:
        transaction_row = ZalihaTransakcija.objects.select_for_update().get(
            pk=link["transaction"].pk
        )
        if transaction_row.referenca_tip or transaction_row.referenca_id:
            raise ValueError("Fizička transakcija je u međuvremenu već povezana.")
        transaction_row.referenca_tip = "KomisijskiCiklus"
        transaction_row.referenca_id = link["cycle_id"]
        transaction_row.lokacija = ZalihaTransakcija.LOKACIJA_FRIZIDER
        transaction_row.save(update_fields=[
            "referenca_tip", "referenca_id", "lokacija"
        ])

    for snapshot in plan["opening_transactions"]:
        ensure_migration_opening_transaction(
            snapshot=snapshot, user=user, stock_delta=Decimal("0"), backfill=True
        )

    for reservation in plan["deactivated"]:
        locked = PacijentRezervacija.objects.select_for_update().get(pk=reservation.pk)
        locked.aktivno = False
        locked.napomena = (
            f"{locked.napomena}\n" if locked.napomena else ""
        ) + "Isključeno iz fizičkog salda: porijeklo nije potvrđeno usklađivanjem."
        locked.save(update_fields=["aktivno", "napomena"])

    for invalid in plan["invalid_receipts"]:
        original = ZalihaTransakcija.objects.select_for_update().get(
            pk=invalid["transaction"].pk
        )
        already_reversed = ZalihaTransakcija.objects.select_for_update().filter(
            lijek=lijek,
            tip=ZalihaTransakcija.TIP_KOREKCIJA,
            referenca_tip="ZalihaTransakcija",
            referenca_id=original.pk,
        ).exists()
        if already_reversed:
            continue
        quantity = Decimal(str(invalid["quantity"] or 0))
        if stock is None or Decimal(str(stock.u_frizideru or 0)) < quantity:
            raise ValueError(
                "Nevažeće zaprimanje nije moguće reverzirati bez negativnog "
                "fizičkog salda."
            )
        stock.u_frizideru = Decimal(str(stock.u_frizideru or 0)) - quantity
        stock.save(update_fields=["u_frizideru", "ukupno"])
        ZalihaTransakcija.objects.create(
            lijek=lijek,
            tip=ZalihaTransakcija.TIP_KOREKCIJA,
            kolicina=-quantity,
            promjena_salda=-quantity,
            datum=timezone.localdate(),
            referenca_tip="ZalihaTransakcija",
            referenca_id=original.pk,
            korisnik=(user if getattr(user, "is_authenticated", False) else None),
            lokacija=ZalihaTransakcija.LOKACIJA_FRIZIDER,
            napomena=(
                "Reverzija nevažećeg fizičkog zaprimanja: događaj je bio "
                "evidentiran prije datuma pripadajućeg komisijskog ciklusa. "
                "Izvorni zapis ostaje sačuvan radi audita."
            ),
        )

    for item in plan["requests_to_reopen"]:
        request = Trebovanje.objects.select_for_update().get(
            pk=item["request"].pk
        )
        quantity = Decimal(str(item["quantity"] or 0))
        request.zaprimljene_doze = max(
            Decimal("0"),
            Decimal(str(request.zaprimljene_doze or 0)) - quantity,
        )
        request.status = "ODOBRENO"
        request.zaduzenje_kreirano = request.zaprimljene_doze > 0
        request.napomena = (
            f"{request.napomena}\n" if request.napomena else ""
        ) + (
            "Fizičko zaprimanje je reverzirano jer je bilo evidentirano "
            "prije datuma komisijskog ciklusa. Komisijsko pravo je sačuvano, "
            "ali ponovo čeka stvarno zaprimanje."
        )
        request.save(update_fields=[
            "zaprimljene_doze",
            "status",
            "zaduzenje_kreirano",
            "napomena",
        ])

    stock_after = Decimal(str(
        Zaliha.objects.get(lijek=lijek).u_frizideru or 0
    ))
    if stock_after != plan["new_physical"]:
        raise ValueError(
            "Konačni fizički saldo ne odgovara pregledanom planu usklađivanja."
        )
    upisi_log(
        user,
        "Usklađeno porijeklo fizičke zalihe",
        objekat=lijek,
        opis=(
            f"{lijek.naziv}: zadržano {plan['kept_quantity']:g}; "
            f"isključeno {plan['deactivated_quantity']:g}; povezano prijema "
            f"{len(plan['receipt_links'])}; dopunjeno migracijskih transakcija "
            f"{len(plan['opening_transactions'])}; fizički saldo ostao "
            f"{physical_before:g} -> {stock_after:g}; reverzirano prijema "
            f"{len(plan['invalid_receipts'])}; vraćeno zahtjeva u stanje "
            f"odobreno {len(plan['requests_to_reopen'])}. Operacija je "
            "izvršena atomski."
        ),
    )
    return plan


@transaction.atomic
def apply_migration_snapshot(form, user):
    """Upiši migraciju i historiju bez operativne terapijske potrošnje."""
    cleaned = form.cleaned_data
    pacijent = form.save(commit=False)
    pacijent.aktivan = bool(cleaned.get("aktivan", True))
    # IV indukcija nema klinički interval. Pacijentov legacy interval FK ipak
    # nije nullable i zato čuva budući SC interval, dok fazni engine za
    # trenutnu IV fazu i dalje eksplicitno vraća ``None``.
    maintenance_interval = cleaned.get("interval_sedmica") or 8
    pacijent.interval_sedmica = maintenance_interval
    pacijent.kolicina_po_terapiji = Decimal(
        str(cleaned["kolicina_po_terapiji"])
    )
    pacijent.save()

    phased_state = None
    if pacijent.terapijski_program and pacijent.terapijski_program.protokol_kljuc:
        from .phased_protocols import configure_program_protocol

        phased_state = configure_program_protocol(
            patient=pacijent,
            program=pacijent.terapijski_program,
            phase=cleaned.get("fazna_faza"),
            current_product=cleaned.get("trenutni_proizvod"),
            maintenance_interval=maintenance_interval,
            user=user,
            # Migracijski logistički unos nije ljekarska propisana IV doza.
            # Doza se potvrđuje u zasebnom kliničkom workflowu.
            induction_units=None,
            allow_missing_iv_dose=True,
            last_actual_date=cleaned.get("datum_zadnje_terapije"),
        )
        pacijent.refresh_from_db(fields=("lijek", "terapijski_program"))

    individualni_protokol = None
    if pacijent.pocetna_faza_terapije == Pacijent.FAZA_INDIVIDUALNI:
        individualni_protokol = create_migrated_individual_protocol(
            pacijent,
            naziv=cleaned["naziv_individualnog_protokola"],
            razlog=cleaned.get("razlog_individualnog_protokola", ""),
            interval_sedmica=pacijent.interval_sedmica,
            broj_jedinica=pacijent.kolicina_po_terapiji,
            user=user,
        )

    lijek = pacijent.lijek
    is_oral = bool(lijek and lijek.oralna_terapija)
    approved = Decimal(str(cleaned.get("broj_odobrenih_doza") or 0))
    used = Decimal(str(cleaned.get("broj_iskoristenih_doza") or 0))
    if is_oral:
        # Servis je javna granica i ne smije zavisiti od toga je li pozvan
        # kroz najnoviju verziju forme. Oralni snapshot eksplicitno nosi
        # posljednje izdavanje i preostalo pravo; iz njih se izvode ukupno i
        # iskorišteno bez pretvaranja fizički izdatih tableta u novo pravo.
        oral_issued = Decimal(str(
            cleaned.get("kolicina_posljednjeg_oralnog_izdavanja") or 0
        ))
        oral_remaining = Decimal(str(
            cleaned.get("oralno_preostalo_odobreno") or 0
        ))
        approved = oral_issued + oral_remaining
        used = oral_issued
    remaining = approved - used
    reserved_from_stock = _reserved_quantity(cleaned)
    at_patient = Decimal(str(cleaned.get("kod_pacijenta") or 0))
    last_date = None if is_oral else cleaned.get("datum_zadnje_terapije")
    create_next_appointment = bool(
        not is_oral
        and last_date
        and cleaned.get("kreiraj_sljedeci_termin")
    )
    next_date = (
        cleaned.get("datum_sljedece_terapije")
        if create_next_appointment
        else None
    )
    note = cleaned.get("napomena_migracije") or ""
    remaining_status = (
        cleaned.get("status_preostalih_odobrenih_doza")
        or MigracijskiSnapshotPacijenta.STATUS_PREOSTALIH_CEKA_ISPORUKU
    )
    migration_identifier = _snapshot_digest(cleaned)

    # Migracija čuva datume u MigracijskiSnapshotPacijenta. Ne proizvodi
    # operativni Termin niti ambulantnu Terapiju; te zapise kreiraju isključivo
    # naknadni, eksplicitni klinički workflowi.

    commission = None
    if lijek and approved > 0:
        commission_status = (
            "ODOBRENA"
            if (
                remaining > 0
                and remaining_status
                == MigracijskiSnapshotPacijenta.STATUS_PREOSTALIH_CEKA_ISPORUKU
            )
            else "AKTIVNA"
            if remaining > 0
            else "POTROSENA"
        )
        commission = Komisija.objects.create(
            pacijent=pacijent,
            lijek=lijek,
            datum_odobrenja=(
                cleaned.get("datum_posljednjeg_oralnog_izdavanja")
                if is_oral
                else last_date
            ) or timezone.localdate(),
            broj_odobrenih_doza=approved,
            preostale_doze=remaining,
            status=commission_status,
            napomena=f"Migracijski početni snapshot. {note}".strip(),
        )

    oral_issue = None
    if is_oral and cleaned.get("oralni_rezim_potvrdjen"):
        from .oral_therapy import (
            confirm_oral_regimen,
            oral_issue_quantity_remaining,
            record_migrated_oral_dispensing,
        )

        standard = cleaned.get("predlozeni_oralni_rezim")
        issued_on = cleaned.get("datum_posljednjeg_oralnog_izdavanja")
        individual = bool(cleaned.get("individualni_oralni_rezim"))
        tablets_per_intake = (
            cleaned.get("oralne_tablete_po_uzimanju")
            if individual else standard.tableta_po_uzimanju
        )
        intakes_per_day = (
            cleaned.get("oralna_uzimanja_dnevno")
            if individual else standard.uzimanja_dnevno
        )
        regimen_note = (cleaned.get("oralna_napomena_rezima") or "").strip()
        regimen = confirm_oral_regimen(
            patient=pacijent,
            medicine=lijek,
            tablets_per_intake=tablets_per_intake,
            intakes_per_day=intakes_per_day,
            effective_from=issued_on or timezone.localdate(),
            phase=(
                "PRILAGODJENO" if individual else standard.faza
            ),
            standard_regimen=None if individual else standard,
            doctor_note=(
                "Potvrđeni zatečeni režim iz migracijskog snapshot-a. "
                f"{regimen_note} {note}"
            ).strip(),
            user=user,
        )
        issued_quantity = cleaned.get(
            "kolicina_posljednjeg_oralnog_izdavanja"
        )
        if issued_on and issued_quantity:
            oral_issue, _ = record_migrated_oral_dispensing(
                patient=pacijent,
                regimen=regimen,
                quantity=issued_quantity,
                issued_on=issued_on,
                approved_remaining=remaining,
                commission=commission,
                migration_identifier=migration_identifier,
                note=note,
                user=user,
            )
            at_patient = oral_issue_quantity_remaining(oral_issue)

    snapshot, snapshot_created = MigracijskiSnapshotPacijenta.objects.update_or_create(
        pacijent=pacijent,
        defaults={
            "lijek": lijek,
            "datum_posljednje_terapije": last_date,
            "interval_sedmica": pacijent.interval_sedmica,
            "broj_odobrenih_doza": approved,
            # Kod oralne terapije izdavanje i klinička potrošnja nisu ista
            # stvar. Administrativno pravo je već umanjeno na Komisiji, dok
            # tablete ostaju fizički kod pacijenta i zato se ne smiju još
            # jednom upisati kao klinički iskorištene u generičkom snapshotu.
            "broj_iskoristenih_doza": Decimal("0") if is_oral else used,
            "status_preostalih_odobrenih_doza": remaining_status,
            "fizicki_u_frizideru": reserved_from_stock,
            "kod_pacijenta": at_patient,
            "sljedeca_terapija": next_date,
            "napomena": note,
            "kreirao": user,
        },
    )
    # Deklarisana pacijentska alokacija koristi samo već potvrđeno početno
    # fizičko stanje. Snapshot sam po sebi ne kreira transakciju i ne podiže
    # centralni saldo.
    if lijek and at_patient > 0 and not is_oral:
        initial_assignment = PacijentZaduzenje.objects.create(
            pacijent=pacijent,
            lijek=lijek,
            komisija=commission,
            ukupno_zaduzeno=at_patient,
            preostalo=at_patient,
            aktivno=True,
            datum_zaduzenja=None,
            migracijski_snapshot=snapshot,
        )
        unit = lijek.jedinica_zalihe_u_recenici(at_patient)
        audit_message = (
            "Početno stanje kućne terapije pri migraciji: "
            f"{at_patient:g} {unit} kod pacijenta."
        )
        upisi_log(
            user,
            "Početno stanje kućne terapije pri migraciji",
            pacijent=pacijent,
            objekat=initial_assignment,
            opis=audit_message,
        )
    if lijek and reserved_from_stock > 0:
        set_migration_reservation(
            snapshot=snapshot,
            kolicina=reserved_from_stock,
            user=user,
        )
        from .inventory import cover_pending_physical_needs

        cover_pending_physical_needs(lijek=lijek, user=user)

    upisi_log(
        user,
        "Migracija postojećeg pacijenta",
        pacijent=pacijent,
        objekat=snapshot,
        opis=(
            f"Lijek: {lijek}; posljednja terapija: {last_date or '-'}; "
            f"posljednje oralno izdavanje: "
            f"{getattr(oral_issue, 'datum_izdavanja', None) or '-'}; "
            f"interval: {pacijent.interval_sedmica} sedmica; odobreno: {approved}; "
            f"iskorišteno: {used}; rezervisano iz fizičke zalihe: "
            f"{reserved_from_stock}; "
            f"kod pacijenta: {at_patient}; protokol: "
            f"{individualni_protokol.naziv if individualni_protokol else 'standardni'}"
        ),
    )
    return pacijent
