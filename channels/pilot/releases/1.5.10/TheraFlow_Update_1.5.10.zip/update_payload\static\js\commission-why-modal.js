(() => {
    if (window.theraFlowCommissionWhyModalReady) return;
    window.theraFlowCommissionWhyModalReady = true;

    let activeTrigger = null;
    let scrollPosition = 0;

    function showDialog(dialog) {
        if (!dialog) return;
        if (typeof dialog.showModal === "function") {
            dialog.showModal();
        } else {
            dialog.setAttribute("open", "");
        }
        requestAnimationFrame(() => {
            const focusTarget = dialog.querySelector("[data-why-close], [tabindex='-1']");
            focusTarget?.focus({ preventScroll: true });
        });
    }

    function closeDialog(dialog) {
        if (typeof dialog.close === "function") {
            dialog.close();
        } else {
            dialog.removeAttribute("open");
            restorePageState();
        }
    }

    function restorePageState() {
        window.scrollTo({ top: scrollPosition, left: window.scrollX, behavior: "auto" });
        if (activeTrigger?.isConnected) {
            activeTrigger.focus({ preventScroll: true });
        }
        activeTrigger = null;
    }

    document.addEventListener("click", (event) => {
        const trigger = event.target.closest("[data-why-open]");
        if (trigger) {
            event.preventDefault();
            event.stopPropagation();
            scrollPosition = window.scrollY;
            activeTrigger = trigger;

            const dialog = document.getElementById(trigger.getAttribute("aria-controls"));
            if (!dialog) {
                showDialog(document.getElementById("commission-why-error"));
                return;
            }

            const content = dialog.querySelector("[data-why-content]");
            const error = dialog.querySelector("[data-why-error]");
            const loading = dialog.querySelector("[data-why-loading]");
            if (loading) loading.hidden = false;
            if (content) content.hidden = true;
            if (error) error.hidden = true;
            showDialog(dialog);
            requestAnimationFrame(() => {
                if (loading) loading.hidden = true;
                if (content) content.hidden = false;
                if (error) error.hidden = Boolean(content);
                dialog.querySelector("[data-why-close]")?.focus({ preventScroll: true });
            });
            return;
        }

        const closeButton = event.target.closest("[data-why-close]");
        if (closeButton) {
            event.preventDefault();
            event.stopPropagation();
            const dialog = closeButton.closest(".commission-why-dialog");
            if (dialog) closeDialog(dialog);
            return;
        }

        const dialog = event.target.closest(".commission-why-dialog");
        if (dialog && event.target === dialog) {
            closeDialog(dialog);
        }
    });

    function syncMigrationConfirmation(checkbox) {
        const form = checkbox?.closest("[data-migration-confirm-form]");
        const button = form?.querySelector("[data-migration-confirm-button]");
        if (button) button.disabled = !checkbox.checked;
    }

    document.querySelectorAll("[data-migration-confirm-checkbox]").forEach(
        syncMigrationConfirmation
    );

    document.addEventListener("change", (event) => {
        if (event.target.matches("[data-migration-confirm-checkbox]")) {
            syncMigrationConfirmation(event.target);
        }
    });

    document.querySelectorAll(".commission-why-dialog").forEach((dialog) => {
        dialog.addEventListener("close", restorePageState);
    });

    document.addEventListener("keydown", (event) => {
        if (event.key !== "Escape") return;
        const dialog = document.querySelector(".commission-why-dialog[open]");
        if (dialog) {
            event.preventDefault();
            closeDialog(dialog);
        }
    });
})();
