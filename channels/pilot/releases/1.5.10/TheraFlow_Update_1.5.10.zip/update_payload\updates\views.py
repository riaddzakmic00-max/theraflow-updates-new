from django.contrib import messages
from django.conf import settings
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import JsonResponse
from django.db import connection
from django.shortcuts import redirect
from django.views.decorators.http import require_GET, require_POST
from django.utils import timezone

from dashboard.permissions import je_admin
from patients.utils import upisi_log
from updates.models import UpdateSession

from .services.update_checker import check_for_updates
from .services.update_downloader import download_update
from .services.update_preparation import prepare_update
from .services.update_state import UpdateLockedError, register_downloaded_package
from .services.updater_launcher import UpdaterLaunchError, launch_rollback, launch_updater
from .services.update_paths import get_update_paths
from .services.update_history import sync_history
from .services.retention import CleanupError, cleanup_old_artifacts
from .services.crash_recovery import reconcile_session
from .updater.state_writer import public_state, read_state
from theraflow.version import __version__


@login_required
@user_passes_test(je_admin)
@require_POST
def check_update(request):
    upisi_log(request.user, "Provjera ažuriranja", opis="Administrator je pokrenuo ručnu provjeru ažuriranja.")
    result = check_for_updates(force=True)
    request.session["update_check_result"] = result
    upisi_log(
        request.user,
        "Rezultat provjere ažuriranja",
        opis=f"Status: {result['status']}; trenutna verzija: {result['current_version']}; nova verzija: {result.get('latest_version') or 'nema'}.",
    )
    if result["status"] in {"update_available", "up_to_date"}:
        messages.success(request, result["message"])
    else:
        messages.warning(request, result["message"])
    return redirect("postavke_sistema")


@login_required
@user_passes_test(je_admin)
@require_POST
def download_update_package(request):
    # URL i hash se nikad ne čitaju iz POST podataka. Ponovo se uzima samo
    # prethodno validirani manifest iz checker cachea / izvora.
    check_result = check_for_updates(force=False)
    if check_result["status"] != "update_available":
        messages.error(request, "Validirano dostupno ažuriranje nije pronađeno.")
        return redirect("postavke_sistema")
    upisi_log(
        request.user,
        "Početak preuzimanja ažuriranja",
        opis=f"Preuzimanje verzije {check_result['latest_version']}.",
    )
    result = download_update(check_result)
    request.session["update_download_result"] = result
    if result["status"] in {"downloaded", "already_downloaded"}:
        try:
            update_session = register_downloaded_package(check_result, result["path"], request.user)
            request.session["update_session_id"] = str(update_session.pk)
        except UpdateLockedError as exc:
            result = {"status": "error", "message": str(exc), "path": result.get("path")}
            request.session["update_download_result"] = result
    upisi_log(
        request.user,
        "Rezultat preuzimanja ažuriranja",
        opis=f"Verzija {check_result['latest_version']}; status: {result['status']}; SHA-256 provjera: {'uspješna' if result['status'] in {'downloaded', 'already_downloaded'} else 'nije potvrđena'}.",
    )
    if result["status"] in {"downloaded", "already_downloaded"}:
        messages.success(request, result["message"])
    else:
        messages.error(request, result["message"])
    return redirect("postavke_sistema")


@login_required
@user_passes_test(je_admin)
@require_POST
def prepare_update_package(request):
    update_session = UpdateSession.objects.filter(is_active=True).first()
    if not update_session:
        result = {"status": "validation_failed", "message": "Aktivan update session nije pronađen."}
    else:
        upisi_log(
            request.user,
            "Početak pripreme ažuriranja",
            opis=f"Update session: {update_session.pk}; ciljna verzija: {update_session.target_version}.",
        )
        result = prepare_update(update_session)
        upisi_log(
            request.user,
            "Rezultat pripreme ažuriranja",
            opis=f"Update session: {update_session.pk}; status: {result['status']}.",
        )
    request.session["update_prepare_result"] = result
    if result["status"] == "ready_to_install":
        messages.success(request, result["message"])
    elif result["status"] == "locked":
        messages.warning(request, result["message"])
    else:
        messages.error(request, result["message"])
    if "application/json" in request.headers.get("Accept", ""):
        return JsonResponse(result)
    return redirect("postavke_sistema")


@login_required
@user_passes_test(je_admin)
@require_POST
def install_update_package(request):
    active_sessions = list(UpdateSession.objects.filter(is_active=True)[:2])
    session = active_sessions[0] if len(active_sessions) == 1 else None
    if not session or session.status != UpdateSession.READY_TO_INSTALL:
        return JsonResponse({"status": "validation_failed", "message": "Update session nije spreman za instalaciju."}, status=409)
    dry_requested = request.POST.get("dry_run") == "1"
    if dry_requested and not settings.THERAFLOW_UPDATE_ALLOW_DRY_RUN:
        return JsonResponse({"status": "forbidden", "message": "Dry-run nije omogućen u ovoj konfiguraciji."}, status=403)
    try:
        result = launch_updater(session, request.user, dry_run=dry_requested)
    except UpdaterLaunchError as exc:
        return JsonResponse({"status": "locked", "message": str(exc)}, status=409)
    request.session["update_session_id"] = str(session.pk)
    upisi_log(request.user, "Pokretanje instalacije ažuriranja", opis=f"Update session: {session.pk}; ciljna verzija: {session.target_version}.")
    return JsonResponse(result, status=202)


@login_required
@user_passes_test(je_admin)
@require_GET
def update_status(request):
    session_id = request.session.get("update_session_id")
    session = UpdateSession.objects.filter(pk=session_id).first() if session_id else None
    session = session or UpdateSession.objects.filter(is_active=True).first() or UpdateSession.objects.order_by("-created_at").first()
    if not session:
        return JsonResponse({"status": "not_found"}, status=404)
    reconcile_session(session)
    state_path = get_update_paths().sessions / f"{session.pk}.json"
    try:
        state = read_state(state_path)
        if state.get("session_id") != str(session.pk):
            raise ValueError("Session mismatch")
    except Exception:
        return JsonResponse({"status": session.status, "target_version": session.target_version})
    status = str(state.get("status") or session.status)[:48]
    session.status = UpdateSession.READY_TO_INSTALL if status == "dry_run_completed" else status
    session.updater_pid = state.get("updater_pid") or session.updater_pid
    fields = ["status", "updater_pid"]
    if status in {
        UpdateSession.UPDATE_COMPLETED, UpdateSession.ROLLBACK_COMPLETED,
        UpdateSession.INSTALL_FAILED, UpdateSession.VALIDATION_FAILED,
        UpdateSession.DEPENDENCY_UNSUPPORTED, UpdateSession.SERVICE_STOP_FAILED,
        UpdateSession.SNAPSHOT_FAILED, UpdateSession.BACKUP_FAILED, UpdateSession.STAGING_FAILED,
        UpdateSession.INTERRUPTED,
    }:
        session.is_active = False
        session.install_completed_at = timezone.now()
        fields.extend(["is_active", "install_completed_at"])
    session.save(update_fields=fields)
    sync_history(session, state)
    result = public_state(state)
    result["target_version"] = session.target_version
    return JsonResponse(result)


@login_required
@user_passes_test(je_admin)
@require_POST
def rollback_update(request):
    session = UpdateSession.objects.filter(is_active=True).order_by("-created_at").first()
    session = session or UpdateSession.objects.filter(
        status__in=[UpdateSession.UPDATE_COMPLETED, UpdateSession.ROLLBACK_REQUIRED, UpdateSession.INSTALL_FAILED, UpdateSession.MANUAL_RECOVERY_REQUIRED]
    ).order_by("-created_at").first()
    if not session:
        return JsonResponse({"status": "not_found", "message": "Siguran rollback session nije pronađen."}, status=404)
    if request.POST.get("confirmation", "").strip() != "VRATI PRETHODNU VERZIJU":
        return JsonResponse({"status": "confirmation_required", "message": "Potrebna je puna sigurnosna potvrda."}, status=400)
    try:
        result = launch_rollback(session, request.user)
    except UpdaterLaunchError as exc:
        return JsonResponse({"status": "validation_failed", "message": str(exc)}, status=409)
    request.session["update_session_id"] = str(session.pk)
    upisi_log(request.user, "Pokretanje rollbacka ažuriranja", opis=f"Update session: {session.pk}.")
    return JsonResponse(result, status=202)


@login_required
@user_passes_test(je_admin)
@require_POST
def cleanup_updates(request):
    try:
        result = cleanup_old_artifacts()
    except CleanupError as exc:
        messages.warning(request, str(exc))
    else:
        messages.success(request, f"Sigurno čišćenje završeno. Uklonjeno stavki: {len(result['removed'])}.")
        upisi_log(request.user, "Čišćenje update artefakata", opis=f"Uklonjeno stavki: {len(result['removed'])}.")
    return redirect("postavke_sistema")


@require_GET
def update_health(request):
    if request.META.get("REMOTE_ADDR") not in {"127.0.0.1", "::1"}:
        return JsonResponse({"status": "forbidden"}, status=403)
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        UpdateSession.objects.only("pk").first()
        from dashboard.postgres_backup import automatic_backup_status

        backup_status = automatic_backup_status()
        scheduler_required = bool(getattr(settings, "PRODUCTION_MODE", False))
        scheduler_ok = backup_status["scheduler_running"] or not scheduler_required
        payload = {
            "status": "ok" if scheduler_ok else "unavailable",
            "database": "ok",
            "backup_scheduler": "ok" if backup_status["scheduler_running"] else (
                "not_required" if not scheduler_required else "unavailable"
            ),
            "version": __version__,
        }
        return JsonResponse(payload, status=200 if scheduler_ok else 503)
    except Exception:
        return JsonResponse(
            {
                "status": "unavailable",
                "database": "unavailable",
                "backup_scheduler": "unavailable",
                "version": __version__,
            },
            status=503,
        )
