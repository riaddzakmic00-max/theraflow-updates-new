"""Minimalni i prenosivi obrasci za zaključavanje transakcijskih redova."""

from django.db import connection


def select_for_update_self(queryset):
    """Zaključaj samo osnovne redove queryseta kada backend podržava ``OF``.

    Pozivaoci koji trebaju opcioni povezani red moraju ga zaključati zasebnim
    querysetom. Time ``select_related()`` nad nullable relacijom nikada nije
    prečica za zaključavanje cijelog grafa.
    """

    if connection.features.has_select_for_update_of:
        return queryset.select_for_update(of=("self",))
    # Backend bez ``FOR UPDATE OF`` ne smije naslijediti JOIN graf od
    # pozivaoca. Povezani objekti će se po potrebi učitati zasebnim upitima.
    return queryset.select_related(None).select_for_update()


def lock_instance(model, pk):
    """Zaključaj jedan osnovni model-red bez implicitnih JOIN-ova."""

    return select_for_update_self(
        model._default_manager.filter(pk=pk)
    ).get()
