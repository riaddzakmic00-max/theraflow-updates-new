import os
from decimal import Decimal, InvalidOperation
import uuid
from datetime import timedelta
from math import ceil
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Count
from django.core.validators import MaxValueValidator, MinValueValidator
from django.utils import timezone


class TerapijskiProgram(models.Model):
    """Kanonska terapija neovisna o brandu, jačini i putu primjene."""

    class KomisijskiProgramTip(models.TextChoices):
        BIOLOGIC = "BIOLOGIC", "Biološka terapija"
        HEPATITIS_B = "HEPATITIS_B", "Hepatitis B"
        UNCONFIGURED = "UNCONFIGURED", "Nije konfigurirano"

    kljuc = models.SlugField(max_length=80, unique=True)
    naziv = models.CharField(max_length=120)
    aktivan = models.BooleanField(default=True)
    commission_program_type = models.CharField(
        max_length=24,
        choices=KomisijskiProgramTip.choices,
        default=KomisijskiProgramTip.UNCONFIGURED,
        help_text="Canonical administrativni program za komisijske zahtjeve.",
    )
    protokol_kljuc = models.CharField(
        max_length=80,
        blank=True,
        help_text="Ključ faznog/calculator enginea; prazan za jednofaznu terapiju.",
    )
    zahtijeva_tezinu_za_pocetak = models.BooleanField(default=False)
    default_lijek = models.ForeignKey(
        "Lijek",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="zadani_za_terapijske_programe",
    )

    class Meta:
        ordering = ("naziv", "id")
        verbose_name = "Terapijski program"
        verbose_name_plural = "Terapijski programi"

    @property
    def prikaz_naziv(self):
        # Fazna terapija se bira kao jedna terapija, nikada kao pojedinačni SKU.
        if self.protokol_kljuc:
            return self.naziv
        if self.default_lijek_id:
            return self.default_lijek.prikaz_naziv
        return self.naziv

    def __str__(self):
        return self.prikaz_naziv


class Lijek(models.Model):
    NACIN_AMBULANTA = "AMBULANTA"
    NACIN_KUCNA_TERAPIJA = "KUCNA_TERAPIJA"
    NACIN_ORALNA_TERAPIJA = "ORALNA_TERAPIJA"
    NACINI_PRIMJENE = [
        (NACIN_AMBULANTA, "Ambulanta"),
        (NACIN_KUCNA_TERAPIJA, "Kućna terapija"),
        (NACIN_ORALNA_TERAPIJA, "Oralna terapija"),
    ]
    PUT_IV = "IV"
    PUT_SC = "SC"
    PUT_PO = "PO"
    PUTEVI_PRIMJENE = [
        (PUT_IV, "Intravenozno (IV)"),
        (PUT_SC, "Supkutano (SC)"),
        (PUT_PO, "Peroralno (PO)"),
    ]
    OBLIK_TABLETA = "TABLETA"
    FARMACEUTSKI_OBLICI = [
        (OBLIK_TABLETA, "Tableta"),
    ]

    naziv = models.CharField(max_length=100, unique=True)
    aktivan = models.BooleanField(default=True)
    terapijski_program = models.ForeignKey(
        TerapijskiProgram,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="proizvodi",
        help_text="Kanonska terapija kojoj ovaj fizički proizvod/SKU pripada.",
    )
    genericki_naziv = models.CharField("Generički naziv", max_length=100, blank=True)
    zasticeno_ime = models.CharField("Zaštićeno ime", max_length=100, blank=True)
    kucna_primjena = models.BooleanField(default=False)
    nacin_primjene = models.CharField(
        max_length=20,
        choices=NACINI_PRIMJENE,
        default=NACIN_AMBULANTA,
    )
    jacina_mg = models.DecimalField(
        "Jačina prezentacije (mg)",
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
    )
    put_primjene = models.CharField(
        "Put primjene",
        max_length=8,
        choices=PUTEVI_PRIMJENE,
        blank=True,
    )
    farmaceutski_oblik = models.CharField(
        "Farmaceutski oblik",
        max_length=20,
        choices=FARMACEUTSKI_OBLICI,
        blank=True,
    )
    broj_tableta_u_pakovanju = models.PositiveIntegerField(
        "Broj tableta u pakovanju",
        null=True,
        blank=True,
        validators=[MinValueValidator(1)],
    )
    izdavanje_cijelih_pakovanja = models.BooleanField(
        "Izdavanje samo cijelih pakovanja",
        default=False,
    )
    package_size_in_doses = models.PositiveIntegerField(
        "Veličina pakovanja u dozama",
        default=1,
        validators=[MinValueValidator(1)],
    )
    jedinica_terapije = models.CharField(
        "Jedinica terapije (jednina)",
        max_length=40,
        default="jedinica",
    )
    jedinica_terapije_mnozina = models.CharField(
        "Jedinica terapije (množina)",
        max_length=60,
        default="jedinice",
    )
    dozvoljava_decimalnu_kolicinu = models.BooleanField(
        "Dozvoljava decimalnu količinu po terapiji",
        default=False,
    )
    jedinica_zalihe = models.CharField(
        "Jedinica zalihe (jednina)",
        max_length=40,
        default="doza",
    )
    jedinica_zalihe_mnozina = models.CharField(
        "Jedinica zalihe (množina)",
        max_length=40,
        default="doze",
    )

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if not self.terapijski_program_id:
            from .medicine_registry import ensure_program_for_product

            ensure_program_for_product(self)

    def jedinica_za_kolicinu(self, kolicina=None):
        """Vrati jedinicu lijeka bez ugrađivanja naziva proizvoda u UI."""
        try:
            value = Decimal(str(kolicina))
        except (InvalidOperation, TypeError, ValueError):
            value = None
        singular, plural = self.jedinice_terapije
        return singular if value == Decimal("1") else plural

    def jedinica_zalihe_za_kolicinu(self, kolicina=None):
        try:
            value = Decimal(str(kolicina))
        except (InvalidOperation, TypeError, ValueError):
            value = None
        singular, plural = self.jedinice_zalihe
        return singular if value == Decimal("1") else plural

    def jedinica_zalihe_u_recenici(self, kolicina=None):
        """Gramatički oblik za audit rečenice, odvojen od kratke UI oznake."""
        try:
            value = Decimal(str(kolicina))
        except (InvalidOperation, TypeError, ValueError):
            value = None
        singular, plural = self.jedinice_zalihe
        if value == Decimal("1"):
            return singular
        # Rečenični oblik mora slijediti konkretni SKU, ne terapijsku grupu:
        # Ustekinumab IV je bočica, a Ustekinumab SC je šprica.
        return {
            "bočice": "bočica",
            "penovi": "penova",
            "šprice": "šprica",
            "tablete": "tableta",
        }.get(plural, plural)

    @property
    def jedinice_zalihe(self):
        configured = (self.jedinica_zalihe, self.jedinica_zalihe_mnozina)
        if configured != ("doza", "doze"):
            return configured
        fallback = {
            "infliximab": ("bočica", "bočice"),
            "vedolizumab": ("bočica", "bočice"),
            "adalimumab": ("pen", "penovi"),
        }.get(self.therapeutic_group_key)
        if fallback:
            return fallback
        if self.therapeutic_group_key == "ustekinumab":
            return (
                ("bočica", "bočice")
                if self.put_primjene == self.PUT_IV
                else ("šprica", "šprice")
            )
        return configured

    @property
    def jedinice_terapije(self):
        """Centralna jedinica lijeka, uz siguran fallback za stare zapise."""
        configured = (
            self.jedinica_terapije,
            self.jedinica_terapije_mnozina,
        )
        if configured != ("jedinica", "jedinice"):
            return configured
        return {
            "infliximab": ("bočica", "bočice"),
            "vedolizumab": ("bočica", "bočice"),
            "adalimumab": ("pen", "pena"),
            "ustekinumab": ("šprica", "šprice"),
        }.get(self.therapeutic_group_key, configured)

    @property
    def effective_package_size(self):
        from .package_sizes import package_size_for

        return package_size_for(self)

    @property
    def procurement_metadata(self):
        from .package_sizes import procurement_breakdown

        return procurement_breakdown(Decimal("0"), self)

    @property
    def package_validation_message(self):
        from .package_sizes import package_multiple_error

        return package_multiple_error(self)

    @property
    def kucna_terapija(self):
        return self.kucna_primjena or self.nacin_primjene == self.NACIN_KUCNA_TERAPIJA

    @property
    def oralna_terapija(self):
        return self.nacin_primjene == self.NACIN_ORALNA_TERAPIJA

    @property
    def brand_name(self):
        return self.zasticeno_ime or self.naziv

    @property
    def generic_name(self):
        return self.genericki_naziv or self.naziv

    @property
    def presentation_strength_label(self):
        """Formatirana jačina/volumen fizičke prezentacije za aktivni UI."""
        if self.jacina_mg is None:
            return ""
        strength = format(Decimal(str(self.jacina_mg)).normalize(), "f")
        if (
            self.therapeutic_group_key == "ustekinumab"
            and self.put_primjene == self.PUT_SC
            and Decimal(str(self.jacina_mg)) == Decimal("90")
        ):
            return f"{strength} mg/1 mL"
        return f"{strength} mg"

    @property
    def prikaz_naziv(self):
        brand = self.brand_name
        generic = self.generic_name
        presentation = []
        if self.presentation_strength_label:
            presentation.append(self.presentation_strength_label)
        if self.put_primjene:
            presentation.append(self.put_primjene)
        display_brand = " ".join((brand, *presentation)).strip()
        if generic and generic.lower() != brand.lower():
            return f"{display_brand} ({generic})"
        return display_brand

    @property
    def therapeutic_group_key(self):
        from .medication_groups import medicine_group_key

        return medicine_group_key(self)

    @property
    def therapeutic_group_name(self):
        from .medication_groups import therapy_group_label

        return therapy_group_label(self)

    @property
    def therapy_group(self):
        from .medication_groups import get_therapy_group

        return get_therapy_group(self)

    def equivalent_ids(self):
        from .medication_groups import equivalent_medicine_ids

        if not hasattr(self, "_equivalent_ids_cache"):
            self._equivalent_ids_cache = equivalent_medicine_ids(self)
        return self._equivalent_ids_cache

    def aktivni_protokol(self):
        return (
            self.terapijskiprotokol_set
            .filter(aktivan=True)
            .annotate(broj_koraka=Count("koraci"))
            .order_by("-broj_koraka", "id")
            .first()
        )

    def __str__(self):
        return self.prikaz_naziv


class TerapijskaFaza(models.Model):
    """Faza terapijskog programa i konkretni proizvod potreban u toj fazi."""

    program = models.ForeignKey(
        TerapijskiProgram,
        on_delete=models.CASCADE,
        related_name="faze",
    )
    kljuc = models.CharField(max_length=40)
    naziv = models.CharField(max_length=120)
    redoslijed = models.PositiveSmallIntegerField(default=1)
    lijek = models.ForeignKey(
        Lijek,
        on_delete=models.PROTECT,
        related_name="terapijske_faze",
    )
    put_primjene = models.CharField(
        max_length=8,
        choices=Lijek.PUTEVI_PRIMJENE,
        blank=True,
    )
    zahtijeva_tezinu = models.BooleanField(default=False)
    interval_sedmica = models.PositiveSmallIntegerField(null=True, blank=True)
    aktivna = models.BooleanField(default=True)

    class Meta:
        ordering = ("program", "redoslijed", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("program", "kljuc"),
                name="uniq_terapijski_program_faza_kljuc",
            ),
            models.UniqueConstraint(
                fields=("program", "redoslijed"),
                name="uniq_terapijski_program_faza_redoslijed",
            ),
        ]

    def clean(self):
        super().clean()
        if (
            self.program_id
            and self.lijek_id
            and self.lijek.terapijski_program_id != self.program_id
        ):
            raise ValidationError(
                {"lijek": "Proizvod mora pripadati terapijskom programu faze."}
            )

    def __str__(self):
        return f"{self.program.naziv} — {self.naziv}"


class TerapijskiProtokol(models.Model):
    TIP_INDUKCIJA = "INDUKCIJA"
    TIP_ODRZAVANJE = "ODRZAVANJE"
    TIP_KOMBINOVANO = "KOMBINOVANO"

    TIPOVI_TERAPIJE = [
        (TIP_INDUKCIJA, "Indukcija"),
        (TIP_ODRZAVANJE, "Održavanje"),
        (TIP_KOMBINOVANO, "Kombinovano"),
    ]

    lijek = models.ForeignKey(Lijek, on_delete=models.CASCADE)
    naziv = models.CharField(max_length=150)
    tip_terapije = models.CharField(
        max_length=20,
        choices=TIPOVI_TERAPIJE,
        default=TIP_ODRZAVANJE
    )
    indukcijske_sedmice = models.CharField(
        max_length=100,
        blank=True,
        help_text='Sedmice od početka terapije, npr. "0,2,6".'
    )
    interval_odrzavanja_sedmica = models.PositiveIntegerField(default=8)
    doza_po_aplikaciji = models.PositiveIntegerField(default=1)
    sigurnosna_rezerva_primjena = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
        help_text="Broj kompletnih terapijskih primjena koje se čuvaju kao rezerva.",
    )
    maksimalna_sigurnosna_rezerva_primjena = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
        help_text="Najveći dozvoljeni broj kompletnih primjena u rezervi.",
    )
    aktivan = models.BooleanField(default=True)
    napomena = models.TextField(blank=True)

    class Meta:
        verbose_name = "Terapijski protokol"
        verbose_name_plural = "Terapijski protokoli"
        ordering = ["lijek__naziv", "naziv"]
        constraints = [
            models.UniqueConstraint(
                fields=["lijek", "naziv"],
                name="uniq_terapijski_protokol_lijek_naziv",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(sigurnosna_rezerva_primjena__isnull=True)
                    | models.Q(
                        maksimalna_sigurnosna_rezerva_primjena__isnull=True
                    )
                    | models.Q(
                        maksimalna_sigurnosna_rezerva_primjena__gte=models.F(
                            "sigurnosna_rezerva_primjena"
                        )
                    )
                ),
                name="standardni_protokol_rezerva_unutar_maksimuma",
            ),
        ]

    def __str__(self):
        return f"{self.lijek} - {self.naziv}"

    def save(self, *args, **kwargs):
        from .medication_groups import maintenance_interval_weeks

        if self.lijek_id:
            self.interval_odrzavanja_sedmica = maintenance_interval_weeks(
                self.lijek,
                self.interval_odrzavanja_sedmica,
            )
            update_fields = kwargs.get("update_fields")
            if update_fields is not None:
                kwargs["update_fields"] = set(update_fields) | {
                    "interval_odrzavanja_sedmica"
                }
        super().save(*args, **kwargs)

    def indukcijske_sedmice_lista(self):
        sedmice = []

        for dio in (self.indukcijske_sedmice or "").split(","):
            dio = dio.strip()
            if not dio:
                continue

            try:
                sedmice.append(int(dio))
            except ValueError:
                continue

        return sorted(set(sedmice))

    def ima_indukciju(self):
        return self.tip_terapije in [
            self.TIP_INDUKCIJA,
            self.TIP_KOMBINOVANO,
        ] and len(self.indukcijske_sedmice_lista()) > 0

    def faza_za_broj_aplikacija(self, broj_aplikacija):
        if self.ima_indukciju() and broj_aplikacija < len(self.indukcijske_sedmice_lista()):
            return "Indukcija"

        return "Održavanje"

    def sedmica_do_sljedece_aplikacije(self, broj_aplikacija_nakon_terapije):
        sedmice = self.indukcijske_sedmice_lista()

        if broj_aplikacija_nakon_terapije <= 0:
            return 0

        if self.ima_indukciju() and broj_aplikacija_nakon_terapije < len(sedmice):
            prethodna_sedmica = sedmice[broj_aplikacija_nakon_terapije - 1]
            sljedeca_sedmica = sedmice[broj_aplikacija_nakon_terapije]
            return max(sljedeca_sedmica - prethodna_sedmica, 1)

        return self.interval_odrzavanja_sedmica

    def doze_za_period(self, broj_sedmica):
        from .medication_groups import maintenance_interval_weeks

        korak_odrzavanja = self.korak_odrzavanja()
        if korak_odrzavanja:
            interval = maintenance_interval_weeks(
                self.lijek,
                korak_odrzavanja.interval_sedmica or self.interval_odrzavanja_sedmica,
            )
            if not interval:
                return 0
            return ceil(broj_sedmica / interval) * korak_odrzavanja.broj_jedinica

        if not self.interval_odrzavanja_sedmica:
            return 0

        return ceil(broj_sedmica / self.interval_odrzavanja_sedmica) * self.doza_po_aplikaciji

    def aktivni_koraci(self):
        return self.koraci.filter(aktivan=True).order_by("faza", "redoslijed", "sedmica_od_pocetka")

    def indukcijski_koraci(self):
        return self.koraci.filter(
            aktivan=True,
            faza=TerapijskiKorakProtokola.FAZA_INDUKCIJA,
        ).order_by("redoslijed", "sedmica_od_pocetka")

    def odrzavajuci_koraci(self):
        return self.koraci.filter(
            aktivan=True,
            faza=TerapijskiKorakProtokola.FAZA_ODRZAVANJE,
        ).order_by("redoslijed", "sedmica_od_pocetka")

    def korak_odrzavanja(self):
        return self.odrzavajuci_koraci().last()

    def ima_korake(self):
        return self.koraci.filter(aktivan=True).exists()


class TerapijskiKorakProtokola(models.Model):
    FAZA_INDUKCIJA = "INDUKCIJA"
    FAZA_ODRZAVANJE = "ODRZAVANJE"
    NACIN_AMBULANTA = "AMBULANTA"
    NACIN_KUCNA_TERAPIJA = "KUCNA_TERAPIJA"

    FAZE = [
        (FAZA_INDUKCIJA, "Indukcija"),
        (FAZA_ODRZAVANJE, "Održavanje"),
    ]
    NACINI_PRIMJENE = [
        (NACIN_AMBULANTA, "Ambulanta"),
        (NACIN_KUCNA_TERAPIJA, "Kućna terapija"),
    ]

    protokol = models.ForeignKey(
        TerapijskiProtokol,
        on_delete=models.CASCADE,
        related_name="koraci",
    )
    naziv_koraka = models.CharField(max_length=150)
    faza = models.CharField(max_length=20, choices=FAZE)
    sedmica_od_pocetka = models.IntegerField(null=True, blank=True)
    redoslijed = models.PositiveIntegerField(default=1)
    doza_mg = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    broj_jedinica = models.DecimalField(max_digits=8, decimal_places=2, default=1)
    interval_sedmica = models.IntegerField(null=True, blank=True)
    nacin_primjene_koraka = models.CharField(
        max_length=20,
        choices=NACINI_PRIMJENE,
        default=NACIN_AMBULANTA,
    )
    aktivan = models.BooleanField(default=True)
    napomena = models.TextField(blank=True)

    def clean(self):
        super().clean()
        if not self.aktivan:
            return
        errors = {}
        if self.broj_jedinica is None or self.broj_jedinica <= 0:
            errors["broj_jedinica"] = (
                "Unesite pozitivnu fizičku količinu lijeka za ovu fazu."
            )
        if not self.nacin_primjene_koraka:
            errors["nacin_primjene_koraka"] = "Odaberite mjesto primjene."
        if self.faza == self.FAZA_INDUKCIJA and self.sedmica_od_pocetka is None:
            errors["sedmica_od_pocetka"] = (
                "Unesite sedmicu primjene indukcijske faze."
            )
        if (
            self.faza == self.FAZA_ODRZAVANJE
            and (self.interval_sedmica is None or self.interval_sedmica <= 0)
        ):
            errors["interval_sedmica"] = (
                "Unesite interval ponavljanja faze održavanja."
            )
        # Infliximab se može dozirati po tjelesnoj masi, pa fiksna mg doza
        # nije obavezna; fizička količina bočica ostaje obavezna iznad.
        if (
            self.protokol_id
            and self.protokol.lijek.therapeutic_group_key != "infliximab"
            and (self.doza_mg is None or self.doza_mg <= 0)
        ):
            errors["doza_mg"] = "Unesite dozu lijeka za ovu fazu."
        if errors:
            raise ValidationError(errors)

    class Meta:
        verbose_name = "Terapijski korak protokola"
        verbose_name_plural = "Terapijski koraci protokola"
        ordering = ["protokol__lijek__naziv", "protokol__naziv", "faza", "redoslijed"]

    def __str__(self):
        return f"{self.protokol} - {self.naziv_koraka}"

    def save(self, *args, **kwargs):
        from .medication_groups import maintenance_interval_weeks

        if self.protokol_id and self.faza == self.FAZA_ODRZAVANJE:
            obavezni_interval = maintenance_interval_weeks(self.protokol.lijek)
            if obavezni_interval:
                self.interval_sedmica = obavezni_interval
                self.nacin_primjene_koraka = self.NACIN_KUCNA_TERAPIJA
                update_fields = kwargs.get("update_fields")
                if update_fields is not None:
                    kwargs["update_fields"] = set(update_fields) | {
                        "interval_sedmica",
                        "nacin_primjene_koraka",
                    }
        super().save(*args, **kwargs)

    def format_broj(self, value):
        if value is None:
            return ""
        if value == value.to_integral_value():
            return str(int(value))
        return str(value.normalize())

    def opis_doze(self):
        dijelovi = []
        if self.doza_mg is not None:
            dijelovi.append(f"{self.format_broj(self.doza_mg)} mg")
        dijelovi.append(f"{self.format_broj(self.broj_jedinica)} jedinica")
        return " / ".join(dijelovi)

    def opis_za_prikaz(self):
        nacin = self.get_nacin_primjene_koraka_display()
        if self.faza == self.FAZA_INDUKCIJA:
            sedmica = self.sedmica_od_pocetka if self.sedmica_od_pocetka is not None else "-"
            return f"Indukcija sedmica {sedmica} — {self.opis_doze()} ({nacin})"

        from .medication_groups import maintenance_interval_weeks

        interval = maintenance_interval_weeks(
            self.protokol.lijek,
            self.interval_sedmica or self.protokol.interval_odrzavanja_sedmica,
        )
        return f"Održavanje — {self.opis_doze()} svake {interval} sedmice ({nacin})"


class StandardniOralniRezim(models.Model):
    """Konfiguracijski predložak oralnog režima vezan za prezentaciju lijeka.

    Ovo nije klinička potvrda za pacijenta. Potvrđeni, historijski režim i
    dalje se čuva u ``OralniTerapijskiRezim`` kao snapshot odluke ljekara.
    """

    FAZA_INDUKCIJA = "INDUKCIJA"
    FAZA_ODRZAVANJE = "ODRZAVANJE"
    FAZA_PRILAGODJENO = "PRILAGODJENO"
    FAZE = [
        (FAZA_INDUKCIJA, "Indukcija"),
        (FAZA_ODRZAVANJE, "Održavanje"),
        (FAZA_PRILAGODJENO, "Prilagođeno"),
    ]

    lijek = models.ForeignKey(
        Lijek,
        on_delete=models.PROTECT,
        related_name="standardni_oralni_rezimi",
    )
    naziv = models.CharField(max_length=150)
    tableta_po_uzimanju = models.DecimalField(max_digits=6, decimal_places=2)
    uzimanja_dnevno = models.PositiveSmallIntegerField()
    faza = models.CharField(max_length=20, choices=FAZE, default=FAZA_ODRZAVANJE)
    aktivan = models.BooleanField(default=True)
    izvor_konfiguracije = models.CharField(max_length=200, blank=True)
    napomena = models.TextField(blank=True)
    kreirano = models.DateTimeField(auto_now_add=True)
    izmijenjeno = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["lijek__naziv", "naziv", "id"]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(tableta_po_uzimanju__gt=0),
                name="std_oral_tablets_gt0",
            ),
            models.CheckConstraint(
                condition=models.Q(uzimanja_dnevno__gt=0),
                name="std_oral_intakes_gt0",
            ),
            models.UniqueConstraint(
                fields=["lijek", "naziv"],
                name="uniq_std_oral_regimen_name",
            ),
        ]
        indexes = [
            models.Index(
                fields=["lijek", "aktivan"],
                name="std_oral_drug_active_idx",
            ),
        ]

    @property
    def tableta_dnevno(self):
        return Decimal(str(self.tableta_po_uzimanju or 0)) * Decimal(
            str(self.uzimanja_dnevno or 0)
        )

    def clean(self):
        super().clean()
        if self.lijek_id and (
            not self.lijek.oralna_terapija
            or self.lijek.farmaceutski_oblik != Lijek.OBLIK_TABLETA
        ):
            raise ValidationError(
                {"lijek": "Standardni oralni režim zahtijeva oralni lijek u tabletama."}
            )

    def __str__(self):
        return f"{self.lijek.prikaz_naziv} — {self.naziv}"


class Pacijent(models.Model):
    FAZA_INDUKCIJA = "INDUKCIJA"
    FAZA_ODRZAVANJE = "ODRZAVANJE"
    FAZA_INDIVIDUALNI = "INDIVIDUALNI"

    POCETNE_FAZE = [
        (FAZA_INDUKCIJA, "Novi pacijent / počinje terapiju"),
        (FAZA_ODRZAVANJE, "Nastavlja standardni protokol"),
        (FAZA_INDIVIDUALNI, "Nastavlja individualni protokol"),
    ]

    ime = models.CharField(max_length=100)
    prezime = models.CharField(max_length=100)
    # Stvarni JMBG je i dalje jedinstven. NULL je dozvoljen isključivo za
    # kontrolisane demo/migracijske kartone koji nemaju dostupan JMBG; više
    # NULL vrijednosti ne narušava jedinstvenost stvarnih identifikatora.
    jmbg = models.CharField(max_length=13, unique=True, null=True, blank=True)
    broj_kartona = models.CharField(max_length=50, blank=True)
    spol = models.CharField(max_length=10, blank=True)
    datum_rodenja = models.DateField(null=True, blank=True)
    adresa = models.CharField(max_length=200, blank=True)
    kanton = models.CharField(max_length=100, blank=True)
    mkb_sifra = models.CharField(max_length=20, blank=True)
    telefon = models.CharField(max_length=50, blank=True)
    dijagnoza = models.CharField(max_length=200)
    terapijski_program = models.ForeignKey(
        TerapijskiProgram,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="pacijenti",
        help_text="Autoritativni identitet terapije; lijek je trenutni/legacy SKU.",
    )
    lijek = models.ForeignKey(Lijek, on_delete=models.SET_NULL, null=True, blank=True)
    terapijski_protokol = models.ForeignKey(
        TerapijskiProtokol,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    predlozeni_oralni_rezim = models.ForeignKey(
        StandardniOralniRezim,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="pacijenti_sa_prijedlogom",
        help_text=(
            "Konfiguracijski prijedlog; ne predstavlja doktorsku potvrdu režima."
        ),
    )
    pocetna_faza_terapije = models.CharField(
        max_length=20,
        choices=POCETNE_FAZE,
        default=FAZA_INDUKCIJA,
    )
    interval_sedmica = models.IntegerField(default=8)
    kolicina_po_terapiji = models.DecimalField(
        "Količina po jednoj terapiji",
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        help_text=(
            "Potvrđena količina lijeka koju pacijent prima po jednoj terapiji."
        ),
    )
    aktivan = models.BooleanField(default=True)

    def save(self, *args, **kwargs):
        from .medication_groups import maintenance_interval_weeks

        self.jmbg = (self.jmbg or "").strip() or None

        if self.lijek_id and self.pocetna_faza_terapije != self.FAZA_INDIVIDUALNI:
            self.interval_sedmica = maintenance_interval_weeks(
                self.lijek,
                self.interval_sedmica,
            )
            update_fields = kwargs.get("update_fields")
            if update_fields is not None:
                kwargs["update_fields"] = set(update_fields) | {"interval_sedmica"}
        super().save(*args, **kwargs)

    class Meta:
        indexes = [
            models.Index(fields=["aktivan", "lijek"], name="pat_active_drug_idx"),
        ]
        constraints = [
            models.CheckConstraint(
                condition=(
                    models.Q(kolicina_po_terapiji__isnull=True)
                    | models.Q(kolicina_po_terapiji__gt=0)
                ),
                name="pacijent_kolicina_po_terapiji_pozitivna",
            ),
        ]

    @property
    def ima_unesenu_kolicinu_po_terapiji(self):
        return bool(
            self.kolicina_po_terapiji is not None
            and self.kolicina_po_terapiji > 0
        )

    def jedinica_terapije_za_prikaz(self, kolicina=None):
        if not self.lijek_id:
            return "jedinica"
        return self.lijek.jedinica_za_kolicinu(
            self.kolicina_po_terapiji if kolicina is None else kolicina
        )

    def efektivni_interval_sedmica(self, fallback=None):
        from .individual_protocols import get_interval_weeks

        return get_interval_weeks(self) if self.pk else (fallback or self.interval_sedmica or 8)

    def __str__(self):
        return f"{self.ime} {self.prezime}"

    @property
    def terapija_za_prikaz(self):
        if self.terapijski_program_id:
            return self.terapijski_program.naziv
        if self.lijek_id:
            return self.lijek.therapeutic_group_name
        return "Nije odabrana"

    @property
    def trenutni_proizvod(self):
        state = self.aktivni_fazni_protokol()
        if state:
            from .phased_protocols import current_phase_details

            return current_phase_details(state)["medicine"]
        return self.lijek

    def posljednja_stvarno_primljena_terapija(self):
        """Najnovija potvrđena primjena, uključujući sigurnu migracijsku historiju.

        Izdavanje lijeka za kućnu terapiju nije dokaz njegove primjene i zato
        nije klinički vremenski oslonac.
        """
        from .request_cache import get_or_set
        from .therapy_history import (
            actually_administered_therapy_query,
            is_actually_administered_therapy,
        )

        def load():
            prefetched = getattr(self, "_planning_therapies", None)
            if prefetched is None:
                prefetched = getattr(self, "_workflow_therapies", None)
            if prefetched is not None:
                equivalent_ids = set(self.lijek.equivalent_ids()) if self.lijek_id else None
                candidates = (
                    therapy for therapy in prefetched
                    if (
                        (equivalent_ids is None or therapy.lijek_id in equivalent_ids)
                        and is_actually_administered_therapy(therapy)
                    )
                )
                return max(
                    candidates,
                    key=lambda therapy: (therapy.datum, therapy.pk or 0),
                    default=None,
                )
            queryset = actually_administered_therapy_query(self.terapija_set.all())
            if self.lijek_id:
                queryset = queryset.filter(lijek_id__in=self.lijek.equivalent_ids())
            return queryset.order_by("-datum", "-id").first()

        return get_or_set("last_received_therapy", self.pk, load) if self.pk else None

    def zadnja_terapija(self):
        """Kompatibilni alias za kanonsku posljednju stvarno primljenu terapiju."""

        return self.posljednja_stvarno_primljena_terapija()

    def aktivni_protokol(self):
        from .individual_protocols import get_effective_protocol

        return get_effective_protocol(self)

    def aktivni_fazni_protokol(self):
        if not self.pk:
            return None
        try:
            state = self.fazni_protokol
        except FazniProtokolPacijenta.DoesNotExist:
            return None
        return state if state.aktivan else None

    def broj_dosadasnjih_aplikacija(self):
        if not self.lijek or not self.pk:
            return 0

        from .request_cache import get_or_set
        from .therapy_history import (
            actually_administered_therapy_query,
            is_actually_administered_therapy,
        )

        def load_count():
            prefetched = getattr(self, "_workflow_therapies", None)
            if prefetched is None:
                prefetched = getattr(self, "_planning_therapies", None)
            if prefetched is not None:
                equivalent_ids = set(self.lijek.equivalent_ids())
                return sum(
                    1 for therapy in prefetched
                    if (
                        therapy.lijek_id in equivalent_ids
                        and is_actually_administered_therapy(therapy)
                    )
                )
            return actually_administered_therapy_query(
                self.terapija_set.filter(
                    lijek_id__in=self.lijek.equivalent_ids()
                )
            ).count()

        return get_or_set(
            "patient_application_count",
            self.pk,
            load_count,
        )

    def broj_aplikacija_za_protokol(self):
        broj = self.broj_dosadasnjih_aplikacija()
        protokol = self.aktivni_protokol()

        if self.pocetna_faza_terapije == self.FAZA_ODRZAVANJE and protokol:
            if protokol.ima_korake():
                return max(broj, protokol.indukcijski_koraci().count())
            return max(broj, len(protokol.indukcijske_sedmice_lista()))

        return broj

    def terapijski_korak_za_redni_broj(self, redni_broj):
        from .individual_protocols import get_step_for_application_number

        return get_step_for_application_number(self, redni_broj)

    def terapijska_faza_za_redni_broj(self, redni_broj):
        korak = self.terapijski_korak_za_redni_broj(redni_broj)
        if korak:
            return korak.get_faza_display()

        if self.pocetna_faza_terapije == self.FAZA_ODRZAVANJE:
            return "Održavanje"

        protokol = self.aktivni_protokol()
        if not protokol:
            return "Nije definisan protokol"

        return protokol.faza_za_broj_aplikacija(max(int(redni_broj or 1) - 1, 0))

    def trenutni_korak_terapije(self):
        from .individual_protocols import get_current_step

        return get_current_step(self)

    def sljedeci_korak_terapije(self):
        return self.trenutni_korak_terapije()

    def nacin_primjene_trenutnog_koraka(self):
        fazni_state = self.aktivni_fazni_protokol()
        if fazni_state:
            return (
                TerapijskiKorakProtokola.NACIN_KUCNA_TERAPIJA
                if fazni_state.sc_je_kucna_terapija
                else TerapijskiKorakProtokola.NACIN_AMBULANTA
            )
        from .individual_protocols import get_application_location

        return get_application_location(self)

    def trenutni_korak_je_ambulanta(self):
        return self.nacin_primjene_trenutnog_koraka() == TerapijskiKorakProtokola.NACIN_AMBULANTA

    def trenutni_korak_je_kucna_terapija(self):
        return self.nacin_primjene_trenutnog_koraka() == TerapijskiKorakProtokola.NACIN_KUCNA_TERAPIJA

    def poruka_prelaska_na_kucnu_terapiju(self):
        if not self.lijek or not self.aktivni_protokol():
            return ""

        trenutni = self.trenutni_korak_terapije()
        if not trenutni or trenutni.nacin_primjene_koraka != TerapijskiKorakProtokola.NACIN_AMBULANTA:
            return ""

        protokol = self.aktivni_protokol()
        koraci = list(protokol.indukcijski_koraci()) + list(protokol.odrzavajuci_koraci())
        try:
            index = next(i for i, korak in enumerate(koraci) if korak.id == trenutni.id)
        except StopIteration:
            return ""

        sljedeci = koraci[index + 1] if index + 1 < len(koraci) else None
        if sljedeci and sljedeci.nacin_primjene_koraka == TerapijskiKorakProtokola.NACIN_KUCNA_TERAPIJA:
            return "Pacijent je spreman za kućnu terapiju nakon sljedeće ambulantne doze."

        return ""

    def sljedeci_korak_opis(self):
        fazni_state = self.aktivni_fazni_protokol()
        if fazni_state:
            from .phased_protocols import current_phase_details

            details = current_phase_details(fazni_state)
            return (
                f"{details['label']} — {details['dose_mg']:g} mg / "
                f"{details['units']:g} jedinica"
            )
        korak = self.sljedeci_korak_terapije()
        if korak:
            return korak.opis_za_prikaz()

        protokol = self.aktivni_protokol()
        if protokol:
            return f"{self.terapijska_faza()} — {self.doza_po_aplikaciji():g} jedinica"

        return f"Fallback interval — {self.interval_sedmica} sedmica"

    def terapijska_faza(self):
        fazni_state = self.aktivni_fazni_protokol()
        if fazni_state:
            from .phased_protocols import current_phase_details

            return current_phase_details(fazni_state)["label"]
        if self.pocetna_faza_terapije == self.FAZA_ODRZAVANJE:
            return "Održavanje"

        from .individual_protocols import get_current_therapy_phase

        return get_current_therapy_phase(self)

    def sedmica_do_sljedece_aplikacije(self, nakon_nove_aplikacije=False):
        fazni_state = self.aktivni_fazni_protokol()
        if fazni_state:
            if fazni_state.faza == fazni_state.FAZA_CEKA_IV:
                return 8
            return fazni_state.interval_odrzavanja_sedmica
        from .individual_protocols import get_interval_weeks

        return get_interval_weeks(self, after_application=nakon_nove_aplikacije)

    def doza_po_aplikaciji(self):
        fazni_state = self.aktivni_fazni_protokol()
        if fazni_state:
            from .phased_protocols import current_phase_details

            return current_phase_details(fazni_state)["units"]
        from .individual_protocols import get_units_per_application

        return get_units_per_application(self)

    def sljedeca_terapija(self):
        from .individual_protocols import get_next_therapy_date

        return get_next_therapy_date(self)

    def aktivna_komisija(self):
        return self.vazece_komisije().first()

    def vazece_komisije(self, lijek=None):
        queryset = self.komisija_set.filter(
            status__in=Komisija.VAZECI_STATUSI,
            preostale_doze__gt=0,
        )
        if lijek:
            queryset = queryset.filter(lijek_id__in=lijek.equivalent_ids())
        elif self.lijek_id:
            queryset = queryset.filter(lijek_id__in=self.lijek.equivalent_ids())
        return queryset.order_by("datum_odobrenja", "id")

    def zaduzeno_lijekova(self, lijek=None):
        lijek = lijek or self.lijek
        prefetched = getattr(self, "_workflow_assignments", None)
        if prefetched is not None:
            medicine_ids = set(lijek.equivalent_ids()) if lijek else None
            return sum(
                (
                    Decimal(str(item.preostalo or 0))
                    for item in prefetched
                    if medicine_ids is None or item.lijek_id in medicine_ids
                ),
                Decimal("0"),
            )

        zaduzenja = self.pacijentzaduzenje_set.filter(aktivno=True)
        if lijek:
            zaduzenja = zaduzenja.filter(lijek_id__in=lijek.equivalent_ids())

        return sum(
            (Decimal(str(zaduzenje.preostalo or 0)) for zaduzenje in zaduzenja),
            Decimal("0")
        )

    def referentni_datum_pokrivenosti(self, fallback_date=None):
        if self.lijek_id and self.pk:
            equivalent_ids = self.lijek.equivalent_ids()
            prefetched = getattr(self, "_workflow_therapies", None)
            if prefetched is not None:
                zadnje_izdavanje = next((
                    item for item in prefetched
                    if item.lijek_id in equivalent_ids
                    and item.tip_evidencije == Terapija.TIP_KUCNA_TERAPIJA
                ), None)
            else:
                zadnje_izdavanje = self.terapija_set.filter(
                    lijek_id__in=equivalent_ids,
                    tip_evidencije=Terapija.TIP_KUCNA_TERAPIJA,
                ).exclude(workflow_status=Terapija.STATUS_PONISTENA).order_by("-datum", "-id").first()
            if zadnje_izdavanje:
                return zadnje_izdavanje.datum, "Računato iz izdate kućne terapije"

            zadnja_terapija = self.zadnja_terapija()
            if zadnja_terapija:
                return zadnja_terapija.datum, "Računato od zadnje evidentirane terapije"

        if fallback_date:
            return fallback_date, "Računato od datuma dodjele"

        return timezone.now().date(), "Računato od današnjeg datuma"

    def izracunaj_pokriven_do(self, preostale_doze, fallback_date=None):
        preostale_doze = Decimal(str(preostale_doze or 0))
        if preostale_doze <= 0:
            return None, "Nije pokriven"

        referentni_datum, izvor = self.referentni_datum_pokrivenosti(fallback_date)
        protokol = self.aktivni_protokol()

        if self.trenutni_korak_je_kucna_terapija():
            from .services import calculate_home_therapy_coverage

            coverage = calculate_home_therapy_coverage(
                self,
                doses_at_patient=preostale_doze,
                reference_date=referentni_datum,
            )
            if coverage["covered_until"]:
                return (
                    coverage["covered_until"],
                    f"{izvor}; simulirano po terapijskom protokolu kućne terapije",
                )
            return None, "Nije pokriven"

        if protokol and protokol.ima_korake():
            pokriven_do = self._simuliraj_pokrivenost_po_protokolu(
                preostale_doze,
                referentni_datum,
            )
            if pokriven_do:
                return pokriven_do, f"{izvor}; simulirano po terapijskom protokolu"
            return None, "Nije pokriven"

        interval = self.sedmica_do_sljedece_aplikacije() or self.interval_sedmica or 8

        doza_po_aplikaciji = Decimal(str(self.doza_po_aplikaciji() or 0))
        if doza_po_aplikaciji <= 0:
            return None, "Nije pokriven"

        broj_aplikacija = int(preostale_doze / doza_po_aplikaciji)
        if broj_aplikacija <= 0:
            return None, "Nije pokriven"

        return referentni_datum + timedelta(
            weeks=broj_aplikacija * interval
        ), izvor

    def _interval_odrzavanja_za_korak(self, korak, protokol=None):
        protokol = protokol or self.aktivni_protokol()
        if self.pocetna_faza_terapije == self.FAZA_ODRZAVANJE:
            return (korak.interval_sedmica if korak else None) or (
                protokol.interval_odrzavanja_sedmica if protokol else None
            ) or self.interval_sedmica or 8

        return (korak.interval_sedmica if korak else None) or (
            protokol.interval_odrzavanja_sedmica if protokol else None
        ) or 8

    def _sedmice_do_koraka_iz_prethodnog(self, redni_broj):
        protokol = self.aktivni_protokol()
        prethodni = self.terapijski_korak_za_redni_broj(redni_broj - 1)
        sljedeci = self.terapijski_korak_za_redni_broj(redni_broj)

        if not sljedeci:
            return None

        if (
            prethodni
            and prethodni.id == sljedeci.id
            and sljedeci.faza == TerapijskiKorakProtokola.FAZA_ODRZAVANJE
        ):
            return self._interval_odrzavanja_za_korak(sljedeci, protokol)

        if prethodni and prethodni.sedmica_od_pocetka is not None and sljedeci.sedmica_od_pocetka is not None:
            return max(sljedeci.sedmica_od_pocetka - prethodni.sedmica_od_pocetka, 0)

        if redni_broj <= 1 and sljedeci.sedmica_od_pocetka is not None:
            return max(sljedeci.sedmica_od_pocetka, 0)

        return self._interval_odrzavanja_za_korak(sljedeci, protokol)

    def _datum_sljedeceg_koraka_iz_referentnog(self, redni_broj, referentni_datum):
        prethodni = self.terapijski_korak_za_redni_broj(redni_broj - 1)
        sljedeci = self.terapijski_korak_za_redni_broj(redni_broj)

        if not sljedeci:
            return None

        if (
            prethodni
            and prethodni.id == sljedeci.id
            and sljedeci.faza == TerapijskiKorakProtokola.FAZA_ODRZAVANJE
        ):
            interval = self._interval_odrzavanja_za_korak(sljedeci)
            return referentni_datum + timedelta(weeks=interval)

        if prethodni and prethodni.sedmica_od_pocetka is not None and sljedeci.sedmica_od_pocetka is not None:
            return referentni_datum + timedelta(
                weeks=max(sljedeci.sedmica_od_pocetka - prethodni.sedmica_od_pocetka, 0)
            )

        if redni_broj <= 1 and sljedeci.sedmica_od_pocetka is not None:
            return referentni_datum + timedelta(weeks=max(sljedeci.sedmica_od_pocetka, 0))

        interval = self._interval_odrzavanja_za_korak(sljedeci)
        return referentni_datum + timedelta(weeks=interval)

    def _simuliraj_pokrivenost_po_protokolu(self, preostale_doze, referentni_datum):
        preostalo = Decimal(str(preostale_doze or 0))
        redni_broj = self.broj_dosadasnjih_aplikacija() + 1
        trenutni_referentni_datum = referentni_datum
        zadnji_pokriveni_datum = None

        for _ in range(240):
            korak = self.terapijski_korak_za_redni_broj(redni_broj)
            if not korak:
                break

            potrebno = Decimal(str(korak.broj_jedinica or 0))
            if potrebno <= 0 or preostalo < potrebno:
                break

            datum_koraka = self._datum_sljedeceg_koraka_iz_referentnog(
                redni_broj,
                trenutni_referentni_datum,
            )
            if not datum_koraka:
                break

            preostalo -= potrebno
            zadnji_pokriveni_datum = datum_koraka
            trenutni_referentni_datum = datum_koraka
            redni_broj += 1

        return zadnji_pokriveni_datum

    def semafor_status(self):
        from .services import izracunaj_status_pacijenta

        status = izracunaj_status_pacijenta(self)["status"]
        if status in [
            "Nema odobrenih doza",
            "Nema fizičkih doza kod pacijenta",
            "Potrebna nova komisija",
            "Terapija kasni",
        ]:
            return "RED"
        if status in [
            "Komisija uskoro",
            "Potrebno zaprimanje pošiljke",
            "Spreman za kućnu terapiju",
        ]:
            return "YELLOW"
        return "GREEN"

    def semafor_text(self):
        from .services import izracunaj_status_pacijenta

        status = izracunaj_status_pacijenta(self)
        return f"{status['status']} - {status['status_razlog']}"

    def doze_za_3_mjeseca(self):
        return self.doze_za_period(13)

    def doze_za_period(self, broj_sedmica):
        return self.potrebe_za_period(broj_sedmica)["ukupno_potrebno"]

    def trenutno_dostupno_za_komisiju(self):
        if self.trenutni_korak_je_kucna_terapija():
            zaduzeno = self.zaduzeno_lijekova(self.lijek)
            return Decimal(str(zaduzeno or 0))

        from .commission_service import valid_commissions_for_patient

        return sum(
            (
                Decimal(str(komisija.preostale_doze or 0))
                for komisija in valid_commissions_for_patient(self)
            ),
            Decimal("0"),
        )

    def potrebe_za_period(self, broj_sedmica):
        from .individual_protocols import get_maintenance_interval_weeks

        broj_sedmica = int(broj_sedmica or 0)
        ukupno = Decimal("0")
        planirani_koraci = []
        planirane_terapije = []
        protokol = self.aktivni_protokol()

        if protokol:
            if protokol.ima_korake():
                odrzavanje = protokol.korak_odrzavanja()
                if self.pocetna_faza_terapije == self.FAZA_ODRZAVANJE:
                    if odrzavanje:
                        interval = get_maintenance_interval_weeks(self)
                        if interval:
                            broj_termina = ceil(broj_sedmica / interval)
                            ukupno = Decimal(str(broj_termina)) * Decimal(str(odrzavanje.broj_jedinica))
                            planirane_terapije.extend(
                                {
                                    "sedmica": index * interval,
                                    "relativna_sedmica": index * interval,
                                    "faza": "ODRZAVANJE",
                                    "broj_jedinica": Decimal(str(odrzavanje.broj_jedinica)),
                                }
                                for index in range(broj_termina)
                            )
                            planirani_koraci.append(
                                f"Održavanje: {broj_termina}x po {odrzavanje.broj_jedinica:g} jedinica"
                            )

                    dostupno = self.trenutno_dostupno_za_komisiju()
                    return {
                        "ukupno_potrebno": ukupno,
                        "trenutno_dostupno": dostupno,
                        "za_novu_komisiju": max(Decimal("0"), ukupno - dostupno),
                        "planirani_koraci": planirani_koraci,
                        "planirane_terapije": planirane_terapije,
                    }

                broj_aplikacija = self.broj_dosadasnjih_aplikacija()
                indukcijski = list(protokol.indukcijski_koraci())
                odrzavajuci = list(protokol.odrzavajuci_koraci())
                svi_koraci = indukcijski + odrzavajuci
                trenutna_sedmica = 0

                if broj_aplikacija > 0 and svi_koraci:
                    zadnji_index = min(broj_aplikacija, len(svi_koraci)) - 1
                    if zadnji_index >= 0:
                        trenutna_sedmica = svi_koraci[zadnji_index].sedmica_od_pocetka or 0

                ponavljajuci_korak = odrzavajuci[-1] if odrzavajuci else None
                ponavljajuci_index = (
                    svi_koraci.index(ponavljajuci_korak)
                    if ponavljajuci_korak in svi_koraci
                    else None
                )

                for index, korak in enumerate(svi_koraci):
                    if index < broj_aplikacija or korak == ponavljajuci_korak:
                        continue

                    sedmica_koraka = korak.sedmica_od_pocetka
                    relativna_sedmica = 0 if sedmica_koraka is None else max(sedmica_koraka - trenutna_sedmica, 0)
                    if relativna_sedmica <= broj_sedmica:
                        jedinica = Decimal(str(korak.broj_jedinica))
                        ukupno += jedinica
                        planirani_koraci.append(
                            f"{korak.get_faza_display()} sedmica {sedmica_koraka if sedmica_koraka is not None else '-'}: {jedinica:g} jedinica"
                        )
                        planirane_terapije.append({
                            "sedmica": sedmica_koraka,
                            "relativna_sedmica": relativna_sedmica,
                            "faza": korak.faza,
                            "broj_jedinica": jedinica,
                        })

                if ponavljajuci_korak:
                    # Interval trenutnog indukcijskog koraka može biti 2 ili
                    # 4 sedmice. Održavanje se mora ponavljati isključivo po
                    # vlastitom intervalu protokola (npr. svakih 8 sedmica).
                    interval = get_maintenance_interval_weeks(self)
                    pocetak_odrzavanja = ponavljajuci_korak.sedmica_od_pocetka
                    if pocetak_odrzavanja is None:
                        prethodni_koraci = [korak for korak in svi_koraci if korak != ponavljajuci_korak]
                        prethodna_sedmica = prethodni_koraci[-1].sedmica_od_pocetka if prethodni_koraci else 0
                        pocetak_odrzavanja = (prethodna_sedmica or 0) + (interval or 0)

                    if ponavljajuci_index is not None and broj_aplikacija > ponavljajuci_index:
                        relativni_pocetak = interval or 0
                    else:
                        relativni_pocetak = max((pocetak_odrzavanja or 0) - trenutna_sedmica, 0)

                    if interval and relativni_pocetak <= broj_sedmica:
                        broj_odrzavanja = int((broj_sedmica - relativni_pocetak) // interval) + 1
                        jedinica = Decimal(str(ponavljajuci_korak.broj_jedinica))
                        ukupno += Decimal(str(broj_odrzavanja)) * jedinica
                        planirani_koraci.append(
                            f"Održavanje od sedmice {pocetak_odrzavanja}: {broj_odrzavanja}x po {jedinica:g} jedinica"
                        )
                        for offset in range(broj_odrzavanja):
                            relativna_sedmica = relativni_pocetak + offset * interval
                            planirane_terapije.append({
                                "sedmica": trenutna_sedmica + relativna_sedmica,
                                "relativna_sedmica": relativna_sedmica,
                                "faza": "ODRZAVANJE",
                                "broj_jedinica": jedinica,
                            })

                dostupno = self.trenutno_dostupno_za_komisiju()
                return {
                    "ukupno_potrebno": ukupno,
                    "trenutno_dostupno": dostupno,
                    "za_novu_komisiju": max(Decimal("0"), ukupno - dostupno),
                    "planirani_koraci": planirani_koraci,
                    "planirane_terapije": planirane_terapije,
                }

            ukupno = Decimal(str(protokol.doze_za_period(broj_sedmica)))
            dostupno = self.trenutno_dostupno_za_komisiju()
            return {
                "ukupno_potrebno": ukupno,
                "trenutno_dostupno": dostupno,
                "za_novu_komisiju": max(Decimal("0"), ukupno - dostupno),
                "planirani_koraci": ["Plan po terapijskom protokolu bez detaljnih koraka."],
                "planirane_terapije": planirane_terapije,
            }

        efektivni_interval = self.efektivni_interval_sedmica()
        if efektivni_interval:
            ukupno = Decimal(str(ceil(broj_sedmica / efektivni_interval)))
            planirani_koraci.append(f"Fallback interval: svake {efektivni_interval} sedmica")

        dostupno = self.trenutno_dostupno_za_komisiju()
        return {
            "ukupno_potrebno": ukupno,
            "trenutno_dostupno": dostupno,
            "za_novu_komisiju": max(Decimal("0"), ukupno - dostupno),
            "planirani_koraci": planirani_koraci,
            "planirane_terapije": planirane_terapije,
        }

    def treba_traziti(self):
        from .services import izracunaj_status_pacijenta

        return izracunaj_status_pacijenta(self)["za_novu_komisiju"]

    def aktivna_pauza_terapije(self):
        if not self.pk:
            return None
        for attribute in ("_workflow_pauses", "_planning_pauses"):
            prefetched = getattr(self, attribute, None)
            if prefetched is not None:
                return prefetched[0] if prefetched else None
        from .request_cache import get_or_set

        return get_or_set(
            "active_therapy_pause",
            self.pk,
            lambda: self.pauze_terapije.filter(aktivna=True).order_by(
                "-datum_pocetka", "-id"
            ).first(),
        )

    def na_aktivnoj_pauzi(self):
        return self.aktivna_pauza_terapije() is not None

class Komisija(models.Model):
    STATUS = [
        ("AKTIVNA", "Aktivna"),
        ("BUDUCA", "Buduća / odobrena"),
        ("ODOBRENA", "Odobrena"),
        ("NOVA", "Potrebna nova komisija"),
        ("POTROSENA", "Potrošena"),
        ("PONISTENA", "Poništena"),
        ("ZAMIJENJENA", "Zamijenjena"),
    ]
    VAZECI_STATUSI = ["AKTIVNA", "BUDUCA", "ODOBRENA"]

    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE)
    lijek = models.ForeignKey(Lijek, on_delete=models.CASCADE)
    datum_odobrenja = models.DateField()
    # Zadržano samo kao historijski datum procijenjene pokrivenosti. Komisija
    # poslovno ne ističe; važenje određuju status i preostale doze.
    datum_isteka = models.DateField(null=True, blank=True)
    broj_odobrenih_doza = models.DecimalField(max_digits=8, decimal_places=2)
    preostale_doze = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS, default="AKTIVNA")
    broj_saglasnosti = models.CharField(max_length=100, blank=True, null=True)
    napomena = models.TextField(blank=True, null=True)

    class Meta:
        indexes = [
            models.Index(
                fields=["pacijent", "status", "datum_isteka"],
                name="comm_patient_status_exp_idx",
            ),
            models.Index(fields=["lijek", "status"], name="comm_drug_status_idx"),
        ]

    def save(self, *args, **kwargs):
        nova = self.pk is None

        if nova and self.preostale_doze == 0:
            self.preostale_doze = self.broj_odobrenih_doza

        update_fields = kwargs.get("update_fields")
        if nova or update_fields is None or "broj_odobrenih_doza" in update_fields:
            from .package_sizes import validate_package_multiple
            validate_package_multiple(
                self.broj_odobrenih_doza,
                self.lijek,
                label="Broj odobrenih doza",
            )

        super().save(*args, **kwargs)

    def clean(self):
        super().clean()
        from .package_sizes import validate_package_multiple

        if self.lijek_id:
            try:
                validate_package_multiple(
                    self.broj_odobrenih_doza,
                    self.lijek,
                    label="Broj odobrenih doza",
                )
            except ValueError as exc:
                from django.core.exceptions import ValidationError
                raise ValidationError({"broj_odobrenih_doza": str(exc)}) from exc

    def je_vazeca(self):
        return (
            self.status in self.VAZECI_STATUSI
            and self.preostale_doze > 0
        )

    def sedmica_pokrivenosti(self):
        pokriven_do = self.terapija_pokrivena_do()
        if not pokriven_do:
            return 0

        return max((pokriven_do - self.datum_odobrenja).days // 7, 0)

    def terapija_pokrivena_do(self):
        pokriven_do, _ = self.pacijent.izracunaj_pokriven_do(
            self.preostale_doze,
            fallback_date=self.datum_odobrenja,
        )
        return pokriven_do

    def __str__(self):
        return f"{self.pacijent} - {self.lijek}"


class PacijentZaduzenje(models.Model):
    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE)
    lijek = models.ForeignKey(Lijek, on_delete=models.CASCADE)
    komisija = models.ForeignKey(Komisija, on_delete=models.CASCADE, null=True, blank=True)
    ukupno_zaduzeno = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    preostalo = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    aktivno = models.BooleanField(default=True)
    datum_zaduzenja = models.DateField(
        null=True,
        blank=True,
        default=timezone.localdate,
    )
    migracijski_snapshot = models.OneToOneField(
        "MigracijskiSnapshotPacijenta",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="pocetno_kucno_zaduzenje",
    )

    class Meta:
        indexes = [
            models.Index(fields=["pacijent", "aktivno"], name="assign_patient_active_idx"),
            models.Index(fields=["lijek", "aktivno"], name="assign_drug_active_idx"),
        ]

    def __str__(self):
        return f"{self.pacijent} - {self.lijek} - {self.preostalo}"


class KucnoIzdavanje(models.Model):
    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE, related_name="kucna_izdavanja")
    lijek = models.ForeignKey(Lijek, on_delete=models.PROTECT, related_name="kucna_izdavanja")
    komisija = models.ForeignKey(Komisija, on_delete=models.SET_NULL, null=True, blank=True, related_name="kucna_izdavanja")
    pacijent_zaduzenje = models.ForeignKey(
        PacijentZaduzenje,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="kucna_izdavanja",
    )
    terapija = models.OneToOneField(
        "Terapija",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="kucno_izdavanje",
    )
    datum = models.DateField()
    kolicina = models.DecimalField(max_digits=8, decimal_places=2)
    serija = models.CharField(max_length=100, blank=True)
    rok_trajanja = models.DateField(null=True, blank=True)
    napomena = models.TextField(blank=True)
    korisnik_koji_je_izdao = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    idempotency_key = models.UUIDField(default=uuid.uuid4, unique=True)
    razduzenje_snapshot = models.JSONField(default=dict, blank=True)
    razduzenje_prvi_put_generisano = models.DateTimeField(null=True, blank=True)
    razduzenje_zadnji_put_generisano = models.DateTimeField(null=True, blank=True)
    razduzenje_broj_generisanja = models.PositiveIntegerField(default=0)
    kreirano = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Kućno izdavanje"
        verbose_name_plural = "Kućna izdavanja"
        ordering = ["-datum", "-id"]

    def __str__(self):
        return (
            f"{self.pacijent} - {self.lijek} - {self.kolicina} "
            f"({self.datum:%d/%m/%Y})"
        )


class PromjenaTerapije(models.Model):
    RAZLOG_NEDOVOLJAN_ODGOVOR = "NEDOVOLJAN_ODGOVOR"
    RAZLOG_GUBITAK_ODGOVORA = "GUBITAK_ODGOVORA"
    RAZLOG_NUSPOJAVE = "NUSPOJAVE"
    RAZLOG_ZAVRSENA_TERAPIJA = "ZAVRSENA_TERAPIJA"
    RAZLOG_OSTALO = "OSTALO"
    RAZLOZI = [
        (RAZLOG_NEDOVOLJAN_ODGOVOR, "Nedovoljan odgovor"),
        (RAZLOG_GUBITAK_ODGOVORA, "Gubitak odgovora"),
        (RAZLOG_NUSPOJAVE, "Nuspojave"),
        (RAZLOG_ZAVRSENA_TERAPIJA, "Završena terapija"),
        (RAZLOG_OSTALO, "Ostalo"),
    ]

    POSTUPANJE_VRATI_U_ZALIHU = "VRATI_U_ZALIHU"
    POSTUPANJE_OSTAVI_U_FRIZIDERU = "OSTAVI_U_FRIZIDERU"
    POSTUPANJE_NEISKORISTENE = "NEISKORISTENE"
    POSTUPANJE_RUCNO_KASNIJE = "RUCNO_KASNIJE"
    POSTUPANJA = [
        (POSTUPANJE_VRATI_U_ZALIHU, "Vraćene u zalihu"),
        (POSTUPANJE_OSTAVI_U_FRIZIDERU, "Ostavljeno u frižideru za drugog pacijenta"),
        (POSTUPANJE_NEISKORISTENE, "Označene kao neiskorištene"),
        (POSTUPANJE_RUCNO_KASNIJE, "Ručno odlučiti kasnije"),
    ]

    NOVA_FAZA_INDUKCIJA = "INDUKCIJA"
    NOVA_FAZA_ODRZAVANJE = "ODRZAVANJE"
    NOVE_FAZE = [
        (NOVA_FAZA_INDUKCIJA, "Indukcijom"),
        (NOVA_FAZA_ODRZAVANJE, "Održavanjem"),
    ]

    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE, related_name="promjene_terapije")
    stari_lijek = models.ForeignKey(Lijek, on_delete=models.PROTECT, related_name="promjene_sa_lijeka")
    novi_lijek = models.ForeignKey(Lijek, on_delete=models.PROTECT, related_name="promjene_na_lijek")
    stari_protokol = models.ForeignKey(
        TerapijskiProtokol,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="zatvorene_promjene_terapije",
    )
    novi_protokol = models.ForeignKey(
        TerapijskiProtokol,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="nove_promjene_terapije",
    )
    datum_promjene = models.DateField(auto_now_add=True)
    datum_odluke = models.DateField(default=timezone.localdate)
    ljekar_koji_je_donio_odluku = models.CharField(max_length=150, blank=True)
    povezani_dokument = models.ForeignKey(
        "DokumentPacijenta",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="klinicke_promjene_terapije",
    )
    datum_zavrsetka_stare_terapije = models.DateField()
    datum_pocetka_nove_terapije = models.DateField()
    razlog = models.CharField(max_length=30, choices=RAZLOZI)
    napomena = models.TextField(blank=True)
    preostale_doze = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    postupanje_sa_preostalim_dozama = models.CharField(max_length=30, choices=POSTUPANJA, blank=True)
    nova_terapija_pocinje = models.CharField(max_length=20, choices=NOVE_FAZE, default=NOVA_FAZA_INDUKCIJA)
    izvrsio = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        ordering = ["-datum_pocetka_nove_terapije", "-id"]

    def __str__(self):
        return f"{self.pacijent}: {self.stari_lijek} → {self.novi_lijek}"


class Termin(models.Model):
    STATUS_PLANIRANA = "ZAKAZAN"
    STATUS_POTVRDJENA = "OBAVLJEN"
    STATUS_ODGODJENA = "ODGODJENA"
    STATUS_NIJE_DOSAO = "NIJE_DOSAO"
    STATUS_PAUSIRANA = "PAUZIRANA"
    STATUS_OTKAZANA = "OTKAZAN"
    STATUS_PONISTENA = "PONISTENA"
    STATUS = [
        (STATUS_PLANIRANA, "Planirana"),
        (STATUS_POTVRDJENA, "Potvrđena"),
        (STATUS_ODGODJENA, "Odgođena"),
        (STATUS_NIJE_DOSAO, "Nije došao"),
        (STATUS_PAUSIRANA, "Privremeno pauzirana"),
        (STATUS_OTKAZANA, "Otkazana"),
        (STATUS_PONISTENA, "Poništena"),
    ]

    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE)
    lijek = models.ForeignKey(Lijek, on_delete=models.CASCADE)
    datum = models.DateField()
    vrijeme = models.TimeField()
    kolicina_po_terapiji = models.DecimalField(
        "Količina po jednoj terapiji",
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
    )
    status = models.CharField(max_length=20, choices=STATUS, default="ZAKAZAN")

    class Meta:
        indexes = [
            models.Index(fields=["datum", "status"], name="term_date_status_idx"),
            models.Index(
                fields=["pacijent", "status", "datum"],
                name="term_patient_status_date_idx",
            ),
            models.Index(
                fields=["lijek", "status", "datum"],
                name="term_drug_status_date_idx",
            ),
        ]
        constraints = [
            models.CheckConstraint(
                condition=(
                    models.Q(kolicina_po_terapiji__isnull=True)
                    | models.Q(kolicina_po_terapiji__gt=0)
                ),
                name="termin_kolicina_po_terapiji_pozitivna",
            ),
        ]

    def __str__(self):
        return f"{self.pacijent} - {self.datum:%d/%m/%Y}"

    def clean(self):
        super().clean()
        from .scheduling import validate_therapy_date

        if self.lijek_id and self.lijek.oralna_terapija:
            raise ValidationError(
                {
                    "lijek": (
                        "Oralna terapija koristi evidenciju izdavanja tableta, "
                        "ne terapijski Termin."
                    )
                }
            )
        validate_therapy_date(
            self.datum,
            lijek=self.lijek if self.lijek_id else None,
            protokol=(
                self.pacijent.aktivni_protokol()
                if self.pacijent_id
                else None
            ),
            allow_demo_weekend=bool(
                getattr(self, "_allow_demo_weekend_validation", False)
            ),
        )


class Terapija(models.Model):
    class UstekinumabFaza(models.TextChoices):
        IV_INDUKCIJA = "CEKA_IV_INDUKCIJU", "IV indukcija"
        IV_U_SC_PRIJELAZ = (
            "CEKA_PRVU_SC",
            "Prva SC doza nakon IV indukcije",
        )
        SC_ODRZAVANJE = "ODRZAVANJE", "SC terapija održavanja"

    STATUS_POTVRDJENA = "POTVRDJENA"
    STATUS_PONISTENA = "PONISTENA"
    STATUSI = [
        (STATUS_POTVRDJENA, "Potvrđena"),
        (STATUS_PONISTENA, "Poništena"),
    ]
    FINANSIJSKI_NIJE_KREIRAN = "NIJE_KREIRAN"
    FINANSIJSKI_CEKA = "CEKA_FINANSIJE"
    FINANSIJSKI_PREDATO = "PREDATO_FINANSIJAMA"
    FINANSIJSKI_PONISTEN = "PONISTEN"
    FINANSIJSKI_STATUSI = [
        (FINANSIJSKI_NIJE_KREIRAN, "Nije kreiran"),
        (FINANSIJSKI_CEKA, "Čeka finansije"),
        (FINANSIJSKI_PREDATO, "Predato finansijama"),
        (FINANSIJSKI_PONISTEN, "Poništeno"),
    ]
    TIP_AMBULANTA = "PRIMJENA_U_AMBULANTI"
    TIP_KUCNA_TERAPIJA = "IZDAVANJE_KUCNE_TERAPIJE"
    TIPOVI_EVIDENCIJE = [
        (TIP_AMBULANTA, "Primljeno u ambulanti"),
        (TIP_KUCNA_TERAPIJA, "Izdato za kućnu terapiju"),
    ]

    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE)
    lijek = models.ForeignKey(Lijek, on_delete=models.CASCADE)
    terapijski_korak = models.ForeignKey(
        TerapijskiKorakProtokola,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    datum = models.DateField()
    serija = models.CharField(max_length=100, blank=True)
    kolicina = models.DecimalField(max_digits=8, decimal_places=2, default=1)
    doza_mg = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    tezina_kg_snapshot = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        null=True,
        blank=True,
    )
    tezina_izmjerena_at_snapshot = models.DateTimeField(null=True, blank=True)
    faza_terapije = models.CharField(max_length=20, blank=True)
    interval_sedmica = models.PositiveIntegerField(null=True, blank=True)
    nuspojave = models.TextField(blank=True)
    laboratorija = models.TextField(blank=True)
    tip_evidencije = models.CharField(
        max_length=30,
        choices=TIPOVI_EVIDENCIJE,
        default=TIP_AMBULANTA,
    )
    is_migration = models.BooleanField(default=False)
    zakljucana = models.BooleanField(default=True)
    workflow_status = models.CharField(max_length=20, choices=STATUSI, default=STATUS_POTVRDJENA)
    workflow_snapshot = models.JSONField(default=dict, blank=True)
    razlog_ponistavanja = models.TextField(blank=True)
    ponistena_at = models.DateTimeField(null=True, blank=True)
    ponistio = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="ponistene_terapije",
    )
    finansijski_status = models.CharField(
        max_length=24,
        choices=FINANSIJSKI_STATUSI,
        default=FINANSIJSKI_NIJE_KREIRAN,
    )
    evidentirao = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="evidentirane_terapije",
    )
    finansijama_predao = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="finansijama_predate_terapije",
    )
    finansijama_predato_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["pacijent", "datum"], name="therapy_patient_date_idx"),
            models.Index(fields=["lijek", "datum"], name="therapy_drug_date_idx"),
        ]

    def save(self, *args, **kwargs):
        nova = self.pk is None
        self.kolicina = Decimal(str(self.kolicina or 0))
        if self.doza_mg is not None:
            self.doza_mg = Decimal(str(self.doza_mg))

        if nova and self.pacijent_id and self.lijek_id:
            from .therapy_history import actually_administered_therapy_query

            redni_broj = actually_administered_therapy_query(
                self.pacijent.terapija_set.filter(
                    lijek_id__in=self.lijek.equivalent_ids()
                )
            ).count() + 1
            if not self.terapijski_korak_id:
                from .individual_protocols import persistable_standard_step

                efektivni_korak = self.pacijent.terapijski_korak_za_redni_broj(redni_broj)
                self.terapijski_korak = persistable_standard_step(efektivni_korak)
            else:
                efektivni_korak = self.pacijent.terapijski_korak_za_redni_broj(redni_broj)
            if not self.faza_terapije:
                self.faza_terapije = self.pacijent.terapijska_faza_za_redni_broj(redni_broj)
            if self.doza_mg is None and efektivni_korak:
                self.doza_mg = efektivni_korak.doza_mg

        if self.pacijent_id and not self.interval_sedmica:
            self.interval_sedmica = self.pacijent.sedmica_do_sljedece_aplikacije()
            update_fields = kwargs.get("update_fields")
            if update_fields is not None:
                kwargs["update_fields"] = set(update_fields) | {"interval_sedmica"}

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.pacijent} - {self.lijek} - {self.datum:%d/%m/%Y}"

    @property
    def faza_terapije_prikaz(self):
        """Prikaži label faze, dok ``faza_terapije`` ostaje kratki DB kod.

        Snapshot čuva label koji je važio u trenutku primjene. Fallback na
        stabilne ustekinumab izbore služi starijim faznim zapisima koji su
        nastali prije uvođenja snapshot labela; ostale legacy vrijednosti se
        prikazuju neizmijenjene.
        """

        snapshot = self.workflow_snapshot or {}
        snapshot_label = snapshot.get("faza_terapije_label")
        if snapshot_label:
            if (
                self.faza_terapije
                == self.UstekinumabFaza.IV_U_SC_PRIJELAZ
                and "čeka prvu SC" in snapshot_label
            ):
                return self.UstekinumabFaza.IV_U_SC_PRIJELAZ.label
            return snapshot_label
        if snapshot.get("fazni_protokol_id"):
            return dict(self.UstekinumabFaza.choices).get(
                self.faza_terapije,
                self.faza_terapije,
            )
        return self.faza_terapije


class PauzaTerapije(models.Model):
    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE, related_name="pauze_terapije")
    datum_pocetka = models.DateField()
    planirani_datum_zavrsetka = models.DateField(null=True, blank=True)
    datum_nastavka = models.DateField(null=True, blank=True)
    razlog = models.TextField()
    aktivna = models.BooleanField(default=True)
    kreirao = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="kreirane_pauze_terapije")
    zavrsio = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="zavrsene_pauze_terapije")
    kreirano = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-datum_pocetka", "-id"]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(planirani_datum_zavrsetka__isnull=True) | models.Q(planirani_datum_zavrsetka__gte=models.F("datum_pocetka")),
                name="pauza_planirani_kraj_nakon_pocetka",
            ),
        ]

    def __str__(self):
        return f"{self.pacijent} - pauza od {self.datum_pocetka:%d/%m/%Y}"


class TerapijaStatusHistorija(models.Model):
    DOGADJAJ_TERAPIJA_EVIDENTIRANA = "TERAPIJA_EVIDENTIRANA"
    DOGADJAJ_TERMIN_ODGODJEN = "TERMIN_ODGODJEN"
    DOGADJAJ_TERMIN_PROMIJENJEN = "TERMIN_PROMIJENJEN"
    DOGADJAJ_NIJE_DOSAO = "NIJE_DOSAO"
    DOGADJAJ_TERAPIJA_PAUSIRANA = "TERAPIJA_PAUSIRANA"
    DOGADJAJ_TERAPIJA_NASTAVLJENA = "TERAPIJA_NASTAVLJENA"
    DOGADJAJ_TERMIN_OTKAZAN = "TERMIN_OTKAZAN"
    DOGADJAJ_NOVI_TERMIN = "NOVI_TERMIN"
    DOGADJAJ_TERAPIJA_PONISTENA = "TERAPIJA_PONISTENA"
    DOGADJAJ_SC_KUCNA_TERAPIJA = "SC_KUCNA_TERAPIJA"
    DOGADJAJ_SC_AMBULANTNA_TERAPIJA = "SC_AMBULANTNA_TERAPIJA"
    DOGADJAJ_KUCNO_IZDAVANJE = "KUCNO_IZDAVANJE"

    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE, related_name="historija_statusa_terapije")
    termin = models.ForeignKey(Termin, on_delete=models.SET_NULL, null=True, blank=True, related_name="historija_statusa")
    terapija = models.ForeignKey(Terapija, on_delete=models.SET_NULL, null=True, blank=True, related_name="historija_statusa")
    prethodni_status = models.CharField(max_length=30, blank=True)
    novi_status = models.CharField(max_length=30)
    razlog = models.TextField(blank=True)
    prethodno_stanje = models.JSONField(default=dict, blank=True)
    novo_stanje = models.JSONField(default=dict, blank=True)
    korisnik = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    datum_vrijeme = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-datum_vrijeme", "-id"]

    def __str__(self):
        return f"{self.pacijent} - {self.novi_status}"

    @property
    def tip_dogadjaja(self):
        return (self.novo_stanje or {}).get("tip_dogadjaja") or self.novi_status


class Zaliha(models.Model):
    lijek = models.OneToOneField(Lijek, on_delete=models.CASCADE)
    ukupno = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    u_frizideru = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    kod_pacijenata = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    minimum = models.DecimalField(max_digits=8, decimal_places=2, default=5)

    @property
    def ukupno_zaduzeno(self):
        return Decimal(str(self.u_frizideru or 0)) + Decimal(str(self.kod_pacijenata or 0))

    def niska_zaliha(self):
        return self.u_frizideru <= self.minimum

    def save(self, *args, **kwargs):
        if not self.pk and Decimal(str(self.u_frizideru or 0)) == 0 and Decimal(str(self.ukupno or 0)) != 0:
            self.u_frizideru = Decimal(str(self.ukupno or 0))
        self.u_frizideru = Decimal(str(self.u_frizideru or 0))
        self.kod_pacijenata = Decimal(str(self.kod_pacijenata or 0))
        if self.u_frizideru < 0:
            raise ValueError("Zaliha u frižideru ne može biti negativna.")
        if self.kod_pacijenata < 0:
            raise ValueError("Zaliha kod pacijenata ne može biti negativna.")
        if self.lijek_id:
            from django.db.models import Sum

            from .medication_groups import strict_equivalent_medicine_ids

            medicine_ids = strict_equivalent_medicine_ids(self.lijek)
            other_stock = Zaliha.objects.filter(lijek_id__in=medicine_ids)
            if self.pk:
                other_stock = other_stock.exclude(pk=self.pk)
            physical_other_rows = Decimal(str(
                other_stock.aggregate(total=Sum("u_frizideru"))["total"] or 0
            ))
            active_reserved = Decimal(str(
                PacijentRezervacija.objects.filter(
                    lijek_id__in=medicine_ids,
                    aktivno=True,
                    kolicina__gt=0,
                ).aggregate(total=Sum("kolicina"))["total"] or 0
            ))
            resulting_physical = physical_other_rows + self.u_frizideru
            if resulting_physical < active_reserved:
                raise ValueError(
                    "Fizičko stanje ne može biti manje od aktivnih fizičkih "
                    f"rezervacija. Stanje {resulting_physical:g}, rezervisano "
                    f"{active_reserved:g}."
                )
        self.ukupno = self.u_frizideru
        update_fields = kwargs.get("update_fields")
        if update_fields is not None:
            kwargs["update_fields"] = set(update_fields) | {"ukupno"}
        super().save(*args, **kwargs)

    def __str__(self):
        return self.lijek.naziv


class MigracijskiSnapshotPacijenta(models.Model):
    """Početno kliničko i operativno stanje uneseno pri migraciji.

    Snapshot nije transakcija zalihe i ne kreira historijsku ``Terapija`` niti
    opcioni ``Termin``. Datumi i prijedlog narednog termina ostaju isključivo
    historijski podaci snapshot-a, bez operativnih side-effecta.
    """

    STATUS_PREOSTALIH_CEKA_ISPORUKU = "CEKA_ISPORUKU"
    STATUS_PREOSTALIH_ZAPRIMLJENE = "ZAPRIMLJENE"
    STATUS_PREOSTALIH_KOD_PACIJENTA = "KOD_PACIJENTA"
    STATUSI_PREOSTALIH_DOZA = [
        (
            STATUS_PREOSTALIH_CEKA_ISPORUKU,
            "Odobrene, čekaju isporuku",
        ),
        (
            STATUS_PREOSTALIH_ZAPRIMLJENE,
            "Zaprimljene i dostupne",
        ),
        (
            STATUS_PREOSTALIH_KOD_PACIJENTA,
            "Već dodijeljene pacijentu",
        ),
    ]

    pacijent = models.OneToOneField(
        Pacijent,
        on_delete=models.CASCADE,
        related_name="migracijski_snapshot",
    )
    lijek = models.ForeignKey(Lijek, on_delete=models.PROTECT)
    datum_posljednje_terapije = models.DateField(null=True, blank=True)
    interval_sedmica = models.PositiveSmallIntegerField()
    broj_odobrenih_doza = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    broj_iskoristenih_doza = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    status_preostalih_odobrenih_doza = models.CharField(
        max_length=24,
        choices=STATUSI_PREOSTALIH_DOZA,
        default=STATUS_PREOSTALIH_CEKA_ISPORUKU,
    )
    fizicki_u_frizideru = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    kod_pacijenta = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    sljedeca_terapija = models.DateField(null=True, blank=True)
    napomena = models.TextField(blank=True)
    kreirao = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    kreirano = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Migracijski snapshot pacijenta"
        verbose_name_plural = "Migracijski snapshoti pacijenata"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(interval_sedmica__gte=1) & models.Q(interval_sedmica__lte=52),
                name="migracijski_snapshot_interval_1_52",
            ),
            models.CheckConstraint(
                condition=models.Q(broj_odobrenih_doza__gte=0),
                name="migracijski_snapshot_odobreno_gte_0",
            ),
            models.CheckConstraint(
                condition=models.Q(broj_iskoristenih_doza__gte=0),
                name="migracijski_snapshot_iskoristeno_gte_0",
            ),
            models.CheckConstraint(
                condition=models.Q(fizicki_u_frizideru__gte=0),
                name="migracijski_snapshot_frizider_gte_0",
            ),
            models.CheckConstraint(
                condition=models.Q(kod_pacijenta__gte=0),
                name="migracijski_snapshot_kod_pacijenta_gte_0",
            ),
            models.CheckConstraint(
                condition=models.Q(broj_iskoristenih_doza__lte=models.F("broj_odobrenih_doza")),
                name="migracijski_snapshot_iskoristeno_lte_odobreno",
            ),
            models.CheckConstraint(
                condition=models.Q(kod_pacijenta__lte=models.F("broj_odobrenih_doza")),
                name="migracijski_snapshot_kod_pacijenta_lte_odobreno",
            ),
            models.CheckConstraint(
                condition=models.Q(
                    broj_odobrenih_doza__gte=(
                        models.F("broj_iskoristenih_doza")
                        + models.F("fizicki_u_frizideru")
                        + models.F("kod_pacijenta")
                    )
                ),
                name="migracijski_snapshot_fizicko_lte_preostalo",
            ),
        ]

    @property
    def preostalo_po_komisiji(self):
        return self.broj_odobrenih_doza - self.broj_iskoristenih_doza

    def __str__(self):
        return f"{self.pacijent} - {self.lijek}"


class MigracijskoPocetnoStanjeZalihe(models.Model):
    """Administratorski potvrđeno globalno fizičko stanje pri migraciji.

    Zapis je namjerno odvojen od komisijskih odobrenja i operativnih
    ``ZalihaTransakcija``. Vrijednost predstavlja inventurni saldo koji je
    administrator jednom potvrdio (i kasnije, uz audit, može korigovati).
    """

    lijek = models.OneToOneField(
        Lijek,
        on_delete=models.PROTECT,
        related_name="migracijsko_pocetno_stanje",
    )
    kolicina = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    ledger_checkpoint_id = models.PositiveIntegerField(
        null=True,
        blank=True,
        help_text=(
            "Posljednja transakcija obuhvaćena potvrđenim početnim stanjem."
        ),
    )
    kreirao = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="kreirana_migracijska_stanja_zalihe",
    )
    izmijenio = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="izmijenjena_migracijska_stanja_zalihe",
    )
    kreirano = models.DateTimeField(auto_now_add=True)
    izmijenjeno = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Migracijsko početno stanje zalihe"
        verbose_name_plural = "Migracijska početna stanja zaliha"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(kolicina__gte=0),
                name="migracijsko_stanje_zalihe_gte_0",
            ),
        ]

    def __str__(self):
        return f"{self.lijek} - {self.kolicina}"


class ZalihaTransakcija(models.Model):
    TIP_ZAPRIMANJE = "ZAPRIMANJE"
    TIP_AMBULANTNA_POTROSNJA = "AMBULANTNA_POTROSNJA"
    TIP_KUCNO_IZDAVANJE = "KUCNO_IZDAVANJE"
    TIP_ORALNO_IZDAVANJE = "ORALNO_IZDAVANJE"
    TIP_POVRAT = "POVRAT"
    TIP_OTPIS = "OTPIS"
    TIP_KOREKCIJA = "KOREKCIJA"
    TIP_POCETNO_STANJE_MIGRACIJE = "POCETNO_STANJE_MIGRACIJE"
    TIP_OSLOBADJANJE_U_SLOBODNU_ZALIHU = "RELEASE_TO_FREE_STOCK"
    TIP_DODJELA_SLOBODNE_ZALIHE = "ASSIGN_FREE_STOCK_TO_PATIENT"
    LOKACIJA_FRIZIDER = "FRIZIDER"
    RAZLOG_PREKID_TERAPIJE = "PREKID_TERAPIJE"
    RAZLOG_PROMJENA_LIJEKA = "PROMJENA_LIJEKA"
    RAZLOG_SMRTNI_SLUCAJ = "SMRTNI_SLUCAJ"
    RAZLOG_DRUGO = "DRUGO"
    RAZLOG_DODJELA = "DODJELA"
    RAZLOZI_SLOBODNE_ZALIHE = [
        (RAZLOG_PREKID_TERAPIJE, "Prekid terapije"),
        (RAZLOG_PROMJENA_LIJEKA, "Promjena lijeka"),
        (RAZLOG_SMRTNI_SLUCAJ, "Smrtni slučaj"),
        (RAZLOG_DRUGO, "Drugo"),
        (RAZLOG_DODJELA, "Dodjela slobodne zalihe"),
    ]
    LOKACIJE = [
        (LOKACIJA_FRIZIDER, "Frižider"),
    ]
    TIPOVI = [
        (TIP_ZAPRIMANJE, "Zaprimanje"),
        (TIP_AMBULANTNA_POTROSNJA, "Ambulantna potrosnja"),
        (TIP_KUCNO_IZDAVANJE, "Kucno izdavanje"),
        (TIP_ORALNO_IZDAVANJE, "Oralno izdavanje"),
        (TIP_POVRAT, "Povrat"),
        (TIP_OTPIS, "Otpis"),
        (TIP_KOREKCIJA, "Korekcija"),
        (
            TIP_POCETNO_STANJE_MIGRACIJE,
            "Početno stanje migracije",
        ),
        (
            TIP_OSLOBADJANJE_U_SLOBODNU_ZALIHU,
            "Oslobađanje u slobodnu zalihu",
        ),
        (
            TIP_DODJELA_SLOBODNE_ZALIHE,
            "Dodjela slobodne zalihe pacijentu",
        ),
    ]

    lijek = models.ForeignKey(Lijek, on_delete=models.PROTECT, related_name="zaliha_transakcije")
    tip = models.CharField(max_length=30, choices=TIPOVI)
    kolicina = models.DecimalField(max_digits=8, decimal_places=2)
    datum = models.DateField(default=timezone.localdate)
    pacijent = models.ForeignKey(Pacijent, on_delete=models.SET_NULL, null=True, blank=True, related_name="zaliha_transakcije")
    komisija = models.ForeignKey(Komisija, on_delete=models.SET_NULL, null=True, blank=True, related_name="zaliha_transakcije")
    referenca_tip = models.CharField(max_length=100, blank=True)
    referenca_id = models.PositiveIntegerField(null=True, blank=True)
    korisnik = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    napomena = models.TextField(blank=True)
    razlog_kod = models.CharField(
        max_length=30,
        choices=RAZLOZI_SLOBODNE_ZALIHE,
        blank=True,
        db_index=True,
        help_text="Strukturirani razlog oslobađanja ili dodjele slobodne zalihe.",
    )
    lokacija = models.CharField(
        max_length=30,
        choices=LOKACIJE,
        blank=True,
    )
    rezervisana_pacijentu = models.BooleanField(
        default=False,
        help_text="Fizička količina u frižideru dodijeljena konkretnom pacijentu.",
    )
    promjena_salda = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Stvarna promjena centralnog salda; prazno koristi količinu transakcije.",
    )
    kreirano = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Transakcija zalihe"
        verbose_name_plural = "Transakcije zaliha"
        ordering = ["datum", "id"]

    def frizider_delta(self):
        kolicina = Decimal(str(
            self.promjena_salda
            if self.promjena_salda is not None
            else self.kolicina or 0
        ))
        if self.tip in [
            self.TIP_ZAPRIMANJE,
            self.TIP_POVRAT,
            self.TIP_KOREKCIJA,
            self.TIP_POCETNO_STANJE_MIGRACIJE,
        ]:
            return kolicina
        if self.tip in [
            self.TIP_AMBULANTNA_POTROSNJA,
            self.TIP_KUCNO_IZDAVANJE,
            self.TIP_ORALNO_IZDAVANJE,
            self.TIP_OTPIS,
        ]:
            return -kolicina
        return Decimal("0")

    def __str__(self):
        return f"{self.lijek} - {self.tip} - {self.kolicina}"


class PotrebaFizickogPokrica(models.Model):
    """Potreba pacijenta koja još nije fizički alocirana.

    Komisijsko pravo i najavljena isporuka ostaju u svojim postojećim
    modelima. Ovaj zapis predstavlja samo razliku između količine koju je
    operativni workflow pokušao alocirati i stvarno raspoložive fizičke
    zalihe.
    """

    STATUS_CEKA = "CEKA_FIZICKO_POKRICE"
    STATUS_POKRIVENA = "POKRIVENA"
    STATUS_OTKAZANA = "OTKAZANA"
    STATUSI = [
        (STATUS_CEKA, "Čeka fizičko pokriće"),
        (STATUS_POKRIVENA, "Fizički pokrivena"),
        (STATUS_OTKAZANA, "Otkazana"),
    ]

    pacijent = models.ForeignKey(
        Pacijent,
        on_delete=models.CASCADE,
        related_name="potrebe_fizickog_pokrica",
    )
    lijek = models.ForeignKey(
        Lijek,
        on_delete=models.PROTECT,
        related_name="potrebe_fizickog_pokrica",
    )
    komisija = models.ForeignKey(
        Komisija,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="potrebe_fizickog_pokrica",
    )
    trebovanje = models.ForeignKey(
        "Trebovanje",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="potrebe_fizickog_pokrica",
    )
    migracijski_snapshot = models.ForeignKey(
        MigracijskiSnapshotPacijenta,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="potrebe_fizickog_pokrica",
    )
    termin = models.ForeignKey(
        "Termin",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="potrebe_fizickog_pokrica",
    )
    trazena_kolicina = models.DecimalField(max_digits=8, decimal_places=2)
    preostala_kolicina = models.DecimalField(max_digits=8, decimal_places=2)
    status = models.CharField(
        max_length=24,
        choices=STATUSI,
        default=STATUS_CEKA,
        db_index=True,
    )
    prioritet_datum = models.DateField(null=True, blank=True, db_index=True)
    napomena = models.TextField(blank=True)
    kreirano = models.DateTimeField(auto_now_add=True)
    izmijenjeno = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Potreba fizičkog pokrića"
        verbose_name_plural = "Potrebe fizičkog pokrića"
        ordering = ["prioritet_datum", "kreirano", "id"]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(trazena_kolicina__gt=0),
                name="fiz_potreba_trazeno_gt_0",
            ),
            models.CheckConstraint(
                condition=models.Q(preostala_kolicina__gte=0),
                name="fiz_potreba_preostalo_gte_0",
            ),
            models.CheckConstraint(
                condition=models.Q(
                    preostala_kolicina__lte=models.F("trazena_kolicina")
                ),
                name="fiz_potreba_preostalo_lte_trazeno",
            ),
        ]

    def save(self, *args, **kwargs):
        self.trazena_kolicina = Decimal(str(self.trazena_kolicina or 0))
        self.preostala_kolicina = Decimal(str(self.preostala_kolicina or 0))
        if self.preostala_kolicina <= 0 and self.status == self.STATUS_CEKA:
            self.preostala_kolicina = Decimal("0")
            self.status = self.STATUS_POKRIVENA
        super().save(*args, **kwargs)

    def __str__(self):
        return (
            f"{self.pacijent} - {self.lijek} - "
            f"čeka {self.preostala_kolicina}"
        )


class PacijentRezervacija(models.Model):
    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE, related_name="rezervacije_lijeka")
    lijek = models.ForeignKey(Lijek, on_delete=models.CASCADE, related_name="rezervacije_pacijenata")
    komisija = models.ForeignKey(Komisija, on_delete=models.SET_NULL, null=True, blank=True, related_name="rezervacije_lijeka")
    trebovanje = models.ForeignKey("Trebovanje", on_delete=models.SET_NULL, null=True, blank=True, related_name="rezervacije_lijeka")
    migracijski_snapshot = models.OneToOneField(
        MigracijskiSnapshotPacijenta,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="rezervacija_fizicke_zalihe",
    )
    migracijsko_pocetno_stanje = models.ForeignKey(
        MigracijskoPocetnoStanjeZalihe,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="rezervacije_pacijenata",
    )
    potreba_fizickog_pokrica = models.OneToOneField(
        PotrebaFizickogPokrica,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="fizicka_rezervacija",
    )
    termin = models.ForeignKey(
        "Termin",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="fizicke_rezervacije",
    )
    kolicina = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    aktivno = models.BooleanField(default=True)
    potrosena_at = models.DateTimeField(null=True, blank=True)
    datum_rezervacije = models.DateField(auto_now_add=True)
    napomena = models.TextField(blank=True)

    class Meta:
        verbose_name = "Rezervacija lijeka za pacijenta"
        verbose_name_plural = "Rezervacije lijeka za pacijente"
        ordering = ["datum_rezervacije", "id"]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(kolicina__gte=0),
                name="fiz_rezervacija_kolicina_gte_0",
            ),
            models.UniqueConstraint(
                fields=["termin"],
                condition=models.Q(aktivno=True, termin__isnull=False),
                name="jedna_aktivna_fiz_rez_po_terminu",
            ),
        ]

    def save(self, *args, **kwargs):
        self.kolicina = Decimal(str(self.kolicina or 0))
        if self.kolicina < 0:
            raise ValueError("Rezervisana kolicina ne moze biti negativna.")
        if self.kolicina == 0:
            self.aktivno = False
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.pacijent} - {self.lijek} - {self.kolicina}"


class DokumentSablon(models.Model):
    TIPOVI = [
        ("RAZDUZIVANJE", "Razduživanje lijeka"),
        ("KOMISIJA", "Komisijski izvještaj"),
    ]

    naziv = models.CharField(max_length=100)
    tip = models.CharField(max_length=30, choices=TIPOVI)
    pdf_file = models.FileField(upload_to="sabloni/", blank=True, null=True)

    def __str__(self):
        return self.naziv


class DokumentPacijenta(models.Model):
    TIP_GASTROSKOPIJA = "gastroskopija"
    TIP_KOLONOSKOPIJA = "kolonoskopija"
    TIP_LABORATORIJA = "laboratorija"
    TIP_HISTOPATOLOGIJA = "histopatologija"
    TIP_OTPUSNO_PISMO = "otpusno_pismo"
    TIP_CT_MR = "ct_mr"
    TIP_KOMISIJA = "komisija"
    TIP_TERAPIJA = "terapija"
    TIP_OSTALO = "ostalo"

    TIPOVI_DOKUMENTA = [
        (TIP_GASTROSKOPIJA, "Gastroskopija"),
        (TIP_KOLONOSKOPIJA, "Kolonoskopija"),
        (TIP_LABORATORIJA, "Laboratorija"),
        (TIP_HISTOPATOLOGIJA, "Histopatologija"),
        (TIP_OTPUSNO_PISMO, "Otpusno pismo"),
        (TIP_CT_MR, "CT/MR"),
        (TIP_KOMISIJA, "Komisija"),
        (TIP_TERAPIJA, "Terapija"),
        (TIP_OSTALO, "Ostalo"),
    ]

    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE)
    naziv = models.CharField(max_length=200)
    tip_dokumenta = models.CharField(max_length=30, choices=TIPOVI_DOKUMENTA)
    fajl = models.FileField(upload_to="dokumenti_pacijenata/")
    datum_dokumenta = models.DateField(null=True, blank=True)
    datum_uploada = models.DateTimeField(auto_now_add=True)
    napomena = models.TextField(blank=True)
    uploaded_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    aktivan = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Dokument pacijenta"
        verbose_name_plural = "Dokumenti pacijenata"
        ordering = ["-datum_dokumenta", "-datum_uploada"]

    def __str__(self):
        return f"{self.pacijent} - {self.naziv}"

    def ekstenzija(self):
        return os.path.splitext(self.fajl.name)[1].lower().lstrip(".")

    def je_pdf(self):
        return self.ekstenzija() == "pdf"

    def je_slika(self):
        return self.ekstenzija() in ["jpg", "jpeg", "png"]


class IndividualniProtokolPacijenta(models.Model):
    MJESTO_AMBULANTA = "AMBULANTA"
    MJESTO_KUCNA_TERAPIJA = "KUCNA_TERAPIJA"
    MJESTA_PRIMJENE = [
        (MJESTO_AMBULANTA, "Ambulanta"),
        (MJESTO_KUCNA_TERAPIJA, "Kućna terapija"),
    ]

    pacijent = models.OneToOneField(
        Pacijent,
        on_delete=models.CASCADE,
        related_name="individualni_protokol",
    )
    standardni_protokol = models.ForeignKey(
        TerapijskiProtokol,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="individualne_varijante",
    )
    naziv = models.CharField(max_length=150)
    indukcijska_faza = models.TextField(blank=True)
    faza_odrzavanja = models.TextField(blank=True)
    interval_odrzavanja_sedmica = models.PositiveIntegerField()
    doza_po_aplikaciji = models.DecimalField(max_digits=10, decimal_places=2)
    sigurnosna_rezerva_primjena = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    maksimalna_sigurnosna_rezerva_primjena = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    mjesto_primjene = models.CharField(max_length=20, choices=MJESTA_PRIMJENE)
    datum_pocetka_odrzavanja = models.DateField(null=True, blank=True)
    aktivan = models.BooleanField(default=True)
    razlog_posljednje_izmjene = models.TextField(blank=True, default="")
    kreirao = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="kreirani_individualni_protokoli",
    )
    izmijenio = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="izmijenjeni_individualni_protokoli",
    )
    datum_kreiranja = models.DateTimeField(auto_now_add=True)
    datum_izmjene = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Individualni protokol pacijenta"
        verbose_name_plural = "Individualni protokoli pacijenata"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(interval_odrzavanja_sedmica__gte=1),
                name="individualni_protokol_interval_gte_1",
            ),
            models.CheckConstraint(
                condition=models.Q(doza_po_aplikaciji__gt=0),
                name="individualni_protokol_doza_gt_0",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(sigurnosna_rezerva_primjena__isnull=True)
                    | models.Q(
                        maksimalna_sigurnosna_rezerva_primjena__isnull=True
                    )
                    | models.Q(
                        maksimalna_sigurnosna_rezerva_primjena__gte=models.F(
                            "sigurnosna_rezerva_primjena"
                        )
                    )
                ),
                name="individualni_protokol_rezerva_unutar_maksimuma",
            ),
        ]

    def __str__(self):
        return f"{self.pacijent} - {self.naziv}"

    def snapshot(self):
        podaci = {
            "naziv": self.naziv,
            "indukcijska_faza": self.indukcijska_faza,
            "faza_odrzavanja": self.faza_odrzavanja,
            "interval_odrzavanja_sedmica": self.interval_odrzavanja_sedmica,
            "doza_po_aplikaciji": str(self.doza_po_aplikaciji),
            "sigurnosna_rezerva_primjena": (
                self.sigurnosna_rezerva_primjena
            ),
            "maksimalna_sigurnosna_rezerva_primjena": (
                self.maksimalna_sigurnosna_rezerva_primjena
            ),
            "mjesto_primjene": self.mjesto_primjene,
            "datum_pocetka_odrzavanja": (
                self.datum_pocetka_odrzavanja.isoformat()
                if self.datum_pocetka_odrzavanja
                else None
            ),
            "aktivan": self.aktivan,
            "standardni_protokol_id": self.standardni_protokol_id,
        }
        podaci["koraci"] = (
            [korak.snapshot() for korak in self.koraci.order_by("faza", "redoslijed", "id")]
            if self.pk
            else []
        )
        return podaci


class IndividualniKorakProtokola(models.Model):
    FAZA_INDUKCIJA = "INDUKCIJA"
    FAZA_ODRZAVANJE = "ODRZAVANJE"
    FAZE = [
        (FAZA_INDUKCIJA, "Indukcija"),
        (FAZA_ODRZAVANJE, "Održavanje"),
    ]

    protokol = models.ForeignKey(
        IndividualniProtokolPacijenta,
        on_delete=models.CASCADE,
        related_name="koraci",
    )
    faza = models.CharField(max_length=20, choices=FAZE)
    redoslijed = models.PositiveIntegerField()
    sedmica_od_pocetka = models.PositiveIntegerField()
    doza_mg = models.DecimalField(max_digits=10, decimal_places=2)
    broj_jedinica = models.DecimalField(max_digits=10, decimal_places=2)
    nacin_primjene = models.CharField(
        max_length=20,
        choices=IndividualniProtokolPacijenta.MJESTA_PRIMJENE,
    )
    interval_sedmica = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        verbose_name = "Korak individualnog protokola"
        verbose_name_plural = "Koraci individualnog protokola"
        ordering = ["faza", "redoslijed", "id"]
        constraints = [
            models.UniqueConstraint(
                fields=["protokol", "faza", "redoslijed"],
                name="uniq_individualni_korak_redoslijed",
            ),
            models.UniqueConstraint(
                fields=["protokol", "faza", "sedmica_od_pocetka"],
                name="uniq_individualni_korak_sedmica",
            ),
            models.UniqueConstraint(
                fields=["protokol"],
                condition=models.Q(faza="ODRZAVANJE"),
                name="uniq_individualno_odrzavanje",
            ),
            models.CheckConstraint(
                condition=models.Q(doza_mg__gte=0),
                name="individualni_korak_doza_mg_gte_0",
            ),
            models.CheckConstraint(
                condition=models.Q(broj_jedinica__gt=0),
                name="individualni_korak_jedinice_gt_0",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(faza="INDUKCIJA", interval_sedmica__isnull=True)
                    | models.Q(faza="ODRZAVANJE", interval_sedmica__gte=1)
                ),
                name="individualni_korak_interval_po_fazi",
            ),
        ]

    def save(self, *args, **kwargs):
        if self.faza == self.FAZA_INDUKCIJA:
            self.interval_sedmica = None
        super().save(*args, **kwargs)

    @staticmethod
    def _format_decimal(value):
        value = Decimal(str(value))
        return str(int(value)) if value == value.to_integral_value() else str(value.normalize())

    def opis_za_prikaz(self):
        osnovno = (
            f"sedmica {self.sedmica_od_pocetka}: "
            f"{self._format_decimal(self.doza_mg)} mg / "
            f"{self._format_decimal(self.broj_jedinica)} jedinica "
            f"({self.get_nacin_primjene_display()})"
        )
        if self.faza == self.FAZA_ODRZAVANJE:
            return f"Održavanje od {osnovno}, svake {self.interval_sedmica} sedmice"
        return f"Indukcija {osnovno}"

    def snapshot(self):
        return {
            "faza": self.faza,
            "redoslijed": self.redoslijed,
            "sedmica_od_pocetka": self.sedmica_od_pocetka,
            "doza_mg": str(self.doza_mg),
            "broj_jedinica": str(self.broj_jedinica),
            "nacin_primjene": self.nacin_primjene,
            "interval_sedmica": self.interval_sedmica,
        }


class IzmjenaIndividualnogProtokola(models.Model):
    protokol = models.ForeignKey(
        IndividualniProtokolPacijenta,
        on_delete=models.CASCADE,
        related_name="historija_izmjena",
    )
    korisnik = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    datum_izmjene = models.DateTimeField(auto_now_add=True)
    datum_odluke = models.DateField(default=timezone.localdate)
    ljekar_koji_je_donio_odluku = models.CharField(max_length=150, blank=True)
    povezani_dokument = models.ForeignKey(
        "DokumentPacijenta",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="izmjene_individualnog_protokola",
    )
    razlog = models.TextField()
    prethodno_stanje = models.JSONField(default=dict, blank=True)
    novo_stanje = models.JSONField(default=dict)

    class Meta:
        verbose_name = "Izmjena individualnog protokola"
        verbose_name_plural = "Izmjene individualnih protokola"
        ordering = ["-datum_izmjene", "-id"]

    def __str__(self):
        return f"{self.protokol.pacijent} - {self.datum_izmjene:%d/%m/%Y %H:%M}"


class AktivnostLog(models.Model):
    datum_vrijeme = models.DateTimeField(auto_now_add=True)
    korisnik = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)

    akcija = models.CharField(max_length=200)

    pacijent = models.ForeignKey(Pacijent, on_delete=models.SET_NULL, null=True, blank=True)

    objekat_tip = models.CharField(max_length=100, blank=True)
    objekat_id = models.PositiveIntegerField(null=True, blank=True)

    opis = models.TextField(blank=True)

    def __str__(self):
        return f"{self.datum_vrijeme:%d/%m/%Y %H:%M} - {self.akcija}"


class KorisnickiPristup(models.Model):
    """Sigurnosno stanje korisnika koje nije dio Django identiteta."""

    korisnik = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="theraflow_pristup",
    )
    zahtijeva_promjenu_lozinke = models.BooleanField(default=False)
    izmijenjeno = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Korisnički pristup"
        verbose_name_plural = "Korisnički pristupi"

    def __str__(self):
        return f"{self.korisnik.username} - sigurnosne postavke"


class KomisijskiRucniUnos(models.Model):
    """Trenutni ljekarski override V2 komisijskog prijedloga.

    Stvarno trebovanje nastaje tek u postojećem komisijskom workflowu. Ovaj
    zapis čuva odluku i njeno obrazloženje bez preuranjenog kreiranja zahtjeva.
    """

    pacijent = models.ForeignKey(
        Pacijent,
        on_delete=models.CASCADE,
        related_name="komisijski_rucni_unosi",
    )
    lijek = models.ForeignKey(
        Lijek,
        on_delete=models.PROTECT,
        related_name="komisijski_rucni_unosi",
    )
    komisijski_ciklus = models.ForeignKey(
        "KomisijskiCiklus",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="rucni_unosi",
    )
    sistemski_prijedlog = models.DecimalField(max_digits=8, decimal_places=2)
    ljekar_trazi = models.DecimalField(max_digits=8, decimal_places=2)
    razlog = models.TextField(blank=True)
    rucni_override = models.BooleanField(default=False, db_index=True)
    aktivan_nacrt = models.BooleanField(default=False, db_index=True)
    korisnik = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="komisijski_rucni_unosi",
    )
    izmijenjeno = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["pacijent", "lijek", "komisijski_ciklus"],
                condition=models.Q(komisijski_ciklus__isnull=False),
                name="uniq_komisijski_unos_pacijent_lijek_ciklus",
            ),
            models.UniqueConstraint(
                fields=["pacijent", "lijek"],
                condition=models.Q(aktivan_nacrt=True),
                name="uniq_aktivan_komisijski_unos_pacijent_lijek",
            ),
            models.CheckConstraint(
                condition=models.Q(sistemski_prijedlog__gte=0),
                name="komisijski_rucni_sistemski_gte_0",
            ),
            models.CheckConstraint(
                condition=models.Q(ljekar_trazi__gte=0),
                name="komisijski_rucni_ljekar_gte_0",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(aktivan_nacrt=False)
                    | models.Q(komisijski_ciklus__isnull=True)
                ),
                name="aktivan_komisijski_unos_bez_ciklusa",
            ),
        ]

    def __str__(self):
        return f"{self.pacijent} - sistem {self.sistemski_prijedlog}, ljekar {self.ljekar_trazi}"


class Trebovanje(models.Model):
    TIP_REDOVNI = "REDOVNI"
    TIP_VANREDNI = "VANREDNI"
    TIPOVI_ZAHTJEVA = [
        (TIP_REDOVNI, "Redovni"),
        (TIP_VANREDNI, "Vanredni"),
    ]

    STATUS_NACRT = "NACRT"
    STATUS_SPREMAN = "SPREMAN"
    STATUS_POSLAN_KOMISIJI = "POSLAN_KOMISIJI"
    STATUS_DJELOMICNO_ODOBRENO = "DJELOMICNO_ODOBRENO"
    STATUS_CEKA_ISPORUKU = "CEKA_ISPORUKU"
    STATUS_OTKAZANO = "OTKAZANO"
    STATUSI = [
        ("U_PRIPREMI", "U pripremi"),
        ("PREDATO", "Predato Zavodu"),
        (STATUS_NACRT, "Nacrt"),
        (STATUS_SPREMAN, "Spreman za predaju"),
        (STATUS_POSLAN_KOMISIJI, "Poslan komisiji"),
        ("ODOBRENO", "Odobreno"),
        (STATUS_DJELOMICNO_ODOBRENO, "Djelimično odobren"),
        (STATUS_CEKA_ISPORUKU, "Čeka isporuku"),
        ("ZAPRIMLJENO", "Lijek zaprimljen"),
        ("ODBIJENO", "Odbijeno"),
        (STATUS_OTKAZANO, "Otkazan"),
    ]
    RAZLOG_NEDOVOLJNO_DO_REDOVNE = "NEDOVOLJNO_DO_REDOVNE"
    RAZLOG_NOVI_PACIJENT = "NOVI_PACIJENT"
    RAZLOG_PROMJENA_TERAPIJE = "PROMJENA_TERAPIJE"
    RAZLOG_RANIJE_ODOBRENJE_NEDOVOLJNO = "RANIJE_ODOBRENJE_NEDOVOLJNO"
    RAZLOG_KASNJENJE_ISPORUKE = "KASNJENJE_ISPORUKE"
    RAZLOG_DRUGI = "DRUGI"
    RAZLOZI_VANREDNOG = [
        (
            RAZLOG_NEDOVOLJNO_DO_REDOVNE,
            "Nedovoljna količina do naredne redovne komisije",
        ),
        (RAZLOG_NOVI_PACIJENT, "Uvođenje novog pacijenta"),
        (RAZLOG_PROMJENA_TERAPIJE, "Promjena terapije"),
        (
            RAZLOG_RANIJE_ODOBRENJE_NEDOVOLJNO,
            "Ranije odobrena količina nije dovoljna",
        ),
        (RAZLOG_KASNJENJE_ISPORUKE, "Kašnjenje isporuke"),
        (RAZLOG_DRUGI, "Drugi razlog"),
    ]

    pacijent = models.ForeignKey(Pacijent, on_delete=models.CASCADE)
    lijek = models.ForeignKey(Lijek, on_delete=models.CASCADE)
    tip_zahtjeva = models.CharField(
        max_length=20,
        choices=TIPOVI_ZAHTJEVA,
        default=TIP_REDOVNI,
        db_index=True,
    )
    razlog_vanrednog = models.CharField(
        max_length=40,
        choices=RAZLOZI_VANREDNOG,
        blank=True,
    )
    razlog_objasnjenje = models.TextField(blank=True)
    kratka_napomena = models.TextField(blank=True)
    kreirao = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="kreirana_trebovanja",
    )
    protokol = models.ForeignKey(
        TerapijskiProtokol,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="trebovanja",
    )
    faza_terapije = models.CharField(max_length=50, blank=True)
    sistemski_prijedlog = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
    )
    sljedeca_zakazana_terapija = models.DateField(null=True, blank=True)
    ocekivana_najranija_isporuka = models.DateField(null=True, blank=True)
    rizik_dostave_pri_kreiranju = models.BooleanField(default=False)
    broj_doza = models.DecimalField(max_digits=8, decimal_places=2, default=1)
    odobrene_doze = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    zaprimljene_doze = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    datum_kreiranja = models.DateField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUSI, default="U_PRIPREMI")
    dokumentacija_kompletna = models.BooleanField(default=False)
    napomena = models.TextField(blank=True)
    predsjednik_konzilija = models.CharField(max_length=150, blank=True)
    clan_konzilija_1 = models.CharField(max_length=150, blank=True)
    clan_konzilija_2 = models.CharField(max_length=150, blank=True)
    zaduzenje_kreirano = models.BooleanField(default=False)
    komisijski_ciklus = models.ForeignKey(
        'KomisijskiCiklus',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="trebovanja"
    )
    komisija = models.ForeignKey(
        Komisija,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="trebovanja",
    )

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=models.Q(odobrene_doze__isnull=True) | models.Q(odobrene_doze__gte=0),
                name="trebovanje_odobrene_doze_gte_0",
            ),
            models.CheckConstraint(
                condition=models.Q(zaprimljene_doze__gte=0),
                name="trebovanje_zaprimljene_doze_gte_0",
            ),
            models.UniqueConstraint(
                fields=["pacijent", "lijek", "komisijski_ciklus"],
                condition=(
                    models.Q(komisijski_ciklus__isnull=False)
                    & models.Q(status__in=["U_PRIPREMI", "NACRT", "SPREMAN"])
                ),
                name="uniq_aktivno_trebovanje_pacijent_lijek_ciklus",
            ),
        ]
        indexes = [
            models.Index(
                fields=["tip_zahtjeva", "status", "datum_kreiranja"],
                name="request_type_status_date_idx",
            ),
        ]

    @property
    def broj_pakovanja(self):
        from .package_sizes import package_count

        return package_count(self.broj_doza, self.lijek)

    @property
    def nabavna_kolicina_prikaz(self):
        from .package_sizes import procurement_breakdown

        return procurement_breakdown(
            self.broj_doza,
            self.lijek,
        )["display_text"]

    @property
    def sistemska_nabavna_kolicina_prikaz(self):
        from .package_sizes import procurement_breakdown

        quantity = (
            self.sistemski_prijedlog
            if self.sistemski_prijedlog is not None
            else self.broj_doza
        )
        return procurement_breakdown(
            quantity,
            self.lijek,
        )["display_text"]

    @property
    def odobreno_pakovanja(self):
        from .package_sizes import package_count

        quantity = (
            self.odobrene_doze
            if self.odobrene_doze is not None
            else self.broj_doza
        )
        return package_count(quantity, self.lijek)

    @property
    def odobrena_nabavna_kolicina_prikaz(self):
        from .package_sizes import procurement_breakdown

        quantity = (
            self.odobrene_doze
            if self.odobrene_doze is not None
            else self.broj_doza
        )
        return procurement_breakdown(
            quantity,
            self.lijek,
        )["display_text"]

    @property
    def zaprimljeno_pakovanja(self):
        from .package_sizes import package_count

        return package_count(self.zaprimljene_doze, self.lijek)

    @property
    def zaprimljena_nabavna_kolicina_prikaz(self):
        from .package_sizes import procurement_breakdown

        return procurement_breakdown(
            self.zaprimljene_doze,
            self.lijek,
        )["display_text"]

    def clean(self):
        super().clean()
        if self.broj_doza is None or self.broj_doza <= 0:
            raise ValidationError({
                "broj_doza": "Tražena količina mora biti veća od nule."
            })
        if not self.lijek_id:
            return
        from .package_sizes import validate_package_multiple

        errors = {}
        for field, label in (
            ("broj_doza", "Tražena količina"),
            ("odobrene_doze", "Odobrena količina"),
            ("zaprimljene_doze", "Zaprimljena količina"),
        ):
            value = getattr(self, field)
            if value is None:
                continue
            try:
                validate_package_multiple(value, self.lijek, label=label)
            except ValueError as exc:
                errors[field] = str(exc)
        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        update_fields = kwargs.get("update_fields")
        quantity_fields = {"broj_doza", "odobrene_doze", "zaprimljene_doze"}
        if self._state.adding or update_fields is None or quantity_fields.intersection(update_fields):
            if self.broj_doza is None or self.broj_doza <= 0:
                raise ValidationError(
                    "Tražena količina mora biti veća od nule."
                )
            from .package_sizes import validate_package_multiple
            for field, label in (
                ("broj_doza", "Tražena količina"),
                ("odobrene_doze", "Odobrena količina"),
                ("zaprimljene_doze", "Zaprimljena količina"),
            ):
                value = getattr(self, field)
                if value is not None:
                    validate_package_multiple(value, self.lijek, label=label)
        super().save(*args, **kwargs)


class Ljekar(models.Model):
    ime_prezime = models.CharField(max_length=150)
    aktivan = models.BooleanField(default=True)

    def __str__(self):
        return self.ime_prezime


class PostavkeSistema(models.Model):
    komisijski_ciklus_mjeseci = models.PositiveIntegerField(default=2)
    priprema_zahtjeva_radnih_dana = models.PositiveIntegerField(default=5)
    vrijeme_isporuke_dana = models.PositiveIntegerField(
        default=18,
        validators=[MinValueValidator(15), MaxValueValidator(20)],
    )
    ciljni_broj_dana_pokrivenosti = models.PositiveIntegerField(
        default=90,
        validators=[MinValueValidator(1)],
    )
    prosjecno_trajanje_odobrenja_komisije_dana = models.PositiveIntegerField(
        default=14,
    )
    sigurnosna_rezerva_dana = models.PositiveIntegerField(default=14)
    potvrdjeni_datum_naredne_komisije = models.DateField(null=True, blank=True)
    zdravstvena_ustanova = models.CharField(max_length=200, blank=True)
    podnosilac_zahtjeva = models.CharField(max_length=150, blank=True)
    default_predsjednik_konzilija = models.CharField(max_length=150, blank=True)
    default_clan_konzilija_1 = models.CharField(max_length=150, blank=True)
    default_clan_konzilija_2 = models.CharField(max_length=150, blank=True)
    pg_dump_path = models.CharField(max_length=500, blank=True)
    migracija_zakljucana = models.BooleanField(default=False)

    def period_planiranja(self):
        # Kompatibilni prikaz u sedmicama; kanonski datumi se računaju servisom.
        return (self.komisijski_ciklus_mjeseci * 4) + ceil(
            Decimal(str(self.vrijeme_isporuke_dana)) / Decimal("7")
        )

    def __str__(self):
        return "Postavke sistema"


class LogistickePostavkeLijeka(models.Model):
    """Opcioni rokovi lijeka; prazna vrijednost nasljeđuje postavke ustanove."""

    lijek = models.OneToOneField(
        Lijek,
        on_delete=models.CASCADE,
        related_name="logisticke_postavke",
    )
    ciljni_broj_dana_pokrivenosti = models.PositiveIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(1)],
    )
    prosjecno_trajanje_odobrenja_komisije_dana = models.PositiveIntegerField(
        null=True,
        blank=True,
    )
    prosjecno_trajanje_dostave_lijeka_dana = models.PositiveIntegerField(
        null=True,
        blank=True,
    )
    sigurnosna_rezerva_dana = models.PositiveIntegerField(null=True, blank=True)
    sigurnosna_rezerva_primjena = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    maksimalna_sigurnosna_rezerva_primjena = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    maksimalni_rok_potrosnje_dana = models.PositiveIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(1)],
        help_text=(
            "Opcioni maksimalni period u kojem dodatna rezerva mora biti "
            "potrošiva."
        ),
    )

    class Meta:
        verbose_name = "Logističke postavke lijeka"
        verbose_name_plural = "Logističke postavke lijekova"

    def __str__(self):
        return f"Logistika — {self.lijek}"


class KomisijskiCiklus(models.Model):
    class TipCiklusa(models.TextChoices):
        REDOVNI = "REDOVNI", "Redovni"
        VANREDNI = "VANREDNI", "Vanredni"

    # Kompatibilni aliasi za postojeće servise i integracije.
    TIP_REDOVNI = TipCiklusa.REDOVNI
    TIP_VANREDNI = TipCiklusa.VANREDNI
    TIPOVI = TipCiklusa.choices
    STATUS = [
        ("nacrt", "Nacrt"),
        ("spremno_za_stampu", "Spremno za štampu"),
        ("odstampano", "Odštampano"),
        ("poslano_komisiji", "Poslano komisiji"),
        ("ceka_saglasnosti", "Čeka saglasnosti"),
        (
            "djelimicno_zaprimljene_saglasnosti",
            "Djelimično zaprimljene saglasnosti",
        ),
        ("zavrseno", "Završeno"),
        # Legacy vrijednosti ostaju podržane dok postojeći Komisijski centar
        # ne pređe na novi workflow.
        ("SIMULACIJA", "Simulacija"),
        ("PREDATO", "Predato na komisiju"),
        ("ODOBRENO", "Odobreno"),
        ("CEKA_ISPORUKU", "Čeka isporuku"),
        ("DJELOMICNO_ZAPRIMLJENO", "Djelimično zaprimljeno"),
        ("ZAPRIMLJENO", "Zaprimljeno"),
        ("ZAVRSENO", "Završeno"),
    ]

    naziv = models.CharField(max_length=50, unique=True)
    mjesec = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(12)],
    )
    godina = models.PositiveSmallIntegerField(null=True, blank=True)
    tip_ciklusa = models.CharField(
        max_length=20,
        choices=TIPOVI,
        default=TipCiklusa.REDOVNI,
        db_index=True,
    )
    datum_kreiranja = models.DateField(auto_now_add=True)
    datum_pripreme = models.DateField(null=True, blank=True)
    datum_slanja = models.DateField(null=True, blank=True)
    rok_pripreme_dokumentacije = models.DateField(null=True, blank=True)
    datum_komisije = models.DateField(null=True, blank=True)
    datum_predaje = models.DateField(null=True, blank=True)
    datum_odobrenja = models.DateField(null=True, blank=True)
    datum_zaprimanja = models.DateField(null=True, blank=True)
    najraniji_ocekivani_datum_isporuke = models.DateField(null=True, blank=True)
    najkasniji_ocekivani_datum_isporuke = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=40, choices=STATUS, default="SIMULACIJA")
    napomena = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(default=timezone.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=["datum_komisije"], name="cycle_planned_date_idx"),
            models.Index(fields=["status", "datum_komisije"], name="cycle_status_date_idx"),
        ]

    def __str__(self):
        return self.naziv


class PacijentSaglasnost(models.Model):
    """Verzionirana saglasnost koja pripada jednom pacijentu.

    Broj na legacy ``Komisija`` zapisu ostaje historijski snapshot. Ovaj model
    je source of truth za trenutno važeći broj i njegove kasnije promjene.
    """

    pacijent = models.ForeignKey(
        Pacijent,
        on_delete=models.CASCADE,
        related_name="saglasnosti_pacijenta",
    )
    broj_saglasnosti = models.CharField(max_length=100, db_index=True)
    vazi_od = models.DateField(default=timezone.localdate)
    vazi_do = models.DateField(null=True, blank=True)
    trenutno_vazeca = models.BooleanField(default=True, db_index=True)
    izmijenio = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="izmjene_saglasnosti_pacijenata",
    )
    izvorni_ciklus = models.ForeignKey(
        "KomisijskiCiklus",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="promjene_saglasnosti_pacijenata",
    )
    izvorno_trebovanje = models.ForeignKey(
        Trebovanje,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="promjene_saglasnosti_pacijenta",
    )
    izvorna_komisija = models.ForeignKey(
        Komisija,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="saglasnosti_pacijenata",
    )
    kreirano = models.DateTimeField(auto_now_add=True)
    izmijenjeno = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-vazi_od", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["pacijent"],
                condition=models.Q(trenutno_vazeca=True),
                name="uniq_current_patient_agreement",
            ),
        ]
        indexes = [
            models.Index(
                fields=["pacijent", "trenutno_vazeca"],
                name="patient_agreement_current_idx",
            ),
        ]

    def __str__(self):
        return f"{self.pacijent} — {self.broj_saglasnosti}"


class EvidencijaSaglasnostiZaprimanja(models.Model):
    """Nepromjenjivi snapshot saglasnosti korišten pri jednom zaprimaju."""

    saglasnost = models.ForeignKey(
        PacijentSaglasnost,
        on_delete=models.PROTECT,
        related_name="zaprimanja",
    )
    pacijent = models.ForeignKey(
        Pacijent,
        on_delete=models.PROTECT,
        related_name="evidencije_saglasnosti_zaprimanja",
    )
    trebovanje = models.ForeignKey(
        Trebovanje,
        on_delete=models.PROTECT,
        related_name="evidencije_saglasnosti_zaprimanja",
    )
    komisijski_ciklus = models.ForeignKey(
        KomisijskiCiklus,
        on_delete=models.PROTECT,
        related_name="evidencije_saglasnosti_zaprimanja",
    )
    broj_saglasnosti_snapshot = models.CharField(max_length=100)
    zaprimljena_kolicina = models.DecimalField(max_digits=8, decimal_places=2)
    korisnik = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="evidencije_saglasnosti_zaprimanja",
    )
    kreirano = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-kreirano", "-id"]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(zaprimljena_kolicina__gt=0),
                name="receipt_agreement_quantity_gt0",
            ),
        ]

    def __str__(self):
        return (
            f"{self.pacijent} — {self.broj_saglasnosti_snapshot} — "
            f"{self.komisijski_ciklus}"
        )


class KomisijskiZahtjev(models.Model):
    class ProgramType(models.TextChoices):
        BIOLOGIC = "BIOLOGIC", "Biološka terapija"
        HEPATITIS_B = "HEPATITIS_B", "Hepatitis B"
        UNCONFIGURED = "UNCONFIGURED", "Nije konfigurirano"

    class RequestPurpose(models.TextChoices):
        NEW = "NEW", "Novi"
        CONTINUATION = "CONTINUATION", "Produženje"
        SWITCH = "SWITCH", "Promjena/switch"
        DISCONTINUATION = "DISCONTINUATION", "Odjava"

    class SuggestedPurpose(models.TextChoices):
        NEW = "NEW", "Novi"
        CONTINUATION = "CONTINUATION", "Produženje"
        SWITCH = "SWITCH", "Promjena/switch"
        DISCONTINUATION = "DISCONTINUATION", "Odjava"
        REQUIRES_CONFIRMATION = "REQUIRES_CONFIRMATION", "Potrebna potvrda"

    class VrstaZahtjeva(models.TextChoices):
        BIOLOSKA_PRODUZENJE = (
            "bioloska_produzenje",
            "Biološka terapija – produženje",
        )
        BIOLOSKA_NOVI = "bioloska_novi", "Biološka terapija – novi"
        BIOLOSKA_SWITCH = (
            "bioloska_switch",
            "Biološka terapija – promjena/switch",
        )
        BIOLOSKA_ODJAVA = "bioloska_odjava", "Biološka terapija – odjava"
        HEPATITIS_B_PRODUZENJE = (
            "hepatitis_b_produzenje",
            "Hepatitis B – produženje",
        )

    class Status(models.TextChoices):
        NACRT = "nacrt", "Nacrt"
        POTVRDJEN = "potvrdjen", "Potvrđen"
        POSLAN = "poslan", "Poslan komisiji"
        CEKA_SAGLASNOST = "ceka_saglasnost", "Čeka saglasnost"
        ODLUCENO = "odluceno", "Odlučeno"

    komisijski_ciklus = models.ForeignKey(
        KomisijskiCiklus,
        on_delete=models.CASCADE,
        related_name="zahtjevi_faza1",
    )
    pacijent = models.ForeignKey(
        Pacijent,
        on_delete=models.PROTECT,
        related_name="komisijski_zahtjevi_faza1",
    )
    vrsta_zahtjeva = models.CharField(
        max_length=32,
        choices=VrstaZahtjeva.choices,
    )
    program_type = models.CharField(
        max_length=24,
        choices=ProgramType.choices,
        blank=True,
        default="",
    )
    request_purpose = models.CharField(
        max_length=24,
        choices=RequestPurpose.choices,
        blank=True,
        default="",
    )
    system_suggested_purpose = models.CharField(
        max_length=32,
        choices=SuggestedPurpose.choices,
        blank=True,
        default="",
    )
    classification_reason_code = models.CharField(max_length=64, blank=True)
    classification_reason = models.TextField(blank=True)
    source_therapy_change = models.ForeignKey(
        PromjenaTerapije,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="komisijski_zahtjevi",
    )
    final_user_decision = models.CharField(
        max_length=24,
        choices=RequestPurpose.choices,
        blank=True,
        default="",
    )
    request_type_override_reason = models.TextField(blank=True)
    request_type_finalized_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="finalizirane_vrste_komisijskih_zahtjeva",
    )
    request_type_finalized_at = models.DateTimeField(null=True, blank=True)
    document_package_key = models.CharField(max_length=80, blank=True)
    document_requirements_snapshot = models.JSONField(default=dict, blank=True)
    status = models.CharField(
        max_length=24,
        choices=Status.choices,
        default=Status.NACRT,
    )
    sistem_predlozio = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
    )
    ljekar_trazi = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
    )
    finalna_kolicina = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Opcioni zbir; stavke lijeka ostaju izvor detaljnih količina.",
    )
    prethodni_lijek = models.ForeignKey(
        Lijek,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="komisijski_switch_sa_lijeka",
    )
    novi_lijek = models.ForeignKey(
        Lijek,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="komisijski_switch_na_lijek",
    )
    preostala_kolicina_prethodnog_lijeka = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
    )
    napomena = models.TextField(blank=True)
    razlog_odjave = models.TextField(blank=True)
    datum_kreiranja = models.DateTimeField(default=timezone.now, editable=False)
    potvrdio_korisnik = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="potvrdjeni_komisijski_zahtjevi_faza1",
    )
    print_snapshot = models.JSONField(
        default=dict,
        blank=True,
        help_text=(
            "Snapshot podataka korištenih za posljednju generaciju službenog "
            "zahtjeva. Ne koristi se za operativni obračun."
        ),
    )
    print_snapshot_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("komisijski_ciklus", "pacijent", "datum_kreiranja")
        constraints = [
            models.UniqueConstraint(
                fields=("komisijski_ciklus", "pacijent"),
                name="uniq_f1_req_cycle_patient",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(sistem_predlozio__isnull=True)
                    | models.Q(sistem_predlozio__gte=0)
                ),
                name="f1_req_system_gte0",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(ljekar_trazi__isnull=True)
                    | models.Q(ljekar_trazi__gte=0)
                ),
                name="f1_req_doctor_gte0",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(finalna_kolicina__isnull=True)
                    | models.Q(finalna_kolicina__gte=0)
                ),
                name="f1_req_final_gte0",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(preostala_kolicina_prethodnog_lijeka__isnull=True)
                    | models.Q(preostala_kolicina_prethodnog_lijeka__gte=0)
                ),
                name="f1_req_old_rem_gte0",
            ),
        ]
        indexes = [
            models.Index(
                fields=("komisijski_ciklus", "vrsta_zahtjeva", "status"),
                name="f1_req_cycle_type_status",
            ),
        ]

    def __str__(self):
        return f"{self.komisijski_ciklus} – {self.pacijent}"

    @property
    def canonical_request_type_label(self):
        from .commission_request_types import request_type_label

        if self.program_type and self.request_purpose:
            return request_type_label(self.program_type, self.request_purpose)
        return self.get_vrsta_zahtjeva_display()

    @property
    def document_package(self):
        from .commission_request_types import document_package_for

        return document_package_for(self.program_type, self.request_purpose)

    @property
    def request_type_was_overridden(self):
        return bool(
            self.system_suggested_purpose
            and self.request_purpose
            and self.system_suggested_purpose != self.request_purpose
        )

    def save(self, *args, **kwargs):
        # Compatibility for legacy imports and tests that still create only the
        # combined field.  Once captured, these canonical snapshot fields are
        # never recomputed from the patient's later state.
        if self.vrsta_zahtjeva and (not self.program_type or not self.request_purpose):
            from .commission_request_types import (
                canonical_from_legacy,
                request_document_snapshot,
            )

            program_type, purpose = canonical_from_legacy(self.vrsta_zahtjeva)
            self.program_type = self.program_type or program_type
            self.request_purpose = self.request_purpose or purpose
            self.final_user_decision = self.final_user_decision or purpose
            self.system_suggested_purpose = self.system_suggested_purpose or purpose
            if program_type and purpose and not self.document_requirements_snapshot:
                snapshot = request_document_snapshot(program_type, purpose)
                self.document_package_key = snapshot["package_key"]
                self.document_requirements_snapshot = snapshot
        super().save(*args, **kwargs)


class KomisijskaStavkaLijeka(models.Model):
    class Jedinica(models.TextChoices):
        FLAKON = "flakon", "Flakon"
        TABLETA = "tableta", "Tableta"
        PEN = "pen", "Pen"
        PAKOVANJE = "pakovanje", "Pakovanje"

    komisijski_zahtjev = models.ForeignKey(
        KomisijskiZahtjev,
        on_delete=models.CASCADE,
        related_name="stavke_lijeka",
    )
    lijek = models.ForeignKey(
        Lijek,
        on_delete=models.PROTECT,
        related_name="komisijske_stavke_faza1",
    )
    genericki_naziv = models.CharField(max_length=100, blank=True)
    zasticeni_naziv = models.CharField(max_length=100, blank=True)
    jacina = models.CharField(max_length=100, blank=True)
    oblik = models.CharField(max_length=100, blank=True)
    kolicina = models.DecimalField(max_digits=10, decimal_places=2)
    odobrena_kolicina = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
    )
    jedinica = models.CharField(max_length=20, choices=Jedinica.choices)
    redoslijed = models.PositiveSmallIntegerField(default=1)

    class Meta:
        ordering = ("komisijski_zahtjev", "redoslijed", "id")
        constraints = [
            models.UniqueConstraint(
                fields=("komisijski_zahtjev", "redoslijed"),
                name="uniq_f1_item_order",
            ),
            models.CheckConstraint(
                condition=models.Q(kolicina__gte=0),
                name="f1_item_qty_gte0",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(odobrena_kolicina__isnull=True)
                    | models.Q(odobrena_kolicina__gte=0)
                ),
                name="f1_item_approved_gte0",
            ),
        ]

    @property
    def trazena_kolicina(self):
        return self.kolicina

    def save(self, *args, **kwargs):
        if self.lijek_id:
            if not self.genericki_naziv:
                self.genericki_naziv = self.lijek.genericki_naziv
            if not self.zasticeni_naziv:
                self.zasticeni_naziv = self.lijek.zasticeno_ime or self.lijek.naziv
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.zasticeni_naziv or self.lijek} – {self.jacina} – {self.kolicina} {self.jedinica}"


class KomisijskaSaglasnost(models.Model):
    class Odluka(models.TextChoices):
        ODOBRENO = "odobreno", "Odobreno"
        DJELIMICNO_ODOBRENO = "djelimicno_odobreno", "Djelimično odobreno"
        ODBIJENO = "odbijeno", "Odbijeno"

    komisijski_zahtjev = models.OneToOneField(
        KomisijskiZahtjev,
        on_delete=models.CASCADE,
        related_name="saglasnost",
    )
    broj_saglasnosti = models.CharField(
        max_length=100,
        unique=True,
        null=True,
        blank=True,
    )
    datum_saglasnosti = models.DateField()
    odluka = models.CharField(max_length=24, choices=Odluka.choices)
    napomena = models.TextField(blank=True)
    created_at = models.DateTimeField(default=timezone.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.broj_saglasnosti} – {self.komisijski_zahtjev}"


class FazniProtokolPacijenta(models.Model):
    """Eksplicitni state za lijekove čiji koraci koriste različite prezentacije."""

    PROTOKOL_USTEKINUMAB = "ustekinumab"

    FAZA_CEKA_IV = "CEKA_IV_INDUKCIJU"
    FAZA_CEKA_PRVU_SC = "CEKA_PRVU_SC"
    FAZA_ODRZAVANJE = "ODRZAVANJE"
    FAZE = [
        (FAZA_CEKA_IV, "Čeka IV indukciju"),
        (FAZA_CEKA_PRVU_SC, "IV završena / čeka prvu SC dozu"),
        (FAZA_ODRZAVANJE, "SC održavanje"),
    ]
    INTERVALI_ODRZAVANJA = [
        (8, "8 sedmica"),
        (12, "12 sedmica"),
    ]
    SC_NACIN_AMBULANTA = "AMBULANTA"
    SC_NACIN_KUCNA = "KUCNA_TERAPIJA"
    SC_NACINI_PRIMJENE = [
        (SC_NACIN_AMBULANTA, "SC primjena u ambulanti"),
        (SC_NACIN_KUCNA, "Kućna terapija"),
    ]

    pacijent = models.OneToOneField(
        Pacijent,
        on_delete=models.CASCADE,
        related_name="fazni_protokol",
    )
    terapijski_program = models.ForeignKey(
        TerapijskiProgram,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="fazni_protokoli_pacijenata",
    )
    trenutna_faza = models.ForeignKey(
        TerapijskaFaza,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="stanja_pacijenata",
    )
    protokol_kljuc = models.CharField(
        max_length=40,
        default=PROTOKOL_USTEKINUMAB,
    )
    faza = models.CharField(max_length=32, choices=FAZE, default=FAZA_CEKA_IV)
    iv_lijek = models.ForeignKey(
        Lijek,
        on_delete=models.PROTECT,
        related_name="fazni_protokoli_iv",
    )
    sc_lijek = models.ForeignKey(
        Lijek,
        on_delete=models.PROTECT,
        related_name="fazni_protokoli_sc",
    )
    pocetni_komisijski_zahtjev = models.ForeignKey(
        KomisijskiZahtjev,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="pokrenuti_fazni_protokoli",
    )
    tezina_kg = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        null=True,
        blank=True,
    )
    tezina_izmjerena_at = models.DateTimeField(null=True, blank=True)
    indukcijska_doza_mg = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
    )
    indukcijski_broj_jedinica = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
    )
    interval_odrzavanja_sedmica = models.PositiveSmallIntegerField(
        choices=INTERVALI_ODRZAVANJA,
        default=8,
    )
    sc_nacin_primjene = models.CharField(
        max_length=24,
        choices=SC_NACINI_PRIMJENE,
        default=SC_NACIN_AMBULANTA,
    )
    kucna_terapija_od = models.DateTimeField(null=True, blank=True)
    kucna_terapija_potvrdio = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="potvrdjeni_ustekinumab_kucni_prijelazi",
    )
    zadnji_povratak_u_ambulantu_at = models.DateTimeField(null=True, blank=True)
    zadnji_povratak_u_ambulantu_evidentirao = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="evidentirani_ustekinumab_povratci_u_ambulantu",
    )
    datum_iv_primjene = models.DateField(null=True, blank=True)
    datum_prve_sc_primjene = models.DateField(null=True, blank=True)
    datum_posljednje_primjene = models.DateField(null=True, blank=True)
    sljedeci_datum = models.DateField(null=True, blank=True)
    aktivan = models.BooleanField(default=True)
    kreirao = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="kreirani_fazni_protokoli",
    )
    izmijenio = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="izmijenjeni_fazni_protokoli",
    )
    kreirano = models.DateTimeField(auto_now_add=True)
    izmijenjeno = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Fazni protokol pacijenta"
        verbose_name_plural = "Fazni protokoli pacijenata"
        constraints = [
            models.CheckConstraint(
                condition=(
                    models.Q(tezina_kg__isnull=True)
                    | models.Q(tezina_kg__gt=0)
                ),
                name="fazni_protokol_tezina_pozitivna",
            ),
            models.CheckConstraint(
                condition=models.Q(interval_odrzavanja_sedmica__in=(8, 12)),
                name="fazni_protokol_interval_8_ili_12",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(sc_nacin_primjene="AMBULANTA")
                    | models.Q(faza="ODRZAVANJE")
                ),
                name="fazni_sc_kucna_samo_odrzavanje",
            ),
        ]

    def __str__(self):
        return f"{self.pacijent} – {self.get_faza_display()}"

    @property
    def sc_je_kucna_terapija(self):
        return (
            self.faza == self.FAZA_ODRZAVANJE
            and self.sc_nacin_primjene == self.SC_NACIN_KUCNA
        )


class AdaptiveDecisionRecord(models.Model):
    """Append-only observation zapis; nikada nije ulaz u klinički engine."""

    DECISION_COMMISSION = "COMMISSION"
    DECISION_PROCUREMENT = "PROCUREMENT"
    DECISION_TYPES = [
        (DECISION_COMMISSION, "Komisijski prijedlog"),
        (DECISION_PROCUREMENT, "Nabavni prijedlog"),
    ]
    REASON_DELIVERY_DELAY = "DELIVERY_DELAY"
    REASON_EXTRA_RESERVE = "EXTRA_RESERVE"
    REASON_THERAPY_PLAN = "THERAPY_PLAN"
    REASON_PATIENT_DELAYED = "PATIENT_DELAYED"
    REASON_SECURED_ELSEWHERE = "SECURED_ELSEWHERE"
    REASON_INCOMPLETE_DATA = "INCOMPLETE_DATA"
    REASON_DOCTOR_AGREEMENT = "DOCTOR_AGREEMENT"
    REASON_OTHER = "OTHER"
    OVERRIDE_REASONS = [
        (REASON_DELIVERY_DELAY, "Očekivano kašnjenje isporuke"),
        (REASON_EXTRA_RESERVE, "Dodatna sigurnosna rezerva"),
        (REASON_THERAPY_PLAN, "Promjena plana terapije"),
        (REASON_PATIENT_DELAYED, "Pacijent privremeno odgođen"),
        (REASON_SECURED_ELSEWHERE, "Lijek već osiguran drugim putem"),
        (REASON_INCOMPLETE_DATA, "Greška ili nepotpun podatak"),
        (REASON_DOCTOR_AGREEMENT, "Dogovor sa ljekarom"),
        (REASON_OTHER, "Drugo"),
    ]

    decision_type = models.CharField(max_length=24, choices=DECISION_TYPES)
    patient = models.ForeignKey(
        Pacijent,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="adaptive_decisions",
    )
    medicine = models.ForeignKey(
        Lijek,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="adaptive_decisions",
    )
    protocol = models.ForeignKey(
        TerapijskiProtokol,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="adaptive_decisions",
    )
    commission_cycle = models.ForeignKey(
        KomisijskiCiklus,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="adaptive_decisions",
    )
    system_proposal_json = models.JSONField(default=dict)
    final_decision_json = models.JSONField(default=dict)
    difference_json = models.JSONField(default=dict)
    override_reason = models.CharField(
        max_length=32,
        choices=OVERRIDE_REASONS,
        blank=True,
    )
    override_note = models.TextField(blank=True)
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="adaptive_decisions",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    algorithm_version = models.CharField(max_length=100)
    data_snapshot_hash = models.CharField(max_length=64, db_index=True)
    is_test_data = models.BooleanField(default=False, db_index=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [
            models.Index(
                fields=["decision_type", "created_at"],
                name="adapt_dec_type_date_idx",
            ),
            models.Index(
                fields=["medicine", "created_at"],
                name="adapt_dec_drug_date_idx",
            ),
        ]

    def save(self, *args, **kwargs):
        if self.pk and type(self).objects.filter(pk=self.pk).exists():
            raise ValidationError(
                "AdaptiveDecisionRecord je neizmjenjiv; kreirajte novi zapis."
            )
        super().save(*args, **kwargs)


class OralniTerapijskiRezim(models.Model):
    """Doktorski potvrđen režim oralne terapije sa istorijom važenja."""

    FAZA_INDUKCIJA = "INDUKCIJA"
    FAZA_ODRZAVANJE = "ODRZAVANJE"
    FAZA_PRILAGODJENO = "PRILAGODJENO"
    FAZE = [
        (FAZA_INDUKCIJA, "Indukcija"),
        (FAZA_ODRZAVANJE, "Održavanje"),
        (FAZA_PRILAGODJENO, "Prilagođeno"),
    ]

    pacijent = models.ForeignKey(
        Pacijent,
        on_delete=models.CASCADE,
        related_name="oralni_rezimi",
    )
    lijek = models.ForeignKey(
        Lijek,
        on_delete=models.PROTECT,
        related_name="oralni_rezimi",
    )
    standardni_rezim = models.ForeignKey(
        StandardniOralniRezim,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="potvrdjeni_rezimi",
        help_text="Standardni predložak iz kojeg je potvrđen ovaj snapshot.",
    )
    tableta_po_uzimanju = models.DecimalField(max_digits=6, decimal_places=2)
    uzimanja_dnevno = models.PositiveSmallIntegerField()
    datum_od = models.DateField(default=timezone.localdate)
    datum_do = models.DateField(null=True, blank=True)
    faza = models.CharField(max_length=20, choices=FAZE, default=FAZA_ODRZAVANJE)
    napomena_ljekara = models.TextField(blank=True)
    potvrdio = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="potvrdjeni_oralni_rezimi",
    )
    aktivan = models.BooleanField(default=True)
    kreirano = models.DateTimeField(auto_now_add=True)
    izmijenjeno = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-datum_od", "-id"]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(tableta_po_uzimanju__gt=0),
                name="oral_regimen_tablets_gt0",
            ),
            models.CheckConstraint(
                condition=models.Q(uzimanja_dnevno__gt=0),
                name="oral_regimen_intakes_gt0",
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(datum_do__isnull=True)
                    | models.Q(datum_do__gte=models.F("datum_od"))
                ),
                name="oral_regimen_dates_valid",
            ),
            models.UniqueConstraint(
                fields=["pacijent"],
                condition=models.Q(aktivan=True),
                name="uniq_active_oral_regimen_patient",
            ),
        ]
        indexes = [
            models.Index(
                fields=["pacijent", "aktivan", "datum_od"],
                name="oral_reg_patient_active_idx",
            ),
        ]

    @property
    def tableta_dnevno(self):
        return Decimal(str(self.tableta_po_uzimanju or 0)) * Decimal(
            str(self.uzimanja_dnevno or 0)
        )

    def __str__(self):
        return (
            f"{self.pacijent} - {self.lijek} - "
            f"{self.tableta_dnevno:g} tableta/dan"
        )


class IzdavanjeOralneTerapije(models.Model):
    """Fizičko izdavanje tableta, odvojeno od termina i primjene terapije."""

    STATUS_AKTIVNO = "AKTIVNO"
    STATUS_PONISTENO = "PONISTENO"
    STATUSI = [
        (STATUS_AKTIVNO, "Aktivno"),
        (STATUS_PONISTENO, "Poništeno"),
    ]

    pacijent = models.ForeignKey(
        Pacijent,
        on_delete=models.PROTECT,
        related_name="oralna_izdavanja",
    )
    lijek = models.ForeignKey(
        Lijek,
        on_delete=models.PROTECT,
        related_name="oralna_izdavanja",
    )
    rezim = models.ForeignKey(
        OralniTerapijskiRezim,
        on_delete=models.PROTECT,
        related_name="izdavanja",
    )
    komisija = models.ForeignKey(
        Komisija,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="oralna_izdavanja",
    )
    komisijska_stavka = models.ForeignKey(
        KomisijskaStavkaLijeka,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="oralna_izdavanja",
    )
    pacijent_zaduzenje = models.ForeignKey(
        PacijentZaduzenje,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="oralna_izdavanja",
    )
    kolicina_tableta = models.PositiveIntegerField(
        validators=[MinValueValidator(1)]
    )
    datum_izdavanja = models.DateField(default=timezone.localdate)
    pokrivenost_od = models.DateField()
    pokrivenost_do = models.DateField(null=True, blank=True)
    sljedeci_nepokriveni_datum = models.DateField()
    pokrivenost_dana = models.DecimalField(max_digits=10, decimal_places=4)
    jacina_mg_snapshot = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
    )
    tableta_po_uzimanju_snapshot = models.DecimalField(
        max_digits=6,
        decimal_places=2,
    )
    uzimanja_dnevno_snapshot = models.PositiveSmallIntegerField()
    tableta_dnevno_snapshot = models.DecimalField(max_digits=8, decimal_places=2)
    faza_snapshot = models.CharField(max_length=20, blank=True)
    broj_saglasnosti_snapshot = models.CharField(max_length=100, blank=True)
    odobreno_preostalo_prije = models.DecimalField(max_digits=10, decimal_places=2)
    odobreno_preostalo_poslije = models.DecimalField(max_digits=10, decimal_places=2)
    serija = models.CharField(max_length=100, blank=True)
    napomena = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUSI, default=STATUS_AKTIVNO)
    is_migration_snapshot = models.BooleanField(
        default=False,
        help_text=(
            "Historijsko izdavanje uneseno migracijom; nema retroaktivni "
            "efekat na trenutnu zalihu ni komisijsko pravo."
        ),
    )
    idempotency_key = models.UUIDField(default=uuid.uuid4, unique=True)
    korisnik_koji_je_izdao = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="izdata_oralna_terapija",
    )
    ponistio = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="ponistena_oralna_izdavanja",
    )
    ponisteno_at = models.DateTimeField(null=True, blank=True)
    razlog_ponistavanja = models.TextField(blank=True)
    kreirano = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Izdavanje oralne terapije"
        verbose_name_plural = "Izdavanja oralne terapije"
        ordering = ["-datum_izdavanja", "-id"]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(kolicina_tableta__gt=0),
                name="oral_issue_quantity_gt0",
            ),
            models.CheckConstraint(
                condition=models.Q(tableta_dnevno_snapshot__gt=0),
                name="oral_issue_daily_gt0",
            ),
            models.CheckConstraint(
                condition=models.Q(pokrivenost_dana__gt=0),
                name="oral_issue_coverage_gt0",
            ),
            models.CheckConstraint(
                condition=models.Q(
                    sljedeci_nepokriveni_datum__gte=models.F("pokrivenost_od")
                ),
                name="oral_issue_next_date_valid",
            ),
            models.CheckConstraint(
                condition=(
                    (
                        models.Q(komisija__isnull=False)
                        & models.Q(komisijska_stavka__isnull=True)
                    )
                    | (
                        models.Q(komisija__isnull=True)
                        & models.Q(komisijska_stavka__isnull=False)
                    )
                    | models.Q(
                        is_migration_snapshot=True,
                        komisija__isnull=True,
                        komisijska_stavka__isnull=True,
                    )
                ),
                name="oral_issue_one_approval_source",
            ),
        ]
        indexes = [
            models.Index(
                fields=["pacijent", "lijek", "status", "datum_izdavanja"],
                name="oral_issue_patient_drug_idx",
            ),
        ]

    @property
    def kolicina_je_djeljiva(self):
        dnevno = Decimal(str(self.tableta_dnevno_snapshot or 0))
        return dnevno > 0 and Decimal(self.kolicina_tableta) % dnevno == 0

    def __str__(self):
        return (
            f"{self.pacijent} - {self.lijek} - "
            f"{self.kolicina_tableta} tableta ({self.datum_izdavanja:%d/%m/%Y})"
        )


class OperationalOutcome(models.Model):
    medicine = models.ForeignKey(
        Lijek,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="adaptive_outcomes",
    )
    commission_cycle = models.ForeignKey(
        KomisijskiCiklus,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="adaptive_outcomes",
    )
    commission_date = models.DateField(null=True, blank=True)
    expected_delivery_date = models.DateField(null=True, blank=True)
    actual_delivery_date = models.DateField(null=True, blank=True)
    planned_lead_time_days = models.IntegerField(null=True, blank=True)
    actual_lead_time_days = models.IntegerField(null=True, blank=True)
    delivery_variance_days = models.IntegerField(null=True, blank=True)
    receipt_date = models.DateField(null=True, blank=True)
    first_scheduled_therapy_after_receipt = models.DateField(
        null=True,
        blank=True,
    )
    postponed_therapy_count = models.PositiveIntegerField(default=0)
    no_show_count = models.PositiveIntegerField(default=0)
    postponement_reasons_json = models.JSONField(default=list, blank=True)
    safety_reserve_consumed = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=0,
    )
    shortage_risk_observed = models.BooleanField(default=False)
    algorithm_version = models.CharField(max_length=100)
    is_test_data = models.BooleanField(default=False, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["medicine", "commission_cycle"],
                name="unique_adaptive_outcome_drug_cycle",
            ),
        ]
        ordering = ["-updated_at", "-id"]


class AdaptiveInsight(models.Model):
    CONFIDENCE_INSUFFICIENT = "INSUFFICIENT"
    CONFIDENCE_PRELIMINARY = "PRELIMINARY"
    CONFIDENCE_STABLE = "STABLE"
    CONFIDENCE_LEVELS = [
        (CONFIDENCE_INSUFFICIENT, "Nedovoljno podataka"),
        (CONFIDENCE_PRELIMINARY, "Preliminarni uvid"),
        (CONFIDENCE_STABLE, "Stabilniji uvid"),
    ]
    STATUS_NEW = "NEW"
    STATUS_REVIEWED = "REVIEWED"
    STATUS_DISMISSED = "DISMISSED"
    STATUSES = [
        (STATUS_NEW, "Novi"),
        (STATUS_REVIEWED, "Pregledan"),
        (STATUS_DISMISSED, "Odbačen"),
    ]

    insight_type = models.CharField(max_length=50)
    medicine = models.ForeignKey(
        Lijek,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="adaptive_insights",
    )
    title = models.CharField(max_length=200)
    explanation = models.TextField()
    sample_size = models.PositiveIntegerField(default=0)
    confidence_level = models.CharField(
        max_length=20,
        choices=CONFIDENCE_LEVELS,
        default=CONFIDENCE_INSUFFICIENT,
    )
    calculated_value = models.JSONField(default=dict, blank=True)
    current_configured_value = models.JSONField(default=dict, blank=True)
    status = models.CharField(
        max_length=20,
        choices=STATUSES,
        default=STATUS_NEW,
    )
    algorithm_version = models.CharField(max_length=100)
    generated_at = models.DateTimeField(auto_now_add=True)
    reviewed_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="reviewed_adaptive_insights",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)
    is_test_data = models.BooleanField(default=False, db_index=True)

    class Meta:
        ordering = ["-generated_at", "-id"]
        indexes = [
            models.Index(
                fields=["insight_type", "medicine", "generated_at"],
                name="adapt_ins_scope_date_idx",
            ),
        ]
