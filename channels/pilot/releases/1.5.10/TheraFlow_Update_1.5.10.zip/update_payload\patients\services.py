from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q, Sum
from django.utils import timezone

from .transaction_locking import select_for_update_self

from .individual_protocols import get_home_therapy_regimen, persistable_standard_step


def calculate_home_therapy_coverage(
    pacijent,
    *,
    doses_at_patient,
    reference_date,
    total_required=Decimal("0"),
    reserved_in_fridge=Decimal("0"),
):
    """Jedini izračun pokrivenosti i narednog izdavanja kućne terapije."""
    doses = max(Decimal("0"), Decimal(str(doses_at_patient or 0)))
    required = max(Decimal("0"), Decimal(str(total_required or 0)))
    reserved = max(Decimal("0"), Decimal(str(reserved_in_fridge or 0)))
    units_per_application, interval_weeks = get_home_therapy_regimen(pacijent)
    if units_per_application <= 0 or interval_weeks <= 0:
        return {
            "doses_at_patient": doses,
            "units_per_application": units_per_application,
            "interval_weeks": interval_weeks,
            "applications_covered": Decimal("0"),
            "coverage_weeks": 0,
            "covered_until": None,
            "next_dispensing": None,
            "doses_to_prepare": max(Decimal("0"), required - doses - reserved),
        }

    applications = doses / units_per_application
    coverage_weeks = int(applications * Decimal(str(interval_weeks)))
    covered_until = (
        reference_date + timedelta(weeks=coverage_weeks)
        if reference_date and doses > 0
        else None
    )
    next_dispensing = covered_until - timedelta(days=7) if covered_until else None
    if next_dispensing and next_dispensing <= timezone.localdate():
        next_dispensing = None
    immediate_shortage = max(Decimal("0"), units_per_application - doses)
    return {
        "doses_at_patient": doses,
        "units_per_application": units_per_application,
        "interval_weeks": interval_weeks,
        "applications_covered": applications,
        "coverage_weeks": coverage_weeks,
        "covered_until": covered_until,
        "next_dispensing": next_dispensing,
        # Ovo polje predstavlja trenutnu operativnu akciju izdavanja, a ne
        # buduću komisijsku potrebu. Komisijski deficit ostaje u centralnom
        # Commission Demand servisu.
        "doses_to_prepare": min(
            reserved,
            immediate_shortage,
        ) if reserved > 0 else immediate_shortage,
    }


@dataclass
class PatientTherapyStatusService:
    pacijent: object

    def calculate(self):
        from .inventory import inventory_position, inventory_position_for_patient
        from .models import (
            Lijek,
            MigracijskiSnapshotPacijenta,
            PacijentRezervacija,
            PacijentZaduzenje,
            Terapija,
            Trebovanje,
            Zaliha,
            ZalihaTransakcija,
        )

        pacijent = self.pacijent
        danas = timezone.now().date()
        lijek = pacijent.lijek
        equivalent_lijek_ids = lijek.equivalent_ids() if lijek else []
        plan_terapije = pacijent.aktivni_protokol()
        zadnja_terapija = pacijent.zadnja_terapija()
        if lijek:
            from .commission_service import valid_commissions_for_patient

            aktivne_komisije = valid_commissions_for_patient(pacijent)
        else:
            aktivne_komisije = []
        aktivna_komisija = aktivne_komisije[0] if aktivne_komisije else None
        trenutna_faza = pacijent.terapijska_faza()
        trenutni_korak = pacijent.trenutni_korak_terapije()

        patient_inventory = inventory_position_for_patient(pacijent)
        # Status pacijenta koristi samo fiziÄŤko stanje. Projekcija svih buduÄ‡ih
        # termina je grupni izvjeĹˇtaj i ne smije se ponavljati za svakog
        # pojedinaÄŤnog pacijenta.
        medicine_inventory = inventory_position(
            lijek,
            include_planned_need=False,
        ) if lijek else {
            "in_fridge": Decimal("0"),
            "reserved_in_fridge": Decimal("0"),
            "at_patient": Decimal("0"),
            "total_physical": Decimal("0"),
            "freely_available": Decimal("0"),
            "planned_therapy_need": Decimal("0"),
        }
        # Kompatibilni zbir aktivnih zaduženja ostaje dostupan postojećim
        # kliničkim prikazima. Kanonska fizička lokacija je zasebno izložena
        # kroz ``inventory_position.at_patient`` i za ambulantne lijekove je 0.
        prefetched_assignments = getattr(pacijent, "_workflow_assignments", None)
        aktivna_zaduzenja = (
            [
                item for item in prefetched_assignments
                if item.lijek_id in equivalent_lijek_ids
            ]
            if prefetched_assignments is not None
            else PacijentZaduzenje.objects.filter(
                pacijent=pacijent,
                lijek_id__in=equivalent_lijek_ids,
                aktivno=True,
                preostalo__gt=0,
            )
        )
        kod_pacijenta = sum(
            (Decimal(str(z.preostalo or 0)) for z in aktivna_zaduzenja),
            Decimal("0"),
        )

        preostalo_na_komisiji = sum(
            (Decimal(str(komisija.preostale_doze or 0)) for komisija in aktivne_komisije),
            Decimal("0"),
        )
        rezervisano_u_frizideru_za_pacijenta = patient_inventory["reserved_in_fridge"]
        odobreno_komisijom = sum(
            (Decimal(str(komisija.broj_odobrenih_doza or 0)) for komisija in aktivne_komisije),
            Decimal("0"),
        )
        from .commission_service import calculate_patient_commission_need

        potrebe_komisije = calculate_patient_commission_need(pacijent) if lijek else {
            "ukupno_potrebno": Decimal("0"),
            "trenutno_dostupno": kod_pacijenta,
            "vec_pokriveno": kod_pacijenta,
            "za_novu_komisiju": Decimal("0"),
            "kolicina_za_komisiju": Decimal("0"),
            "odobreno_preostalo": Decimal("0"),
            "planirani_koraci": [],
        }
        za_novu_komisiju = Decimal(str(potrebe_komisije.get("za_novu_komisiju") or 0))

        zadnje_kucno_izdavanje = None
        if lijek and pacijent.pk:
            prefetched_therapies = getattr(pacijent, "_workflow_therapies", None)
            if prefetched_therapies is not None:
                zadnje_kucno_izdavanje = next((
                    item for item in prefetched_therapies
                    if item.lijek_id in equivalent_lijek_ids
                    and item.tip_evidencije == Terapija.TIP_KUCNA_TERAPIJA
                ), None)
            else:
                zadnje_kucno_izdavanje = Terapija.objects.filter(
                    pacijent=pacijent,
                    lijek_id__in=equivalent_lijek_ids,
                    tip_evidencije=Terapija.TIP_KUCNA_TERAPIJA,
                ).exclude(workflow_status=Terapija.STATUS_PONISTENA).order_by("-datum", "-id").first()

        planirani_pocetak_terapije = pacijent.sljedeca_terapija()
        try:
            migracijski_datum_terapije = (
                pacijent.migracijski_snapshot.datum_posljednje_terapije
            )
        except MigracijskiSnapshotPacijenta.DoesNotExist:
            migracijski_datum_terapije = None
        terapijski_ciklus_pokrenut = bool(
            zadnja_terapija
            or planirani_pocetak_terapije
            or migracijski_datum_terapije
            or zadnje_kucno_izdavanje
        )

        # Način primjene je per-patient odluka. To je posebno važno za
        # ustekinumab: isti SC proizvod može još biti ambulantan kod jednog,
        # a kućni kod drugog pacijenta.
        kucna_terapija = pacijent.trenutni_korak_je_kucna_terapija()
        rezim_terapije = "KUCNA_TERAPIJA" if kucna_terapija else "AMBULANTNA"

        referentni_datum_kucne_terapije = (
            zadnje_kucno_izdavanje.datum
            if zadnje_kucno_izdavanje
            else zadnja_terapija.datum if zadnja_terapija else danas
        )
        kucne_doze = kod_pacijenta
        if kucna_terapija and kucne_doze <= 0 and zadnje_kucno_izdavanje:
            kucne_doze = Decimal(str(zadnje_kucno_izdavanje.kolicina or 0))
        home_coverage = calculate_home_therapy_coverage(
            pacijent,
            doses_at_patient=kucne_doze if kucna_terapija else Decimal("0"),
            reference_date=referentni_datum_kucne_terapije,
            total_required=potrebe_komisije.get("ukupno_potrebno", 0),
            reserved_in_fridge=rezervisano_u_frizideru_za_pacijenta,
        )
        central_home_coverage = None
        if kucna_terapija:
            from .commission_demand import (
                SOURCE_AT_PATIENT,
                calculate_patient_demand,
            )

            central_demand = calculate_patient_demand(
                pacijent,
                today=danas,
            )
            covered_at_home_dates = []
            first_not_at_home = None
            for detail in central_demand.detalji if central_demand else ():
                covered_at_home = sum(
                    (
                        Decimal(str(allocation.quantity or 0))
                        for allocation in detail.izvori_pokrica
                        if allocation.source == SOURCE_AT_PATIENT
                    ),
                    Decimal("0"),
                )
                if covered_at_home >= Decimal(str(detail.potrebna_kolicina or 0)):
                    covered_at_home_dates.append(detail.datum_terapije)
                elif first_not_at_home is None:
                    first_not_at_home = detail.datum_terapije
            dispensing_candidate = (
                first_not_at_home - timedelta(days=7)
                if first_not_at_home
                else None
            )
            next_dispensing = (
                dispensing_candidate
                if dispensing_candidate and dispensing_candidate > danas
                else None
            )
            central_home_coverage = {
                "next_dispensing": (
                    next_dispensing
                    if first_not_at_home
                    else home_coverage["next_dispensing"]
                ),
                "doses_to_prepare": (
                    Decimal("0")
                    if covered_at_home_dates
                    else home_coverage["doses_to_prepare"]
                ),
            }
            home_coverage.update(central_home_coverage)
            # Operativni status, profil i komisijski prikazi moraju završiti na
            # istom kanonskom fizičkom presjeku. Time stara demand grana ne
            # može ponovo vratiti subotnji datum izdavanja.
            from .home_therapy import calculate_home_therapy_projection

            canonical_home = calculate_home_therapy_projection(
                pacijent,
                today=danas,
                reference_date=referentni_datum_kucne_terapije,
            )
            # Stari zapisi kućnog izdavanja mogu postojati samo kao Terapija,
            # bez PacijentZaduzenje reda. Ne prepisuj njihov važeći fallback
            # nulom iz ledgera. Za novi, još nepokrenuti ciklus fizička količina
            # se prikazuje, ali sama po sebi ne izmišlja početni datum terapije.
            if canonical_home.patient_quantity > 0:
                has_therapy_anchor = bool(
                    zadnja_terapija
                    or planirani_pocetak_terapije
                    or migracijski_datum_terapije
                    or zadnje_kucno_izdavanje
                )
                home_coverage.update({
                    "doses_at_patient": canonical_home.patient_quantity,
                    "units_per_application": canonical_home.units_per_application,
                    "interval_weeks": canonical_home.interval_weeks,
                    "applications_covered": (
                        canonical_home.patient_quantity
                        / canonical_home.units_per_application
                        if canonical_home.units_per_application > 0
                        else Decimal("0")
                    ),
                    "coverage_weeks": (
                        int(
                            canonical_home.patient_quantity
                            / canonical_home.units_per_application
                        ) * canonical_home.interval_weeks
                        if canonical_home.units_per_application > 0
                        else 0
                    ),
                    "covered_until": (
                        canonical_home.physical_covered_until
                        if has_therapy_anchor else None
                    ),
                    "next_dispensing": (
                        canonical_home.next_dispensing
                        if has_therapy_anchor else None
                    ),
                })
        doza_po_aplikaciji_kucne = home_coverage["units_per_application"]
        broj_kucnih_aplikacija = home_coverage["applications_covered"]
        interval_kucne_terapije = home_coverage["interval_weeks"]
        dovoljno_za_sedmica = home_coverage["coverage_weeks"] if kucna_terapija else 0
        procijenjeno_do = home_coverage["covered_until"] if kucna_terapija else None

        zaliha_ustanove = medicine_inventory["in_fridge"]

        zaprimljeno_trebovanje = None
        if lijek and pacijent.pk:
            prefetched_requests = getattr(pacijent, "_workflow_requests", None)
            if prefetched_requests is not None:
                zaprimljeno_trebovanje = next((
                    item for item in prefetched_requests
                    if item.lijek_id in equivalent_lijek_ids
                    and item.status == "ZAPRIMLJENO"
                ), None)
            else:
                zaprimljeno_trebovanje = Trebovanje.objects.filter(
                    pacijent=pacijent,
                    lijek_id__in=equivalent_lijek_ids,
                    status="ZAPRIMLJENO",
                ).order_by("-datum_kreiranja", "-id").first()
        komisija_ids = [komisija.id for komisija in aktivne_komisije]
        prefetched_receipts = getattr(pacijent, "_workflow_receipts", None)
        if prefetched_receipts is not None:
            ima_povezano_zaprimanje = any(
                item.lijek_id in equivalent_lijek_ids
                and (item.pacijent_id == pacijent.pk or item.komisija_id in komisija_ids)
                for item in prefetched_receipts
            )
        else:
            ima_povezano_zaprimanje = bool(
                lijek
                and ZalihaTransakcija.objects.filter(
                    lijek_id__in=equivalent_lijek_ids,
                    tip=ZalihaTransakcija.TIP_ZAPRIMANJE,
                ).filter(
                    Q(pacijent=pacijent) | Q(komisija_id__in=komisija_ids)
                ).exists()
            )
        komisija_je_zaprimljena = bool(
            kod_pacijenta > 0
            or rezervisano_u_frizideru_za_pacijenta > 0
            or zaprimljeno_trebovanje
            or ima_povezano_zaprimanje
        )
        zaprimljene_doze_za_pokrivenost = Decimal("0")
        if (
            kucna_terapija
            and kod_pacijenta <= 0
            and rezervisano_u_frizideru_za_pacijenta <= 0
            and komisija_je_zaprimljena
            and zaliha_ustanove > 0
        ):
            prijavljeno_zaprimljeno = Decimal(str(
                getattr(zaprimljeno_trebovanje, "broj_doza", 0) or preostalo_na_komisiji
            ))
            zaprimljene_doze_za_pokrivenost = min(
                zaliha_ustanove,
                preostalo_na_komisiji,
                prijavljeno_zaprimljeno,
            )
        sljedece_izdavanje = home_coverage["next_dispensing"] if kucna_terapija else None
        potrebno_za_naredno_izdavanje = za_novu_komisiju
        treba_izdati_kucne_terapije = Decimal("0")
        if kucna_terapija:
            potrebno_za_naredno_izdavanje = home_coverage["doses_to_prepare"]
            treba_izdati_kucne_terapije = min(
                rezervisano_u_frizideru_za_pacijenta,
                preostalo_na_komisiji,
            )

        sljedeca_terapija = None if kucna_terapija else planirani_pocetak_terapije
        if kucna_terapija and procijenjeno_do:
            pokriven_do = procijenjeno_do
            pokriven_do_izvor = "Računato iz kućnih doza"
        elif kucna_terapija and rezervisano_u_frizideru_za_pacijenta > 0:
            pokriven_do, _ = pacijent.izracunaj_pokriven_do(
                rezervisano_u_frizideru_za_pacijenta,
                fallback_date=aktivna_komisija.datum_odobrenja if aktivna_komisija else danas,
            )
            pokriven_do_izvor = "Računato iz zaprimljenih doza rezervisanih za pacijenta"
        elif kucna_terapija and zaprimljene_doze_za_pokrivenost > 0:
            pokriven_do, _ = pacijent.izracunaj_pokriven_do(
                zaprimljene_doze_za_pokrivenost,
                fallback_date=aktivna_komisija.datum_odobrenja if aktivna_komisija else danas,
            )
            pokriven_do_izvor = "Računato iz zaprimljenih fizičkih doza za pacijentovo trebovanje"
        elif zadnje_kucno_izdavanje:
            evidentirani_interval = (
                zadnje_kucno_izdavanje.interval_sedmica
                or pacijent.sedmica_do_sljedece_aplikacije()
                or pacijent.interval_sedmica
                or 8
            )
            interval = pacijent.efektivni_interval_sedmica(evidentirani_interval)
            pokriven_do = zadnje_kucno_izdavanje.datum + timedelta(
                weeks=int(Decimal(str(zadnje_kucno_izdavanje.kolicina or 0)) * Decimal(str(interval)))
            )
            pokriven_do_izvor = "Računato iz izdate kućne terapije"
        elif not kucna_terapija and preostalo_na_komisiji > 0:
            pokriven_do, _ = pacijent.izracunaj_pokriven_do(preostalo_na_komisiji)
            pokriven_do_izvor = "Racunato iz preostalih komisijskih doza"
        else:
            pokriven_do, pokriven_do_izvor = pacijent.izracunaj_pokriven_do(kod_pacijenta)

        if kucna_terapija and pokriven_do and pokriven_do <= danas:
            sljedece_izdavanje = None

        if not terapijski_ciklus_pokrenut:
            pokriven_do = None
            pokriven_do_izvor = "Čeka zakazivanje prve terapije"
            procijenjeno_do = None
            dovoljno_za_sedmica = 0
            sljedece_izdavanje = None
            potrebno_za_naredno_izdavanje = Decimal("0")
            treba_izdati_kucne_terapije = Decimal("0")
            za_novu_komisiju = Decimal("0")
        posljednja_dostupna_terapija = pokriven_do

        upozorenja = []
        prefetched_requests = getattr(pacijent, "_workflow_requests", None)
        if prefetched_requests is not None:
            aktivno_trebovanje = next((
                item for item in prefetched_requests
                if item.lijek_id in equivalent_lijek_ids
                and item.status in {"U_PRIPREMI", "PREDATO", "ODOBRENO"}
            ), None)
        else:
            aktivno_trebovanje = Trebovanje.objects.filter(
                pacijent=pacijent,
                lijek_id__in=equivalent_lijek_ids,
                status__in=["U_PRIPREMI", "PREDATO", "ODOBRENO"],
            ).order_by("-datum_kreiranja", "-id").first()

        status = "Uredno"
        status_razlog = "Terapija, komisija i fizičke doze su usklađene."
        status_css = "status-uredno"
        status_kucne_terapije = "Uredno"
        sekundarni_status = ""
        administrativni_status = ""
        administrativni_status_css = ""

        if not pacijent.aktivan:
            status = "Neaktivan"
            status_razlog = "Pacijent nije aktivan."
            status_css = "status-neutral"
        elif not lijek:
            status = "Bez lijeka"
            status_razlog = "Pacijent nema dodijeljen lijek."
            status_css = "status-neutral"
            upozorenja.append(status_razlog)
        elif not terapijski_ciklus_pokrenut and not (
            kucna_terapija
            and (
                aktivna_komisija
                or rezervisano_u_frizideru_za_pacijenta > 0
                or kucne_doze > 0
            )
        ):
            status = "Čeka zakazivanje"
            status_kucne_terapije = status
            status_razlog = "Prva terapija još nije zakazana."
            status_css = "status-neutral"
        elif aktivno_trebovanje and aktivno_trebovanje.status == "ODOBRENO" and not aktivno_trebovanje.zaduzenje_kreirano:
            status = "Potrebno zaprimanje pošiljke"
            status_razlog = "Trebovanje je odobreno, ali doze još nisu zaprimljene i zadužene."
            status_css = "status-komisija"
            upozorenja.append(status_razlog)
        elif kucna_terapija:
            status = "Spreman za kućnu terapiju"
            status_razlog = "Trenutni korak protokola je kućna terapija; ne zakazuje se ambulantni termin."
            status_css = "status-kucna-terapija"
            upozorenja.append(status_razlog)
        elif sljedeca_terapija and sljedeca_terapija < danas:
            status = "Terapija kasni"
            status_razlog = f"Sljedeća terapija je bila planirana {sljedeca_terapija:%d/%m/%Y}."
            status_css = "status-hitno"
            upozorenja.append(status_razlog)
        elif not aktivna_komisija:
            fizicki_dostupno_bez_odobrenja = (
                Decimal(str(rezervisano_u_frizideru_za_pacijenta or 0))
                + Decimal(str(kod_pacijenta or 0))
            )
            if fizicki_dostupno_bez_odobrenja > 0 and za_novu_komisiju <= 0:
                status = "Fizički pokriven"
                status_razlog = (
                    f"Pacijent ima {fizicki_dostupno_bez_odobrenja:g} fizički "
                    "raspoloživih doza bez vlastitog komisijskog odobrenja."
                )
                status_css = (
                    "status-kucna-terapija"
                    if getattr(lijek, "kucna_terapija", False)
                    else "status-uredno"
                )
                if rezervisano_u_frizideru_za_pacijenta > 0:
                    sekundarni_status = (
                        f"{rezervisano_u_frizideru_za_pacijenta:g} doza "
                        "rezervisano u frižideru"
                    )
                administrativni_status = "Bez vlastitog komisijskog odobrenja"
                administrativni_status_css = "status-komisija"
            elif kod_pacijenta <= 0:
                status = "Nema odobrenih doza"
                status_razlog = "Nema aktivne komisije ni fizičkih doza kod pacijenta."
                status_css = "status-hitno"
            elif za_novu_komisiju > 0:
                status = "Potrebna nova komisija"
                status_razlog = "Dostupne fizičke doze ne pokrivaju planirani period."
                status_css = "status-hitno"
            upozorenja.append(status_razlog) if status != "Uredno" else None
        elif preostalo_na_komisiji <= 0:
            status = "Nema odobrenih doza"
            status_razlog = "Aktivna komisija nema preostalih odobrenih doza."
            status_css = "status-hitno"
            upozorenja.append(status_razlog)
        elif kucna_terapija and kod_pacijenta <= 0:
            status = "Nema fizičkih doza kod pacijenta"
            status_razlog = "Komisija postoji, ali pacijentu nisu zadužene fizičke doze."
            status_css = "status-hitno"
            upozorenja.append(status_razlog)
        elif za_novu_komisiju > 0 and (kucna_terapija or preostalo_na_komisiji <= 0):
            status = "Potrebna nova komisija"
            status_razlog = "Dostupne i odobrene doze ne pokrivaju planirani period."
            status_css = "status-hitno"
            upozorenja.append(status_razlog)
        elif not kucna_terapija and preostalo_na_komisiji > 0:
            status = "Komisijski pokriven"
            status_razlog = f"{preostalo_na_komisiji:g} komisijske doze preostale. Lijek se primjenjuje u ambulanti."
            status_css = "status-uredno"
        if (
            kucna_terapija
            and pacijent.aktivan
            and lijek
            and (
                terapijski_ciklus_pokrenut
                or aktivna_komisija
                or rezervisano_u_frizideru_za_pacijenta > 0
                or kucne_doze > 0
            )
        ):
            status_css = "status-kucna-terapija"
            fizicki_dostupno = (
                Decimal(str(rezervisano_u_frizideru_za_pacijenta or 0))
                + Decimal(str(kucne_doze or 0))
            )
            if (
                not aktivna_komisija
                and fizicki_dostupno > 0
                and kucne_doze <= 0
                and za_novu_komisiju <= 0
            ):
                status = (
                    f"Fizički pokriven do {pokriven_do:%d.%m.%Y.}"
                    if pokriven_do else "Fizički pokriven"
                )
                status_kucne_terapije = status
                status_razlog = (
                    f"Pacijent ima {fizicki_dostupno:g} fizički raspoloživih doza "
                    "bez prenosa komisijskog prava."
                )
                if rezervisano_u_frizideru_za_pacijenta > 0:
                    sekundarni_status = (
                        f"{rezervisano_u_frizideru_za_pacijenta:g} doza "
                        "rezervisano u frižideru"
                    )
                administrativni_status = "Bez vlastitog komisijskog odobrenja"
                administrativni_status_css = "status-komisija"
            elif kucne_doze > 0:
                status = "Kućna terapija aktivna"
                status_kucne_terapije = status
                if procijenjeno_do:
                    status_razlog = (
                        f"Pacijent trenutno ima {kucne_doze:g} kucnih doza, "
                        f"dovoljno za {dovoljno_za_sedmica} sedmica."
                    )
                else:
                    status_razlog = (
                        f"Pacijent trenutno ima {kucne_doze:g} kucnih doza. "
                        "Datum prve terapije još nije zakazan."
                    )
            elif not aktivna_komisija or preostalo_na_komisiji <= 0:
                status = "Potrebna nova komisija"
                status_kucne_terapije = status
                status_razlog = "Nema vazece komisije sa preostalim odobrenim dozama."
                status_css = "status-hitno"
            elif rezervisano_u_frizideru_za_pacijenta > 0:
                status = "Komisijski pokriven – čeka izdavanje"
                status_kucne_terapije = status
                status_razlog = (
                    f"U ambulanti je dostupno {rezervisano_u_frizideru_za_pacijenta:g} "
                    "doza za ovog pacijenta. Potrebno je izdati kucnu terapiju."
                )
            elif preostalo_na_komisiji > 0 and not komisija_je_zaprimljena:
                status = "Komisijski pokriven - ceka zaprimanje"
                status_kucne_terapije = status
                status_razlog = (
                    f"Odobreno je {preostalo_na_komisiji:g} doza, "
                    "ali lijek jos nije zaprimljen u ambulantu."
                )
                status_css = "status-komisija"
            elif preostalo_na_komisiji > 0:
                status = "Komisijski pokriven"
                status_kucne_terapije = status
                status_razlog = (
                    f"Odobreno je {preostalo_na_komisiji:g} doza i lijek je zaprimljen; "
                    "potrebno je povezati raspoložive doze sa pacijentom."
                )
            elif potrebno_za_naredno_izdavanje > 0:
                status = "Komisija potrebna"
                status_kucne_terapije = status
                status_razlog = "Za naredno izdavanje treba pripremiti ili obnoviti komisijske doze."
                status_css = "status-komisija"

        aktivna_pauza = pacijent.aktivna_pauza_terapije()
        if aktivna_pauza:
            status = "Privremeno pauzirana"
            status_kucne_terapije = status
            status_razlog = aktivna_pauza.razlog
            status_css = "status-neutral"
            za_novu_komisiju = Decimal("0")

        if lijek and zaliha_ustanove <= 0:
            upozorenja.append("Ustanova trenutno nema zalihu ovog lijeka.")

        if zadnje_kucno_izdavanje:
            pokriven_do_izvor = "Računato iz izdate kućne terapije"

        return {
            "lijek": lijek,
            "plan_terapije": plan_terapije,
            "trenutna_faza": trenutna_faza,
            "zadnja_terapija": zadnja_terapija,
            "sljedeca_terapija": sljedeca_terapija,
            "kod_pacijenta": kod_pacijenta,
            "aktivna_komisija": aktivna_komisija,
            "aktivne_komisije": aktivne_komisije,
            "preostalo_na_komisiji": preostalo_na_komisiji,
            "rezervisano_u_frizideru_za_pacijenta": rezervisano_u_frizideru_za_pacijenta,
            "odobreno_komisijom": odobreno_komisijom,
            "pokriven_do": pokriven_do,
            "pokriven_do_izvor": pokriven_do_izvor,
            "posljednja_dostupna_terapija": posljednja_dostupna_terapija,
            "za_novu_komisiju": za_novu_komisiju,
            "status": status,
            "status_razlog": status_razlog,
            "status_css": status_css,
            "sekundarni_status": sekundarni_status,
            "administrativni_status": administrativni_status,
            "administrativni_status_css": administrativni_status_css,
            "upozorenja": upozorenja,
            "potrebe_komisije": potrebe_komisije,
            "komisija_je_zaprimljena": komisija_je_zaprimljena,
            "ceka_zaprimanje": bool(
                kucna_terapija
                and preostalo_na_komisiji > 0
                and not komisija_je_zaprimljena
            ),
            "zaprimljene_doze_za_pokrivenost": zaprimljene_doze_za_pokrivenost,
            "zaliha_ustanove": zaliha_ustanove,
            "inventory_position": medicine_inventory,
            "kucna_terapija": kucna_terapija,
            "rezim_terapije": rezim_terapije,
            "režim_terapije": rezim_terapije,
            "kucne_doze": kucne_doze,
            "dovoljno_za_sedmica": dovoljno_za_sedmica,
            "procijenjeno_do": procijenjeno_do,
            "sljedece_izdavanje": sljedece_izdavanje,
            "potrebno_za_naredno_izdavanje": potrebno_za_naredno_izdavanje,
            "treba_izdati_kucne_terapije": treba_izdati_kucne_terapije,
            "status_kucne_terapije": status_kucne_terapije,
            "interval_kucne_terapije": interval_kucne_terapije,
            "referentni_datum_kucne_terapije": referentni_datum_kucne_terapije,
            "zadnje_kucno_izdavanje": zadnje_kucno_izdavanje,
            "aktivna_pauza": aktivna_pauza,
            "terapijski_ciklus_pokrenut": terapijski_ciklus_pokrenut,
        }


def izracunaj_status_pacijenta(pacijent):
    from .request_cache import get_or_set

    if not pacijent or not getattr(pacijent, "pk", None):
        return PatientTherapyStatusService(pacijent).calculate()
    return get_or_set(
        "patient_therapy_status",
        (pacijent.pk, pacijent.lijek_id),
        lambda: PatientTherapyStatusService(pacijent).calculate(),
    )


def default_therapy_dose(pacijent):
    return Decimal(str(pacijent.doza_po_aplikaciji() or 0))


def recalculate_future_appointments(pacijent, *, from_date=None):
    """Preračunaj samo buduće zakazane termine; historiju nikada ne mijenja."""
    from .models import Pacijent, Termin
    from .utils import upisi_log

    # Novi upit izbjegava reverse OneToOne cache iz requesta u kojem je upravo
    # kreiran individualni protokol.
    pacijent = Pacijent.objects.select_related(
        "lijek", "terapijski_protokol", "individualni_protokol"
    ).get(pk=pacijent.pk)

    if pacijent.na_aktivnoj_pauzi():
        return 0
    queryset = Termin.objects.filter(pacijent=pacijent, status="ZAKAZAN")
    if from_date:
        queryset = queryset.filter(datum__gte=from_date)
    future = list(queryset.order_by("datum", "vrijeme", "id"))
    if not future:
        return 0

    last = pacijent.zadnja_terapija()
    reference = last.datum if last else future[0].datum
    application_number = pacijent.broj_dosadasnjih_aplikacija() + 1
    changed = []
    for index, termin in enumerate(future):
        if index == 0 and not last:
            calculated = reference
        else:
            calculated = pacijent._datum_sljedeceg_koraka_iz_referentnog(
                application_number,
                reference,
            ) or reference + timedelta(
                weeks=pacijent.sedmica_do_sljedece_aplikacije(
                    nakon_nove_aplikacije=True
                )
            )
        from .scheduling import adjust_to_allowed_therapy_date

        scheduled = adjust_to_allowed_therapy_date(
            calculated,
            lijek=pacijent.lijek,
            protokol=pacijent.aktivni_protokol(),
        )
        calculated = scheduled.datum
        if termin.datum != calculated:
            termin.datum = calculated
            changed.append(termin)
            if scheduled.prilagodjen:
                upisi_log(
                    None,
                    "Automatski prilagođen datum terapije",
                    pacijent=pacijent,
                    objekat=termin,
                    opis=(
                        f"{scheduled.razlog} Novi datum: "
                        f"{scheduled.datum:%d/%m/%Y}"
                    ),
                )
        reference = calculated
        application_number += 1
    if changed:
        Termin.objects.bulk_update(changed, ["datum"])
    return len(changed)


def confirm_therapy_arrival(
    *,
    termin,
    primljene_doze,
    interval_sedmica,
    korisnik=None,
    override_zaduzenja=False,
    faza_terapije=None,
    doza_mg=None,
    sljedeci_datum=None,
    scheduling_validation_today=None,
):
    from .models import (
        AktivnostLog,
        Komisija,
        PacijentZaduzenje,
        Terapija,
        Termin,
        Zaliha,
        ZalihaTransakcija,
    )
    from .utils import upisi_log

    primljene_doze = Decimal(str(primljene_doze or 0))
    if primljene_doze <= 0:
        raise ValueError("Broj primljenih doza mora biti veci od nule.")

    with transaction.atomic():
        termin = select_for_update_self(
            Termin.objects.select_related("pacijent", "lijek")
        ).get(pk=termin.pk)
        if termin.lijek.oralna_terapija:
            raise ValueError(
                "Oralna terapija se ne potvrđuje kao dolazak na terapiju. "
                "Koristite izdavanje oralne terapije."
            )
        if termin.status == "OBAVLJEN":
            raise ValueError("Dolazak je vec potvrden za ovaj termin. Zaliha nije ponovo skinuta.")

        pacijent = termin.pacijent
        if pacijent.na_aktivnoj_pauzi():
            raise ValueError("Pacijent je na privremenoj pauzi. Nova terapija se ne može evidentirati.")
        if termin.status != Termin.STATUS_PLANIRANA:
            raise ValueError("Terapiju nije moguće potvrditi iz trenutnog statusa termina.")
        from .phased_protocols import (
            advance_protocol_after_therapy,
            commission_authorization_medicine_ids,
            consume_phase_reservations,
            current_phase_details,
            ensure_phase_reservation,
            phased_protocol_for_patient,
            therapy_event_phase_label,
        )

        phase_state = phased_protocol_for_patient(pacijent, lock=True)
        phase_details = current_phase_details(phase_state) if phase_state else None
        if phase_state:
            if phase_state.sc_je_kucna_terapija:
                raise ValueError(
                    "Pacijent je na kućnoj SC terapiji. Evidentirajte izdavanje "
                    "lijeka, ne ambulantni dolazak."
                )
            lijek = termin.lijek
            if lijek.pk != phase_details["medicine"].pk:
                raise ValueError(
                    "Termin ne koristi prezentaciju trenutne faze protokola."
                )
            required_phase_units = Decimal(str(phase_details["units"] or 0))
            if required_phase_units <= 0:
                raise ValueError(
                    "Količina za trenutnu fazu protokola nije evidentirana. "
                    "Prvo unesite odobrenu količinu lijeka."
                )
            if primljene_doze != required_phase_units:
                raise ValueError(
                    "Primljena količina ne odgovara potvrđenoj fazi protokola."
                )
            korak_terapije = None
            ambulantni_korak = True
            # ``Terapija.faza_terapije`` je VARCHAR(20) machine-status polje.
            # Puni korisnički naziv ostaje presentation/snapshot podatak.
            faza_terapije = phase_details["phase"]
            doza_mg = phase_details["dose_mg"]
        else:
            lijek = pacijent.lijek
            korak_terapije = pacijent.trenutni_korak_terapije()
            ambulantni_korak = pacijent.trenutni_korak_je_ambulanta()

        zaliha = Zaliha.objects.select_for_update().filter(lijek=lijek).first()
        if ambulantni_korak and not zaliha:
            raise ValueError(f"Zaliha za {lijek.naziv} nije evidentirana.")

        stara_zaliha = Decimal(str(zaliha.u_frizideru or 0)) if zaliha else Decimal("0")
        if ambulantni_korak and stara_zaliha < primljene_doze:
            raise ValueError(
                f"Nema dovoljno globalne zalihe za {lijek.naziv}. "
                f"Dostupno {stara_zaliha}, potrebno {primljene_doze}."
            )

        if phase_state:
            from .medication_groups import strict_equivalent_medicine_ids

            current_presentation_ids = set(strict_equivalent_medicine_ids(lijek))
            authorization_ids = set(
                commission_authorization_medicine_ids(phase_state, lijek)
            )
            commission_base = (
                Komisija.objects.select_for_update()
                .filter(
                    pacijent=pacijent,
                    lijek_id__in=authorization_ids,
                    status__in=Komisija.VAZECI_STATUSI,
                    preostale_doze__gt=0,
                )
            )
            # Prvo troši pravo tačne trenutne prezentacije. Pravo sa IV SKU-a je
            # kontrolisani fallback samo za aktivni ustekinumab SC fazni korak.
            exact_commissions = list(
                commission_base.filter(
                    lijek_id__in=current_presentation_ids,
                ).order_by("datum_odobrenja", "id")
            )
            bridged_commissions = list(
                commission_base.exclude(
                    lijek_id__in=current_presentation_ids,
                ).order_by("datum_odobrenja", "id")
            )
            komisije = exact_commissions + bridged_commissions
        else:
            current_presentation_ids = set()
            komisije = list(
                pacijent.vazece_komisije(lijek=lijek).select_for_update()
            )
        if ambulantni_korak:
            if not komisije:
                raise ValueError("Pacijent nema aktivnu komisiju za ovu terapiju.")
            ukupno_na_komisijama = sum(
                (Decimal(str(komisija.preostale_doze or 0)) for komisija in komisije),
                Decimal("0"),
            )
            if ukupno_na_komisijama < primljene_doze:
                raise ValueError(
                    f"Nema dovoljno preostalih doza na komisiji. "
                    f"Preostalo {ukupno_na_komisijama}, potrebno {primljene_doze}."
                )
        zaduzenja = []
        doze_kod_pacijenta = Decimal("0")
        if not ambulantni_korak:
            zaduzenje_ids = list(
                PacijentZaduzenje.objects.filter(
                    pacijent=pacijent,
                    lijek=lijek,
                    aktivno=True,
                    preostalo__gt=0,
                ).order_by(
                    "komisija__datum_odobrenja",
                    "komisija_id",
                    "datum_zaduzenja",
                    "id",
                ).values_list("id", flat=True)
            )
            zaduzenja_by_id = {
                zaduzenje.id: zaduzenje
                for zaduzenje in PacijentZaduzenje.objects.select_for_update().filter(id__in=zaduzenje_ids)
            }
            zaduzenja = [zaduzenja_by_id[zaduzenje_id] for zaduzenje_id in zaduzenje_ids]
            doze_kod_pacijenta = sum(
                (Decimal(str(z.preostalo or 0)) for z in zaduzenja),
                Decimal("0"),
            )
            if doze_kod_pacijenta < primljene_doze and not override_zaduzenja:
                raise ValueError(
                    f"Pacijent nema dovoljno kucnih doza. Kod pacijenta je "
                    f"{doze_kod_pacijenta}, a terapija trazi {primljene_doze}."
                )

        phase_reservation_changes = []
        ambulatory_reservation_changes = []
        if phase_state:
            try:
                phase_reservation_changes = consume_phase_reservations(
                    patient=pacijent,
                    medicine=lijek,
                    quantity=primljene_doze,
                )
            except ValidationError as exc:
                raise ValueError(exc.messages[0]) from exc
        elif ambulantni_korak:
            from .inventory import consume_patient_physical_reservation

            allocation_consumption = consume_patient_physical_reservation(
                pacijent=pacijent,
                lijek=lijek,
                quantity=primljene_doze,
                termin=termin,
            )
            ambulatory_reservation_changes = allocation_consumption["changes"]

        terapija = Terapija.objects.create(
            pacijent=pacijent,
            lijek=lijek,
            terapijski_korak=persistable_standard_step(korak_terapije),
            datum=termin.datum,
            kolicina=primljene_doze,
            doza_mg=(doza_mg if doza_mg is not None else korak_terapije.doza_mg if korak_terapije else None),
            faza_terapije=faza_terapije or pacijent.terapijska_faza(),
            interval_sedmica=(
                phase_details["interval_weeks"] or 8
                if phase_state else interval_sedmica
            ),
            finansijski_status=Terapija.FINANSIJSKI_CEKA,
            evidentirao=(
                korisnik
                if getattr(korisnik, "is_authenticated", False)
                else None
            ),
        )

        preostalo_za_skinuti = primljene_doze
        komisijske_promjene = []
        zaduzenja_promjene = []
        if ambulantni_korak:
            for komisija in komisije:
                if preostalo_za_skinuti <= 0:
                    break
                komisija_pre = Decimal(str(komisija.preostale_doze or 0))
                skidanje = min(komisija_pre, preostalo_za_skinuti)
                komisijske_promjene.append({
                    "komisija_id": komisija.id,
                    "lijek_id": komisija.lijek_id,
                    "kolicina": str(skidanje),
                    "pravo_faznog_prelaza": bool(
                        phase_state
                        and komisija.lijek_id not in current_presentation_ids
                    ),
                })
                komisija.preostale_doze = komisija_pre - skidanje
                preostalo_za_skinuti -= skidanje
                if komisija.preostale_doze <= 0:
                    komisija.preostale_doze = Decimal("0")
                    komisija.status = "POTROSENA"
                komisija.save(update_fields=["preostale_doze", "status"])
        else:
            for zaduzenje in zaduzenja:
                if preostalo_za_skinuti <= 0:
                    break
                zaduzenje_pre = Decimal(str(zaduzenje.preostalo or 0))
                skidanje = min(zaduzenje_pre, preostalo_za_skinuti)
                zaduzenja_promjene.append({"zaduzenje_id": zaduzenje.id, "kolicina": str(skidanje)})
                zaduzenje.preostalo = zaduzenje_pre - skidanje
                preostalo_za_skinuti -= skidanje
                if zaduzenje.preostalo <= 0:
                    zaduzenje.preostalo = Decimal("0")
                    zaduzenje.aktivno = False
                zaduzenje.save(update_fields=["preostalo", "aktivno"])

        if ambulantni_korak:
            zaliha.u_frizideru = stara_zaliha - primljene_doze
            if zaliha.u_frizideru < 0:
                raise ValueError("Zaliha ne moze biti negativna.")
            zaliha.save(update_fields=["u_frizideru", "ukupno"])
            ZalihaTransakcija.objects.create(
                lijek=lijek,
                tip=ZalihaTransakcija.TIP_AMBULANTNA_POTROSNJA,
                kolicina=primljene_doze,
                datum=termin.datum,
                pacijent=pacijent,
                referenca_tip="Terapija",
                referenca_id=terapija.id,
                korisnik=korisnik if getattr(korisnik, "is_authenticated", False) else None,
                napomena=f"{lijek.naziv}: ambulantno potroseno {primljene_doze} doza.",
            )
        elif zaliha:
            zaliha.kod_pacijenata = max(
                Decimal("0"),
                Decimal(str(zaliha.kod_pacijenata or 0)) - primljene_doze,
            )
            zaliha.save(update_fields=["kod_pacijenata", "ukupno"])
        nova_zaliha = Decimal(str(zaliha.u_frizideru or 0)) if zaliha else Decimal("0")

        prethodni_status_termina = termin.status
        termin.status = Termin.STATUS_POTVRDJENA
        termin.save(update_fields=["status"])

        phase_transition = None
        if phase_state:
            try:
                phase_transition = advance_protocol_after_therapy(
                    state=phase_state,
                    therapy=terapija,
                    user=korisnik,
                )
            except ValidationError as exc:
                raise ValueError(exc.messages[0]) from exc
            interval_sedmica = terapija.interval_sedmica

        from .scheduling import adjust_to_allowed_therapy_date

        izracunati_sljedeci_datum = (
            phase_transition["next_date"]
            if phase_transition else
            termin.datum + timedelta(weeks=interval_sedmica)
        )
        next_medicine = (
            phase_transition["next"]["medicine"]
            if phase_transition else lijek
        )
        next_quantity = (
            phase_transition["next"]["units"]
            if phase_transition else None
        )
        calculated_schedule = adjust_to_allowed_therapy_date(
            izracunati_sljedeci_datum,
            lijek=next_medicine,
            protokol=pacijent.aktivni_protokol(),
        )
        if sljedeci_datum is not None:
            from django.core.exceptions import ValidationError
            from .scheduling import validate_therapy_date

            if sljedeci_datum <= termin.datum:
                raise ValueError(
                    "Sljedeći termin mora biti poslije evidentirane terapije."
                )
            try:
                validate_therapy_date(
                    sljedeci_datum,
                    lijek=next_medicine,
                    protokol=pacijent.aktivni_protokol(),
                )
            except ValidationError as exc:
                raise ValueError(exc.messages[0]) from exc
            scheduled_next = (
                calculated_schedule
                if sljedeci_datum == calculated_schedule.datum
                else adjust_to_allowed_therapy_date(
                    sljedeci_datum,
                    lijek=next_medicine,
                    protokol=pacijent.aktivni_protokol(),
                )
            )
        else:
            scheduled_next = calculated_schedule
        sljedeci_datum = scheduled_next.datum
        sljedeci_termin = None
        next_phase_reservation = None
        if pacijent.trenutni_korak_je_ambulanta():
            from .therapy_workflow import schedule_therapy_appointment

            sljedeci_termin, _ = schedule_therapy_appointment(
                pacijent=pacijent,
                lijek=next_medicine,
                datum=sljedeci_datum,
                vrijeme=termin.vrijeme,
                user=korisnik,
                kolicina_po_terapiji=next_quantity,
                validation_today=scheduling_validation_today,
                reason=(
                    "Automatski zakazan sljedeći termin nakon evidentirane "
                    "terapije."
                ),
            )
            if phase_state:
                try:
                    next_phase_reservation, _reservation_created = ensure_phase_reservation(
                        state=phase_state,
                        appointment=sljedeci_termin,
                        user=korisnik,
                    )
                except ValidationError as exc:
                    upisi_log(
                        korisnik,
                        "Upozorenje rezervacije faznog protokola",
                        pacijent=pacijent,
                        objekat=sljedeci_termin,
                        opis=exc.messages[0],
                    )
            if scheduled_next.prilagodjen:
                upisi_log(
                    korisnik,
                    "Automatski prilagođen datum terapije",
                    pacijent=pacijent,
                    objekat=sljedeci_termin,
                    opis=(
                        f"Izračunati datum "
                        f"{izracunati_sljedeci_datum:%d/%m/%Y} "
                        f"prilagođen je na {sljedeci_datum:%d/%m/%Y}. "
                        f"{scheduled_next.razlog}"
                    ),
                )

        terapija.workflow_snapshot = {
            "vrsta": "AMBULANTNA_PRIMJENA" if ambulantni_korak else "KUCNA_PRIMJENA",
            "faza_terapije_label": (
                therapy_event_phase_label(phase_details)
                if phase_state else terapija.faza_terapije
            ),
            "termin_id": termin.id,
            "prethodni_status_termina": prethodni_status_termina,
            "zaliha_kolicina": str(primljene_doze),
            "komisijske_promjene": komisijske_promjene,
            "zaduzenja_promjene": zaduzenja_promjene,
            "rezervacijske_promjene": ambulatory_reservation_changes,
            "sljedeci_termin_id": sljedeci_termin.id if sljedeci_termin else None,
            "fazni_protokol_id": phase_state.id if phase_state else None,
            "fazni_state_prije": (
                phase_transition["state_before"] if phase_transition else None
            ),
            "fazni_state_poslije": (
                phase_transition["state_after"] if phase_transition else None
            ),
            "fazne_rezervacijske_promjene": phase_reservation_changes,
            "fazna_naredna_rezervacija_id": (
                next_phase_reservation.pk if next_phase_reservation else None
            ),
        }
        terapija.save(update_fields=["workflow_snapshot"])

        from .therapy_workflow import record_status_history
        record_status_history(
            pacijent=pacijent,
            termin=termin,
            terapija=terapija,
            previous_status=prethodni_status_termina,
            new_status=Terapija.STATUS_POTVRDJENA,
            reason="Dolazak potvrđen i terapija evidentirana.",
            user=korisnik,
            previous_state={"termin_status": prethodni_status_termina},
            new_state={"termin_status": termin.status, "terapija_id": terapija.id},
            event_type="TERAPIJA_EVIDENTIRANA",
        )

        # Ručna izmjena važi za ovu evidentiranu terapiju. Protokol pacijenta
        # ostaje jedini izvor za naredne automatske prijedloge.

        upisi_log(
            korisnik,
            (
                "Promjena zalihe - potvrda dolaska"
                if ambulantni_korak else "Evidentirana kućna primjena"
            ),
            pacijent=pacijent,
            objekat=zaliha if ambulantni_korak else terapija,
            opis=(
                f"{lijek.naziv}: potvrda dolaska / terapija. "
                f"Kolicina {primljene_doze}. Stara zaliha {stara_zaliha}, nova zaliha {nova_zaliha}."
                if ambulantni_korak else
                f"{lijek.naziv}: evidentirana kućna primjena {primljene_doze}; "
                "frižider nije promijenjen."
            ),
        )

        if not ambulantni_korak and override_zaduzenja and doze_kod_pacijenta < primljene_doze:
            AktivnostLog.objects.create(
                korisnik=korisnik if korisnik and korisnik.is_authenticated else None,
                akcija="Override potvrde terapije",
                pacijent=pacijent,
                objekat_tip="Termin",
                objekat_id=termin.id,
                opis=(
                    f"{lijek.naziv}: potvrdena terapija {primljene_doze} doza "
                    f"iako je kod pacijenta bilo {doze_kod_pacijenta}."
                ),
            )

        return terapija


@transaction.atomic
def mark_therapy_submitted_to_finance(*, terapija, korisnik=None):
    """Označi evidentiranu terapiju kao predatu finansijama uz audit zapis."""
    from .models import Terapija
    from .utils import upisi_log

    terapija = select_for_update_self(
        Terapija.objects.select_related("pacijent", "lijek")
    ).get(pk=terapija.pk)
    if terapija.workflow_status == Terapija.STATUS_PONISTENA:
        raise ValueError("Poništena terapija ne može biti predata finansijama.")
    if terapija.finansijski_status == Terapija.FINANSIJSKI_PREDATO:
        return terapija, False
    if terapija.finansijski_status != Terapija.FINANSIJSKI_CEKA:
        raise ValueError("Terapija nije spremna za predaju finansijama.")

    prethodni_status = terapija.finansijski_status
    terapija.finansijski_status = Terapija.FINANSIJSKI_PREDATO
    terapija.finansijama_predao = (
        korisnik if getattr(korisnik, "is_authenticated", False) else None
    )
    terapija.finansijama_predato_at = timezone.now()
    terapija.save(
        update_fields=[
            "finansijski_status",
            "finansijama_predao",
            "finansijama_predato_at",
        ]
    )
    upisi_log(
        korisnik,
        "Terapija predata finansijama",
        pacijent=terapija.pacijent,
        objekat=terapija,
        opis=(
            f"{terapija.lijek.naziv}: finansijski status promijenjen "
            f"iz {prethodni_status} u {terapija.finansijski_status}."
        ),
    )
    return terapija, True
