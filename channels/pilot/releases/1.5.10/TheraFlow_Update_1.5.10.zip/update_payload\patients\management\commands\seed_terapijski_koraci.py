from django.core.management import call_command
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Kompatibilni alias za seed_terapijski_protokoli."

    def handle(self, *args, **options):
        call_command("seed_terapijski_protokoli")
