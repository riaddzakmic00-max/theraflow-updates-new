import re
import os
import re
import subprocess
import time
from pathlib import Path


class ServiceError(RuntimeError):
    def __init__(self, message, exit_code=None):
        self.exit_code = exit_code
        super().__init__(message)


def _run(args, timeout=20):
    try:
        return subprocess.run(args, capture_output=True, text=True, check=False, timeout=timeout, shell=False)
    except subprocess.TimeoutExpired as exc:
        raise ServiceError("Windows servisna komanda je istekla.", -1) from exc


def query(service_name):
    result = _run(["sc.exe", "queryex", service_name])
    if result.returncode != 0:
        raise ServiceError("TheraFlow servis nije pronađen.", result.returncode)
    state = re.search(r"STATE\s*:\s*\d+\s+(\w+)", result.stdout, re.I)
    pid = re.search(r"PID\s*:\s*(\d+)", result.stdout, re.I)
    return {"state": state.group(1).upper() if state else "UNKNOWN", "pid": int(pid.group(1)) if pid else 0, "raw": result.stdout[:20000]}


def configuration(service_name):
    result = _run(["sc.exe", "qc", service_name])
    if result.returncode != 0:
        raise ServiceError("Konfiguracija TheraFlow servisa nije dostupna.", result.returncode)
    return result.stdout[:20000]


def wait_for_state(service_name, expected, timeout=60, interval=1):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if query(service_name)["state"] == expected:
            return True
        time.sleep(interval)
    return False


def stop(service_name, timeout=60):
    current = query(service_name)
    if current["state"] == "STOPPED":
        return current
    _run(["sc.exe", "stop", service_name])
    if wait_for_state(service_name, "STOPPED", timeout):
        return query(service_name)
    # Ne koristiti taskkill /T. Updater je namjerno odvojeni potomak web
    # procesa; ubijanje cijelog servisnog stabla može ugasiti i updater prije
    # nego što stigne instalirati fajlove ili zapisati terminalno stanje.
    current = query(service_name)
    raise ServiceError(
        "TheraFlow servis se nije mogao sigurno zaustaviti u zadanom roku "
        f"(state={current['state']}, pid={current['pid']})."
    )


def start(service_name, timeout=60):
    current = query(service_name)
    if current["state"] != "RUNNING":
        result = _run(["sc.exe", "start", service_name])
        if result.returncode != 0:
            observed = query(service_name)
            if observed["state"] != "RUNNING":
                raise ServiceError(
                    "TheraFlow servis se nije mogao pokrenuti.",
                    result.returncode,
                )
    if not wait_for_state(service_name, "RUNNING", timeout):
        raise ServiceError("TheraFlow servis nije prešao u RUNNING stanje.")
    return query(service_name)


def install_backup_scheduler(application_root, timeout=120):
    application_root = Path(application_root).resolve()
    candidates = (
        application_root / "service" / "install_backup_scheduler_service.bat",
        application_root.parent
        / "scripts"
        / "service"
        / "install_backup_scheduler_service.bat",
    )
    script = next((path for path in candidates if path.is_file()), candidates[0])
    if not script.is_file():
        if os.environ.get("THERAFLOW_PRODUCTION", "").lower() not in {
            "1",
            "true",
            "yes",
            "on",
        }:
            return {"state": "SKIPPED", "pid": 0}
        raise ServiceError("Instalacijska skripta backup schedulera nije pronađena.")
    result = _run(["cmd.exe", "/d", "/c", str(script)], timeout=timeout)
    if result.returncode != 0:
        output = (result.stderr or result.stdout or "").strip().splitlines()
        detail = output[-1].strip() if output else "bez dodatnog izlaza"
        raise ServiceError(
            "TheraFlowBackupScheduler se nije mogao instalirati ili pokrenuti: "
            f"{detail}",
            result.returncode,
        )
    return query("TheraFlowBackupScheduler")
