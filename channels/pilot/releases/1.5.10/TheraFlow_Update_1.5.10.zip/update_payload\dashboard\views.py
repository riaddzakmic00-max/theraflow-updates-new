import calendar
import mimetypes
import csv
import logging
import os
import shutil
import uuid
from io import BytesIO
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import get_user_model, login, logout, update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from urllib import request
from django.contrib.auth.decorators import user_passes_test
from django.db import transaction
from django.views.decorators.cache import never_cache
from django.views.decorators.debug import sensitive_post_parameters
from django.views.decorators.http import require_POST
from datetime import datetime, time
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.cache import cache
from django.core.paginator import Paginator
from datetime import timedelta
from math import ceil
from django.http import HttpResponse, JsonResponse
from django.db.models import Count, Min, Q
from patients.utils import upisi_log
from patients.demo_dataset_v2 import (
    existing_demo_v2_patients_count,
    generate_demo_dataset_v2,
    reset_demo_dataset_v2,
)
from patients.demo_reset import DemoDatasetResetError
from patients.integrity import run_database_integrity_check
from patients.schema_gate import ADMIN_SCHEMA_MESSAGE, run_schema_gate
from patients.inventory import (
    active_reservation_details,
    assign_free_stock_to_patient,
    cover_pending_physical_needs,
    eligible_free_stock_recipients,
    free_stock_recipient_candidates,
    free_stock_quantity,
    free_stock_source_rows,
    inventory_position_for_patient,
    kriticne_zalihe_iz_potreba,
    release_patient_reservations_to_free_stock,
    reserve_physical_stock,
    rekalkulisi_fizicke_zalihe,
    zalihe_sa_potrebama,
)
from patients.home_therapy import (
    calculate_home_therapy_projection,
    format_stock_quantity,
    home_therapy_issue_availability,
    issue_home_therapy,
)
from patients.oral_therapy import (
    confirm_oral_regimen,
    issue_oral_therapy,
    oral_therapy_status,
    void_oral_issuance,
)
from patients.individual_protocols import (
    create_migrated_individual_protocol,
    get_standard_protocol,
    individual_protocol_initial_data,
    patient_protocol_display_data,
    persistable_standard_step,
    save_structured_protocol_steps,
    structured_protocol_initial_data,
)
from patients.medication_groups import (
    THERAPY_GROUP_ADALIMUMAB,
    THERAPY_GROUP_ENTYVIO,
    THERAPY_GROUP_OSTALI,
    THERAPY_GROUP_REMSIMA,
    equivalent_medicine_ids,
    get_therapy_group,
    medicine_group_css,
    medicine_group_label,
    medicine_group_q,
    therapy_group_label,
    therapy_group_bucket_key,
    therapy_group_q,
)
from patients.medicine_registry import (
    active_patient_therapy_summary,
    active_therapy_medicines,
    active_therapy_programs,
)
from patients.therapy_regimens import (
    TYPE_HOME_SC,
    TYPE_INFUSION,
    TYPE_ORAL,
    therapy_regimen_type_q,
)
from patients.commission_service import (
    approve_cycle,
    calculate_patient_commission_need,
    commission_cycle_overview,
    commission_needs_by_patient,
    complete_cycle,
    confirm_next_commission_date,
    get_commission_schedule,
    mark_cycle_waiting_delivery,
    mark_requests_sent,
    lock_cycle_receipt_rows,
    patient_commission_coverage,
    patients_for_next_commission,
    expected_delivery_for_cycle,
)
from patients.commission_receiving import (
    agreement_number_conflicts,
    agreement_number_owners,
    patient_agreement_suggestion,
    resolve_receipt_approval_context,
    use_patient_agreement_for_receipt,
    update_patient_agreement,
    validate_agreement_number,
)
from patients.commission_request_state import resolve_commission_request_state
from patients.patient_deactivation import deactivate_patient_safely
from patients.commission_demand import commission_demand_v2_enabled
from patients.commission_eligibility import (
    WORKFLOW_NEW_AWAITING_INITIAL_COMMISSION,
)
from patients.commission_planning import (
    commission_dashboard_summary,
    commission_draft_snapshot,
    commission_patient_status_snapshot,
    commission_planning_row_for_patient,
    commission_planning_rows,
    commission_request_snapshot,
    delivery_risk_rows,
    reconcile_stale_draft_membership,
    save_commission_manual_override,
    validate_commission_request_snapshot,
)
from patients.package_sizes import (
    complete_package_count,
    package_multiple_error,
    package_size_for,
    procurement_breakdown,
    procurement_unit_display_label,
    validate_package_multiple,
)
from patients.extraordinary_commission import (
    ACTIVE_EXTRAORDINARY_STATUSES,
    cancel_extraordinary_request,
    create_extraordinary_request,
    extraordinary_request_context,
    extraordinary_requests,
    mark_extraordinary_ready,
    move_extraordinary_to_regular,
    update_extraordinary_request,
)
from patients.adaptive_assistant import (
    adaptive_summary_safely,
    anonymized_aggregate_rows_safely,
    calculate_descriptive_insights_safely,
)
from patients.scheduling import (
    demo_weekend_appointments_enabled,
    is_allowed_therapy_date,
    is_demo_weekend_calendar_date,
    user_can_create_demo_weekend_appointment,
    weekend_appointments_queryset,
)
from patients.video_demo import VIDEO_DEMO_MARKER, tagged_video_demo_appointment_ids
from patients.migration_service import (
    apply_migration_snapshot,
    create_snapshot_confirmation_token,
    migration_inventory_summary,
    migration_inventory_reconciliation_preview,
    potvrdi_historijske_migracijske_rezervacije,
    reconcile_migration_inventory_provenance,
    snapshot_confirmation_is_valid,
    snapshot_for_display,
    uskladi_pocetno_stanje_zalihe,
)
from patients.therapy_workflow import (
    cancel_therapy,
    mark_no_show,
    pause_patient_therapy,
    postpone_therapy,
    resume_patient_therapy,
    schedule_therapy_appointment,
    void_therapy,
)
from patients.reset_test_data import collect_test_inventory_stats, reset_test_inventory
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.utils import timezone
from django.http import FileResponse, Http404
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from PyPDF2 import PdfReader, PdfWriter
from .forms import (
    DodjelaSlobodneZaliheForm,
    DokumentPacijentaForm,
    FirstAdminSetupForm,
    IndukcijskiKorakFormSet,
    IndividualniProtokolPacijentaForm,
    KucnoIzdavanjeForm,
    OralniTerapijskiRezimForm,
    OralnoIzdavanjeForm,
    KomisijskaSaglasnostPhase3Form,
    KomisijskaStavkaLijekaPhase2FormSet,
    KomisijskiZahtjevPhase2Form,
    MigracijaPacijentaForm,
    OdobrenaKomisijaForm,
    OdrzavanjeIndividualnogProtokolaForm,
    PacijentForm,
    PromjenaTerapijeForm,
    TerminForm,
    UserCreateForm,
    UserEditForm,
    UserPasswordResetForm,
    UstekinumabIntervalChangeForm,
    UstekinumabPhaseScheduleForm,
    UstekinumabProtocolSetupForm,
)
from django.contrib.auth.decorators import login_required
from dashboard.permissions import korisnik_uloga
from dashboard.alarmi import napravi_alarm_centar
from dashboard.pdf_coordinates import PDF_FORMS, PDF_TEMPLATE_MAP, get_pdf_coords, save_pdf_coord
from dashboard.pdf_overlay import merge_pdf_overlay_page, render_pdf_overlay
from dashboard.commission_phase2 import (
    CATEGORY_SPECS,
    agreement_progress,
    apply_manual_request_type_decision,
    clear_print_snapshot,
    cycle_display_title,
    cycle_workflow_status,
    generate_cycle_category_pdfs,
    generate_cycle_summary_pdf,
    grouped_cycle_requests,
    legacy_request_type_from_planning,
    request_row,
    resolve_generated_file,
    save_commission_agreement,
    sync_commission_request_from_planning,
    validate_cycle_for_print,
)
from patients.commission_request_types import (
    PURPOSE_REQUIRES_CONFIRMATION,
    canonical_from_legacy,
    classify_commission_request,
)
from dashboard.postgres_backup import (
    BackupError,
    automatic_backup_status,
    create_postgres_backup,
    ensure_backup_dir,
    ensure_daily_backup,
    executable_path,
    list_postgres_backups,
    restore_postgres_backup,
    run_manual_backup_test,
    safe_backup_path,
)
from django.db import models

from dashboard.permissions import (
    je_admin,
    je_koordinator_ili_admin,
    je_doktor,
    je_sestra,
    je_doktor_ili_admin,
    je_sestra_ili_admin,
    je_terapijski_tim,
)

from patients.models import (
    AdaptiveDecisionRecord,
    Pacijent,
    Termin,
    Komisija,
    KucnoIzdavanje,
    IzdavanjeOralneTerapije,
    Zaliha,
    Terapija,
    Lijek,
    DokumentSablon,
    DokumentPacijenta,
    PacijentZaduzenje,
    PacijentRezervacija,
    PromjenaTerapije,
    AktivnostLog,
    Trebovanje,
    ZalihaTransakcija,
    Ljekar,
    PostavkeSistema,
    KomisijskiCiklus,
    KomisijskaSaglasnost,
    PacijentSaglasnost,
    KomisijskiZahtjev,
    MigracijskiSnapshotPacijenta,
    IndividualniProtokolPacijenta,
    IzmjenaIndividualnogProtokola,
    TerapijaStatusHistorija,
    FazniProtokolPacijenta,
    OralniTerapijskiRezim,
)
from patients.services import (
    confirm_therapy_arrival,
    default_therapy_dose,
    izracunaj_status_pacijenta,
    mark_therapy_submitted_to_finance,
    recalculate_future_appointments,
)


logger = logging.getLogger(__name__)

from dashboard.user_access import (
    invalidate_user_sessions,
    requires_password_change,
    set_password_change_required,
    set_user_active,
    set_user_role,
    user_role,
)


def _first_admin_setup_allowed():
    User = get_user_model()
    return not User.objects.filter(is_superuser=True, is_active=True).exists()


@sensitive_post_parameters("password1", "password2")
@never_cache
def setup_first_admin(request):
    if not _first_admin_setup_allowed():
        return redirect("login")

    if request.method == "POST":
        form = FirstAdminSetupForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                if not _first_admin_setup_allowed():
                    return redirect("login")
                user = form.save()
            login(request, user)
            messages.success(request, "Prvi administrator sistema je kreiran.")
            return redirect("dashboard")
    else:
        form = FirstAdminSetupForm()

    return render(request, "dashboard/setup_first_admin.html", {"form": form})

def izracunaj_potrosnju_pacijenta(pacijent, dana):
    if not pacijent.lijek:
        return 0

    protokol = pacijent.aktivni_protokol()

    if protokol:
        return pacijent.doze_za_period(ceil(dana / 7))

    doza_po_terapiji = 1
    interval_sedmica = pacijent.efektivni_interval_sedmica()
    broj_sedmica = dana / 7
    broj_terapija = ceil(broj_sedmica / interval_sedmica)

    return broj_terapija * doza_po_terapiji


def clanovi_konzilija_za_trebovanje(trebovanje):
    try:
        postavke = get_postavke_sistema()
    except Exception:
        postavke = None

    return {
        "predsjednik": (
            trebovanje.predsjednik_konzilija
            or (postavke.default_predsjednik_konzilija if postavke else "")
            or ""
        ),
        "clan_1": (
            trebovanje.clan_konzilija_1
            or (postavke.default_clan_konzilija_1 if postavke else "")
            or ""
        ),
        "clan_2": (
            trebovanje.clan_konzilija_2
            or (postavke.default_clan_konzilija_2 if postavke else "")
            or ""
        ),
    }


def default_clanovi_konzilija():
    try:
        postavke = get_postavke_sistema()
    except Exception:
        postavke = None

    return {
        "predsjednik": (postavke.default_predsjednik_konzilija if postavke else "") or "",
        "clan_1": (postavke.default_clan_konzilija_1 if postavke else "") or "",
        "clan_2": (postavke.default_clan_konzilija_2 if postavke else "") or "",
    }


def format_date_bs(value):
    return value.strftime("%d/%m/%Y") if value else ""


def zadnji_ljekar_ime():
    try:
        postavke = get_postavke_sistema()
    except Exception:
        postavke = None

    return (
        (postavke.podnosilac_zahtjeva if postavke else "")
        or getattr(settings, "PDF_SPECIJALISTA", "")
        or "Mr. Sc. Nijaz Tucaković"
    )


def pdf_zdravstvena_ustanova():
    try:
        postavke = get_postavke_sistema()
    except Exception:
        postavke = None

    return (
        (postavke.zdravstvena_ustanova if postavke else "")
        or getattr(settings, "PDF_ZDRAVSTVENA_USTANOVA", "")
        or "JU Opća bolnica prim.dr. Abdulah Nakaš"
    )


def opis_doze_pacijenta(pacijent):
    korak = pacijent.sljedeci_korak_terapije()
    if korak:
        return korak.opis_doze()

    try:
        return f"{pacijent.doza_po_aplikaciji():g} jedinica"
    except Exception:
        return ""


def zahtjev_zavodu_values(trebovanje):
    pacijent = trebovanje.pacijent
    lijek = trebovanje.lijek
    clanovi = clanovi_konzilija_za_trebovanje(trebovanje)
    ustanova = pdf_zdravstvena_ustanova()
    specijalista = zadnji_ljekar_ime()
    zasticeno_ime = lijek.brand_name if lijek else ""
    genericki_naziv = lijek.generic_name if lijek else ""

    print("USTANOVA:", repr(ustanova))
    print("SPECIJALISTA:", repr(specijalista))

    return {
        "lijek_header": zasticeno_ime,
        "ustanova": ustanova,
        "ustanova_linija": "______________________________",
        "datum": format_date_bs(timezone.now().date()),
        "jmbg": pacijent.jmbg or "",
        "ime_prezime": f"{pacijent.prezime.upper()} {pacijent.ime.upper()}",
        "spol": pacijent.spol or "",
        "datum_rodjenja": format_date_bs(pacijent.datum_rodenja),
        "adresa": pacijent.adresa or "",
        "kanton": pacijent.kanton or "",
        "mkb_sifra": pacijent.mkb_sifra or "",
        "dijagnoza": pacijent.dijagnoza or "",
        "hitnost_normalno": "X",
        "doza": opis_doze_pacijenta(pacijent),
        "lijek": zasticeno_ime,
        "lijek_genericki": genericki_naziv,
        "jacina": "________",
        "oblik": "________",
        "broj_trazenih_doza": procurement_breakdown(
            trebovanje.broj_doza,
            lijek,
        )["display_text"],
        "ljekar": specijalista,
        "predsjednik_konzilija": clanovi["predsjednik"],
        "clan_konzilija_1": clanovi["clan_1"],
        "clan_konzilija_2": clanovi["clan_2"],
        "napomena": trebovanje.napomena or "",
    }


def render_zahtjev_zavodu_pdf(trebovanje, output_path):
    sablon_path = os.path.join(settings.BASE_DIR, "media", "sabloni", "za_zavod.pdf")
    return render_pdf_overlay(
        sablon_path,
        output_path,
        get_pdf_coords("zahtjev_zavod"),
        zahtjev_zavodu_values(trebovanje),
        debug=getattr(settings, "PDF_DEBUG", False),
    )


def razduzenje_values(pacijent, aktivna_komisija, terapija=None):
    clanovi = default_clanovi_konzilija()
    zadnja_terapija = (
        terapija or pacijent.posljednja_stvarno_primljena_terapija()
    )

    if terapija:
        utroseno = terapija.kolicina
        kolicina = terapija.kolicina
    else:
        try:
            utroseno = pacijent.terapija_set.filter(
                lijek=pacijent.lijek,
                workflow_status=Terapija.STATUS_POTVRDJENA,
            ).aggregate(models.Sum("kolicina"))["kolicina__sum"] or 0
        except Exception:
            utroseno = 0
        kolicina = aktivna_komisija.broj_odobrenih_doza if aktivna_komisija else ""

    evidentirao = getattr(zadnja_terapija, "evidentirao", None)
    odgovorna_osoba = (
        (evidentirao.get_full_name() or evidentirao.username)
        if evidentirao
        else zadnji_ljekar_ime()
    )
    lijek = zadnja_terapija.lijek if zadnja_terapija else pacijent.lijek
    lijek_opis = lijek.prikaz_naziv if lijek else ""
    if zadnja_terapija and zadnja_terapija.faza_terapije:
        lijek_opis = f"{lijek_opis} - {zadnja_terapija.faza_terapije_prikaz}"

    return {
        "pacijent": f"{pacijent.ime} {pacijent.prezime}",
        "jmbg": pacijent.jmbg or "",
        "broj_saglasnosti": aktivna_komisija.broj_saglasnosti if aktivna_komisija and aktivna_komisija.broj_saglasnosti else "",
        "datum_odobrenja": format_date_bs(aktivna_komisija.datum_odobrenja) if aktivna_komisija else "",
        "mkb_sifra": pacijent.mkb_sifra or "",
        "dijagnoza": pacijent.dijagnoza or "",
        "lijek": lijek_opis,
        "kolicina": kolicina,
        "serija": zadnja_terapija.serija if zadnja_terapija and zadnja_terapija.serija else "",
        "utroseno": utroseno,
        "datum_terapije": format_date_bs(zadnja_terapija.datum) if zadnja_terapija else "",
        "datum_razduzenja": format_date_bs(timezone.now().date()),
        "faza_terapije": (
            zadnja_terapija.faza_terapije_prikaz if zadnja_terapija else ""
        ),
        "ustanova": pdf_zdravstvena_ustanova(),
        "korisnik": odgovorna_osoba,
        "ljekar": odgovorna_osoba,
        "predsjednik_konzilija": clanovi["predsjednik"],
        "clan_konzilija_1": clanovi["clan_1"],
        "clan_konzilija_2": clanovi["clan_2"],
    }


def korisnik_moze_razduzenje(user):
    return je_admin(user) or je_doktor(user) or je_sestra(user)


def razduzenje_izdavanje_snapshot(izdavanje):
    pacijent = izdavanje.pacijent
    lijek = izdavanje.lijek
    komisija = izdavanje.komisija
    clanovi = default_clanovi_konzilija()
    korak = pacijent.trenutni_korak_terapije() if pacijent else None
    korisnik = izdavanje.korisnik_koji_je_izdao

    genericki_naziv = lijek.generic_name if lijek else ""
    zasticeno_ime = lijek.brand_name if lijek else ""
    odgovorna_osoba = ""
    if korisnik:
        odgovorna_osoba = korisnik.get_full_name() or korisnik.username
    if not odgovorna_osoba:
        odgovorna_osoba = zadnji_ljekar_ime()

    return {
        "pacijent": f"{pacijent.ime} {pacijent.prezime}" if pacijent else "",
        "jmbg": pacijent.jmbg if pacijent else "",
        "datum_rodenja": format_date_bs(pacijent.datum_rodenja) if pacijent else "",
        "adresa": pacijent.adresa if pacijent else "",
        "kanton": pacijent.kanton if pacijent else "",
        "broj_saglasnosti": komisija.broj_saglasnosti if komisija and komisija.broj_saglasnosti else "",
        "datum_odobrenja": format_date_bs(komisija.datum_odobrenja) if komisija else "",
        "mkb_sifra": pacijent.mkb_sifra if pacijent else "",
        "dijagnoza": pacijent.dijagnoza if pacijent else "",
        "lijek": zasticeno_ime or (lijek.naziv if lijek else ""),
        "lijek_genericki": genericki_naziv,
        "genericki_naziv": genericki_naziv,
        "zasticeni_naziv": zasticeno_ime,
        "kolicina": str(izdavanje.kolicina),
        "broj_izdanih_doza": str(izdavanje.kolicina),
        "doza": korak.opis_doze() if korak else opis_doze_pacijenta(pacijent),
        "jacina": f"{korak.doza_mg:g} mg" if korak and korak.doza_mg else "",
        "serija": izdavanje.serija or "",
        "lot": izdavanje.serija or "",
        "rok_trajanja": format_date_bs(izdavanje.rok_trajanja),
        "utroseno": str(izdavanje.kolicina),
        "datum_terapije": format_date_bs(izdavanje.datum),
        "datum_izdavanja": format_date_bs(izdavanje.datum),
        "datum_razduzenja": format_date_bs(izdavanje.datum),
        "ustanova": pdf_zdravstvena_ustanova(),
        "ambulanta": pdf_zdravstvena_ustanova(),
        "ljekar": zadnji_ljekar_ime(),
        "odgovorna_osoba": odgovorna_osoba,
        "korisnik": odgovorna_osoba,
        "predsjednik_konzilija": clanovi["predsjednik"],
        "clan_konzilija_1": clanovi["clan_1"],
        "clan_konzilija_2": clanovi["clan_2"],
        "napomena": izdavanje.napomena or "",
    }


def razduzenje_izdavanje_values(izdavanje):
    values = dict(izdavanje.razduzenje_snapshot or {})
    if not values:
        values = razduzenje_izdavanje_snapshot(izdavanje)

    for key in ("kolicina", "broj_izdanih_doza", "utroseno"):
        if key in values and values[key] not in ("", None):
            try:
                values[key] = Decimal(str(values[key]))
            except Exception:
                pass

    return values


def validiraj_razduzenje_izdavanja(izdavanje):
    values = razduzenje_izdavanje_values(izdavanje)
    required = {
        "broj_saglasnosti": "nedostaje broj saglasnosti",
        "serija": "nedostaje serija",
        "rok_trajanja": "nedostaje rok trajanja",
        "pacijent": "nedostaju podaci pacijenta",
        "jmbg": "nedostaje JMBG",
        "genericki_naziv": "nedostaje genericki naziv lijeka",
        "zasticeni_naziv": "nedostaje zasticeni naziv lijeka",
        "kolicina": "nedostaje broj izdanih doza",
        "datum_izdavanja": "nedostaje datum izdavanja",
        "odgovorna_osoba": "nedostaju podaci odgovorne osobe",
    }
    missing = [message for key, message in required.items() if not values.get(key)]
    return missing


def osiguraj_razduzenje_snapshot(izdavanje):
    if izdavanje.razduzenje_snapshot:
        return False
    izdavanje.razduzenje_snapshot = razduzenje_izdavanje_snapshot(izdavanje)
    izdavanje.save(update_fields=["razduzenje_snapshot"])
    return True


def evidentiraj_generisanje_razduzenja(izdavanje, user):
    now = timezone.now()
    prvi_put = izdavanje.razduzenje_prvi_put_generisano is None
    if prvi_put:
        izdavanje.razduzenje_prvi_put_generisano = now
    izdavanje.razduzenje_zadnji_put_generisano = now
    izdavanje.razduzenje_broj_generisanja = (izdavanje.razduzenje_broj_generisanja or 0) + 1
    izdavanje.save(update_fields=[
        "razduzenje_prvi_put_generisano",
        "razduzenje_zadnji_put_generisano",
        "razduzenje_broj_generisanja",
    ])
    upisi_log(
        user,
        "Generisano razduzenje prema Zavodu",
        pacijent=izdavanje.pacijent,
        objekat=izdavanje,
        opis=(
            f"Izdavanje {izdavanje.id}: {izdavanje.kolicina} doza; "
            f"{'prvo generisanje' if prvi_put else 'ponovna stampa'}."
        ),
    )


@login_required
def dashboard(request):
    danas = timezone.now().date()
    sutra = danas + timedelta(days=1)
    komisijski_v2 = commission_demand_v2_enabled()
    komisijski_plan_redovi = commission_planning_rows(today=danas) if komisijski_v2 else []
    komisijski_dashboard = (
        commission_dashboard_summary(komisijski_plan_redovi, today=danas)
        if komisijski_v2
        else None
    )
    komisijski_plan_po_pacijentu = {
        row["pacijent"].pk: row for row in komisijski_plan_redovi
    }
    alarm_centar = napravi_alarm_centar()
    trebovanja_u_toku = Trebovanje.objects.filter(
        status__in=["U_PRIPREMI", "PREDATO", "ODOBRENO"]
    ).order_by("-datum_kreiranja")[:5]

    # ZAKAZAN je trenutno jedini aktivni status termina. OBAVLJEN predstavlja
    # završenu/potvrđenu terapiju i ne pripada operativnom redu, jednako kao
    # odgođeni, otkazani, no-show i poništeni termini.
    aktivni_statusi_danas = (Termin.STATUS_PLANIRANA,)
    termini_danas = list(
        Termin.objects.filter(
            datum=danas,
            status__in=aktivni_statusi_danas,
        )
        .exclude(lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA)
        .select_related("pacijent", "pacijent__terapijski_program", "lijek")
        .order_by("vrijeme")
    )
    prvi_naredni_aktivni_termin = None
    if not termini_danas:
        prvi_naredni_aktivni_termin = (
            Termin.objects.filter(
                datum__gt=danas,
                status=Termin.STATUS_PLANIRANA,
            )
            .exclude(lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA)
            .select_related("pacijent", "pacijent__terapijski_program", "lijek")
            .order_by("datum", "vrijeme", "id")
            .first()
        )
    otkazani_termini_danas = Termin.objects.filter(
        datum=danas,
        status=Termin.STATUS_OTKAZANA,
    ).exclude(
        lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA
    ).count()

    danasnje_terapije = len(termini_danas)
    cekaju_potvrdu = danasnje_terapije

    def oblik_broja(broj, jedan, nekoliko, mnogo):
        broj = int(broj)
        if broj % 10 == 1 and broj % 100 != 11:
            return jedan
        if broj % 10 in [2, 3, 4] and broj % 100 not in [12, 13, 14]:
            return nekoliko
        return mnogo

    otkazani_termini_meta = (
        f"{otkazani_termini_danas} "
        f"{oblik_broja(otkazani_termini_danas, 'otkazana', 'otkazane', 'otkazanih')}"
        if otkazani_termini_danas
        else ""
    )

    termini_danas_panel = termini_danas

    for termin in termini_danas_panel:
        termin.vrijeme_fmt = termin.vrijeme.strftime("%H:%M") if termin.vrijeme else ""
        termin.terapija_naziv = termin.pacijent.terapija_za_prikaz
        termin.proizvod_naziv = termin.lijek.prikaz_naziv if termin.lijek_id else ""
        termin.status_label = dict(Termin.STATUS).get(termin.status, termin.status)
        termin.moze_potvrditi = False
        termin.telefon_pacijenta = termin.pacijent.telefon if termin.pacijent and termin.pacijent.telefon else ""
        termin.preostale_doze = None
        termin.preostale_doze_label = "Nije dostupno"
        termin.komisija_label = "Pokriven terapijom"
        termin.next_badge_label = "Spreman za terapiju"
        termin.next_badge_css = "next-ready"
        termin.countdown_label = "Na redu sada"
        try:
            status_pacijenta = izracunaj_status_pacijenta(termin.pacijent)
            termin.faza_terapije = status_pacijenta.get("trenutna_faza") or ""
            termin.sljedeca_terapija = status_pacijenta.get("sljedeca_terapija")
            planning = komisijski_plan_po_pacijentu.get(termin.pacijent_id)
            termin.preostale_doze = (
                planning["odobreno_preostalo"]
                if planning else status_pacijenta.get("preostalo_na_komisiji")
            )
            if termin.preostale_doze is not None:
                termin.preostale_doze_label = f"{termin.preostale_doze:g} doza"
            if (
                status_pacijenta.get("status_css") == "status-hitno"
                or (termin.preostale_doze is not None and termin.preostale_doze <= 0)
            ):
                termin.komisija_label = "Potrebna nova"
                termin.next_badge_label = "Nema pokrića"
                termin.next_badge_css = "next-danger"
            elif termin.preostale_doze is not None and termin.preostale_doze <= 2:
                termin.komisija_label = "Pri kraju"
                termin.next_badge_label = "Čeka potvrdu"
                termin.next_badge_css = "next-waiting"
            termin.moze_potvrditi = (
                termin.status == "ZAKAZAN"
                and termin.pacijent.trenutni_korak_je_ambulanta()
            )
        except Exception:
            termin.faza_terapije = ""

        try:
            termin.broj_doze = (
                termin.pacijent.broj_dosadasnjih_aplikacija() + 1
            )
            termin.doza_label = f"D{termin.broj_doze}"
        except Exception:
            termin.broj_doze = None
            termin.doza_label = ""

        if termin.faza_terapije:
            faza_kratko = "Održavanje" if "odr" in termin.faza_terapije.lower() else "Indukcija"
        else:
            faza_kratko = ""
        termin.faza_i_doza = " • ".join(dio for dio in [faza_kratko, termin.doza_label] if dio)

        if termin.status == "OTKAZAN":
            termin.next_badge_label = "Otkazan"
            termin.next_badge_css = "next-cancelled"
            termin.countdown_label = "Termin je otkazan"
        elif termin.status != "ZAKAZAN":
            if termin.next_badge_css != "next-danger":
                termin.next_badge_label = "Spreman za terapiju"
                termin.next_badge_css = "next-ready"
            termin.countdown_label = "Na redu sada"
        else:
            if termin.next_badge_css != "next-danger":
                termin.next_badge_label = "Čeka potvrdu"
                termin.next_badge_css = "next-waiting"
            if termin.datum == danas and termin.vrijeme:
                termin_dt = timezone.make_aware(datetime.combine(termin.datum, termin.vrijeme))
                minuta_do_termina = int((termin_dt - timezone.now()).total_seconds() // 60)
                if minuta_do_termina > 0:
                    termin.countdown_label = f"Počinje za {minuta_do_termina} min"
                else:
                    termin.countdown_label = "Na redu sada"

    for index, termin in enumerate(termini_danas_panel):
        termin.preostalo_danas = max(len(termini_danas_panel) - index - 1, 0)
        termin.preostalo_danas_label = oblik_broja(
            termin.preostalo_danas,
            "terapija",
            "terapije",
            "terapija",
        )

    komisije_uskoro_sve = (
        [] if komisijski_v2 else patients_for_next_commission()
    )
    komisije_uskoro_panel = komisije_uskoro_sve[:5]
    kriticne_zalihe_sve = kriticne_zalihe_iz_potreba()

    termini_sutra_count = sum(
        1 for termin in Termin.objects.filter(datum=sutra, status="ZAKAZAN")
        .exclude(lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA)
        .select_related("pacijent", "lijek")
        if termin.pacijent.trenutni_korak_je_ambulanta()
    )
    
    pocetak_mjeseca = danas.replace(day=1)

    terapije_ovaj_mjesec = Terapija.objects.filter(
        datum__gte=pocetak_mjeseca
    ).exclude(
        lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA
    ).count()

    potrosene_doze_mjesec = Terapija.objects.filter(
        datum__gte=pocetak_mjeseca
    ).exclude(
        lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA
    ).aggregate(models.Sum("kolicina"))["kolicina__sum"] or 0

    aktivna_trebovanja = Trebovanje.objects.filter(
        status__in=["U_PRIPREMI", "PREDATO", "ODOBRENO"]
    ).count()

    aktivne_komisije = Komisija.objects.filter(
        status="AKTIVNA"
    ).count()

    alarm_pacijenti = []
    plan_potreba = []
    prioriteti = []

    from patients.querysets import with_workflow_data

    # V2 planner je kanonski izvor komisijskih prioriteta i već je izračunat
    # iznad. Legacy per-patient status petlja puni samo stare, više nekorištene
    # dashboard kolekcije i ne smije drugi put pokretati cijeli obračun.
    workflow_patients = (
        []
        if komisijski_v2
        else with_workflow_data(Pacijent.objects.filter(aktivan=True))
    )
    for pacijent in workflow_patients:
        from patients.patient_risk import patient_risk

        lijek = pacijent.lijek

        if not lijek:
            continue

        status_pacijenta = izracunaj_status_pacijenta(pacijent)
        strukturirani_rizik = patient_risk(
            pacijent,
            workflow=status_pacijenta,
            planning=komisijski_plan_po_pacijentu.get(pacijent.pk),
            today=danas,
        )
        protokol = status_pacijenta["plan_terapije"]
        minimalno_za_terapiju = pacijent.doza_po_aplikaciji() if protokol else Decimal("1")
        planirati_doza = status_pacijenta["potrebe_komisije"]["ukupno_potrebno"] if protokol else Decimal("6")
        trenutno_doza = status_pacijenta["kod_pacijenta"]
        fali = status_pacijenta["za_novu_komisiju"]

        if fali > 0:
            alarm_pacijenti.append({
                "pacijent": pacijent,
                "lijek": lijek,
                "trenutno": trenutno_doza,
                "minimalno": minimalno_za_terapiju,
                "fali": fali,
                "protokol": protokol,
                "status_pacijenta": status_pacijenta,
            })

            plan_potreba.append({
                "pacijent": pacijent,
                "lijek": lijek,
                "trenutno": trenutno_doza,
                "planirati": max(planirati_doza - trenutno_doza, 0),
            })

        if (
            strukturirani_rizik.urgent
            or getattr(strukturirani_rizik, "code", "") == "REVIEW"
        ):
            prioriteti.append({
                "tip": strukturirani_rizik.label,
                "badge": "red" if strukturirani_rizik.urgent else "amber",
                "severity_rank": 0 if strukturirani_rizik.urgent else 2,
                "naslov": f"{pacijent.ime} {pacijent.prezime}",
                "opis": strukturirani_rizik.reason,
                "razlog_kod": strukturirani_rizik.code,
                "pacijent_id": pacijent.pk,
                "pacijent_url": reverse("profil_pacijenta", args=[pacijent.id]),
                "url": reverse("profil_pacijenta", args=[pacijent.id]),
                "akcija": "Prikaži pacijenta",
            })

    if komisijski_v2:
        for red in komisijski_plan_redovi:
            if red.get("za_pregled"):
                prioriteti.append({
                    "tip": "Potrebna provjera",
                    "badge": "amber",
                    "severity_rank": 2,
                    "naslov": f"{red['pacijent'].ime} {red['pacijent'].prezime}",
                    "opis": red["status_razlog"],
                    "pacijent_id": red["pacijent"].pk,
                    "pacijent_url": reverse(
                        "profil_pacijenta", args=[red["pacijent"].pk]
                    ),
                    "url": f"{reverse('komisijski_centar')}?filter=pregled",
                    "akcija": "Provjeri podatke",
                })
                continue
            if red["status"] not in {"ZA_KOMISIJU", "KRITICNO"}:
                continue
            rizik_dostave = bool(
                red.get("ocekivani_datum_dolaska")
                and red.get("rizicna_terapija")
                and red["ocekivani_datum_dolaska"] > red["rizicna_terapija"]
            )
            prioriteti.append({
                "tip": "Rizik dostave" if rizik_dostave else "Komisijski rizik",
                "badge": "red" if red["status"] == "KRITICNO" else "amber",
                "severity_rank": 0 if red["status"] == "KRITICNO" else 1,
                "naslov": f"{red['pacijent'].ime} {red['pacijent'].prezime}",
                "opis": red["status_razlog"],
                "pacijent_id": red["pacijent"].pk,
                "pacijent_url": reverse(
                    "profil_pacijenta",
                    args=[red["pacijent"].pk],
                ),
                "url": reverse("komisijski_centar"),
                "akcija": "Otvori komisije",
            })
    else:
        for potreba in komisije_uskoro_sve:
            nabavka = procurement_breakdown(
                potreba["za_novu_komisiju"],
                potreba["lijek"],
            )
            prioriteti.append({
                "tip": "Komisijski rizik",
                "badge": "amber",
                "severity_rank": 1,
                "naslov": f"{potreba['pacijent'].ime} {potreba['pacijent'].prezime}",
                "opis": (
                    f"{potreba['lijek'].naziv} · potreba {potreba['izracunata_potreba']} doza; "
                    f"tražiti {nabavka['display_text']}"
                ),
                "pacijent_id": potreba["pacijent"].pk,
                "pacijent_url": reverse(
                    "profil_pacijenta",
                    args=[potreba["pacijent"].pk],
                ),
                "url": reverse("komisijski_centar"),
                "akcija": "Otvori komisije",
            })

    for zaliha in kriticne_zalihe_sve:
        prioriteti.append({
            "tip": "Nedovoljna zaliha",
            "badge": "red",
            "severity_rank": 0,
            "naslov": zaliha["lijek"].naziv,
            "opis": f"{zaliha['status_razlog']} {zaliha['preporucena_akcija']}.",
            "url": reverse("lista_zaliha"),
            "akcija": "Otvori zalihe",
        })

    # Jedan pacijent može u istom trenutku imati strukturirani i komisijski
    # signal. Na početnoj se prikazuje samo najteži operativni zaključak.
    prioriteti.sort(key=lambda item: item.get("severity_rank", 2))
    jedinstveni_prioriteti = []
    vidjeni_pacijenti = set()
    for prioritet in prioriteti:
        pacijent_id = prioritet.get("pacijent_id")
        if pacijent_id and pacijent_id in vidjeni_pacijenti:
            continue
        if pacijent_id:
            vidjeni_pacijenti.add(pacijent_id)
        jedinstveni_prioriteti.append(prioritet)
    prioriteti = jedinstveni_prioriteti

    broj_komisija_uskoro = (
        komisijski_dashboard["broj_uskoro"]
        if komisijski_v2
        else len(komisije_uskoro_sve)
    )
    broj_kriticnih_zaliha = len(kriticne_zalihe_sve)
    broj_prioriteta = len(prioriteti)
    glavni_prioritet = prioriteti[0] if prioriteti else None
    broj_ostalih_prioriteta = max(broj_prioriteta - 1, 0)
    if glavni_prioritet and glavni_prioritet["tip"] == "Rizik dostave":
        prioriteti_url = f"{reverse('komisijski_centar')}?filter=rizik_dostave"
    elif glavni_prioritet and glavni_prioritet["tip"] == "Komisijski rizik":
        prioriteti_url = reverse("komisijski_centar")
    elif glavni_prioritet and "zaliha" in glavni_prioritet["tip"].lower():
        prioriteti_url = reverse("lista_zaliha")
    else:
        prioriteti_url = reverse("alarm_centar")
    if danasnje_terapije == 0:
        danasnji_pregled = ["Danas nema planiranih terapija."]
    else:
        if danasnje_terapije == 1:
            operativni_sazetak = "Danas je planirana 1 terapija."
        else:
            operativni_sazetak = (
                f"Danas su planirane {danasnje_terapije} "
                f"{oblik_broja(danasnje_terapije, 'terapija', 'terapije', 'terapija')}."
            )
        prvi_danasnji = termini_danas_panel[0]
        if prvi_danasnji.vrijeme:
            operativni_sazetak += (
                f" Prvi termin je u {prvi_danasnji.vrijeme:%H:%M}."
            )
        danasnji_pregled = [operativni_sazetak]

    if kriticne_zalihe_sve:
        danasnji_pregled.append(
            "Potrebna je provjera kritične zalihe lijeka "
            f"{kriticne_zalihe_sve[0]['lijek'].naziv}."
        )

    komisijska_naredna_akcija = None
    if komisijski_dashboard:
        if komisijski_dashboard["broj_uskoro"]:
            komisijska_naredna_akcija = {
                "label": "Sljedeća akcija",
                "value": "Pokrenuti pripremu komisije",
            }
        elif komisijski_dashboard.get("rizik"):
            komisijska_naredna_akcija = {
                "label": "Sljedeća akcija",
                "value": "Provjeriti rizik dostave",
            }
        elif komisijski_dashboard["broj_kriticnih"]:
            komisijska_naredna_akcija = {
                "label": "Sljedeća akcija",
                "value": "Provjeriti kritične pacijente",
            }
        elif komisijski_dashboard.get("broj_za_pregled"):
            komisijska_naredna_akcija = {
                "label": "Potrebna provjera",
                "value": "Dovršiti konfiguraciju terapijskog plana",
            }
        else:
            komisijska_naredna_akcija = {
                "label": "Status ciklusa",
                "value": "Nema pripreme za pokretanje",
            }

    today_iso = danas.isoformat()
    terapijski_centar_danas_url = f"{reverse('terapijski_centar')}?view=day&date={today_iso}"
    dashboard_cards = [
        {
            "label": "Današnje terapije",
            "value": danasnje_terapije,
            "url": terapijski_centar_danas_url,
            "meta": otkazani_termini_meta,
        },
        {
            "label": "Čekaju potvrdu",
            "value": cekaju_potvrdu,
            "url": f"{terapijski_centar_danas_url}&status=zakazan",
        },
        {
            "label": "Komisije uskoro",
            "value": broj_komisija_uskoro,
            "url": reverse("komisijski_centar"),
        },
        {
            "label": "Kritične zalihe",
            "value": broj_kriticnih_zaliha,
            "url": reverse("lista_zaliha"),
        },
    ]

    context = {
        "pacijenti": Pacijent.objects.filter(aktivan=True)[:10],
        "ukupno_aktivnih": Pacijent.objects.filter(aktivan=True).count(),
        "pacijenti_danas": danasnje_terapije,
        "pacijenti_sutra": termini_sutra_count,
        "komisije_uskoro": broj_komisija_uskoro,
        "niske_zalihe": broj_kriticnih_zaliha,
        "alarm_pacijenti": alarm_pacijenti,
        "plan_potreba": plan_potreba,
        "broj_alarma": len(alarm_pacijenti),
        "dashboard_cards": dashboard_cards,
        "danasnji_pregled": danasnji_pregled,
        "danasnji_pregled_warning": bool(kriticne_zalihe_sve),
        "danasnje_terapije": danasnje_terapije,
        "cekaju_potvrdu": cekaju_potvrdu,
        "kriticne_zalihe": broj_kriticnih_zaliha,
        "prioriteti": prioriteti[:6],
        "broj_prioriteta": broj_prioriteta,
        "glavni_prioritet": glavni_prioritet,
        "broj_ostalih_prioriteta": broj_ostalih_prioriteta,
        "prioriteti_url": prioriteti_url,
        "today_iso": today_iso,
        "uloga": korisnik_uloga(request.user),
        "je_admin": je_admin(request.user),
        "je_doktor": je_doktor(request.user),
        "je_sestra": je_sestra(request.user),
        "alarm_centar": alarm_centar,
        "kriticni_alarmi": alarm_centar["kriticni"],
        "upozorenja_alarmi": alarm_centar["upozorenja"],
        "informacije_alarmi": alarm_centar["informacije"],
        "broj_kriticnih": len(alarm_centar["kriticni"]),
        "broj_upozorenja": len(alarm_centar["upozorenja"]),
        "trebovanja_u_toku": trebovanja_u_toku,
        "komisije_uskoro_panel": komisije_uskoro_panel,
        "termini_danas_panel": termini_danas_panel,
        "prvi_naredni_aktivni_termin": prvi_naredni_aktivni_termin,
        "otkazani_termini_danas": otkazani_termini_danas,
        "otkazani_termini_meta": otkazani_termini_meta,
        "terapije_ovaj_mjesec": terapije_ovaj_mjesec,
        "potrosene_doze_mjesec": potrosene_doze_mjesec,
        "aktivna_trebovanja": aktivna_trebovanja,
        "aktivne_komisije": aktivne_komisije,
        "komisijski_v2": komisijski_v2,
        "komisijski_dashboard": komisijski_dashboard,
        "komisijska_naredna_akcija": komisijska_naredna_akcija,
        "komisijski_plan_redovi": komisijski_plan_redovi,
        
    }

    return render(request, "dashboard/dashboard.html", context)

def _ustekinumab_nursing_ui(
    *,
    state,
    protocol,
    today_appointment,
    operational_appointment,
    can_manage_protocol,
    can_schedule,
    can_manage_home,
    home_issue_available,
):
    """Prezentacijski sloj za jednostavan sestrinski prikaz protokola."""

    if not state or not protocol:
        return {
            "configured": False,
            "status": "Protokol nije kompletno podešen",
            "action": "EDIT" if can_manage_protocol else "NONE",
            "action_label": "Uredi protokol" if can_manage_protocol else "",
            "action_hint": (
                "Doktor ili administrator treba dovršiti podešavanje protokola."
                if not can_manage_protocol else ""
            ),
            "next_date": None,
            "has_current_stock": False,
        }

    phase = state.faza
    current_product = protocol["current_product"]
    current_route = current_product.put_primjene if current_product else ""
    next_date = (
        today_appointment.datum
        if today_appointment else
        operational_appointment.datum
        if operational_appointment else
        protocol["next_expected_dose"]
    )
    action = "NONE"
    action_label = ""
    action_hint = ""
    scheduling_readiness = protocol.get("scheduling_readiness") or {}

    if today_appointment:
        status = (
            "Potrebno potvrditi IV indukciju"
            if current_route == "IV" else
            "Potrebno potvrditi SC terapiju"
        )
        action = "CONFIRM"
        action_label = "Potvrdi terapiju"
    elif home_issue_available and can_manage_home and not protocol["is_home_sc"]:
        status = "Može se izdati kućna terapija"
        action = "ISSUE_HOME"
        action_label = "Izdaj kućnu terapiju"
    elif protocol["is_home_sc"]:
        status = "Kućna terapija je aktivna"
        action_hint = "Pratiti naredno izdavanje prema potvrđenom intervalu."
    elif operational_appointment:
        status = "Terapija je zakazana"
        action_hint = "Na datum termina potrebno je potvrditi primjenu."
    else:
        if phase == state.FAZA_CEKA_IV:
            if not scheduling_readiness.get("ready"):
                status = "Nedovoljna količina za zakazivanje"
                action_hint = (
                    scheduling_readiness.get("reason")
                    or "Unesite odobrenu količinu IV indukcije."
                )
            else:
                status = "Potrebno zakazati IV indukciju"
                action_label = "Zakaži IV indukciju"
        elif phase == state.FAZA_CEKA_PRVU_SC:
            status = "Potrebno zakazati prvu SC terapiju"
            action_label = "Zakaži prvu SC terapiju"
        else:
            status = "Potrebno zakazati SC terapiju"
            action_label = "Zakaži SC terapiju"
        if action_label and can_schedule:
            action = "SCHEDULE"
        elif action_label:
            action_hint = "Zakazivanje obavlja ovlašteni član terapijskog tima."

    return {
        "configured": True,
        "status": status,
        "action": action,
        "action_label": action_label,
        "action_hint": action_hint,
        "next_date": next_date,
        "has_current_stock": bool(
            Decimal(str(protocol.get("patient_reserved") or 0))
            >= Decimal(str((protocol.get("phase") or {}).get("units") or 0))
            > 0
        ),
    }


@login_required
def profil_pacijenta(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    saglasnost_prijedlog = patient_agreement_suggestion(pacijent)
    historija_saglasnosti = list(
        PacijentSaglasnost.objects.filter(pacijent=pacijent)
        .select_related("izmijenio", "izvorni_ciklus")
        .order_by("-vazi_od", "-id")
    )
    if not historija_saglasnosti and saglasnost_prijedlog.exists:
        historija_saglasnosti = [saglasnost_prijedlog]
    oralni_status = None
    if (
        (pacijent.lijek_id and pacijent.lijek.oralna_terapija)
        or OralniTerapijskiRezim.objects.filter(pacijent=pacijent).exists()
    ):
        oralni_status = oral_therapy_status(pacijent)
    status_pacijenta = izracunaj_status_pacijenta(pacijent)
    fazni_state_za_prikaz = pacijent.aktivni_fazni_protokol()
    komisijski_v2 = commission_demand_v2_enabled()
    komisijski_plan = (
        commission_planning_row_for_patient(pacijent)
        if komisijski_v2
        else None
    )
    # Pacijentov tab Komisije uvijek koristi kanonski planner, nezavisno od
    # toga da li je napredni V2 panel trenutno vidljiv kroz feature flag.
    # Ovo je isti red koji koriste Pokrivenost i Komisijski centar.
    komisijski_plan_za_karton = (
        komisijski_plan
        if komisijski_plan is not None
        else commission_planning_row_for_patient(pacijent)
    )
    if (
        komisijski_plan_za_karton
        and (komisijski_plan_za_karton.get("sljedeci_korak") or "")
        .strip().casefold() == "otvori karton"
    ):
        # Na kartonu ta poruka nije radnja: korisnik je već na kartonu.
        # Zamjenjujemo samo presentation label, bez promjene planner odluke.
        komisijski_plan_za_karton["sljedeci_korak"] = (
            "Pregledajte prijedlog"
            if komisijski_plan_za_karton.get("included_in_draft")
            else "Uključite pacijenta u komisiju"
            if (
                komisijski_plan_za_karton.get("nova_komisija_potrebna")
                or komisijski_plan_za_karton.get("za_pregled")
                or komisijski_plan_za_karton.get("rizik_dostave")
            )
            else "Nije potrebna trenutna akcija"
        )
    oralni_operativni_plan = None
    if oralni_status:
        # Protokol koristi isti centralni red kao Pokrivenost, Zalihe i
        # Komisijski centar, čak i kada je opšti V2 panel skriven feature
        # flagom. Time buduća klinička projekcija ne glumi trenutnu akciju.
        oralni_operativni_plan = (
            komisijski_plan
            if komisijski_plan is not None
            else commission_planning_row_for_patient(pacijent)
        )
    oral_issue_form = None
    if oralni_status and oralni_status.get("medicine"):
        oral_issue_form = OralnoIzdavanjeForm(
            regimen=oralni_status.get("regimen"),
            approval_options=oralni_status.get("approval_options"),
            physical_available=oralni_status.get("physical_available"),
            next_planned_issue=oralni_status.get("next_uncovered"),
            quantity_at_patient=oralni_status.get("quantity_at_patient"),
        )
    if (
        komisijski_plan
        and not status_pacijenta.get("aktivna_komisija")
        and Decimal(str(status_pacijenta.get("rezervisano_u_frizideru_za_pacijenta") or 0))
        + Decimal(str(status_pacijenta.get("kod_pacijenta") or 0)) > 0
        and not komisijski_plan.get("included_in_draft")
        and not komisijski_plan.get("rizik_dostave")
        and Decimal(str(komisijski_plan.get("final_procurement_units") or 0)) <= 0
    ):
        fizicki_pokriven_do = komisijski_plan.get("fizicki_pokriven_do_operativno")
        status_pacijenta["status"] = (
            f"Fizički pokriven do {fizicki_pokriven_do:%d.%m.%Y.}"
            if fizicki_pokriven_do else "Fizički pokriven"
        )
        status_pacijenta["status_css"] = "status-kucna-terapija"
        status_pacijenta["administrativni_status"] = (
            "Bez vlastitog komisijskog odobrenja"
        )
        status_pacijenta["administrativni_status_css"] = "status-komisija"
    coverage_calculation = (
        komisijski_plan_za_karton.get("coverage_calculation")
        if komisijski_plan_za_karton else None
    )
    commission_decision = (
        komisijski_plan_za_karton.get("commission_decision")
        if komisijski_plan_za_karton else None
    )
    # Kućna projekcija i kanonski rezultat dolaze iz istog planner poziva.
    # Karton više ne pokreće paralelnu projekciju s drugim delivery datumom.
    home_projection = (
        komisijski_plan_za_karton.get("home_projection")
        if coverage_calculation is not None else None
    )
    if (
        home_projection is None
        and pacijent.lijek_id
        and pacijent.trenutni_korak_je_kucna_terapija()
    ):
        # Kompatibilni fallback za lijek bez podrške u commission planneru.
        home_projection = calculate_home_therapy_projection(pacijent)
    if coverage_calculation is not None:
        status_pacijenta["pokriven_do"] = (
            coverage_calculation.physically_secured_until
        )
        status_pacijenta["sljedece_izdavanje"] = (
            coverage_calculation.next_dispensing_date
        )
        status_pacijenta["status"] = coverage_calculation.status_label
        status_pacijenta["status_razlog"] = (
            coverage_calculation.warning_text
            or coverage_calculation.current_action
        )
        status_pacijenta["status_css"] = (
            "status-hitno"
            if coverage_calculation.immediate_risk
            else "status-kucna-terapija"
        )

    aktivna_komisija = status_pacijenta["aktivna_komisija"]
    aktivne_komisije = status_pacijenta.get("aktivne_komisije", [])
    zaduzeno_lijekova = status_pacijenta["kod_pacijenta"]
    potrebe_komisije = (
        komisijski_plan
        if komisijski_v2 and komisijski_plan
        else status_pacijenta["potrebe_komisije"]
    )
    # Karton koristi isti kanonski Commission Service rezultat kao izračun
    # nove komisije; ovo je isključivo neiskorišteno odobreno pravo.
    preostalo_po_komisiji = potrebe_komisije.get("odobreno_preostalo", Decimal("0"))
    doze_za_komisiju = potrebe_komisije["za_novu_komisiju"]

    trebovanja = Trebovanje.objects.filter(
        pacijent=pacijent
    ).order_by("-datum_kreiranja")
    napomene_pacijenta = list(
        AktivnostLog.objects.filter(
            pacijent=pacijent,
            akcija="Napomena pacijenta",
        ).select_related("korisnik").order_by("-datum_vrijeme", "-id")[:20]
    )

    dokumenti_pacijenta = DokumentPacijenta.objects.filter(
        pacijent=pacijent,
        aktivan=True,
    ).order_by("-datum_dokumenta", "-datum_uploada")

    # Tab Komisije je strogo pacijent-centričan. Sažetak koristi centralni
    # coverage servis koji filtrira pravo po pacijentu i ekvivalentnoj
    # trenutnoj terapiji; historijski redovi dolaze isključivo preko
    # pacijentovog FK-a i nikada iz agregata cijelog komisijskog ciklusa.
    komisije = list(
        pacijent.komisija_set.select_related("lijek").order_by(
            "-datum_odobrenja",
            "-id",
        )
    )
    pacijent_komisijsko_pokrice = patient_commission_coverage(pacijent)
    pacijentu_odobreno = Decimal(str(
        pacijent_komisijsko_pokrice.get("approved_total") or 0
    ))
    pacijentu_preostalo_odobreno = Decimal(str(
        pacijent_komisijsko_pokrice.get("approved_remaining") or 0
    ))
    pacijentu_iskoristeno_odobrenje = max(
        Decimal("0"),
        pacijentu_odobreno - pacijentu_preostalo_odobreno,
    )
    procenat_iskoristenog_odobrenja = (
        max(
            0,
            min(
                100,
                int(round(
                    pacijentu_iskoristeno_odobrenje
                    * Decimal("100")
                    / pacijentu_odobreno
                )),
            ),
        )
        if pacijentu_odobreno > 0
        else 0
    )
    pacijentu_pokriveno_do = (
        coverage_calculation.physically_secured_until
        if coverage_calculation is not None else (
            home_projection.physical_covered_until
            if home_projection and home_projection.date_plan_reliable
            else None
        )
    )
    if (
        pacijentu_pokriveno_do is None
        and aktivna_komisija
        and pacijentu_preostalo_odobreno > 0
    ):
        pacijentu_pokriveno_do, _ = pacijent.izracunaj_pokriven_do(
            pacijentu_preostalo_odobreno,
            fallback_date=aktivna_komisija.datum_odobrenja,
        )

    planirani_ciklus = None
    planirana_komisija = None
    rok_pripreme = None
    komisijska_akcija_potrebna = False
    sljedeci_korak = "Nije potrebna trenutna akcija."
    sljedeci_korak_detalj = ""
    if komisijski_plan_za_karton:
        planirani_ciklus = (
            coverage_calculation.commission_window
            if coverage_calculation is not None else (
                komisijski_plan_za_karton.get("planirati_za_komisiju")
                or komisijski_plan_za_karton.get("preporuceni_komisijski_ciklus")
            )
        )
        planirana_komisija = (
            commission_decision.cycle_date
            if commission_decision is not None else (
                getattr(planirani_ciklus, "datum_komisije", None)
                if planirani_ciklus else None
            )
        )
        komisijska_akcija_potrebna = bool(
            (
                coverage_calculation.immediate_risk
                if coverage_calculation is not None else False
            )
            or (
                commission_decision.is_action_required
                if commission_decision is not None else False
            )
            or (
                komisijski_plan_za_karton.get("nova_komisija_potrebna")
                or komisijski_plan_za_karton.get("za_pregled")
                or komisijski_plan_za_karton.get("rizik_dostave")
                or komisijski_plan_za_karton.get("included_in_draft")
            )
        )
        if not planirana_komisija and komisijska_akcija_potrebna:
            planirana_komisija = komisijski_plan_za_karton.get(
                "naredna_administrativna_komisija"
            )
        rok_pripreme = (
            coverage_calculation.preparation_date
            if coverage_calculation is not None else (
                (
                    getattr(planirani_ciklus, "rok_pripreme", None)
                    if planirani_ciklus else None
                ) or komisijski_plan_za_karton.get(
                    "posljednji_siguran_datum_za_ukljucivanje"
                )
            )
        )
        sljedeci_korak = (
            komisijski_plan_za_karton.get("sljedeci_korak")
            or "Nije potrebna trenutna akcija"
        ).strip()
        if sljedeci_korak[-1:] not in ".!?":
            sljedeci_korak += "."
        if planirana_komisija:
            if komisijska_akcija_potrebna:
                sljedeci_korak_detalj = (
                    f"Za komisiju {planirana_komisija:%d/%m/%Y}."
                )
                if rok_pripreme:
                    sljedeci_korak_detalj += (
                        f" Zahtjev pripremiti do {rok_pripreme:%d/%m/%Y}."
                    )
            else:
                sljedeci_korak_detalj = (
                    "Planirana naredna komisija: "
                    f"{planirana_komisija:%d/%m/%Y}."
                )
        elif komisijski_plan_za_karton.get("status_razlog"):
            sljedeci_korak_detalj = komisijski_plan_za_karton["status_razlog"]

    aktivni_proizvod = (
        aktivna_komisija.lijek
        if aktivna_komisija else (
            komisijski_plan_za_karton.get("potreban_proizvod")
            if komisijski_plan_za_karton else pacijent.trenutni_proizvod
        )
    )
    aktivni_proizvod_naziv = "Nije definisan"
    if aktivni_proizvod:
        aktivni_proizvod_naziv = " ".join(
            dio for dio in (
                aktivni_proizvod.brand_name,
                aktivni_proizvod.presentation_strength_label,
                aktivni_proizvod.put_primjene,
            ) if dio
        )
    posljednje_odobrenje = next(
        (
            komisija for komisija in komisije
            if Decimal(str(komisija.broj_odobrenih_doza or 0)) > 0
        ),
        None,
    )
    posljednje_odobreno = Decimal(str(
        getattr(posljednje_odobrenje, "broj_odobrenih_doza", 0) or 0
    ))
    posljednje_preostalo = Decimal(str(
        getattr(posljednje_odobrenje, "preostale_doze", 0) or 0
    ))
    posljednje_razduzeno = max(
        Decimal("0"),
        posljednje_odobreno - posljednje_preostalo,
    )
    klinicki_primijenjeno = (
        home_projection.administered_quantity
        if home_projection else Decimal("0")
    )
    buduce_doze_kod_pacijenta = Decimal("0")
    if (
        home_projection
        and home_projection.units_per_application > 0
    ):
        buduce_doze_kod_pacijenta = (
            home_projection.patient_quantity
            // home_projection.units_per_application
        )
    nacrt_kolicina = Decimal(str(
        (komisijski_plan_za_karton or {}).get("final_procurement_units") or 0
    ))
    nacrt_nabavka = (
        procurement_breakdown(nacrt_kolicina, aktivni_proizvod)
        if aktivni_proizvod and nacrt_kolicina > 0 else None
    )
    pacijent_komisijski_sazetak = {
        "odobreno": pacijentu_odobreno,
        "preostalo": pacijentu_preostalo_odobreno,
        "iskoristeno": pacijentu_iskoristeno_odobrenje,
        "procenat_iskoristeno": procenat_iskoristenog_odobrenja,
        "datum_odobrenja": (
            aktivna_komisija.datum_odobrenja if aktivna_komisija else None
        ),
        "broj_saglasnosti": (
            saglasnost_prijedlog.number
        ),
        "status": (
            aktivna_komisija.get_status_display()
            if aktivna_komisija else "Nema aktivnog odobrenja"
        ),
        "status_kod": aktivna_komisija.status if aktivna_komisija else "",
        "ima_aktivno_odobrenje": bool(aktivna_komisija),
        "posljednje_odobreno": posljednje_odobreno,
        "posljednje_razduzeno": posljednje_razduzeno,
        "posljednje_odobrenje": posljednje_odobrenje,
        "klinicki_primijenjeno": klinicki_primijenjeno,
        "kod_pacijenta": (
            home_projection.patient_quantity
            if home_projection else Decimal(str(status_pacijenta["kod_pacijenta"] or 0))
        ),
        "rezervisano": (
            home_projection.reserved_quantity
            if home_projection else Decimal(str(
                status_pacijenta["rezervisano_u_frizideru_za_pacijenta"] or 0
            ))
        ),
        "buduce_doze_kod_pacijenta": buduce_doze_kod_pacijenta,
        "pokriveno_do": pacijentu_pokriveno_do,
        "lijek": pacijent.lijek,
        "terapija_naziv": pacijent.terapija_za_prikaz,
        "proizvod": aktivni_proizvod,
        "proizvod_naziv": aktivni_proizvod_naziv,
        "planirana_komisija": planirana_komisija,
        "rok_pripreme": rok_pripreme,
        "komisijska_akcija_potrebna": komisijska_akcija_potrebna,
        "sljedeci_korak": sljedeci_korak,
        "sljedeci_korak_detalj": sljedeci_korak_detalj,
        "naredna_komisija_napomena": (
            komisijski_plan_za_karton.get("status_oznaka")
            if komisijska_akcija_potrebna and komisijski_plan_za_karton
            else "Sistem prati naredni sigurni ciklus"
        ),
        "ukljucen_u_nacrt": bool(
            (komisijski_plan_za_karton or {}).get("included_in_draft")
        ),
        "nacrt_nabavka": nacrt_nabavka,
    }
    for komisija in komisije:
        komisija.pacijentu_odobreno = Decimal(str(
            komisija.broj_odobrenih_doza or 0
        ))
        komisija.pacijentu_preostalo = Decimal(str(
            komisija.preostale_doze or 0
        ))
        komisija.pacijentu_iskoristeno = max(
            Decimal("0"),
            komisija.pacijentu_odobreno - komisija.pacijentu_preostalo,
        )
        komisija.pacijentu_pokriveno_do = komisija.terapija_pokrivena_do()
        komisija.pacijentu_proizvod_naziv = " ".join(
            dio for dio in (
                komisija.lijek.brand_name,
                komisija.lijek.presentation_strength_label,
                komisija.lijek.put_primjene,
            ) if dio
        )
        komisija.pacijentu_terapija_naziv = (
            komisija.lijek.generic_name
            or komisija.lijek.therapeutic_group_name
        )
    historijske_komisije = [
        komisija for komisija in komisije
        if not aktivna_komisija or komisija.pk != aktivna_komisija.pk
    ]
    komisijski_zahtjevi = list(
        pacijent.komisijski_zahtjevi_faza1.select_related(
            "komisijski_ciklus",
            "source_therapy_change",
            "request_type_finalized_by",
        ).order_by("-datum_kreiranja", "-pk")
    )
    terapije = pacijent.terapija_set.exclude(
        lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA
    ).order_by("-datum", "-id")
    termini = pacijent.termin_set.exclude(
        lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA
    ).order_by("-datum", "-vrijeme")
    zaduzenja = pacijent.pacijentzaduzenje_set.all().order_by("-datum_zaduzenja")
    kucna_izdavanja = list(pacijent.kucna_izdavanja.select_related(
        "lijek",
        "komisija",
        "korisnik_koji_je_izdao",
    ).order_by("-datum", "-id"))
    rezervacije_u_frizideru = list(
        PacijentRezervacija.objects.filter(
            pacijent=pacijent,
            lijek_id__in=(pacijent.lijek.equivalent_ids() if pacijent.lijek_id else []),
            aktivno=True,
            kolicina__gt=0,
        ).select_related("lijek").order_by("-datum_rezervacije", "-id")
    )
    dodjele_slobodne_zalihe = list(
        ZalihaTransakcija.objects.filter(
            pacijent=pacijent,
            lijek_id__in=(pacijent.lijek.equivalent_ids() if pacijent.lijek_id else []),
            tip=ZalihaTransakcija.TIP_DODJELA_SLOBODNE_ZALIHE,
        ).select_related("lijek", "korisnik").order_by("-kreirano", "-id")
    )
    release_ids = [
        item.referenca_id for item in dodjele_slobodne_zalihe
        if item.referenca_tip == "ZalihaTransakcija" and item.referenca_id
    ]
    release_by_id = {
        item.pk: item
        for item in ZalihaTransakcija.objects.filter(pk__in=release_ids).select_related(
            "pacijent", "korisnik", "lijek"
        )
    }
    for dodjela in dodjele_slobodne_zalihe:
        dodjela.izvor_oslobadjanja = release_by_id.get(dodjela.referenca_id)
        dodjela.kolicina_prikaz = format_stock_quantity(
            dodjela.lijek, dodjela.kolicina
        )
    for rezervacija in rezervacije_u_frizideru:
        rezervacija.kolicina_prikaz = format_stock_quantity(
            rezervacija.lijek, rezervacija.kolicina
        )
    promjene_terapije = pacijent.promjene_terapije.select_related(
        "stari_lijek",
        "novi_lijek",
        "izvrsio",
    )
    historija_protokola = IzmjenaIndividualnogProtokola.objects.filter(
        protokol__pacijent=pacijent,
    ).select_related("korisnik").order_by("-datum_izmjene", "-id")
    historija_statusa_terapije = TerapijaStatusHistorija.objects.filter(
        pacijent=pacijent,
    ).select_related("korisnik", "termin", "terapija").order_by("-datum_vrijeme", "-id")
    aktivna_zaduzenja = zaduzenja.filter(aktivno=True, preostalo__gt=0)
    for zaduzenje in zaduzenja:
        zaduzenje.potroseno_iz_zaduzenja = max(
            Decimal("0"),
            Decimal(str(zaduzenje.ukupno_zaduzeno or 0))
            - Decimal(str(zaduzenje.preostalo or 0))
        )
        zaduzenje.ukupno_zaduzeno_prikaz = format_stock_quantity(
            zaduzenje.lijek, zaduzenje.ukupno_zaduzeno
        )
        zaduzenje.preostalo_prikaz = format_stock_quantity(
            zaduzenje.lijek, zaduzenje.preostalo
        )
        zaduzenje.potroseno_prikaz = format_stock_quantity(
            zaduzenje.lijek, zaduzenje.potroseno_iz_zaduzenja
        )
        zaduzenje.komisija_prikaz = (
            f"{zaduzenje.komisija.datum_odobrenja:%d/%m/%Y} · "
            f"{zaduzenje.komisija.broj_saglasnosti + ' · ' if zaduzenje.komisija.broj_saglasnosti else ''}"
            f"{zaduzenje.komisija.get_status_display()}"
            if zaduzenje.komisija_id else "Nije povezana"
        )
    for izdavanje in kucna_izdavanja:
        izdavanje.kolicina_prikaz = format_stock_quantity(
            izdavanje.lijek, izdavanje.kolicina
        )
        izdavanje.komisija_prikaz = (
            f"{izdavanje.komisija.datum_odobrenja:%d/%m/%Y} · "
            f"{izdavanje.komisija.broj_saglasnosti + ' · ' if izdavanje.komisija.broj_saglasnosti else ''}"
            f"{izdavanje.komisija.get_status_display()}"
            if izdavanje.komisija_id else "Nije povezana"
        )
    odobreno_komisijom = status_pacijenta["odobreno_komisijom"]
    zaprimljeno_u_ustanovi = rezervisano_u_frizideru_za_pacijenta(pacijent, pacijent.lijek)
    dodijeljeno_pacijentu = sum(
        (Decimal(str(z.ukupno_zaduzeno or 0)) for z in zaduzenja),
        Decimal("0")
    )
    kod_pacijenta = status_pacijenta["kod_pacijenta"]
    u_frizideru = (
        home_projection.reserved_quantity
        if home_projection else zaprimljeno_u_ustanovi
    )
    potroseno = sum(
        (
            Decimal(str(t.kolicina or 0))
            for t in terapije
            if not t.is_migration
        ),
        Decimal("0")
    )
    potroseno_aktivna_komisija = Decimal("0")
    if aktivne_komisije:
        potroseno_aktivna_komisija = sum(
            (
                max(
                    Decimal("0"),
                    Decimal(str(komisija.broj_odobrenih_doza or 0))
                    - Decimal(str(komisija.preostale_doze or 0)),
                )
                for komisija in aktivne_komisije
            ),
            Decimal("0"),
        )
    potroseno_iz_zaduzenja = max(
        Decimal("0"),
        dodijeljeno_pacijentu - kod_pacijenta
    )
    doza_po_aplikaciji = Decimal(str(pacijent.doza_po_aplikaciji() or 0))

    terapije_po_lijeku_redni_broj = defaultdict(int)
    terapije_za_prikaz = list(pacijent.terapija_set.all().order_by("datum", "id"))
    from patients.therapy_history import is_actually_administered_therapy

    for terapija in terapije_za_prikaz:
        terapija.kolicina_prikaz = format_stock_quantity(
            terapija.lijek, terapija.kolicina
        )
        if is_actually_administered_therapy(terapija):
            terapije_po_lijeku_redni_broj[terapija.lijek_id] += 1
        redni_broj = terapije_po_lijeku_redni_broj[terapija.lijek_id]
        if (
            terapija.lijek_id == pacijent.lijek_id
            and is_actually_administered_therapy(terapija)
            and not fazni_state_za_prikaz
        ):
            korak_za_prikaz = pacijent.terapijski_korak_za_redni_broj(redni_broj)
            terapija.terapijski_korak_prikaz = korak_za_prikaz
            terapija.faza_terapije = pacijent.terapijska_faza_za_redni_broj(redni_broj)
            if korak_za_prikaz and not terapija.doza_mg:
                terapija.doza_mg = korak_za_prikaz.doza_mg
        else:
            terapija.terapijski_korak_prikaz = terapija.terapijski_korak
    terapije = list(reversed(terapije_za_prikaz))
    zadnje_primljene_terapije = [
        terapija
        for terapija in terapije
        if is_actually_administered_therapy(terapija)
    ][:3]
    from patients.therapy_timeline import build_therapy_timeline

    terapijska_hronologija = build_therapy_timeline(
        therapies=terapije,
        histories=list(historija_statusa_terapije),
    )

    for zaduzenje in zaduzenja:
        zaduzenje.pokriven_do, zaduzenje.pokriven_do_izvor = (
            pacijent.izracunaj_pokriven_do(
                zaduzenje.preostalo,
                fallback_date=zaduzenje.datum_zaduzenja,
            )
        )

    pokriven_do_pacijenta = status_pacijenta["pokriven_do"]
    pokriven_do_izvor = status_pacijenta["pokriven_do_izvor"]
    danasnji_termin = termini.filter(
        datum=timezone.now().date(),
        status="ZAKAZAN"
    ).order_by("vrijeme").first()
    operativni_termin = termini.filter(
        status=Termin.STATUS_PLANIRANA,
        datum__gte=timezone.localdate(),
    ).order_by("datum", "vrijeme", "id").first()
    termini_u_proslosti_za_pregled = termini.filter(
        status=Termin.STATUS_PLANIRANA,
        datum__lt=timezone.localdate(),
    )
    ceka_novi_termin = bool(
        not operativni_termin
        and termini.filter(
            status__in=[
                Termin.STATUS_ODGODJENA,
                Termin.STATUS_NIJE_DOSAO,
                Termin.STATUS_OTKAZANA,
            ],
        ).exists()
    )

    status_upozorenja = status_pacijenta["status"]
    status_upozorenja_klasa = "green"
    if status_pacijenta["status_css"] == "status-hitno":
        status_upozorenja_klasa = "red"
    elif status_pacijenta["status_css"] == "status-kucna-terapija":
        status_upozorenja_klasa = "home"
    elif status_pacijenta["status_css"] == "status-komisija":
        status_upozorenja_klasa = "amber"

    migracijski_snapshot = getattr(pacijent, "migracijski_snapshot", None)
    sistemske_postavke = get_postavke_sistema()
    prikazi_evidentiranje_ranijeg_odobrenja = bool(
        je_admin(request.user)
        and not sistemske_postavke.migracija_zakljucana
    )
    vanredni_context = extraordinary_request_context(pacijent)
    kreiran_vanredni = None
    kreiran_vanredni_id = request.GET.get("kreiran_vanredni")
    if kreiran_vanredni_id and str(kreiran_vanredni_id).isdigit():
        kreiran_vanredni = extraordinary_requests().filter(
            pk=int(kreiran_vanredni_id),
            pacijent=pacijent,
        ).first()

    protokol_terapije = patient_protocol_display_data(pacijent)
    definicija_kolicine = protokol_terapije["kolicina_po_terapiji"]
    from patients.phased_protocols import (
        phased_protocol_for_patient,
        protocol_display_data,
        ustekinumab_home_issuance_available,
    )

    ustekinumab_state = phased_protocol_for_patient(pacijent)
    ustekinumab_protocol = protocol_display_data(ustekinumab_state)
    ustekinumab_home_issue_available = (
        ustekinumab_home_issuance_available(ustekinumab_state)
    )
    from patients.medication_groups import medicine_group_key

    ustekinumab_setup_visible = bool(
        ustekinumab_state
        or (pacijent.lijek_id and medicine_group_key(pacijent.lijek) == "ustekinumab")
    )
    ustekinumab_setup_form = UstekinumabProtocolSetupForm(
        patient=pacijent,
        state=ustekinumab_state,
    )
    ustekinumab_schedule_form = UstekinumabPhaseScheduleForm(
        initial={
            "datum": (
                ustekinumab_state.sljedeci_datum
                if ustekinumab_state and ustekinumab_state.sljedeci_datum
                else timezone.localdate()
            ),
            "vrijeme": time(9, 0),
        }
    )
    ustekinumab_interval_form = UstekinumabIntervalChangeForm(
        initial={
            "interval_odrzavanja_sedmica": (
                ustekinumab_state.interval_odrzavanja_sedmica
                if ustekinumab_state else 8
            )
        }
    )
    moze_upravljati_terapijskim_workflowom = je_doktor_ili_admin(request.user)
    moze_promijeniti_ustekinumab_sc_nacin = je_terapijski_tim(request.user)
    ustekinumab_nursing_ui = _ustekinumab_nursing_ui(
        state=ustekinumab_state,
        protocol=ustekinumab_protocol,
        today_appointment=danasnji_termin,
        operational_appointment=operativni_termin,
        can_manage_protocol=moze_upravljati_terapijskim_workflowom,
        can_schedule=je_terapijski_tim(request.user),
        can_manage_home=moze_promijeniti_ustekinumab_sc_nacin,
        home_issue_available=ustekinumab_home_issue_available,
    ) if ustekinumab_setup_visible else None

    # Karton pacijenta je operativni ekran: sve istaknute vrijednosti ispod
    # dolaze iz već izračunatih termina, fizičke pokrivenosti i kanonskog
    # commission plannera. Template ne računa paralelne datume ili količine.
    home_issue_availability = home_therapy_issue_availability(pacijent)
    can_issue_home_therapy = je_sestra_ili_admin(request.user)
    home_therapy_action = {
        "visible": bool(
            can_issue_home_therapy and home_issue_availability.visible
        ),
        "enabled": bool(
            can_issue_home_therapy and home_issue_availability.enabled
        ),
        "reason": home_issue_availability.reason,
        "status_label": home_issue_availability.status_label,
    }
    prikazi_izdaj_kucnu_terapiju = home_therapy_action["visible"]
    home_therapy_form = None
    if home_therapy_action["enabled"]:
        home_package_size = int(home_issue_availability.package_size)
        home_therapy_form = KucnoIzdavanjeForm(
            initial={"kolicina": home_package_size},
            pacijent=pacijent,
            lijek=pacijent.lijek,
            max_quantity=home_issue_availability.fridge_quantity,
            commission_medicine_ids=(
                home_issue_availability.commission_medicine_ids
            ),
        )
    overview_product = (
        getattr(operativni_termin, "lijek", None)
        or pacijent.trenutni_proizvod
        or pacijent.lijek
    )
    coverage_row = (
        (komisijski_plan_za_karton or {}).get("coverage") or {}
    )
    continuity = (komisijski_plan_za_karton or {}).get(
        "kontinuitet_terapije"
    )
    if oralni_status:
        overview_title = "Sljedeće izdavanje"
        overview_date = (
            (komisijski_plan_za_karton or {}).get("sljedece_potrebno_izdavanje")
            or oralni_status.get("next_uncovered")
        )
        overview_therapy = oralni_status.get("medicine_title")
        overview_dose = (
            f"{oralni_status['regimen'].tableta_dnevno:g} tableta dnevno"
            if oralni_status.get("regimen") else "Režim nije potvrđen"
        )
        overview_place = "Kod pacijenta · oralna terapija"
        overview_physical_quantity = Decimal(str(
            coverage_row.get("at_patient") or 0
        ))
        overview_required_quantity = Decimal("1")
        overview_coverage_until = (
            (komisijski_plan_za_karton or {}).get("fizicki_pokriven_do")
            or oralni_status.get("coverage_until")
        )
    elif home_projection:
        overview_title = "Sljedeće izdavanje"
        overview_date = (
            coverage_calculation.next_dispensing_date
            if coverage_calculation is not None else
            home_projection.next_dispensing
            or status_pacijenta.get("sljedece_izdavanje")
        )
        overview_therapy = (
            overview_product.prikaz_naziv
            if overview_product else pacijent.terapija_za_prikaz
        )
        overview_required_quantity = Decimal(str(
            home_issue_availability.package_size if overview_product else 1
        ))
        overview_package = (
            procurement_breakdown(overview_required_quantity, overview_product)
            if overview_product else None
        )
        overview_dose = (
            overview_package["display_text"]
            if overview_package else "Pakovanje nije definisano"
        )
        overview_place = "Kućna terapija"
        overview_physical_quantity = Decimal(str(
            home_projection.patient_quantity or 0
        ))
        overview_coverage_until = (
            coverage_calculation.physically_secured_until
            if coverage_calculation is not None else (
                continuity.safely_covered_until
                if continuity else home_projection.physical_covered_until
            )
        )
    else:
        overview_title = "Sljedeća terapija"
        overview_date = (
            getattr(operativni_termin, "datum", None)
            or status_pacijenta.get("sljedeca_terapija")
        )
        overview_therapy = (
            overview_product.prikaz_naziv
            if overview_product else pacijent.terapija_za_prikaz
        )
        overview_required_quantity = Decimal(str(
            getattr(operativni_termin, "kolicina_po_terapiji", None)
            or pacijent.doza_po_aplikaciji()
            or 1
        ))
        overview_dose = (
            format_stock_quantity(overview_product, overview_required_quantity)
            if overview_product else "Doza nije definisana"
        )
        overview_place = "Ambulanta"
        overview_physical_quantity = Decimal(str(
            coverage_row.get("reserved_in_fridge")
            or status_pacijenta.get("rezervisano_u_frizideru_za_pacijenta")
            or 0
        ))
        overview_coverage_until = (
            (komisijski_plan_za_karton or {}).get(
                "fizicki_pokriven_do_operativno"
            )
            or (komisijski_plan_za_karton or {}).get("fizicki_pokriven_do")
            or pokriven_do_pacijenta
        )

    if overview_physical_quantity >= overview_required_quantity:
        overview_stock_label = "Osigurano"
        overview_stock_css = "is-secured"
    elif overview_physical_quantity > 0:
        overview_stock_label = "Djelimično osigurano"
        overview_stock_css = "is-warning"
    else:
        overview_stock_label = "Nije fizički osigurano"
        overview_stock_css = "is-risk"
    overview_stock_detail = (
        format_stock_quantity(overview_product, overview_physical_quantity)
        if overview_product else f"{overview_physical_quantity:g} doza"
    )
    if continuity and continuity.risk:
        overview_title = "Rizik prekida terapije"
        overview_date = continuity.first_uncovered_therapy
        overview_stock_label = "Nedostaje do isporuke"
        overview_stock_css = "is-risk"

    planned_cycle = (
        coverage_calculation.commission_window
        if coverage_calculation is not None else (
            (komisijski_plan_za_karton or {}).get("planirati_za_komisiju")
            or (komisijski_plan_za_karton or {}).get(
                "preporuceni_komisijski_ciklus"
            )
        )
    )
    planned_cycle_date = (
        (commission_decision.cycle_date if commission_decision else None)
        or getattr(planned_cycle, "datum_komisije", None)
        or (
            (komisijski_plan_za_karton or {}).get(
                "naredna_administrativna_komisija"
            )
            if komisijska_akcija_potrebna else None
        )
    )
    procurement = (
        commission_decision.procurement
        if commission_decision is not None else
        (komisijski_plan_za_karton or {}).get("sistemska_nabavka")
    )
    suggested_quantity = Decimal(str(
        commission_decision.displayed_quantity
        if commission_decision is not None else
        (komisijski_plan_za_karton or {}).get("sistem_predlaze") or 0
    ))
    commission_quantity_display = (
        (
            procurement.get("display_text", "")
            if isinstance(procurement, dict)
            else getattr(procurement, "display_text", "")
        )
        or (
            format_stock_quantity(overview_product, suggested_quantity)
            if overview_product else f"{suggested_quantity:g} doza"
        )
    )
    required_quantity = Decimal(str(
        (komisijski_plan_za_karton or {}).get("ukupno_potrebno") or 0
    ))
    covered_quantity = Decimal(str(
        (komisijski_plan_za_karton or {}).get("vec_pokriveno_za_preporuku")
        or (komisijski_plan_za_karton or {}).get("vec_pokriveno")
        or 0
    ))
    latest_request = komisijski_zahtjevi[0] if komisijski_zahtjevi else None
    commission_status_label = "Trenutno nije potrebna komisija"
    commission_status_css = "green"
    commission_action_label = "Nije potrebna trenutna akcija"
    if latest_request:
        legacy_request = Trebovanje.objects.filter(
            pacijent=pacijent,
            lijek_id__in=(
                pacijent.lijek.equivalent_ids() if pacijent.lijek_id else []
            ),
            komisijski_ciklus=latest_request.komisijski_ciklus,
        ).order_by("-pk").first()
        request_state = resolve_commission_request_state(
            phase2_request=latest_request,
            legacy_request=legacy_request,
            medicine_ids=(
                pacijent.lijek.equivalent_ids() if pacijent.lijek_id else ()
            ),
        )
        commission_status_label = request_state.title
        commission_status_css = request_state.tone
        commission_action_label = request_state.next_action
        planned_cycle_date = (
            latest_request.komisijski_ciklus.datum_komisije
            or planned_cycle_date
        )
    elif (komisijski_plan_za_karton or {}).get("included_in_draft"):
        commission_status_label = "Uključeno u nacrt"
        commission_status_css = "amber"
        commission_action_label = "Pregledajte prijedlog"
    elif komisijska_akcija_potrebna:
        commission_status_label = (
            (komisijski_plan_za_karton or {}).get("status_oznaka")
            or "Potrebno uključiti u komisiju"
        )
        commission_status_css = (
            (komisijski_plan_za_karton or {}).get("status_klasa") or "amber"
        )
        commission_action_label = "Uključite pacijenta u komisiju"

    if continuity and continuity.risk:
        commission_status_label = continuity.status_label
        commission_status_css = "red"
        commission_action_label = continuity.recommended_action_label
    elif commission_decision is not None:
        commission_status_label = commission_decision.status_label
        commission_status_css = commission_decision.status_tone
        commission_action_label = commission_decision.action_label
        planned_cycle_date = commission_decision.cycle_date

    primary_action = None
    if danasnji_termin:
        primary_action = {
            "label": "Potvrdi dolazak",
            "url_name": "potvrdi_dolazak",
            "url_arg": danasnji_termin.id,
            "icon": "bi-check2-circle",
        }
    elif continuity and continuity.recommended_action_code == "ASSIGN_FREE_STOCK":
        primary_action = {
            "label": continuity.recommended_action_label,
            "url_name": "dodijeli_slobodne_doze",
            "url_arg": overview_product.id,
            "icon": "bi-box-arrow-in-right",
        }
    elif continuity and continuity.recommended_action_code == "INCLUDE_EARLIER_CYCLE":
        primary_action = {
            "label": continuity.recommended_action_label,
            "url_name": "komisijski_centar",
            "url_arg": None,
            "icon": "bi-calendar2-check",
        }
    elif continuity and continuity.recommended_action_code == "EXTRAORDINARY_REQUEST":
        primary_action = {
            "label": continuity.recommended_action_label,
            "dialog": "extraordinary",
            "icon": "bi-lightning-charge",
        }
    elif continuity and continuity.recommended_action_code == "MONITOR_EXTRAORDINARY":
        primary_action = {
            "label": continuity.recommended_action_label,
            "url_name": "vanredni_zahtjevi",
            "url_arg": None,
            "icon": "bi-eye",
        }
    elif continuity and continuity.recommended_action_code == "REVIEW_PLAN":
        if not home_projection:
            primary_action = {
                "label": continuity.recommended_action_label,
                "tab_target": "terapije",
                "icon": "bi-calendar2-week",
            }
    elif oralni_status and oralni_status.get("can_issue"):
        primary_action = {
            "label": "Izdaj oralnu terapiju",
            "url_name": "oralna_terapija",
            "url_arg": pacijent.id,
            "icon": "bi-capsule-pill",
        }
    elif (
        not operativni_termin
        and pacijent.aktivan
        and not oralni_status
        and not prikazi_izdaj_kucnu_terapiju
    ):
        primary_action = {
            "label": "Zakaži terapiju",
            "url_name": "novi_termin_pacijent",
            "url_arg": pacijent.id,
            "icon": "bi-calendar-plus",
        }
    elif komisijska_akcija_potrebna:
        primary_action = {
            "label": commission_action_label,
            "url_name": "komisijski_centar",
            "url_arg": None,
            "icon": "bi-clipboard2-check",
        }

    if oralni_status:
        patient_phase_label = (
            "Aktivan oralni režim"
            if oralni_status.get("regimen") else "Oralni režim nije potvrđen"
        )
        header_therapy = oralni_status.get("medicine_title")
    else:
        patient_phase_label = (
            ustekinumab_protocol.get("phase_label")
            if ustekinumab_protocol else (
                "Kućna terapija"
                if status_pacijenta["rezim_terapije"] == "KUCNA_TERAPIJA"
                else status_pacijenta.get("trenutna_faza")
            )
        ) or "Faza nije definisana"
        header_therapy = (
            overview_product.prikaz_naziv
            if overview_product else pacijent.terapija_za_prikaz
        )

    raw_jmbg = str(pacijent.jmbg or "")
    can_view_full_jmbg = je_doktor_ili_admin(request.user)
    if can_view_full_jmbg or not raw_jmbg:
        jmbg_za_prikaz = raw_jmbg or "Nije upisan"
    elif len(raw_jmbg) > 6:
        jmbg_za_prikaz = f"{raw_jmbg[:3]}•••••••{raw_jmbg[-3:]}"
    else:
        jmbg_za_prikaz = "••••••"

    patient_record_overview = {
        "header_therapy": header_therapy,
        "phase_label": patient_phase_label,
        "title": overview_title,
        "date": overview_date,
        "therapy": overview_therapy,
        "dose": overview_dose,
        "place": overview_place,
        "stock_label": overview_stock_label,
        "stock_css": overview_stock_css,
        "stock_detail": overview_stock_detail,
        "covered_until": overview_coverage_until,
        "primary_action": primary_action,
        "planned_cycle_date": planned_cycle_date,
        "commission_quantity_display": commission_quantity_display,
        "commission_required_display": (
            format_stock_quantity(overview_product, required_quantity)
            if overview_product else f"{required_quantity:g} doza"
        ),
        "commission_covered_display": (
            format_stock_quantity(overview_product, covered_quantity)
            if overview_product else f"{covered_quantity:g} doza"
        ),
        "commission_status_label": commission_status_label,
        "commission_status_css": commission_status_css,
        "commission_action_label": commission_action_label,
        "commission_subject_label": (
            commission_decision.subject_label
            if commission_decision is not None else "Komisijski plan"
        ),
        "commission_badge_label": (
            commission_decision.badge_label
            if commission_decision is not None else commission_status_label
        ),
        "commission_why_label": (
            commission_decision.why_button_label
            if commission_decision is not None else
            f"Zašto {commission_quantity_display}?"
        ),
        "commission_action_needed": komisijska_akcija_potrebna,
        "continuity": continuity,
        "coverage_calculation": coverage_calculation,
        "commission_decision": commission_decision,
        "is_home_therapy": bool(home_projection),
        "next_dose_date": (
            home_projection.next_dose_date if home_projection else None
        ),
        "next_dispensing_date": (
            coverage_calculation.next_dispensing_date
            if coverage_calculation is not None else (
                home_projection.next_dispensing if home_projection else None
            )
        ),
        "patient_quantity_display": (
            home_projection.patient_quantity_display if home_projection else ""
        ),
        "reserved_quantity_display": (
            home_projection.reserved_quantity_display if home_projection else ""
        ),
        "free_quantity_display": (
            home_projection.free_fridge_quantity_display if home_projection else ""
        ),
        "issue_action_visible": home_therapy_action["visible"],
        "issue_action_enabled": home_therapy_action["enabled"],
    }
    return render(request, "dashboard/profil_pacijenta.html", {
        "pacijent": pacijent,
        "status_pacijenta": status_pacijenta,

        "komisije": komisije,
        "historijske_komisije": historijske_komisije,
        "pacijent_komisijski_sazetak": pacijent_komisijski_sazetak,
        "komisijski_zahtjevi": komisijski_zahtjevi,
        "trenutna_saglasnost": saglasnost_prijedlog,
        "historija_saglasnosti": historija_saglasnosti,
        "terapije": terapije,
        "zadnje_terapije": zadnje_primljene_terapije,

        "termini": termini,
        "danasnji_termin": danasnji_termin,
        "operativni_termin": operativni_termin,
        "termini_u_proslosti_za_pregled": termini_u_proslosti_za_pregled,
        "ceka_novi_termin": ceka_novi_termin,
        "terapijska_hronologija": terapijska_hronologija,

        "zaduzenja": zaduzenja,
        "kucna_izdavanja": kucna_izdavanja,
        "rezervacije_u_frizideru": rezervacije_u_frizideru,
        "dodjele_slobodne_zalihe": dodjele_slobodne_zalihe,
        "zadnje_kucno_izdavanje": kucna_izdavanja[0] if kucna_izdavanja else None,
        "aktivna_zaduzenja": aktivna_zaduzenja,
        "promjene_terapije": promjene_terapije,
        "historija_protokola": historija_protokola,
        "historija_statusa_terapije": historija_statusa_terapije,
        "aktivna_pauza_terapije": pacijent.aktivna_pauza_terapije(),

        "doze_za_komisiju": doze_za_komisiju,
        "potrebe_komisije": potrebe_komisije,
        "zaduzeno_lijekova": zaduzeno_lijekova,
        "preostalo_po_komisiji": preostalo_po_komisiji,
        "odobreno_komisijom": odobreno_komisijom,
        "zaprimljeno_u_ustanovi": zaprimljeno_u_ustanovi,
        "u_frizideru": u_frizideru,
        "dodijeljeno_pacijentu": dodijeljeno_pacijentu,
        "kod_pacijenta": kod_pacijenta,
        "kod_pacijenta_doze": kod_pacijenta,
        "jedinica_kod_pacijenta": (
            pacijent.lijek.jedinica_zalihe_za_kolicinu(kod_pacijenta)
            if pacijent.lijek_id
            else "doze"
        ),
        "potroseno": potroseno,
        "potroseno_aktivna_komisija": potroseno_aktivna_komisija,
        "potroseno_iz_zaduzenja": potroseno_iz_zaduzenja,
        "pokriven_do_pacijenta": pokriven_do_pacijenta,
        "pokriven_do_izvor": pokriven_do_izvor,
        "prikazi_izdaj_kucnu_terapiju": prikazi_izdaj_kucnu_terapiju,
        "home_therapy_action": home_therapy_action,
        "home_therapy_form": home_therapy_form,
        "poruka_prelaska_na_kucnu_terapiju": pacijent.poruka_prelaska_na_kucnu_terapiju(),
        "aktivna_komisija": aktivna_komisija,
        "aktivne_komisije": aktivne_komisije,
        "trebovanja": trebovanja,
        "napomene_pacijenta": napomene_pacijenta,
        "dokumenti_pacijenta": dokumenti_pacijenta,
        "zadnji_dokumenti": dokumenti_pacijenta[:3],
        "zadnje_napomene": trebovanja.exclude(napomena="")[:2],
        "status_upozorenja": status_upozorenja,
        "status_upozorenja_klasa": status_upozorenja_klasa,
        "tipovi_dokumenata": DokumentPacijenta.TIPOVI_DOKUMENTA,
        "protokol_terapije": protokol_terapije,
        "ustekinumab_state": ustekinumab_state,
        "ustekinumab_protocol": ustekinumab_protocol,
        "ustekinumab_home_issue_available": ustekinumab_home_issue_available,
        "ustekinumab_setup_form": ustekinumab_setup_form,
        "ustekinumab_schedule_form": ustekinumab_schedule_form,
        "ustekinumab_interval_form": ustekinumab_interval_form,
        "ustekinumab_setup_visible": ustekinumab_setup_visible,
        "ustekinumab_nursing_ui": ustekinumab_nursing_ui,
        "oralni_status": oralni_status,
        "oral_issue_form": oral_issue_form,
        "oralni_operativni_plan": oralni_operativni_plan,
        "doza_po_terapiji": definicija_kolicine["quantity"],
        "jedinica_doze_po_terapiji": definicija_kolicine["unit"],
        "kolicina_po_terapiji_nedostaje": (
            definicija_kolicine["status"] == "MISSING"
        ),
        "migracijski_snapshot": migracijski_snapshot,
        "moze_urediti_individualni_protokol": je_doktor_ili_admin(request.user),
        "moze_upravljati_terapijskim_workflowom": moze_upravljati_terapijskim_workflowom,
        "moze_promijeniti_ustekinumab_sc_nacin": moze_promijeniti_ustekinumab_sc_nacin,
        "moze_ponistiti_terapiju": je_koordinator_ili_admin(request.user),
        "moze_deaktivirati_pacijenta": je_koordinator_ili_admin(request.user),
        "moze_unijeti_saglasnost": je_sestra_ili_admin(request.user),
        "prikazi_evidentiranje_ranijeg_odobrenja": (
            prikazi_evidentiranje_ranijeg_odobrenja
        ),
        "komisijski_v2": komisijski_v2,
        "komisijski_plan": komisijski_plan,
        "komisijski_plan_za_karton": komisijski_plan_za_karton,
        "coverage_calculation": coverage_calculation,
        "home_projection": home_projection,
        "vanredni_context": vanredni_context,
        "vanredni_zahtjevi": extraordinary_requests().filter(pacijent=pacijent),
        "kreiran_vanredni": kreiran_vanredni,
        "patient_record_overview": patient_record_overview,
        "jmbg_za_prikaz": jmbg_za_prikaz,
        "can_view_full_jmbg": can_view_full_jmbg,
    })


@login_required
@require_POST
def dodaj_napomenu_pacijenta(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, pk=pacijent_id)
    tekst = (request.POST.get("napomena") or "").strip()
    if not tekst:
        messages.error(request, "Unesite napomenu.")
    else:
        upisi_log(
            request.user,
            "Napomena pacijenta",
            pacijent=pacijent,
            opis=tekst,
        )
        messages.success(request, "Napomena je sačuvana u historiji pacijenta.")
    return redirect(
        f"{reverse('profil_pacijenta', args=[pacijent.pk])}"
        "?tab=historija#history-notes"
    )


@login_required
def uredi_individualni_protokol(request, pacijent_id):
    if not je_doktor_ili_admin(request.user):
        raise PermissionDenied(
            "Samo administrator, doktor ili koordinator biološke terapije "
            "mogu uređivati protokol terapije."
        )

    pacijent = get_object_or_404(
        Pacijent.objects.select_related("lijek", "terapijski_protokol"),
        id=pacijent_id,
    )
    try:
        individualni = pacijent.individualni_protokol
    except IndividualniProtokolPacijenta.DoesNotExist:
        individualni = None

    if request.method == "POST":
        prethodno_stanje = individualni.snapshot() if individualni else {}
        form = IndividualniProtokolPacijentaForm(
            request.POST,
            instance=individualni,
            pacijent=pacijent,
        )
        indukcijski_formset = IndukcijskiKorakFormSet(
            request.POST,
            prefix="indukcija",
        )
        odrzavanje_form = OdrzavanjeIndividualnogProtokolaForm(
            request.POST,
            prefix="odrzavanje",
        )
        header_validan = form.is_valid()
        indukcija_validna = indukcijski_formset.is_valid()
        odrzavanje_validno = odrzavanje_form.is_valid()
        if header_validan and indukcija_validna and odrzavanje_validno:
            with transaction.atomic():
                protokol = form.save(commit=False)
                protokol.pacijent = pacijent
                if not protokol.standardni_protokol_id:
                    protokol.standardni_protokol = get_standard_protocol(pacijent)
                if not protokol.pk:
                    protokol.kreirao = request.user
                protokol.izmijenio = request.user
                protokol.razlog_posljednje_izmjene = form.cleaned_data["razlog_izmjene"]
                protokol.indukcijska_faza = ""
                protokol.faza_odrzavanja = ""
                protokol.interval_odrzavanja_sedmica = odrzavanje_form.cleaned_data["interval_sedmica"]
                protokol.doza_po_aplikaciji = odrzavanje_form.cleaned_data["broj_jedinica"]
                protokol.mjesto_primjene = odrzavanje_form.cleaned_data["nacin_primjene"]
                protokol.save()

                pacijent.kolicina_po_terapiji = odrzavanje_form.cleaned_data[
                    "broj_jedinica"
                ]
                pacijent.save(update_fields=["kolicina_po_terapiji"])

                save_structured_protocol_steps(
                    protokol,
                    [korak_form.cleaned_data for korak_form in indukcijski_formset.forms],
                    odrzavanje_form.cleaned_data,
                )

                IzmjenaIndividualnogProtokola.objects.create(
                    protokol=protokol,
                    korisnik=request.user,
                    datum_odluke=(
                        form.cleaned_data.get("datum_odluke")
                        or timezone.localdate()
                    ),
                    ljekar_koji_je_donio_odluku=(
                        form.cleaned_data.get("ljekar_koji_je_donio_odluku")
                        or ""
                    ),
                    povezani_dokument=form.cleaned_data.get("povezani_dokument"),
                    razlog=form.cleaned_data["razlog_izmjene"],
                    prethodno_stanje=prethodno_stanje,
                    novo_stanje=protokol.snapshot(),
                )
                upisi_log(
                    request.user,
                    "Izmijenjen individualni protokol pacijenta",
                    pacijent=pacijent,
                    objekat=protokol,
                    opis=(
                        f"{protokol.naziv}; razlog: "
                        f"{form.cleaned_data['razlog_izmjene']}; "
                        f"datum odluke: {form.cleaned_data.get('datum_odluke') or timezone.localdate()}; "
                        f"ljekar: {form.cleaned_data.get('ljekar_koji_je_donio_odluku') or '-'}; "
                        f"dokument: {getattr(form.cleaned_data.get('povezani_dokument'), 'pk', '-')}"
                    ),
                )
                # Reverse OneToOne cache može sadržavati raniji DoesNotExist iz
                # istog requesta; osvježavanje garantuje da resolver vidi novi zapis.
                pacijent.refresh_from_db()
                pacijent._state.fields_cache.pop("individualni_protokol", None)
                broj_preracunatih = recalculate_future_appointments(pacijent)
                if broj_preracunatih:
                    upisi_log(
                        request.user,
                        "Preračunati budući termini nakon izmjene protokola",
                        pacijent=pacijent,
                        objekat=protokol,
                        opis=f"Preračunato termina: {broj_preracunatih}.",
                    )
            messages.success(request, "Individualni protokol pacijenta je sačuvan.")
            profil_url = reverse("profil_pacijenta", kwargs={"pacijent_id": pacijent.id})
            return redirect(f"{profil_url}#protokol")
    else:
        indukcija_initial, odrzavanje_initial = structured_protocol_initial_data(
            pacijent,
            individualni,
        )
        form = IndividualniProtokolPacijentaForm(
            instance=individualni,
            pacijent=pacijent,
            initial=(
                None if individualni else individual_protocol_initial_data(pacijent)
            ),
        )
        indukcijski_formset = IndukcijskiKorakFormSet(
            initial=indukcija_initial,
            prefix="indukcija",
        )
        odrzavanje_form = OdrzavanjeIndividualnogProtokolaForm(
            initial=odrzavanje_initial,
            prefix="odrzavanje",
        )

    return render(request, "dashboard/uredi_individualni_protokol.html", {
        "pacijent": pacijent,
        "form": form,
        "indukcijski_formset": indukcijski_formset,
        "odrzavanje_form": odrzavanje_form,
        "individualni_protokol": individualni,
        "standardni_protokol": get_standard_protocol(pacijent),
    })


@login_required
@user_passes_test(je_doktor_ili_admin)
def promijeni_terapiju(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    stari_lijek = pacijent.lijek

    if not stari_lijek:
        messages.error(request, "Pacijent nema aktivnu terapiju koju je moguće promijeniti.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)
    if pacijent.na_aktivnoj_pauzi():
        messages.error(request, "Promjena lijeka nije dozvoljena dok je terapija privremeno pauzirana.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)

    aktivna_komisija = Komisija.objects.filter(
        pacijent=pacijent,
        lijek=stari_lijek,
        status="AKTIVNA",
    ).order_by("-datum_odobrenja", "-id").first()
    preostale_doze = Decimal("0")
    if aktivna_komisija:
        preostale_doze = Decimal(str(aktivna_komisija.preostale_doze or 0))

    aktivna_zaduzenja = PacijentZaduzenje.objects.filter(
        pacijent=pacijent,
        lijek=stari_lijek,
        aktivno=True,
    )
    preostalo_kod_pacijenta = sum(
        (Decimal(str(z.preostalo or 0)) for z in aktivna_zaduzenja),
        Decimal("0"),
    )

    if request.method == "POST":
        form = PromjenaTerapijeForm(
            request.POST,
            pacijent=pacijent,
            preostale_doze=preostale_doze,
        )
        if form.is_valid():
            novi_program = form.cleaned_data["nova_terapija"]
            novi_lijek = form.cleaned_data["novi_proizvod"]
            datum_pocetka = form.cleaned_data["datum_pocetka_nove_terapije"]
            postupanje = form.cleaned_data.get("postupanje_sa_preostalim_dozama") or ""
            nova_faza = form.cleaned_data["nova_terapija_pocinje"]
            stari_protokol = pacijent.terapijski_protokol
            novi_protokol = novi_lijek.aktivni_protokol()
            datum_zavrsetka = datum_pocetka - timedelta(days=1)

            try:
                with transaction.atomic():
                    Pacijent.objects.select_for_update().get(pk=pacijent.pk)
                    promjena = PromjenaTerapije.objects.create(
                        pacijent=pacijent,
                        stari_lijek=stari_lijek,
                        novi_lijek=novi_lijek,
                        stari_protokol=stari_protokol,
                        novi_protokol=novi_protokol,
                        datum_odluke=(
                            form.cleaned_data.get("datum_odluke")
                            or timezone.localdate()
                        ),
                        ljekar_koji_je_donio_odluku=(
                            form.cleaned_data.get("ljekar_koji_je_donio_odluku")
                            or ""
                        ),
                        povezani_dokument=form.cleaned_data.get("povezani_dokument"),
                        datum_zavrsetka_stare_terapije=datum_zavrsetka,
                        datum_pocetka_nove_terapije=datum_pocetka,
                        razlog=form.cleaned_data["razlog"],
                        napomena=form.cleaned_data.get("napomena") or "",
                        preostale_doze=preostale_doze,
                        postupanje_sa_preostalim_dozama=postupanje if preostale_doze > 0 else "",
                        nova_terapija_pocinje=nova_faza,
                        izvrsio=request.user if request.user.is_authenticated else None,
                    )

                    otkazani_termini = Termin.objects.filter(
                        pacijent=pacijent,
                        lijek=stari_lijek,
                        status="ZAKAZAN",
                        datum__gte=datum_pocetka,
                    ).update(status="OTKAZAN")

                    zaduzenja_za_zatvaranje = list(aktivna_zaduzenja.select_for_update())
                    transfer_kod_pacijenta = sum(
                        (Decimal(str(z.preostalo or 0)) for z in zaduzenja_za_zatvaranje),
                        Decimal("0"),
                    )

                    if (
                        transfer_kod_pacijenta > 0
                        and postupanje in [
                            PromjenaTerapije.POSTUPANJE_VRATI_U_ZALIHU,
                            PromjenaTerapije.POSTUPANJE_OSTAVI_U_FRIZIDERU,
                        ]
                        and lijek_je_kucna_terapija(pacijent, stari_lijek)
                    ):
                        promijeni_zalihu(
                            lijek=stari_lijek,
                            kolicina=transfer_kod_pacijenta,
                            korisnik=request.user,
                            pacijent=pacijent,
                            akcija="Promjena terapije - povrat preostalih doza",
                            opis=(
                                f"{stari_lijek.naziv}: vraćeno {transfer_kod_pacijenta} "
                                "doza kod pacijenta u frižider."
                            ),
                            frizider_delta=transfer_kod_pacijenta,
                            kod_pacijenata_delta=-transfer_kod_pacijenta,
                            tip_transakcije=ZalihaTransakcija.TIP_POVRAT,
                        )

                    for zaduzenje in zaduzenja_za_zatvaranje:
                        zaduzenje.aktivno = False
                        zaduzenje.save(update_fields=["aktivno"])

                    if aktivna_komisija:
                        napomena = aktivna_komisija.napomena or ""
                        postupanje_opis = (
                            promjena.get_postupanje_sa_preostalim_dozama_display()
                            if preostale_doze > 0
                            else "Nema preostalih doza."
                        )
                        dodatak = (
                            f"Promjena terapije {datum_pocetka:%d/%m/%Y}: "
                            f"{stari_lijek.naziv} → {novi_lijek.naziv}. "
                            f"Postupanje: {postupanje_opis}."
                        )
                        aktivna_komisija.napomena = f"{napomena}\n{dodatak}".strip()
                        if preostale_doze > 0 and postupanje == PromjenaTerapije.POSTUPANJE_RUCNO_KASNIJE:
                            aktivna_komisija.status = "NOVA"
                        else:
                            aktivna_komisija.status = "ZAMIJENJENA"
                            aktivna_komisija.preostale_doze = Decimal("0")
                        aktivna_komisija.save(update_fields=["status", "preostale_doze", "napomena"])

                    pacijent.lijek = novi_lijek
                    pacijent.terapijski_program = novi_program
                    pacijent.terapijski_protokol = novi_protokol
                    pacijent.pocetna_faza_terapije = (
                        Pacijent.FAZA_ODRZAVANJE
                        if nova_faza == PromjenaTerapije.NOVA_FAZA_ODRZAVANJE
                        else Pacijent.FAZA_INDUKCIJA
                    )
                    if novi_protokol and novi_protokol.interval_odrzavanja_sedmica:
                        pacijent.interval_sedmica = novi_protokol.interval_odrzavanja_sedmica
                    pacijent.save(
                        update_fields=[
                            "lijek",
                            "terapijski_program",
                            "terapijski_protokol",
                            "pocetna_faza_terapije",
                            "interval_sedmica",
                        ]
                    )
                    FazniProtokolPacijenta.objects.filter(
                        pacijent=pacijent,
                    ).exclude(
                        terapijski_program=novi_program,
                    ).update(aktivan=False)
                    if novi_program.protokol_kljuc:
                        from patients.phased_protocols import configure_program_protocol

                        configure_program_protocol(
                            patient=pacijent,
                            program=novi_program,
                            maintenance_interval=pacijent.interval_sedmica,
                            user=request.user,
                            prescribed_iv_dose_mg=form.cleaned_data.get(
                                "pocetna_iv_doza_mg"
                            ),
                        )

                    oslobodjeno_iz_rezervacije = Decimal("0")
                    if postupanje != PromjenaTerapije.POSTUPANJE_RUCNO_KASNIJE:
                        oslobodjeno_iz_rezervacije = release_patient_reservations_to_free_stock(
                            pacijent=pacijent,
                            lijek=stari_lijek,
                            user=request.user,
                            reason=(
                                f"Promjena lijeka {stari_lijek.naziv} → {novi_lijek.naziv}; "
                                "doze starog lijeka ostaju u frižideru kao slobodna zaliha. "
                                f"Postupanje: {postupanje or 'nije posebno navedeno'}."
                            ),
                            reason_code=ZalihaTransakcija.RAZLOG_PROMJENA_LIJEKA,
                            reference=promjena,
                        )

                    prvi_korak = pacijent.trenutni_korak_terapije()
                    if pacijent.trenutni_korak_je_ambulanta():
                        schedule_therapy_appointment(
                            pacijent=pacijent,
                            lijek=novi_lijek,
                            datum=datum_pocetka,
                            vrijeme=time(8, 0),
                            user=request.user,
                            reason="Prvi termin zakazan nakon promjene terapije.",
                        )

                    upisi_log(
                        request.user,
                        "Promjena terapije",
                        pacijent=pacijent,
                        objekat=promjena,
                        opis=(
                            f"{stari_lijek.naziv} → {novi_lijek.naziv}; "
                            f"prethodno lijek={stari_lijek.naziv}, protokol={stari_protokol}; "
                            f"novo lijek={novi_lijek.naziv}, protokol={novi_protokol}; "
                            f"datum odluke: {promjena.datum_odluke:%d/%m/%Y}; "
                            f"ljekar: {promjena.ljekar_koji_je_donio_odluku or '-'}; "
                            f"dokument: {promjena.povezani_dokument_id or '-'}; "
                            f"razlog: {promjena.get_razlog_display()}; "
                            f"preostale doze: {preostale_doze}; "
                            f"postupanje: {promjena.get_postupanje_sa_preostalim_dozama_display() or '-'}; "
                            f"oslobođeno u slobodnu zalihu: {oslobodjeno_iz_rezervacije}; "
                            f"otkazani termini: {otkazani_termini}; "
                            f"novi korak: {prvi_korak.opis_za_prikaz() if prvi_korak else 'osnovni plan'}."
                        ),
                    )
            except ValueError as exc:
                messages.error(request, str(exc))
            else:
                messages.success(request, "Promjena terapije je evidentirana.")
                return redirect("profil_pacijenta", pacijent_id=pacijent.id)
    else:
        form = PromjenaTerapijeForm(
            pacijent=pacijent,
            preostale_doze=preostale_doze,
        )

    return render(request, "dashboard/promijeni_terapiju.html", {
        "form": form,
        "pacijent": pacijent,
        "stari_lijek": stari_lijek,
        "aktivna_komisija": aktivna_komisija,
        "preostale_doze": preostale_doze,
        "preostalo_kod_pacijenta": preostalo_kod_pacijenta,
    })


@login_required
@user_passes_test(je_doktor_ili_admin)
@require_POST
def postavi_ustekinumab_protokol(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, pk=pacijent_id)
    from patients.phased_protocols import (
        configure_ustekinumab_protocol,
        create_ustekinumab_commission_proposal,
        current_phase_details,
        ensure_phase_reservation,
        phased_protocol_for_patient,
    )

    current_state = phased_protocol_for_patient(pacijent)
    form = UstekinumabProtocolSetupForm(
        request.POST,
        patient=pacijent,
        state=current_state,
    )
    if not form.is_valid():
        messages.error(
            request,
            "Protokol nije spremljen: "
            + "; ".join(
                str(error)
                for errors in form.errors.values()
                for error in errors
            ),
        )
        return redirect(f"{reverse('profil_pacijenta', args=[pacijent.pk])}?tab=protokol#protokol")

    try:
        with transaction.atomic():
            state = configure_ustekinumab_protocol(
                patient=pacijent,
                iv_medicine=form.cleaned_data["iv_lijek"],
                sc_medicine=form.cleaned_data["sc_lijek"],
                phase=form.cleaned_data["faza"],
                maintenance_interval=form.cleaned_data[
                    "interval_odrzavanja_sedmica"
                ],
                user=request.user,
                prescribed_iv_dose_mg=form.cleaned_data.get(
                    "pocetna_iv_doza_mg"
                ),
                last_actual_date=form.cleaned_data.get(
                    "datum_zadnje_stvarne_doze"
                ),
            )
            if form.cleaned_data.get("kreiraj_komisijski_prijedlog"):
                create_ustekinumab_commission_proposal(
                    state=state,
                    cycle=form.cleaned_data["komisijski_ciklus"],
                    request_type=form.cleaned_data["vrsta_zahtjeva"],
                    include_first_sc=form.cleaned_data.get("ukljuci_prvu_sc", False),
                    user=request.user,
                    previous_medicine=form.cleaned_data.get("prethodni_lijek"),
                )
            if form.cleaned_data.get("planirani_datum"):
                phase = current_phase_details(state)
                appointment, _created = schedule_therapy_appointment(
                    pacijent=state.pacijent,
                    lijek=phase["medicine"],
                    datum=form.cleaned_data["planirani_datum"],
                    vrijeme=form.cleaned_data["planirano_vrijeme"],
                    user=request.user,
                    reason=(
                        "Ljekar potvrdio termin prema aktivnom faznom "
                        "ustekinumab protokolu."
                    ),
                    kolicina_po_terapiji=phase["units"],
                )
                ensure_phase_reservation(
                    state=state,
                    appointment=appointment,
                    user=request.user,
                )
    except (ValidationError, ValueError) as exc:
        messages.error(request, str(exc))
    else:
        messages.success(
            request,
            "Ustekinumab protokol je potvrđen i auditiran.",
        )
    return redirect(f"{reverse('profil_pacijenta', args=[pacijent.pk])}?tab=protokol#protokol")


@login_required
@user_passes_test(je_terapijski_tim)
@require_POST
def zakazi_ustekinumab_fazu(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, pk=pacijent_id)
    from patients.phased_protocols import (
        current_phase_details,
        ensure_phase_reservation,
        phase_scheduling_readiness,
        phased_protocol_for_patient,
    )

    state = phased_protocol_for_patient(pacijent)
    if not state:
        messages.error(request, "Pacijent nema aktivan fazni protokol.")
        return redirect(f"{reverse('profil_pacijenta', args=[pacijent.pk])}?tab=protokol#protokol")
    if state.sc_je_kucna_terapija:
        messages.error(
            request,
            "Pacijent je na kućnoj terapiji. Vratite ga na ambulantnu primjenu "
            "prije zakazivanja novog SC termina.",
        )
        return redirect(f"{reverse('profil_pacijenta', args=[pacijent.pk])}?tab=protokol#protokol")
    form = UstekinumabPhaseScheduleForm(request.POST)
    if not form.is_valid():
        messages.error(request, "Unesite ispravan datum i vrijeme termina.")
    else:
        try:
            with transaction.atomic():
                phase = current_phase_details(state)
                if state.faza == state.FAZA_CEKA_IV:
                    readiness = phase_scheduling_readiness(state)
                    if not readiness["ready"]:
                        raise ValidationError(readiness["reason"])
                appointment, created = schedule_therapy_appointment(
                    pacijent=pacijent,
                    lijek=phase["medicine"],
                    datum=form.cleaned_data["datum"],
                    vrijeme=form.cleaned_data["vrijeme"],
                    user=request.user,
                    reason=(
                        "Terapijski tim zakazao termin prema aktivnom faznom "
                        "ustekinumab protokolu."
                    ),
                    kolicina_po_terapiji=phase["units"],
                )
                ensure_phase_reservation(
                    state=state,
                    appointment=appointment,
                    user=request.user,
                )
        except (ValidationError, ValueError) as exc:
            messages.error(request, str(exc))
        else:
            messages.success(
                request,
                "Termin je zakazan i fazna rezervacija je provjerena."
                if created else
                "Termin već postoji; rezervacija je provjerena bez dupliranja.",
            )
    return redirect(f"{reverse('profil_pacijenta', args=[pacijent.pk])}?tab=protokol#protokol")


@login_required
@user_passes_test(je_doktor_ili_admin)
@require_POST
def promijeni_ustekinumab_interval(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, pk=pacijent_id)
    from patients.phased_protocols import (
        change_maintenance_interval,
        phased_protocol_for_patient,
    )

    state = phased_protocol_for_patient(pacijent)
    form = UstekinumabIntervalChangeForm(request.POST)
    if not state:
        messages.error(request, "Pacijent nema aktivan fazni protokol.")
    elif not form.is_valid():
        messages.error(request, "Unesite novi interval i razlog promjene.")
    else:
        try:
            change_maintenance_interval(
                state=state,
                interval_weeks=form.cleaned_data[
                    "interval_odrzavanja_sedmica"
                ],
                user=request.user,
                reason=form.cleaned_data["razlog"],
            )
        except ValidationError as exc:
            messages.error(request, str(exc))
        else:
            messages.success(request, "Interval održavanja je promijenjen uz audit zapis.")
    return redirect(f"{reverse('profil_pacijenta', args=[pacijent.pk])}?tab=protokol#protokol")


@login_required
@user_passes_test(je_terapijski_tim)
def prebaci_ustekinumab_na_kucnu_terapiju(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, pk=pacijent_id)
    from patients.phased_protocols import (
        phased_protocol_for_patient,
        transition_ustekinumab_sc_to_home,
        ustekinumab_sc_transition_summary,
    )

    state = phased_protocol_for_patient(pacijent)
    if not state:
        messages.error(request, "Pacijent nema aktivan Ustekinumab fazni protokol.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.pk)
    summary = ustekinumab_sc_transition_summary(state)
    if request.method == "POST":
        try:
            _state, cancelled = transition_ustekinumab_sc_to_home(
                state=state,
                user=request.user,
            )
        except ValidationError as exc:
            messages.error(request, " ".join(exc.messages))
        else:
            messages.success(
                request,
                "Pacijent je prebačen na kućnu terapiju. "
                f"Otkazano budućih ambulantnih termina: {cancelled}.",
            )
        return redirect(
            f"{reverse('profil_pacijenta', args=[pacijent.pk])}?tab=protokol#protokol"
        )
    return render(request, "dashboard/ustekinumab_sc_nacin_primjene.html", {
        "pacijent": pacijent,
        "state": state,
        "summary": summary,
        "target_home": True,
    })


@login_required
@user_passes_test(je_terapijski_tim)
def vrati_ustekinumab_na_ambulantnu_primjenu(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, pk=pacijent_id)
    from patients.phased_protocols import (
        phased_protocol_for_patient,
        return_ustekinumab_sc_to_ambulatory,
        ustekinumab_sc_transition_summary,
    )

    state = phased_protocol_for_patient(pacijent)
    if not state:
        messages.error(request, "Pacijent nema aktivan Ustekinumab fazni protokol.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.pk)
    summary = ustekinumab_sc_transition_summary(state)
    if request.method == "POST":
        try:
            _state, changed = return_ustekinumab_sc_to_ambulatory(
                state=state,
                user=request.user,
            )
        except ValidationError as exc:
            messages.error(request, " ".join(exc.messages))
        else:
            messages.success(
                request,
                "Pacijent je vraćen na SC primjenu u ambulanti. "
                "Sljedeći termin se zakazuje eksplicitno."
                if changed else
                "Pacijent je već na SC primjeni u ambulanti.",
            )
        return redirect(
            f"{reverse('profil_pacijenta', args=[pacijent.pk])}?tab=protokol#protokol"
        )
    return render(request, "dashboard/ustekinumab_sc_nacin_primjene.html", {
        "pacijent": pacijent,
        "state": state,
        "summary": summary,
        "target_home": False,
    })


@login_required
def potvrdi_dolazak(request, termin_id):
    termin = get_object_or_404(Termin, id=termin_id)
    pacijent = termin.pacijent
    from patients.phased_protocols import (
        current_phase_details,
        phase_confirmation_description,
        phased_protocol_for_patient,
    )

    fazni_protokol = phased_protocol_for_patient(pacijent)
    fazni_korak = (
        current_phase_details(fazni_protokol) if fazni_protokol else None
    )
    if fazni_protokol and fazni_protokol.sc_je_kucna_terapija:
        messages.warning(
            request,
            "Pacijent je na kućnoj SC terapiji. Koristite opciju Izdaj kućnu terapiju.",
        )
        return redirect("profil_pacijenta", pacijent_id=pacijent.pk)
    lijek = termin.lijek if fazni_protokol else pacijent.lijek
    if termin.lijek.oralna_terapija:
        messages.warning(
            request,
            "Oralna terapija nema dolazak na terapiju. "
            "Evidentirajte stvarno izdavanje tableta na kartonu pacijenta.",
        )
        return redirect(
            f"{reverse('profil_pacijenta', args=[pacijent.pk])}"
            "?tab=oralna-terapija#oralna-terapija"
        )
    protokol = pacijent.aktivni_protokol()
    korak_terapije = None if fazni_protokol else pacijent.trenutni_korak_terapije()

    default_faza = fazni_korak["label"] if fazni_korak else pacijent.terapijska_faza()
    default_doza_mg = (
        fazni_korak["dose_mg"]
        if fazni_korak else
        korak_terapije.doza_mg if korak_terapije else None
    )
    default_mjesto = (
        "AMBULANTA"
        if fazni_protokol else
        pacijent.nacin_primjene_trenutnog_koraka()
    )

    if termin.status == "OBAVLJEN":
        messages.warning(request, "Dolazak je vec potvrden za ovaj termin. Zaliha nije ponovo skinuta.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)

    if not fazni_protokol and not pacijent.trenutni_korak_je_ambulanta():
        messages.warning(
            request,
            "Trenutni korak protokola je kućna terapija. Koristite opciju Izdaj kućnu terapiju."
        )
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)

    if fazni_protokol:
        default_doza = Decimal(str(fazni_korak["units"] or 0))
        if default_doza <= 0:
            messages.error(
                request,
                "Količina za trenutnu fazu protokola nije evidentirana. "
                "Prvo unesite odobrenu količinu lijeka.",
            )
            return redirect(
                f"{reverse('profil_pacijenta', args=[pacijent.pk])}"
                "?tab=protokol#protokol"
            )
        default_interval = (
            8
            if fazni_protokol.faza == fazni_protokol.FAZA_CEKA_IV
            else fazni_protokol.interval_odrzavanja_sedmica
        )
    elif protokol:
        default_doza = (
            termin.kolicina_po_terapiji
            or default_therapy_dose(pacijent)
        )
        default_interval = pacijent.sedmica_do_sljedece_aplikacije(
            nakon_nove_aplikacije=True
        )
    else:
        default_doza = (
            termin.kolicina_po_terapiji
            or default_therapy_dose(pacijent)
        )
        default_interval = pacijent.interval_sedmica or 8

    from patients.scheduling import adjust_to_allowed_therapy_date

    predlozeni_sljedeci = adjust_to_allowed_therapy_date(
        termin.datum + timedelta(weeks=default_interval),
        lijek=lijek,
        protokol=protokol,
    )

    if request.method == "POST":
        # Resolve the selected outcome before parsing doses or creating a
        # Terapija. Previously every POST fell through to confirmation.
        posted_action = (
            request.POST.get("workflow_action")
            or request.POST.get("status_terapije")
            or request.POST.get("status")
            or "potvrdi"
        ).strip().casefold()

        if posted_action in {"odgodi", "odgodjena", "odgođena"}:
            new_date_raw = request.POST.get("novi_datum", "").strip()
            try:
                new_date = (
                    datetime.strptime(new_date_raw, "%Y-%m-%d").date()
                    if new_date_raw else None
                )
                postpone_therapy(
                    termin=termin,
                    new_date=new_date,
                    reason=(request.POST.get("razlog", "").strip() or "Terapija odgođena."),
                    user=request.user,
                )
            except (TypeError, ValueError) as exc:
                messages.error(request, str(exc))
                return redirect("potvrdi_dolazak", termin_id=termin.id)
            messages.success(
                request,
                (
                    "Termin je promijenjen bez evidentiranja potrošnje lijeka."
                    if new_date
                    else "Termin je odgođen i pacijent čeka novi termin."
                ),
            )
            return redirect("profil_pacijenta", pacijent_id=pacijent.id)

        if posted_action in {"nije_dosao", "nije-došao", "nije došao"}:
            new_date_raw = request.POST.get("novi_datum", "").strip()
            try:
                new_date = (
                    datetime.strptime(new_date_raw, "%Y-%m-%d").date()
                    if new_date_raw
                    else None
                )
                mark_no_show(
                    termin=termin,
                    reason=request.POST.get("razlog", "").strip(),
                    user=request.user,
                    reschedule_date=new_date,
                )
            except (TypeError, ValueError) as exc:
                messages.error(request, str(exc))
                return redirect("potvrdi_dolazak", termin_id=termin.id)
            messages.success(
                request,
                "Nedolazak je evidentiran bez promjene zalihe ili komisije.",
            )
            return redirect("profil_pacijenta", pacijent_id=pacijent.id)

        if posted_action not in {"potvrdi", "potvrdjena", "potvrđena", ""}:
            messages.error(request, "Nepoznat ishod termina. Terapija nije evidentirana.")
            return redirect("potvrdi_dolazak", termin_id=termin.id)

        try:
            primljene_doze = Decimal(
                str(request.POST.get("primljene_doze", default_doza))
            )
            interval_sedmica = int(
                request.POST.get("interval_sedmica", default_interval)
            )
        except (InvalidOperation, TypeError, ValueError):
            messages.error(
                request,
                "Količina i interval terapije moraju biti ispravni brojevi.",
            )
            return redirect("potvrdi_dolazak", termin_id=termin.id)
        posted_faza_terapije = (
            request.POST.get("faza_terapije", default_faza).strip()
            or default_faza
        )
        # Read-only input prikazuje puni label, ali fazni workflow prema servisu
        # prosljeđuje isključivo kratki kanonski kod.
        faza_terapije = (
            fazni_korak["phase"]
            if fazni_protokol
            else posted_faza_terapije
        )
        posted_doza_mg = request.POST.get("doza_mg", "").strip()
        try:
            doza_mg = (
                Decimal(posted_doza_mg) if posted_doza_mg else default_doza_mg
            )
        except InvalidOperation:
            messages.error(request, "Doza terapije u mg nije ispravan broj.")
            return redirect("potvrdi_dolazak", termin_id=termin.id)
        override_zaduzenja = False
        sljedeci_datum_raw = request.POST.get("sljedeci_datum", "").strip()
        try:
            sljedeci_datum = (
                datetime.strptime(sljedeci_datum_raw, "%Y-%m-%d").date()
                if sljedeci_datum_raw
                else None
            )
        except ValueError:
            messages.error(request, "Datum sljedeće terapije nije ispravan.")
            return redirect("potvrdi_dolazak", termin_id=termin.id)

        if primljene_doze <= 0:
            messages.error(request, "Broj primljenih doza mora biti veci od nule.")
            return redirect("potvrdi_dolazak", termin_id=termin.id)

        try:
            # Servis je također atomski; vanjska transakcija obuhvata i završni
            # audit zapis viewa, pa nijedan dio potvrde ne može ostati parcijalan.
            with transaction.atomic():
                terapija = confirm_therapy_arrival(
                    termin=termin,
                    primljene_doze=primljene_doze,
                    interval_sedmica=interval_sedmica,
                    korisnik=request.user,
                    override_zaduzenja=override_zaduzenja,
                    faza_terapije=faza_terapije,
                    doza_mg=doza_mg,
                    sljedeci_datum=sljedeci_datum,
                )

                upisi_log(
                    request.user,
                    "Potvrđena terapija",
                    pacijent=pacijent,
                    objekat=lijek,
                    opis=(
                        f"{lijek.naziv} - primljeno {primljene_doze} doza. "
                        f"Sljedeća terapija za {interval_sedmica} sedmica."
                    ),
                )
        except ValueError as exc:
            messages.error(request, str(exc))
            return redirect("potvrdi_dolazak", termin_id=termin.id)

        return redirect("terapija_zavrsena", terapija_id=terapija.id)

    return render(request, "dashboard/potvrdi_dolazak.html", {
        "termin": termin,
        "pacijent": pacijent,
        "lijek": lijek,
        "protokol": protokol,
        "terapijska_faza": default_faza,
        "korak_terapije": korak_terapije,
        "sljedeci_korak_opis": (
            phase_confirmation_description(fazni_korak)
            if fazni_korak else pacijent.sljedeci_korak_opis()
        ),
        "default_doza": default_doza,
        "default_jedinica_label": lijek.jedinica_zalihe_za_kolicinu(
            default_doza
        ),
        "default_interval": default_interval,
        "default_doza_mg": default_doza_mg,
        "default_mjesto": default_mjesto,
        "predlozeni_sljedeci_datum": predlozeni_sljedeci.datum,
        "sljedeci_datum_prilagodjen": predlozeni_sljedeci.prilagodjen,
        "prikazi_override_zaduzenja": False,
        "fazni_protokol": fazni_protokol,
        "fazni_korak": fazni_korak,
    })


@login_required
def terapija_zavrsena(request, terapija_id):
    terapija = get_object_or_404(
        Terapija.objects.select_related(
            "pacijent", "lijek", "evidentirao"
        ),
        id=terapija_id,
        workflow_status=Terapija.STATUS_POTVRDJENA,
    )
    kucno_izdavanje = KucnoIzdavanje.objects.filter(
        terapija=terapija
    ).only("id").first()
    kucno_izdavanje_workflow = bool(
        terapija.tip_evidencije == Terapija.TIP_KUCNA_TERAPIJA
        or kucno_izdavanje
    )
    return render(request, "dashboard/terapija_zavrsena.html", {
        "terapija": terapija,
        "pacijent": terapija.pacijent,
        "kucno_izdavanje": kucno_izdavanje,
        "kucno_izdavanje_workflow": kucno_izdavanje_workflow,
    })


@login_required
def finansije_pregled(request):
    terapije = Terapija.objects.filter(
        finansijski_status=Terapija.FINANSIJSKI_CEKA,
        workflow_status=Terapija.STATUS_POTVRDJENA,
    ).select_related(
        "pacijent", "lijek", "evidentirao"
    ).order_by("datum", "id")
    return render(request, "dashboard/finansije_pregled.html", {
        "terapije": terapije,
        "broj_terapija": terapije.count(),
    })


@login_required
def predaj_terapiju_finansijama(request, terapija_id):
    terapija = get_object_or_404(Terapija, id=terapija_id)
    if request.method != "POST":
        return redirect("finansije_pregled")
    try:
        _, promijenjeno = mark_therapy_submitted_to_finance(
            terapija=terapija,
            korisnik=request.user,
        )
    except ValueError as exc:
        messages.error(request, str(exc))
    else:
        if promijenjeno:
            messages.success(request, "Finansijski dokument je predat finansijama.")
        else:
            messages.info(request, "Terapija je već predata finansijama.")
    return redirect("finansije_pregled")


@login_required
def print_finansijski_dokument(request, terapija_id):
    terapija = get_object_or_404(
        Terapija.objects.select_related(
            "pacijent", "lijek", "evidentirao", "finansijama_predao"
        ),
        id=terapija_id,
    )
    output = BytesIO()
    c = canvas.Canvas(output, pagesize=A4)
    c.setTitle(f"Finansijski dokument terapije {terapija.id}")
    c.setFont("DejaVuSans-Bold", 16)
    c.drawString(70, 780, "Finansijski dokument terapije")
    c.setFont("DejaVuSans", 10)
    rows = [
        ("Ustanova", pdf_zdravstvena_ustanova()),
        ("Datum terapije", format_date_bs(terapija.datum)),
        ("Pacijent", f"{terapija.pacijent.ime} {terapija.pacijent.prezime}"),
        ("Lijek", terapija.lijek.prikaz_naziv),
        ("Količina", f"{terapija.kolicina:g} jedinica"),
        ("Faza terapije", terapija.faza_terapije_prikaz or "Nije navedena"),
        ("Način evidentiranja", terapija.get_tip_evidencije_display()),
        ("Finansijski status", terapija.get_finansijski_status_display()),
        (
            "Evidentirao",
            (
                terapija.evidentirao.get_full_name()
                or terapija.evidentirao.username
                if terapija.evidentirao
                else "Nema podatka"
            ),
        ),
    ]
    y = 735
    for label, value in rows:
        c.setFont("DejaVuSans-Bold", 10)
        c.drawString(70, y, f"{label}:")
        c.setFont("DejaVuSans", 10)
        c.drawString(200, y, str(value))
        y -= 24
    c.line(70, y - 8, 525, y - 8)
    c.setFont("DejaVuSans", 8)
    c.drawString(70, y - 28, f"TheraFlow evidencija #{terapija.id}")
    c.save()
    output.seek(0)
    return FileResponse(
        output,
        as_attachment=request.GET.get("download") == "1",
        filename=f"finansijski_dokument_terapija_{terapija.id}.pdf",
    )


@login_required
@user_passes_test(je_doktor_ili_admin)
def promijeni_status_termina(request, termin_id):
    termin = get_object_or_404(Termin, id=termin_id)
    if request.method != "POST":
        return redirect("profil_pacijenta", pacijent_id=termin.pacijent_id)
    action = request.POST.get("workflow_action", "")
    reason = request.POST.get("razlog", "").strip()
    try:
        if action == "nije_dosao":
            new_date_raw = request.POST.get("novi_datum", "").strip()
            new_date = datetime.strptime(new_date_raw, "%Y-%m-%d").date() if new_date_raw else None
            mark_no_show(termin=termin, reason=reason, user=request.user, reschedule_date=new_date)
            messages.success(request, "Nedolazak je evidentiran bez promjene zalihe ili komisije.")
        elif action == "odgodi":
            new_date_raw = request.POST.get("novi_datum", "").strip()
            new_date = (
                datetime.strptime(new_date_raw, "%Y-%m-%d").date()
                if new_date_raw else None
            )
            postpone_therapy(termin=termin, new_date=new_date, reason=reason, user=request.user)
            messages.success(
                request,
                (
                    "Termin je promijenjen bez potrošnje lijeka."
                    if new_date
                    else "Termin je odgođen i pacijent čeka novi termin."
                ),
            )
        elif action == "otkazi":
            cancel_therapy(termin=termin, reason=reason, user=request.user)
            messages.success(request, "Terapija je otkazana bez promjene zalihe ili komisije.")
        else:
            raise ValueError("Nepoznata workflow akcija.")
    except (ValueError, TypeError) as exc:
        messages.error(request, str(exc))
    profile_url = reverse("profil_pacijenta", args=[termin.pacijent_id])
    return redirect(f"{profile_url}?tab=terapije#terapije")


@login_required
@user_passes_test(je_doktor_ili_admin)
def upravljaj_pauzom_terapije(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    if request.method != "POST":
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)
    action = request.POST.get("pause_action", "")
    reason = request.POST.get("razlog", "").strip()
    try:
        if action == "pause":
            start_raw = request.POST.get("datum_pocetka", "")
            end_raw = request.POST.get("datum_zavrsetka", "")
            start_date = datetime.strptime(start_raw, "%Y-%m-%d").date()
            planned_end = datetime.strptime(end_raw, "%Y-%m-%d").date() if end_raw else None
            pause_patient_therapy(
                pacijent=pacijent,
                start_date=start_date,
                planned_end_date=planned_end,
                reason=reason,
                user=request.user,
            )
            messages.success(request, "Terapija je privremeno pauzirana.")
        elif action == "resume":
            resume_raw = request.POST.get("datum_nastavka", "")
            resume_date = datetime.strptime(resume_raw, "%Y-%m-%d").date()
            resume_patient_therapy(
                pacijent=pacijent,
                resume_date=resume_date,
                reason=reason,
                user=request.user,
            )
            messages.success(request, "Pacijent je vraćen u terapijsko planiranje.")
        else:
            raise ValueError("Nepoznata akcija pauze.")
    except (ValueError, TypeError) as exc:
        messages.error(request, str(exc))
    profile_url = reverse("profil_pacijenta", args=[pacijent.id])
    return redirect(f"{profile_url}?tab=terapije#terapije")


@login_required
@user_passes_test(je_koordinator_ili_admin)
def ponisti_terapiju(request, terapija_id):
    terapija = get_object_or_404(Terapija, id=terapija_id)
    if request.method != "POST":
        return redirect("profil_pacijenta", pacijent_id=terapija.pacijent_id)
    try:
        void_therapy(
            terapija=terapija,
            reason=request.POST.get("razlog", ""),
            user=request.user,
        )
    except (ValueError, PermissionError) as exc:
        messages.error(request, str(exc))
    else:
        messages.success(request, "Terapija je poništena i operativne količine su vraćene.")
    return redirect("profil_pacijenta", pacijent_id=terapija.pacijent_id)

@login_required
def lista_danas(request):
    danas = timezone.now().date()
    termini = [
        termin for termin in Termin.objects.select_related("pacijent", "lijek")
        .filter(datum=danas)
        .exclude(lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA)
        .order_by("vrijeme")
        if termin.pacijent.trenutni_korak_je_ambulanta()
    ]

    return render(request, "dashboard/lista.html", {
        "naslov": "Pacijenti danas",
        "termini": termini,
    })


@login_required
def lista_sutra(request):
    sutra = timezone.now().date() + timedelta(days=1)
    termini = [
        termin for termin in Termin.objects.select_related("pacijent", "lijek")
        .filter(datum=sutra)
        .exclude(lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA)
        .order_by("vrijeme")
        if termin.pacijent.trenutni_korak_je_ambulanta()
    ]

    return render(request, "dashboard/lista.html", {
        "naslov": "Pacijenti sutra",
        "termini": termini,
    })

@login_required
def komisije_uskoro(request):
    komisije = patients_for_next_commission()

    return render(request, "dashboard/komisije.html", {
        "komisije": komisije
    })

@login_required
def niske_zalihe(request):
    zalihe = kriticne_zalihe_iz_potreba()

    return render(request, "dashboard/zalihe.html", {
        "zalihe": zalihe
    })


@login_required
def plan_nabavke(request):
    pacijenti = Pacijent.objects.filter(aktivan=True)

    return render(request, "dashboard/plan_nabavke.html", {
        "pacijenti": pacijenti
    })


@login_required
def pacijenti_po_lijeku(request, lijek_id):
    lijek = get_object_or_404(Lijek, id=lijek_id)
    pacijenti = Pacijent.objects.filter(
        lijek_id__in=equivalent_medicine_ids(lijek),
        aktivan=True,
    )

    return render(request, "dashboard/pacijenti_po_lijeku.html", {
        "lijek": lijek,
        "pacijenti": pacijenti
    })


def napravi_pdf_putanju(naziv):
    output_dir = Path(settings.MEDIA_ROOT) / "generated"
    output_dir.mkdir(parents=True, exist_ok=True)
    return str(output_dir / naziv)


def lijek_je_infliximab(lijek):
    return get_therapy_group(lijek) == THERAPY_GROUP_REMSIMA


def lijek_je_vedolizumab(lijek):
    if not lijek:
        return False
    tekst = " ".join([
        str(getattr(lijek, "naziv", "") or ""),
        str(getattr(lijek, "genericki_naziv", "") or ""),
        str(getattr(lijek, "zasticeno_ime", "") or ""),
    ]).lower()
    return (
        "vedolizumab" in tekst
        or "entyvio" in tekst
    )


def format_bocice(kolicina):
    kolicina = Decimal(str(kolicina or 0))
    if kolicina == kolicina.to_integral_value():
        broj = int(kolicina)
        broj_label = str(broj)
    else:
        broj = None
        broj_label = str(kolicina.normalize()).replace(".", ",")

    if broj == 1:
        jedinica = "bočica"
    elif broj in [2, 3, 4]:
        jedinica = "bočice"
    else:
        jedinica = "bočica"
    return f"{broj_label} {jedinica}"


def infliximab_terapija_pdf_redovi(pacijent, terapija=None):
    lijek = pacijent.lijek
    if not lijek_je_infliximab(lijek):
        return None

    terapija = (
        terapija or pacijent.posljednja_stvarno_primljena_terapija()
    )
    kolicina = Decimal(str(getattr(terapija, "kolicina", None) or pacijent.doza_po_aplikaciji() or 0))
    mg = int(kolicina * Decimal("100")) if kolicina == kolicina.to_integral_value() else kolicina * Decimal("100")

    return [
        "1. Hydrocortison 100 mg i.v.",
        "u 100 ml 0,9% NaCl",
        "(Premedikacija)",
        "2. Remsima (Infliximab)",
        f"{format_bocice(kolicina)} = {mg} mg",
    ]


def terapija_pdf_redovi(pacijent, terapija=None):
    lijek = pacijent.lijek
    if not lijek:
        return []

    terapija = (
        terapija or pacijent.posljednja_stvarno_primljena_terapija()
    )
    kolicina = Decimal(str(getattr(terapija, "kolicina", None) or pacijent.doza_po_aplikaciji() or 0))

    if lijek_je_infliximab(lijek):
        return infliximab_terapija_pdf_redovi(pacijent, terapija)

    if lijek_je_vedolizumab(lijek):
        mg = int(kolicina * Decimal("300")) if kolicina == kolicina.to_integral_value() else kolicina * Decimal("300")
        return [
            "1. Entyvio (Vedolizumab)",
            f"{format_bocice(kolicina)} = {mg} mg",
        ]

    naziv = lijek.prikaz_naziv
    redovi = [f"1. {naziv}"]
    doza_po_jedinici = Decimal(str(getattr(terapija, "doza_mg", None) or 0))
    if doza_po_jedinici > 0:
        ukupno_mg = doza_po_jedinici * kolicina
        mg_label = (
            str(int(ukupno_mg))
            if ukupno_mg == ukupno_mg.to_integral_value()
            else str(ukupno_mg.normalize()).replace(".", ",")
        )
        jedinice = "jedinica" if kolicina == 1 else "jedinice"
        kolicina_label = (
            str(int(kolicina))
            if kolicina == kolicina.to_integral_value()
            else str(kolicina.normalize()).replace(".", ",")
        )
        redovi.append(f"{kolicina_label} {jedinice} = {mg_label} mg")
    else:
        redovi.append(f"{kolicina:g} jedinica")
    return redovi


def print_sljedeca_terapija(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    status_pacijenta = izracunaj_status_pacijenta(pacijent)
    path = napravi_pdf_putanju(f"sljedeca_terapija_{pacijent.id}.pdf")

    c = canvas.Canvas(path, pagesize=A4)
    c.setFont("DejaVuSans-Bold", 18)
    c.drawString(80, 780, "TheraFlow - Termin za sljedecu terapiju")

    c.setFont("DejaVuSans", 12)
    c.drawString(80, 730, f"Pacijent: {pacijent.ime} {pacijent.prezime}")
    c.drawString(80, 705, f"JMBG: {pacijent.jmbg}")
    c.drawString(80, 680, f"Lijek: {pacijent.lijek.prikaz_naziv if pacijent.lijek else 'Bez lijeka'}")
    c.drawString(80, 655, f"Interval: svakih {pacijent.efektivni_interval_sedmica()} sedmica")
    sljedeca_terapija_pdf = (
        format_date_bs(status_pacijenta["sljedeca_terapija"])
        if status_pacijenta["sljedeca_terapija"]
        else status_pacijenta["status"]
    )
    c.drawString(80, 630, f"Sljedeca terapija: {sljedeca_terapija_pdf}")

    c.drawString(80, 580, "Molimo pacijenta da se javi na zakazani termin.")
    c.save()

    return FileResponse(open(path, "rb"), as_attachment=False)


@login_required
def print_karton(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)

    sablon_path = os.path.join(
        settings.BASE_DIR,
        "media",
        "sabloni",
        "lista_terapije.pdf",
    )
    
    output_path = napravi_pdf_putanju(f"lista_terapije_{pacijent.id}.pdf")

    packet = BytesIO()
    c = canvas.Canvas(packet, pagesize=A4)

    danas = timezone.now().date()

    c.setFont("DejaVuSans-Bold", 10)

    # Datum gore desno
    c.drawString(470, 730, danas.strftime("%d/%m/%Y"))


    # Prezime i ime
    c.drawString(210, 682, f"{pacijent.prezime.upper()} {pacijent.ime.upper()}")

    # Godina rođenja
    if pacijent.datum_rodenja:
        c.drawString(
            110,
            700,
            pacijent.datum_rodenja.strftime("%d/%m/%Y")
        )

    # Dijagnoza
    c.drawString(110, 650, str(pacijent.dijagnoza))

    c.setFont("DejaVuSans", 10)

    zadnja_terapija = pacijent.posljednja_stvarno_primljena_terapija()
    y = 565
    for red in terapija_pdf_redovi(pacijent, zadnja_terapija):
        c.drawString(365, y, red)
        y -= 15

    c.save()
    packet.seek(0)

    overlay_pdf = PdfReader(packet)
    template_pdf = PdfReader(open(sablon_path, "rb"))

    writer = PdfWriter()

    page = template_pdf.pages[0]
    page.merge_page(overlay_pdf.pages[0])
    writer.add_page(page)

    with open(output_path, "wb") as f:
        writer.write(f)

    return FileResponse(open(output_path, "rb"), as_attachment=False)

@login_required
def print_komisija(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    komisijski_plan = (
        commission_planning_row_for_patient(pacijent)
        if commission_demand_v2_enabled()
        else None
    )
    if komisijski_plan:
        potrebno = Decimal(str(
            komisijski_plan.get("final_procurement_units", 0) or 0
        ))
        if (
            not komisijski_plan.get("eligible_for_current_cycle")
            or potrebno <= 0
        ):
            return HttpResponse(
                "PDF komisijskog zahtjeva nije moguće kreirati za količinu 0 "
                "ili pacijenta koji ne pripada trenutnom ciklusu.",
                status=400,
                content_type="text/plain; charset=utf-8",
            )
    else:
        potreba = calculate_patient_commission_need(pacijent)
        potrebno = Decimal(str(potreba["za_novu_komisiju"] or 0))
        if potrebno <= 0:
            return HttpResponse(
                "PDF komisijskog zahtjeva nije moguće kreirati za količinu 0.",
                status=400,
                content_type="text/plain; charset=utf-8",
            )
    path = napravi_pdf_putanju(f"komisija_{pacijent.id}.pdf")

    c = canvas.Canvas(path, pagesize=A4)
    c.setFont("DejaVuSans-Bold", 18)
    c.drawString(80, 780, "Zahtjev za komisiju / nabavku terapije")

    c.setFont("DejaVuSans", 12)
    c.drawString(80, 730, f"Pacijent: {pacijent.ime} {pacijent.prezime}")
    c.drawString(80, 705, f"JMBG: {pacijent.jmbg}")
    c.drawString(80, 680, f"Dijagnoza: {pacijent.dijagnoza}")
    c.drawString(80, 655, f"Zaštićeno ime: {pacijent.lijek.brand_name if pacijent.lijek else ''}")
    c.drawString(80, 630, f"Generičko ime: {pacijent.lijek.generic_name if pacijent.lijek else ''}")
    c.drawString(80, 605, f"Interval: svakih {pacijent.efektivni_interval_sedmica()} sedmica")
    c.drawString(
        80,
        580,
        f"Za narednu komisiju tražiti: {potrebno} doza"
    )

    c.save()

    return FileResponse(
        open(path, "rb"),
        as_attachment=False
    )

@login_required
def print_razduzivanje(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)

    terapija = None
    terapija_id = request.GET.get("terapija_id", "").strip()
    if terapija_id:
        if not terapija_id.isdigit():
            raise Http404("Neispravan identifikator terapije.")
        terapija = get_object_or_404(
            Terapija.objects.select_related("lijek", "evidentirao"),
            id=int(terapija_id),
            pacijent=pacijent,
            workflow_status=Terapija.STATUS_POTVRDJENA,
            tip_evidencije=Terapija.TIP_AMBULANTA,
        )

    aktivna_komisija = Komisija.objects.filter(
        pacijent=pacijent,
        lijek=(terapija.lijek if terapija else pacijent.lijek),
        status="AKTIVNA"
    ).order_by("-datum_odobrenja").first()

    sablon_path = os.path.join(
        settings.BASE_DIR,
        "media",
        "sabloni",
        "razduzivanje_sablon.pdf"
    )
    output_suffix = f"terapija_{terapija.id}" if terapija else f"pacijent_{pacijent.id}"
    output_path = napravi_pdf_putanju(f"razduzivanje_{output_suffix}.pdf")

    render_pdf_overlay(
        sablon_path,
        output_path,
        get_pdf_coords("razduzenje_zavod"),
        razduzenje_values(pacijent, aktivna_komisija, terapija=terapija),
        debug=getattr(settings, "PDF_DEBUG", False),
    )

    return FileResponse(open(output_path, "rb"), as_attachment=False)


@login_required
def print_razduzenje_izdavanja(request, izdavanje_id):
    if not korisnik_moze_razduzenje(request.user):
        raise PermissionDenied("Nemate ovlastenje za razduzenje prema Zavodu.")

    izdavanje = get_object_or_404(
        KucnoIzdavanje.objects.select_related(
            "pacijent",
            "lijek",
            "komisija",
            "pacijent_zaduzenje",
            "korisnik_koji_je_izdao",
        ),
        id=izdavanje_id,
    )
    osiguraj_razduzenje_snapshot(izdavanje)
    missing = validiraj_razduzenje_izdavanja(izdavanje)
    if missing:
        upisi_log(
            request.user,
            "Razduzenje prema Zavodu nije generisano",
            pacijent=izdavanje.pacijent,
            objekat=izdavanje,
            opis=f"Izdavanje {izdavanje.id}: {', '.join(missing)}.",
        )
        return HttpResponse(
            "Razduzenje prema Zavodu nije generisano: " + "; ".join(missing) + ".",
            status=400,
            content_type="text/plain; charset=utf-8",
        )

    sablon_path = os.path.join(
        settings.BASE_DIR,
        "media",
        "sabloni",
        "razduzivanje_sablon.pdf"
    )
    output_path = napravi_pdf_putanju(f"razduzenje_izdavanje_{izdavanje.id}.pdf")

    render_pdf_overlay(
        sablon_path,
        output_path,
        get_pdf_coords("razduzenje_zavod"),
        razduzenje_izdavanje_values(izdavanje),
        debug=getattr(settings, "PDF_DEBUG", False),
    )
    evidentiraj_generisanje_razduzenja(izdavanje, request.user)

    return FileResponse(open(output_path, "rb"), as_attachment=False)

@login_required
def upload_sabloni(request):
    sabloni = DokumentSablon.objects.all()

    return render(request, "dashboard/upload_sabloni.html", {
        "sabloni": sabloni
    })


def dokument_file_response(dokument, as_attachment=False):
    if not dokument.fajl:
        raise Http404("Dokument nema fajl.")

    content_type, _ = mimetypes.guess_type(dokument.fajl.name)
    response = FileResponse(
        dokument.fajl.open("rb"),
        as_attachment=as_attachment,
        filename=os.path.basename(dokument.fajl.name),
        content_type=content_type or "application/octet-stream",
    )
    return response


@login_required
def dokumenti_centar(request):
    q = request.GET.get("q", "").strip()
    tip = request.GET.get("tip", "").strip()
    lijek = request.GET.get("lijek", "").strip()

    dokumenti = (
        DokumentPacijenta.objects
        .filter(aktivan=True, pacijent__aktivan=True)
        .select_related("pacijent", "pacijent__lijek", "uploaded_by")
        .order_by("-datum_dokumenta", "-datum_uploada")
    )

    if q:
        dokumenti = dokumenti.filter(
            Q(naziv__icontains=q)
            | Q(pacijent__ime__icontains=q)
            | Q(pacijent__prezime__icontains=q)
            | Q(pacijent__jmbg__icontains=q)
            | Q(napomena__icontains=q)
        )

    if tip:
        dokumenti = dokumenti.filter(tip_dokumenta=tip)

    if lijek:
        dokumenti = dokumenti.filter(pacijent__lijek_id=lijek)

    tipovi_count = []
    for value, label in DokumentPacijenta.TIPOVI_DOKUMENTA:
        count = DokumentPacijenta.objects.filter(
            aktivan=True,
            pacijent__aktivan=True,
            tip_dokumenta=value,
        ).count()
        tipovi_count.append({
            "value": value,
            "label": label,
            "count": count,
        })

    return render(request, "dashboard/dokumenti_centar.html", {
        "dokumenti": dokumenti,
        "q": q,
        "tip": tip,
        "lijek": lijek,
        "tipovi": DokumentPacijenta.TIPOVI_DOKUMENTA,
        "tipovi_count": tipovi_count,
        "lijekovi": active_therapy_medicines(),
        "ukupno_dokumenata": DokumentPacijenta.objects.filter(
            aktivan=True,
            pacijent__aktivan=True,
        ).count(),
    })


@login_required
def novi_dokument(request):
    pacijent_id = request.GET.get("pacijent")
    initial = {}
    if pacijent_id:
        initial["pacijent"] = pacijent_id

    if request.method == "POST":
        form = DokumentPacijentaForm(request.POST, request.FILES)
        if form.is_valid():
            dokument = form.save(commit=False)
            dokument.uploaded_by = request.user
            dokument.save()
            upisi_log(
                request.user,
                "Upload dokumenta pacijenta",
                pacijent=dokument.pacijent,
                objekat=dokument,
                opis=f"{dokument.naziv} ({dokument.get_tip_dokumenta_display()})",
            )
            messages.success(request, "Dokument je uspješno dodan.")
            return redirect("dokument_pregled", id=dokument.id)
    else:
        form = DokumentPacijentaForm(initial=initial)

    return render(request, "dashboard/novi_dokument.html", {
        "form": form,
    })


@login_required
def dokument_pregled(request, id):
    dokument = get_object_or_404(
        DokumentPacijenta.objects.select_related("pacijent"),
        id=id,
        aktivan=True,
        pacijent__aktivan=True,
    )

    if dokument.je_pdf():
        return dokument_file_response(dokument, as_attachment=False)

    if dokument.je_slika():
        return render(request, "dashboard/dokument_preview.html", {
            "dokument": dokument,
        })

    return dokument_file_response(dokument, as_attachment=True)


@login_required
def dokument_preuzmi(request, id):
    dokument = get_object_or_404(
        DokumentPacijenta,
        id=id,
        aktivan=True,
        pacijent__aktivan=True,
    )
    return dokument_file_response(dokument, as_attachment=True)


@login_required
def dokument_arhiviraj(request, id):
    dokument = get_object_or_404(DokumentPacijenta, id=id, aktivan=True)

    if request.method == "POST":
        dokument.aktivan = False
        dokument.save(update_fields=["aktivan"])
        upisi_log(
            request.user,
            "Arhiviran dokument pacijenta",
            pacijent=dokument.pacijent,
            objekat=dokument,
            opis=dokument.naziv,
        )
        messages.success(request, "Dokument je arhiviran.")
        return redirect("dokumenti_centar")

    return render(request, "dashboard/potvrdi_arhiviranje_dokumenta.html", {
        "dokument": dokument,
    })

@login_required
def lista_pacijenata(request):
    def lijek_css_class(lijek):
        return medicine_group_css(lijek)

    def lijek_grupa(pacijent):
        if not pacijent.lijek_id:
            return "Bez lijeka"
        program = (
            pacijent.terapijski_program
            or pacijent.lijek.terapijski_program
        )
        return program.naziv if program else medicine_group_label(pacijent.lijek)

    def format_datum(datum):
        return datum.strftime("%d/%m/%Y") if datum else "Nije zakazana"

    q = request.GET.get("q", "").strip()
    canonical_therapy_filter = request.GET.get("terapija", "").strip().lower()
    legacy_medicine_filter = request.GET.get("lijek", "").strip().lower()
    lijek_filter = canonical_therapy_filter or legacy_medicine_filter
    status_filter = request.GET.get("status", "").strip().lower()
    quick_view = request.GET.get("view", "").strip().lower()
    if not quick_view:
        quick_view = {
            "hitno": "action",
            "komisija": "commission",
            "neaktivni": "inactive",
            "aktivni": "active",
        }.get(status_filter, "active")
    if quick_view not in {
        "active", "action", "therapy-7", "commission", "covered", "inactive"
    }:
        quick_view = "active"
    sort_by = request.GET.get("sort", "priority").strip().lower()
    if sort_by not in {"priority", "name", "medicine", "next", "coverage", "commission"}:
        sort_by = "priority"
    try:
        per_page = int(request.GET.get("per_page", 25))
    except (TypeError, ValueError):
        per_page = 25
    if per_page not in {25, 50, 100}:
        per_page = 25
    group_by_drug = request.GET.get("group", "") == "drug"
    today = timezone.localdate()

    from patients.querysets import with_workflow_data

    svi_pacijenti = with_workflow_data(Pacijent.objects.all()).order_by("prezime", "ime")
    komisijski_v2 = commission_demand_v2_enabled()
    komisijski_statusi = (
        commission_patient_status_snapshot()
        if komisijski_v2
        else None
    )
    komisijski_plan_po_pacijentu = (
        komisijski_statusi["row_by_patient_id"]
        if komisijski_statusi
        else {}
    )

    brojaci_pacijenata = svi_pacijenti.aggregate(
        ukupno_zapisa=Count("pk"),
        ukupno_aktivnih=Count("pk", filter=Q(aktivan=True)),
        venske_terapije=Count(
            "pk",
            filter=(
                Q(aktivan=True)
                & therapy_regimen_type_q(TYPE_INFUSION, prefix="lijek")
            ),
        ),
        sc_kucne_terapije=Count(
            "pk",
            filter=(
                Q(aktivan=True)
                & therapy_regimen_type_q(TYPE_HOME_SC, prefix="lijek")
            ),
        ),
        oralne_terapije=Count(
            "pk",
            filter=(
                Q(aktivan=True)
                & therapy_regimen_type_q(TYPE_ORAL, prefix="lijek")
            ),
        ),
    )
    ukupno_zapisa = brojaci_pacijenata["ukupno_zapisa"]
    ukupno_aktivnih = brojaci_pacijenata["ukupno_aktivnih"]
    stats = {
        "ukupno_aktivnih": ukupno_aktivnih,
        "ukupno_zapisa": ukupno_zapisa,
        "venske_terapije": brojaci_pacijenata["venske_terapije"],
        "sc_kucne_terapije": brojaci_pacijenata["sc_kucne_terapije"],
        "oralne_terapije": brojaci_pacijenata["oralne_terapije"],
        "za_djelovanje": 0,
    }
    upcoming_action_ids = set(
        Termin.objects.filter(
            pacijent__aktivan=True,
            status=Termin.STATUS_PLANIRANA,
            datum__gte=today,
            datum__lte=today + timedelta(days=7),
        ).values_list("pacijent_id", flat=True)
    )
    if komisijski_statusi:
        planner_action_ids = (
            set(komisijski_statusi["delivery_risk_ids"])
            | set(komisijski_statusi["included_ids"])
            | set(komisijski_statusi["review_ids"])
        )
        fallback_action_ids = set()
    else:
        from patients.patient_risk import patient_risk

        fallback_action_ids = {
            patient.pk
            for patient in with_workflow_data(
                Pacijent.objects.filter(aktivan=True, lijek__isnull=False)
            )
            if patient_risk(patient).urgent
        }
        planner_action_ids = fallback_action_ids
    action_patient_ids = planner_action_ids | upcoming_action_ids
    stats["za_djelovanje"] = len(action_patient_ids)

    pacijenti = svi_pacijenti

    if quick_view == "inactive":
        pacijenti = pacijenti.filter(aktivan=False)
    else:
        pacijenti = pacijenti.filter(aktivan=True)

    if q:
        pacijenti = pacijenti.filter(
            Q(ime__icontains=q)
            | Q(prezime__icontains=q)
            | Q(jmbg__icontains=q)
            | Q(dijagnoza__icontains=q)
            | Q(mkb_sifra__icontains=q)
            | Q(terapijski_program__naziv__icontains=q)
            | Q(lijek__naziv__icontains=q)
            | Q(lijek__genericki_naziv__icontains=q)
            | Q(lijek__zasticeno_ime__icontains=q)
            | Q(komisija__status__icontains=q)
            | Q(komisija__broj_saglasnosti__icontains=q)
        )

    if lijek_filter:
        if lijek_filter == "bez-lijeka":
            pacijenti = pacijenti.filter(lijek__isnull=True)
        elif lijek_filter == "ostali":
            poznati = (
                therapy_group_q(THERAPY_GROUP_ENTYVIO, prefix="lijek")
                | therapy_group_q(THERAPY_GROUP_REMSIMA, prefix="lijek")
                | therapy_group_q(THERAPY_GROUP_ADALIMUMAB, prefix="lijek")
                | medicine_group_q("ustekinumab", prefix="lijek")
                | medicine_group_q("risankizumab", prefix="lijek")
            )
            pacijenti = pacijenti.exclude(poznati).filter(lijek__isnull=False)
        elif lijek_filter.isdigit() and canonical_therapy_filter:
            program_id = int(lijek_filter)
            pacijenti = pacijenti.filter(
                Q(terapijski_program_id=program_id)
                | Q(
                    terapijski_program__isnull=True,
                    lijek__terapijski_program_id=program_id,
                )
            )
        elif lijek_filter.isdigit():
            # Backward compatibility for saved legacy links that filtered by
            # a concrete Lijek id.
            pacijenti = pacijenti.filter(lijek_id=int(lijek_filter))
        else:
            filter_grupa = {
                "entyvio": THERAPY_GROUP_ENTYVIO,
                "remsima": THERAPY_GROUP_REMSIMA,
                "adalimumab": THERAPY_GROUP_ADALIMUMAB,
            }.get(lijek_filter)
            pacijenti = pacijenti.filter(
                therapy_group_q(filter_grupa, prefix="lijek")
                if filter_grupa
                else medicine_group_q(lijek_filter, prefix="lijek")
            )

    pacijenti = pacijenti.distinct().annotate(
        _list_next_date=Min(
            "termin__datum",
            filter=Q(termin__status=Termin.STATUS_PLANIRANA),
        )
    )

    # Za listu od 100+ zapisa sortiranje i paginacija koriste lagani indeks.
    # Puni workflow se računa tek za redove trenutne stranice.
    indeks_pacijenata = list(
        pacijenti.values(
            "pk",
            "ime",
            "prezime",
            "lijek__naziv",
            "lijek__zasticeno_ime",
            "lijek__genericki_naziv",
            "terapijski_program__naziv",
            "_list_next_date",
        )
    )

    delivery_risk_ids = (
        komisijski_statusi.get("delivery_risk_ids", set())
        if komisijski_statusi else fallback_action_ids
    )
    included_ids = komisijski_statusi.get("included_ids", set()) if komisijski_statusi else set()
    review_ids = komisijski_statusi.get("review_ids", set()) if komisijski_statusi else set()
    covered_ids = komisijski_statusi.get("covered_ids", set()) if komisijski_statusi else set()

    def indeksni_podaci(red):
        planning = komisijski_plan_po_pacijentu.get(red["pk"]) or {}
        coverage_calculation = planning.get("coverage_calculation")
        ciklus = planning.get("preporuceni_komisijski_ciklus")
        komisija_datum = (
            coverage_calculation.commission_date
            if coverage_calculation is not None else
            getattr(ciklus, "datum_komisije", None)
        )
        pokrivenost_datum = (
            coverage_calculation.physically_secured_until
            if coverage_calculation is not None else (
                planning.get("fizicki_pokriven_do_operativno")
                or planning.get("fizicki_pokriven_do")
                or planning.get("pokriven_do")
            )
        )
        sljedeca = (
            coverage_calculation.next_dispensing_date
            if coverage_calculation is not None else red["_list_next_date"]
        )
        if red["pk"] in delivery_risk_ids:
            prioritet = 10
        elif sljedeca == today:
            prioritet = 20
        elif sljedeca and today < sljedeca <= today + timedelta(days=7):
            prioritet = 30
        elif red["pk"] in included_ids:
            prioritet = 40
        elif red["pk"] in review_ids:
            prioritet = 45
        else:
            prioritet = 50
        return prioritet, sljedeca, pokrivenost_datum, komisija_datum

    if quick_view == "action":
        indeks_pacijenata = [
            red for red in indeks_pacijenata if indeksni_podaci(red)[0] <= 45
        ]
    elif quick_view == "therapy-7":
        indeks_pacijenata = [
            red for red in indeks_pacijenata
            if red["_list_next_date"]
            and today <= red["_list_next_date"] <= today + timedelta(days=7)
        ]
    elif quick_view == "commission":
        indeks_pacijenata = [
            red for red in indeks_pacijenata
            if red["pk"] in included_ids
            or (
                indeksni_podaci(red)[3]
                and indeksni_podaci(red)[3] <= today + timedelta(days=75)
            )
        ]
    elif quick_view == "covered":
        indeks_pacijenata = [
            red for red in indeks_pacijenata
            if red["pk"] in covered_ids or indeksni_podaci(red)[2]
        ]

    far_future = datetime.max.date()
    if sort_by == "name":
        index_sort_key = lambda red: (
            (red["prezime"] or "").lower(),
            (red["ime"] or "").lower(),
            red["pk"],
        )
    elif sort_by == "medicine":
        index_sort_key = lambda red: (
            (
                red["terapijski_program__naziv"]
                or red["lijek__genericki_naziv"]
                or red["lijek__naziv"]
                or ""
            ).lower(),
            (red["prezime"] or "").lower(),
            (red["ime"] or "").lower(),
        )
    elif sort_by == "next":
        index_sort_key = lambda red: (
            red["_list_next_date"] or far_future,
            (red["prezime"] or "").lower(),
        )
    elif sort_by == "coverage":
        index_sort_key = lambda red: (
            indeksni_podaci(red)[2] or far_future,
            (red["prezime"] or "").lower(),
        )
    elif sort_by == "commission":
        index_sort_key = lambda red: (
            indeksni_podaci(red)[3] or far_future,
            (red["prezime"] or "").lower(),
        )
    else:
        index_sort_key = lambda red: (
            indeksni_podaci(red)[0],
            red["_list_next_date"] or far_future,
            (red["prezime"] or "").lower(),
            (red["ime"] or "").lower(),
        )
    indeks_pacijenata.sort(key=index_sort_key)

    paginator = Paginator(indeks_pacijenata, per_page)
    page_obj = paginator.get_page(request.GET.get("page"))
    page_ids = [red["pk"] for red in page_obj.object_list]
    pacijenti_po_id = {
        pacijent.pk: pacijent
        for pacijent in with_workflow_data(Pacijent.objects.filter(pk__in=page_ids))
    }
    pacijent_list = [pacijenti_po_id[pk] for pk in page_ids if pk in pacijenti_po_id]
    prikazani_pacijenti = []

    for pacijent in pacijent_list:
        status_pacijenta = izracunaj_status_pacijenta(pacijent)
        from patients.patient_risk import patient_risk
        strukturirani_rizik = patient_risk(
            pacijent,
            workflow=status_pacijenta,
            planning=(
                komisijski_plan_po_pacijentu.get(pacijent.pk) or {}
                if komisijski_statusi is not None
                else None
            ),
        )
        status = status_pacijenta["status"].upper()
        status_css = status_pacijenta["status_css"]
        komisijski_plan = komisijski_plan_po_pacijentu.get(pacijent.pk)
        coverage_calculation = (
            komisijski_plan.get("coverage_calculation")
            if komisijski_plan else None
        )
        if (
            komisijski_plan
            and not status_pacijenta.get("aktivna_komisija")
            and Decimal(str(status_pacijenta.get("rezervisano_u_frizideru_za_pacijenta") or 0))
            + Decimal(str(status_pacijenta.get("kod_pacijenta") or 0)) > 0
            and not komisijski_plan.get("included_in_draft")
            and not komisijski_plan.get("rizik_dostave")
            and Decimal(str(komisijski_plan.get("final_procurement_units") or 0)) <= 0
        ):
            fizicki_pokriven_do = komisijski_plan.get(
                "fizicki_pokriven_do_operativno"
            )
            status = (
                f"FIZIČKI POKRIVEN DO {fizicki_pokriven_do:%d.%m.%Y.}"
                if fizicki_pokriven_do else "FIZIČKI POKRIVEN"
            )
            status_css = "status-kucna-terapija"
            status_pacijenta["administrativni_status"] = (
                "Bez vlastitog komisijskog odobrenja"
            )
            status_pacijenta["administrativni_status_css"] = "status-komisija"
        if settings.DEBUG and get_therapy_group(pacijent.lijek) == THERAPY_GROUP_ADALIMUMAB:
            logger.debug(
                "Patient therapy diagnostic: pacijent_id=%s lijek_id=%s naziv=%r genericki_naziv=%r "
                "therapy_group=%s aktivna_komisija=%r zaduzeno_lijekova=%s workflow_status=%r pokriven_do=%r",
                pacijent.id,
                pacijent.lijek_id,
                pacijent.lijek.naziv,
                pacijent.lijek.genericki_naziv,
                get_therapy_group(pacijent.lijek),
                pacijent.aktivna_komisija(),
                pacijent.zaduzeno_lijekova(),
                status_pacijenta.get("status"),
                status_pacijenta.get("pokriven_do"),
            )

        if not pacijent.aktivan:
            status = "NEAKTIVAN"
            status_css = "status-neutral"
        elif not pacijent.lijek:
            status = "BEZ LIJEKA"
            status_css = "status-neutral"
        elif coverage_calculation and coverage_calculation.immediate_risk:
            status = "RIZIK PREKIDA TERAPIJE"
            status_css = "status-hitno"
            status_pacijenta["status_razlog"] = (
                coverage_calculation.warning_text
            )
        elif komisijski_plan and komisijski_plan.get("rizik_dostave"):
            status = "RIZIK DOSTAVE"
            status_css = "status-hitno"
        elif komisijski_plan and komisijski_plan.get("included_in_draft"):
            status = "POTREBNA KOMISIJA"
            status_css = "status-komisija"
            status_pacijenta["status_razlog"] = komisijski_plan.get(
                "status_razlog",
                status_pacijenta["status_razlog"],
            )

        sljedeca = (
            coverage_calculation.next_dispensing_date
            if coverage_calculation is not None else
            status_pacijenta["sljedeca_terapija"]
        )
        inicijali = f"{(pacijent.ime or ' ')[0]}{(pacijent.prezime or ' ')[0]}".upper()
        naziv_grupe = lijek_grupa(pacijent)
        css = lijek_css_class(pacijent.lijek)

        if not pacijent.aktivan:
            priority = 70
            primary_status = "Neaktivan"
        elif coverage_calculation and coverage_calculation.immediate_risk:
            priority = 10
            primary_status = "Rizik prekida terapije"
        elif strukturirani_rizik.code in {
            "THERAPY_LATE", "STOCK", "COMMISSION_COVERAGE"
        }:
            priority = 0
            primary_status = "Hitno"
        elif strukturirani_rizik.code == "DELIVERY_RISK":
            priority = 10
            primary_status = "Rizik prekida terapije"
        elif sljedeca == today and coverage_calculation is None:
            priority = 20
            primary_status = "Terapija danas"
        elif (
            sljedeca and today < sljedeca <= today + timedelta(days=7)
            and coverage_calculation is None
        ):
            priority = 30
            primary_status = "Terapija u narednih 7 dana"
        elif komisijski_plan and komisijski_plan.get("included_in_draft"):
            priority = 40
            primary_status = "Komisija uskoro"
        elif strukturirani_rizik.code == "REVIEW":
            priority = 45
            primary_status = "Potrebna provjera"
        else:
            priority = 50
            primary_status = status.title()

        if (
            "FIZI" in status.upper()
            and "POKRIVEN" in status.upper()
        ):
            primary_status = status.capitalize()
        elif status_pacijenta.get("aktivna_komisija") and priority >= 50:
            primary_status = "Komisijski pokriven"
        elif sljedeca is None and priority >= 50 and coverage_calculation is None:
            primary_status = "Čeka zakazivanje"
        elif coverage_calculation is not None and priority >= 50:
            primary_status = coverage_calculation.status_label
        if coverage_calculation is not None:
            # Kućna terapija uvijek izlaže odluku istog kanonskog rezultata;
            # tehničko članstvo u nacrtu ne smije je preimenovati u
            # generičko "Komisija uskoro".
            primary_status = coverage_calculation.status_label

        secondary_parts = []
        if status_pacijenta.get("sekundarni_status"):
            secondary_parts.append(status_pacijenta["sekundarni_status"])
        if status_pacijenta.get("administrativni_status"):
            secondary_parts.append(
                status_pacijenta["administrativni_status"].lower()
            )
        if not secondary_parts and strukturirani_rizik.reason:
            secondary_parts.append(strukturirani_rizik.reason)

        commission_window = (
            coverage_calculation.commission_window
            if coverage_calculation is not None else (
                komisijski_plan.get("preporuceni_komisijski_ciklus")
                if komisijski_plan else None
            )
        )
        commission_date = (
            commission_window.datum_komisije
            if commission_window else None
        )
        if komisijski_plan and komisijski_plan.get("included_in_draft"):
            commission_text = (
                f"Uključiti u ciklus {commission_date:%d.%m.%Y.}"
                if commission_date else "Uključiti u naredni komisijski ciklus"
            )
        elif commission_date:
            commission_text = f"Planirati u ciklusu {commission_date:%d.%m.%Y.}"
        elif status_pacijenta.get("aktivna_komisija"):
            commission_text = "Aktivno komisijsko odobrenje"
        else:
            commission_text = "Nije potrebna trenutna komisija"

        coverage_date = (
            coverage_calculation.physically_secured_until
            if coverage_calculation is not None else (
                komisijski_plan.get("fizicki_pokriven_do_operativno")
                or komisijski_plan.get("fizicki_pokriven_do")
                or komisijski_plan.get("pokriven_do")
                if komisijski_plan else status_pacijenta.get("pokriven_do")
            )
        )
        reserved = Decimal(str(
            status_pacijenta.get("rezervisano_u_frizideru_za_pacijenta") or 0
        ))
        at_patient = Decimal(str(status_pacijenta.get("kod_pacijenta") or 0))
        physical_quantity = reserved + at_patient
        physical_display = (
            f"{physical_quantity:g} "
            f"{pacijent.lijek.jedinica_zalihe_za_kolicinu(physical_quantity)}"
            if pacijent.lijek_id else "0"
        )
        active_commission = status_pacijenta.get("aktivna_komisija")
        commission_right = (
            getattr(active_commission, "preostale_doze", None)
            if active_commission and not isinstance(active_commission, bool)
            else None
        )
        first_uncovered = (
            coverage_calculation.first_without_available_source
            if coverage_calculation is not None else (
                komisijski_plan.get("prva_nepokrivena_terapija")
                if komisijski_plan else None
            )
        )
        recommended_action = (
            coverage_calculation.current_action
            if coverage_calculation is not None else (
                komisijski_plan.get("sljedeci_korak")
                if komisijski_plan else status_pacijenta.get("status_razlog")
            )
        )

        pacijent.ui = {
            "inicijali": inicijali,
            "lijek_naziv": pacijent.terapija_za_prikaz,
            "lijek_css": css,
            "sljedeca_terapija": format_datum(sljedeca),
            "next_event_label": (
                "Sljedeće izdavanje"
                if coverage_calculation is not None else "Sljedeća terapija"
            ),
            "next_event_value": (
                format_datum(sljedeca)
                if sljedeca else (
                    "Nije potrebno trenutno izdavanje"
                    if coverage_calculation is not None else "Nije zakazana"
                )
            ),
            "status": status,
            "status_razlog": status_pacijenta["status_razlog"],
            "rizik_kod": strukturirani_rizik.code,
            "rizik_naziv": strukturirani_rizik.label,
            "rizik_razlog": strukturirani_rizik.reason,
            "status_css": status_css,
            "primary_status": primary_status,
            "secondary_status": " · ".join(secondary_parts),
            "priority": priority,
            "next_date": sljedeca,
            "coverage_date": coverage_date,
            "commission_date": commission_date,
            "commission_text": commission_text,
            "therapy_name": pacijent.terapija_za_prikaz,
            "therapy_product": (
                pacijent.trenutni_proizvod.prikaz_naziv
                if pacijent.trenutni_proizvod else "Nije konfigurisan"
            ),
            # Compatibility for older partials/integrations; this is now the
            # canonical therapy, never the brand/SKU identity.
            "therapy_brand": pacijent.terapija_za_prikaz,
            "therapy_generic": "",
            "therapy_phase": pacijent.terapijska_faza() if pacijent.lijek_id else "Nije definisana",
            "diagnosis_text": " · ".join(
                value for value in (pacijent.dijagnoza, pacijent.mkb_sifra) if value
            ),
            "physical_display": physical_display,
            "commission_right": commission_right,
            "first_uncovered": first_uncovered,
            "recommended_action": recommended_action or "Nije potrebna trenutna akcija",
            "sekundarni_status": status_pacijenta.get("sekundarni_status", ""),
            "administrativni_status": status_pacijenta.get(
                "administrativni_status", ""
            ),
            "administrativni_status_css": status_pacijenta.get(
                "administrativni_status_css", "status-neutral"
            ),
            "inactive": not pacijent.aktivan,
        }
        pacijent.ui["group_name"] = naziv_grupe
        prikazani_pacijenti.append(pacijent)

    pacijent_list = prikazani_pacijenti
    page_obj.object_list = pacijent_list

    grupe_map = {}
    for pacijent in pacijent_list:
        naziv_grupe = pacijent.ui["group_name"]
        if naziv_grupe not in grupe_map:
            grupe_map[naziv_grupe] = {
                "naziv": naziv_grupe,
                "css": pacijent.ui["lijek_css"],
                "pacijenti": [],
                "aktivnih": 0,
            }
        grupe_map[naziv_grupe]["pacijenti"].append(pacijent)
        if pacijent.aktivan:
            grupe_map[naziv_grupe]["aktivnih"] += 1

    grupe = sorted(
        grupe_map.values(),
        key=lambda grupa: (
            grupa["naziv"] == "Bez lijeka",
            grupa["naziv"].casefold(),
        ),
    )

    pagination_params = request.GET.copy()
    pagination_params.pop("page", None)
    pagination_query = pagination_params.urlencode()

    return render(request, "dashboard/lista_pacijenata.html", {
        "pacijenti": pacijent_list,
        "grupe_pacijenata": grupe,
        "stats": stats,
        "therapy_summary": active_patient_therapy_summary(),
        "q": q,
        "lijek_filter": lijek_filter,
        "lijekovi_filter": active_therapy_programs(),
        "status_filter": status_filter,
        "quick_view": quick_view,
        "sort_by": sort_by,
        "per_page": per_page,
        "group_by_drug": group_by_drug,
        "pagination_query": pagination_query,
        "page_obj": page_obj,
    })

@login_required
def lista_terapija(request):
    terapije = Terapija.objects.exclude(
        lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA
    ).select_related(
        "pacijent", "lijek", "lijek__terapijski_program"
    ).order_by("-datum")

    return render(request, "dashboard/lista_terapija.html", {
        "terapije": terapije
    })

@login_required
def lista_komisija(request):
    komisije = Komisija.objects.all().order_by("-datum_odobrenja")

    return render(request, "dashboard/lista_komisija.html", {
        "komisije": komisije
    })

@login_required
def lista_zaliha(request):
    from patients.inventory_presentation import build_inventory_presentation
    from patients.stock_risk import StockRiskService

    summary = StockRiskService().summary()
    for row in summary["rows"]:
        procurement = procurement_breakdown(
            row.get("za_novu_komisiju", 0),
            row["lijek"],
        )
        row["nabavka_komisije"] = procurement
        row["neto_jedinica_prikaza"] = procurement_unit_display_label(
            row.get("izracunata_potreba_komisije", 0),
            row["lijek"],
        )
        row["za_novu_komisiju"] = procurement["rounded_procurement_units"]
        row["broj_pakovanja_komisije"] = procurement["package_count"]
        row["komisijska_izracunata_potreba"] = (
            Decimal(str(row.get("komisijska_osnovna_potreba") or 0))
            + Decimal(str(row.get("komisijska_sigurnosna_rezerva") or 0))
        )
        potreba_ciklusa = Decimal(str(
            row.get("kolicina_za_preporuceni_ciklus") or 0
        ))
        slobodno = Decimal(str(row.get("slobodno_raspolozivo") or 0))
        row["pokriveno_slobodnom_zalihom"] = min(
            potreba_ciklusa,
            slobodno,
        )
    presentation = build_inventory_presentation(summary["rows"])
    return render(request, "dashboard/lista_zaliha.html", {
        "zalihe": presentation["rows"],
        "inventory_groups": presentation["groups"],
        "inventory_overview": presentation["overview"],
        "ukupno_u_frizideru": summary["ukupno_u_frizideru"],
        "ukupno_kod_pacijenata": summary["ukupno_kod_pacijenata"],
        "lijekovi_za_komisiju": summary["lijekovi_za_komisiju"],
        "kriticni_lijekovi": summary["kriticni_lijekovi"],
    })

@login_required
def kalendar_terapija(request):
    danas = timezone.now().date()
    demo_weekend_active = demo_weekend_appointments_enabled()
    komisijski_plan_po_pacijentu = (
        {
            row["pacijent"].pk: row
            for row in commission_planning_rows(today=danas)
        }
        if commission_demand_v2_enabled()
        else {}
    )
    view_type = request.GET.get("view", "week")
    prikazi_kucnu_terapiju = request.GET.get("home") == "1"
    nevalidni_vikend_termini = (
        list(
            weekend_appointments_queryset(
                Termin.objects.select_related("pacijent", "lijek")
            )
            .exclude(lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA)
            .exclude(
                historija_statusa__razlog__startswith=VIDEO_DEMO_MARKER
            )
            .order_by("datum", "vrijeme")[:50]
        )
        if je_admin(request.user) and not demo_weekend_active
        else []
    )
    if view_type not in ["day", "week", "month"]:
        view_type = "week"

    selected_date = danas
    date_param = request.GET.get("date")
    if date_param:
        try:
            selected_date = datetime.strptime(date_param, "%Y-%m-%d").date()
        except ValueError:
            selected_date = danas

    bs_dani = [
        "Ponedjeljak",
        "Utorak",
        "Srijeda",
        "Četvrtak",
        "Petak",
        "Subota",
        "Nedjelja",
    ]
    bs_dani_kratko = ["Pon", "Uto", "Sri", "Čet", "Pet", "Sub", "Ned"]
    mjeseci = [
        "",
        "Januar",
        "Februar",
        "Mart",
        "April",
        "Maj",
        "Juni",
        "Juli",
        "August",
        "Septembar",
        "Oktobar",
        "Novembar",
        "Decembar",
    ]

    def datum_ba(datum):
        return datum.strftime("%d/%m/%Y")

    def vrijeme_ba(vrijeme):
        return vrijeme.strftime("%H:%M") if vrijeme else ""

    def lijek_css_class(lijek):
        return medicine_group_css(lijek)

    def pripremi_termin(termin):
        termin.vrijeme_fmt = vrijeme_ba(termin.vrijeme)
        termin.datum_fmt = datum_ba(termin.datum)
        termin.dan_naziv = bs_dani[termin.datum.weekday()]
        termin.dan_kratko = bs_dani_kratko[termin.datum.weekday()]
        termin.lijek_css = lijek_css_class(termin.lijek)
        termin.terapija_naziv = termin.pacijent.terapija_za_prikaz
        termin.proizvod_naziv = (
            termin.lijek.prikaz_naziv if termin.lijek_id else ""
        )
        termin.status_label = dict(Termin.STATUS).get(termin.status, termin.status)
        termin.status_css = f"status-{termin.status.lower()}"
        if termin.datum == danas and termin.status == "ZAKAZAN":
            termin.status_css = "status-danas"
        termin.faza_terapije = ""
        termin.faza_kratko = ""
        termin.broj_doze = None
        termin.doza_label = ""
        termin.terapija_sa_dozom = ""
        termin.preostale_doze = None
        termin.pokrivenost_css = "coverage-green"
        termin.pokrivenost_label = "Pokriven terapijom"
        termin.prikazi_preostalo = False
        termin.telefon = termin.pacijent.telefon if termin.pacijent else ""
        termin.sljedeca_terapija_fmt = ""
        termin.pacijent_url = reverse("profil_pacijenta", args=[termin.pacijent.id]) if termin.pacijent_id else "#"
        termin.potvrdi_url = reverse("potvrdi_dolazak", args=[termin.id])

        try:
            status_pacijenta = izracunaj_status_pacijenta(termin.pacijent)
            termin.faza_terapije = status_pacijenta["trenutna_faza"]
            termin.sljedeca_terapija_fmt = (
                datum_ba(status_pacijenta["sljedeca_terapija"])
                if status_pacijenta.get("sljedeca_terapija")
                else ""
            )
            planning = komisijski_plan_po_pacijentu.get(termin.pacijent_id)
            termin.preostale_doze = (
                planning["odobreno_preostalo"]
                if planning else status_pacijenta["preostalo_na_komisiji"]
            )
            termin.prikazi_preostalo = termin.preostale_doze <= 2
            if status_pacijenta["status_css"] == "status-hitno" or termin.preostale_doze <= 0:
                termin.pokrivenost_css = "coverage-red"
                termin.pokrivenost_label = "Potrebna nova komisija / nije pokriven"
            elif termin.preostale_doze <= 2:
                termin.pokrivenost_css = "coverage-amber"
                termin.pokrivenost_label = "Zadnja ili pretposljednja doza"
        except Exception:
            termin.faza_terapije = ""

        try:
            termin.broj_doze = termin.pacijent.broj_dosadasnjih_aplikacija() + 1
            termin.doza_label = f"D{termin.broj_doze}"
        except Exception:
            termin.broj_doze = None
            termin.doza_label = ""

        if termin.faza_terapije:
            termin.faza_kratko = "Održavanje" if "odr" in termin.faza_terapije.lower() else "Indukcija"
        termin.terapija_sa_dozom = " • ".join(
            dio for dio in [termin.faza_kratko or termin.faza_terapije, termin.doza_label] if dio
        )

        return termin

    def termini_za_period(pocetak, kraj):
        queryset = list(
            Termin.objects.select_related("pacijent", "lijek")
            .filter(datum__gte=pocetak, datum__lte=kraj)
            .exclude(lijek__nacin_primjene=Lijek.NACIN_ORALNA_TERAPIJA)
            .order_by("datum", "vrijeme")
        )
        from patients.querysets import with_workflow_data

        patients_by_id = {
            patient.pk: patient
            for patient in with_workflow_data(Pacijent.objects.filter(
                pk__in={item.pacijent_id for item in queryset}
            ))
        }
        for termin in queryset:
            if termin.pacijent_id in patients_by_id:
                termin.pacijent = patients_by_id[termin.pacijent_id]

        return [
            pripremi_termin(termin)
            for termin in queryset
            if (
                (
                    is_allowed_therapy_date(
                        termin.datum,
                        lijek=termin.lijek,
                        protokol=termin.pacijent.aktivni_protokol(),
                    )
                    or is_demo_weekend_calendar_date(termin.datum)
                    or termin.pk in video_demo_termin_ids
                )
                and (
                    termin.pacijent.trenutni_korak_je_kucna_terapija()
                    if prikazi_kucnu_terapiju
                    else termin.pacijent.trenutni_korak_je_ambulanta()
                )
            )
        ]

    def sazetak_po_lijeku(termini):
        sazetak = {}
        for termin in termini:
            naziv = termin.terapija_naziv
            if naziv not in sazetak:
                sazetak[naziv] = {
                    "lijek": naziv,
                    "count": 0,
                    "css": termin.lijek_css,
                }
            sazetak[naziv]["count"] += 1
        return list(sazetak.values())

    if view_type == "day":
        pocetak = selected_date
        kraj = selected_date
        prev_date = selected_date - timedelta(days=1)
        next_date = selected_date + timedelta(days=1)
        period_label = f"{bs_dani[selected_date.weekday()]}, {datum_ba(selected_date)}"
    elif view_type == "month":
        pocetak = selected_date.replace(day=1)
        if selected_date.month == 12:
            next_month = selected_date.replace(year=selected_date.year + 1, month=1, day=1)
        else:
            next_month = selected_date.replace(month=selected_date.month + 1, day=1)
        kraj = next_month - timedelta(days=1)
        prev_date = (pocetak - timedelta(days=1)).replace(day=1)
        next_date = next_month
        period_label = f"{mjeseci[selected_date.month]} {selected_date.year}"
    else:
        pocetak = selected_date - timedelta(days=selected_date.weekday())
        video_demo_weekend_ids = tagged_video_demo_appointment_ids(
            start_date=pocetak + timedelta(days=5),
            end_date=pocetak + timedelta(days=6),
        )
        prikazi_vikend = demo_weekend_active or bool(video_demo_weekend_ids)
        kraj = pocetak + timedelta(days=6 if prikazi_vikend else 4)
        prev_date = pocetak - timedelta(days=7)
        next_date = pocetak + timedelta(days=7)
        period_label = (
            f"{datum_ba(pocetak)} – "
            f"{datum_ba(pocetak + timedelta(days=6))}"
        )

    video_demo_termin_ids = tagged_video_demo_appointment_ids(
        start_date=pocetak,
        end_date=kraj,
    )
    video_demo_dates = set(
        Termin.objects.filter(pk__in=video_demo_termin_ids).values_list(
            "datum", flat=True
        )
    )
    # Kalendar i KPI kartice namjerno dijele isti, već filtrirani skup termina.
    # ``pocetak`` i ``kraj`` su jedini source of truth za odabrani dan,
    # sedmicu ili mjesec, uključujući navigaciju u prošle/buduće periode.
    termini = termini_za_period(pocetak, kraj)
    summary_cards = {
        "terapije": len(termini),
        "cekaju_potvrdu": sum(
            1 for termin in termini
            if termin.status == Termin.STATUS_PLANIRANA
        ),
        "zavrsene": sum(
            1 for termin in termini
            if termin.status == Termin.STATUS_POTVRDJENA
        ),
        "odgodjene_ili_nedolasci": sum(
            1 for termin in termini
            if termin.status in {
                Termin.STATUS_ODGODJENA,
                Termin.STATUS_NIJE_DOSAO,
            }
        ),
    }
    termini_po_datumu = {}
    for termin in termini:
        termini_po_datumu.setdefault(termin.datum, []).append(termin)

    week_days = []
    if view_type == "week":
        for index in range(7 if (demo_weekend_active or video_demo_dates) else 5):
            datum = pocetak + timedelta(days=index)
            week_days.append({
                "date": datum,
                "date_iso": datum.isoformat(),
                "date_fmt": datum_ba(datum),
                "naziv": bs_dani[index],
                "kratko": bs_dani_kratko[index],
                "is_today": datum == danas,
                "termini": termini_po_datumu.get(datum, []),
            })

    month_weeks = []
    if view_type == "month":
        month_calendar = calendar.Calendar(firstweekday=0)
        for week in month_calendar.monthdatescalendar(selected_date.year, selected_date.month):
            week_cells = []
            for datum in week:
                cell_termini = termini_po_datumu.get(datum, [])
                lijek_classes = []
                for termin in cell_termini:
                    if termin.lijek_css not in lijek_classes:
                        lijek_classes.append(termin.lijek_css)
                week_cells.append({
                    "date": datum,
                    "date_iso": datum.isoformat(),
                    "date_fmt": datum_ba(datum),
                    "day": datum.day,
                    "kratko": bs_dani_kratko[datum.weekday()],
                    "in_month": datum.month == selected_date.month,
                    "is_today": datum == danas,
                    "is_closed": (
                        datum.weekday() >= 5
                        and not demo_weekend_active
                        and datum not in video_demo_dates
                    ),
                    "termini": cell_termini,
                    "lijek_classes": lijek_classes,
                })
            month_weeks.append(week_cells)

    return render(request, "dashboard/kalendar_terapija.html", {
        "termini": termini,
        "view_type": view_type,
        "selected_date": selected_date,
        "selected_date_iso": selected_date.isoformat(),
        "selected_date_fmt": datum_ba(selected_date),
        "today_iso": danas.isoformat(),
        "period_label": period_label,
        "period_start": pocetak,
        "period_end": kraj,
        "prev_date": prev_date.isoformat(),
        "next_date": next_date.isoformat(),
        "week_days": week_days,
        "month_weeks": month_weeks,
        "summary_counts": sazetak_po_lijeku(termini),
        "summary_cards": summary_cards,
        "total_termina": len(termini),
        "prikazi_kucnu_terapiju": prikazi_kucnu_terapiju,
        "danas": danas,
        "nevalidni_vikend_termini": nevalidni_vikend_termini,
        "broj_nevalidnih_vikend_termina": len(nevalidni_vikend_termini),
        "demo_weekend_active": demo_weekend_active,
    })

@login_required
def alarm_centar(request):
    alarm_centar = napravi_alarm_centar()

    context = {
        "alarm_centar": alarm_centar,
        "kriticni_alarmi": alarm_centar["kriticni"],
        "upozorenja_alarmi": alarm_centar["upozorenja"],
        "informacije_alarmi": alarm_centar["informacije"],
        "broj_kriticnih": len(alarm_centar["kriticni"]),
        "broj_upozorenja": len(alarm_centar["upozorenja"]),
    }

    return render(request, "dashboard/komisijski_centar.html", context)

@login_required
def print_plan_nabavke(request):
    path = napravi_pdf_putanju("plan_nabavke.pdf")

    danas = timezone.now().date()

    alarm_lijekovi = []

    for red in zalihe_sa_potrebama():
        lijek = red["lijek"]
        nedostaje = Decimal(str(red["za_novu_komisiju"] or 0))

        if nedostaje > 0:
            alarm_lijekovi.append({
                "lijek": lijek,
                "nedostaje": procurement_breakdown(
                    nedostaje,
                    lijek,
                )["display_text"],
            })

    c = canvas.Canvas(path, pagesize=A4)

    c.setFont("DejaVuSans-Bold", 18)
    c.drawString(80, 780, "TheraFlow - Plan nabavke terapije")

    c.setFont("DejaVuSans", 12)
    c.drawString(80, 750, f"Datum: {format_date_bs(danas)}")

    y = 700

    c.setFont("DejaVuSans-Bold", 12)
    c.drawString(80, y, "Lijek")
    c.drawString(300, y, "Za komisiju")
    y -= 25

    c.setFont("DejaVuSans", 12)

    if alarm_lijekovi:
        for alarm in alarm_lijekovi:
            c.drawString(80, y, str(alarm["lijek"]))
            c.drawString(300, y, str(alarm["nedostaje"]))
            y -= 25
    else:
        c.drawString(80, y, "Nema lijekova za trebovanje.")

    c.save()

    return FileResponse(open(path, "rb"), as_attachment=False)

@login_required
def novi_pacijent(request):
    if request.method == "POST":
        form = PacijentForm(request.POST)

        if form.is_valid():
            with transaction.atomic():
                pacijent = form.save(commit=False)
                pacijent.aktivan = True
                pacijent.save()
                if pacijent.terapijski_program.protokol_kljuc:
                    from patients.phased_protocols import configure_program_protocol

                    configure_program_protocol(
                        patient=pacijent,
                        program=pacijent.terapijski_program,
                        maintenance_interval=pacijent.interval_sedmica,
                        user=request.user,
                        prescribed_iv_dose_mg=form.cleaned_data.get(
                            "pocetna_iv_doza_mg"
                        ),
                    )

            return redirect("profil_pacijenta", pacijent_id=pacijent.id)

    else:
        form = PacijentForm()

    return render(request, "dashboard/novi_pacijent.html", {
        "form": form
    })


@login_required
def provjeri_jmbg_migracija(request):
    """Lokalna provjera JMBG-a i mogućeg demo duplikata."""
    jmbg = (request.GET.get("jmbg") or "").strip()
    ime = (request.GET.get("ime") or "").strip()
    prezime = (request.GET.get("prezime") or "").strip()
    datum_rodenja_raw = (request.GET.get("datum_rodenja") or "").strip()
    exclude_id = request.GET.get("exclude_id")
    candidates = Pacijent.objects.all()
    if exclude_id and str(exclude_id).isdigit():
        candidates = candidates.exclude(pk=int(exclude_id))

    pacijent = candidates.filter(jmbg=jmbg).first() if jmbg else None
    match_type = "JMBG" if pacijent else ""
    if (
        pacijent is None
        and not jmbg
        and ime
        and prezime
        and datum_rodenja_raw
    ):
        try:
            datum_rodenja = datetime.strptime(
                datum_rodenja_raw, "%Y-%m-%d"
            ).date()
        except ValueError:
            datum_rodenja = None
        if datum_rodenja:
            pacijent = candidates.filter(
                ime__iexact=ime,
                prezime__iexact=prezime,
                datum_rodenja=datum_rodenja,
            ).order_by("-aktivan", "pk").first()
            if pacijent:
                match_type = "DEMOGRAPHIC_WARNING"

    return JsonResponse({
        "exists": bool(pacijent),
        "blocking": match_type == "JMBG",
        "match_type": match_type,
        "patient_name": str(pacijent) if pacijent else "",
        "profile_url": (
            reverse("profil_pacijenta", args=[pacijent.pk])
            if pacijent
            else ""
        ),
    })


def _add_migration_apply_error(form, exc):
    """Prikaži domensku grešku uz konkretno polje kad god je moguće."""

    if isinstance(exc, ValidationError):
        if hasattr(exc, "message_dict"):
            for field, errors in exc.message_dict.items():
                target = field if field in form.fields else None
                for error in errors:
                    form.add_error(target, error)
        else:
            for error in exc.messages:
                form.add_error(None, error)
        return
    if isinstance(exc, ValueError):
        form.add_error(None, str(exc))
        return
    form.add_error(
        None,
        "Spremanje nije uspjelo zbog tehničke greške. Podaci nisu promijenjeni.",
    )


@user_passes_test(je_koordinator_ili_admin)
def migracija_pacijenta(request):
    postavke = get_postavke_sistema()
    if postavke.migracija_zakljucana:
        messages.warning(request, "Migracija postojecih pacijenata je zakljucana.")
        return redirect("lista_pacijenata")

    migration_snapshot = None
    snapshot_token = ""
    if request.method == "POST":
        action = request.POST.get("migration_action", "preview")
        form = MigracijaPacijentaForm(request.POST)
        if form.is_valid():
            if action in {"save_next", "save_open"}:
                try:
                    pacijent = apply_migration_snapshot(form, request.user)
                except Exception as exc:
                    logger.exception(
                        "Migracija pacijenta nije završena; transakcija je vraćena."
                    )
                    _add_migration_apply_error(form, exc)
                else:
                    messages.success(
                        request,
                        f"Pacijent {pacijent} je sačuvan bez terapijske potrošnje.",
                    )
                    if action == "save_next":
                        return redirect("migracija_pacijenta")
                    return redirect("profil_pacijenta", pacijent_id=pacijent.id)
            elif action == "confirm":
                token = request.POST.get("snapshot_token", "")
                if snapshot_confirmation_is_valid(form.cleaned_data, token):
                    try:
                        pacijent = apply_migration_snapshot(form, request.user)
                    except Exception as exc:
                        logger.exception(
                            "Migracija pacijenta nije završena; transakcija je vraćena."
                        )
                        _add_migration_apply_error(form, exc)
                        migration_snapshot = snapshot_for_display(form.cleaned_data)
                        snapshot_token = create_snapshot_confirmation_token(
                            form.cleaned_data
                        )
                    else:
                        messages.success(
                            request,
                            "Početno stanje i historijski podaci su sačuvani. "
                            "Nisu kreirani termin ni ambulantna terapija.",
                        )
                        return redirect("profil_pacijenta", pacijent_id=pacijent.id)
                else:
                    form.add_error(
                        None,
                        "Podaci su promijenjeni ili je potvrda istekla. "
                        "Pregledajte snapshot ponovo.",
                    )
            else:
                migration_snapshot = snapshot_for_display(form.cleaned_data)
                snapshot_token = create_snapshot_confirmation_token(form.cleaned_data)
    else:
        form = MigracijaPacijentaForm()

    migration_count = MigracijskiSnapshotPacijenta.objects.count()
    migration_inventory_rows = migration_inventory_summary()
    for inventory_row in migration_inventory_rows:
        inventory_row["reconciliation_preview"] = (
            migration_inventory_reconciliation_preview(inventory_row["lijek"])
        )

    # Isključivo prezentacijski sloj za kompaktan pregled početnog stanja.
    # Sve količine, upozorenja i plan usklađivanja ostaju rezultat centralnog
    # migration inventory servisa iznad.
    migration_inventory_groups = {
        "venous": [],
        "subcutaneous": [],
        "oral": [],
        "empty": [],
    }
    for inventory_row in migration_inventory_rows:
        medicine = inventory_row["lijek"]
        all_zero = all(
            Decimal(str(inventory_row.get(field) or 0)) == 0
            for field in (
                "fizicki",
                "rezervisano",
                "kod_pacijenata",
                "preostalo_odobreno",
                "ceka_fizicko_pokrice",
            )
        ) and not inventory_row.get("oralni_detalji")

        if all_zero:
            group_key = "empty"
        elif inventory_row.get("oralni_workflow"):
            group_key = "oral"
        elif (
            medicine.put_primjene == Lijek.PUT_SC
            or medicine.kucna_terapija
        ):
            group_key = "subcutaneous"
        else:
            group_key = "venous"

        invalid_sources = [
            item for item in inventory_row.get("reservation_details", [])
            if not item.get("porijeklo_potvrdjeno")
        ]
        duplicate_sources = [
            item for item in invalid_sources
            if item.get("duplikat_fizickog_osnova")
        ]
        unverified_sources = [
            item for item in invalid_sources
            if not item.get("duplikat_fizickog_osnova")
        ]
        awaiting_quantity = Decimal(str(
            inventory_row.get("ceka_fizicko_pokrice") or 0
        ))
        physical = Decimal(str(inventory_row.get("fizicki") or 0))
        allocated = Decimal(str(inventory_row.get("rezervisano") or 0))
        migration_difference = Decimal(str(
            inventory_row.get("odstupanje_od_migracijskog_unosa") or 0
        ))
        has_declared_migration_quantity = Decimal(str(
            inventory_row.get("migracijom_uneseno_fizicki") or 0
        )) > 0
        issue_count = (
            len(invalid_sources)
            + (1 if awaiting_quantity > 0 else 0)
            + (1 if allocated > physical else 0)
            + (
                1
                if has_declared_migration_quantity
                and migration_difference != 0
                else 0
            )
        )
        issue_count = max(issue_count, len(inventory_row.get("warnings", [])))
        is_critical = allocated > physical or (
            has_declared_migration_quantity and migration_difference != 0
        )
        has_problem = bool(inventory_row.get("warnings")) or is_critical

        if issue_count == 1:
            issue_word = "stavka"
        elif issue_count in {2, 3, 4}:
            issue_word = "stavke"
        else:
            issue_word = "stavki"

        if is_critical:
            status_code = "critical"
            status_label = f"Nije usklađeno · {issue_count} {issue_word}"
        elif has_problem:
            status_code = "warning"
            status_label = f"Potrebna provjera · {issue_count} {issue_word}"
        else:
            status_code = "ok"
            status_label = "Uredno"

        display_problems = []
        if unverified_sources:
            display_problems.append({
                "code": "source",
                "count": len(unverified_sources),
                "text": (
                    f"{len(unverified_sources)} izvora nema potvrđeno porijeklo"
                ),
            })
        if duplicate_sources:
            display_problems.append({
                "code": "duplicate",
                "count": len(duplicate_sources),
                "text": f"{len(duplicate_sources)} aktivnih zapisa se preklapa",
            })
        if awaiting_quantity > 0:
            display_problems.append({
                "code": "awaiting",
                "quantity": awaiting_quantity,
                "text": "Nije fizički osigurano",
            })
        if allocated > physical:
            display_problems.append({
                "code": "overallocated",
                "quantity": allocated - physical,
                "text": "Dodijeljeno je više od fizičkog stanja",
            })
        if has_declared_migration_quantity and migration_difference != 0:
            display_problems.append({
                "code": "difference",
                "quantity": abs(migration_difference),
                "text": "Razlika u odnosu na migracijski unos",
            })

        displayed_issue_count = sum(
            int(problem.get("count") or 1)
            for problem in display_problems
        )
        if has_problem and displayed_issue_count == 0:
            display_problems.append({
                "code": "review",
                "count": 1,
                "text": "Podaci zahtijevaju dodatnu provjeru",
            })
            displayed_issue_count = 1
        issue_count = displayed_issue_count
        if issue_count == 1:
            issue_word = "stavka"
        elif issue_count in {2, 3, 4}:
            issue_word = "stavke"
        else:
            issue_word = "stavki"
        if is_critical:
            status_label = f"Nije usklađeno · {issue_count} {issue_word}"
        elif has_problem:
            status_label = f"Potrebna provjera · {issue_count} {issue_word}"
        else:
            status_label = "Uredno"

        affected_quantity = sum(
            (Decimal(str(item.get("kolicina") or 0)) for item in invalid_sources),
            Decimal("0"),
        ) + awaiting_quantity + (
            abs(migration_difference)
            if has_declared_migration_quantity
            else Decimal("0")
        )
        if duplicate_sources:
            recommendation = "Pregledati i spojiti duple aktivne zapise."
        elif unverified_sources:
            recommendation = "Povezati fizičke količine sa potvrđenim migracijskim unosom."
        elif awaiting_quantity > 0:
            recommendation = "Provjeriti količinu koja još nije fizički osigurana."
        elif is_critical:
            recommendation = "Pregledati raspodjelu i potvrditi ispravno fizičko stanje."
        else:
            recommendation = "Nije potrebna trenutna akcija."

        inventory_row.update({
            "presentation_group": group_key,
            "presentation_all_zero": all_zero,
            "presentation_status_code": status_code,
            "presentation_status_label": status_label,
            "presentation_issue_count": issue_count,
            "presentation_has_problem": has_problem,
            "presentation_is_critical": is_critical,
            "presentation_problems": display_problems,
            "presentation_affected_quantity": affected_quantity,
            "presentation_recommendation": recommendation,
            "presentation_sort_key": (
                0 if has_problem else 1,
                (medicine.naziv or "").casefold(),
            ),
            "presentation_is_first_problem": False,
        })
        migration_inventory_groups[group_key].append(inventory_row)

    for group_rows in migration_inventory_groups.values():
        group_rows.sort(key=lambda row: row["presentation_sort_key"])

    first_problem_assigned = False
    for group_key in ("venous", "subcutaneous", "oral", "empty"):
        for inventory_row in migration_inventory_groups[group_key]:
            if inventory_row["presentation_has_problem"] and not first_problem_assigned:
                inventory_row["presentation_is_first_problem"] = True
                first_problem_assigned = True

    migration_inventory_problem_count = sum(
        row["presentation_issue_count"]
        for row in migration_inventory_rows
        if row["presentation_has_problem"]
    )
    migration_inventory_review_count = sum(
        1 for row in migration_inventory_rows
        if row["presentation_has_problem"]
    )
    migration_inventory_ok_count = sum(
        1 for row in migration_inventory_rows
        if not row["presentation_has_problem"]
        and not row["presentation_all_zero"]
    )
    migration_warning_count = sum(
        len(row["warnings"]) for row in migration_inventory_rows
    )
    migration_inventory_confirmed = bool(migration_inventory_rows) and all(
        row["uskladjeno"] for row in migration_inventory_rows
    )
    def migration_product_config(lijek):
        return {
            "home": lijek.kucna_terapija,
            "oral": lijek.oralna_terapija,
            "package_size": lijek.effective_package_size,
            "unit_singular": lijek.jedinice_terapije[0],
            "unit_plural": lijek.jedinice_terapije[1],
            "stock_unit_singular": lijek.jedinice_zalihe[0],
            "stock_unit_plural": lijek.jedinice_zalihe[1],
            "decimal_allowed": lijek.dozvoljava_decimalnu_kolicinu,
            "requires_manual_quantity": (
                lijek.therapeutic_group_key == "infliximab"
                or (
                    lijek.therapeutic_group_key == "ustekinumab"
                    and lijek.put_primjene == Lijek.PUT_IV
                )
            ),
        }

    lijekovi_config = {}
    for program in active_therapy_programs():
        default_product = program.default_lijek
        if default_product is None:
            continue
        config = migration_product_config(default_product)
        config["products"] = {
            str(product.pk): migration_product_config(product)
            for product in program.proizvodi.filter(aktivan=True).order_by("pk")
        }
        lijekovi_config[str(program.pk)] = config
    return render(request, "dashboard/migracija_pacijenta.html", {
        "form": form,
        "postavke": postavke,
        "migration_snapshot": migration_snapshot,
        "snapshot_token": snapshot_token,
        "migration_count": migration_count,
        "migration_warning_count": migration_warning_count,
        "migration_inventory_rows": migration_inventory_rows,
        "migration_inventory_groups": migration_inventory_groups,
        "migration_inventory_problem_count": migration_inventory_problem_count,
        "migration_inventory_review_count": migration_inventory_review_count,
        "migration_inventory_ok_count": migration_inventory_ok_count,
        "migration_inventory_confirmed": migration_inventory_confirmed,
        "lijekovi_config": lijekovi_config,
    })


@user_passes_test(je_koordinator_ili_admin)
def uskladi_migracijsku_zalihu(request):
    if request.method != "POST":
        return redirect("migracija_pacijenta")

    postavke = get_postavke_sistema()
    if postavke.migracija_zakljucana:
        messages.warning(request, "Migracija postojećih pacijenata je zaključana.")
        return redirect("lista_pacijenata")

    lijek = get_object_or_404(Lijek, pk=request.POST.get("lijek_id"))
    action = request.POST.get("inventory_action")
    try:
        if action == "set_global_stock":
            raw_quantity = (request.POST.get("kolicina") or "").strip().replace(",", ".")
            quantity = Decimal(raw_quantity)
            if quantity < 0:
                raise ValueError("Količina ne može biti negativna.")
            uskladi_pocetno_stanje_zalihe(
                lijek=lijek,
                kolicina=quantity,
                user=request.user,
            )
            messages.success(
                request,
                f"Globalno početno stanje za {lijek.naziv} je potvrđeno: "
                f"{quantity:g}.",
            )
        elif action == "confirm_legacy_reservations":
            count = potvrdi_historijske_migracijske_rezervacije(
                lijek=lijek,
                user=request.user,
            )
            messages.success(
                request,
                f"Potvrđene su {count} pacijentske rezervacije za {lijek.naziv}.",
            )
        elif action == "reconcile_provenance":
            if request.POST.get("potvrdi_uskladjivanje") != "DA":
                raise ValueError(
                    "Prvo pregledajte plan i potvrdite usklađivanje porijekla."
                )
            plan = reconcile_migration_inventory_provenance(
                lijek=lijek,
                user=request.user,
            )
            messages.success(
                request,
                f"Porijeklo zalihe za {lijek.naziv} je usklađeno. "
                f"Fizički saldo je ostao {plan['current_physical']:g}; "
                f"zadržano je {plan['kept_quantity']:g} validnih rezervacija.",
            )
        else:
            raise ValueError("Nepoznata akcija usklađivanja.")
    except (ArithmeticError, ValueError) as exc:
        messages.error(request, f"Usklađivanje nije izvršeno: {exc}")

    return redirect("migracija_pacijenta")


@user_passes_test(je_koordinator_ili_admin)
def zavrsi_migraciju(request):
    if request.method != "POST":
        return redirect("migracija_pacijenta")

    if request.POST.get("potvrdi_zavrsetak") != "DA":
        messages.warning(
            request,
            "Potvrdite završetak unosa svih pacijenata prije zaključavanja.",
        )
        return redirect("migracija_pacijenta")

    postavke = get_postavke_sistema()
    postavke.migracija_zakljucana = True
    postavke.save(update_fields=["migracija_zakljucana"])
    upisi_log(request.user, "Zakljucana migracija pacijenata", objekat=postavke)
    messages.success(request, "Migracijski mod je zakljucan. Nastavite normalan rad kroz Potvrdi dolazak.")
    return redirect("postavke_sistema")


@login_required
def novi_termin(request, pacijent_id=None):
    pacijent = None
    if pacijent_id is not None:
        pacijent = get_object_or_404(Pacijent, id=pacijent_id)

    demo_weekend_allowed = user_can_create_demo_weekend_appointment(
        request.user
    )

    if request.method == "POST":
        form = TerminForm(
            request.POST,
            user=request.user,
            allow_demo_weekend=True,
        )

        if form.is_valid():
            termin = form.save(commit=False)
            if termin.pacijent.na_aktivnoj_pauzi():
                form.add_error("pacijent", "Pacijent je na privremenoj pauzi i ne može dobiti novi termin.")
                return render(request, "dashboard/novi_termin.html", {"form": form, "pacijent": pacijent})
            termin.lijek = termin.pacijent.lijek
            termin.vrijeme = time(12, 0)
            try:
                termin, created = schedule_therapy_appointment(
                    pacijent=termin.pacijent,
                    lijek=termin.lijek,
                    datum=termin.datum,
                    vrijeme=termin.vrijeme,
                    user=request.user,
                    reason="Novi termin ručno zakazan.",
                    allow_demo_weekend=True,
                )
            except ValueError as exc:
                form.add_error("datum", str(exc))
                return render(request, "dashboard/novi_termin.html", {
                    "form": form,
                    "pacijent": pacijent,
                    "demo_weekend_allowed": demo_weekend_allowed,
                })
            if not created:
                messages.info(
                    request,
                    "Aktivan termin sa istim datumom već postoji.",
                )

            if pacijent:
                return redirect("profil_pacijenta", pacijent_id=pacijent.id)
            return redirect("kalendar_terapija")
    else:
        form = TerminForm(
            initial={"pacijent": pacijent} if pacijent else None,
            user=request.user,
            allow_demo_weekend=True,
        )

    if pacijent:
        form.fields["pacijent"].queryset = Pacijent.objects.filter(id=pacijent.id)
        form.fields["pacijent"].initial = pacijent

    return render(request, "dashboard/novi_termin.html", {
        "form": form,
        "pacijent": pacijent,
        "demo_weekend_allowed": demo_weekend_allowed,
    })

@login_required
def generisi_komisiju(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)

    danas = timezone.now().date()
    path = napravi_pdf_putanju(f"generisana_komisija_{pacijent.id}.pdf")

    potreba = calculate_patient_commission_need(pacijent, today=danas)
    potrebno_3_mjeseca = potreba["ukupno_potrebno"]
    preostalo = potreba["trenutno_dostupno"]
    traziti = potreba["za_novu_komisiju"]
    traziti_prikaz = procurement_breakdown(
        traziti,
        pacijent.lijek,
    )["display_text"]

    c = canvas.Canvas(path, pagesize=A4)

    c.setFont("DejaVuSans-Bold", 18)
    c.drawString(80, 780, "TheraFlow - Prijedlog komisije")

    c.setFont("DejaVuSans", 12)
    c.drawString(80, 735, f"Datum: {format_date_bs(danas)}")
    c.drawString(80, 710, f"Pacijent: {pacijent.ime} {pacijent.prezime}")
    c.drawString(80, 685, f"JMBG: {pacijent.jmbg}")
    c.drawString(80, 660, f"Dijagnoza: {pacijent.dijagnoza}")
    c.drawString(80, 635, f"Lijek: {pacijent.lijek}")
    c.drawString(80, 610, f"Interval terapije: svakih {pacijent.efektivni_interval_sedmica()} sedmica")

    c.setFont("DejaVuSans-Bold", 14)
    c.drawString(80, 560, "Obracun terapije")

    c.setFont("DejaVuSans", 12)
    c.drawString(80, 530, f"Potrebno do očekivane isporuke: {potrebno_3_mjeseca} doza")
    c.drawString(80, 505, f"Trenutno preostalo: {preostalo} doza")

    c.setFont("DejaVuSans-Bold", 14)
    c.drawString(80, 465, f"Za novu komisiju traziti: {traziti_prikaz}")

    c.line(80, 390, 320, 390)
    c.setFont("DejaVuSans", 11)
    c.drawString(80, 370, "Potpis odgovorne osobe")

    c.save()

    return FileResponse(open(path, "rb"), as_attachment=False)

@login_required
def kreiraj_komisiju(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    potreba = calculate_patient_commission_need(pacijent)
    broj_doza = potreba["za_novu_komisiju"]
    if broj_doza <= 0:
        messages.info(request, "Pacijent trenutno ima dovoljno pokrića do očekivane isporuke.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)
    ciklus = KomisijskiCiklus.objects.filter(status="SIMULACIJA").order_by("-id").first()
    if ciklus is None:
        ciklus = KomisijskiCiklus.objects.create(naziv=generisi_broj_komisijskog_ciklusa())
    Trebovanje.objects.update_or_create(
        pacijent=pacijent,
        lijek=pacijent.lijek,
        komisijski_ciklus=ciklus,
        status="U_PRIPREMI",
        defaults={"broj_doza": broj_doza},
    )

    messages.success(
    request,
    "Pacijent je dodat u pripremu narednog komisijskog ciklusa."
)

    return redirect("profil_pacijenta", pacijent_id=pacijent.id)

@login_required
@user_passes_test(je_koordinator_ili_admin)
def deaktiviraj_pacijenta(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    if request.method != "POST":
        raise PermissionDenied("Deaktivacija pacijenta zahtijeva potvrdu i razlog.")
    legacy_reason = (request.POST.get("razlog") or "").strip()
    reason_code = (request.POST.get("razlog_oslobadjanja") or "").strip()
    reason_note = (request.POST.get("napomena_oslobadjanja") or "").strip()
    allowed_reasons = {
        ZalihaTransakcija.RAZLOG_PREKID_TERAPIJE,
        ZalihaTransakcija.RAZLOG_PROMJENA_LIJEKA,
        ZalihaTransakcija.RAZLOG_SMRTNI_SLUCAJ,
        ZalihaTransakcija.RAZLOG_DRUGO,
    }
    if reason_code and reason_code not in allowed_reasons:
        messages.error(request, "Odaberite ispravan razlog deaktivacije.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)
    if reason_code == ZalihaTransakcija.RAZLOG_DRUGO and not reason_note:
        messages.error(request, "Za razlog ‘Drugo’ unesite napomenu.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)
    if not reason_code and not legacy_reason:
        messages.error(request, "Razlog deaktivacije je obavezan.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)
    reason_label = dict(ZalihaTransakcija.RAZLOZI_SLOBODNE_ZALIHE).get(
        reason_code,
        legacy_reason,
    )
    deactivate_patient_safely(
        patient_id=pacijent.pk,
        user=request.user,
        reason=reason_note or legacy_reason or reason_label,
        reason_code=reason_code,
    )

    return redirect("lista_pacijenata")

@login_required
@user_passes_test(je_koordinator_ili_admin)
def aktiviraj_pacijenta(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    pacijent.aktivan = True
    pacijent.save(update_fields=["aktivan"])
    upisi_log(
        request.user,
        "Ponovna aktivacija pacijenta",
        pacijent=pacijent,
        objekat=pacijent,
        opis="Pacijent je ponovo aktiviran u operativnom workflowu.",
    )

    return redirect("profil_pacijenta", pacijent_id=pacijent.id)


@login_required
def kreiraj_trebovanje(request):
    danas = timezone.now().date()
    vrijeme = timezone.now().strftime("%H-%M-%S")

    path = napravi_pdf_putanju(
        f"trebovanje_po_pacijentu_{danas}_{vrijeme}.pdf"
    )

    c = canvas.Canvas(path, pagesize=A4)

    c.setFont("DejaVuSans-Bold", 18)
    c.drawString(80, 800, "PLAN TREBOVANJA PO PACIJENTU")

    c.setFont("DejaVuSans", 10)
    c.drawString(80, 780, f"Datum: {format_date_bs(danas)}")

    y = 740

    pacijenti = Pacijent.objects.filter(
        aktivan=True
    ).order_by("prezime", "ime")

    potrebe_pacijenata = {
        item["pacijent"].id: item for item in patients_for_next_commission()
    }
    for pacijent in pacijenti:
        lijek = pacijent.lijek
        potreba = potrebe_pacijenata.get(pacijent.id)
        if not lijek or not potreba:
            continue
        preostalo = potreba["trenutno_dostupno"]
        traziti = potreba["za_novu_komisiju"]
        traziti_prikaz = procurement_breakdown(
            traziti,
            lijek,
        )["display_text"]
        komisija = pacijent.aktivna_komisija()

        c.setFont("DejaVuSans-Bold", 12)
        c.drawString(
            80,
            y,
            f"{pacijent.ime} {pacijent.prezime}"
        )

        y -= 20

        c.setFont("DejaVuSans", 11)
        c.drawString(100, y, f"Lijek: {lijek.naziv}")
        y -= 18

        c.drawString(100, y, f"Preostalo doza: {preostalo}")
        y -= 18

        c.drawString(100, y, f"Trebovati: {traziti_prikaz}")
        y -= 18

        if komisija:
            c.drawString(
                100,
                y,
                f"Procijenjena pokrivenost do: {komisija.terapija_pokrivena_do()}"
            )
        else:
            c.drawString(100, y, "Nema aktivne komisije")

        y -= 35

        if y < 100:
            c.showPage()
            y = 760

    c.save()

    return FileResponse(
        open(path, "rb"),
        as_attachment=False
    )

@login_required
@user_passes_test(je_sestra_ili_admin)
def izdaj_kucnu_terapiju(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    lijek = pacijent.lijek
    availability = home_therapy_issue_availability(pacijent)
    if not availability.visible:
        messages.warning(request, "Ovaj lijek ne podržava kućnu terapiju.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)
    if not availability.enabled:
        messages.warning(request, availability.reason)
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)

    commission_medicine_ids = availability.commission_medicine_ids
    dostupno_u_frizideru = rezervisano_u_frizideru_za_pacijenta(pacijent, lijek)
    ukupno_u_frizideru = availability.fridge_quantity
    home_projection = calculate_home_therapy_projection(pacijent) if lijek else None
    komisijski_odobreno = sum(
        (
            Decimal(str(komisija.broj_odobrenih_doza or 0))
            for komisija in pacijent.komisija_set.filter(
                lijek_id__in=commission_medicine_ids,
                status__in=Komisija.VAZECI_STATUSI,
                preostale_doze__gt=0,
            )
        ),
        Decimal("0"),
    ) if lijek else Decimal("0")
    ukupno_izdato = Decimal(str(
        KucnoIzdavanje.objects.filter(
            pacijent=pacijent,
            lijek_id__in=equivalent_medicine_ids(lijek) if lijek else [],
        ).exclude(
            terapija__workflow_status=Terapija.STATUS_PONISTENA,
        ).aggregate(total=models.Sum("kolicina"))["total"] or 0
    ))
    preostalo_kod_pacijenta = inventory_position_for_patient(pacijent)["at_patient"]

    default_doza = int(availability.package_size)

    if request.method == "POST":
        posted_key = request.POST.get("idempotency_key")
        if posted_key:
            postojece = KucnoIzdavanje.objects.filter(idempotency_key=posted_key).first()
            if postojece:
                messages.info(request, "Ovo kućno izdavanje je već evidentirano.")
                return redirect("print_razduzenje_izdavanja", izdavanje_id=postojece.id)

        form = KucnoIzdavanjeForm(
            request.POST,
            pacijent=pacijent,
            lijek=lijek,
            max_quantity=ukupno_u_frizideru,
            commission_medicine_ids=commission_medicine_ids,
        )
        if form.is_valid():
            key = form.cleaned_data["idempotency_key"]
            izdate_doze = form.cleaned_data["kolicina"]
            izabrana_komisija = form.cleaned_data["komisija"]
            try:
                izdavanje, created = issue_home_therapy(
                    patient=pacijent,
                    commission=izabrana_komisija,
                    quantity=izdate_doze,
                    issued_on=form.cleaned_data["datum"],
                    idempotency_key=key,
                    batch=form.cleaned_data.get("serija") or "",
                    expires_on=form.cleaned_data.get("rok_trajanja"),
                    note=form.cleaned_data.get("napomena") or "",
                    user=request.user,
                    snapshot_factory=razduzenje_izdavanje_snapshot,
                )
            except ValueError as exc:
                messages.error(request, str(exc))
                return redirect("izdaj_kucnu_terapiju", pacijent_id=pacijent.id)
            if not created:
                messages.info(request, "Ovo kućno izdavanje je već evidentirano.")
            return redirect("terapija_zavrsena", terapija_id=izdavanje.terapija_id)

    else:
        form = KucnoIzdavanjeForm(
            initial={"kolicina": default_doza},
            pacijent=pacijent,
            lijek=lijek,
            max_quantity=ukupno_u_frizideru,
            commission_medicine_ids=commission_medicine_ids,
        )

    izdavanja_za_prikaz = list(pacijent.kucna_izdavanja.select_related(
        "lijek", "komisija", "korisnik_koji_je_izdao"
    ).order_by("-datum", "-id")[:10])
    for item in izdavanja_za_prikaz:
        item.kolicina_prikaz = format_stock_quantity(item.lijek, item.kolicina)
        item.komisija_prikaz = (
            f"{item.komisija.datum_odobrenja:%d/%m/%Y} · "
            f"{item.komisija.broj_saglasnosti + ' · ' if item.komisija.broj_saglasnosti else ''}"
            f"{item.komisija.get_status_display()}"
            if item.komisija_id else "Nije povezana"
        )

    return render(request, "dashboard/izdaj_kucnu_terapiju.html", {
        "pacijent": pacijent,
        "lijek": lijek,
        "form": form,
        "dostupno_u_frizideru": dostupno_u_frizideru,
        "ukupno_u_frizideru": ukupno_u_frizideru,
        "komisijski_odobreno": komisijski_odobreno,
        "ukupno_izdato": ukupno_izdato,
        "preostalo_kod_pacijenta": preostalo_kod_pacijenta,
        "home_projection": home_projection,
        "aktivira_ustekinumab_kucni_rezim": (
            availability.activates_ustekinumab_home_mode
        ),
        "izdavanja": izdavanja_za_prikaz,
    })


@login_required
def oralna_terapija(request, pacijent_id):
    pacijent = get_object_or_404(
        Pacijent.objects.select_related("lijek"),
        id=pacijent_id,
    )
    if not pacijent.lijek_id or not pacijent.lijek.oralna_terapija:
        messages.warning(
            request,
            "Trenutni lijek pacijenta nije podešen kao oralna terapija.",
        )
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)

    status = oral_therapy_status(pacijent)
    regimen = status["regimen"]
    suggested_regimen = status["suggested_standard_regimen"]
    action = request.POST.get("action") if request.method == "POST" else ""
    regimen_initial = {
        "standardni_rezim": (
            regimen.standardni_rezim
            if regimen and regimen.standardni_rezim_id
            else suggested_regimen
        ),
        "tableta_po_uzimanju": (
            regimen.tableta_po_uzimanju
            if regimen
            else suggested_regimen.tableta_po_uzimanju
            if suggested_regimen
            else None
        ),
        "uzimanja_dnevno": (
            regimen.uzimanja_dnevno
            if regimen
            else suggested_regimen.uzimanja_dnevno
            if suggested_regimen
            else None
        ),
        "datum_od": regimen.datum_od if regimen else timezone.localdate(),
        "faza": (
            regimen.faza
            if regimen
            else suggested_regimen.faza
            if suggested_regimen
            else OralniTerapijskiRezim.FAZA_ODRZAVANJE
        ),
        "napomena_ljekara": regimen.napomena_ljekara if regimen else "",
    }
    regimen_form = OralniTerapijskiRezimForm(
        request.POST if action == "confirm_regimen" else None,
        patient=pacijent,
        initial=regimen_initial,
    )
    issue_form = OralnoIzdavanjeForm(
        request.POST if action == "issue" else None,
        regimen=regimen,
        approval_options=status["approval_options"],
        physical_available=status["physical_available"],
        next_planned_issue=status["next_uncovered"],
        quantity_at_patient=status["quantity_at_patient"],
    )

    if action == "confirm_regimen":
        if not je_doktor_ili_admin(request.user):
            raise PermissionDenied(
                "Samo doktor, koordinator ili administrator može potvrditi režim."
            )
        if regimen_form.is_valid():
            try:
                confirm_oral_regimen(
                    patient=pacijent,
                    medicine=pacijent.lijek,
                    tablets_per_intake=regimen_form.cleaned_data["tableta_po_uzimanju"],
                    intakes_per_day=regimen_form.cleaned_data["uzimanja_dnevno"],
                    effective_from=regimen_form.cleaned_data["datum_od"],
                    phase=regimen_form.cleaned_data["faza"],
                    standard_regimen=regimen_form.cleaned_data.get("standardni_rezim"),
                    doctor_note=regimen_form.cleaned_data.get("napomena_ljekara") or "",
                    user=request.user,
                )
            except ValueError as exc:
                messages.error(request, str(exc))
            else:
                messages.success(request, "Oralni terapijski režim je potvrđen.")
                return redirect("oralna_terapija", pacijent_id=pacijent.id)

    if action == "issue":
        if not regimen:
            messages.error(request, "Prvo je potrebno potvrditi oralni režim.")
        elif issue_form.is_valid():
            try:
                issue, created = issue_oral_therapy(
                    patient=pacijent,
                    regimen=regimen,
                    approval_source=issue_form.cleaned_data["izvor_odobrenja"],
                    quantity=issue_form.cleaned_data["kolicina_tableta"],
                    issued_on=issue_form.cleaned_data["datum_izdavanja"],
                    idempotency_key=issue_form.cleaned_data["idempotency_key"],
                    batch=issue_form.cleaned_data.get("serija") or "",
                    note=issue_form.cleaned_data.get("napomena") or "",
                    suggested_quantity=issue_form.cleaned_data.get(
                        "predlozena_kolicina"
                    ),
                    adjustment_reason=issue_form.cleaned_data.get(
                        "razlog_korekcije"
                    ) or "",
                    early_issue_reason=issue_form.cleaned_data.get(
                        "audit_ranijeg_izdavanja"
                    ) or "",
                    user=request.user,
                )
            except ValueError as exc:
                messages.error(request, str(exc))
            else:
                warning = issue_form.cleaned_data.get("upozorenje_nepotpun_dan")
                if warning:
                    messages.warning(request, warning)
                if created:
                    messages.success(
                        request,
                        f"Izdato je {issue.kolicina_tableta} tableta. "
                        f"Sljedeći nepokriveni datum je "
                        f"{issue.sljedeci_nepokriveni_datum:%d/%m/%Y}.",
                    )
                else:
                    messages.info(request, "Ovo oralno izdavanje je već evidentirano.")
                if request.POST.get("return_to") == "profile":
                    return redirect("profil_pacijenta", pacijent_id=pacijent.id)
                return redirect("oralna_terapija", pacijent_id=pacijent.id)

    status = oral_therapy_status(pacijent)
    oralni_operativni_plan = commission_planning_row_for_patient(pacijent)
    return render(
        request,
        "dashboard/oralna_terapija.html",
        {
            "pacijent": pacijent,
            "lijek": pacijent.lijek,
            "oralni_status": status,
            "oralni_operativni_plan": oralni_operativni_plan,
            "regimen_form": regimen_form,
            "issue_form": issue_form,
            "moze_potvrditi_rezim": je_doktor_ili_admin(request.user),
            "moze_ponistiti": je_koordinator_ili_admin(request.user),
        },
    )


@require_POST
@login_required
def ponisti_oralno_izdavanje(request, izdavanje_id):
    issue = get_object_or_404(IzdavanjeOralneTerapije, pk=izdavanje_id)
    patient_id = issue.pacijent_id
    try:
        void_oral_issuance(
            issue=issue,
            reason=request.POST.get("razlog") or "",
            user=request.user,
        )
    except (PermissionError, ValueError) as exc:
        messages.error(request, str(exc))
    else:
        messages.success(
            request,
            "Oralno izdavanje je poništeno; zaliha i pravo su vraćeni.",
        )
    return redirect("oralna_terapija", pacijent_id=patient_id)


@login_required
@user_passes_test(je_sestra_ili_admin)
@require_POST
def evidentiraj_saglasnost_pacijenta(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    broj = request.POST.get("broj_saglasnosti") or ""
    source_commission = (
        Komisija.objects.filter(pacijent=pacijent)
        .order_by("-datum_odobrenja", "-pk")
        .first()
    )
    try:
        agreement, created = update_patient_agreement(
            patient=pacijent,
            number=broj,
            user=request.user,
            source_commission=source_commission,
        )
    except ValueError as exc:
        messages.error(request, str(exc))
    else:
        conflicts = agreement_number_conflicts(
            agreement.broj_saglasnosti,
            patient=pacijent,
        )
        if conflicts:
            messages.warning(
                request,
                "Broj saglasnosti je već evidentiran kod drugog pacijenta; "
                "podatak je sačuvan bez automatskog prebacivanja.",
            )
        messages.success(
            request,
            "Broj saglasnosti je evidentiran."
            if created else "Broj saglasnosti već je važeći.",
        )
    return redirect(f"{reverse('profil_pacijenta', args=[pacijent.pk])}#komisije")


@login_required
@user_passes_test(je_admin)
def unesi_odobrenu_komisiju(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    if get_postavke_sistema().migracija_zakljucana:
        messages.warning(request, "Migracijski unos ranijih odobrenja je zaključan.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.pk)

    if request.method == "POST":
        form = OdobrenaKomisijaForm(request.POST)
        form.instance.pacijent = pacijent
        form.instance.lijek = pacijent.lijek

        if form.is_valid():
            komisija = form.save(commit=False)
            komisija.pacijent = pacijent
            komisija.lijek = pacijent.lijek
            komisija.preostale_doze = komisija.broj_odobrenih_doza
            komisija.status = "AKTIVNA"

            duplicate = Komisija.objects.filter(
                pacijent=pacijent,
                lijek_id__in=pacijent.lijek.equivalent_ids(),
                datum_odobrenja=komisija.datum_odobrenja,
                broj_odobrenih_doza=komisija.broj_odobrenih_doza,
            )
            if komisija.broj_saglasnosti:
                duplicate = duplicate.filter(
                    broj_saglasnosti__iexact=komisija.broj_saglasnosti,
                )
            if duplicate.exists():
                messages.error(
                    request,
                    "Ovo historijsko odobrenje već je evidentirano.",
                )
                return render(request, "dashboard/unesi_odobrenu_komisiju.html", {
                    "form": form,
                    "pacijent": pacijent,
                })

            komisija.save()

            messages.success(
                request,
                "Odobrena komisija je unesena. Pacijent se zadužuje tek nakon fizičke dodjele doza."
            )

            return redirect("profil_pacijenta", pacijent_id=pacijent.id)

    else:
        form = OdobrenaKomisijaForm()

    return render(request, "dashboard/unesi_odobrenu_komisiju.html", {
        "form": form,
        "pacijent": pacijent,
    })


@login_required
def print_zahtjev_zavodu_trebovanje(request, trebovanje_id):
    trebovanje = get_object_or_404(Trebovanje, id=trebovanje_id)
    if Decimal(str(trebovanje.broj_doza or 0)) <= 0:
        return HttpResponse(
            "PDF komisijskog zahtjeva nije moguće kreirati za količinu 0.",
            status=400,
            content_type="text/plain; charset=utf-8",
        )
    output_path = napravi_pdf_putanju(
        f"zahtjev_zavodu_trebovanje_{trebovanje.id}.pdf"
    )
    render_zahtjev_zavodu_pdf(trebovanje, output_path)

    return FileResponse(open(output_path, "rb"), as_attachment=False)


@login_required
def pretraga_pacijenata(request):
    q = request.GET.get("q", "").strip()

    pacijenti = Pacijent.objects.none()

    if q:
        pacijenti = Pacijent.objects.filter(
            Q(ime__icontains=q) |
            Q(prezime__icontains=q) |
            Q(lijek__naziv__icontains=q)
        ).distinct()

    return render(
        request,
        "dashboard/pretraga_pacijenata.html",
        {
            "q": q,
            "pacijenti": pacijenti,
        }
    )


@login_required
@user_passes_test(je_admin)
def pdf_koordinate(request):
    all_coords = {
        form_key: get_pdf_coords(form_key)
        for form_key in PDF_FORMS.keys()
    }
    form_key = request.POST.get("form_key") or request.GET.get("form_key") or "zahtjev_zavod"
    if form_key not in PDF_FORMS:
        form_key = "zahtjev_zavod"

    field_names = list(all_coords[form_key].keys())
    field_name = request.POST.get("field_name") or request.GET.get("field_name") or field_names[0]
    if field_name not in all_coords[form_key]:
        field_name = field_names[0]

    if request.method == "POST":
        x = request.POST.get("x", all_coords[form_key][field_name]["x"])
        y = request.POST.get("y", all_coords[form_key][field_name]["y"])
        print("SAVE PDF COORDS:", form_key, field_name, x, y)
        try:
            save_pdf_coord(form_key, field_name, x, y)
            messages.success(request, "Koordinate su sačuvane.")
        except (KeyError, TypeError, ValueError, OSError):
            messages.error(request, "Koordinate nisu ispravne.")
        return redirect(f"{reverse('pdf_koordinate')}?form_key={form_key}&field_name={field_name}")

    current = all_coords[form_key][field_name]
    forms_payload = {
        key: {
            "label": meta["label"],
            "fields": all_coords[key],
            "preview_url": reverse("pdf_koordinate_preview", args=[key]),
            "template_path": str(Path(settings.MEDIA_ROOT) / "sabloni" / PDF_TEMPLATE_MAP.get(key, "")),
            "template_exists": (Path(settings.MEDIA_ROOT) / "sabloni" / PDF_TEMPLATE_MAP.get(key, "")).exists(),
            "pdf_width": 595,
            "pdf_height": 842,
        }
        for key, meta in PDF_FORMS.items()
    }

    return render(request, "dashboard/pdf_koordinate.html", {
        "forms_payload": forms_payload,
        "form_key": form_key,
        "field_name": field_name,
        "field_names": field_names,
        "current": current,
        "pdf_debug": getattr(settings, "PDF_DEBUG", False),
    })


@login_required
@user_passes_test(je_admin)
def pdf_koordinate_preview(request, obrazac):
    PDF_TEMPLATE_MAP = {
        "zahtjev_zavod": "za_zavod.pdf",
        "razduzenje_zavod": "razduzivanje_sablon.pdf",
        "lista_terapije": "lista_terapije.pdf",
    }
    sabloni_dir = Path(settings.MEDIA_ROOT) / "sabloni"

    print("BASE_DIR =", settings.BASE_DIR)
    print("MEDIA_ROOT =", settings.MEDIA_ROOT)
    print("SABLONI_DIR =", sabloni_dir)
    print("SABLONI_EXISTS =", sabloni_dir.exists())
    print("FILES_IN_SABLONI =", list(sabloni_dir.glob("*")))

    filename = PDF_TEMPLATE_MAP.get(obrazac)
    template_path = sabloni_dir / filename if filename else sabloni_dir / ""

    print("OBRAZAC =", obrazac)
    print("FILENAME =", filename)
    print("TEMPLATE_PATH =", template_path)
    print("TEMPLATE_EXISTS =", template_path.exists())

    if not template_path.exists():
        return HttpResponse(
            "PDF template nije pronađen.<br>"
            f"Tražena putanja: {template_path}<br>"
            f"Sabloni folder postoji: {sabloni_dir.exists()}<br>"
            f"Fajlovi u folderu: {list(sabloni_dir.glob('*'))}",
            status=404
        )

    try:
        import fitz
    except ImportError:
        return HttpResponse("Instaliraj PyMuPDF: pip install PyMuPDF", status=500)

    preview_dir = Path(settings.MEDIA_ROOT) / "pdf_previews"
    preview_dir.mkdir(parents=True, exist_ok=True)
    preview_path = preview_dir / f"{obrazac}.png"

    try:
        if not preview_path.exists() or preview_path.stat().st_mtime < template_path.stat().st_mtime:
            pdf = fitz.open(str(template_path))
            page = pdf.load_page(0)
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
            pix.save(str(preview_path))
            pdf.close()

        response = FileResponse(open(preview_path, "rb"), content_type="image/png")
        response["Cache-Control"] = "no-cache"
        return response
    except Exception as exc:
        return HttpResponse(
            f"PDF template nije moguce prikazati: {template_path}<br>{exc}",
            status=500
        )

@login_required
def ajax_pretraga_pacijenata(request):
    q = request.GET.get("q", "").strip()

    if len(q) < 2:
        return JsonResponse({"groups": []})

    pacijenti = Pacijent.objects.filter(
        Q(ime__icontains=q)
        | Q(prezime__icontains=q)
        | Q(jmbg__icontains=q)
        | Q(terapijski_program__naziv__icontains=q)
        | Q(lijek__naziv__icontains=q)
        | Q(lijek__genericki_naziv__icontains=q)
        | Q(lijek__zasticeno_ime__icontains=q)
    ).select_related("lijek", "terapijski_program").distinct()[:6]

    lijekovi = Lijek.objects.filter(
        Q(naziv__icontains=q)
        | Q(genericki_naziv__icontains=q)
        | Q(zasticeno_ime__icontains=q),
        aktivan=True,
    ).order_by("naziv")[:5]

    komisije = Komisija.objects.filter(
        Q(broj_saglasnosti__icontains=q)
        | Q(pacijent__ime__icontains=q)
        | Q(pacijent__prezime__icontains=q)
        | Q(lijek__naziv__icontains=q)
        | Q(lijek__genericki_naziv__icontains=q)
        | Q(lijek__zasticeno_ime__icontains=q)
    ).select_related("pacijent", "lijek").order_by("-datum_odobrenja")[:5]

    trebovanja = Trebovanje.objects.filter(
        Q(pacijent__ime__icontains=q)
        | Q(pacijent__prezime__icontains=q)
        | Q(lijek__naziv__icontains=q)
        | Q(lijek__genericki_naziv__icontains=q)
        | Q(lijek__zasticeno_ime__icontains=q)
        | Q(status__icontains=q)
        | Q(komisijski_ciklus__naziv__icontains=q)
    ).select_related("pacijent", "lijek", "komisijski_ciklus").order_by("-datum_kreiranja")[:5]

    posiljke = KomisijskiCiklus.objects.filter(
        Q(naziv__icontains=q) | Q(status__icontains=q)
    ).order_by("-datum_kreiranja")[:5]

    groups = []

    pacijent_items = [
        {
            "title": f"{p.ime} {p.prezime}",
            "subtitle": f"{p.jmbg} · {p.terapija_za_prikaz}",
            "url": f"/pacijent/{p.id}/",
            "icon": "bi-person-vcard",
        }
        for p in pacijenti
    ]
    if pacijent_items:
        groups.append({"title": "Pacijenti", "items": pacijent_items})

    lijek_items = [
        {
            "title": lijek.prikaz_naziv,
            "subtitle": "Lista pacijenata za lijek",
            "url": f"/pacijenti/?q={lijek.naziv}",
            "icon": "bi-capsule",
        }
        for lijek in lijekovi
    ]
    if lijek_items:
        groups.append({"title": "Lijekovi", "items": lijek_items})

    komisija_items = [
        {
            "title": f"{k.pacijent} · {k.lijek}",
            "subtitle": f"Komisija {k.broj_saglasnosti or 'bez broja'} · {k.get_status_display()}",
            "url": f"/pacijent/{k.pacijent_id}/",
            "icon": "bi-clipboard2-pulse",
        }
        for k in komisije
    ]
    komisija_items.extend([
        {
            "title": f"{t.pacijent} · {t.lijek}",
            "subtitle": f"Trebovanje · {t.get_status_display()}",
            "url": "/komisijski-centar/odobrenje/",
            "icon": "bi-file-earmark-medical",
        }
        for t in trebovanja
    ])
    if komisija_items:
        groups.append({"title": "Komisije/Trebovanja", "items": komisija_items[:8]})

    posiljka_items = [
        {
            "title": ciklus.naziv,
            "subtitle": ciklus.get_status_display(),
            "url": "/komisijski-centar/zaprimanje/",
            "icon": "bi-box-arrow-in-down",
        }
        for ciklus in posiljke
    ]
    if posiljka_items:
        groups.append({"title": "Pošiljke", "items": posiljka_items})

    return JsonResponse({"groups": groups})

@login_required
def brzi_unos(request):
    return render(
        request,
        "dashboard/brzi_unos.html"
    )

@login_required
def _legacy_izvjestaji(request):
    danas = timezone.now().date()
    periodi = {
        "30": ("30 dana", 30, 3),
        "90": ("90 dana", 90, 3),
        "180": ("6 mjeseci", 180, 6),
        "365": ("12 mjeseci", 365, 12),
    }
    period_key = request.GET.get("period", "90")
    if period_key not in periodi:
        period_key = "90"
    period_label, period_dana, broj_mjeseci = periodi[period_key]
    pocetak_perioda = danas - timedelta(days=period_dana)
    lijek_id = request.GET.get("lijek") or ""
    export = request.GET.get("export") or ""

    svi_lijekovi = list(
        active_therapy_medicines().order_by("genericki_naziv", "naziv")
    )
    lijekovi_po_grupi = {}
    for lijek in svi_lijekovi:
        lijekovi_po_grupi.setdefault(get_therapy_group(lijek), lijek)
    lijekovi = list(lijekovi_po_grupi.values())
    lijek_filter = Lijek.objects.filter(id=lijek_id).first() if lijek_id else None
    filter_lijek_ids = equivalent_medicine_ids(lijek_filter) if lijek_filter else []
    aktivni_pacijenti_qs = Pacijent.objects.filter(aktivan=True).select_related("lijek", "terapijski_protokol")
    terapije_qs = Terapija.objects.filter(datum__gte=pocetak_perioda, datum__lte=danas).select_related("lijek", "pacijent")
    komisije_qs = Komisija.objects.all().select_related("lijek", "pacijent")
    if lijek_filter:
        aktivni_pacijenti_qs = aktivni_pacijenti_qs.filter(lijek_id__in=filter_lijek_ids)
        terapije_qs = terapije_qs.filter(lijek_id__in=filter_lijek_ids)
        komisije_qs = komisije_qs.filter(lijek_id__in=filter_lijek_ids)

    aktivni_pacijenti = list(aktivni_pacijenti_qs)
    terapije_danas = Terapija.objects.filter(datum=danas)
    if lijek_filter:
        terapije_danas = terapije_danas.filter(lijek_id__in=filter_lijek_ids)
    potrosene_doze_period = terapije_qs.aggregate(total=models.Sum("kolicina"))["total"] or Decimal("0")
    komisija_uskoro = len(patients_for_next_commission())

    zalihe_redovi = [
        row for row in zalihe_sa_potrebama()
        if not lijek_filter or get_therapy_group(row["lijek"]) == get_therapy_group(lijek_filter)
    ]
    predvidjena_potreba_3m = sum((
        Decimal(str(row["potreba_do_ocekivane_isporuke"] or 0)) for row in zalihe_redovi
    ), Decimal("0"))
    ukupno_u_frizideru = sum((Decimal(str(row["u_frizideru"] or 0)) for row in zalihe_redovi), Decimal("0"))
    potrosnja_30 = sum((Decimal(str(row["potrosnja_30_dana"] or 0)) for row in zalihe_redovi), Decimal("0"))
    dnevna_potreba = potrosnja_30 / Decimal("30") if potrosnja_30 else Decimal("0")
    pokrivenost_dana = int(ukupno_u_frizideru / dnevna_potreba) if dnevna_potreba else None
    pokrivenost_label = f"{pokrivenost_dana} dana" if pokrivenost_dana is not None else "Nema planirane potrebe"

    mjeseci = []
    pocetak_mjeseca = danas.replace(day=1)
    cursor = pocetak_mjeseca
    for _ in range(broj_mjeseci - 1):
        cursor = (cursor.replace(day=1) - timedelta(days=1)).replace(day=1)
    while cursor <= pocetak_mjeseca:
        sljedeci = (
            cursor.replace(year=cursor.year + 1, month=1, day=1)
            if cursor.month == 12
            else cursor.replace(month=cursor.month + 1, day=1)
        )
        mjesec_qs = Terapija.objects.filter(datum__gte=cursor, datum__lt=sljedeci)
        if lijek_filter:
            mjesec_qs = mjesec_qs.filter(lijek_id__in=filter_lijek_ids)
        mjeseci.append({
            "label": cursor.strftime("%m.%Y"),
            "doze": mjesec_qs.aggregate(total=models.Sum("kolicina"))["total"] or Decimal("0"),
            "terapije": mjesec_qs.count(),
        })
        cursor = sljedeci
    max_mjesec_doze = max([Decimal(str(m["doze"])) for m in mjeseci] or [Decimal("1")]) or Decimal("1")
    for mjesec in mjeseci:
        mjesec["doze_width"] = int((Decimal(str(mjesec["doze"])) / max_mjesec_doze) * 100)

    lijek_rows = []
    for lijek in lijekovi:
        if lijek_filter and get_therapy_group(lijek) != get_therapy_group(lijek_filter):
            continue
        group_ids = equivalent_medicine_ids(lijek)
        aktivni = Pacijent.objects.filter(lijek_id__in=group_ids, aktivan=True).count()
        doze_period = terapije_qs.filter(lijek_id__in=group_ids).aggregate(total=models.Sum("kolicina"))["total"] or Decimal("0")
        terapije_period = terapije_qs.filter(lijek_id__in=group_ids).count()
        if aktivni or doze_period or terapije_period:
            lijek_rows.append({
                "lijek": lijek,
                "aktivni": aktivni,
                "doze": doze_period,
                "terapije": terapije_period,
            })
    max_aktivni = max([item["aktivni"] for item in lijek_rows] or [1]) or 1
    max_doze = max([Decimal(str(item["doze"])) for item in lijek_rows] or [Decimal("1")]) or Decimal("1")
    for item in lijek_rows:
        item["aktivni_width"] = int((item["aktivni"] / max_aktivni) * 100)
        item["doze_width"] = int((Decimal(str(item["doze"])) / max_doze) * 100)

    forecast_rows = []
    for row in zalihe_redovi:
        potrebno = Decimal(str(row["potreba_do_ocekivane_isporuke"] or 0))
        fizicki = Decimal(str(row["ukupno_fizicko_stanje"] or 0))
        pokrivenost = int(min((fizicki / potrebno) * 100, Decimal("999"))) if potrebno else 100
        forecast_rows.append({
            **row,
            "pokrivenost": pokrivenost,
            "pokrivenost_width": min(pokrivenost, 100),
            "nedostaje": row["za_novu_komisiju"],
            "status_class": "red" if row["status"] == "Kritično" else "amber" if row["status"] == "Planirati nabavku" else "green",
        })

    ukupno_odobreno = komisije_qs.aggregate(total=models.Sum("broj_odobrenih_doza"))["total"] or Decimal("0")
    ukupno_preostalo = komisije_qs.aggregate(total=models.Sum("preostale_doze"))["total"] or Decimal("0")
    ukupno_potroseno_odobreno = max(Decimal("0"), Decimal(str(ukupno_odobreno)) - Decimal(str(ukupno_preostalo)))
    iskoristenost = int((ukupno_potroseno_odobreno / ukupno_odobreno) * 100) if ukupno_odobreno else 0

    pacijenti_bez_termina = 0
    pacijenti_bez_doza = 0
    terapija_kasni = 0
    indukcija_po_lijeku = defaultdict(lambda: {"lijek": "", "indukcija": 0, "odrzavanje": 0})
    for pacijent in aktivni_pacijenti:
        if not pacijent.termin_set.filter(status="ZAKAZAN").exists() and pacijent.trenutni_korak_je_ambulanta():
            pacijenti_bez_termina += 1
        status = izracunaj_status_pacijenta(pacijent)
        if status.get("status") in ["Nema fizičkih doza kod pacijenta", "Nedovoljno kućnih doza", "Nema odobrenih doza"]:
            pacijenti_bez_doza += 1
        if status.get("status") == "Terapija kasni":
            terapija_kasni += 1
        lijek_naziv = therapy_group_label(pacijent.lijek)
        indukcija_po_lijeku[lijek_naziv]["lijek"] = lijek_naziv
        if "induk" in (pacijent.terapijska_faza() or "").lower():
            indukcija_po_lijeku[lijek_naziv]["indukcija"] += 1
        else:
            indukcija_po_lijeku[lijek_naziv]["odrzavanje"] += 1
    indukcija_rows = list(indukcija_po_lijeku.values())
    max_faza = max([row["indukcija"] + row["odrzavanje"] for row in indukcija_rows] or [1]) or 1
    for row in indukcija_rows:
        row["indukcija_width"] = int((row["indukcija"] / max_faza) * 100)
        row["odrzavanje_width"] = int((row["odrzavanje"] / max_faza) * 100)

    prvi_dolasci = Terapija.objects.values("pacijent_id").annotate(
        prva_terapija=models.Min("datum")
    )
    if lijek_filter:
        prvi_dolasci = prvi_dolasci.filter(lijek_id__in=filter_lijek_ids)
    prvi_dolasci = list(prvi_dolasci)
    novi_pacijenti_mjeseci = []
    for mjesec in mjeseci:
        mjesec_start = datetime.strptime(f"01.{mjesec['label']}", "%d.%m.%Y").date()
        mjesec_end = (
            mjesec_start.replace(year=mjesec_start.year + 1, month=1, day=1)
            if mjesec_start.month == 12
            else mjesec_start.replace(month=mjesec_start.month + 1, day=1)
        )
        novi_pacijenti_mjeseci.append({
            "label": mjesec["label"],
            "broj": sum(1 for item in prvi_dolasci if mjesec_start <= item["prva_terapija"] < mjesec_end),
            "width": 0,
        })
    max_novi = max([item["broj"] for item in novi_pacijenti_mjeseci] or [1]) or 1
    for item in novi_pacijenti_mjeseci:
        item["width"] = int((item["broj"] / max_novi) * 100)

    kpi_cards = [
        {"label": "Aktivni pacijenti", "value": len(aktivni_pacijenti), "icon": "bi-people"},
        {"label": "Terapije danas", "value": terapije_danas.count(), "icon": "bi-calendar2-pulse"},
        {"label": f"Potrošene doze ({period_label})", "value": potrosene_doze_period, "icon": "bi-capsule"},
        {"label": "Pokrivenost zalihama", "value": pokrivenost_label, "icon": "bi-shield-check"},
        {"label": "Pacijenti za narednu komisiju", "value": komisija_uskoro, "icon": "bi-clipboard2-pulse"},
        {"label": "Potreba do očekivane isporuke", "value": predvidjena_potreba_3m, "icon": "bi-graph-up-arrow"},
    ]

    export_rows = [
        ["Lijek", "U frižideru", "Kod pacijenata", "Za novu komisiju", "Potreba do isporuke", "Pokrivenost %", "Status"]
    ]
    for row in forecast_rows:
        export_rows.append([
            row["lijek"].naziv,
            row["u_frizideru"],
            row["kod_pacijenata"],
            row["za_novu_komisiju"],
            row["potreba_do_ocekivane_isporuke"],
            row["pokrivenost"],
            row["status"],
        ])

    if export == "excel":
        import csv

        response = HttpResponse(content_type="text/csv; charset=utf-8")
        response["Content-Disposition"] = 'attachment; filename="theraflow-izvjestaji.csv"'
        response.write("\ufeff")
        writer = csv.writer(response)
        writer.writerows(export_rows)
        return response

    if export == "pdf":
        response = HttpResponse(content_type="application/pdf")
        response["Content-Disposition"] = 'attachment; filename="theraflow-izvjestaji.pdf"'
        p = canvas.Canvas(response, pagesize=A4)
        p.setFont("DejaVuSans-Bold", 14)
        p.drawString(40, 800, "TheraFlow BI izvještaj")
        p.setFont("DejaVuSans", 9)
        y = 775
        for card in kpi_cards:
            p.drawString(40, y, f"{card['label']}: {card['value']}")
            y -= 16
        y -= 12
        p.setFont("DejaVuSans-Bold", 10)
        p.drawString(40, y, "Zalihe i pokrivenost")
        y -= 16
        p.setFont("DejaVuSans", 8)
        for row in forecast_rows[:24]:
            p.drawString(
                40,
                y,
                f"{row['lijek'].naziv}: frižider {row['u_frizideru']}, "
                f"do isporuke {row['potreba_do_ocekivane_isporuke']}, status {row['status']}",
            )
            y -= 13
            if y < 50:
                p.showPage()
                p.setFont("DejaVuSans", 8)
                y = 800
        p.save()
        return response

    return render(request, "dashboard/izvjestaji.html", {
        "periodi": periodi,
        "period_key": period_key,
        "period_label": period_label,
        "lijekovi": lijekovi,
        "lijek_id": lijek_id,
        "kpi_cards": kpi_cards,
        "mjeseci": mjeseci,
        "lijek_rows": lijek_rows,
        "forecast_rows": forecast_rows,
        "komisije": {
            "odobreno": ukupno_odobreno,
            "potroseno": ukupno_potroseno_odobreno,
            "iskoristenost": iskoristenost,
        },
        "stanje_pacijenata": {
            "komisija_uskoro": komisija_uskoro,
            "bez_termina": pacijenti_bez_termina,
            "bez_doza": pacijenti_bez_doza,
            "terapija_kasni": terapija_kasni,
        },
        "indukcija_rows": indukcija_rows,
        "novi_pacijenti_mjeseci": novi_pacijenti_mjeseci,
    })


@login_required
def izvjestaji(request):
    from patients.reporting import build_report_data

    danas = timezone.localdate()
    periodi = {
        "30": ("30 dana", 30),
        "90": ("90 dana", 90),
        "180": ("6 mjeseci", 180),
        "365": ("12 mjeseci", 365),
    }
    tabovi = {
        "operativni": "Operativni pregled",
        "terapije": "Terapije i potrošnja",
        "komisije": "Komisije i zalihe",
        "razvoj": "Razvoj ambulante",
    }
    period_key = request.GET.get("period", "90")
    if period_key not in periodi:
        period_key = "90"
    period_label, period_days = periodi[period_key]
    start = danas - timedelta(days=period_days - 1)
    tab = request.GET.get("tab", "operativni")
    if tab not in tabovi:
        tab = "operativni"
    medicine_id = request.GET.get("lijek", "")
    medicine = Lijek.objects.filter(pk=medicine_id).first() if medicine_id else None
    therapy_type = request.GET.get("tip_terapije", "")
    phase = request.GET.get("faza", "")
    patient_scope = request.GET.get("pacijenti", "aktivni")
    if patient_scope not in {"aktivni", "neaktivni", "svi"}:
        patient_scope = "aktivni"
    active_only = patient_scope == "aktivni"
    inactive_only = patient_scope == "neaktivni"
    show_inactive = request.GET.get("prikazi_neaktivne") == "1"

    report = build_report_data(
        start=start,
        end=danas,
        medicine=medicine,
        therapy_type=therapy_type,
        phase=phase,
        active_only=active_only,
        inactive_only=inactive_only,
        show_inactive=show_inactive,
    )
    action_filter = request.GET.get("akcija", "")
    allowed_action_filters = {
        "commission",
        "without_appointment",
        "without_doses",
        "late",
        "pauses",
    }
    if action_filter not in allowed_action_filters:
        action_filter = ""
    operational_actions = [
        item
        for item in report["operational_actions"]
        if not action_filter or action_filter in item["kategorije"]
    ]
    total_requested = sum((row["kolicina_za_komisiju"] for row in report["commission_inventory"]), Decimal("0"))
    medicines_requiring = sum(1 for row in report["commission_inventory"] if row["kolicina_za_komisiju"] > 0)
    total_fridge = sum((_decimal_report(row["u_frizideru"]) for row in report["commission_inventory"]), Decimal("0"))

    query_params = request.GET.copy()
    query_params.pop("export", None)
    query_params["tab"] = tab
    base_query_params = query_params.copy()
    base_query_params.pop("akcija", None)
    tab_query_params = base_query_params.copy()
    tab_query_params.pop("tab", None)
    export_rows = _report_export_rows(
        tab,
        report,
        action_filter=action_filter,
    )
    export = request.GET.get("export", "")
    if export == "excel":
        import csv
        response = HttpResponse(content_type="text/csv; charset=utf-8")
        response["Content-Disposition"] = f'attachment; filename="theraflow-{tab}-{danas}.csv"'
        response.write("\ufeff")
        writer = csv.writer(response)
        settings_row = get_postavke_sistema()
        writer.writerow([tabovi[tab]])
        writer.writerow(["Period", f"{start:%d/%m/%Y} - {danas:%d/%m/%Y}"])
        writer.writerow(["Lijek", medicine.therapeutic_group_name if medicine else "Svi lijekovi"])
        writer.writerow(["Pacijenti", {
            "aktivni": "Aktivni pacijenti",
            "neaktivni": "Neaktivni pacijenti",
            "svi": "Svi pacijenti",
        }[patient_scope]])
        if therapy_type:
            writer.writerow(["Tok terapije", therapy_type])
        if phase:
            writer.writerow(["Faza", phase])
        writer.writerow(["Ustanova", settings_row.zdravstvena_ustanova or "TheraFlow"])
        writer.writerow(["Generisao", request.user.get_full_name() or request.user.username])
        writer.writerow([])
        writer.writerows(export_rows)
        return response
    if export == "pdf":
        response = HttpResponse(content_type="application/pdf")
        response["Content-Disposition"] = f'attachment; filename="theraflow-{tab}-{danas}.pdf"'
        pdf = canvas.Canvas(response, pagesize=A4)
        pdf.setFont("DejaVuSans-Bold", 14)
        pdf.drawString(36, 805, f"TheraFlow — {tabovi[tab]}")
        pdf.setFont("DejaVuSans", 8)
        pdf.drawString(
            36,
            790,
            (
                f"Period: {start:%d/%m/%Y} - {danas:%d/%m/%Y} | "
                f"Lijek: {medicine.therapeutic_group_name if medicine else 'Svi lijekovi'} | "
                f"Pacijenti: {patient_scope}"
            ),
        )
        y = 770
        for row in export_rows:
            text_row = " | ".join(str(value) for value in row)
            pdf.drawString(36, y, text_row[:125])
            y -= 13
            if y < 45:
                pdf.showPage()
                pdf.setFont("DejaVuSans", 8)
                y = 805
        pdf.save()
        return response

    all_medicines = []
    seen_groups = set()
    for item in active_therapy_medicines().order_by("genericki_naziv", "naziv"):
        group = get_therapy_group(item)
        if group not in seen_groups:
            seen_groups.add(group)
            all_medicines.append(item)

    return render(request, "dashboard/izvjestaji.html", {
        "tabovi": tabovi,
        "aktivni_tab": tab,
        "periodi": periodi,
        "period_key": period_key,
        "period_label": period_label,
        "pocetak_perioda": start,
        "kraj_perioda": danas,
        "lijekovi": all_medicines,
        "lijek_id": medicine_id,
        "tip_terapije": therapy_type,
        "faza": phase,
        "status_pacijenata": patient_scope,
        "prikazi_neaktivne": show_inactive,
        "report": report,
        "operativne_akcije": operational_actions,
        "akcija_filter": action_filter,
        "broj_lijekova_za_nabavku": medicines_requiring,
        "ukupno_za_komisiju": total_requested,
        "ukupno_u_frizideru": total_fridge,
        "export_query": query_params.urlencode(),
        "base_query": base_query_params.urlencode(),
        "tab_query": tab_query_params.urlencode(),
    })


def _decimal_report(value):
    return Decimal(str(value or 0))


def _report_export_rows(tab, report, *, action_filter=""):
    if tab == "terapije":
        rows = [["Mjesec", "Ambulantno", "Kućno izdavanje", "Ukupno razduženo"]]
        rows.extend([[m["label"], m["ambulantno"], m["kucno"], m["ukupno"]] for m in report["months"]])
        return rows
    if tab == "komisije":
        rows = [["Lijek", "Aktivni pacijenti", "Neto potreba", "Za komisiju", "Traženo", "Odobreno", "Zaprimljeno", "Čeka isporuku", "Frižider", "Rezervisano", "Kod pacijenta", "Ambulantno", "Kućno", "Preostalo pravo"]]
        rows.extend([[
            r["lijek"].therapeutic_group_name,
            r["aktivni_pacijenti"],
            (
                f"{r['stvarna_neto_potreba']} "
                f"{r.get('neto_jedinica_prikaza', '')}"
            ).strip(),
            r["nabavka_komisije"]["display_text"],
            r["ukupno_trazeno"],
            r["ukupno_odobreno"],
            r["fizicki_zaprimljeno"],
            r["odobreno_ceka_isporuku"],
            r["u_frizideru"],
            r["rezervisano"],
            r["kod_pacijenata"],
            r["primijenjeno_ambulantno"],
            r["izdano_kucno"],
            r["preostalo_pravo"],
        ] for r in report["commission_inventory"]])
        rows.extend([
            [],
            ["Komisijski zahtjevi u periodu"],
            ["Pacijent", "Ciklus", "Vrsta zahtjeva", "Dokumentacija", "Status"],
        ])
        rows.extend([
            [
                str(request.pacijent),
                request.komisijski_ciklus.naziv,
                request.canonical_request_type_label,
                request.document_package.label,
                request.get_status_display(),
            ]
            for request in report.get("commission_requests", ())
        ])
        return rows
    if tab == "razvoj":
        return [["Mjesec", "Novi pacijenti"], *[[r["label"], r["broj"]] for r in report["new_patients"]]]
    rows = [
        ["Trenutno za uraditi"],
        ["Akcija", "Pacijent", "Lijek", "Rok", "Status", "Sljedeći korak"],
    ]
    for item in report["operational_actions"]:
        if action_filter and action_filter not in item["kategorije"]:
            continue
        rows.append([
            item["potrebna_akcija"],
            str(item["pacijent"]),
            item["lijek"].therapeutic_group_name if item["lijek"] else "",
            item["rok"].strftime("%d/%m/%Y") if item["rok"] else "Bez roka",
            item["status_oznaka"],
            item["action_label"],
        ])
    rows.extend([
        [],
        ["U izabranom periodu"],
        ["Evidentirane terapije", report["therapy_summary"]["broj_terapija"]],
        ["Nedolasci", report["period_counts"]["no_show"]],
        ["Odgođeni termini", report["period_counts"]["postponed"]],
        ["Otkazani termini", report["period_counts"]["cancelled"]],
    ])
    return rows

@login_required
@user_passes_test(je_koordinator_ili_admin)
def audit_log(request):

    logovi = AktivnostLog.objects.all().order_by("-datum_vrijeme")

    return render(
        request,
        "dashboard/audit_log.html",
        {
            "logovi": logovi
        }
    )

@login_required
@user_passes_test(je_admin)
def backup_baze(request):
    ensure_backup_dir()
    if request.method == "POST":
        action = request.POST.get("action", "manual_backup")
        try:
            if action == "manual_backup_test":
                backup_path = run_manual_backup_test()
            elif action == "usb_backup":
                destination = Path(
                    (request.POST.get("usb_destination") or "").strip()
                ).expanduser()
                if not destination.is_absolute() or not destination.is_dir():
                    raise BackupError(
                        "USB uređaj nije pronađen. Povežite uređaj i pokušajte ponovo."
                    )
                request.session["theraflow_usb_backup_destination"] = str(
                    destination.resolve()
                )
                backup_path = create_postgres_backup()
                usb_path = destination.resolve() / backup_path.name
                if usb_path.exists():
                    raise BackupError("Backup sa istim nazivom već postoji na USB lokaciji.")
                shutil.copy2(backup_path, usb_path)
                backup_path = usb_path
            else:
                backup_path = create_postgres_backup()
        except BackupError as exc:
            messages.error(
                request,
                f"Backup nije kreiran. Pogledajte detalje greške. {exc}",
            )
        else:
            action_label = (
                "Ručni test PostgreSQL backupa"
                if action == "manual_backup_test"
                else "Ručni PostgreSQL backup na USB lokaciju"
                if action == "usb_backup"
                else "Ručni PostgreSQL backup"
            )
            upisi_log(
                request.user,
                action_label,
                opis=f"Backup uspješno napravljen: {backup_path.name}",
            )
            if action == "manual_backup_test":
                messages.success(
                    request,
                    "Test backupa je uspješno završen. Ovo ne potvrđuje da scheduler radi.",
                )
            else:
                messages.success(request, "Backup je uspješno kreiran.")
        return redirect("backup_baze")

    try:
        pg_dump_resolved_path = executable_path("pg_dump")
        pg_dump_error = ""
    except BackupError as exc:
        pg_dump_resolved_path = ""
        pg_dump_error = str(exc)

    return render(request, "dashboard/backup_baze.html", {
        "backupi": list_postgres_backups(),
        "backup_dir": ensure_backup_dir(),
        "automatic_backup": automatic_backup_status(),
        "pg_dump_resolved_path": pg_dump_resolved_path,
        "pg_dump_error": pg_dump_error,
        "usb_destination": request.session.get(
            "theraflow_usb_backup_destination", ""
        ),
    })

def automatski_backup_baze():
    try:
        backup_path = ensure_daily_backup()
    except BackupError as exc:
        print(f"AUTOMATSKI BACKUP NIJE NAPRAVLJEN: {exc}")
        return None
    return backup_path


@login_required
@user_passes_test(je_admin)
def preuzmi_backup(request, filename):
    try:
        backup_path = safe_backup_path(filename)
    except BackupError as exc:
        messages.error(request, str(exc))
        return redirect("backup_baze")
    return FileResponse(open(backup_path, "rb"), as_attachment=True, filename=backup_path.name)


@login_required
@user_passes_test(je_admin)
def restore_backup(request):
    if request.method == "POST":
        backup_fajl = request.POST.get("backup_fajl")
        potvrda = request.POST.get("restore_confirmed") == "on"
        if not potvrda:
            messages.error(request, "Za restore morate potvrditi da razumijete da će trenutna baza biti zamijenjena.")
            return redirect("restore_backup")

        try:
            before_restore = restore_postgres_backup(backup_fajl)
        except BackupError as exc:
            messages.error(request, str(exc))
        else:
            upisi_log(
                request.user,
                "Restore PostgreSQL baze",
                opis=(
                    f"Vraćen backup: {backup_fajl}. "
                    f"Prije restore-a napravljen backup: {before_restore.name}."
                ),
            )
            messages.success(
                request,
                "Backup uspješno vraćen. Potrebno je restartovati TheraFlow."
            )
        return redirect("restore_backup")

    return render(request, "dashboard/restore_backup.html", {
        "backupi": list_postgres_backups()
    })


@login_required
@user_passes_test(je_koordinator_ili_admin)
def dodijeli_slobodne_doze(request, lijek_id):
    lijek = get_object_or_404(Lijek, id=lijek_id)
    slobodno = free_stock_quantity(lijek)
    request_token = request.POST.get("request_token", "") or request.session.get(
        "free_stock_assignment_request_token", ""
    )
    used_tokens = request.session.get("free_stock_assignment_tokens", [])

    # POST/Redirect/GET obično spriječi replay, ali isti HTTP zahtjev može
    # biti ponovljen nakon timeouta. Već uspješno potrošen token tretiramo
    # kao isti zahtjev i ne dodjeljujemo doze drugi put.
    if request.method == "POST" and request_token and request_token in used_tokens:
        pacijent = Pacijent.objects.filter(pk=request.POST.get("pacijent")).first()
        if pacijent:
            messages.success(
                request,
                f"Uspješno je dodijeljeno {request.POST.get('kolicina')} slobodnih "
                f"doza pacijentu {pacijent}.",
            )
        else:
            messages.success(request, "Dodjela slobodnih doza je već evidentirana.")
        return redirect("lista_zaliha")

    if request.method != "POST":
        request_token = uuid.uuid4().hex
        request.session["free_stock_assignment_request_token"] = request_token
    kandidati = free_stock_recipient_candidates(lijek)
    maksimalna_kolicina = slobodno
    for item in kandidati:
        item["preporucena_kolicina"] = min(slobodno, item["nedostaje"])
        item["maksimalno_moguce"] = slobodno
        item["jedinica"] = lijek.jedinica_zalihe_za_kolicinu(
            item["nedostaje"]
        )
    form = DodjelaSlobodneZaliheForm(
        request.POST or None,
        max_quantity=maksimalna_kolicina,
    )
    kandidati_po_id = {
        str(item["pacijent"].pk): item for item in kandidati
    }
    izvori = free_stock_source_rows(lijek)

    if request.method == "POST":
        razlog = (request.POST.get("razlog") or "").strip()
        if not form.is_valid():
            messages.error(request, "Unesite ispravnu cjelobrojnu količinu.")
        elif request.POST.get("pacijent") not in kandidati_po_id:
            messages.error(
                request,
                "Odabrani pacijent nema odgovarajuću buduću nepokrivenu potrebu.",
            )
        elif not razlog:
            messages.error(request, "Razlog dodjele je obavezan.")
        else:
            kolicina = Decimal(form.cleaned_data["kolicina"])
            pacijent = kandidati_po_id[request.POST["pacijent"]]["pacijent"]
            trenutni_manjak = Decimal(str(
                kandidati_po_id[request.POST["pacijent"]]["nedostaje"] or 0
            ))
            try:
                assign_free_stock_to_patient(
                    pacijent=pacijent,
                    lijek=lijek,
                    quantity=kolicina,
                    user=request.user,
                    reason=razlog,
                )
            except ValueError as exc:
                messages.error(request, str(exc))
            except Exception:
                logger.exception("Kontrolisana greška pri dodjeli slobodnih doza")
                messages.error(
                    request,
                    "Dodjela slobodnih doza nije izvršena. Pokušajte ponovo.",
                )
            else:
                if request_token:
                    used_tokens.append(request_token)
                    request.session["free_stock_assignment_tokens"] = used_tokens[-20:]
                messages.success(
                    request,
                    f"Uspješno je dodijeljeno {form.cleaned_data['kolicina']} "
                    f"slobodnih doza pacijentu {pacijent}.",
                )
                if kolicina > trenutni_manjak:
                    messages.warning(
                        request,
                        "Dodijeljeno je više od trenutne potrebe pacijenta.",
                    )
                return redirect("lista_zaliha")

    return render(request, "dashboard/dodijeli_slobodne_doze.html", {
        "lijek": lijek,
        "slobodno": slobodno,
        "form": form,
        "kandidati": kandidati,
        "izvori": izvori,
        "request_token": request_token,
    })


@login_required
@user_passes_test(je_koordinator_ili_admin)
def oslobodi_nevazecu_rezervaciju(request, rezervacija_id):
    if request.method != "POST":
        raise PermissionDenied("Oslobađanje rezervacije zahtijeva potvrdu.")
    rezervacija = get_object_or_404(
        PacijentRezervacija.objects.select_related("pacijent", "lijek"),
        id=rezervacija_id,
        aktivno=True,
        kolicina__gt=0,
    )
    detalj = next(
        (
            item for item in active_reservation_details(rezervacija.lijek)
            if item["rezervacija"].pk == rezervacija.pk
        ),
        None,
    )
    if not detalj or detalj["opravdan_aktivni_izvor"]:
        messages.error(request, "Rezervacija je još opravdano vezana za aktivnu terapiju pacijenta.")
        return redirect("lista_zaliha")
    razlog_kod = (request.POST.get("razlog_oslobadjanja") or "").strip()
    napomena = (
        request.POST.get("napomena_oslobadjanja")
        or request.POST.get("razlog")
        or ""
    ).strip()
    try:
        released = release_patient_reservations_to_free_stock(
            pacijent=rezervacija.pacijent,
            lijek=rezervacija.lijek,
            user=request.user,
            reason=napomena,
            reason_code=razlog_kod,
            reference=rezervacija,
        )
    except ValueError as exc:
        messages.error(request, str(exc))
        return redirect("lista_zaliha")
    messages.success(
        request,
        f"Oslobođeno je {released:g} iz nevažeće rezervacije u slobodnu zalihu.",
    )
    return redirect("lista_zaliha")


@login_required
@user_passes_test(je_koordinator_ili_admin)
def oslobodi_nevazece_rezervacije_lijeka(request, lijek_id):
    if request.method != "POST":
        raise PermissionDenied("Oslobađanje rezervacija zahtijeva potvrdu.")
    lijek = get_object_or_404(Lijek, id=lijek_id)
    razlog_kod = (request.POST.get("razlog_oslobadjanja") or "").strip()
    napomena = (
        request.POST.get("napomena_oslobadjanja")
        or request.POST.get("razlog")
        or ""
    ).strip()
    invalid = [
        item for item in active_reservation_details(lijek)
        if not item["opravdan_aktivni_izvor"]
    ]
    if not invalid:
        messages.info(request, "Nema nevažećih rezervacija za oslobađanje.")
        return redirect("lista_zaliha")
    released = Decimal("0")
    processed_patients = set()
    with transaction.atomic():
        for item in invalid:
            patient = item["pacijent"]
            if patient.pk in processed_patients:
                continue
            processed_patients.add(patient.pk)
            try:
                released += release_patient_reservations_to_free_stock(
                    pacijent=patient,
                    lijek=lijek,
                    user=request.user,
                    reason=napomena,
                    reason_code=razlog_kod,
                    reference=item["rezervacija"],
                )
            except ValueError as exc:
                messages.error(request, str(exc))
                transaction.set_rollback(True)
                return redirect("lista_zaliha")
    messages.success(
        request,
        f"Oslobođeno je {released:g} iz nevažećih rezervacija. "
        "Zaliha i komisijska potreba su ponovo izračunate.",
    )
    return redirect("lista_zaliha")


@login_required
@user_passes_test(je_koordinator_ili_admin)
def premjesti_doze(request, pacijent_id):
    """Premjesti samo stvarnu, još aktivnu pacijentsku rezervaciju."""
    pacijent_od = get_object_or_404(Pacijent, id=pacijent_id)
    rezervacije = PacijentRezervacija.objects.filter(
        pacijent=pacijent_od,
        aktivno=True,
        kolicina__gt=0,
    ).select_related("lijek").order_by("datum_rezervacije", "id")
    izvorna_rezervacija = rezervacije.first()
    if not izvorna_rezervacija:
        oslobadjanje = ZalihaTransakcija.objects.filter(
            pacijent=pacijent_od,
            tip=ZalihaTransakcija.TIP_OSLOBADJANJE_U_SLOBODNU_ZALIHU,
        ).order_by("-datum", "-id").first()
        if oslobadjanje:
            messages.info(request, "Doze više nisu rezervisane starom pacijentu; dodijelite ih iz slobodne zalihe.")
            return redirect("dodijeli_slobodne_doze", lijek_id=oslobadjanje.lijek_id)
        messages.info(request, "Pacijent nema aktivnih rezervisanih doza za premještaj.")
        return redirect("profil_pacijenta", pacijent_id=pacijent_od.id)

    lijek = izvorna_rezervacija.lijek
    dostupno = sum((Decimal(str(r.kolicina or 0)) for r in rezervacije if r.lijek_id in equivalent_medicine_ids(lijek)), Decimal("0"))
    pacijenti = eligible_free_stock_recipients(lijek).exclude(id=pacijent_od.id)
    if request.method == "POST":
        razlog = (request.POST.get("napomena") or "").strip()
        try:
            broj_doza = Decimal(request.POST.get("broj_doza") or "0")
        except Exception:
            broj_doza = Decimal("0")
        pacijent_za = get_object_or_404(pacijenti, id=request.POST.get("pacijent_za"))
        if broj_doza <= 0 or broj_doza > dostupno:
            messages.error(request, "Unesite količinu koja ne prelazi aktivnu rezervaciju.")
        elif not razlog:
            messages.error(request, "Razlog premještaja je obavezan.")
        else:
            with transaction.atomic():
                skini_rezervaciju_pacijenta(pacijent_od, lijek, broj_doza)
                rezervisi_doze_za_pacijenta(
                    pacijent_za, lijek, broj_doza,
                    korisnik=request.user,
                    napomena=f"Premještaj rezervacije: {razlog}",
                )
                upisi_log(
                    request.user, "Premještaj rezervisanih doza",
                    pacijent=pacijent_od,
                    opis=(f"{lijek.naziv}: {broj_doza} sa {pacijent_od} na {pacijent_za}. "
                          f"Fizički saldo nije promijenjen; komisijsko pravo nije preneseno. Razlog: {razlog}"),
                )
            messages.success(request, "Rezervisane doze su premještene.")
            return redirect("profil_pacijenta", pacijent_id=pacijent_od.id)

    return render(request, "dashboard/premjesti_doze.html", {
        "pacijent_od": pacijent_od,
        "izvorni_lijek": lijek,
        "dostupno": dostupno,
        "pacijenti": pacijenti,
    })

@login_required
def novo_trebovanje(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    lijek = pacijent.lijek

    if not lijek:
        messages.error(request, "Pacijent nema dodijeljen lijek.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)

    status_pacijenta = izracunaj_status_pacijenta(pacijent)
    trenutno_doza = status_pacijenta["kod_pacijenta"]
    planirati_doza = status_pacijenta["potrebe_komisije"]["ukupno_potrebno"] or Decimal("6")
    predlozeni_broj_doza = max(status_pacijenta["za_novu_komisiju"], Decimal("1"))

    if request.method == "POST":
        broj_doza = Decimal(str(request.POST.get("broj_doza", predlozeni_broj_doza)))
        try:
            validate_package_multiple(broj_doza, lijek, label="Tražena količina")
        except ValueError as exc:
            messages.error(request, str(exc))
            return redirect("novo_trebovanje", pacijent_id=pacijent.id)

        trebovanje = Trebovanje.objects.create(
            pacijent=pacijent,
            lijek=lijek,
            broj_doza=broj_doza,
            status="U_PRIPREMI",
            napomena=f"Ručno potvrđeno trebovanje. Trenutno zaduženo: {trenutno_doza} doza.",
            predsjednik_konzilija=request.POST.get("predsjednik_konzilija", "").strip(),
            clan_konzilija_1=request.POST.get("clan_konzilija_1", "").strip(),
            clan_konzilija_2=request.POST.get("clan_konzilija_2", "").strip(),
        )

        upisi_log(
            request.user,
            "Pripremljeno trebovanje",
            pacijent=pacijent,
            objekat=trebovanje,
            opis=f"{lijek.naziv} - pripremljeno trebovanje za {broj_doza} doza."
        )

        messages.success(request, f"Trebovanje pripremljeno: {broj_doza} doza.")
        return redirect("profil_pacijenta", pacijent_id=pacijent.id)
    
    ljekari = Ljekar.objects.filter(aktivan=True).order_by("ime_prezime")

    return render(request, "dashboard/novo_trebovanje.html", {
        "pacijent": pacijent,
        "lijek": lijek,
        "trenutno_doza": trenutno_doza,
        "predlozeni_broj_doza": predlozeni_broj_doza,
        "ljekari": ljekari,
    })

@login_required
def promijeni_status_trebovanja(request, trebovanje_id, status):
    trebovanje = get_object_or_404(Trebovanje, id=trebovanje_id)

    dozvoljeni_statusi = [
        "PREDATO",
        "ODOBRENO",
        "ZAPRIMLJENO",
        "ODBIJENO",
    ]

    if status not in dozvoljeni_statusi:
        messages.error(request, "Neispravan status trebovanja.")
        return redirect("profil_pacijenta", pacijent_id=trebovanje.pacijent.id)

    if status == "ZAPRIMLJENO":
        if trebovanje.zaduzenje_kreirano:
            messages.warning(
                request,
                "Lijek je već zaprimljen i zadužen za ovog pacijenta. Dupli unos je spriječen."
            )
            return redirect("profil_pacijenta", pacijent_id=trebovanje.pacijent.id)

        broj_doza = Decimal(str(trebovanje.broj_doza or 0))
        if broj_doza <= 0:
            messages.error(request, "Broj doza na trebovanju mora biti veći od nule.")
            return redirect("profil_pacijenta", pacijent_id=trebovanje.pacijent.id)
        try:
            validate_package_multiple(
                broj_doza,
                trebovanje.lijek,
                label="Zaprimljena količina",
            )
        except ValueError as exc:
            messages.error(request, str(exc))
            return redirect("profil_pacijenta", pacijent_id=trebovanje.pacijent.id)

        with transaction.atomic():
            _zaliha, fizicka_transakcija = promijeni_zalihu(
                lijek=trebovanje.lijek,
                kolicina=broj_doza,
                korisnik=request.user,
                pacijent=trebovanje.pacijent,
                referenca=trebovanje,
                akcija="Zaprimanje lijeka",
                opis=f"{trebovanje.lijek.naziv}: zaprimljeno {broj_doza} doza u frižider.",
                frizider_delta=broj_doza,
                tip_transakcije=ZalihaTransakcija.TIP_ZAPRIMANJE,
                vrati_transakciju=True,
            )
            cover_pending_physical_needs(
                lijek=trebovanje.lijek,
                user=request.user,
            )
            aktivna_komisija = trebovanje.pacijent.vazece_komisije(lijek=trebovanje.lijek).first()
            rezervisi_doze_za_pacijenta(
                pacijent=trebovanje.pacijent,
                lijek=trebovanje.lijek,
                broj_doza=broj_doza,
                komisija=aktivna_komisija,
                trebovanje=trebovanje,
                korisnik=request.user,
                napomena="Rezervisano kroz rucno zaprimanje trebovanja.",
                fizicka_transakcija=fizicka_transakcija,
            )

            trebovanje.status = status
            trebovanje.zaduzenje_kreirano = True
            if not trebovanje.napomena:
                trebovanje.napomena = "Ručno potvrđeno: lijek zaprimljen u frižider."
            elif "zaprimljen u frižider" not in trebovanje.napomena:
                trebovanje.napomena = (
                    f"{trebovanje.napomena}\n"
                    "Ručno potvrđeno: lijek zaprimljen u frižider."
                )
            trebovanje.save(update_fields=["status", "zaduzenje_kreirano", "napomena"])

            upisi_log(
                request.user,
                "Ručno potvrđen dolazak lijeka",
                pacijent=trebovanje.pacijent,
                objekat=trebovanje,
                opis=(
                    f"{trebovanje.lijek.naziv}: ručno potvrđeno {broj_doza} doza. "
                    "Fizički saldo je povećan; postojeće potrebe su pokrivene "
                    "po prioritetu, a ostatak je alociran ovom zahtjevu samo "
                    "do raspoložive količine."
                )
            )
    else:
        trebovanje.status = status
        trebovanje.save(update_fields=["status"])

    upisi_log(
        request.user,
        "Promjena statusa trebovanja",
        pacijent=trebovanje.pacijent,
        objekat=trebovanje,
        opis=f"{trebovanje.lijek.naziv} - status promijenjen u {trebovanje.get_status_display()}."
    )

    messages.success(request, f"Status trebovanja promijenjen: {trebovanje.get_status_display()}")

    return redirect("profil_pacijenta", pacijent_id=trebovanje.pacijent.id)

@login_required
def print_zahtjev_zavodu(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)

    zadnje_trebovanje = Trebovanje.objects.filter(
        pacijent=pacijent
    ).order_by("-datum_kreiranja").first()

    if zadnje_trebovanje:
        return print_zahtjev_zavodu_trebovanje(request, zadnje_trebovanje.id)

    messages.error(request, "Pacijent nema kreirano trebovanje. Prvo pripremite trebovanje.")
    return redirect("profil_pacijenta", pacijent_id=pacijent.id)

# ============================================================
# THERAFLOW v1.5 - KOMISIJSKI CENTAR
# Ovo je sigurna nadogradnja: stari Alarm centar ostaje funkcionalan,
# a novi link "Komisijski centar" koristi istu postojeću alarm logiku.
# ============================================================

def _commission_summary_identity(medicines):
    """UI identitet komisijske kartice iz konkretnih proizvoda/SKU-ova."""

    unique_medicines = []
    seen = set()
    for medicine in medicines:
        if not medicine:
            continue
        identity = medicine.pk if medicine.pk is not None else id(medicine)
        if identity in seen:
            continue
        seen.add(identity)
        unique_medicines.append(medicine)

    if not unique_medicines:
        return {
            "naziv": "Bez definisanog lijeka",
            "podnaslov": "",
            "proizvod_naziv": "",
        }

    primary = unique_medicines[0]
    brands = []
    for medicine in unique_medicines:
        brand = str(medicine.brand_name or "").strip()
        if brand and brand not in brands:
            brands.append(brand)

    generic = str(medicine_group_label(primary) or "").strip()
    if len(brands) == 1:
        title = brands[0]
        subtitle_parts = []
        if generic and generic.casefold() != title.casefold():
            subtitle_parts.append(generic)
        presentation = " ".join(
            part
            for part in (
                primary.presentation_strength_label,
                primary.put_primjene,
            )
            if part
        )
        if presentation:
            subtitle_parts.append(presentation)
        subtitle = " · ".join(subtitle_parts)
    else:
        title = generic or "Više proizvoda"
        subtitle = " / ".join(brands)

    return {
        "naziv": title,
        "podnaslov": subtitle,
        "proizvod_naziv": primary.prikaz_naziv,
    }


def _apply_commission_cycle_display(rows, cycle_overview):
    """Dodaj jednoznačne, prezentacijske oznake bez promjene planera."""

    current_date = cycle_overview.get("current_date")
    next_date = cycle_overview.get("next_date")
    has_current = cycle_overview.get("has_current_cycle", False)
    for row in rows:
        planned_window = (
            row.get("planirati_za_komisiju")
            or row.get("preporuceni_komisijski_ciklus")
        )
        planned_date = getattr(planned_window, "datum_komisije", None)
        preparation_deadline = getattr(planned_window, "rok_pripreme", None)
        if not planned_date:
            row.update({
                "komisijski_ciklus_uloga": "none",
                "komisijski_ciklus_oznaka": "Trenutno nije potrebna komisija",
                "komisijski_ciklus_datum": None,
                "komisijski_rok_pripreme": None,
            })
            continue

        if has_current and planned_date == current_date:
            role = "current"
            label = "Uključiti u trenutni ciklus"
        elif planned_date == next_date:
            role = "next"
            label = (
                "Uključiti u sljedeći ciklus"
                if has_current
                else "Uključiti u narednu komisiju"
            )
        else:
            role = "planned"
            label = "Uključiti u planirani ciklus"
        row.update({
            "komisijski_ciklus_uloga": role,
            "komisijski_ciklus_oznaka": label,
            "komisijski_ciklus_datum": planned_date,
            "komisijski_rok_pripreme": (
                preparation_deadline
                or row.get("komisiju_pokrenuti_najkasnije")
            ),
        })


def _apply_commission_center_ui(rows):
    """Kompaktne UI oznake izvedene iz kanonskog komisijskog plana."""

    for row in rows:
        included = bool(
            row.get("ukljucen_u_nacrt")
            or row.get("kategorija") == "ukljuciti"
        )
        medicine = row.get("potreban_proizvod") or row.get("lijek")
        system_quantity = Decimal(str(
            row.get("sistem_predlaze", row.get("za_novu_komisiju", 0)) or 0
        ))
        final_quantity = Decimal(str(
            row.get("ljekar_trazi", system_quantity) or 0
        ))
        display_quantity = final_quantity if included else Decimal("0")
        row["ui_final_nabavka"] = procurement_breakdown(
            display_quantity,
            medicine,
        )
        row["ui_quantity_manually_adjusted"] = bool(
            included
            and row.get("rucni_unos")
            and final_quantity != system_quantity
        )

        coverage_calculation = row.get("coverage_calculation")
        if coverage_calculation and coverage_calculation.immediate_risk:
            status_label, status_class = "Rizik prekida terapije", "red"
        elif row.get("za_pregled"):
            status_label, status_class = "Potrebna provjera", "red"
        elif row.get("vanredni_zahtjev_u_toku"):
            status_label, status_class = "Čeka odluku", "amber"
        elif coverage_calculation is not None:
            status_label = coverage_calculation.status_label
            status_class = "blue"
        elif (
            included
            and row.get("oralni_plan")
            and row.get("status_oznaka") == "Potrebno pripremiti zahtjev"
        ):
            # Za oralnu terapiju rok pripreme je operativna poruka, a ne samo
            # tehnička spremnost prijedloga. Sačuvaj je u kompaktnom prikazu.
            status_label, status_class = "Potrebno pripremiti zahtjev", "amber"
        elif included:
            status_label, status_class = "Spremno", "green"
        else:
            status_label, status_class = "Nije potrebno", "gray"
        row["ui_status_label"] = status_label
        row["ui_status_class"] = status_class


def _komisijski_centar_v2_context(aktivni_filter, user):
    commission_schedule = get_commission_schedule()
    cycle_overview = commission_cycle_overview(schedule=commission_schedule)
    rows = commission_planning_rows()
    _apply_commission_cycle_display(rows, cycle_overview)
    reconcile_stale_draft_membership(rows, user=user)
    draft = commission_draft_snapshot(rows=rows)
    for row in rows:
        system_quantity = Decimal(str(row["sistem_predlaze"] or 0))
        reserve_quantity = min(
            Decimal(str(row["sigurnosna_rezerva"] or 0)),
            system_quantity,
        )
        row["prikaz_osnovno"] = system_quantity - reserve_quantity
        row["prikaz_rezerva"] = reserve_quantity
    _apply_commission_center_ui(rows)
    included_rows = draft["included_rows"]
    groups = {
        "ukljuciti": included_rows,
        "pregled": [row for row in rows if row["za_pregled"]],
        "pokriveni": [
            row for row in rows
            if not row["ukljucen_u_nacrt"] and not row["za_pregled"]
        ],
        "rizik_dostave": delivery_risk_rows(rows),
    }
    included = groups["ukljuciti"]
    summary_products = {}
    for row in included_rows:
        key = therapy_group_bucket_key(row["lijek"])
        summary_products.setdefault(key, []).append(
            row.get("potreban_proizvod") or row["lijek"]
        )
    summary = []
    for key, item in draft["groups"].items():
        identity = _commission_summary_identity(
            summary_products.get(key) or [item["lijek"]]
        )
        summary.append({
            **identity,
            "lijek": item["lijek"],
            "za_komisiju": item["final_requested_quantity"],
            "broj_pacijenata": item["patient_count"],
            "nabavka": item["procurement"],
            "broj_pakovanja": item["procurement"]["package_count"],
        })
    return {
        "komisijski_v2": True,
        "aktivni_filter": aktivni_filter,
        "commission_schedule": commission_schedule,
        "commission_cycle_overview": cycle_overview,
        "pacijenti_za_prikaz": groups[aktivni_filter],
        "broj_za_ukljuciti": len(groups["ukljuciti"]),
        "broj_za_pregled": len(groups["pregled"]),
        "broj_spremno_za_potvrdu": sum(
            1 for row in included if row["ui_status_label"] == "Spremno"
        ),
        "broj_pokrivenih": len(groups["pokriveni"]),
        "broj_rizik_dostave": len(groups["rizik_dostave"]),
        "broj_lijekova_za_komisiju": len(summary),
        "ukupno_za_komisiju": draft["total_quantity"],
        "sazetak_po_lijeku": summary,
        "ukupno_pacijenata_u_sazetku": draft["patient_count"],
        "moze_rucni_unos": je_doktor_ili_admin(user),
    }


def _komisijski_centar_context(aktivni_filter="ukljuciti", user=None):
    """Prezentacijski model Komisijskog centra iz kanonskog Commission Service-a."""
    dozvoljeni_filteri = {"ukljuciti", "pregled", "pokriveni"}
    if commission_demand_v2_enabled():
        dozvoljeni_filteri.add("rizik_dostave")
    aktivni_filter = aktivni_filter if aktivni_filter in dozvoljeni_filteri else "ukljuciti"
    if commission_demand_v2_enabled():
        return _komisijski_centar_v2_context(aktivni_filter, user)
    commission_schedule = get_commission_schedule()
    cycle_overview = commission_cycle_overview(schedule=commission_schedule)
    from patients.querysets import with_workflow_data

    pacijenti = list(with_workflow_data(
        Pacijent.objects.filter(aktivan=True, lijek__isnull=False)
        .exclude(pauze_terapije__aktivna=True)
    ).order_by("prezime", "ime", "id"))
    potrebe = commission_needs_by_patient(
        schedule=commission_schedule,
        patients=pacijenti,
    )

    svi_redovi = []
    for pacijent in pacijenti:
        potreba = potrebe[pacijent.pk]
        status_pacijenta = izracunaj_status_pacijenta(pacijent)
        za_komisiju = Decimal(str(potreba["za_novu_komisiju"] or 0))
        status_css = status_pacijenta.get("status_css")

        if za_komisiju > 0:
            kategorija = "ukljuciti"
            if status_css == "status-hitno":
                status_oznaka, status_klasa = "Kritično", "red"
            else:
                status_oznaka, status_klasa = "Za komisiju", "amber"
        elif status_css in {"status-hitno", "status-komisija", "status-neutral"}:
            kategorija = "pregled"
            status_oznaka, status_klasa = "Za pregled", "blue"
        else:
            kategorija = "pokriveni"
            status_oznaka, status_klasa = "Pokriven", "green"

        svi_redovi.append({
            "pacijent": pacijent,
            "lijek": pacijent.lijek,
            "terapija_naziv": pacijent.terapija_za_prikaz,
            "potreban_proizvod": pacijent.lijek,
            "terapijska_faza": status_pacijenta.get("trenutna_faza"),
            "sljedeca_terapija": status_pacijenta.get("sljedeca_terapija"),
            "pokriven_do": status_pacijenta.get("pokriven_do"),
            "status_razlog": status_pacijenta.get("status_razlog"),
            "status_oznaka": status_oznaka,
            "status_klasa": status_klasa,
            "kategorija": kategorija,
            **potreba,
        })

    _apply_commission_cycle_display(svi_redovi, cycle_overview)
    _apply_commission_center_ui(svi_redovi)

    za_ukljuciti = [red for red in svi_redovi if red["kategorija"] == "ukljuciti"]
    za_pregled = [red for red in svi_redovi if red["kategorija"] == "pregled"]
    pokriveni = [red for red in svi_redovi if red["kategorija"] == "pokriveni"]
    redovi_po_filteru = {
        "ukljuciti": za_ukljuciti,
        "pregled": za_pregled,
        "pokriveni": pokriveni,
    }

    sazetak_po_lijeku = {}
    for red in za_ukljuciti:
        grupa = therapy_group_bucket_key(red["lijek"])
        if grupa not in sazetak_po_lijeku:
            sazetak_po_lijeku[grupa] = {
                "lijek": red["lijek"],
                "proizvodi": [],
                "za_komisiju": Decimal("0"),
                "broj_pacijenata": 0,
            }
        sazetak_po_lijeku[grupa]["proizvodi"].append(
            red.get("potreban_proizvod") or red["lijek"]
        )
        sazetak_po_lijeku[grupa]["za_komisiju"] += Decimal(str(red["za_novu_komisiju"] or 0))
        sazetak_po_lijeku[grupa]["broj_pacijenata"] += 1
    for item in sazetak_po_lijeku.values():
        item.update(_commission_summary_identity(item.pop("proizvodi")))
        item["nabavka"] = procurement_breakdown(
            item["za_komisiju"],
            item["lijek"],
        )
        item["za_komisiju"] = item["nabavka"]["rounded_procurement_units"]
        item["broj_pakovanja"] = item["nabavka"]["package_count"]

    return {
        "aktivni_filter": aktivni_filter,
        "commission_schedule": commission_schedule,
        "commission_cycle_overview": cycle_overview,
        "pacijenti_za_prikaz": redovi_po_filteru[aktivni_filter],
        "broj_za_ukljuciti": len(za_ukljuciti),
        "broj_za_pregled": len(za_pregled),
        "broj_spremno_za_potvrdu": sum(
            1 for row in za_ukljuciti if row["ui_status_label"] == "Spremno"
        ),
        "broj_pokrivenih": len(pokriveni),
        "broj_lijekova_za_komisiju": len(sazetak_po_lijeku),
        "ukupno_za_komisiju": sum(
            (Decimal(str(red["za_novu_komisiju"] or 0)) for red in za_ukljuciti),
            Decimal("0"),
        ),
        "sazetak_po_lijeku": list(sazetak_po_lijeku.values()),
        "ukupno_pacijenata_u_sazetku": len(za_ukljuciti),
    }


def _commission_phase2_context(request):
    cycles = list(
        KomisijskiCiklus.objects.annotate(
            phase2_request_count=Count("zahtjevi_faza1", distinct=True)
        ).order_by("-godina", "-mjesec", "-datum_komisije", "-id")
    )
    selected_cycle = None
    requested_cycle_id = request.GET.get("cycle")
    if requested_cycle_id:
        selected_cycle = next(
            (cycle for cycle in cycles if str(cycle.pk) == requested_cycle_id),
            None,
        )
    if selected_cycle is None:
        selected_cycle = next(
            (cycle for cycle in cycles if cycle.phase2_request_count),
            cycles[0] if cycles else None,
        )

    context = {
        "commission_center_tab": "zahtjevi",
        "phase2_cycles": cycles,
        "phase2_cycle": selected_cycle,
        "phase2_categories": [],
        "phase2_selected_rows": [],
        "phase2_total": 0,
        "phase2_ready": 0,
        "phase2_errors": [],
        "phase2_can_manage": je_doktor_ili_admin(request.user),
        "phase2_generation": None,
        "phase2_cycle_title": "",
        "phase2_cycle_internal_id": "",
        "phase2_cycle_workflow_status": None,
    }
    if selected_cycle is None:
        return context

    grouped = grouped_cycle_requests(
        selected_cycle,
        request.GET.get("category"),
    )
    errors = validate_cycle_for_print(selected_cycle)
    generation = request.session.get("commission_phase2_generation")
    if generation and generation.get("cycle_id") != selected_cycle.pk:
        generation = None
    context.update(
        {
            "phase2_categories": grouped["categories"],
            "phase2_selected_category": grouped["selected_category"],
            "phase2_selected_rows": grouped["selected_rows"],
            "phase2_total": len(grouped["requests"]),
            "phase2_ready": len(grouped["requests"]) - len(errors),
            "phase2_errors": errors,
            "phase2_generation": generation,
            "phase2_cycle_title": cycle_display_title(selected_cycle),
            "phase2_cycle_internal_id": selected_cycle.naziv,
            "phase2_cycle_workflow_status": cycle_workflow_status(
                selected_cycle,
                grouped["requests"],
            ),
        }
    )
    return context


PHASE3_STATUS_FILTERS = (
    ("sve", "Sve"),
    ("ceka", "Čeka saglasnost"),
    (KomisijskaSaglasnost.Odluka.ODOBRENO, "Odobreno"),
    (
        KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
        "Djelimično odobreno",
    ),
    (KomisijskaSaglasnost.Odluka.ODBIJENO, "Odbijeno"),
)


def _commission_phase3_context(
    request,
    *,
    bound_form=None,
    bound_request_id=None,
):
    cycles = list(
        KomisijskiCiklus.objects.annotate(
            phase3_request_count=Count("zahtjevi_faza1", distinct=True)
        ).order_by("-godina", "-mjesec", "-datum_komisije", "-id")
    )
    requested_cycle_id = request.GET.get("cycle") or request.POST.get("cycle")
    selected_cycle = next(
        (cycle for cycle in cycles if str(cycle.pk) == str(requested_cycle_id)),
        None,
    )
    if selected_cycle is None:
        selected_cycle = next(
            (cycle for cycle in cycles if cycle.phase3_request_count),
            cycles[0] if cycles else None,
        )

    context = {
        "commission_center_tab": "saglasnosti",
        "phase3_cycles": cycles,
        "phase3_cycle": selected_cycle,
        "phase3_rows": [],
        "phase3_progress": {
            "total": 0,
            "entered": 0,
            "waiting": 0,
            "approved": 0,
            "partial": 0,
            "rejected": 0,
            "status_label": "Čeka saglasnosti",
        },
        "phase3_status_filters": [],
        "phase3_category_filters": [],
        "phase3_selected_status": "sve",
        "phase3_selected_category": "sve",
        "phase3_can_manage": je_doktor_ili_admin(request.user),
        "phase3_cycle_title": "",
        "phase3_cycle_internal_id": "",
        "phase2_total": 0,
    }
    if selected_cycle is None:
        return context

    status_filter = (
        request.GET.get("status")
        or request.POST.get("return_status")
        or "sve"
    )
    valid_statuses = {key for key, _label in PHASE3_STATUS_FILTERS}
    if status_filter not in valid_statuses:
        status_filter = "sve"
    category_filter = (
        request.GET.get("category")
        or request.POST.get("return_category")
        or "sve"
    )
    if category_filter != "sve" and category_filter not in CATEGORY_SPECS:
        category_filter = "sve"

    requests = (
        KomisijskiZahtjev.objects.filter(komisijski_ciklus=selected_cycle)
        .select_related(
            "pacijent",
            "prethodni_lijek",
            "novi_lijek",
            "saglasnost",
        )
        .prefetch_related("stavke_lijeka__lijek")
        .order_by("pacijent__prezime", "pacijent__ime", "pk")
    )
    progress = agreement_progress(selected_cycle)
    if status_filter == "ceka":
        requests = requests.filter(saglasnost__isnull=True)
    elif status_filter != "sve":
        requests = requests.filter(saglasnost__odluka=status_filter)
    if category_filter != "sve":
        requests = requests.filter(vrsta_zahtjeva=category_filter)

    rows = []
    for commission_request in requests:
        agreement = getattr(commission_request, "saglasnost", None)
        form_id = f"phase3-agreement-{commission_request.pk}"
        if (
            bound_form is not None
            and bound_request_id == commission_request.pk
        ):
            form = bound_form
        else:
            form = KomisijskaSaglasnostPhase3Form(
                instance=agreement,
                commission_request=commission_request,
                prefix=f"saglasnost-{commission_request.pk}",
                form_id=form_id,
            )
        item_rows = []
        for item in commission_request.stavke_lijeka.all():
            item_rows.append(
                {
                    "item": item,
                    "approved_field": form[f"odobreno_{item.pk}"],
                }
            )
        display = request_row(commission_request)
        rows.append(
            {
                "request": commission_request,
                "agreement": agreement,
                "form": form,
                "form_id": form_id,
                "items": item_rows,
                "medicine_label": display["medicine_label"],
                "requested_lines": display["item_lines"],
            }
        )

    status_counts = {
        "sve": progress["total"],
        "ceka": progress["waiting"],
        KomisijskaSaglasnost.Odluka.ODOBRENO: progress["approved"],
        KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO: progress["partial"],
        KomisijskaSaglasnost.Odluka.ODBIJENO: progress["rejected"],
    }
    category_counts = dict(
        KomisijskiZahtjev.objects.filter(komisijski_ciklus=selected_cycle)
        .values_list("vrsta_zahtjeva")
        .annotate(total=Count("id"))
    )
    context.update(
        {
            "phase3_rows": rows,
            "phase3_progress": progress,
            "phase3_status_filters": [
                {
                    "key": key,
                    "label": label,
                    "count": status_counts[key],
                    "active": key == status_filter,
                }
                for key, label in PHASE3_STATUS_FILTERS
            ],
            "phase3_category_filters": [
                {
                    "key": "sve",
                    "label": "Sve vrste",
                    "count": progress["total"],
                    "active": category_filter == "sve",
                },
                *[
                    {
                        "key": key,
                        "label": spec["short_label"],
                        "count": category_counts.get(key, 0),
                        "active": category_filter == key,
                    }
                    for key, spec in CATEGORY_SPECS.items()
                ],
            ],
            "phase3_selected_status": status_filter,
            "phase3_selected_category": category_filter,
            "phase3_cycle_title": cycle_display_title(selected_cycle),
            "phase3_cycle_internal_id": selected_cycle.naziv,
            "phase2_total": progress["total"],
        }
    )
    return context


@login_required
def komisijski_centar(request):
    if request.GET.get("view") == "zahtjevi":
        return render(
            request,
            "dashboard/komisijski_centar.html",
            _commission_phase2_context(request),
        )
    if request.GET.get("view") == "saglasnosti":
        return render(
            request,
            "dashboard/komisijski_centar.html",
            _commission_phase3_context(request),
        )

    context = _komisijski_centar_context(
        request.GET.get("filter", "ukljuciti"),
        request.user,
    )
    active_extraordinary = extraordinary_requests(active_only=True)
    active_status_counts = dict(
        active_extraordinary.order_by()
        .values("status")
        .annotate(total=Count("id"))
        .values_list("status", "total")
    )
    status_labels = (
        (Trebovanje.STATUS_NACRT, "nacrt"),
        (Trebovanje.STATUS_SPREMAN, "spremno za predaju"),
        (Trebovanje.STATUS_POSLAN_KOMISIJI, "čeka odluku"),
        ("ODOBRENO", "odobreno"),
        (Trebovanje.STATUS_DJELOMICNO_ODOBRENO, "djelimično odobreno"),
        (Trebovanje.STATUS_CEKA_ISPORUKU, "čeka isporuku"),
    )
    active_count = sum(active_status_counts.values())
    context.update({
        "aktivni_vanredni_zahtjevi": active_extraordinary[:3],
        "broj_aktivnih_vanrednih": active_count,
        "broj_preostalih_vanrednih": max(active_count - 3, 0),
        "vanredni_status_sazetak": [
            {
                "status": status,
                "label": label,
                "broj": active_status_counts[status],
            }
            for status, label in status_labels
            if active_status_counts.get(status)
        ],
    })
    context.update({
        "commission_center_tab": "planiranje",
        "phase2_total": KomisijskiZahtjev.objects.count(),
    })
    return render(request, "dashboard/komisijski_centar.html", context)


@login_required
@user_passes_test(je_doktor_ili_admin)
def komisijski_zahtjev_phase2_uredi(request, ciklus_id, zahtjev_id):
    cycle = get_object_or_404(KomisijskiCiklus, pk=ciklus_id)
    commission_request = get_object_or_404(
        KomisijskiZahtjev.objects.select_related(
            "pacijent", "prethodni_lijek", "novi_lijek"
        ),
        pk=zahtjev_id,
        komisijski_ciklus=cycle,
    )
    if request.method == "POST":
        form = KomisijskiZahtjevPhase2Form(
            request.POST,
            instance=commission_request,
            prefix="request",
        )
        item_formset = KomisijskaStavkaLijekaPhase2FormSet(
            request.POST,
            instance=commission_request,
            prefix="items",
        )
        if form.is_valid() and item_formset.is_valid():
            with transaction.atomic():
                saved_request = form.save(commit=False)
                previous_type = commission_request.vrsta_zahtjeva
                saved_request.vrsta_zahtjeva = previous_type
                changed_type = apply_manual_request_type_decision(
                    saved_request,
                    legacy_request_type=form.cleaned_data["vrsta_zahtjeva"],
                    reason=form.cleaned_data.get("request_type_override_reason", ""),
                    user=request.user,
                )
                saved_request.potvrdio_korisnik = request.user
                clear_print_snapshot(saved_request)
                saved_request.save()
                item_formset.instance = saved_request
                item_formset.save()
                upisi_log(
                    request.user,
                    "Uređen komisijski zahtjev",
                    pacijent=saved_request.pacijent,
                    objekat=saved_request,
                    opis=(
                        f"{cycle.naziv}; sistemski prijedlog "
                        f"{saved_request.system_suggested_purpose or '-'}; "
                        f"prije {previous_type}; konačno {saved_request.vrsta_zahtjeva}; "
                        f"ručna izmjena {changed_type}; razlog "
                        f"{saved_request.request_type_override_reason or '-'}; "
                        "snapshot za sljedeću generaciju je osvježen."
                    ),
                )
            messages.success(request, "Komisijski zahtjev je sačuvan.")
            return redirect(
                f"{reverse('komisijski_centar')}?view=zahtjevi&cycle={cycle.pk}"
                f"&category={saved_request.vrsta_zahtjeva}"
            )
    else:
        form = KomisijskiZahtjevPhase2Form(
            instance=commission_request,
            prefix="request",
        )
        item_formset = KomisijskaStavkaLijekaPhase2FormSet(
            instance=commission_request,
            prefix="items",
        )
    return render(
        request,
        "dashboard/komisijski_zahtjev_phase2_form.html",
        {
            "cycle": cycle,
            "commission_request": commission_request,
            "form": form,
            "item_formset": item_formset,
        },
    )


@login_required
@user_passes_test(je_doktor_ili_admin)
@require_POST
def generisi_komisijske_zahtjeve_phase2(request, ciklus_id):
    cycle = get_object_or_404(KomisijskiCiklus, pk=ciklus_id)
    if not cycle.zahtjevi_faza1.exists():
        messages.warning(
            request,
            "U ovaj komisijski ciklus još nije uključen nijedan zahtjev.",
        )
        return redirect(
            f"{reverse('komisijski_centar')}?view=zahtjevi&cycle={cycle.pk}#print-preview"
        )
    result = generate_cycle_category_pdfs(cycle, request.user)
    if result["errors"]:
        messages.error(
            request,
            f"{len(result['errors'])} zahtjeva nije spremno za štampu.",
        )
    else:
        if cycle.status in {"nacrt", "SIMULACIJA"}:
            cycle.status = "spremno_za_stampu"
            cycle.save(update_fields=("status", "updated_at"))
        request.session["commission_phase2_generation"] = {
            "cycle_id": cycle.pk,
            "generation_id": result["generation_id"],
            "generated_at": result["generated_at"].isoformat(),
            "files": [
                {
                    "category": item["category"],
                    "label": item["label"],
                    "filename": item["filename"],
                    "count": item["count"],
                }
                for item in result["files"]
            ],
        }
        messages.success(
            request,
            f"Generisano je {len(result['files'])} PDF dokumenata po kategorijama.",
        )
    return redirect(
        f"{reverse('komisijski_centar')}?view=zahtjevi&cycle={cycle.pk}#print-preview"
    )


@login_required
@user_passes_test(je_doktor_ili_admin)
def zbirni_spisak_komisije_phase2(request, ciklus_id):
    cycle = get_object_or_404(KomisijskiCiklus, pk=ciklus_id)
    if not cycle.zahtjevi_faza1.exists():
        messages.warning(
            request,
            "U ovaj komisijski ciklus još nije uključen nijedan zahtjev.",
        )
        return redirect(
            f"{reverse('komisijski_centar')}?view=zahtjevi&cycle={cycle.pk}#print-preview"
        )
    result = generate_cycle_summary_pdf(cycle, request.user)
    if result["errors"]:
        messages.error(
            request,
            f"{len(result['errors'])} zahtjeva nije spremno za štampu.",
        )
        return redirect(
            f"{reverse('komisijski_centar')}?view=zahtjevi&cycle={cycle.pk}#print-preview"
        )
    return FileResponse(
        open(result["path"], "rb"),
        as_attachment=False,
        filename="Zbirni_spisak_komisije.pdf",
        content_type="application/pdf",
    )


@login_required
def komisijski_phase2_pdf(request, ciklus_id, generation_id, filename):
    get_object_or_404(KomisijskiCiklus, pk=ciklus_id)
    path = resolve_generated_file(ciklus_id, generation_id, filename)
    if path is None:
        raise Http404("Generisani PDF nije pronađen.")
    return FileResponse(
        open(path, "rb"),
        as_attachment=False,
        filename=filename,
        content_type="application/pdf",
    )


@login_required
@user_passes_test(je_doktor_ili_admin)
@require_POST
def oznaci_komisijski_ciklus_odstampan_phase2(request, ciklus_id):
    cycle = get_object_or_404(KomisijskiCiklus, pk=ciklus_id)
    if not cycle.zahtjevi_faza1.exists():
        messages.warning(
            request,
            "Ciklus bez zahtjeva nije moguće označiti kao odštampan.",
        )
        return redirect(
            f"{reverse('komisijski_centar')}?view=zahtjevi&cycle={cycle.pk}#print-preview"
        )
    cycle.status = "odstampano"
    cycle.save(update_fields=("status", "updated_at"))
    upisi_log(
        request.user,
        "Komisijski dokumenti označeni kao odštampani",
        objekat=cycle,
        opis=cycle.naziv,
    )
    messages.success(request, "Dokumenti su označeni kao odštampani.")
    return redirect(
        f"{reverse('komisijski_centar')}?view=zahtjevi&cycle={cycle.pk}#print-preview"
    )


@login_required
@user_passes_test(je_doktor_ili_admin)
@require_POST
def oznaci_komisijski_ciklus_poslan_phase2(request, ciklus_id):
    cycle = get_object_or_404(KomisijskiCiklus, pk=ciklus_id)
    if not cycle.zahtjevi_faza1.exists():
        messages.warning(
            request,
            "Ciklus bez zahtjeva nije moguće označiti kao poslan komisiji.",
        )
        return redirect(
            f"{reverse('komisijski_centar')}?view=zahtjevi&cycle={cycle.pk}#print-preview"
        )
    cycle.status = "poslano_komisiji"
    cycle.datum_slanja = timezone.localdate()
    cycle.save(update_fields=("status", "datum_slanja", "updated_at"))
    upisi_log(
        request.user,
        "Komisijski ciklus označen kao poslan komisiji",
        objekat=cycle,
        opis=f"{cycle.naziv}; datum slanja {cycle.datum_slanja:%d/%m/%Y}.",
    )
    messages.success(request, "Komisijski ciklus je označen kao poslan.")
    return redirect(
        f"{reverse('komisijski_centar')}?view=zahtjevi&cycle={cycle.pk}#print-preview"
    )


@login_required
@user_passes_test(je_doktor_ili_admin)
@require_POST
def sacuvaj_komisijsku_saglasnost_phase3(request, ciklus_id, zahtjev_id):
    cycle = get_object_or_404(KomisijskiCiklus, pk=ciklus_id)
    commission_request = get_object_or_404(
        KomisijskiZahtjev.objects.prefetch_related("stavke_lijeka__lijek"),
        pk=zahtjev_id,
        komisijski_ciklus=cycle,
    )
    agreement = getattr(commission_request, "saglasnost", None)
    form_id = f"phase3-agreement-{commission_request.pk}"
    form = KomisijskaSaglasnostPhase3Form(
        request.POST,
        instance=agreement,
        commission_request=commission_request,
        prefix=f"saglasnost-{commission_request.pk}",
        form_id=form_id,
    )
    if form.is_valid():
        try:
            save_commission_agreement(
                commission_request=commission_request,
                agreement_number=form.cleaned_data.get("broj_saglasnosti"),
                agreement_date=form.cleaned_data["datum_saglasnosti"],
                decision=form.cleaned_data["odluka"],
                approved_quantities=form.normalized_quantities,
                note=form.cleaned_data.get("napomena", ""),
                user=request.user,
            )
        except ValidationError as exc:
            form.add_error(None, exc)
        else:
            messages.success(
                request,
                f"Saglasnost za {commission_request.pacijent} je sačuvana.",
            )
            status_filter = request.POST.get("return_status", "sve")
            category_filter = request.POST.get("return_category", "sve")
            return redirect(
                f"{reverse('komisijski_centar')}?view=saglasnosti"
                f"&cycle={cycle.pk}&status={status_filter}"
                f"&category={category_filter}#saglasnost-{commission_request.pk}"
            )

    context = _commission_phase3_context(
        request,
        bound_form=form,
        bound_request_id=commission_request.pk,
    )
    messages.error(request, "Provjerite podatke u označenom redu.")
    return render(request, "dashboard/komisijski_centar.html", context)


@login_required
@user_passes_test(je_doktor_ili_admin)
def pokreni_vanredni_zahtjev(request, pacijent_id):
    pacijent = get_object_or_404(
        Pacijent.objects.select_related("lijek", "terapijski_protokol"),
        pk=pacijent_id,
    )
    if request.method != "POST":
        return redirect("profil_pacijenta", pacijent_id=pacijent.pk)
    try:
        vanredni = create_extraordinary_request(
            pacijent=pacijent,
            quantity=request.POST.get("broj_doza", ""),
            reason=request.POST.get("razlog_vanrednog", ""),
            other_reason=request.POST.get("razlog_objasnjenje", ""),
            note=request.POST.get("kratka_napomena", ""),
            user=request.user,
        )
    except ValidationError as exc:
        messages.error(request, " ".join(exc.messages))
        existing = getattr(exc, "existing_request", None)
        if existing:
            if existing.tip_zahtjeva == Trebovanje.TIP_VANREDNI:
                return redirect(
                    "vanredni_zahtjev_detalj",
                    zahtjev_id=existing.pk,
                )
            return redirect(
                f"{reverse('profil_pacijenta', args=[pacijent.pk])}"
                "?tab=trebovanja#trebovanja"
            )
        return redirect(
            f"{reverse('profil_pacijenta', args=[pacijent.pk])}"
            "?otvori_vanredni=1#pregled"
        )
    messages.success(
        request,
        "Vanredni zahtjev je dodan u Komisijski centar.",
    )
    return redirect(
        f"{reverse('profil_pacijenta', args=[pacijent.pk])}"
        f"?kreiran_vanredni={vanredni.pk}#pregled"
    )


@login_required
def vanredni_zahtjevi(request):
    status_filter = request.GET.get("status", "aktivni")
    queryset = (
        extraordinary_requests(active_only=status_filter == "aktivni")
        if status_filter != "svi"
        else extraordinary_requests()
    )
    return render(request, "dashboard/vanredni_zahtjevi.html", {
        "zahtjevi": queryset,
        "status_filter": status_filter,
        "broj_aktivnih": extraordinary_requests(active_only=True).count(),
    })


@login_required
def vanredni_zahtjev_detalj(request, zahtjev_id):
    vanredni = get_object_or_404(
        extraordinary_requests(),
        pk=zahtjev_id,
    )
    if request.method == "POST":
        if not je_doktor_ili_admin(request.user):
            raise PermissionDenied(
                "Samo administrator, doktor ili koordinator biološke terapije "
                "mogu mijenjati vanredni zahtjev."
            )
        action = request.POST.get("action", "")
        try:
            if action == "save":
                update_extraordinary_request(
                    vanredni,
                    quantity=request.POST.get("broj_doza", ""),
                    reason=request.POST.get("razlog_vanrednog", ""),
                    other_reason=request.POST.get("razlog_objasnjenje", ""),
                    note=request.POST.get("kratka_napomena", ""),
                    user=request.user,
                )
                messages.success(request, "Vanredni zahtjev je sačuvan.")
            elif action == "ready":
                mark_extraordinary_ready(vanredni, user=request.user)
                messages.success(request, "Zahtjev je spreman za predaju.")
            elif action == "send":
                if vanredni.status != Trebovanje.STATUS_SPREMAN:
                    raise ValidationError(
                        "Zahtjev mora biti spreman prije slanja komisiji."
                    )
                mark_requests_sent(
                    Trebovanje.objects.filter(pk=vanredni.pk),
                    user=request.user,
                )
                messages.success(request, "Vanredni zahtjev je označen kao poslan.")
            elif action == "approve":
                if vanredni.status != Trebovanje.STATUS_POSLAN_KOMISIJI:
                    raise ValidationError(
                        "Odobrenje se može evidentirati tek nakon slanja komisiji."
                    )
                datum = datetime.strptime(
                    request.POST.get("datum_odobrenja", ""),
                    "%Y-%m-%d",
                ).date()
                approve_cycle(
                    vanredni.komisijski_ciklus,
                    {
                        vanredni.pk: Decimal(str(
                            request.POST.get("odobrene_doze", "0")
                        ))
                    },
                    datum,
                    user=request.user,
                    approval_number=request.POST.get(
                        "broj_saglasnosti", ""
                    ).strip(),
                )
                messages.success(request, "Odluka komisije je evidentirana.")
            elif action == "wait_delivery":
                mark_cycle_waiting_delivery(
                    vanredni.komisijski_ciklus,
                    user=request.user,
                )
                messages.success(request, "Zahtjev sada čeka isporuku.")
            elif action == "cancel":
                cancel_extraordinary_request(vanredni, user=request.user)
                messages.success(request, "Vanredni zahtjev je otkazan.")
            elif action == "move_regular":
                move_extraordinary_to_regular(vanredni, user=request.user)
                messages.success(
                    request,
                    "Zahtjev je prebačen u redovni komisijski ciklus.",
                )
                return redirect("komisijska_simulacija")
            else:
                raise ValidationError("Nepoznata akcija vanrednog zahtjeva.")
        except (ValidationError, ValueError, ArithmeticError) as exc:
            error_messages = (
                exc.messages if isinstance(exc, ValidationError) else [str(exc)]
            )
            messages.error(request, " ".join(error_messages))
        return redirect("vanredni_zahtjev_detalj", zahtjev_id=vanredni.pk)

    audit_filter = Q(objekat_tip="Trebovanje", objekat_id=vanredni.pk)
    if vanredni.komisijski_ciklus_id:
        audit_filter |= Q(
            objekat_tip="KomisijskiCiklus",
            objekat_id=vanredni.komisijski_ciklus_id,
        )
    if vanredni.komisija_id:
        audit_filter |= Q(
            objekat_tip="Komisija",
            objekat_id=vanredni.komisija_id,
        )
    audit = AktivnostLog.objects.filter(audit_filter).select_related(
        "korisnik"
    ).order_by("-datum_vrijeme", "-id")
    return render(request, "dashboard/vanredni_zahtjev_detalj.html", {
        "zahtjev": vanredni,
        "reason_choices": Trebovanje.RAZLOZI_VANREDNOG,
        "audit": audit,
        "editable": vanredni.status in (
            Trebovanje.STATUS_NACRT,
            Trebovanje.STATUS_SPREMAN,
        ),
        "expected_delivery": (
            expected_delivery_for_cycle(vanredni.komisijski_ciklus)
            if vanredni.komisijski_ciklus_id else None
        ),
        "moze_upravljati": je_doktor_ili_admin(request.user),
    })


@login_required
@user_passes_test(je_doktor_ili_admin)
def sacuvaj_komisijski_rucni_unos(request, pacijent_id):
    if request.method != "POST":
        return redirect("komisijski_centar")
    pacijent = get_object_or_404(Pacijent, id=pacijent_id, aktivan=True)
    row = commission_planning_row_for_patient(pacijent)
    if row is None:
        messages.error(request, "Za pacijenta nije moguće izračunati komisijski plan.")
        return redirect("komisijski_centar")
    try:
        save_commission_manual_override(
            pacijent=pacijent,
            system_quantity=row["sistem_predlaze"],
            manual_quantity=request.POST.get("ljekar_trazi", ""),
            reason=request.POST.get("razlog_odstupanja", ""),
            reason_code=request.POST.get("override_reason", ""),
            user=request.user,
            decision_context=row,
        )
    except ValidationError as exc:
        messages.error(request, " ".join(exc.messages))
    else:
        messages.success(request, "Konačna količina za komisiju je sačuvana.")
    return redirect(f"{reverse('komisijski_centar')}?filter={row['kategorija']}#pacijent-{pacijent.id}")


@login_required
def za_komisiju(request):
    context = _komisijski_centar_context(
        request.GET.get("filter", "ukljuciti"),
        request.user,
    )
    return render(request, "dashboard/komisijski_centar.html", context)


@login_required
def komisijska_simulacija(request):
    komisijski_v2 = commission_demand_v2_enabled()
    planning_rows = commission_planning_rows() if komisijski_v2 else []
    if komisijski_v2:
        reconcile_stale_draft_membership(planning_rows, user=request.user)
    planning_by_patient = {row["pacijent"].pk: row for row in planning_rows}
    prijedlozi_komisije = (
        [row for row in planning_rows if row["ukljucen_u_nacrt"]]
        if komisijski_v2
        else patients_for_next_commission()
    )

    simulacija_ids = request.session.get("simulacija_pacijenti_ids", [])
    simulacija_ids = [int(x) for x in simulacija_ids]

    grupe = {}
    vec_dodani = set()

    def dodaj_stavku(pacijent, lijek, sistem_predlaze=None):
        if not pacijent or not lijek:
            return

        if pacijent.id in vec_dodani:
            return

        vec_dodani.add(pacijent.id)

        # Komisijska simulacija je logistički kontekst. Ustekinumab IV i SC
        # pripadaju istoj terapiji, ali su različiti fizički SKU-ovi.
        lijek_id = therapy_group_bucket_key(lijek)

        if lijek_id not in grupe:
            grupe[lijek_id] = {
                "lijek": lijek,
                "stavke": [],
                "ukupno_pacijenata": 0,
                "ukupno_sistem": 0,
                "ukupno_konacno": 0,
                "ukupno_pakovanja_sistem": 0,
                "ukupno_pakovanja_konacno": 0,
                "konacno_pakovanja_validno": True,
            }

        status_pacijenta = izracunaj_status_pacijenta(pacijent)
        potrebe = status_pacijenta["potrebe_komisije"]
        planning = planning_by_patient.get(pacijent.pk)
        if planning:
            sistem_predlaze = planning["sistem_predlaze"]
            ljekar_trazi = planning["ljekar_trazi"]
            razlog_odstupanja = planning["razlog_odstupanja"]
        else:
            sistem_predlaze = status_pacijenta["za_novu_komisiju"] if sistem_predlaze is None else sistem_predlaze
            ljekar_trazi = sistem_predlaze
            razlog_odstupanja = ""

        obracun_jedinica = (
            planning["obracun_jedinica"].split(" = ", 1)[0]
            if planning and planning["obracun_jedinica"]
            else ""
        )
        reserve_quantity = min(
            Decimal(str(planning["sigurnosna_rezerva"] or 0)),
            Decimal(str(sistem_predlaze or 0)),
        ) if planning else Decimal("0")
        system_procurement = procurement_breakdown(sistem_predlaze, lijek)
        package_size = system_procurement["units_per_package"]
        system_package_count = system_procurement["package_count"]
        final_package_count = complete_package_count(ljekar_trazi, lijek)
        final_procurement = (
            procurement_breakdown(ljekar_trazi, lijek)
            if final_package_count is not None
            else None
        )
        request_classification = classify_commission_request(pacijent)
        grupe[lijek_id]["stavke"].append({
            "pacijent": pacijent,
            "lijek": lijek,
            "terapija_naziv": (
                planning["terapija_naziv"]
                if planning else pacijent.terapija_za_prikaz
            ),
            "potreban_proizvod": (
                planning["potreban_proizvod"] if planning else lijek
            ),
            "protokol": status_pacijenta["plan_terapije"],
            "terapijska_faza": status_pacijenta["trenutna_faza"],
            "sistem_predlaze": sistem_predlaze,
            "ljekar_trazi": ljekar_trazi,
            "razlog_odstupanja": razlog_odstupanja,
            "rucni_unos": planning["rucni_unos"] if planning else None,
            "objasnjenje_red": planning,
            "prikaz_osnovno": Decimal(str(sistem_predlaze or 0)) - reserve_quantity,
            "prikaz_rezerva": reserve_quantity,
            "obracun_jedinica": obracun_jedinica,
            "izracunata_potreba": planning["neto_nedostatak"] if planning else potrebe.get("izracunata_potreba", 0),
            "broj_pakovanja": system_package_count,
            "konacno_pakovanja": final_package_count,
            "sistemska_nabavka": system_procurement,
            "konacna_nabavka": final_procurement,
            "velicina_pakovanja": package_size,
            "poruka_validacije_pakovanja": (
                planning["poruka_validacije_pakovanja"]
                if planning
                else package_multiple_error(lijek, label="Konačna količina")
            ),
            "potrebno_u_periodu": planning["ukupno_potrebno"] if planning else potrebe["ukupno_potrebno"],
            "trenutno_dostupno": planning["vec_pokriveno"] if planning else potrebe["trenutno_dostupno"],
            "za_novu_komisiju": planning["sistem_predlaze"] if planning else potrebe["za_novu_komisiju"],
            "planirani_koraci": potrebe["planirani_koraci"],
            "zadnja_terapija": status_pacijenta["zadnja_terapija"],
            "sljedeca_terapija": status_pacijenta["sljedeca_terapija"],
            "status_pacijenta": status_pacijenta,
            "rizik_dostave": (
                planning["rizik_dostave"] if planning else False
            ),
            "request_classification": request_classification,
            "predlozena_vrsta_zahtjeva": (
                request_classification.legacy_request_type or ""
            ),
            "request_type_label": request_classification.label,
            "request_type_reason": request_classification.reason,
            "request_type_requires_confirmation": (
                request_classification.requires_confirmation
            ),
            "document_package": request_classification.package,
        })

        grupe[lijek_id]["ukupno_pacijenata"] += 1
        grupe[lijek_id]["ukupno_sistem"] += sistem_predlaze
        grupe[lijek_id]["ukupno_konacno"] += ljekar_trazi
        grupe[lijek_id]["ukupno_pakovanja_sistem"] += system_package_count
        if final_package_count is not None:
            grupe[lijek_id]["ukupno_pakovanja_konacno"] += final_package_count
        else:
            grupe[lijek_id]["konacno_pakovanja_validno"] = False

    for prijedlog in prijedlozi_komisije:
        dodaj_stavku(
            prijedlog["pacijent"],
            prijedlog["lijek"],
            prijedlog.get("za_novu_komisiju", prijedlog.get("sistem_predlaze")),
        )

    dodatni_pacijenti = Pacijent.objects.filter(
        id__in=simulacija_ids,
        aktivan=True
    )

    for pacijent in dodatni_pacijenti:
        dodaj_stavku(
            pacijent,
            pacijent.lijek
        )

    for grupa in grupe.values():
        grupa["sistemska_nabavka"] = procurement_breakdown(
            grupa["ukupno_sistem"],
            grupa["lijek"],
        )
        grupa["ukupno_sistem"] = grupa["sistemska_nabavka"][
            "rounded_procurement_units"
        ]
        grupa["ukupno_pakovanja_sistem"] = grupa["sistemska_nabavka"][
            "package_count"
        ]
        if grupa["konacno_pakovanja_validno"]:
            grupa["konacna_nabavka"] = procurement_breakdown(
                grupa["ukupno_konacno"],
                grupa["lijek"],
            )
            grupa["ukupno_pakovanja_konacno"] = grupa["konacna_nabavka"][
                "package_count"
            ]

    simulation_groups = list(grupe.values())
    return render(request, "dashboard/komisijska_simulacija.html", {
        "grupe": simulation_groups,
        "ukupno_pacijenata_prijedloga": sum(
            group["ukupno_pacijenata"] for group in simulation_groups
        ),
        "komisijski_v2": komisijski_v2,
        "moze_rucni_unos": je_doktor_ili_admin(request.user),
        "adaptive_assistant_enabled": bool(
            getattr(settings, "ADAPTIVE_ASSISTANT_ENABLED", False)
        ),
        "adaptive_override_reasons": AdaptiveDecisionRecord.OVERRIDE_REASONS,
        "commission_request_type_choices": (
            KomisijskiZahtjev.VrstaZahtjeva.choices
        ),
    })


@login_required
def komisijsko_zaprimanje(request):
    ciklusi = KomisijskiCiklus.objects.filter(
        status__in=["PREDATO", "ODOBRENO", "CEKA_ISPORUKU", "DJELOMICNO_ZAPRIMLJENO"]
    ).order_by("-datum_predaje", "-datum_kreiranja")

    return render(request, "dashboard/komisijsko_zaprimanje.html", {
        "ciklusi": ciklusi
    })


@login_required
def komisijska_historija(request):
    ciklusi = KomisijskiCiklus.objects.exclude(
        status="SIMULACIJA"
    ).filter(
        tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI,
    ).prefetch_related(
        "zahtjevi_faza1__pacijent",
        "zahtjevi_faza1__stavke_lijeka__lijek",
    ).order_by("-datum_kreiranja")

    trebovanja = Trebovanje.objects.exclude(
        status="U_PRIPREMI"
    ).filter(
        tip_zahtjeva=Trebovanje.TIP_REDOVNI,
    ).order_by("-datum_kreiranja")

    komisije = Komisija.objects.all().order_by("-datum_odobrenja")

    return render(request, "dashboard/komisijska_historija.html", {
        "ciklusi": ciklusi,
        "trebovanja": trebovanja,
        "komisije": komisije,
    })



@login_required
def sacuvaj_simulaciju_trebovanja(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)
    lijek = pacijent.lijek

    if request.method == "POST":
        try:
            broj_doza = Decimal(str(request.POST.get("broj_doza", "0")))
        except Exception:
            messages.error(request, "Tražena količina mora biti ispravan broj.")
            return redirect("komisijska_simulacija")
        if broj_doza <= 0:
            messages.error(
                request,
                "Komisijski zahtjev mora imati količinu veću od nule.",
            )
            return redirect("komisijska_simulacija")
        if commission_demand_v2_enabled():
            planning = commission_planning_row_for_patient(pacijent)
            if (
                planning is None
                or not planning.get("eligible_for_current_cycle")
            ):
                messages.error(
                    request,
                    "Pacijent ne pripada trenutnom komisijskom ciklusu.",
                )
                return redirect("komisijska_simulacija")
        try:
            validate_package_multiple(broj_doza, lijek, label="Tražena količina")
        except ValueError as exc:
            messages.error(request, str(exc))
            return redirect("komisijska_simulacija")

        trebovanje = Trebovanje.objects.create(
            pacijent=pacijent,
            lijek=lijek,
            broj_doza=broj_doza,
            status="U_PRIPREMI",
            napomena="Kreirano iz Komisijski centar → Simulacija."
        )

        upisi_log(
            request.user,
            "Simulacija komisije",
            pacijent=pacijent,
            objekat=trebovanje,
            opis=f"Tražena količina je {broj_doza} doza lijeka {lijek.naziv}."
        )

        messages.success(
            request,
            f"Trebovanje sačuvano: {pacijent.ime} {pacijent.prezime} — {broj_doza} doza."
        )

    return redirect("komisijska_simulacija")

@login_required
def komisijsko_odobrenje(request):
    ciklusi = KomisijskiCiklus.objects.filter(
        status="SIMULACIJA",
        tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI,
    ).order_by("-datum_kreiranja")

    trebovanja = Trebovanje.objects.filter(
        status="U_PRIPREMI",
        tip_zahtjeva=Trebovanje.TIP_REDOVNI,
    ).order_by("-datum_kreiranja")

    return render(request, "dashboard/komisijsko_odobrenje.html", {
        "ciklusi": ciklusi,
        "trebovanja": trebovanja
    })

@login_required
@transaction.atomic
def sacuvaj_cijelu_simulaciju(request):
    if request.method != "POST":
        return redirect("komisijska_simulacija")

    komisijski_v2 = commission_demand_v2_enabled()
    if komisijski_v2 and not je_doktor_ili_admin(request.user):
        messages.error(
            request,
            "Samo administrator, doktor ili koordinator biološke terapije "
            "mogu sačuvati komisijske količine.",
        )
        return redirect("komisijska_simulacija")
    planning_by_patient = (
        {row["pacijent"].pk: row for row in commission_planning_rows()}
        if komisijski_v2
        else {}
    )
    kreirano = 0

    submitted_patient_ids = []
    expected_patient_quantities = {}
    submitted_request_types = {}
    submitted_request_classifications = {}
    submitted_request_type_reasons = {}
    for pacijent in Pacijent.objects.filter(aktivan=True):
        field_name = f"broj_doza_{pacijent.id}"
        if field_name not in request.POST:
            continue
        try:
            submitted_quantity = Decimal(str(request.POST.get(field_name, "0")))
        except Exception:
            messages.error(request, "Tražena količina mora biti ispravan broj.")
            return redirect("komisijska_simulacija")
        planning = planning_by_patient.get(pacijent.pk) if komisijski_v2 else None
        request_classification = classify_commission_request(pacijent)
        request_type_field = f"vrsta_zahtjeva_{pacijent.id}"
        if request_type_field in request.POST:
            request_type = request.POST.get(request_type_field, "").strip()
            valid_request_types = {
                value
                for value, _label in KomisijskiZahtjev.VrstaZahtjeva.choices
            }
            if request_type not in valid_request_types:
                messages.error(
                    request,
                    f"Odaberite vrstu komisijskog zahtjeva za pacijenta {pacijent}.",
                )
                return redirect("komisijska_simulacija")
        else:
            request_type = (
                request_classification.legacy_request_type
                if not request_classification.requires_confirmation
                else None
            ) or legacy_request_type_from_planning(planning)
        selected_program_type, selected_purpose = canonical_from_legacy(request_type)
        request_type_reason = request.POST.get(
            f"razlog_vrste_zahtjeva_{pacijent.id}",
            "",
        ).strip()
        request_type_changed_or_confirmed = (
            request_classification.requires_confirmation
            or request_classification.program_type != selected_program_type
            or request_classification.request_purpose != selected_purpose
        )
        if request_type_changed_or_confirmed and not request_type_reason:
            messages.error(
                request,
                "Razlog je obavezan kada potvrđujete ili mijenjate sistemski "
                f"prijedlog vrste zahtjeva za pacijenta {pacijent}.",
            )
            return redirect("komisijska_simulacija")
        if submitted_quantity < 0 or (
            submitted_quantity == 0
            and request_type
            != KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_ODJAVA
        ):
            messages.error(
                request,
                "Količina 0 dozvoljena je samo za odjavu.",
            )
            return redirect("komisijska_simulacija")
        if not pacijent.lijek:
            messages.error(request, "Pacijent nema odabran lijek.")
            return redirect("komisijska_simulacija")
        if komisijski_v2:
            if planning is None:
                messages.error(
                    request,
                    "Komisijski plan pacijenta više nije dostupan. Osvježite prijedlog.",
                )
                return redirect("komisijska_simulacija")
            if not planning.get("eligible_for_current_cycle"):
                messages.error(
                    request,
                    f"{pacijent} ne pripada trenutnom komisijskom ciklusu.",
                )
                return redirect("komisijska_simulacija")
            reason = request.POST.get(
                f"razlog_odstupanja_{pacijent.id}",
                "",
            ).strip()
            reason_code = request.POST.get(
                f"override_reason_{pacijent.id}",
                "",
            ).strip()
            if (
                submitted_quantity
                != Decimal(str(planning["sistem_predlaze"] or 0))
                and not (reason or reason_code)
            ):
                messages.error(
                    request,
                    "Razlog je obavezan kada konačna količina odstupa od sistemskog prijedloga.",
                )
                return redirect("komisijska_simulacija")
        try:
            validate_package_multiple(
                submitted_quantity,
                pacijent.lijek,
                label="Tražena količina",
            )
        except ValueError as exc:
            messages.error(request, str(exc))
            return redirect("komisijska_simulacija")
        submitted_patient_ids.append(pacijent.pk)
        submitted_request_types[pacijent.pk] = request_type
        submitted_request_classifications[pacijent.pk] = request_classification
        submitted_request_type_reasons[pacijent.pk] = request_type_reason
        if submitted_quantity > 0:
            expected_patient_quantities[
                (pacijent.pk, therapy_group_bucket_key(pacijent.lijek))
            ] = submitted_quantity

    if not submitted_patient_ids:
        messages.error(
            request,
            "Nema pacijenata za trenutni komisijski ciklus.",
        )
        return redirect("komisijska_simulacija")

    planned_cycle_date = next(
        (
            getattr(
                row.get("planirati_za_komisiju")
                or row.get("preporuceni_komisijski_ciklus"),
                "datum_komisije",
                None,
            )
            for row in planning_by_patient.values()
            if row.get("planirati_za_komisiju")
            or row.get("preporuceni_komisijski_ciklus")
        ),
        None,
    )
    ciklus = KomisijskiCiklus.objects.create(
        naziv=generisi_broj_komisijskog_ciklusa(),
        status="SIMULACIJA",
        datum_komisije=planned_cycle_date,
        mjesec=planned_cycle_date.month if planned_cycle_date else None,
        godina=planned_cycle_date.year if planned_cycle_date else None,
    )

    pacijenti = Pacijent.objects.filter(
        aktivan=True,
        pk__in=submitted_patient_ids,
    )

    for pacijent in pacijenti:
        field_name = f"broj_doza_{pacijent.id}"

        if field_name not in request.POST:
            continue

        broj_doza = Decimal(str(request.POST.get(field_name, "0")))

        if broj_doza <= 0 and not komisijski_v2:
            continue

        if not pacijent.lijek:
            continue

        try:
            validate_package_multiple(
                broj_doza,
                pacijent.lijek,
                label="Tražena količina",
            )
        except ValueError as exc:
            ciklus.delete()
            messages.error(request, str(exc))
            return redirect("komisijska_simulacija")

        if komisijski_v2:
            planning = planning_by_patient.get(pacijent.pk)
            if planning is None:
                ciklus.delete()
                messages.error(request, "Komisijski plan pacijenta više nije dostupan. Osvježite prijedlog.")
                return redirect("komisijska_simulacija")
            try:
                save_commission_manual_override(
                    pacijent=pacijent,
                    system_quantity=planning["sistem_predlaze"],
                    manual_quantity=broj_doza,
                    reason=request.POST.get(f"razlog_odstupanja_{pacijent.id}", ""),
                    reason_code=request.POST.get(
                        f"override_reason_{pacijent.id}",
                        "",
                    ),
                    user=request.user,
                    commission_cycle=ciklus,
                    decision_context=planning,
                )
            except ValidationError as exc:
                ciklus.delete()
                messages.error(request, " ".join(exc.messages))
                return redirect("komisijska_simulacija")

        if broj_doza <= 0:
            continue

        trebovanje = (
            Trebovanje.objects.filter(
                pacijent=pacijent,
                lijek=pacijent.lijek,
                status="U_PRIPREMI",
                komisijski_ciklus__isnull=True,
            )
            .order_by("-datum_kreiranja", "-pk")
            .first()
        )
        if trebovanje:
            trebovanje.broj_doza = broj_doza
            trebovanje.sistemski_prijedlog = (
                planning["sistem_predlaze"] if komisijski_v2 else broj_doza
            )
            trebovanje.komisijski_ciklus = ciklus
            trebovanje.napomena = (
                f"Povezano s Komisijski centar → Simulacija ({ciklus.naziv})."
            )
            trebovanje.save(update_fields=[
                "broj_doza",
                "sistemski_prijedlog",
                "komisijski_ciklus",
                "napomena",
            ])
        else:
            trebovanje = Trebovanje.objects.create(
                pacijent=pacijent,
                lijek=pacijent.lijek,
                sistemski_prijedlog=(
                    planning["sistem_predlaze"] if komisijski_v2 else broj_doza
                ),
                broj_doza=broj_doza,
                status="U_PRIPREMI",
                komisijski_ciklus=ciklus,
                napomena=f"Kreirano iz Komisijski centar → Simulacija ({ciklus.naziv})."
            )

        upisi_log(
            request.user,
            "Simulacija komisije",
            pacijent=pacijent,
            objekat=trebovanje,
            opis=f"{ciklus.naziv}: konačno za komisiju {broj_doza} doza lijeka {pacijent.lijek.naziv}."
        )

        kreirano += 1

    try:
        validate_commission_request_snapshot(
            ciklus.trebovanja.select_related("pacijent", "lijek").all(),
            expected_patient_quantities,
        )
    except ValidationError as exc:
        transaction.set_rollback(True)
        messages.error(request, " ".join(exc.messages))
        return redirect("komisijska_simulacija")

    try:
        for pacijent in pacijenti:
            field_name = f"broj_doza_{pacijent.id}"
            if field_name not in request.POST:
                continue
            broj_doza = Decimal(str(request.POST.get(field_name, "0")))
            planning = planning_by_patient.get(pacijent.pk)
            system_quantity = (
                planning["sistem_predlaze"] if planning else broj_doza
            )
            note = request.POST.get(
                f"razlog_odstupanja_{pacijent.id}",
                "",
            ).strip()
            sync_commission_request_from_planning(
                cycle=ciklus,
                patient=pacijent,
                medicine=pacijent.lijek,
                request_type=submitted_request_types[pacijent.pk],
                system_quantity=system_quantity,
                doctor_quantity=broj_doza,
                user=request.user,
                note=note,
                classification=submitted_request_classifications[pacijent.pk],
                request_type_override_reason=(
                    submitted_request_type_reasons[pacijent.pk]
                ),
            )
    except ValidationError as exc:
        transaction.set_rollback(True)
        messages.error(request, " ".join(exc.messages))
        return redirect("komisijska_simulacija")

    request.session["simulacija_pacijenti_ids"] = []
    request.session.modified = True

    messages.success(
        request,
        f"Prijedlog komisije je sačuvan kao {ciklus.naziv}. Kreirano trebovanja: {kreirano}."
    )

    return redirect("komisijsko_odobrenje")

@login_required
def dodaj_u_simulaciju(request, pacijent_id):
    pacijent = get_object_or_404(Pacijent, id=pacijent_id)

    simulacija_ids = request.session.get("simulacija_pacijenti_ids", [])

    if pacijent.id not in simulacija_ids:
        simulacija_ids.append(pacijent.id)

    request.session["simulacija_pacijenti_ids"] = simulacija_ids
    request.session.modified = True

    messages.success(
        request,
        f"{pacijent.ime} {pacijent.prezime} je dodat u simulaciju komisije."
    )

    return redirect("komisijska_simulacija")

def get_postavke_sistema():
    postavke, created = PostavkeSistema.objects.get_or_create(id=1)
    return postavke


def lijek_je_kucna_terapija(pacijent, lijek):
    return bool(
        (
            pacijent
            and getattr(pacijent, "lijek_id", None) == getattr(lijek, "pk", None)
            and pacijent.trenutni_korak_je_kucna_terapija()
        )
        or getattr(lijek, "kucna_terapija", False)
        or getattr(lijek, "kucna_primjena", False)
        or getattr(lijek, "nacin_primjene", "") == Lijek.NACIN_KUCNA_TERAPIJA
    )


def dohvati_zalihu_za_update(lijek):
    return Zaliha.objects.select_for_update().get_or_create(
        lijek=lijek,
        defaults={
            "ukupno": 0,
            "u_frizideru": 0,
            "kod_pacijenata": 0,
            "minimum": 2,
        }
    )[0]


def promijeni_zalihu(
    *,
    lijek,
    kolicina,
    korisnik=None,
    pacijent=None,
    akcija,
    opis,
    frizider_delta=Decimal("0"),
    kod_pacijenata_delta=Decimal("0"),
    tip_transakcije=None,
    komisija=None,
    referenca=None,
    datum=None,
    vrati_transakciju=False,
):
    kolicina = Decimal(str(kolicina or 0))
    frizider_delta = Decimal(str(frizider_delta or 0))
    kod_pacijenata_delta = Decimal(str(kod_pacijenata_delta or 0))
    zaliha = dohvati_zalihu_za_update(lijek)
    prije_frizider = Decimal(str(zaliha.u_frizideru or 0))
    prije_kod_pacijenata = Decimal(str(zaliha.kod_pacijenata or 0))
    zaliha.u_frizideru = prije_frizider + frizider_delta
    zaliha.kod_pacijenata = prije_kod_pacijenata + kod_pacijenata_delta

    if zaliha.u_frizideru < 0:
        raise ValueError(
            f"Nema dovoljno zalihe u frižideru za {lijek.naziv}. "
            f"Dostupno {prije_frizider}, pokušaj skidanja {kolicina}."
        )
    if zaliha.kod_pacijenata < 0:
        raise ValueError(
            f"Nema dovoljno zalihe kod pacijenata za {lijek.naziv}. "
            f"Dostupno {prije_kod_pacijenata}, pokušaj skidanja {kolicina}."
        )

    zaliha.save(update_fields=["u_frizideru", "kod_pacijenata", "ukupno"])
    fizicka_transakcija = None
    if frizider_delta != 0:
        if not tip_transakcije:
            if frizider_delta > 0:
                tip_transakcije = ZalihaTransakcija.TIP_ZAPRIMANJE
            elif kod_pacijenata_delta > 0:
                tip_transakcije = ZalihaTransakcija.TIP_KUCNO_IZDAVANJE
            else:
                tip_transakcije = ZalihaTransakcija.TIP_AMBULANTNA_POTROSNJA
        fizicka_transakcija = ZalihaTransakcija.objects.create(
            lijek=lijek,
            tip=tip_transakcije,
            kolicina=abs(frizider_delta),
            datum=datum or timezone.localdate(),
            pacijent=pacijent,
            komisija=komisija,
            referenca_tip=referenca.__class__.__name__ if referenca is not None else "",
            referenca_id=getattr(referenca, "id", None),
            korisnik=korisnik if getattr(korisnik, "is_authenticated", False) else None,
            lokacija=(
                ZalihaTransakcija.LOKACIJA_FRIZIDER
                if frizider_delta > 0 else ""
            ),
            napomena=opis,
        )
    upisi_log(
        korisnik,
        akcija,
        pacijent=pacijent,
        objekat=zaliha,
        opis=(
            f"{opis} Frižider: {prije_frizider} → {zaliha.u_frizideru}; "
            f"kod pacijenata/kućna terapija: {prije_kod_pacijenata} → {zaliha.kod_pacijenata}."
        )
    )
    if vrati_transakciju:
        return zaliha, fizicka_transakcija
    return zaliha


def rezervisano_u_frizideru_za_pacijenta(pacijent, lijek=None):
    if not pacijent:
        return Decimal("0")
    lijek = lijek or pacijent.lijek
    if not lijek:
        return Decimal("0")
    return inventory_position_for_patient(pacijent)["reserved_in_fridge"]


def rezervisi_doze_za_pacijenta(
    pacijent,
    lijek,
    broj_doza,
    komisija=None,
    trebovanje=None,
    korisnik=None,
    napomena="",
    fizicka_transakcija=None,
):
    broj_doza = Decimal(str(broj_doza or 0))
    if broj_doza <= 0:
        return None
    if trebovanje is not None:
        direct_reference = bool(
            fizicka_transakcija
            and fizicka_transakcija.tip == ZalihaTransakcija.TIP_ZAPRIMANJE
            and fizicka_transakcija.lijek_id == lijek.pk
            and fizicka_transakcija.referenca_tip == "Trebovanje"
            and fizicka_transakcija.referenca_id == trebovanje.pk
        )
        cycle_reference = bool(
            fizicka_transakcija
            and fizicka_transakcija.tip == ZalihaTransakcija.TIP_ZAPRIMANJE
            and fizicka_transakcija.lijek_id == lijek.pk
            and fizicka_transakcija.referenca_tip == "KomisijskiCiklus"
            and fizicka_transakcija.referenca_id == trebovanje.komisijski_ciklus_id
        )
        if not (direct_reference or cycle_reference):
            raise ValueError(
                "Trebovanje samo po sebi nije dokaz fizičkog zaprimanja. "
                "Nedostaje povezana transakcija ulaza u frižider."
            )
    result = reserve_physical_stock(
        pacijent=pacijent,
        lijek=lijek,
        quantity=broj_doza,
        komisija=komisija,
        trebovanje=trebovanje,
        priority_date=(
            getattr(trebovanje, "sljedeca_zakazana_terapija", None)
            if trebovanje else None
        ),
        user=korisnik,
        note=napomena,
    )
    return result["reservation"]


def skini_rezervaciju_pacijenta(pacijent, lijek, broj_doza):
    broj_doza = Decimal(str(broj_doza or 0))
    if broj_doza <= 0:
        return []
    dostupno = rezervisano_u_frizideru_za_pacijenta(pacijent, lijek)
    if dostupno < broj_doza:
        raise ValueError(
            f"Nema dovoljno rezervisanih doza za pacijenta. "
            f"Rezervisano u frizideru za pacijenta: {dostupno} doza; trazeno: {broj_doza} doza."
        )

    preostalo = broj_doza
    promjene = []
    rezervacije = PacijentRezervacija.objects.select_for_update().filter(
        pacijent=pacijent,
        lijek_id__in=equivalent_medicine_ids(lijek),
        aktivno=True,
        kolicina__gt=0,
    ).order_by("datum_rezervacije", "id")
    for rezervacija in rezervacije:
        if preostalo <= 0:
            break
        trenutno = Decimal(str(rezervacija.kolicina or 0))
        skidanje = min(trenutno, preostalo)
        rezervacija.kolicina = trenutno - skidanje
        if rezervacija.kolicina <= 0:
            rezervacija.kolicina = Decimal("0")
            rezervacija.aktivno = False
        rezervacija.save(update_fields=["kolicina", "aktivno"])
        promjene.append((rezervacija, skidanje))
        preostalo -= skidanje

    if preostalo > 0:
        raise ValueError("Rezervacije pacijenta nisu uskladjene sa trazenom kolicinom.")
    return promjene


def dodijeli_doze_pacijentu(pacijent, lijek, broj_doza, komisija=None, korisnik=None):
    broj_doza = Decimal(str(broj_doza or 0))
    if broj_doza <= 0:
        return None

    zaliha = dohvati_zalihu_za_update(lijek)
    u_frizideru = Decimal(str(zaliha.u_frizideru or 0))
    zaduzenje_je_kucno = lijek_je_kucna_terapija(pacijent, lijek)
    if zaduzenje_je_kucno and u_frizideru < broj_doza:
        raise ValueError(
            f"Nema dovoljno zalihe u frižideru za {lijek.naziv}. Dostupno {u_frizideru}, pokušaj dodjele {broj_doza}."
        )

    zaduzenje = PacijentZaduzenje.objects.filter(
        pacijent=pacijent,
        lijek_id__in=equivalent_medicine_ids(lijek),
        komisija=komisija,
        aktivno=True,
    ).order_by("-datum_zaduzenja").first()

    if komisija:
        vec_zaduzeno = sum(
            (
                Decimal(str(z.ukupno_zaduzeno or 0))
                for z in PacijentZaduzenje.objects.select_for_update().filter(
                    pacijent=pacijent,
                    lijek_id__in=equivalent_medicine_ids(lijek),
                    komisija=komisija,
                )
            ),
            Decimal("0"),
        )
        if vec_zaduzeno + broj_doza > Decimal(str(komisija.broj_odobrenih_doza or 0)):
            raise ValueError(
                f"Zaduženje po komisiji {komisija.broj_saglasnosti or komisija.id} "
                "ne smije preći odobrenu količinu."
            )

    if zaduzenje:
        zaduzenje.ukupno_zaduzeno = Decimal(str(zaduzenje.ukupno_zaduzeno or 0)) + broj_doza
        zaduzenje.preostalo = Decimal(str(zaduzenje.preostalo or 0)) + broj_doza
        zaduzenje.save(update_fields=["ukupno_zaduzeno", "preostalo"])
        if zaduzenje_je_kucno:
            promijeni_zalihu(
                lijek=lijek,
                kolicina=broj_doza,
                korisnik=korisnik,
                pacijent=pacijent,
                komisija=komisija,
                akcija="Zaduženje pacijenta - kućna terapija",
                opis=f"{lijek.naziv}: prebačeno {broj_doza} doza iz frižidera kod pacijenta.",
                frizider_delta=-broj_doza,
                kod_pacijenata_delta=broj_doza,
                tip_transakcije=ZalihaTransakcija.TIP_KUCNO_IZDAVANJE,
            )
        else:
            upisi_log(
                korisnik,
                "Zaduženje pacijenta - ambulantna terapija",
                pacijent=pacijent,
                objekat=zaduzenje,
                opis=f"{lijek.naziv}: zaduženo {broj_doza} doza pacijentu. Lijek ostaje u frižideru do potvrde terapije."
            )
        upisi_log(
            korisnik,
            "Dodjela doza pacijentu",
            pacijent=pacijent,
            objekat=zaduzenje,
            opis=f"{lijek.naziv}: dodijeljeno {broj_doza} doza pacijentu."
        )
        return zaduzenje

    zaduzenje = PacijentZaduzenje.objects.create(
        pacijent=pacijent,
        lijek=lijek,
        komisija=komisija,
        ukupno_zaduzeno=broj_doza,
        preostalo=broj_doza,
        aktivno=True,
    )
    if zaduzenje_je_kucno:
        promijeni_zalihu(
            lijek=lijek,
            kolicina=broj_doza,
            korisnik=korisnik,
            pacijent=pacijent,
            komisija=komisija,
            akcija="Zaduženje pacijenta - kućna terapija",
            opis=f"{lijek.naziv}: prebačeno {broj_doza} doza iz frižidera kod pacijenta.",
            frizider_delta=-broj_doza,
            kod_pacijenata_delta=broj_doza,
            tip_transakcije=ZalihaTransakcija.TIP_KUCNO_IZDAVANJE,
        )
    else:
        upisi_log(
            korisnik,
            "Zaduženje pacijenta - ambulantna terapija",
            pacijent=pacijent,
            objekat=zaduzenje,
            opis=f"{lijek.naziv}: zaduženo {broj_doza} doza pacijentu. Lijek ostaje u frižideru do potvrde terapije."
        )
    upisi_log(
        korisnik,
        "Dodjela doza pacijentu",
        pacijent=pacijent,
        objekat=zaduzenje,
        opis=f"{lijek.naziv}: dodijeljeno {broj_doza} doza pacijentu."
    )
    return zaduzenje


@transaction.atomic
def zaprimi_trebovanje_iz_ciklusa(
    trebovanje,
    datum_odobrenja,
    broj_saglasnosti,
    broj_doza,
    povecaj_zalihu=True,
    korisnik=None,
    fizicka_transakcija=None,
):
    broj_doza = Decimal(str(broj_doza or 0))
    from patients.transaction_locking import lock_instance

    trebovanje = lock_instance(Trebovanje, trebovanje.pk)
    pacijent = trebovanje.pacijent
    lijek = trebovanje.lijek
    if Decimal(str(trebovanje.broj_doza or 0)) <= 0:
        raise ValueError(
            "Komisijski zahtjev sa količinom 0 nije moguće zaprimiti."
        )
    odobreno = Decimal(str(trebovanje.odobrene_doze if trebovanje.odobrene_doze is not None else broj_doza))
    vec_zaprimljeno = Decimal(str(trebovanje.zaprimljene_doze or 0))
    if broj_doza <= 0:
        raise ValueError("Zaprimljena količina mora biti veća od nule.")
    validate_package_multiple(broj_doza, lijek, label="Zaprimljena količina")
    if vec_zaprimljeno + broj_doza > odobreno:
        raise ValueError(
            f"Zaprimanje prelazi odobrenu količinu. Odobreno {odobreno}, "
            f"već zaprimljeno {vec_zaprimljeno}."
        )

    komisija = (
        lock_instance(Komisija, trebovanje.komisija_id)
        if trebovanje.komisija_id
        else None
    )
    if komisija is None:
        komisija = Komisija.objects.create(
            pacijent=pacijent,
            lijek=lijek,
            datum_odobrenja=datum_odobrenja,
            broj_odobrenih_doza=odobreno,
            preostale_doze=odobreno,
            status="ODOBRENA",
            broj_saglasnosti="",
            napomena=f"Odobreno kroz komisijski ciklus {trebovanje.komisijski_ciklus}."
        )
        trebovanje.komisija = komisija

    # Agreement versioning must see the previous patient value before the
    # current commission snapshot is updated.
    use_patient_agreement_for_receipt(
        patient=pacijent,
        number=broj_saglasnosti,
        request=trebovanje,
        quantity=broj_doza,
        user=korisnik,
    )
    komisija.status = "AKTIVNA"
    komisija.broj_saglasnosti = broj_saglasnosti
    komisija.save(update_fields=["status", "broj_saglasnosti"])

    if povecaj_zalihu:
        _zaliha, fizicka_transakcija = promijeni_zalihu(
            lijek=lijek,
            kolicina=broj_doza,
            korisnik=korisnik,
            pacijent=pacijent,
            komisija=komisija,
            referenca=trebovanje,
            akcija="Zaprimanje lijeka",
            opis=f"{lijek.naziv}: zaprimljeno {broj_doza} doza u frižider.",
            frizider_delta=broj_doza,
            tip_transakcije=ZalihaTransakcija.TIP_ZAPRIMANJE,
            datum=datum_odobrenja,
            vrati_transakciju=True,
        )
        cover_pending_physical_needs(lijek=lijek, user=korisnik)

    # Raspodjela je obavezna i kada je fizicka zaliha vec povecana zbirno u
    # bulk toku. ``povecaj_zalihu`` smije kontrolisati samo ulaz u frizider.
    rezervisi_doze_za_pacijenta(
        pacijent=pacijent,
        lijek=lijek,
        broj_doza=broj_doza,
        komisija=komisija,
        trebovanje=trebovanje,
        korisnik=korisnik,
        napomena="Rezervisano kroz zaprimanje komisijskog ciklusa.",
        fizicka_transakcija=fizicka_transakcija,
    )

    trebovanje.zaprimljene_doze = vec_zaprimljeno + broj_doza
    if trebovanje.zaprimljene_doze >= odobreno:
        trebovanje.status = "ZAPRIMLJENO"
    elif trebovanje.tip_zahtjeva == Trebovanje.TIP_VANREDNI:
        trebovanje.status = Trebovanje.STATUS_CEKA_ISPORUKU
    else:
        trebovanje.status = "ODOBRENO"
    trebovanje.zaduzenje_kreirano = trebovanje.status == "ZAPRIMLJENO"
    trebovanje.save(update_fields=[
        "komisija", "zaprimljene_doze", "status", "zaduzenje_kreirano"
    ])

    return komisija


def lijek_css_class(lijek):
    return medicine_group_css(lijek)


def grupisi_trebovanja_po_lijeku(trebovanja):
    grupe = {}

    for trebovanje in trebovanja:
        lijek_id = (
            therapy_group_bucket_key(trebovanje.lijek)
            if trebovanje.lijek else THERAPY_GROUP_OSTALI
        )
        if lijek_id not in grupe:
            naziv_grupe = therapy_group_label(trebovanje.lijek)
            if str(lijek_id).startswith(THERAPY_GROUP_OSTALI) and trebovanje.lijek:
                # OSTALI je tehnička grupa za postojeće filtere. Korisniku se
                # uvijek prikazuje stvarni lijek/proizvod, posebno za oralne
                # terapije koje nemaju unaprijed definisanu biološku grupu.
                naziv_grupe = trebovanje.lijek.prikaz_naziv
            grupe[lijek_id] = {
                "lijek": trebovanje.lijek,
                "naziv": naziv_grupe,
                "css": lijek_css_class(trebovanje.lijek),
                "trebovanja": [],
                "preporuceno": Decimal("0"),
                "otvoreno": Decimal("0"),
            }

        broj_doza = Decimal(str(
            trebovanje.odobrene_doze
            if trebovanje.odobrene_doze is not None
            else trebovanje.broj_doza or 0
        ))
        preostalo_za_zaprimanje = max(
            Decimal("0"), broj_doza - Decimal(str(trebovanje.zaprimljene_doze or 0))
        )
        trebovanje.preostalo_za_zaprimanje = preostalo_za_zaprimanje
        trebovanje.preostalo_za_zaprimanje_pakovanja = complete_package_count(
            preostalo_za_zaprimanje,
            trebovanje.lijek,
        )
        trebovanje.preostala_nabavka = procurement_breakdown(
            preostalo_za_zaprimanje,
            trebovanje.lijek,
        )
        grupe[lijek_id]["trebovanja"].append(trebovanje)
        grupe[lijek_id]["preporuceno"] += broj_doza
        if trebovanje.status != "ZAPRIMLJENO":
            grupe[lijek_id]["otvoreno"] += preostalo_za_zaprimanje

    for grupa in grupe.values():
        grupa["velicina_pakovanja"] = package_size_for(grupa["lijek"])
        grupa["preporuceno_pakovanja"] = complete_package_count(
            grupa["preporuceno"],
            grupa["lijek"],
        )
        grupa["otvoreno_pakovanja"] = complete_package_count(
            grupa["otvoreno"],
            grupa["lijek"],
        )
        grupa["preporucena_nabavka"] = procurement_breakdown(
            grupa["preporuceno"],
            grupa["lijek"],
        )
        grupa["otvorena_nabavka"] = procurement_breakdown(
            grupa["otvoreno"],
            grupa["lijek"],
        )
        grupa["poruka_validacije_pakovanja"] = package_multiple_error(
            grupa["lijek"],
            label="Zaprimljena količina",
        )

    redoslijed = {
        "Adalimumab": 1,
        "Vedolizumab": 2,
        "Infliximab": 3,
    }

    return sorted(
        grupe.values(),
        key=lambda grupa: (redoslijed.get(grupa["naziv"], 50), grupa["naziv"])
    )


def napravi_pregled_zaprimanja(trebovanja):
    grupe = []

    for grupa in grupisi_trebovanja_po_lijeku(trebovanja):
        potvrdeno = [
            trebovanje for trebovanje in grupa["trebovanja"]
            if Decimal(str(trebovanje.zaprimljene_doze or 0)) > 0
        ]
        ceka = [
            trebovanje for trebovanje in grupa["trebovanja"]
            if trebovanje.preostalo_za_zaprimanje > 0
        ]
        zaprimljeno = sum(
            (Decimal(str(trebovanje.zaprimljene_doze or 0))
             for trebovanje in grupa["trebovanja"]),
            Decimal("0"),
        )
        preostalo = sum(
            (trebovanje.preostalo_za_zaprimanje for trebovanje in ceka),
            Decimal("0"),
        )

        grupa.update({
            "potvrdeno": potvrdeno,
            "ceka": ceka,
            "zaprimljeno": zaprimljeno,
            "preostalo": preostalo,
        })
        grupe.append(grupa)

    ukupno_zaprimljeno = sum((grupa["zaprimljeno"] for grupa in grupe), Decimal("0"))
    ukupno_preostalo = sum((grupa["preostalo"] for grupa in grupe), Decimal("0"))
    ukupno_potvrdenih = sum((len(grupa["potvrdeno"]) for grupa in grupe), 0)
    ukupno_na_cekanju = sum((len(grupa["ceka"]) for grupa in grupe), 0)

    return {
        "grupe": grupe,
        "ukupno_zaprimljeno": ukupno_zaprimljeno,
        "ukupno_dodijeljeno": ukupno_zaprimljeno,
        "ukupno_preostalo": ukupno_preostalo,
        "ukupno_potvrdenih": ukupno_potvrdenih,
        "ukupno_na_cekanju": ukupno_na_cekanju,
    }


def parse_datum_odobrenja(request, ciklus, *, approval_context=None):
    """Datum iz domene ima prednost; ručni unos je fallback za stare zapise."""

    approval_context = approval_context or resolve_receipt_approval_context(ciklus)
    if approval_context.approval_date:
        return approval_context.approval_date, None

    datum_odobrenja_raw = (request.POST.get("datum_odobrenja") or "").strip()
    if not datum_odobrenja_raw:
        return None, "Unesite datum odobrenja komisije."
    try:
        return datetime.strptime(datum_odobrenja_raw, "%Y-%m-%d").date(), None
    except ValueError:
        return None, "Datum odobrenja nije ispravan."


def _receipt_form_state(request, *, selected_ids=(), field_errors=None):
    quantities = {
        key.removeprefix("broj_doza_"): value
        for key, value in request.POST.items()
        if key.startswith("broj_doza_")
    }
    single_request_id = (request.POST.get("trebovanje_id") or "").strip()
    if single_request_id and "broj_doza" in request.POST:
        quantities[single_request_id] = request.POST.get("broj_doza")
    return {
        "selected_ids": {str(value) for value in selected_ids},
        "quantities": quantities,
        "received_quantities": {
            key.removeprefix("zaprimljeno_lijek_"): value
            for key, value in request.POST.items()
            if key.startswith("zaprimljeno_lijek_")
        },
        "approval_date": (request.POST.get("datum_odobrenja") or "").strip(),
        "agreement_numbers": {
            key.removeprefix("broj_saglasnosti_"): value
            for key, value in request.POST.items()
            if key.startswith("broj_saglasnosti_")
        },
        "field_errors": field_errors or {},
    }


def _render_receipt_cycle(request, ciklus, *, form_state=None, status=200):
    trebovanja = list(
        ciklus.trebovanja.select_related("pacijent", "lijek", "komisija")
        .all()
        .order_by("lijek__naziv", "pacijent__prezime", "pacijent__ime")
    )
    approval_context = resolve_receipt_approval_context(
        ciklus,
        requests=trebovanja,
    )
    default_step = "odobrenje" if ciklus.status == "PREDATO" else "raspodjela"
    step = request.GET.get("step", default_step)
    if step not in ["odobrenje", "raspodjela", "pregled", "potvrda"]:
        step = default_step
    form_state = form_state or {
        "selected_ids": set(),
        "quantities": {},
        "received_quantities": {},
        "approval_date": "",
        "agreement_numbers": {},
        "field_errors": {},
    }
    approval_date_value = (
        approval_context.approval_date.isoformat()
        if approval_context.approval_date
        else form_state["approval_date"]
    )
    groups = grupisi_trebovanja_po_lijeku(trebovanja)
    for group in groups:
        medicine_id = str(group["lijek"].pk)
        group["receipt_value"] = form_state["received_quantities"].get(
            medicine_id,
            group["otvoreno"],
        )
        group["field_error"] = form_state["field_errors"].get(
            f"zaprimljeno_lijek_{medicine_id}",
        )
        for receipt_request in group["trebovanja"]:
            receipt_request.commission_state = resolve_commission_request_state(
                legacy_request=receipt_request,
                medicine_ids=(receipt_request.lijek_id,),
            )
            request_id = str(receipt_request.pk)
            receipt_request.receipt_selected = (
                request_id in form_state["selected_ids"]
            )
            receipt_request.receipt_quantity_value = form_state["quantities"].get(
                request_id,
                receipt_request.preostalo_za_zaprimanje,
            )
            receipt_request.receipt_field_error = form_state["field_errors"].get(
                f"broj_doza_{request_id}",
            )
            agreement = patient_agreement_suggestion(receipt_request.pacijent)
            receipt_request.agreement_current_number = agreement.number
            receipt_request.agreement_valid_from = agreement.valid_from
            receipt_request.agreement_number_value = form_state[
                "agreement_numbers"
            ].get(request_id, agreement.number)
            receipt_request.agreement_field_error = form_state["field_errors"].get(
                f"broj_saglasnosti_{request_id}",
            )
    receipt_date_error = form_state["field_errors"].get("datum_odobrenja")
    if not approval_date_value and not receipt_date_error:
        receipt_date_error = "Unesite datum odobrenja komisije."
    context = {
        "ciklus": ciklus,
        "step": step,
        "trebovanja": trebovanja,
        "grupe_lijekova": groups,
        "pregled_zaprimanja": napravi_pregled_zaprimanja(trebovanja),
        "ocekivana_isporuka": expected_delivery_for_cycle(ciklus),
        "approval_context": approval_context,
        "approval_date_value": approval_date_value,
        "agreement_number_owners": agreement_number_owners(),
        "receipt_form_state": form_state,
        "receipt_date_error": receipt_date_error,
        "receipt_selection_error": form_state["field_errors"].get("selection"),
        "receipt_general_error": form_state["field_errors"].get("general"),
    }
    return render(request, "dashboard/zaprimanje_ciklusa.html", context, status=status)


def azuriraj_status_ciklusa(ciklus, datum_odobrenja, korisnik=None):
    ciklus.datum_odobrenja = datum_odobrenja
    ciklus.save(update_fields=["datum_odobrenja"])
    return complete_cycle(ciklus, user=korisnik)

def _audit_user_access(actor, action, target, description):
    upisi_log(
        actor,
        action,
        objekat=target,
        opis=f"Korisnik: {target.username}. {description}",
    )


@login_required
@user_passes_test(je_koordinator_ili_admin)
def postavke(request):
    return render(request, "dashboard/postavke.html", {
        "profile_role": user_role(request.user),
        "requires_password_change": requires_password_change(request.user),
    })


@login_required
@user_passes_test(je_admin)
def korisnici_pristup(request):
    User = get_user_model()
    users = list(User.objects.prefetch_related("groups").order_by("last_name", "first_name", "username"))
    for user in users:
        user.theraflow_role = user_role(user)
    return render(request, "dashboard/korisnici_pristup.html", {"users": users})


@sensitive_post_parameters("temporary_password", "temporary_password_confirm")
@login_required
@user_passes_test(je_admin)
def dodaj_korisnika(request):
    form = UserCreateForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            User = get_user_model()
            user = User.objects.create_user(
                username=form.cleaned_data["username"],
                password=form.cleaned_data["temporary_password"],
                first_name=form.cleaned_data["first_name"],
                last_name=form.cleaned_data["last_name"],
                is_active=form.cleaned_data["is_active"],
            )
            user, _ = set_user_role(user, form.cleaned_data["role"])
            set_password_change_required(
                user, form.cleaned_data["require_password_change"]
            )
            _audit_user_access(
                request.user,
                "Kreiranje korisnika",
                user,
                f"Uloga: {form.cleaned_data['role']}; aktivan: {'da' if user.is_active else 'ne'}.",
            )
        messages.success(request, "Korisnik je uspješno kreiran.")
        return redirect("korisnici_pristup")
    return render(request, "dashboard/korisnik_form.html", {
        "form": form,
        "page_heading": "Dodaj korisnika",
        "submit_label": "Kreiraj korisnika",
    })


@login_required
@user_passes_test(je_admin)
def uredi_korisnika(request, user_id):
    User = get_user_model()
    target = get_object_or_404(User, pk=user_id)
    form = UserEditForm(request.POST or None, user_instance=target)
    if request.method == "POST" and form.is_valid():
        previous_name = target.get_full_name()
        previous_role = user_role(target)
        try:
            with transaction.atomic():
                target.first_name = form.cleaned_data["first_name"]
                target.last_name = form.cleaned_data["last_name"]
                target.save(update_fields=["first_name", "last_name"])
                target, _ = set_user_role(target, form.cleaned_data["role"])
                if previous_name != target.get_full_name():
                    _audit_user_access(
                        request.user,
                        "Uređivanje korisnika",
                        target,
                        f"Ime i prezime: '{previous_name}' → '{target.get_full_name()}'.",
                    )
                if previous_role != form.cleaned_data["role"]:
                    _audit_user_access(
                        request.user,
                        "Promjena uloge korisnika",
                        target,
                        f"Prethodna uloga: {previous_role}; nova uloga: {form.cleaned_data['role']}.",
                    )
        except ValidationError as exc:
            form.add_error("role", exc)
        else:
            messages.success(request, "Podaci korisnika su sačuvani.")
            return redirect("korisnici_pristup")
    return render(request, "dashboard/korisnik_form.html", {
        "form": form,
        "target_user": target,
        "page_heading": "Uredi korisnika",
        "submit_label": "Sačuvaj izmjene",
    })


@sensitive_post_parameters("temporary_password", "temporary_password_confirm")
@login_required
@user_passes_test(je_admin)
def resetuj_lozinku_korisnika(request, user_id):
    User = get_user_model()
    target = get_object_or_404(User, pk=user_id)
    form = UserPasswordResetForm(request.POST or None, user_instance=target)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            target.set_password(form.cleaned_data["temporary_password"])
            target.save(update_fields=["password"])
            set_password_change_required(target, True)
            removed = invalidate_user_sessions(target)
            _audit_user_access(
                request.user,
                "Resetovanje lozinke korisnika",
                target,
                f"Postavljena privremena lozinka; uklonjeno aktivnih sesija: {removed}. Promjena pri sljedećoj prijavi je obavezna.",
            )
        messages.success(request, "Privremena lozinka je postavljena. Korisnik je odjavljen sa svih uređaja.")
        return redirect("korisnici_pristup")
    return render(request, "dashboard/resetuj_lozinku_korisnika.html", {
        "form": form,
        "target_user": target,
    })


@login_required
@user_passes_test(je_admin)
def promijeni_status_korisnika(request, user_id):
    if request.method != "POST":
        raise PermissionDenied
    User = get_user_model()
    target = get_object_or_404(User, pk=user_id)
    active = request.POST.get("active") == "1"
    try:
        target, previous = set_user_active(target, active)
    except ValidationError as exc:
        messages.error(request, exc.messages[0])
        return redirect("korisnici_pristup")
    _audit_user_access(
        request.user,
        "Aktivacija korisnika" if active else "Deaktivacija korisnika",
        target,
        f"Prethodni status: {'aktivan' if previous else 'neaktivan'}; novi status: {'aktivan' if active else 'neaktivan'}.",
    )
    if target.pk == request.user.pk and not active:
        logout(request)
        return redirect("login")
    messages.success(request, "Status korisnika je promijenjen.")
    return redirect("korisnici_pristup")


@login_required
@user_passes_test(je_admin)
def odjavi_sve_sesije_korisnika(request, user_id):
    if request.method != "POST":
        raise PermissionDenied
    User = get_user_model()
    target = get_object_or_404(User, pk=user_id)
    removed = invalidate_user_sessions(target)
    _audit_user_access(
        request.user,
        "Odjava korisnika sa svih sesija",
        target,
        f"Uklonjeno aktivnih sesija: {removed}.",
    )
    if target.pk == request.user.pk:
        logout(request)
        return redirect("login")
    messages.success(request, "Korisnik je odjavljen sa svih aktivnih sesija.")
    return redirect("korisnici_pristup")


@sensitive_post_parameters()
@login_required
def promijeni_vlastitu_lozinku(request):
    forced = requires_password_change(request.user)
    form = PasswordChangeForm(request.user, request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        update_session_auth_hash(request, user)
        set_password_change_required(user, False)
        _audit_user_access(
            user,
            "Promjena vlastite lozinke",
            user,
            "Lozinka je promijenjena; sadržaj lozinke nije evidentiran.",
        )
        messages.success(request, "Lozinka je uspješno promijenjena.")
        return redirect("dashboard")
    return render(request, "dashboard/promijeni_vlastitu_lozinku.html", {
        "form": form,
        "forced": forced,
    })


@login_required
@user_passes_test(je_admin)
def postavke_sistema(request):
    postavke = get_postavke_sistema()

    if request.method == "POST":
        postavke.komisijski_ciklus_mjeseci = max(
            1, int(request.POST.get("komisijski_ciklus_mjeseci", 2))
        )
        postavke.priprema_zahtjeva_radnih_dana = max(
            0, int(request.POST.get("priprema_zahtjeva_radnih_dana", 5))
        )
        postavke.vrijeme_isporuke_dana = min(
            20,
            max(15, int(request.POST.get("vrijeme_isporuke_dana", 18))),
        )
        postavke.prosjecno_trajanje_odobrenja_komisije_dana = max(
            0,
            int(request.POST.get("prosjecno_trajanje_odobrenja_komisije_dana", 14)),
        )
        postavke.sigurnosna_rezerva_dana = max(
            0, int(request.POST.get("sigurnosna_rezerva_dana", 14))
        )
        previous_confirmed_date = postavke.potvrdjeni_datum_naredne_komisije
        confirmed_raw = request.POST.get("potvrdjeni_datum_naredne_komisije", "").strip()
        confirmed_date = datetime.strptime(confirmed_raw, "%Y-%m-%d").date() if confirmed_raw else None
        postavke.default_predsjednik_konzilija = request.POST.get(
            "default_predsjednik_konzilija", ""
        ).strip()
        postavke.default_clan_konzilija_1 = request.POST.get(
            "default_clan_konzilija_1", ""
        ).strip()
        postavke.default_clan_konzilija_2 = request.POST.get(
            "default_clan_konzilija_2", ""
        ).strip()
        postavke.save()
        if confirmed_date != previous_confirmed_date:
            confirm_next_commission_date(confirmed_date, user=request.user)

        messages.success(request, "Postavke sistema su uspješno sačuvane.")
        return redirect("postavke_sistema")

    from updates.models import UpdateHistory, UpdateSession
    from updates.services.crash_recovery import reconcile_session

    update_session = UpdateSession.objects.filter(is_active=True).first() or UpdateSession.objects.order_by("-created_at").first()
    if update_session:
        reconcile_session(update_session)
        update_session.refresh_from_db()
    install_poll_statuses = {
        "install_starting", "validating_plan", "creating_snapshot", "snapshot_completed",
        "service_stopping", "service_stopped", "files_installing", "files_installed",
        "django_check_running", "django_check_passed", "migrations_running",
        "migrations_completed", "collectstatic_running", "collectstatic_completed",
        "service_starting", "service_running", "health_check_running", "health_check_passed",
        "update_completed", "rollback_required", "install_failed", "validation_failed",
        "dependency_update_unsupported", "dry_run_completed",
        "rollback_starting", "rollback_validating", "rollback_service_stopping",
        "rollback_files_restoring", "rollback_config_restoring", "rollback_database_backing_up",
        "rollback_database_restoring", "rollback_application_check", "rollback_service_starting",
        "rollback_health_check", "rollback_completed", "manual_recovery_required",
    }
    from patients.commission_administration import get_administrative_commission_timeline

    return render(request, "dashboard/postavke_sistema.html", {
        "postavke": postavke,
        "administrative_timeline": get_administrative_commission_timeline(
            settings=postavke,
        ),
        "update_result": request.session.get("update_check_result"),
        "update_download_result": request.session.get("update_download_result"),
        "update_prepare_result": request.session.get("update_prepare_result"),
        "active_update_session": update_session,
        "update_install_poll": bool(update_session and update_session.status in install_poll_statuses),
        "update_history": UpdateHistory.objects.select_related("initiated_by")[:10],
        "rollback_available": bool(update_session and update_session.status in {
            UpdateSession.ROLLBACK_REQUIRED, UpdateSession.INSTALL_FAILED,
            UpdateSession.UPDATE_COMPLETED, UpdateSession.MANUAL_RECOVERY_REQUIRED,
        }),
    })


@login_required
@user_passes_test(je_admin)
def postavke_pdf_obrazaca(request):
    postavke = get_postavke_sistema()

    if request.method == "POST":
        postavke.zdravstvena_ustanova = request.POST.get(
            "zdravstvena_ustanova", ""
        ).strip()
        postavke.podnosilac_zahtjeva = request.POST.get(
            "podnosilac_zahtjeva", ""
        ).strip()
        postavke.default_predsjednik_konzilija = request.POST.get(
            "predsjednik_konzilija", ""
        ).strip()
        postavke.default_clan_konzilija_1 = request.POST.get(
            "clan_konzilija_1", ""
        ).strip()
        postavke.default_clan_konzilija_2 = request.POST.get(
            "clan_konzilija_2", ""
        ).strip()
        postavke.save()

        messages.success(request, "Postavke PDF obrazaca su sačuvane.")
        return redirect("postavke_pdf_obrazaca")

    return render(request, "dashboard/postavke_pdf_obrazaca.html", {
        "postavke": postavke,
        "default_ustanova": getattr(settings, "PDF_ZDRAVSTVENA_USTANOVA", "JU Opća bolnica prim.dr. Abdulah Nakaš"),
        "default_podnosilac": getattr(settings, "PDF_SPECIJALISTA", "Mr. Sc. Nijaz Tucaković"),
    })


@login_required
@user_passes_test(je_admin)
def reset_test_data_view(request):
    if request.method == "GET":
        return render(request, "dashboard/reset_test_data_confirm.html", {
            "existing_demo_count": existing_demo_v2_patients_count(),
        })

    if request.method != "POST":
        return redirect("servisni_centar")

    if request.POST.get("confirm_reset") != "RESET V2":
        messages.warning(request, "Reset Demo Dataset V2 nije potvrđen. Upišite RESET V2 za nastavak.")
        return redirect("reset_test_data")

    try:
        stats = reset_demo_dataset_v2()
    except DemoDatasetResetError as exc:
        messages.error(
            request,
            f"Reset nije izvršen; nijedan demo zapis nije obrisan. {exc}",
        )
        return redirect("reset_test_data")
    summary_labels = (
        "pacijenti",
        "terapije",
        "termini",
        "komisije",
        "transakcije",
    )
    summary = ", ".join(
        f"{stats.get(label, 0)} {label}" for label in summary_labels
    )
    upisi_log(
        request.user,
        "Reset Demo Dataset V2",
        opis=f"Servisni centar: uklonjeni su isključivo V2 zapisi: {summary}."
    )
    messages.success(request, f"Reset Demo Dataset V2 završen. Obrisano: {summary}.")

    return redirect("servisni_centar")


@login_required
@user_passes_test(je_admin)
def reset_test_inventory_view(request):
    if request.method == "GET":
        return render(request, "dashboard/reset_test_inventory_confirm.html", {
            "stats": collect_test_inventory_stats(),
        })

    if request.method != "POST":
        return redirect("servisni_centar")

    if request.POST.get("confirm_reset") != "RESET ZALIHE":
        messages.warning(request, "Reset testnih zaliha nije potvrđen. Upišite RESET ZALIHE za nastavak.")
        return redirect("reset_test_inventory")

    stats = reset_test_inventory()
    summary = ", ".join(f"{count} {label}" for label, count in stats.items())
    upisi_log(
        request.user,
        "Reset testnih zaliha",
        opis=f"Servisni centar: obrisano/resetovano {summary}."
    )
    messages.success(request, f"Reset testnih zaliha završen. Obrađeno: {summary}.")

    return redirect("servisni_centar")


@login_required
@user_passes_test(je_admin)
def rekalkulisi_zalihe_view(request):
    if request.method == "POST":
        rezultat = rekalkulisi_fizicke_zalihe(commit=True, korisnik=request.user)
        promjena_count = sum(
            1
            for row in rezultat
            if row["prije_frizider"] != row["poslije_frizider"]
            or row["prije_kod"] != row["poslije_kod"]
        )
        messages.success(
            request,
            f"Rekalkulacija fizičkih zaliha završena. Promijenjeno {promjena_count} redova.",
        )
        return redirect("lista_zaliha")

    return render(request, "dashboard/rekalkulisi_zalihe_confirm.html", {
        "rezultat": rekalkulisi_fizicke_zalihe(commit=False, korisnik=request.user),
    })


@login_required
@user_passes_test(je_admin)
def servisni_centar(request):
    return render(
        request,
        "dashboard/servisni_centar.html",
        {
            "backup_service": automatic_backup_status(),
            "adaptive_assistant": adaptive_summary_safely(),
        },
    )


@login_required
@user_passes_test(je_admin)
def adaptive_assistant_view(request):
    if request.method == "POST":
        if request.POST.get("action") != "analyze":
            messages.error(request, "Nepoznata akcija Adaptivnog asistenta.")
            return redirect("adaptive_assistant")
        if not getattr(settings, "ADAPTIVE_ASSISTANT_ENABLED", False):
            messages.warning(
                request,
                "Adaptivni asistent je isključen konfiguracijom.",
            )
            return redirect("adaptive_assistant")
        generated = calculate_descriptive_insights_safely(persist=True)
        if not generated:
            messages.warning(
                request,
                "Analiza trenutno nije dostupna. Osnovni TheraFlow rad nije pogođen.",
            )
            return redirect("adaptive_assistant")
        upisi_log(
            request.user,
            "Pokrenuta analiza Adaptivnog asistenta",
            opis=(
                f"Generisano {len(generated)} deskriptivnih uvida u "
                "observation režimu. Nije promijenjena nijedna odluka."
            ),
        )
        messages.success(
            request,
            f"Generisano deskriptivnih uvida: {len(generated)}.",
        )
        return redirect("adaptive_assistant")

    return render(request, "dashboard/adaptive_assistant.html", {
        "adaptive_assistant": adaptive_summary_safely(),
        "adaptive_insights": calculate_descriptive_insights_safely(),
    })


@login_required
@user_passes_test(je_admin)
def adaptive_assistant_export(request):
    rows = anonymized_aggregate_rows_safely()
    if rows is None:
        return HttpResponse(
            "Anonimizirani izvoz trenutno nije dostupan.",
            content_type="text/plain; charset=utf-8",
            status=503,
        )
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = (
        'attachment; filename="theraflow_adaptive_aggregates.csv"'
    )
    response.write("\ufeff")
    writer = csv.DictWriter(
        response,
        fieldnames=[
            "medicine",
            "decisions",
            "manual_changes",
            "accepted_percentage",
            "average_quantity_delta",
        ],
    )
    writer.writeheader()
    writer.writerows(rows)
    upisi_log(
        request.user,
        "Izvoz agregata Adaptivnog asistenta",
        opis=(
            "Izvezeni su isključivo anonimizirani agregati po lijeku; "
            "izvoz ne sadrži pacijente, JMBG ni korisnička imena."
        ),
    )
    return response


@login_required
@user_passes_test(je_admin)
def generisi_demo_podatke_view(request):
    schema_gate = run_schema_gate()
    if not schema_gate.clean:
        messages.error(request, ADMIN_SCHEMA_MESSAGE)
        context = {
            "existing_demo_count": 0,
            "stats": None,
            "schema_gate_blocked": True,
        }
        if request.method == "GET":
            return render(request, "dashboard/generisi_demo_podatke.html", context)
        return redirect("generisi_demo_podatke")

    existing_count = existing_demo_v2_patients_count()
    context = {
        "existing_demo_count": existing_count,
        "stats": None,
    }

    if request.method == "GET":
        return render(request, "dashboard/generisi_demo_podatke.html", context)

    if request.method != "POST":
        return redirect("servisni_centar")

    if request.POST.get("confirm_demo") != "DEMO":
        messages.warning(request, "Generisanje demo podataka nije potvrdeno. Upisite DEMO za nastavak.")
        return redirect("generisi_demo_podatke")

    try:
        generator_options = {"user": request.user}
        if request.POST.get("include_free_stock_edge_case") == "on":
            generator_options["include_free_stock_edge_case"] = True
        stats = generate_demo_dataset_v2(**generator_options)
    except (ValueError, DemoDatasetResetError) as exc:
        messages.warning(request, str(exc))
        return redirect("generisi_demo_podatke")

    upisi_log(
        request.user,
        "Generisani demo podaci",
        opis=(
            f"Pacijenti: {stats['pacijenti']}, termini: {stats['termini']}, "
            f"terapije: {stats['terapije']}, komisije: {stats['komisije']}, "
            f"zaduzenja: {stats['zaduzenja']}."
        )
    )
    messages.success(request, "Demo podaci su uspjesno generisani.")

    context["stats"] = stats
    context["existing_demo_count"] = existing_demo_v2_patients_count()
    return render(request, "dashboard/generisi_demo_podatke.html", context)


@login_required
@user_passes_test(je_admin)
def provjera_integriteta_baze(request):
    report = None
    severity_sections = []

    if request.method == "POST":
        report = run_database_integrity_check()
        severity_sections = [
            ("critical", "Kriti\u010dne gre\u0161ke", report["problems_by_severity"]["critical"]),
            ("warning", "Upozorenja", report["problems_by_severity"]["warning"]),
            ("info", "Informacije", report["problems_by_severity"]["info"]),
        ]
        messages.info(
            request,
            f"Provjera integriteta zavr\u0161ena. Prona\u0111eno problema: {report['problem_count']}."
        )

    return render(request, "dashboard/provjera_integriteta.html", {
        "report": report,
        "severity_sections": severity_sections,
    })

@login_required
def oznaci_trebovanja_predato(request):
    if request.method != "POST":
        return redirect("komisijsko_odobrenje")

    ids = request.POST.getlist("trebovanje_ids")

    if not ids:
        messages.error(request, "Niste označili nijednog pacijenta.")
        return redirect("komisijsko_odobrenje")

    trebovanja = Trebovanje.objects.filter(id__in=ids)
    broj = mark_requests_sent(trebovanja, user=request.user)

    messages.success(
        request,
        f"Zahtjevi su označeni kao poslani na komisiju za {broj} pacijenata."
    )

    return redirect("komisijsko_odobrenje")

@login_required
def print_odabrane_zahtjeve(request):
    if request.method != "POST":
        return redirect("komisijsko_odobrenje")

    ids = request.POST.getlist("trebovanje_ids")

    if not ids:
        messages.error(request, "Niste oznacili nijednog pacijenta.")
        return redirect("komisijsko_odobrenje")

    trebovanja = list(Trebovanje.objects.filter(id__in=ids).select_related(
        "pacijent",
        "lijek",
        "komisijski_ciklus",
    ).order_by(
        "lijek__naziv",
        "pacijent__prezime",
        "pacijent__ime"
    ))
    pdf_snapshot = commission_request_snapshot(trebovanja)
    if pdf_snapshot["duplicates"]:
        messages.error(
            request,
            "Greška integriteta komisijskog nacrta: pronađeni su dupli "
            "aktivni zahtjevi. PDF nije generisan.",
        )
        return redirect("komisijsko_odobrenje")

    danas = timezone.now().date()
    sablon_path = os.path.join(settings.BASE_DIR, "media", "sabloni", "za_zavod.pdf")
    output_path = napravi_pdf_putanju(f"odabrani_zahtjevi_komisija_{danas}.pdf")
    coords = get_pdf_coords("zahtjev_zavod")
    debug = getattr(settings, "PDF_DEBUG", False)
    writer = PdfWriter()

    for trebovanje in trebovanja:
        template_pdf = PdfReader(open(sablon_path, "rb"))
        page = template_pdf.pages[0]
        merge_pdf_overlay_page(
            page,
            coords,
            zahtjev_zavodu_values(trebovanje),
            debug=debug,
        )
        writer.add_page(page)

    with open(output_path, "wb") as f:
        writer.write(f)

    return FileResponse(open(output_path, "rb"), as_attachment=False)
def generisi_broj_komisijskog_ciklusa():
    godina = timezone.now().year

    zadnji = KomisijskiCiklus.objects.filter(
        naziv__startswith=f"KOM-{godina}-"
    ).order_by("-id").first()

    if zadnji:
        try:
            zadnji_broj = int(zadnji.naziv.split("-")[-1])
        except Exception:
            zadnji_broj = 0
    else:
        zadnji_broj = 0

    novi_broj = zadnji_broj + 1

    return f"KOM-{godina}-{novi_broj:04d}"


@transaction.atomic
def _zaprimi_odabrana_trebovanja_ciklusa(
    *,
    ciklus,
    trebovanja,
    doze_po_trebovanju,
    zaprimljeno_po_lijeku,
    datum_odobrenja,
    brojevi_saglasnosti,
    korisnik,
):
    """Atomski zaprimi odabrane redove uz stabilan cycle -> request lock red."""

    request_ids = [item.pk for item in trebovanja]
    locked_cycle, locked_requests = lock_cycle_receipt_rows(
        ciklus.pk,
        request_ids,
    )
    if len(locked_requests) != len(set(request_ids)):
        raise ValueError("Neki označeni redovi više ne pripadaju ovom ciklusu.")

    # Svježa provjera se izvršava nakon locka i prije bilo kakvog povećanja
    # fizičke zalihe. Drugi paralelni POST zato ne može ponoviti receipt.
    for locked_request in locked_requests:
        quantity = Decimal(str(doze_po_trebovanju[locked_request.pk]))
        approved = Decimal(str(
            locked_request.odobrene_doze
            if locked_request.odobrene_doze is not None
            else locked_request.broj_doza
        ))
        received = Decimal(str(locked_request.zaprimljene_doze or 0))
        if locked_request.status == "ZAPRIMLJENO":
            raise ValueError(
                f"{locked_request.pacijent} je već zaprimljen u ovom ciklusu."
            )
        if received + quantity > approved:
            raise ValueError(
                f"Zaprimanje za {locked_request.pacijent} prelazi odobrenu "
                f"količinu {approved:g}."
            )

    medicines = {item.lijek_id: item.lijek for item in locked_requests}
    fizicke_transakcije = {}
    for lijek_id, received in zaprimljeno_po_lijeku.items():
        lijek = medicines.get(lijek_id)
        if not lijek:
            raise ValueError("Zaprimljeni lijek ne pripada označenim zahtjevima.")
        _zaliha, fizicka_transakcija = promijeni_zalihu(
            lijek=lijek,
            kolicina=received,
            korisnik=korisnik,
            akcija="Zaprimanje lijeka",
            opis=f"{lijek.naziv}: bulk zaprimljeno {received} doza u frižider.",
            frizider_delta=received,
            tip_transakcije=ZalihaTransakcija.TIP_ZAPRIMANJE,
            referenca=locked_cycle,
            vrati_transakciju=True,
        )
        fizicke_transakcije[lijek_id] = fizicka_transakcija
        cover_pending_physical_needs(lijek=lijek, user=korisnik)

    for locked_request in locked_requests:
        quantity = doze_po_trebovanju[locked_request.pk]
        komisija = zaprimi_trebovanje_iz_ciklusa(
            locked_request,
            datum_odobrenja,
            brojevi_saglasnosti[locked_request.pk],
            quantity,
            povecaj_zalihu=False,
            korisnik=korisnik,
            fizicka_transakcija=fizicke_transakcije[locked_request.lijek_id],
        )
        upisi_log(
            korisnik,
            "Bulk zaprimanje komisijskog ciklusa",
            pacijent=locked_request.pacijent,
            objekat=komisija,
            opis=(
                f"{locked_cycle.naziv}: bulk zaprimljeno {quantity} doza lijeka "
                f"{locked_request.lijek.naziv}."
            ),
        )

    azuriraj_status_ciklusa(locked_cycle, datum_odobrenja, korisnik)
    return locked_cycle, locked_requests


@transaction.atomic
def _zaprimi_jedno_trebovanje_ciklusa(
    *,
    ciklus,
    trebovanje,
    datum_odobrenja,
    broj_saglasnosti,
    broj_doza,
    korisnik,
):
    locked_cycle, locked_requests = lock_cycle_receipt_rows(
        ciklus.pk,
        [trebovanje.pk],
    )
    if len(locked_requests) != 1:
        raise ValueError("Trebovanje više ne pripada ovom komisijskom ciklusu.")
    locked_request = locked_requests[0]
    komisija = zaprimi_trebovanje_iz_ciklusa(
        locked_request,
        datum_odobrenja,
        broj_saglasnosti,
        broj_doza,
        korisnik=korisnik,
    )
    azuriraj_status_ciklusa(locked_cycle, datum_odobrenja, korisnik)
    upisi_log(
        korisnik,
        "Zaprimanje komisijskog ciklusa",
        pacijent=locked_request.pacijent,
        objekat=komisija,
        opis=(
            f"{locked_cycle.naziv}: zaprimljeno {broj_doza} doza lijeka "
            f"{locked_request.lijek.naziv}."
        ),
    )
    return locked_cycle, locked_request, komisija

@login_required
def zaprimanje_ciklusa(request, ciklus_id):
    ciklus = get_object_or_404(KomisijskiCiklus, id=ciklus_id)

    if request.method == "POST":
        if request.POST.get("bulk_action") == "wait_delivery":
            try:
                mark_cycle_waiting_delivery(ciklus, user=request.user)
            except ValueError as exc:
                messages.error(request, str(exc))
            else:
                messages.success(request, "Ciklus je prešao u fazu čekanja isporuke.")
            return redirect("zaprimanje_ciklusa", ciklus_id=ciklus.id)

        if request.POST.get("bulk_action") == "approve_cycle":
            datum_odobrenja, datum_error = parse_datum_odobrenja(request, ciklus)
            if not datum_odobrenja:
                return _render_receipt_cycle(
                    request,
                    ciklus,
                    form_state=_receipt_form_state(
                        request,
                        field_errors={"datum_odobrenja": datum_error},
                    ),
                )
            approved_quantities = {}
            try:
                for trebovanje in ciklus.trebovanja.all():
                    approved_quantities[trebovanje.id] = Decimal(str(request.POST.get(
                        f"odobrene_doze_{trebovanje.id}", trebovanje.broj_doza
                    )))
                approve_cycle(
                    ciklus,
                    approved_quantities,
                    datum_odobrenja,
                    user=request.user,
                    approval_number="",
                )
            except (ValueError, ArithmeticError) as exc:
                messages.error(request, str(exc))
            else:
                messages.success(request, "Odobrene količine su evidentirane.")
            return redirect("zaprimanje_ciklusa", ciklus_id=ciklus.id)

        if request.POST.get("bulk_action") == "confirm_selected":
            selected_ids = request.POST.getlist("selected_trebovanja")

            if not selected_ids:
                return _render_receipt_cycle(
                    request,
                    ciklus,
                    form_state=_receipt_form_state(
                        request,
                        field_errors={
                            "selection": (
                                "Označite najmanje jednog pacijenta kojem je "
                                "lijek stigao."
                            ),
                        },
                    ),
                )

            approval_context = resolve_receipt_approval_context(ciklus)
            datum_odobrenja, datum_error = parse_datum_odobrenja(
                request,
                ciklus,
                approval_context=approval_context,
            )
            if not datum_odobrenja:
                return _render_receipt_cycle(
                    request,
                    ciklus,
                    form_state=_receipt_form_state(
                        request,
                        selected_ids=selected_ids,
                        field_errors={"datum_odobrenja": datum_error},
                    ),
                )

            def validation_response(message, *, field=None):
                return _render_receipt_cycle(
                    request,
                    ciklus,
                    form_state=_receipt_form_state(
                        request,
                        selected_ids=selected_ids,
                        field_errors={field or "general": message},
                    ),
                )

            trebovanja = list(
                Trebovanje.objects.select_related("pacijent", "lijek").filter(
                    id__in=selected_ids,
                    komisijski_ciklus=ciklus
                ).order_by("lijek__naziv", "pacijent__prezime", "pacijent__ime")
            )

            if len(trebovanja) != len(set(selected_ids)):
                return validation_response(
                    "Neki označeni redovi ne pripadaju ovoj pošiljci.",
                    field="selection",
                )

            doze_po_trebovanju = {}
            brojevi_saglasnosti = {}
            dodijeljeno_po_lijeku = defaultdict(lambda: Decimal("0"))
            zaprimljeno_po_lijeku = {}

            for trebovanje in trebovanja:
                if trebovanje.status == "ZAPRIMLJENO":
                    return validation_response(
                        f"{trebovanje.pacijent} je već zaprimljen u ovom ciklusu.",
                        field="selection",
                    )

                agreement_field = f"broj_saglasnosti_{trebovanje.id}"
                try:
                    brojevi_saglasnosti[trebovanje.id] = validate_agreement_number(
                        request.POST.get(agreement_field, "")
                    )
                except ValueError as exc:
                    return validation_response(str(exc), field=agreement_field)

                try:
                    broj_doza = Decimal(str(request.POST.get(
                        f"broj_doza_{trebovanje.id}",
                        trebovanje.broj_doza
                    )))
                except Exception:
                    broj_doza = Decimal("0")

                if broj_doza <= 0:
                    return validation_response(
                        f"Količina za {trebovanje.pacijent} mora biti veća od nule.",
                        field=f"broj_doza_{trebovanje.id}",
                    )

                doze_po_trebovanju[trebovanje.id] = broj_doza
                try:
                    validate_package_multiple(
                        broj_doza,
                        trebovanje.lijek,
                        label="Zaprimljena količina",
                    )
                except ValueError as exc:
                    return validation_response(
                        str(exc),
                        field=f"broj_doza_{trebovanje.id}",
                    )
                dodijeljeno_po_lijeku[trebovanje.lijek_id] += broj_doza

            for lijek_id, dodijeljeno in dodijeljeno_po_lijeku.items():
                lijek = next((t.lijek for t in trebovanja if t.lijek_id == lijek_id), None)
                naziv_lijeka = lijek.naziv if lijek else "lijek"
                try:
                    zaprimljeno = Decimal(str(request.POST.get(
                        f"zaprimljeno_lijek_{lijek_id}",
                        dodijeljeno
                    )))
                except Exception:
                    zaprimljeno = Decimal("0")

                if zaprimljeno <= 0:
                    return validation_response(
                        f"Unesite ukupno zaprimljenu količinu za {naziv_lijeka}.",
                        field=f"zaprimljeno_lijek_{lijek_id}",
                    )

                try:
                    validate_package_multiple(
                        zaprimljeno,
                        lijek,
                        label="Ukupno zaprimljena količina",
                    )
                except ValueError as exc:
                    return validation_response(
                        str(exc),
                        field=f"zaprimljeno_lijek_{lijek_id}",
                    )

                if dodijeljeno > zaprimljeno:
                    return validation_response(
                        f"Dodijeljeno za {naziv_lijeka} ({dodijeljeno}) "
                        f"prelazi zaprimljeno ({zaprimljeno}).",
                        field=f"zaprimljeno_lijek_{lijek_id}",
                    )

                zaprimljeno_po_lijeku[lijek_id] = zaprimljeno

            try:
                ciklus, trebovanja = _zaprimi_odabrana_trebovanja_ciklusa(
                    ciklus=ciklus,
                    trebovanja=trebovanja,
                    doze_po_trebovanju=doze_po_trebovanju,
                    zaprimljeno_po_lijeku=zaprimljeno_po_lijeku,
                    datum_odobrenja=datum_odobrenja,
                    brojevi_saglasnosti=brojevi_saglasnosti,
                    korisnik=request.user,
                )
            except ValueError as exc:
                return validation_response(str(exc))

            messages.success(
                request,
                f"Zaprimanje uspješno potvrđeno za {len(trebovanja)} pacijenata."
            )
            for trebovanje in trebovanja:
                conflicts = agreement_number_conflicts(
                    brojevi_saglasnosti[trebovanje.pk],
                    patient=trebovanje.pacijent,
                )
                if conflicts:
                    names = ", ".join(str(item) for item in conflicts[:3])
                    messages.warning(
                        request,
                        f"Broj saglasnosti {brojevi_saglasnosti[trebovanje.pk]} "
                        f"evidentiran je i kod drugog pacijenta: {names}. "
                        "Podaci nisu automatski mijenjani.",
                    )
            ciklus.refresh_from_db()
            naredni_step = "potvrda" if ciklus.status == "ZAPRIMLJENO" else "pregled"
            return redirect(f"{reverse('zaprimanje_ciklusa', args=[ciklus.id])}?step={naredni_step}")

        trebovanje_id = request.POST.get("trebovanje_id")
        trebovanje = get_object_or_404(
            Trebovanje,
            id=trebovanje_id,
            komisijski_ciklus=ciklus
        )

        if trebovanje.status == "ZAPRIMLJENO":
            messages.error(request, "Ovo trebovanje je već zaprimljeno.")
            return redirect("zaprimanje_ciklusa", ciklus_id=ciklus.id)

        try:
            broj_doza = Decimal(str(request.POST.get("broj_doza", trebovanje.broj_doza)))
        except ValueError:
            broj_doza = 0

        approval_context = resolve_receipt_approval_context(ciklus)
        agreement_field = f"broj_saglasnosti_{trebovanje.id}"
        try:
            broj_saglasnosti = validate_agreement_number(
                request.POST.get(agreement_field, "")
            )
        except ValueError as exc:
            return _render_receipt_cycle(
                request,
                ciklus,
                form_state=_receipt_form_state(
                    request,
                    field_errors={agreement_field: str(exc)},
                ),
            )

        if broj_doza <= 0:
            return _render_receipt_cycle(
                request,
                ciklus,
                form_state=_receipt_form_state(
                    request,
                    field_errors={
                        f"broj_doza_{trebovanje.id}": (
                            "Broj zaprimljenih doza mora biti veći od nule."
                        ),
                    },
                ),
            )

        datum_odobrenja, datum_error = parse_datum_odobrenja(
            request,
            ciklus,
            approval_context=approval_context,
        )
        if not datum_odobrenja:
            return _render_receipt_cycle(
                request,
                ciklus,
                form_state=_receipt_form_state(
                    request,
                    field_errors={
                        "datum_odobrenja": datum_error,
                    },
                ),
            )

        try:
            ciklus, trebovanje, komisija = _zaprimi_jedno_trebovanje_ciklusa(
                ciklus=ciklus,
                trebovanje=trebovanje,
                datum_odobrenja=datum_odobrenja,
                broj_saglasnosti=broj_saglasnosti,
                broj_doza=broj_doza,
                korisnik=request.user,
            )
        except ValueError as exc:
            return _render_receipt_cycle(
                request,
                ciklus,
                form_state=_receipt_form_state(
                    request,
                    field_errors={
                        f"broj_doza_{trebovanje.id}": str(exc),
                    },
                ),
            )

        messages.success(
            request,
            f"Zaprimljeno: {trebovanje.pacijent.ime} {trebovanje.pacijent.prezime} - {broj_doza} doza."
        )
        conflicts = agreement_number_conflicts(
            broj_saglasnosti,
            patient=trebovanje.pacijent,
        )
        if conflicts:
            names = ", ".join(str(item) for item in conflicts[:3])
            messages.warning(
                request,
                f"Broj saglasnosti {broj_saglasnosti} evidentiran je i kod "
                f"drugog pacijenta: {names}. Podaci nisu automatski mijenjani.",
            )
        return redirect("zaprimanje_ciklusa", ciklus_id=ciklus.id)

    return _render_receipt_cycle(request, ciklus)
