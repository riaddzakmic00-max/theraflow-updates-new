from decimal import Decimal

from .medication_groups import (
    THERAPY_GROUP_ADALIMUMAB,
    THERAPY_GROUP_ENTYVIO,
    THERAPY_GROUP_REMSIMA,
    get_therapy_group,
    medicine_group_q,
)
from .models import Lijek, Pacijent, TerapijskiKorakProtokola, TerapijskiProtokol


STANDARD_PROTOCOLS = {
    "entyvio": {
        "lijek_naziv": "Entyvio",
        "naziv": "Standardni plan",
        "tip_terapije": TerapijskiProtokol.TIP_KOMBINOVANO,
        "indukcijske_sedmice": "0,2,6",
        "interval_odrzavanja_sedmica": 8,
        "doza_po_aplikaciji": 1,
        "kucna_terapija": False,
        "napomena": "Default protokol: indukcija 0,2,6; odrzavanje svakih 8 sedmica.",
        "koraci": [
            ("Indukcija 1", TerapijskiKorakProtokola.FAZA_INDUKCIJA, 0, 1, Decimal("300"), Decimal("1"), None, TerapijskiKorakProtokola.NACIN_AMBULANTA),
            ("Indukcija 2", TerapijskiKorakProtokola.FAZA_INDUKCIJA, 2, 2, Decimal("300"), Decimal("1"), None, TerapijskiKorakProtokola.NACIN_AMBULANTA),
            ("Indukcija 3", TerapijskiKorakProtokola.FAZA_INDUKCIJA, 6, 3, Decimal("300"), Decimal("1"), None, TerapijskiKorakProtokola.NACIN_AMBULANTA),
            ("Odrzavanje", TerapijskiKorakProtokola.FAZA_ODRZAVANJE, 14, 4, Decimal("300"), Decimal("1"), 8, TerapijskiKorakProtokola.NACIN_AMBULANTA),
        ],
    },
    "remsima": {
        "lijek_naziv": "Remsima",
        "naziv": "Standardni plan",
        "tip_terapije": TerapijskiProtokol.TIP_KOMBINOVANO,
        "indukcijske_sedmice": "0,2,6",
        "interval_odrzavanja_sedmica": 8,
        "doza_po_aplikaciji": 4,
        "kucna_terapija": False,
        "napomena": "Default protokol: indukcija 0,2,6; odrzavanje svakih 8 sedmica.",
        "koraci": [
            ("Indukcija 1", TerapijskiKorakProtokola.FAZA_INDUKCIJA, 0, 1, None, Decimal("4"), None, TerapijskiKorakProtokola.NACIN_AMBULANTA),
            ("Indukcija 2", TerapijskiKorakProtokola.FAZA_INDUKCIJA, 2, 2, None, Decimal("4"), None, TerapijskiKorakProtokola.NACIN_AMBULANTA),
            ("Indukcija 3", TerapijskiKorakProtokola.FAZA_INDUKCIJA, 6, 3, None, Decimal("4"), None, TerapijskiKorakProtokola.NACIN_AMBULANTA),
            ("Odrzavanje", TerapijskiKorakProtokola.FAZA_ODRZAVANJE, 14, 4, None, Decimal("4"), 8, TerapijskiKorakProtokola.NACIN_AMBULANTA),
        ],
    },
    "infliximab": {
        "alias_for": "remsima",
    },
    "vedolizumab": {
        "alias_for": "entyvio",
    },
    "adalimumab": {
        "lijek_naziv": "Adalimumab",
        "naziv": "Odrzavanje kucne terapije",
        "tip_terapije": TerapijskiProtokol.TIP_ODRZAVANJE,
        "indukcijske_sedmice": "",
        "interval_odrzavanja_sedmica": 2,
        "doza_po_aplikaciji": 1,
        "kucna_terapija": True,
        "napomena": "Default protokol: kucna terapija svakih 2 sedmice.",
        "koraci": [
            ("Odrzavanje kuci", TerapijskiKorakProtokola.FAZA_ODRZAVANJE, 0, 1, Decimal("40"), Decimal("1"), 2, TerapijskiKorakProtokola.NACIN_KUCNA_TERAPIJA),
        ],
    },
}


def standard_key_for_lijek(lijek):
    key = {
        THERAPY_GROUP_ENTYVIO: "entyvio",
        THERAPY_GROUP_REMSIMA: "remsima",
        THERAPY_GROUP_ADALIMUMAB: "adalimumab",
    }.get(get_therapy_group(lijek))
    config = STANDARD_PROTOCOLS.get(key)
    return config.get("alias_for", key) if config else None


def load_standard_protocol_for_lijek(lijek, protokol=None):
    key = standard_key_for_lijek(lijek)
    if not key:
        return None, False, 0

    config = STANDARD_PROTOCOLS[key]

    if config.get("kucna_terapija"):
        lijek.kucna_primjena = True
        lijek.nacin_primjene = Lijek.NACIN_KUCNA_TERAPIJA
        lijek.put_primjene = Lijek.PUT_SC
        lijek.package_size_in_doses = 2
        lijek.jedinica_terapije = "pen"
        lijek.jedinica_terapije_mnozina = "pena"
        lijek.jedinica_zalihe = "pen"
        lijek.jedinica_zalihe_mnozina = "penovi"
        lijek.save(update_fields=[
            "kucna_primjena",
            "nacin_primjene",
            "put_primjene",
            "package_size_in_doses",
            "jedinica_terapije",
            "jedinica_terapije_mnozina",
            "jedinica_zalihe",
            "jedinica_zalihe_mnozina",
        ])

    if protokol is None:
        existing = list(
            TerapijskiProtokol.objects.filter(
                lijek=lijek,
                naziv=config["naziv"],
            ).order_by("-aktivan", "id")
        )
        if existing:
            protokol = existing[0]
            created = False
            duplicate_ids = [duplicate.id for duplicate in existing[1:]]
            if duplicate_ids:
                Pacijent.objects.filter(
                    terapijski_protokol_id__in=duplicate_ids
                ).update(terapijski_protokol=protokol)
                TerapijskiProtokol.objects.filter(id__in=duplicate_ids).delete()
        else:
            protokol = TerapijskiProtokol.objects.create(
                lijek=lijek,
                naziv=config["naziv"],
                tip_terapije=config["tip_terapije"],
                indukcijske_sedmice=config["indukcijske_sedmice"],
                interval_odrzavanja_sedmica=config["interval_odrzavanja_sedmica"],
                doza_po_aplikaciji=config["doza_po_aplikaciji"],
                napomena=config["napomena"],
                aktivan=True,
            )
            created = True
    else:
        created = False

    protokol.naziv = config["naziv"]
    protokol.tip_terapije = config["tip_terapije"]
    protokol.indukcijske_sedmice = config["indukcijske_sedmice"]
    protokol.interval_odrzavanja_sedmica = config["interval_odrzavanja_sedmica"]
    protokol.doza_po_aplikaciji = config["doza_po_aplikaciji"]
    protokol.napomena = config["napomena"]
    protokol.aktivan = True
    protokol.save()

    koraci_count = 0
    aktivni_redoslijedi = []
    for naziv, faza, sedmica, redoslijed, doza_mg, broj_jedinica, interval, nacin_primjene in config["koraci"]:
        aktivni_redoslijedi.append(redoslijed)
        koraci = list(
            TerapijskiKorakProtokola.objects.filter(
                protokol=protokol,
                redoslijed=redoslijed,
            ).order_by("id")
        )
        if koraci:
            korak = koraci[0]
            step_created = False
            if len(koraci) > 1:
                TerapijskiKorakProtokola.objects.filter(
                    id__in=[duplikat.id for duplikat in koraci[1:]]
                ).update(aktivan=False)
        else:
            korak = TerapijskiKorakProtokola(protokol=protokol, redoslijed=redoslijed)
            step_created = True
        korak.naziv_koraka = naziv
        korak.faza = faza
        korak.sedmica_od_pocetka = sedmica
        korak.doza_mg = doza_mg
        korak.broj_jedinica = broj_jedinica
        korak.interval_sedmica = interval
        korak.nacin_primjene_koraka = nacin_primjene
        korak.aktivan = True
        korak.save()
        if step_created:
            koraci_count += 1

    TerapijskiKorakProtokola.objects.filter(protokol=protokol).exclude(
        redoslijed__in=aktivni_redoslijedi
    ).update(aktivan=False)

    return protokol, created, koraci_count


def load_all_standard_protocols(create_missing_lijek=True):
    results = []

    for key, config in STANDARD_PROTOCOLS.items():
        if config.get("alias_for"):
            continue

        lijek = Lijek.objects.filter(medicine_group_q(key)).first()
        if not lijek and create_missing_lijek:
            lijek = Lijek.objects.create(naziv=config["lijek_naziv"])

        if not lijek:
            results.append((config["lijek_naziv"], None, False, 0))
            continue

        protokol, created, koraci_count = load_standard_protocol_for_lijek(lijek)
        results.append((lijek.naziv, protokol, created, koraci_count))

    return results
