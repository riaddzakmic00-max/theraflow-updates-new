from django.db import migrations, models


def popuni_nazive_lijekova(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")

    vrijednosti = {
        "remsima": {
            "genericki_naziv": "infliksimab",
            "zasticeno_ime": "Remsima",
        },
        "entyvio": {
            "genericki_naziv": "vedolizumab",
            "zasticeno_ime": "Entyvio",
        },
        "adalimumab": {
            "genericki_naziv": "adalimumab",
            "zasticeno_ime": "Hyrimoz",
        },
    }

    for naziv, podaci in vrijednosti.items():
        Lijek.objects.filter(naziv__iexact=naziv).update(**podaci)


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0023_terapijskikorakprotokola_nacin_primjene"),
    ]

    operations = [
        migrations.AddField(
            model_name="lijek",
            name="genericki_naziv",
            field=models.CharField(blank=True, max_length=100),
        ),
        migrations.AddField(
            model_name="lijek",
            name="zasticeno_ime",
            field=models.CharField(blank=True, max_length=100),
        ),
        migrations.RunPython(popuni_nazive_lijekova, migrations.RunPython.noop),
    ]
