from django.core.management.base import BaseCommand, CommandError

from patients.reset_test_data import reset_test_data


class Command(BaseCommand):
    help = "Briše testne pacijente i povezane operativne podatke, bez brisanja šifrarnika i protokola."

    def add_arguments(self, parser):
        parser.add_argument(
            "--yes",
            action="store_true",
            help="Preskoči interaktivnu potvrdu. Koristiti samo u kontrolisanim testnim okruženjima.",
        )

    def handle(self, *args, **options):
        if not options["yes"]:
            potvrda = input("Da li ste sigurni? Upišite RESET za nastavak: ")
            if potvrda.strip() != "RESET":
                raise CommandError("Reset testnih podataka je otkazan.")

        stats = reset_test_data()

        self.stdout.write(self.style.SUCCESS("Obrisano:"))
        for label, count in stats.items():
            self.stdout.write(f"- obrisano {label}: {count}")
