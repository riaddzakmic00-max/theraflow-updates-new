# Generated for TheraFlow therapeutic protocol support

import django.db.models.deletion
from django.db import migrations, models


def napravi_pocetne_protokole(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    Pacijent = apps.get_model("patients", "Pacijent")
    TerapijskiProtokol = apps.get_model("patients", "TerapijskiProtokol")

    pravila = [
        {
            "kljucevi": ["remsima", "remisima", "infliximab"],
            "naziv": "Remsima kombinovani protokol",
            "tip_terapije": "KOMBINOVANO",
            "indukcijske_sedmice": "0,2,6",
            "interval": 8,
            "doza": 4,
            "napomena": "Početni protokol iz postojeće hardkodirane logike.",
        },
        {
            "kljucevi": ["entyvio", "vedolizumab"],
            "naziv": "Entyvio kombinovani protokol",
            "tip_terapije": "KOMBINOVANO",
            "indukcijske_sedmice": "0,2,6",
            "interval": 8,
            "doza": 1,
            "napomena": "Početni protokol iz postojeće hardkodirane logike.",
        },
        {
            "kljucevi": ["adalimumab"],
            "naziv": "Adalimumab održavanje",
            "tip_terapije": "ODRZAVANJE",
            "indukcijske_sedmice": "",
            "interval": 2,
            "doza": 1,
            "napomena": "Početni protokol iz postojeće hardkodirane logike.",
        },
        {
            "kljucevi": ["stelara", "ustekinumab"],
            "naziv": "Stelara održavanje",
            "tip_terapije": "ODRZAVANJE",
            "indukcijske_sedmice": "",
            "interval": 8,
            "doza": 1,
            "napomena": "TODO: provjeriti i uskladiti protokol u adminu.",
        },
        {
            "kljucevi": ["skyrizi", "risankizumab"],
            "naziv": "Skyrizi kombinovani protokol",
            "tip_terapije": "KOMBINOVANO",
            "indukcijske_sedmice": "0,4,8",
            "interval": 8,
            "doza": 1,
            "napomena": "TODO: provjeriti i uskladiti protokol u adminu.",
        },
    ]

    for lijek in Lijek.objects.all():
        naziv_lijeka = lijek.naziv.lower()
        odabrano = None

        for pravilo in pravila:
            if any(kljuc in naziv_lijeka for kljuc in pravilo["kljucevi"]):
                odabrano = pravilo
                break

        if not odabrano:
            odabrano = {
                "naziv": f"{lijek.naziv} osnovni protokol",
                "tip_terapije": "ODRZAVANJE",
                "indukcijske_sedmice": "",
                "interval": 8,
                "doza": 1,
                "napomena": "Automatski fallback protokol. TODO: provjeriti u adminu.",
            }

        protokol, created = TerapijskiProtokol.objects.get_or_create(
            lijek=lijek,
            naziv=odabrano["naziv"],
            defaults={
                "tip_terapije": odabrano["tip_terapije"],
                "indukcijske_sedmice": odabrano["indukcijske_sedmice"],
                "interval_odrzavanja_sedmica": odabrano["interval"],
                "doza_po_aplikaciji": odabrano["doza"],
                "aktivan": True,
                "napomena": odabrano["napomena"],
            },
        )

        Pacijent.objects.filter(
            lijek=lijek,
            terapijski_protokol__isnull=True
        ).update(terapijski_protokol=protokol)


def ukloni_pocetne_protokole(apps, schema_editor):
    TerapijskiProtokol = apps.get_model("patients", "TerapijskiProtokol")
    TerapijskiProtokol.objects.all().delete()


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0014_trebovanje_komisijski_ciklus"),
    ]

    operations = [
        migrations.CreateModel(
            name="TerapijskiProtokol",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("naziv", models.CharField(max_length=150)),
                ("tip_terapije", models.CharField(choices=[("INDUKCIJA", "Indukcija"), ("ODRZAVANJE", "Održavanje"), ("KOMBINOVANO", "Kombinovano")], default="ODRZAVANJE", max_length=20)),
                ("indukcijske_sedmice", models.CharField(blank=True, help_text='Sedmice od početka terapije, npr. "0,2,6".', max_length=100)),
                ("interval_odrzavanja_sedmica", models.PositiveIntegerField(default=8)),
                ("doza_po_aplikaciji", models.PositiveIntegerField(default=1)),
                ("aktivan", models.BooleanField(default=True)),
                ("napomena", models.TextField(blank=True)),
                ("lijek", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to="patients.lijek")),
            ],
            options={
                "verbose_name": "Terapijski protokol",
                "verbose_name_plural": "Terapijski protokoli",
                "ordering": ["lijek__naziv", "naziv"],
            },
        ),
        migrations.AddField(
            model_name="pacijent",
            name="terapijski_protokol",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to="patients.terapijskiprotokol"),
        ),
        migrations.RunPython(napravi_pocetne_protokole, ukloni_pocetne_protokole),
    ]
