"""Strukturirani operativni razlog statusa pacijenta."""

from dataclasses import dataclass

from django.utils import timezone


@dataclass(frozen=True)
class PatientRisk:
    code: str
    label: str
    reason: str
    urgent: bool


def patient_risk(pacijent, *, workflow=None, planning=None, today=None):
    from .services import izracunaj_status_pacijenta

    today = today or timezone.localdate()
    workflow = workflow or izracunaj_status_pacijenta(pacijent)
    status = workflow.get("status") or ""
    reason = workflow.get("status_razlog") or status or "Nema dodatnog objašnjenja."

    if not pacijent.aktivan:
        return PatientRisk("INACTIVE", "Neaktivan pacijent", reason, False)

    # Uz kanonski komisijski red, HITNO znači isključivo stvarni rizik dostave
    # iz istog V2 izvora koji koristi Komisijski centar.
    if planning is not None:
        planning_reason = planning.get("status_razlog") or reason
        if planning.get("rizik_dostave"):
            return PatientRisk(
                "DELIVERY_RISK",
                "Rizik dostave",
                planning_reason,
                True,
            )
        if planning.get("included_in_draft"):
            return PatientRisk(
                "COMMISSION_DUE",
                "Potrebna komisija",
                planning_reason,
                False,
            )
        if planning.get("za_pregled"):
            return PatientRisk(
                "REVIEW",
                "Potrebna provjera",
                planning_reason,
                False,
            )
        return PatientRisk("OK", "Bez hitnog razloga", planning_reason, False)

    next_therapy = workflow.get("sljedeca_terapija")
    if next_therapy and next_therapy < today:
        return PatientRisk("THERAPY_LATE", "Terapija kasni", reason, True)
    if next_therapy is None:
        return PatientRisk("NO_APPOINTMENT", "Nema zakazan termin", reason, True)
    if workflow.get("status_css") == "status-hitno":
        if "zalih" in reason.lower() or "fizičk" in reason.lower():
            return PatientRisk("STOCK", "Nedovoljna zaliha", reason, True)
        return PatientRisk("COMMISSION_COVERAGE", "Komisijska nepokrivenost", reason, True)
    if workflow.get("status_css") == "status-komisija":
        return PatientRisk("COMMISSION_DUE", "Komisija uskoro", reason, False)
    return PatientRisk("OK", "Bez hitnog razloga", reason, False)
