from django.db import migrations, models


def migrate_kucna_primjena(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    Lijek.objects.filter(kucna_primjena=True).update(nacin_primjene="KUCNA_TERAPIJA")
    Lijek.objects.filter(kucna_primjena=False).update(nacin_primjene="AMBULANTA")


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0020_dokumentpacijenta"),
    ]

    operations = [
        migrations.AddField(
            model_name="lijek",
            name="nacin_primjene",
            field=models.CharField(
                choices=[
                    ("AMBULANTA", "Ambulanta"),
                    ("KUCNA_TERAPIJA", "Kućna terapija"),
                ],
                default="AMBULANTA",
                max_length=20,
            ),
        ),
        migrations.AddField(
            model_name="terapija",
            name="tip_evidencije",
            field=models.CharField(
                choices=[
                    ("PRIMJENA_U_AMBULANTI", "Primljeno u ambulanti"),
                    ("IZDAVANJE_KUCNE_TERAPIJE", "Izdato za kućnu terapiju"),
                ],
                default="PRIMJENA_U_AMBULANTI",
                max_length=30,
            ),
        ),
        migrations.RunPython(migrate_kucna_primjena, migrations.RunPython.noop),
    ]
