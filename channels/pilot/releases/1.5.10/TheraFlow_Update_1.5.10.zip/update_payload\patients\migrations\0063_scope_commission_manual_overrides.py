from django.db import migrations, models
import django.db.models.deletion


def classify_and_archive_existing_overrides(apps, schema_editor):
    ManualOverride = apps.get_model("patients", "KomisijskiRucniUnos")
    Request = apps.get_model("patients", "Trebovanje")

    for override in ManualOverride.objects.all().iterator():
        override.aktivan_nacrt = False
        override.rucni_override = bool(
            override.korisnik_id
            and (override.razlog or "").strip()
            and override.ljekar_trazi != override.sistemski_prijedlog
        )
        matching_request = (
            Request.objects.filter(
                pacijent_id=override.pacijent_id,
                lijek_id=override.lijek_id,
                broj_doza=override.ljekar_trazi,
                komisijski_ciklus_id__isnull=False,
            )
            .order_by("-datum_kreiranja", "-id")
            .first()
        )
        if matching_request:
            override.komisijski_ciklus_id = matching_request.komisijski_ciklus_id
        override.save(
            update_fields=[
                "aktivan_nacrt",
                "rucni_override",
                "komisijski_ciklus",
            ]
        )


def close_duplicate_active_requests(apps, schema_editor):
    Request = apps.get_model("patients", "Trebovanje")
    seen = set()
    active = (
        Request.objects.filter(
            komisijski_ciklus_id__isnull=False,
            status__in=["U_PRIPREMI", "NACRT", "SPREMAN"],
        )
        .order_by(
            "pacijent_id",
            "lijek_id",
            "komisijski_ciklus_id",
            "-id",
        )
    )
    for request in active.iterator():
        key = (
            request.pacijent_id,
            request.lijek_id,
            request.komisijski_ciklus_id,
        )
        if key not in seen:
            seen.add(key)
            continue
        request.status = "OTKAZANO"
        request.napomena = (
            f"{request.napomena or ''}\n"
            "Automatski deaktiviran dupli aktivni komisijski nacrt tokom "
            "integrity migracije."
        ).strip()
        request.save(update_fields=["status", "napomena"])


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0062_adaptive_assistant_observation"),
    ]

    operations = [
        migrations.AddField(
            model_name="komisijskirucniunos",
            name="aktivan_nacrt",
            field=models.BooleanField(db_index=True, default=False),
        ),
        migrations.AddField(
            model_name="komisijskirucniunos",
            name="komisijski_ciklus",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="rucni_unosi",
                to="patients.komisijskiciklus",
            ),
        ),
        migrations.AddField(
            model_name="komisijskirucniunos",
            name="rucni_override",
            field=models.BooleanField(db_index=True, default=False),
        ),
        migrations.RemoveConstraint(
            model_name="komisijskirucniunos",
            name="uniq_komisijski_rucni_unos_pacijent_lijek",
        ),
        migrations.RunPython(
            classify_and_archive_existing_overrides,
            migrations.RunPython.noop,
        ),
        migrations.RunPython(
            close_duplicate_active_requests,
            migrations.RunPython.noop,
        ),
        migrations.AddConstraint(
            model_name="komisijskirucniunos",
            constraint=models.UniqueConstraint(
                condition=models.Q(komisijski_ciklus__isnull=False),
                fields=("pacijent", "lijek", "komisijski_ciklus"),
                name="uniq_komisijski_unos_pacijent_lijek_ciklus",
            ),
        ),
        migrations.AddConstraint(
            model_name="komisijskirucniunos",
            constraint=models.UniqueConstraint(
                condition=models.Q(aktivan_nacrt=True),
                fields=("pacijent", "lijek"),
                name="uniq_aktivan_komisijski_unos_pacijent_lijek",
            ),
        ),
        migrations.AddConstraint(
            model_name="komisijskirucniunos",
            constraint=models.CheckConstraint(
                condition=(
                    models.Q(aktivan_nacrt=False)
                    | models.Q(komisijski_ciklus__isnull=True)
                ),
                name="aktivan_komisijski_unos_bez_ciklusa",
            ),
        ),
        migrations.AddConstraint(
            model_name="trebovanje",
            constraint=models.UniqueConstraint(
                condition=(
                    models.Q(komisijski_ciklus__isnull=False)
                    & models.Q(status__in=["U_PRIPREMI", "NACRT", "SPREMAN"])
                ),
                fields=("pacijent", "lijek", "komisijski_ciklus"),
                name="uniq_aktivno_trebovanje_pacijent_lijek_ciklus",
            ),
        ),
    ]
