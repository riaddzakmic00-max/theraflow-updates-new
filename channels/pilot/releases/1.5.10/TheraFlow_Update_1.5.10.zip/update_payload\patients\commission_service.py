import calendar
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from math import ceil

from django.db import connection, transaction
from django.conf import settings as django_settings
from django.db.models import F, Sum
from django.utils import timezone

from .models import (
    Komisija,
    KomisijskiCiklus,
    MigracijskiSnapshotPacijenta,
    Pacijent,
    PacijentZaduzenje,
    PostavkeSistema,
    Trebovanje,
)
from .package_sizes import (
    procurement_breakdown,
    round_up_to_package,
    validate_package_multiple,
)
from .request_cache import get_or_set
from .transaction_locking import select_for_update_self
from .utils import upisi_log


OPEN_REQUEST_STATUSES = ("U_PRIPREMI", "PREDATO", "ODOBRENO")
VALID_COMMISSION_STATUSES = ("AKTIVNA", "BUDUCA", "ODOBRENA")
FINAL_CYCLE_STATUSES = ("ZAPRIMLJENO", "ZAVRSENO", "zavrseno")


@dataclass(frozen=True)
class CommissionSchedule:
    last_actual_date: date | None
    estimated_next_date: date | None
    confirmed_next_date: date | None
    effective_next_date: date | None
    preparation_start_date: date | None
    expected_delivery_date: date | None
    phase_code: str
    status_label: str
    active_cycle: object | None
    need_coverage_end_date: date | None = None
    delivery_confirmed: bool = False

    @property
    def phase_display(self):
        return {
            "NOT_DUE": "Još nije vrijeme za pripremu",
            "PREPARATION": "Priprema zahtjeva",
            "SENT": "Zahtjevi poslani",
            "APPROVED": "Komisija odobrila",
            "WAITING_DELIVERY": "Čeka se isporuka",
            "DELIVERY_LATE": "Isporuka kasni",
            "RECEIVING": "Zaprimanje u toku",
            "AWAITING_CONFIRMATION": "Čeka potvrdu datuma",
            "NO_REFERENCE": "Nema referentnog ciklusa",
        }.get(self.phase_code, self.status_label)


def get_settings():
    from .request_cache import get_or_set

    def load_settings():
        settings, _ = PostavkeSistema.objects.get_or_create(pk=1)
        return settings

    return get_or_set("commission_settings", 1, load_settings)


def add_calendar_months(value, months):
    if value is None:
        return None
    zero_based = value.month - 1 + int(months)
    year = value.year + zero_based // 12
    month = zero_based % 12 + 1
    day = min(value.day, calendar.monthrange(year, month)[1])
    return value.replace(year=year, month=month, day=day)


def configured_non_working_dates():
    """Vrati evidentirane neradne datume iz centralne konfiguracije."""

    configured = getattr(django_settings, "THERAFLOW_NON_WORKING_DATES", ())
    if isinstance(configured, str):
        configured = configured.split(",")
    result = set()
    for value in configured or ():
        if isinstance(value, date):
            result.add(value)
            continue
        try:
            result.add(date.fromisoformat(str(value).strip()))
        except ValueError:
            continue
    return frozenset(result)


def subtract_workdays(value, workdays, holidays=None):
    if value is None:
        return None
    holidays = set(
        configured_non_working_dates() if holidays is None else holidays
    )
    remaining = max(int(workdays or 0), 0)
    result = value
    while remaining:
        result -= timedelta(days=1)
        if result.weekday() < 5 and result not in holidays:
            remaining -= 1
    return result


def next_workday(value, holidays=None):
    """Pomjeri administrativni datum unaprijed na prvi radni dan."""
    if value is None:
        return None
    holidays = set(
        configured_non_working_dates() if holidays is None else holidays
    )
    result = value
    while result.weekday() >= 5 or result in holidays:
        result += timedelta(days=1)
    return result


def last_actual_commission_date():
    cycle_date = (
        KomisijskiCiklus.objects.filter(
            datum_odobrenja__isnull=False,
            tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI,
        )
        .order_by("-datum_odobrenja", "-id")
        .values_list("datum_odobrenja", flat=True)
        .first()
    )
    if cycle_date:
        return cycle_date
    return (
        Komisija.objects.filter(datum_odobrenja__isnull=False)
        .exclude(trebovanja__tip_zahtjeva=Trebovanje.TIP_VANREDNI)
        .order_by("-datum_odobrenja", "-id")
        .values_list("datum_odobrenja", flat=True)
        .first()
    )


def _active_cycle():
    return (
        KomisijskiCiklus.objects.filter(
            tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI,
        )
        .exclude(status__in=FINAL_CYCLE_STATUSES)
        # Više unaprijed kreiranih nacrta ne smije učiniti najnovije
        # kreirani, kasniji ciklus "trenutnim". Otvoreni ciklus je prvi
        # nezavršeni redovni ciklus u zajedničkom komisijskom kalendaru.
        .order_by(
            F("datum_komisije").asc(nulls_last=True),
            "datum_kreiranja",
            "id",
        )
        .first()
    )


def _cycle_preparation_deadline(cycle, commission_date, settings):
    if cycle and cycle.rok_pripreme_dokumentacije:
        return cycle.rok_pripreme_dokumentacije
    if not commission_date:
        return None
    return subtract_workdays(
        commission_date,
        settings.priprema_zahtjeva_radnih_dana,
    )


def _cycle_status_label(cycle, *, today, preparation_deadline):
    if not cycle:
        return (
            "Priprema nije počela"
            if preparation_deadline and today < preparation_deadline
            else "Vrijeme je za pripremu"
        )
    if cycle.status in FINAL_CYCLE_STATUSES:
        return "Završeno"
    if cycle.status in {
        "PREDATO",
        "poslano_komisiji",
        "ceka_saglasnosti",
        "djelimicno_zaprimljene_saglasnosti",
    }:
        return "Predato komisiji"
    if cycle.status in {
        "ODOBRENO",
        "CEKA_ISPORUKU",
        "DJELOMICNO_ZAPRIMLJENO",
    }:
        return cycle.get_status_display()
    return "Priprema u toku"


def commission_cycle_overview(*, today=None, schedule=None, settings=None):
    """Jedinstveni prezentacijski model trenutnog i sljedećeg ciklusa.

    Isti eksplicitni ``KomisijskiCiklus`` zapisi i administrativni raspored
    koriste se u zaglavlju, rokovima i oznakama pacijentovog plana. Funkcija
    ne računa potrebu niti količine pacijenata.
    """

    today = today or timezone.localdate()
    settings = settings or get_settings()
    schedule = schedule or get_commission_schedule(
        today=today,
        settings=settings,
    )
    current_cycle = _active_cycle()
    current_date = current_cycle.datum_komisije if current_cycle else None
    current_deadline = _cycle_preparation_deadline(
        current_cycle,
        current_date,
        settings,
    )

    if current_cycle:
        following_cycles = (
            KomisijskiCiklus.objects.filter(
                tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI,
            )
            .exclude(pk=current_cycle.pk)
            .exclude(status__in=FINAL_CYCLE_STATUSES)
        )
        if current_date:
            following_cycles = following_cycles.filter(
                datum_komisije__gt=current_date,
            )
        ordered_following_cycles = following_cycles.order_by(
            F("datum_komisije").asc(nulls_last=True),
            "datum_kreiranja",
            "id",
        )

        # Potvrđeni datum iz postavki je administrativni source of truth za
        # naredni planirani ciklus. Ranije kreiran nacrt/simulacija ne smije ga
        # prepisati samo zato što ima raniji datum. Eksplicitni ciklus ostaje
        # vezan za prikaz samo kada odgovara potvrđenom datumu.
        confirmed_is_still_next = bool(
            schedule.confirmed_next_date
            and (not current_date or schedule.effective_next_date > current_date)
        )
        if confirmed_is_still_next:
            next_date = schedule.effective_next_date
            following_cycle = (
                ordered_following_cycles.filter(datum_komisije=next_date).first()
                if next_date else None
            )
        else:
            following_cycle = ordered_following_cycles.first()
            next_date = (
                following_cycle.datum_komisije if following_cycle else None
            )
            if not next_date:
                next_date = schedule.effective_next_date
                while next_date and current_date and next_date <= current_date:
                    next_date = add_calendar_months(
                        next_date,
                        settings.komisijski_ciklus_mjeseci,
                    )
        if not next_date and current_date:
            next_date = add_calendar_months(
                current_date,
                settings.komisijski_ciklus_mjeseci,
            )
        next_deadline = (
            schedule.preparation_start_date
            if (
                confirmed_is_still_next
                and next_date == schedule.effective_next_date
            )
            else _cycle_preparation_deadline(
                following_cycle,
                next_date,
                settings,
            )
        )
        return {
            "has_current_cycle": True,
            "current_cycle": current_cycle,
            "current_date": current_date,
            "current_preparation_deadline": current_deadline,
            "current_status_label": _cycle_status_label(
                current_cycle,
                today=today,
                preparation_deadline=current_deadline,
            ),
            "next_cycle": following_cycle,
            "next_date": next_date,
            "next_preparation_deadline": next_deadline,
            "next_status_label": _cycle_status_label(
                None,
                today=today,
                preparation_deadline=next_deadline,
            ),
        }

    next_date = schedule.effective_next_date
    next_deadline = schedule.preparation_start_date
    return {
        "has_current_cycle": False,
        "current_cycle": None,
        "current_date": None,
        "current_preparation_deadline": None,
        "current_status_label": None,
        "next_cycle": None,
        "next_date": next_date,
        "next_preparation_deadline": next_deadline,
        "next_status_label": _cycle_status_label(
            None,
            today=today,
            preparation_deadline=next_deadline,
        ),
    }


def _phase(active_cycle, today, preparation_start, effective_date, expected_delivery):
    if active_cycle:
        mapping = {
            "SIMULACIJA": ("PREPARATION", "Pripremiti komisiju"),
            "PREDATO": ("SENT", "Zahtjevi poslani"),
            "ODOBRENO": ("APPROVED", "Komisija odobrila"),
            "CEKA_ISPORUKU": ("WAITING_DELIVERY", "Čeka se isporuka"),
            "DJELOMICNO_ZAPRIMLJENO": ("RECEIVING", "Čeka se ostatak isporuke"),
        }
        if active_cycle.status in mapping:
            code, label = mapping[active_cycle.status]
            if code == "WAITING_DELIVERY" and expected_delivery and today > expected_delivery:
                return "DELIVERY_LATE", "Isporuka kasni"
            return code, label

    if not effective_date:
        return "NO_REFERENCE", "Nije evidentirana prethodna komisija"
    if preparation_start and today < preparation_start:
        return "NOT_DUE", f"Pripremu započeti {preparation_start:%d/%m/%Y}."
    if today <= effective_date:
        return "PREPARATION", "Pripremiti komisiju"
    return "AWAITING_CONFIRMATION", "Potrebno je potvrditi novi datum komisije"


def get_commission_schedule(*, today=None, settings=None, holidays=None):
    today = today or timezone.localdate()
    if settings is None and holidays is None:
        return get_or_set(
            "commission_schedule",
            today,
            lambda: _get_commission_schedule_uncached(today=today),
        )
    return _get_commission_schedule_uncached(
        today=today,
        settings=settings,
        holidays=holidays,
    )


def _get_commission_schedule_uncached(*, today, settings=None, holidays=None):
    settings = settings or get_settings()
    last_actual = last_actual_commission_date()
    estimated = add_calendar_months(last_actual, settings.komisijski_ciklus_mjeseci)
    confirmed = settings.potvrdjeni_datum_naredne_komisije
    effective = next_workday(confirmed or estimated, holidays=holidays)
    preparation = subtract_workdays(
        effective,
        settings.priprema_zahtjeva_radnih_dana,
        holidays=holidays,
    )
    delivery = (
        next_workday(
            effective + timedelta(days=settings.vrijeme_isporuke_dana),
            holidays=holidays,
        )
        if effective
        else None
    )
    active_cycle = _active_cycle()
    delivery_confirmed = bool(
        active_cycle
        and active_cycle.datum_odobrenja
        and _cycle_has_pending_delivery(active_cycle)
    )
    if active_cycle and active_cycle.datum_odobrenja:
        delivery = expected_delivery_for_cycle(active_cycle, settings=settings)
    coverage_reference = (
        active_cycle.datum_odobrenja
        if active_cycle and active_cycle.datum_odobrenja
        else effective
    )
    following_commission = add_calendar_months(
        coverage_reference,
        settings.komisijski_ciklus_mjeseci,
    )
    need_coverage_end = (
        following_commission + timedelta(days=settings.vrijeme_isporuke_dana)
        if following_commission
        else delivery
    )
    phase_code, status_label = _phase(active_cycle, today, preparation, effective, delivery)
    return CommissionSchedule(
        last_actual_date=last_actual,
        estimated_next_date=estimated,
        confirmed_next_date=confirmed,
        effective_next_date=effective,
        preparation_start_date=preparation,
        expected_delivery_date=delivery,
        phase_code=phase_code,
        status_label=status_label,
        active_cycle=active_cycle,
        need_coverage_end_date=need_coverage_end,
        delivery_confirmed=delivery_confirmed,
    )


def expected_delivery_for_cycle(cycle, settings=None):
    settings = settings or get_settings()
    if not cycle:
        return None
    if cycle.najkasniji_ocekivani_datum_isporuke:
        return next_workday(cycle.najkasniji_ocekivani_datum_isporuke)
    reference_date = cycle.datum_komisije or cycle.datum_odobrenja
    if not reference_date:
        return None
    return next_workday(
        reference_date
        + timedelta(
            days=(
                settings.vrijeme_isporuke_dana
                + settings.sigurnosna_rezerva_dana
            )
        )
    )


def _cycle_has_pending_delivery(cycle):
    """Isporuka postoji samo za stvarno odobrenu, još nezaprimljenu količinu."""
    if not cycle or not getattr(cycle, "pk", None):
        return False
    return cycle.trebovanja.filter(
        status="ODOBRENO",
        odobrene_doze__isnull=False,
    ).filter(
        odobrene_doze__gt=F("zaprimljene_doze")
    ).exists()


def confirm_next_commission_date(value, *, user=None):
    settings = get_settings()
    previous = settings.potvrdjeni_datum_naredne_komisije
    settings.potvrdjeni_datum_naredne_komisije = value
    settings.save(update_fields=["potvrdjeni_datum_naredne_komisije"])
    upisi_log(
        user,
        "Promjena datuma naredne komisije",
        objekat=settings,
        opis=f"Potvrđeni datum naredne komisije: {previous or '-'} → {value or '-'}.",
    )
    return get_commission_schedule(settings=settings)


def approved_remaining_for_patient(pacijent):
    if not pacijent or not pacijent.lijek_id:
        return Decimal("0")
    return patient_commission_coverage(pacijent)["approved_remaining"]


def valid_commissions_for_patient(pacijent):
    if not pacijent or not pacijent.lijek_id:
        return []
    prefetched = getattr(pacijent, "_workflow_commissions", None)
    if prefetched is not None:
        medicine_ids = set(pacijent.lijek.equivalent_ids())
        return [item for item in prefetched if item.lijek_id in medicine_ids]
    return get_or_set(
        "valid_commissions_for_patient",
        (pacijent.pk, pacijent.lijek_id),
        lambda: list(
            Komisija.objects.filter(
                pacijent=pacijent,
                lijek_id__in=pacijent.lijek.equivalent_ids(),
                status__in=VALID_COMMISSION_STATUSES,
                preostale_doze__gt=0,
            ).order_by("datum_odobrenja", "id")
        ),
    )


def pending_approved_for_patient(pacijent):
    if not pacijent or not pacijent.lijek_id:
        return Decimal("0")
    total = Decimal("0")
    prefetched = getattr(pacijent, "_workflow_requests", None)
    if prefetched is not None:
        medicine_ids = set(pacijent.lijek.equivalent_ids())
        requests = [
            item for item in prefetched
            if item.status == "ODOBRENO"
            and item.lijek_id in medicine_ids
            and item.odobrene_doze is not None
            and item.komisija_id is None
        ]
    else:
        requests = Trebovanje.objects.filter(
            pacijent=pacijent,
            lijek_id__in=pacijent.lijek.equivalent_ids(),
            status="ODOBRENO",
            odobrene_doze__isnull=False,
            komisija__isnull=True,
        ).only("odobrene_doze", "zaprimljene_doze")
    for request in requests:
        total += max(
            Decimal("0"),
            Decimal(str(request.odobrene_doze or 0)) - Decimal(str(request.zaprimljene_doze or 0)),
        )
    return total


def patient_commission_coverage(pacijent):
    from .request_cache import get_or_set

    if not pacijent or not getattr(pacijent, "pk", None):
        return _patient_commission_coverage_uncached(pacijent)
    return get_or_set(
        "patient_commission_coverage",
        (pacijent.pk, pacijent.lijek_id),
        lambda: _patient_commission_coverage_uncached(pacijent),
    )


def _patient_commission_coverage_uncached(pacijent):
    """Vrati pacijentovo pokriće po izvoru bez dvostrukog brojanja.

    Aktivna rezervacija vezana za komisiju fizički predstavlja dio istih
    ``preostale_doze``. Taj povezani dio se zato prikazuje kao rezervisan u
    frižideru, a oduzima od doprinosa neiskorištenog odobrenog prava.
    Slobodna, neraspoređena zaliha lijeka nije pokriće konkretnog pacijenta.
    """
    from .inventory import inventory_position_for_patient

    if not pacijent or not pacijent.lijek_id:
        zero = Decimal("0")
        return {
            "approved_total": zero,
            "approved_remaining": zero,
            "unused_approved": zero,
            "physically_reserved": zero,
            "reserved_in_fridge": zero,
            "physically_available": zero,
            "at_patient": zero,
            "awaiting_delivery": zero,
            "approved_waiting_delivery": zero,
            "administratively_covered": zero,
            "physically_covered": zero,
            "linked_overlap_excluded": zero,
            "total_covered": zero,
        }

    medicine_ids = pacijent.lijek.equivalent_ids()
    commissions = list(valid_commissions_for_patient(pacijent))

    # Migracijski snapshot je kanonski zapis zatecenog prava. Operativno
    # izdavanje je u starijem workflowu moglo spustiti ``preostale_doze`` na
    # nulu iako su iste jedinice samo premjestene pacijentu. Za migracijsko
    # odobrenje zato uvijek vrijedi: odobreno - historijski iskoristeno.
    try:
        prefetched_snapshot = pacijent.migracijski_snapshot
    except MigracijskiSnapshotPacijenta.DoesNotExist:
        prefetched_snapshot = None
    snapshot = (
        prefetched_snapshot
        if prefetched_snapshot is not None
        and prefetched_snapshot.lijek_id in medicine_ids
        else None
    )
    migration_commission = None
    if snapshot is not None:
        migration_commission = (
            Komisija.objects.filter(
                pacijent=pacijent,
                lijek_id__in=medicine_ids,
                napomena__startswith="Migracijski",
            )
            .order_by("id")
            .first()
        )
        if (
            migration_commission is not None
            and all(item.pk != migration_commission.pk for item in commissions)
            and snapshot.preostalo_po_komisiji > 0
        ):
            commissions.append(migration_commission)

    from .inventory import patient_reservation_breakdown

    reservation_breakdown = patient_reservation_breakdown(
        pacijent,
        medicine_ids=medicine_ids,
    )
    reserved_total = reservation_breakdown["total_effective"]
    linked_overlap = reservation_breakdown["linked_overlap"]
    linked_by_commission = {}
    for item in reservation_breakdown["items"]:
        commission_id = item["commission_id"]
        if not commission_id:
            continue
        linked_by_commission[commission_id] = (
            linked_by_commission.get(commission_id, Decimal("0"))
            + Decimal(str(item["effective_quantity"] or 0))
        )

    physical = inventory_position_for_patient(pacijent)
    at_patient = Decimal(str(physical["at_patient"] or 0))
    prefetched_assignments = getattr(pacijent, "_workflow_assignments", None)
    if prefetched_assignments is not None:
        at_patient_by_commission = {}
        for assignment in prefetched_assignments:
            if (
                assignment.lijek_id not in medicine_ids
                or assignment.komisija_id is None
            ):
                continue
            at_patient_by_commission[assignment.komisija_id] = (
                at_patient_by_commission.get(
                    assignment.komisija_id,
                    Decimal("0"),
                )
                + Decimal(str(assignment.preostalo or 0))
            )
    else:
        at_patient_by_commission = {
            row["komisija_id"]: Decimal(str(row["total"] or 0))
            for row in PacijentZaduzenje.objects.filter(
                pacijent=pacijent,
                lijek_id__in=medicine_ids,
                aktivno=True,
                preostalo__gt=0,
                komisija_id__isnull=False,
            )
            .values("komisija_id")
            .annotate(total=Sum("preostalo"))
        }
    known_commission_ids = {item.pk for item in commissions}
    missing_assignment_commission_ids = set(at_patient_by_commission) - known_commission_ids
    if missing_assignment_commission_ids:
        commissions.extend(
            Komisija.objects.filter(pk__in=missing_assignment_commission_ids)
        )

    approved_total = Decimal("0")
    approved_raw = Decimal("0")
    unused_approved = Decimal("0")
    waiting_delivery = Decimal("0")
    linked_overlap = Decimal("0")
    for commission in commissions:
        is_migration = bool(
            migration_commission is not None
            and commission.pk == migration_commission.pk
        )
        if is_migration:
            right_remaining = Decimal(str(snapshot.preostalo_po_komisiji or 0))
            effective_status = (
                "ODOBRENA"
                if snapshot.status_preostalih_odobrenih_doza
                == snapshot.STATUS_PREOSTALIH_CEKA_ISPORUKU
                else "AKTIVNA"
            )
            physical_part = (
                linked_by_commission.get(commission.pk, Decimal("0"))
                + at_patient_by_commission.get(commission.pk, Decimal("0"))
            )
        else:
            stored_remaining = Decimal(str(commission.preostale_doze or 0))
            issued_but_not_applied = at_patient_by_commission.get(
                commission.pk,
                Decimal("0"),
            )
            right_remaining = min(
                Decimal(str(commission.broj_odobrenih_doza or 0)),
                stored_remaining + issued_but_not_applied,
            )
            effective_status = (
                "AKTIVNA"
                if issued_but_not_applied > 0
                and commission.status == "POTROSENA"
                else commission.status
            )
            # I rezervacija i doza kod pacijenta su fizicki podskup istog
            # preostalog prava. Stariji workflow je izdavanje vec odbijao iz
            # DB salda, pa ga gore vracamo samo radi kanonskog presjeka.
            physical_part = (
                linked_by_commission.get(commission.pk, Decimal("0"))
                + issued_but_not_applied
            )

        unphysical = max(Decimal("0"), right_remaining - physical_part)
        linked_overlap += min(right_remaining, physical_part)
        if effective_status == "AKTIVNA":
            approved_total += Decimal(str(commission.broj_odobrenih_doza or 0))
            approved_raw += right_remaining
            unused_approved += unphysical
        elif effective_status in {"BUDUCA", "ODOBRENA"}:
            waiting_delivery += unphysical

    waiting_delivery += pending_approved_for_patient(pacijent)
    total_covered = unused_approved + reserved_total + at_patient + waiting_delivery
    return {
        "approved_total": approved_total,
        "approved_remaining": approved_raw,
        "unused_approved": unused_approved,
        "physically_reserved": reserved_total,
        "reserved_in_fridge": reserved_total,
        "physically_available": reserved_total + at_patient,
        "at_patient": at_patient,
        "awaiting_delivery": waiting_delivery,
        "approved_waiting_delivery": waiting_delivery,
        "administratively_covered": unused_approved + waiting_delivery,
        "physically_covered": reserved_total + at_patient,
        "linked_overlap_excluded": linked_overlap,
        "total_covered": total_covered,
    }


def commission_need_coverage_end(*, schedule, today, settings=None):
    """Vrati horizont potreban do isporuke narednog ciklusa.

    Zahtjev koji se sada priprema mora pokriti pacijenta i nakon isporuke tog
    ciklusa, sve dok lijek iz sljedećeg redovnog ciklusa realno može stići.
    Inače bi prva terapija poslije trenutne isporuke mogla ostati nepokrivena.
    """
    if schedule.need_coverage_end_date:
        return schedule.need_coverage_end_date
    # Ručno konstruisani rasporedi (npr. simulacija ili postojeće integracije)
    # nemaju parametre ciklusa. Njihov eksplicitni datum isporuke ostaje
    # autoritativan umjesto da se miješa s globalnim postavkama.
    if schedule.expected_delivery_date:
        return schedule.expected_delivery_date
    settings = settings or get_settings()
    reference_commission = schedule.effective_next_date
    if reference_commission:
        following_commission = add_calendar_months(
            reference_commission,
            settings.komisijski_ciklus_mjeseci,
        )
        if following_commission:
            return following_commission + timedelta(
                days=settings.vrijeme_isporuke_dana
            )
    fallback = add_calendar_months(today, settings.komisijski_ciklus_mjeseci)
    return fallback + timedelta(days=settings.vrijeme_isporuke_dana)


def commission_action_state(*, schedule, today, patient_coverage_end, calculated_quantity):
    """Odvoji buduću matematičku potrebu od trenutno aktivne komisijske akcije.

    Prije definisanog početka pripreme zahtjev se aktivira samo ako postojeće
    pacijentovo pokriće ne doseže očekivanu isporuku narednog ciklusa. Datum
    očekivane isporuke je sigurnosna granica: do tada nova količina još ne bi
    bila fizički dostupna pacijentu.
    """
    calculated_quantity = Decimal(str(calculated_quantity or 0))
    if calculated_quantity <= 0:
        return False, "Trenutno pokriće zadovoljava planski horizont."

    preparation_start = schedule.preparation_start_date
    if preparation_start and today < preparation_start:
        expected_delivery = schedule.expected_delivery_date
        coverage_is_safe = bool(
            patient_coverage_end
            and expected_delivery
            and patient_coverage_end >= expected_delivery
        )
        if coverage_is_safe:
            return (
                False,
                f"Pripremu započeti {preparation_start:%d/%m/%Y}.; "
                f"pacijent je pokriven do {patient_coverage_end:%d/%m/%Y}.",
            )
        return (
            True,
            "Potrebna je ranija priprema jer postojeće pokriće ne doseže "
            "očekivanu isporuku narednog ciklusa.",
        )

    return True, "Dosegnut je definisani period pripreme komisije."


def _base_patient_commission_need(pacijent, *, schedule, today):
    coverage_end = commission_need_coverage_end(
        schedule=schedule,
        today=today,
    )
    weeks = max(ceil(max((coverage_end - today).days, 1) / 7), 1)
    planning = pacijent.potrebe_za_period(weeks)
    # ``doze_za_period`` je javni kanonski ulaz koji koriste simulacija i
    # postojeće integracije. Detaljni plan ispod samo objašnjava isti period.
    total_needed = Decimal(str(pacijent.doze_za_period(weeks) or 0))
    protocol_start_date = (
        today
        if pacijent.pocetna_faza_terapije == Pacijent.FAZA_INDUKCIJA
        and pacijent.broj_dosadasnjih_aplikacija() == 0
        else None
    )
    planned_therapies = []
    for item in planning.get("planirane_terapije", []):
        planned = dict(item)
        relative_week = int(planned.get("relativna_sedmica") or 0)
        planned["datum"] = today + timedelta(weeks=relative_week)
        planned_therapies.append(planned)
    approved_remaining = approved_remaining_for_patient(pacijent)
    coverage = patient_commission_coverage(pacijent)
    covered = coverage["total_covered"]
    net_required = max(Decimal("0"), total_needed - covered)
    calculated_requested = round_up_to_package(net_required, pacijent.lijek)
    patient_coverage_end, _coverage_source = pacijent.izracunaj_pokriven_do(
        covered,
        fallback_date=today,
    )
    action_due, action_reason = commission_action_state(
        schedule=schedule,
        today=today,
        patient_coverage_end=patient_coverage_end,
        calculated_quantity=calculated_requested,
    )
    requested = calculated_requested if action_due else Decimal("0")
    procurement = procurement_breakdown(requested, pacijent.lijek)
    return {
        "ukupno_potrebno": total_needed,
        "trenutno_dostupno": covered,
        "vec_pokriveno": covered,
        "izracunata_potreba": net_required,
        "neto_potreba": net_required,
        "matematicka_kolicina_za_komisiju": calculated_requested,
        "za_novu_komisiju": requested,
        "kolicina_za_komisiju": requested,
        "komisijska_akcija_aktivna": action_due,
        "komisijska_akcija_razlog": action_reason,
        "datum_aktivacije_komisije": schedule.preparation_start_date,
        "pokriven_do_pacijenta": patient_coverage_end,
        "broj_pakovanja": procurement["package_count"],
        "velicina_pakovanja": procurement["units_per_package"],
        "nabavka_komisije": procurement,
        "planirani_koraci": planning.get("planirani_koraci", []),
        "planirane_terapije": planned_therapies,
        "datum_pocetka_obracuna": today,
        "datum_pocetka_protokola": protocol_start_date,
        "datum_pocetka_protokola_izvor": (
            "Početak indukcije jednak je početku obračuna."
            if protocol_start_date
            else "Datum početka protokola nije pouzdano evidentiran."
        ),
        "period_sedmica": weeks,
        "pokrice_do": coverage_end,
        "odobreno_preostalo": approved_remaining,
        "odobreno_ceka_isporuku": coverage["approved_waiting_delivery"],
        "pravno_pokrice": coverage["unused_approved"] + coverage["approved_waiting_delivery"],
        "fizicki_dodijeljeno": coverage["reserved_in_fridge"] + coverage["at_patient"],
        "coverage": coverage,
        "slobodna_zaliha_dodijeljena_izracunom": Decimal("0"),
    }


def commission_needs_by_patient(*, schedule=None, today=None, patients=None):
    """Izračunaj potrebe samo iz pokrića koje pripada konkretnom pacijentu."""
    today = today or timezone.localdate()
    schedule = schedule or get_commission_schedule(today=today)
    if patients is None:
        from .querysets import with_workflow_data

        patients = with_workflow_data(Pacijent.objects.filter(
            aktivan=True, lijek__isnull=False
        ).exclude(pauze_terapije__aktivna=True)).order_by("lijek_id", "id")
    patients = list(patients)
    result = {}
    for patient in patients:
        cache_key = (
            patient.pk,
            patient.lijek_id,
            today,
            schedule.effective_next_date,
            schedule.preparation_start_date,
            schedule.expected_delivery_date,
            schedule.need_coverage_end_date,
        )
        result[patient.pk] = get_or_set(
            "patient_commission_need",
            cache_key,
            lambda patient=patient: _base_patient_commission_need(
                patient,
                schedule=schedule,
                today=today,
            ),
        )
    return result


def calculate_patient_commission_need(pacijent, *, schedule=None, today=None):
    if not pacijent or not pacijent.pk or not pacijent.lijek_id or pacijent.na_aktivnoj_pauzi():
        return {
            "ukupno_potrebno": Decimal("0"),
            "trenutno_dostupno": Decimal("0"),
            "vec_pokriveno": Decimal("0"),
            "za_novu_komisiju": Decimal("0"),
            "kolicina_za_komisiju": Decimal("0"),
            "izracunata_potreba": Decimal("0"),
            "neto_potreba": Decimal("0"),
            "matematicka_kolicina_za_komisiju": Decimal("0"),
            "komisijska_akcija_aktivna": False,
            "komisijska_akcija_razlog": "Nema aktivnog pacijenta ili protokola za obračun.",
            "datum_aktivacije_komisije": None,
            "pokriven_do_pacijenta": None,
            "broj_pakovanja": 0,
            "velicina_pakovanja": 1,
            "planirani_koraci": [],
            "planirane_terapije": [],
            "datum_pocetka_obracuna": today or timezone.localdate(),
            "datum_pocetka_protokola": None,
            "datum_pocetka_protokola_izvor": "Nema aktivnog protokola za obračun.",
            "odobreno_preostalo": Decimal("0"),
            "odobreno_ceka_isporuku": Decimal("0"),
            "pravno_pokrice": Decimal("0"),
            "fizicki_dodijeljeno": Decimal("0"),
            "coverage": {
                "unused_approved": Decimal("0"),
                "reserved_in_fridge": Decimal("0"),
                "at_patient": Decimal("0"),
                "approved_waiting_delivery": Decimal("0"),
                "linked_overlap_excluded": Decimal("0"),
                "total_covered": Decimal("0"),
            },
            "slobodna_zaliha_dodijeljena_izracunom": Decimal("0"),
        }
    # Potreba je pacijent-specifična. Ranije se za svaki poziv ponovo računala
    # cijela terapijska grupa, pa je petlja kroz pacijente imala kvadratnu
    # složenost i hiljade identičnih upita. Grupni API ostaje dostupan za
    # ekrane koji zaista obrađuju više pacijenata odjednom.
    today = today or timezone.localdate()
    schedule = schedule or get_commission_schedule(today=today)
    cache_key = (
        pacijent.pk,
        pacijent.lijek_id,
        today,
        schedule.effective_next_date,
        schedule.preparation_start_date,
        schedule.expected_delivery_date,
        schedule.need_coverage_end_date,
    )
    return get_or_set(
        "patient_commission_need",
        cache_key,
        lambda: _base_patient_commission_need(
            pacijent,
            schedule=schedule,
            today=today,
        ),
    )


def patients_for_next_commission(*, schedule=None, today=None):
    today = today or timezone.localdate()
    schedule = schedule or get_commission_schedule(today=today)
    result = []
    from .querysets import with_workflow_data

    patients = list(with_workflow_data(
        Pacijent.objects.filter(aktivan=True, lijek__isnull=False).exclude(
            pauze_terapije__aktivna=True
        )
    ).order_by("lijek_id", "id"))
    needs = commission_needs_by_patient(
        schedule=schedule,
        today=today,
        patients=patients,
    )
    for patient in patients:
        need = needs[patient.pk]
        if need["za_novu_komisiju"] > 0:
            result.append({"pacijent": patient, "lijek": patient.lijek, **need})
    from django.core.cache import cache

    cache.set("theraflow:sidebar:commission-count:v1", len(result), 30)
    return result


def _requests_for_update(request_ids):
    """Queryset koji zaključava isključivo osnovne Trebovanje redove."""
    queryset = Trebovanje.objects.filter(
        pk__in=request_ids,
    ).exclude(
        status="PREDATO",
    ).order_by("pk")
    return select_for_update_self(queryset)


def lock_cycle_receipt_rows(cycle_id, request_ids):
    """Serijalizuj zaprimanje: ciklus, pa njegova trebovanja stabilnim redom.

    Funkcija se poziva unutar jednog ``transaction.atomic()`` bloka. Ne učitava
    opcione komisijske relacije JOIN-om; njih zaključava konkretni receipt
    servis tek ako FK stvarno postoji.
    """

    if not connection.in_atomic_block:
        raise RuntimeError("Lock zaprimanja mora biti unutar transaction.atomic().")
    # Osnovni red ciklusa nema JOIN niti DISTINCT i prvi je u stabilnom
    # redoslijedu zaključavanja za svako zaprimanje.
    cycle = KomisijskiCiklus.objects.select_for_update().get(pk=cycle_id)
    normalized_ids = sorted({int(request_id) for request_id in request_ids})

    # Kandidati se namjerno materijalizuju prije locking SELECT-a. Ovaj prvi
    # upit smije koristiti DISTINCT jer nema FOR UPDATE. Ne prenosimo njegov
    # Query objekat u sljedeći korak: custom manager, JOIN ili naknadni helper
    # zato ne mogu ostaviti ``query.distinct=True`` na locking upitu.
    candidate_ids = list(
        Trebovanje.objects.filter(
            pk__in=normalized_ids,
            komisijski_ciklus_id=cycle.pk,
        )
        .order_by()
        .values_list("pk", flat=True)
        .distinct()
    )

    requests_qs = select_for_update_self(
        Trebovanje.objects.filter(
            pk__in=candidate_ids,
            komisijski_ciklus_id=cycle.pk,
        ).order_by("pk")
    )
    assert requests_qs.query.distinct is False, str(requests_qs.query)
    requests = list(requests_qs)
    return cycle, requests


@transaction.atomic
def mark_requests_sent(requests, *, sent_date=None, user=None):
    sent_date = sent_date or timezone.localdate()
    request_ids = list(requests.values_list("pk", flat=True))
    requests = list(_requests_for_update(request_ids))
    if any(Decimal(str(request.broj_doza or 0)) <= 0 for request in requests):
        raise ValueError(
            "Komisijski zahtjev sa količinom 0 nije moguće predati."
        )
    if any(
        request.tip_zahtjeva == Trebovanje.TIP_VANREDNI
        and request.status != Trebovanje.STATUS_SPREMAN
        for request in requests
    ):
        raise ValueError(
            "Vanredni zahtjev mora biti spreman prije slanja komisiji."
        )
    cycle_ids = {request.komisijski_ciklus_id for request in requests if request.komisijski_ciklus_id}
    for request in requests:
        request.status = (
            Trebovanje.STATUS_POSLAN_KOMISIJI
            if request.tip_zahtjeva == Trebovanje.TIP_VANREDNI
            else "PREDATO"
        )
        request.save(update_fields=["status"])
        if request.tip_zahtjeva == Trebovanje.TIP_VANREDNI:
            upisi_log(
                user,
                "Vanredni zahtjev poslan komisiji",
                pacijent=request.pacijent,
                objekat=request,
                opis=f"{request.komisijski_ciklus}: SPREMAN → POSLAN_KOMISIJI.",
            )
    for cycle in KomisijskiCiklus.objects.select_for_update().filter(id__in=cycle_ids).order_by("pk"):
        previous = cycle.status
        cycle.status = "PREDATO"
        cycle.datum_predaje = sent_date
        cycle.save(update_fields=["status", "datum_predaje"])
        upisi_log(
            user,
            "Komisijski ciklus predat",
            objekat=cycle,
            opis=f"{cycle.naziv}: {previous} → PREDATO; datum slanja {sent_date}.",
        )
    return len(requests)


@transaction.atomic
def approve_cycle(cycle, approved_quantities, actual_date, *, user=None, approval_number=""):
    cycle = KomisijskiCiklus.objects.select_for_update().get(pk=cycle.pk)
    if cycle.status not in ("PREDATO", "ODOBRENO", "CEKA_ISPORUKU"):
        raise ValueError("Komisijski ciklus nije u fazi u kojoj se može evidentirati odobrenje.")

    locked_requests = select_for_update_self(
        cycle.trebovanja.select_related("pacijent", "lijek")
    )
    for request in locked_requests:
        if Decimal(str(request.broj_doza or 0)) <= 0:
            raise ValueError(
                "Komisijski zahtjev sa količinom 0 nije moguće odobriti."
            )
        approved = Decimal(str(approved_quantities.get(request.id, request.broj_doza) or 0))
        if approved < 0:
            raise ValueError("Odobrena količina ne može biti negativna.")
        validate_package_multiple(
            approved,
            request.lijek,
            label="Odobrena količina",
        )
        request.odobrene_doze = approved
        if approved == 0:
            request.status = "ODBIJENO"
            if request.komisija_id:
                commission = Komisija.objects.select_for_update().get(
                    pk=request.komisija_id
                )
                commission.preostale_doze = Decimal("0")
                commission.status = "PONISTENA"
                commission.save(update_fields=["preostale_doze", "status"])
            request.save(update_fields=["odobrene_doze", "status"])
            upisi_log(
                user,
                "Komisijski zahtjev odbijen",
                pacijent=request.pacijent,
                objekat=request,
                opis=(
                    f"{cycle.naziv}: traženo {request.broj_doza}, odobreno 0 "
                    "doza. Zaliha, zaduženje i termin nisu kreirani."
                ),
            )
            continue
        request.status = (
            Trebovanje.STATUS_DJELOMICNO_ODOBRENO
            if (
                request.tip_zahtjeva == Trebovanje.TIP_VANREDNI
                and approved < Decimal(str(request.broj_doza or 0))
            )
            else "ODOBRENO"
        )
        defaults = {
            "pacijent": request.pacijent,
            "lijek": request.lijek,
            "datum_odobrenja": actual_date,
            "datum_isteka": None,
            "broj_odobrenih_doza": approved,
            "preostale_doze": approved,
            "status": "ODOBRENA",
            "broj_saglasnosti": approval_number,
            "napomena": f"Odobreno kroz komisijski ciklus {cycle.naziv}.",
        }
        if request.komisija_id:
            commission = Komisija.objects.select_for_update().get(pk=request.komisija_id)
            for field, value in defaults.items():
                setattr(commission, field, value)
            commission.save(update_fields=list(defaults))
        else:
            commission = Komisija.objects.create(**defaults)
        request.komisija = commission
        request.save(update_fields=["odobrene_doze", "status", "komisija"])
        upisi_log(
            user,
            "Unesena odobrena količina",
            pacijent=request.pacijent,
            objekat=request,
            opis=f"{cycle.naziv}: traženo {request.broj_doza}, odobreno {approved} doza.",
        )

    cycle.datum_odobrenja = actual_date
    if not cycle.datum_komisije:
        cycle.datum_komisije = actual_date
    cycle.status = "ODOBRENO"
    cycle.save(update_fields=["datum_odobrenja", "datum_komisije", "status"])
    upisi_log(
        user,
        "Komisija odobrila zahtjeve",
        objekat=cycle,
        opis=f"{cycle.naziv}: stvarni datum komisije {actual_date}; unesene odobrene količine.",
    )
    return cycle


@transaction.atomic
def mark_cycle_waiting_delivery(cycle, *, user=None):
    cycle = KomisijskiCiklus.objects.select_for_update().get(pk=cycle.pk)
    if cycle.status not in ("ODOBRENO", "CEKA_ISPORUKU"):
        raise ValueError("Ciklus mora biti odobren prije čekanja isporuke.")
    previous = cycle.status
    cycle.status = "CEKA_ISPORUKU"
    cycle.save(update_fields=["status"])
    extraordinary_requests = cycle.trebovanja.filter(
        tip_zahtjeva=Trebovanje.TIP_VANREDNI,
        status__in=("ODOBRENO", Trebovanje.STATUS_DJELOMICNO_ODOBRENO),
    )
    for request in extraordinary_requests.select_for_update():
        request.status = Trebovanje.STATUS_CEKA_ISPORUKU
        request.save(update_fields=["status"])
        upisi_log(
            user,
            "Vanredni zahtjev čeka isporuku",
            pacijent=request.pacijent,
            objekat=request,
            opis=f"{cycle.naziv}: odobrenje evidentirano; zahtjev čeka isporuku.",
        )
    if previous != cycle.status:
        upisi_log(
            user,
            "Komisijski ciklus čeka isporuku",
            objekat=cycle,
            opis=f"{cycle.naziv}: {previous} → CEKA_ISPORUKU; očekivana isporuka "
                 f"{expected_delivery_for_cycle(cycle) or '-'}.",
        )
    return cycle


@transaction.atomic
def complete_cycle(cycle, *, receipt_date=None, user=None):
    """Zatvori ciklus i stvarni datum komisije učini referencom narednog ciklusa."""
    receipt_date = receipt_date or timezone.localdate()
    cycle = KomisijskiCiklus.objects.select_for_update().get(pk=cycle.pk)
    if cycle.trebovanja.exclude(status="ZAPRIMLJENO").exists():
        cycle.status = "DJELOMICNO_ZAPRIMLJENO"
        cycle.save(update_fields=["status"])
        return cycle

    cycle.status = "ZAPRIMLJENO"
    cycle.datum_zaprimanja = receipt_date
    cycle.save(update_fields=["status", "datum_zaprimanja"])

    from .adaptive_assistant import observe_operational_outcomes_safely

    observe_operational_outcomes_safely(
        cycle,
        actual_delivery_date=receipt_date,
    )

    if cycle.tip_ciklusa == KomisijskiCiklus.TIP_VANREDNI:
        return cycle

    settings = get_settings()
    if (
        settings.potvrdjeni_datum_naredne_komisije
        and cycle.datum_odobrenja
        and settings.potvrdjeni_datum_naredne_komisije <= cycle.datum_odobrenja
    ):
        previous = settings.potvrdjeni_datum_naredne_komisije
        settings.potvrdjeni_datum_naredne_komisije = None
        settings.save(update_fields=["potvrdjeni_datum_naredne_komisije"])
        upisi_log(
            user,
            "Završen komisijski ciklus",
            objekat=cycle,
            opis=f"{cycle.naziv}: zaprimanje završeno {receipt_date}; potvrđeni datum "
                 f"{previous} je iskorišten i novi datum će biti procijenjen iz stvarne komisije.",
        )
    return cycle
