@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "SERVICE_NAME=TheraFlow"
set "DB_SERVICE=TheraFlowPostgres"
set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%..\..") do set "INSTALL_ROOT=%%~fI"
set "APP_ROOT=%INSTALL_ROOT%\app"
set "PROGRAM_DATA=%ProgramData%\TheraFlow"
set "PYTHON_EXE=%PROGRAM_DATA%\runtime\venv\Scripts\python.exe"
set "APP_SCRIPT=%APP_ROOT%\run_theraflow.py"
set "ENV_FILE=%PROGRAM_DATA%\config\.env"
set "LOG_DIR=%PROGRAM_DATA%\logs\application"
set "INSTALLER_LOG=%PROGRAM_DATA%\logs\install_runtime.log"
set "STDOUT_LOG=%LOG_DIR%\service_output.log"
set "STDERR_LOG=%LOG_DIR%\service_error.log"
set "NSSM_EXE=%INSTALL_ROOT%\runtime\nssm\nssm.exe"
set "SERVICE_PID="

if /I "%~1"=="--self-test" goto self_test

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1
call :log "Configuring TheraFlow Application service."

call :require_file "%PYTHON_EXE%" "private Python virtual environment"
if errorlevel 1 exit /b 1
call :require_file "%APP_SCRIPT%" "Waitress entry point"
if errorlevel 1 exit /b 1
call :require_file "%ENV_FILE%" "canonical production environment"
if errorlevel 1 exit /b 1
call :require_file "%NSSM_EXE%" "NSSM runtime"
if errorlevel 1 exit /b 1

sc query "%DB_SERVICE%" >nul 2>&1
if errorlevel 1 (
    call :log "ERROR: Required database service %DB_SERVICE% does not exist."
    exit /b 1
)

sc query "%SERVICE_NAME%" >nul 2>&1
if not errorlevel 1 (
    sc qc "%SERVICE_NAME%" | findstr /I /L /C:"%NSSM_EXE%" >nul 2>&1
    if errorlevel 1 (
        call :log "ERROR: Same-named service is not owned by this TheraFlow installation; refusing to modify it."
        exit /b 1
    )
    call :safe_stop_service
    if errorlevel 1 exit /b 1
) else (
    "%NSSM_EXE%" install "%SERVICE_NAME%" "%PYTHON_EXE%" >> "%INSTALLER_LOG%" 2>&1
    if errorlevel 1 exit /b 1
)

call :nssm_set Application "%PYTHON_EXE%"
if errorlevel 1 exit /b 1
call :nssm_set AppDirectory "%APP_ROOT%"
if errorlevel 1 exit /b 1
call :nssm_set AppParameters "run_theraflow.py"
if errorlevel 1 exit /b 1
call :nssm_set DisplayName "TheraFlow Application"
if errorlevel 1 exit /b 1
call :nssm_set Description "TheraFlow application served locally by Waitress."
if errorlevel 1 exit /b 1
call :nssm_set Start SERVICE_AUTO_START
if errorlevel 1 exit /b 1
call :nssm_set ObjectName LocalSystem
if errorlevel 1 exit /b 1
call :nssm_set DependOnService "%DB_SERVICE%"
if errorlevel 1 exit /b 1
call :nssm_set AppStdout "%STDOUT_LOG%"
if errorlevel 1 exit /b 1
call :nssm_set AppStderr "%STDERR_LOG%"
if errorlevel 1 exit /b 1
call :nssm_set AppRotateFiles 1
if errorlevel 1 exit /b 1
call :nssm_set AppRotateOnline 1
if errorlevel 1 exit /b 1
call :nssm_set AppRotateSeconds 86400
if errorlevel 1 exit /b 1
call :nssm_set AppRotateBytes 10485760
if errorlevel 1 exit /b 1
"%NSSM_EXE%" set "%SERVICE_NAME%" AppEnvironmentExtra "THERAFLOW_PRODUCTION=1" "THERAFLOW_ENV_FILE=%ENV_FILE%" "PYTHONUNBUFFERED=1" >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1
"%NSSM_EXE%" set "%SERVICE_NAME%" AppExit Default Restart >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1
call :nssm_set AppRestartDelay 5000
if errorlevel 1 exit /b 1

sc.exe config "%SERVICE_NAME%" start= auto depend= "%DB_SERVICE%" DisplayName= "TheraFlow Application" >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1
sc.exe failure "%SERVICE_NAME%" reset= 86400 actions= restart/5000/restart/15000/""/0 >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1
sc.exe failureflag "%SERVICE_NAME%" 1 >> "%INSTALLER_LOG%" 2>&1

sc.exe start "%DB_SERVICE%" >> "%INSTALLER_LOG%" 2>&1
call :wait_for_named_state "%DB_SERVICE%" RUNNING 60
if errorlevel 1 exit /b 1
"%NSSM_EXE%" start "%SERVICE_NAME%" >> "%INSTALLER_LOG%" 2>&1
call :wait_for_named_state "%SERVICE_NAME%" RUNNING 60
if errorlevel 1 exit /b 1
call :log "TheraFlow Application service is RUNNING and depends on TheraFlowPostgres."
call "%SCRIPT_DIR%install_updater_service.bat"
if errorlevel 1 (
    call :log "ERROR: TheraFlowUpdaterService installation failed."
    exit /b 1
)
call :log "TheraFlowUpdaterService restricted service is RUNNING."
exit /b 0

:self_test
set "NSSM_SET_TEST_MODE=1"
set "NSSM_SELFTEST_OPTION="
set "NSSM_SELFTEST_VALUE="
call :nssm_set AppDirectory "C:\Program Files\TheraFlow Self Test\app"
if errorlevel 1 exit /b 1
if not "%NSSM_SELFTEST_OPTION%"=="AppDirectory" (
    echo INSTALL_SERVICE_SELF_TEST_FAIL option
    exit /b 1
)
if not "%NSSM_SELFTEST_VALUE%"=="C:\Program Files\TheraFlow Self Test\app" (
    echo INSTALL_SERVICE_SELF_TEST_FAIL value
    exit /b 1
)
echo INSTALL_SERVICE_SELF_TEST_PASS
exit /b 0

:safe_stop_service
sc query "%SERVICE_NAME%" | find /I "STOPPED" >nul 2>&1
if not errorlevel 1 exit /b 0
"%NSSM_EXE%" stop "%SERVICE_NAME%" >> "%INSTALLER_LOG%" 2>&1
call :wait_for_named_state "%SERVICE_NAME%" STOPPED 45
if not errorlevel 1 exit /b 0
for /f "tokens=2 delims=:" %%P in ('sc queryex "%SERVICE_NAME%" ^| findstr /I "PID"') do set "SERVICE_PID=%%P"
set "SERVICE_PID=%SERVICE_PID: =%"
echo %SERVICE_PID%| findstr /R "^[0-9][0-9]*$" >nul 2>&1
if errorlevel 1 exit /b 1
if "%SERVICE_PID%"=="0" exit /b 1
taskkill /PID %SERVICE_PID% /F /T >> "%INSTALLER_LOG%" 2>&1
call :wait_for_named_state "%SERVICE_NAME%" STOPPED 30
exit /b %ERRORLEVEL%

:wait_for_named_state
set "WAIT_SERVICE=%~1"
set "WAIT_STATE=%~2"
set "WAIT_SECONDS=%~3"
for /l %%I in (1,1,%WAIT_SECONDS%) do (
    sc query "%WAIT_SERVICE%" | find /I "%WAIT_STATE%" >nul 2>&1
    if not errorlevel 1 exit /b 0
    timeout /t 1 /nobreak >nul
)
call :log "ERROR: Service %WAIT_SERVICE% did not reach %WAIT_STATE%."
exit /b 1

:require_file
if not exist "%~1" (
    call :log "ERROR: %~2 not found: %~1"
    exit /b 1
)
exit /b 0

:nssm_set
if "%~1"=="" (
    if not defined NSSM_SET_TEST_MODE call :log "ERROR: Missing NSSM option name."
    exit /b 2
)
if "%~2"=="" (
    if not defined NSSM_SET_TEST_MODE call :log "ERROR: Missing value for NSSM option %~1."
    exit /b 2
)
if defined NSSM_SET_TEST_MODE (
    set "NSSM_SELFTEST_OPTION=%~1"
    set "NSSM_SELFTEST_VALUE=%~2"
    exit /b 0
)
"%NSSM_EXE%" set "%SERVICE_NAME%" "%~1" "%~2" >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 (
    call :log "ERROR: Could not set NSSM option %~1."
    exit /b 1
)
exit /b 0

:log
>> "%INSTALLER_LOG%" echo [%DATE% %TIME%] %~1
exit /b 0
