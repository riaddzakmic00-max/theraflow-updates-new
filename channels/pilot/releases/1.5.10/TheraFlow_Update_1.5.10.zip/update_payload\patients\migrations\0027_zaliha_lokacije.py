from decimal import Decimal

from django.db import migrations, models
from django.db.models import Sum


def migrate_zaliha_lokacije(apps, schema_editor):
    Zaliha = apps.get_model("patients", "Zaliha")
    PacijentZaduzenje = apps.get_model("patients", "PacijentZaduzenje")

    for zaliha in Zaliha.objects.all():
        kod_pacijenata = (
            PacijentZaduzenje.objects.filter(
                lijek_id=zaliha.lijek_id,
                aktivno=True,
                preostalo__gt=0,
            ).aggregate(total=Sum("preostalo"))["total"]
            or Decimal("0")
        )
        zaliha.u_frizideru = zaliha.ukupno or Decimal("0")
        zaliha.kod_pacijenata = kod_pacijenata
        zaliha.save(update_fields=["u_frizideru", "kod_pacijenata", "ukupno"])


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0026_lijek_unicode_labels"),
    ]

    operations = [
        migrations.AddField(
            model_name="zaliha",
            name="kod_pacijenata",
            field=models.DecimalField(decimal_places=2, default=0, max_digits=8),
        ),
        migrations.AddField(
            model_name="zaliha",
            name="u_frizideru",
            field=models.DecimalField(decimal_places=2, default=0, max_digits=8),
        ),
        migrations.RunPython(migrate_zaliha_lokacije, migrations.RunPython.noop),
    ]
