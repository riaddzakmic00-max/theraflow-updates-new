"""Kanonski operativni rizik zalihe za Zalihe, Dashboard i izvještaje."""

from datetime import timedelta
from decimal import Decimal

from django.db.models import F, Sum
from django.utils import timezone

from .commission_service import expected_delivery_for_cycle, get_commission_schedule
from .home_therapy import format_stock_quantity
from .medication_groups import equivalent_medicine_ids
from .models import Trebovanje
from .therapy_regimens import TYPE_ORAL


class StockRiskService:
    """Objedinjuje fizičko stanje, potrošnju, plan i komisijski transport."""

    STATUS_CRITICAL = "Kritično"
    STATUS_LOW_COVERED = "Niska fizička zaliha — trenutno pokriveno"
    STATUS_WAITING = "Čeka zaprimanje"

    def __init__(self, *, today=None):
        self.today = today or timezone.localdate()
        self.commission_schedule = get_commission_schedule(today=self.today)

    def _incoming_shipment(self, lijek):
        medicine_ids = equivalent_medicine_ids(lijek)
        requests = list(
            Trebovanje.objects.filter(
                lijek_id__in=medicine_ids,
                status__in=(
                    "ODOBRENO",
                    Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
                    Trebovanje.STATUS_CEKA_ISPORUKU,
                ),
                odobrene_doze__isnull=False,
                komisijski_ciklus__datum_odobrenja__isnull=False,
                komisijski_ciklus__isnull=False,
            )
            .filter(odobrene_doze__gt=F("zaprimljene_doze"))
            .select_related("komisijski_ciklus")
            .order_by("komisijski_ciklus__datum_odobrenja", "id")
        )
        if not requests:
            return {
                "postoji": False,
                "odobreno": Decimal("0"),
                "ocekivano": Decimal("0"),
                "datum": None,
                "ciklus": None,
            }
        approved = sum(
            (Decimal(str(item.odobrene_doze or 0)) for item in requests),
            Decimal("0"),
        )
        expected = sum(
            (
                max(
                    Decimal("0"),
                    Decimal(str(item.odobrene_doze or 0))
                    - Decimal(str(item.zaprimljene_doze or 0)),
                )
                for item in requests
            ),
            Decimal("0"),
        )
        cycle = requests[0].komisijski_ciklus
        return {
            "postoji": expected > 0,
            "odobreno": approved,
            "ocekivano": expected,
            "datum": expected_delivery_for_cycle(cycle),
            "ciklus": cycle,
        }

    def _finalize(self, row):
        row = dict(row)
        shipment = self._incoming_shipment(row["lijek"])
        active = bool(row["broj_aktivnih_pacijenata"])
        commission_need = Decimal(str(row["za_novu_komisiju"] or 0))
        physical_shortfall = Decimal(str(row.get("physical_shortfall") or 0))
        awaiting_physical_coverage = Decimal(str(
            row.get("ceka_fizicko_pokrice") or 0
        ))
        approved_awaiting_receipt = Decimal(str(
            row.get("odobreno_ceka_zaprimanje") or 0
        ))
        planning_incomplete = bool(row.get("planiranje_nepotpuno"))
        planning_reasons = tuple(row.get("razlozi_nepotpunog_planiranja") or ())
        therapy_types = tuple(row.get("tipovi_planiranja") or ())
        oral_therapy = bool(
            row.get("oralna_terapija") or TYPE_ORAL in therapy_types
        )
        at_patient = Decimal(str(row.get("kod_pacijenata") or 0))
        free_stock = Decimal(str(row.get("slobodno_raspolozivo") or 0))
        oral_physical_gap = bool(
            oral_therapy
            and active
            and not planning_incomplete
            and at_patient <= 0
            and free_stock <= 0
        )
        first_uncovered = row.get("prvi_pacijent_bez_pokrica_datum")
        has_known_schedule = bool(row.get("ima_poznat_buduci_raspored"))
        delivery_risk = bool(
            first_uncovered
            and (
                (
                    shipment["postoji"]
                    and shipment["datum"]
                    and shipment["datum"] > first_uncovered
                )
                or (
                    row.get("rizicna_isporuka")
                    and row["rizicna_isporuka"] > first_uncovered
                )
            )
        )
        high_priority = bool(
            first_uncovered
            and first_uncovered <= self.today + timedelta(days=14)
        )
        home_therapy = bool(row.get("kucna_terapija"))
        home_physical_until = row.get("home_physical_covered_until")
        home_first_uncovered = row.get("home_first_uncovered_therapy")
        home_next_dispensing = row.get("home_next_dispensing")

        if physical_shortfall > 0:
            status, css = "Fizički manjak rezervacija", "critical"
            reason, action = (
                f"U frižideru je {row['u_frizideru']:g}, a fizički je "
                f"rezervisano {row['rezervisano']:g}; nepokriveno je "
                f"{physical_shortfall:g}.",
                "Uskladiti fizičko stanje i rezervacije",
            )
        elif awaiting_physical_coverage > 0:
            status, css = "Još nije fizički osigurano", "waiting"
            reason, action = (
                f"Fizički je rezervisano {row['rezervisano']:g} od "
                f"{row['u_frizideru']:g} na stanju; još "
                f"{awaiting_physical_coverage:g} evidentirane potrebe još "
                "nije fizički osigurano.",
                "Zaprimiti zalihu ili rasporediti slobodnu zalihu",
            )
        elif not active:
            status, css = "Nema aktivnih pacijenata", "neutral"
            reason, action = (
                "Nema aktivnih pacijenata na ovom lijeku.",
                "Nije potrebna operativna akcija",
            )
        elif approved_awaiting_receipt > 0:
            status, css = self.STATUS_WAITING, "waiting"
            reason, action = (
                "Sve trenutne fizičke doze su rezervisane. Dodatne "
                f"{format_stock_quantity(row['lijek'], approved_awaiting_receipt)} "
                "su odobrene i čekaju "
                "zaprimanje.",
                "Zaprimiti isporuku",
            )
        elif home_therapy and commission_need > 0:
            status, css = "Potrebna komisija", "commission"
            reason = (
                f"Postojeća kućna zaliha pokriva terapiju do "
                f"{home_physical_until:%d.%m.%Y}; preporuka za trenutni "
                "komisijski ciklus je pozitivna."
                if home_physical_until else
                "Centralni komisijski plan preporučuje novu količinu."
            )
            action = (
                "Rizik prekida terapije – potrebna ranija isporuka, "
                "postojeća zaliha ili vanredni zahtjev."
                if Decimal(str(row.get("u_frizideru") or 0)) <= 0
                else "Pokrenuti komisiju"
            )
        elif home_therapy and home_physical_until:
            # Administrativno odobrenje nije fizička lokacija. Operativni
            # status kućne terapije zato govori samo o stvarnoj količini kod
            # pacijenta i u frižideru.
            status, css = (
                f"Fizički pokriven do {home_physical_until:%d.%m.}",
                "ok",
            )
            reason = (
                f"Prva terapija bez pokrića je {home_first_uncovered:%d.%m.%Y}."
                if home_first_uncovered
                else "Prva terapija bez pokrića nije određena."
            )
            action = (
                "Rizik prekida terapije – potrebna ranija isporuka, "
                "postojeća zaliha ili vanredni zahtjev."
                if Decimal(str(row.get("u_frizideru") or 0)) <= 0
                else
                "Organizovati naredno izdavanje do "
                f"{home_next_dispensing:%d.%m.%Y}."
                if home_next_dispensing
                else "Pratiti fizičko pokriće kućne terapije"
            )
        elif planning_incomplete:
            status, css = "Konfiguracija nepotpuna", "neutral"
            reason, action = (
                planning_reasons[0]
                if planning_reasons
                else "Za najmanje jednog pacijenta plan nije kompletno definisan.",
                "Dovršiti i potvrditi oralni režim"
                if oral_therapy
                else "Ručna provjera terapijskog protokola",
            )
        elif oral_therapy and commission_need > 0:
            status, css = "Potrebna komisija", "commission"
            reason, action = (
                "Potvrđeni dnevni oralni režim daje pozitivnu potrebu u tabletama; "
                "ambulantni termini nisu primjenjivi na ovaj tip terapije.",
                "Pokrenuti komisiju",
            )
        elif oral_therapy and at_patient > 0:
            status, css = "Izdato pacijentima", "ok"
            reason, action = (
                f"Prema stvarnim zapisima o izdavanju i dnevnom režimu kod "
                f"pacijenata je procijenjeno još {at_patient:g} tableta.",
                "Pratiti datum narednog oralnog izdavanja",
            )
        elif oral_therapy and free_stock > 0:
            status, css = "Potrebno oralno izdavanje", "waiting"
            reason, action = (
                f"U kabinetu je {free_stock:g} slobodnih tableta, ali nema "
                "evidentirane fizičke količine kod pacijenta.",
                "Evidentirati oralno izdavanje kroz karton pacijenta",
            )
        elif oral_therapy:
            status, css = "Nema fizičkog pokrića", "critical"
            reason, action = (
                "Potvrđeni oralni režim ima aktivnu potrebu, ali nema tableta "
                "na stanju ni aktivnog zapisa o izdavanju sa preostalom količinom.",
                "Zaprimiti zalihu ili evidentirati oralno izdavanje",
            )
        elif delivery_risk:
            status, css = "Rizik dostave", "critical"
            therapy_date = first_uncovered
            delivery_date = shipment["datum"] or row.get("rizicna_isporuka")
            reason = (
                "Očekivana isporuka "
                f"{delivery_date:%d/%m/%Y} dolazi nakon nepokrivene terapije "
                f"{therapy_date:%d/%m/%Y}."
                if therapy_date and delivery_date
                else "Terapija nije fizički pokrivena prije očekivane isporuke."
            )
            action = (
                "Pokrenuti komisiju"
                if commission_need > 0
                else "Pratiti zaprimanje"
            )
        elif (
            first_uncovered
            and shipment["postoji"]
            and row.get("prvi_pacijent_planirano_pokriven_do")
        ):
            status, css = "Pokriveno", "ok"
            reason, action = (
                f"Fizičko pokriće traje do {first_uncovered:%d/%m/%Y}; "
                "potvrđena isporuka stiže prije tog termina.",
                "Pratiti zaprimanje",
            )
        elif first_uncovered and commission_need > 0:
            status, css = "Potrebna komisija", "commission"
            reason, action = (
                f"Prva terapija bez pokrića je "
                f"{first_uncovered:%d/%m/%Y}.",
                "Pokrenuti komisiju",
            )
        elif first_uncovered:
            status, css = "Pokriveno", "ok"
            reason, action = (
                f"Prva kasnija terapija bez pokrića je "
                f"{first_uncovered:%d/%m/%Y}, ali za trenutni komisijski "
                "ciklus nije potrebna nova količina.",
                "Planirati naredni ciklus",
            )
        elif not has_known_schedule:
            status, css = (
                ("Potrebna komisija", "commission")
                if commission_need > 0
                else ("Pokriveno", "neutral")
            )
            reason, action = (
                "Nema zakazanih budućih terapija.",
                "Planirati početnu nabavku"
                if commission_need > 0
                else "Zakazati sljedeću terapiju",
            )
        else:
            status, css = "Pokriveno", "ok"
            reason, action = (
                "Sve poznate buduće terapije su fizički pokrivene.",
                "Nije potrebna operativna akcija",
            )

        if high_priority and status == "Potrebna komisija":
            css = "critical"
            reason = (
                f"Prva terapija bez pokrića je "
                f"{first_uncovered:%d/%m/%Y}; potrebna je hitna provjera."
            )

        if (
            active
            and not oral_therapy
            and free_stock > 0
            and (first_uncovered or commission_need > 0)
        ):
            action = "Prvo rasporediti slobodnu zalihu."
            reason = (
                f"Dostupno je {free_stock:g} fizičkih jedinica koje još nisu "
                "dodijeljene pacijentima. Centralni plan ih računa samo jednom."
            )

        if physical_shortfall > 0:
            coverage_state = "fizicki_manjak_rezervacija"
            coverage_message = (
                f"Nepokrivene fizičke rezervacije: {physical_shortfall:g}. "
                "Komisijska pokrivenost se prikazuje zasebno."
            )
        elif awaiting_physical_coverage > 0:
            coverage_state = "ceka_fizicko_pokrice"
            coverage_message = (
                f"Još nije fizički osigurano: {awaiting_physical_coverage:g}. "
                "Ova količina nije fizička rezervacija."
            )
        elif not active:
            coverage_state = "nema_pacijenata"
            coverage_message = "Nema aktivnih pacijenata"
        elif approved_awaiting_receipt > 0:
            coverage_state = "odobreno_ceka_zaprimanje"
            coverage_message = (
                f"Odobreno – čeka zaprimanje: {approved_awaiting_receipt:g}. "
                "Količina još nije uračunata u fizičko stanje frižidera."
            )
        elif planning_incomplete:
            coverage_state = "konfiguracija_nepotpuna"
            coverage_message = reason
        elif oral_therapy and at_patient > 0:
            coverage_state = "oralno_kod_pacijenta"
            coverage_message = (
                f"Procijenjeno preostalo kod pacijenata: {at_patient:g} tableta."
            )
        elif oral_therapy and free_stock > 0:
            coverage_state = "oralno_ceka_izdavanje"
            coverage_message = "Postoji fizička zaliha, ali izdavanje nije evidentirano."
        elif oral_therapy:
            coverage_state = "oralno_bez_fizickog_pokrica"
            coverage_message = (
                "Komisijsko odobrenje nije fizička zaliha kod pacijenta."
            )
        elif home_therapy and home_first_uncovered:
            coverage_state = "datum"
            coverage_message = None
        elif first_uncovered:
            coverage_state = "datum"
            coverage_message = None
        elif not has_known_schedule:
            coverage_state = "nepoznat"
            coverage_message = "Nema zakazanih budućih terapija."
        else:
            coverage_state = "bez_manjka"
            coverage_message = "Nema utvrđenog manjka"

        row.update(
            status=status,
            status_css=css,
            status_razlog=reason,
            preporucena_akcija=action,
            posiljka=shipment,
            kriticno=(
                physical_shortfall > 0
                or awaiting_physical_coverage > 0
                or oral_physical_gap
                or delivery_risk
                or high_priority
            ),
            treba_komisiju=commission_need > 0,
            fizicki_manjak_rezervacija=physical_shortfall > 0,
            ceka_fizicko_pokrice=awaiting_physical_coverage,
            oralno_bez_fizickog_pokrica=oral_physical_gap,
            procjena_moguca=not planning_incomplete,
            konfiguracija_nepotpuna=planning_incomplete,
            tip_terapije_nije_klasican=bool(row.get("neklasicno_planiranje")),
            rizik_dostave=delivery_risk,
            visoki_prioritet=high_priority,
            pokrice_datum_stanje=coverage_state,
            pokrice_datum_poruka=coverage_message,
            centralni_datum_komisije=self.commission_schedule.effective_next_date,
            posljednji_siguran_datum_za_ukljucivanje=(
                row["preporuceni_komisijski_ciklus"].rok_pripreme
                if row.get("preporuceni_komisijski_ciklus") else None
            ),
            ocekivana_pouzdana_isporuka=(
                row["preporuceni_komisijski_ciklus"].najkasnija_isporuka
                if row.get("preporuceni_komisijski_ciklus") else None
            ),
        )
        return row

    def rows(self):
        from .inventory import _inventory_rows_for_stock_risk

        return [
            self._finalize(row)
            for row in _inventory_rows_for_stock_risk(today=self.today)
        ]

    def critical_rows(self):
        return [row for row in self.rows() if row["kriticno"]]

    def summary(self):
        rows = self.rows()
        return {
            "rows": rows,
            "ukupno_u_frizideru": sum(
                (row["u_frizideru"] for row in rows), Decimal("0")
            ),
            "ukupno_kod_pacijenata": sum(
                (row["kod_pacijenata"] for row in rows), Decimal("0")
            ),
            "lijekovi_za_komisiju": sum(
                1 for row in rows if row["treba_komisiju"]
            ),
            "kriticni_lijekovi": sum(1 for row in rows if row["kriticno"]),
        }
