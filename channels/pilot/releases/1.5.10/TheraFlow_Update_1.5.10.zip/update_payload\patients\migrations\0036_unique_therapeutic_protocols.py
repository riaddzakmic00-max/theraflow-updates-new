from collections import defaultdict

from django.db import migrations, models


def dedupe_therapeutic_protocols(apps, schema_editor):
    Pacijent = apps.get_model("patients", "Pacijent")
    TerapijskiKorakProtokola = apps.get_model("patients", "TerapijskiKorakProtokola")
    TerapijskiProtokol = apps.get_model("patients", "TerapijskiProtokol")

    groups = defaultdict(list)
    for protokol in TerapijskiProtokol.objects.all().order_by("lijek_id", "naziv", "id"):
        groups[(protokol.lijek_id, protokol.naziv)].append(protokol)

    for protokoli in groups.values():
        if len(protokoli) < 2:
            continue

        def score(protokol):
            koraci_count = TerapijskiKorakProtokola.objects.filter(
                protokol=protokol,
                aktivan=True,
            ).count()
            pacijenti_count = Pacijent.objects.filter(
                terapijski_protokol=protokol,
            ).count()
            return (-koraci_count, -pacijenti_count, not protokol.aktivan, protokol.id)

        canonical = sorted(protokoli, key=score)[0]
        duplicate_ids = [
            protokol.id
            for protokol in protokoli
            if protokol.id != canonical.id
        ]

        if not duplicate_ids:
            continue

        Pacijent.objects.filter(
            terapijski_protokol_id__in=duplicate_ids,
        ).update(terapijski_protokol=canonical)
        TerapijskiProtokol.objects.filter(id__in=duplicate_ids).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0035_alter_aktivnostlog_id_alter_dokumentpacijenta_id_and_more"),
    ]

    operations = [
        migrations.RunPython(dedupe_therapeutic_protocols, migrations.RunPython.noop),
        migrations.AddConstraint(
            model_name="terapijskiprotokol",
            constraint=models.UniqueConstraint(
                fields=("lijek", "naziv"),
                name="uniq_terapijski_protokol_lijek_naziv",
            ),
        ),
    ]
