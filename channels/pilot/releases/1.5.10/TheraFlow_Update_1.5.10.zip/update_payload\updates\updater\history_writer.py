import json
import os
from datetime import datetime, timezone
from pathlib import Path

from .state_writer import safe_message


def write_history_event(plan, state, status):
    event = {
        "session_id": plan["session_id"],
        "source_version": plan["current_version"],
        "target_version": plan["target_version"],
        "status": status,
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "rollback_type": state.get("rollback_type", ""),
        "rollback_result": state.get("status", ""),
        "final_active_version": state.get("previous_version_restored") or plan["target_version"],
        "safe_error_summary": safe_message(state.get("rollback_error_message") or state.get("error_message") or ""),
    }
    destination = Path(plan["backup_root"]) / "update_history_event.json"
    temporary = destination.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(event, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, destination)
    return destination
