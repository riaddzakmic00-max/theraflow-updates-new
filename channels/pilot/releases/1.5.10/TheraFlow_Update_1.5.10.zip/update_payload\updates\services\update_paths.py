from dataclasses import dataclass
from pathlib import Path

from django.conf import settings


@dataclass(frozen=True)
class UpdatePaths:
    data_root: Path
    packages: Path
    staging: Path
    sessions: Path
    backups: Path


def _local_resolved(path):
    path = Path(path).expanduser().resolve()
    text = str(path)
    if text.startswith("\\\\"):
        raise ValueError("Mrežna putanja nije dozvoljena za update podatke.")
    return path


def get_update_paths(create=True):
    data_root = _local_resolved(settings.THERAFLOW_DATA_DIR)
    paths = UpdatePaths(
        data_root=data_root,
        packages=data_root / "updates" / "packages",
        staging=data_root / "updates" / "staging",
        sessions=data_root / "updates" / "sessions",
        backups=data_root / "backups" / "updates",
    )
    if create:
        for path in (paths.packages, paths.staging, paths.sessions, paths.backups):
            path.mkdir(parents=True, exist_ok=True)
    return paths


def ensure_child(path, parent):
    path = Path(path).resolve()
    parent = Path(parent).resolve()
    if path == parent or parent not in path.parents:
        raise ValueError("Putanja nije unutar dozvoljenog update direktorija.")
    return path
