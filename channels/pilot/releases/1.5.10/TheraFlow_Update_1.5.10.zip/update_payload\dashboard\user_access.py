from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.contrib.sessions.models import Session
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q

from dashboard.permissions import ROLE_COORDINATOR
from patients.models import KorisnickiPristup


ROLE_ADMIN = "Administrator"
ROLE_CHOICES = (
    (ROLE_ADMIN, ROLE_ADMIN),
    (ROLE_COORDINATOR, ROLE_COORDINATOR),
)
MANAGED_GROUPS = ("Admin", ROLE_COORDINATOR, "Doktor", "Sestra")


def user_role(user):
    if user.is_superuser or user.groups.filter(name="Admin").exists():
        return ROLE_ADMIN
    if user.groups.filter(name=ROLE_COORDINATOR).exists():
        return ROLE_COORDINATOR
    return "Bez dodijeljene uloge"


def active_admins():
    User = get_user_model()
    return User.objects.filter(is_active=True).filter(
        Q(is_superuser=True) | Q(groups__name="Admin")
    ).distinct()


def requires_password_change(user):
    if not getattr(user, "is_authenticated", False):
        return False
    return KorisnickiPristup.objects.filter(
        korisnik=user,
        zahtijeva_promjenu_lozinke=True,
    ).exists()


def set_password_change_required(user, required):
    access, _ = KorisnickiPristup.objects.get_or_create(korisnik=user)
    access.zahtijeva_promjenu_lozinke = bool(required)
    access.save(update_fields=["zahtijeva_promjenu_lozinke", "izmijenjeno"])


def invalidate_user_sessions(user):
    removed = 0
    for session in Session.objects.all().iterator():
        try:
            auth_user_id = session.get_decoded().get("_auth_user_id")
        except Exception:
            continue
        if str(auth_user_id) == str(user.pk):
            session.delete()
            removed += 1
    return removed


def _ensure_admin_can_be_removed(user):
    if user_role(user) == ROLE_ADMIN and active_admins().filter(pk=user.pk).exists():
        User = get_user_model()
        # Zaključavanje aktivnih korisnika serijalizira istovremene democije i
        # deaktivacije bez SELECT FOR UPDATE + DISTINCT kombinacije.
        list(
            User.objects.select_for_update()
            .filter(is_active=True)
            .values_list("pk", flat=True)
        )
        if active_admins().count() <= 1:
            raise ValidationError(
                "Nije dozvoljeno ukloniti ili deaktivirati posljednjeg aktivnog administratora."
            )


@transaction.atomic
def set_user_role(user, role):
    if role not in dict(ROLE_CHOICES):
        raise ValidationError("Odabrana uloga nije dozvoljena.")

    User = get_user_model()
    locked_user = User.objects.select_for_update().get(pk=user.pk)
    previous_role = user_role(locked_user)
    if previous_role == ROLE_ADMIN and role != ROLE_ADMIN:
        _ensure_admin_can_be_removed(locked_user)

    groups = {
        name: Group.objects.get_or_create(name=name)[0]
        for name in MANAGED_GROUPS
    }
    locked_user.groups.remove(*groups.values())
    if role == ROLE_ADMIN:
        locked_user.groups.add(groups["Admin"])
    else:
        locked_user.groups.add(groups[ROLE_COORDINATOR])
        if locked_user.is_superuser or locked_user.is_staff:
            locked_user.is_superuser = False
            locked_user.is_staff = False
            locked_user.save(update_fields=["is_superuser", "is_staff"])
    return locked_user, previous_role


@transaction.atomic
def set_user_active(user, active):
    User = get_user_model()
    locked_user = User.objects.select_for_update().get(pk=user.pk)
    if not active and locked_user.is_active:
        _ensure_admin_can_be_removed(locked_user)
    previous = locked_user.is_active
    locked_user.is_active = bool(active)
    locked_user.save(update_fields=["is_active"])
    if not active:
        invalidate_user_sessions(locked_user)
    return locked_user, previous
