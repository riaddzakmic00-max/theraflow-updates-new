from patients.request_cache import begin_request_cache, end_request_cache
from django.shortcuts import redirect
from django.urls import reverse

from dashboard.user_access import requires_password_change


class RequiredPasswordChangeMiddleware:
    """Blokira aplikaciju dok korisnik ne zamijeni privremenu lozinku."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if getattr(request.user, "is_authenticated", False) and requires_password_change(request.user):
            allowed_paths = {
                reverse("promijeni_vlastitu_lozinku"),
                reverse("logout"),
            }
            if request.path not in allowed_paths:
                return redirect("promijeni_vlastitu_lozinku")
        return self.get_response(request)


class RequestComputationCacheMiddleware:
    """Dijeli kanonske read-only izraÄŤune unutar jednog HTTP requesta."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        token = begin_request_cache(enabled=request.method in {"GET", "HEAD"})
        try:
            return self.get_response(request)
        finally:
            end_request_cache(token)
