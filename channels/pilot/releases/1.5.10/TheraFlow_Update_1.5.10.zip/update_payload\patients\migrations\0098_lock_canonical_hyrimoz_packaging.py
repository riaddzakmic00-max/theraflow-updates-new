from django.db import migrations
from django.db.models import Q


def lock_canonical_hyrimoz_packaging(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    TerapijskiProgram = apps.get_model("patients", "TerapijskiProgram")

    program = TerapijskiProgram.objects.filter(kljuc="adalimumab").first()
    canonical_id = program.default_lijek_id if program else None
    hyrimoz = Q(zasticeno_ime__iexact="Hyrimoz") | Q(naziv__icontains="Hyrimoz")
    if canonical_id:
        hyrimoz |= Q(pk=canonical_id)
    Lijek.objects.filter(hyrimoz).update(
        kucna_primjena=True,
        nacin_primjene="KUCNA_TERAPIJA",
        put_primjene="SC",
        package_size_in_doses=2,
        izdavanje_cijelih_pakovanja=False,
        jedinica_terapije="pen",
        jedinica_terapije_mnozina="pena",
        jedinica_zalihe="pen",
        jedinica_zalihe_mnozina="penovi",
    )


class Migration(migrations.Migration):
    dependencies = [("patients", "0097_patient_jmbg_optional_unique")]

    operations = [
        migrations.RunPython(
            lock_canonical_hyrimoz_packaging,
            migrations.RunPython.noop,
        ),
    ]
