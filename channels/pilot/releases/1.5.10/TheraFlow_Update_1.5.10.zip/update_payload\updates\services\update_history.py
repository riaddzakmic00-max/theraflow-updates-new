import json
from datetime import datetime
from pathlib import Path

from django.utils import timezone

from updates.models import UpdateHistory
from updates.updater.state_writer import process_step_label, safe_message


def _dt(value):
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed if timezone.is_aware(parsed) else timezone.make_aware(parsed)
    except (TypeError, ValueError):
        return None


def history_status(state):
    status = state.get("status")
    if status == "update_completed":
        return UpdateHistory.SUCCESSFUL
    if status == "rollback_completed":
        return UpdateHistory.FAILED_ROLLED_BACK
    if status == "manual_recovery_required":
        return UpdateHistory.FAILED_MANUAL_RECOVERY
    if status in {"install_failed", "validation_failed", "dependency_update_unsupported", "service_stop_failed", "snapshot_failed", "backup_failed", "staging_failed", "interrupted", "updater_service_failed"}:
        return UpdateHistory.FAILED_BEFORE_INSTALL
    return None


def sync_history(session, state):
    status = history_status(state)
    if not status:
        return None
    source_version = state.get("current_version")
    if not source_version and session.install_plan_path:
        try:
            source_version = json.loads(Path(session.install_plan_path).read_text(encoding="utf-8"))["current_version"]
        except (OSError, ValueError, KeyError):
            source_version = "unknown"
    # Historija instalacije mjeri instalacijski proces, ne vrijeme provedeno
    # između preuzimanja/pripreme paketa i korisnikovog klika na instalaciju.
    started = (
        _dt(state.get("install_started_at"))
        or session.install_started_at
        or _dt(state.get("started_at"))
        or session.created_at
    )
    # Terminalni state mora imati fiksan završetak. Za starije state fajlove
    # koristi njihov posljednji updated_at, a ne timezone.now(), kako svaki
    # novi poll ne bi beskonačno povećavao prikazano trajanje.
    completed = (
        _dt(
            state.get("rollback_completed_at")
            or state.get("completed_at")
            or state.get("updated_at")
        )
        or session.install_completed_at
        or session.updated_at
        or timezone.now()
    )
    duration = max(0, int((completed - started).total_seconds())) if started and completed else None
    failed_step_label = state.get("failed_step_label") or (
        process_step_label(state.get("failed_step")) if state.get("failed_step") else ""
    )
    error_summary = safe_message(
        state.get("rollback_error_message") or state.get("error_message") or ""
    )
    if failed_step_label and status != UpdateHistory.SUCCESSFUL:
        error_summary = f"Zaustavljeno na: {failed_step_label}. {error_summary}".strip()
    return UpdateHistory.objects.update_or_create(
        session=session,
        defaults={
            "source_version": str(source_version or "unknown")[:50],
            "target_version": session.target_version,
            "started_at": started,
            "completed_at": completed,
            "status": status,
            "initiated_by": session.install_started_by or session.prepared_by,
            "mandatory": bool(session.manifest_snapshot.get("mandatory")),
            "package_sha256": session.package_sha256,
            "backup_created": bool(session.backup_directory),
            "backup_validated": session.database_backup_validated,
            "files_installed": bool(state.get("files_changed")),
            "migrations_executed": bool(state.get("migration_completed")),
            "health_check_result": str(state.get("health_check_status") or "")[:64],
            "rollback_executed": bool(state.get("rollback_started_at")),
            "rollback_type": str(state.get("rollback_type") or "")[:20],
            "rollback_result": str(state.get("status") or "")[:64] if state.get("rollback_started_at") else "",
            "final_active_version": str(state.get("previous_version_restored") or (session.target_version if status == UpdateHistory.SUCCESSFUL else ""))[:50],
            "duration_seconds": duration,
            "safe_error_summary": error_summary,
        },
    )[0]
