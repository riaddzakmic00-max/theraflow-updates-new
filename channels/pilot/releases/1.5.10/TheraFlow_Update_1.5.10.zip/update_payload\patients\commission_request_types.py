"""Canonical commission request classification and document-package registry.

The clinical therapy (``TerapijskiProgram``) is deliberately kept separate from
the physical product/SKU.  This module is the one place that combines a program
category and a request purpose into the legacy value still used by the existing
PDF workflow.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from django.utils import timezone


PROGRAM_BIOLOGIC = "BIOLOGIC"
PROGRAM_HEPATITIS_B = "HEPATITIS_B"
PROGRAM_UNCONFIGURED = "UNCONFIGURED"

PURPOSE_NEW = "NEW"
PURPOSE_CONTINUATION = "CONTINUATION"
PURPOSE_SWITCH = "SWITCH"
PURPOSE_DISCONTINUATION = "DISCONTINUATION"
PURPOSE_REQUIRES_CONFIRMATION = "REQUIRES_CONFIRMATION"

PROGRAM_LABELS = {
    PROGRAM_BIOLOGIC: "Biološka terapija",
    PROGRAM_HEPATITIS_B: "Hepatitis B",
    PROGRAM_UNCONFIGURED: "Nedefinisan program",
}
PURPOSE_LABELS = {
    PURPOSE_NEW: "novi",
    PURPOSE_CONTINUATION: "produženje",
    PURPOSE_SWITCH: "promjena/switch",
    PURPOSE_DISCONTINUATION: "odjava",
    PURPOSE_REQUIRES_CONFIRMATION: "potrebna potvrda",
}


@dataclass(frozen=True)
class DocumentPackageSpec:
    key: str
    label: str
    legacy_request_type: Optional[str]
    template_name: Optional[str]
    required_document_types: Optional[tuple[str, ...]] = None
    short_label: str = ""
    heading: str = ""
    filename: str = ""

    @property
    def configured(self):
        return bool(self.legacy_request_type and self.template_name)


# Only packages that already have a configured official source are marked as
# configured.  Missing combinations remain visible to the user but cannot be
# silently rendered with the wrong form.
DOCUMENT_PACKAGE_SPECS = {
    (PROGRAM_BIOLOGIC, PURPOSE_CONTINUATION): DocumentPackageSpec(
        "biologic-continuation",
        "Produženje biološke terapije",
        "bioloska_produzenje",
        "za_zavod.pdf",
        short_label="Produženje",
        heading="BIOLOŠKA TERAPIJA - PRODUŽENJE",
        filename="01_Bioloska_terapija_produzenje.pdf",
    ),
    (PROGRAM_BIOLOGIC, PURPOSE_NEW): DocumentPackageSpec(
        "biologic-new",
        "Prvo uključivanje u biološku terapiju",
        "bioloska_novi",
        "za_zavod.pdf",
        short_label="Novi",
        heading="BIOLOŠKA TERAPIJA - NOVI",
        filename="02_Bioloska_terapija_novi.pdf",
    ),
    (PROGRAM_BIOLOGIC, PURPOSE_SWITCH): DocumentPackageSpec(
        "biologic-switch",
        "Promjena biološke terapije",
        "bioloska_switch",
        "za_zavod.pdf",
        short_label="Switch",
        heading="BIOLOŠKA TERAPIJA - PROMJENA/SWITCH",
        filename="03_Bioloska_terapija_promjena_switch.pdf",
    ),
    (PROGRAM_BIOLOGIC, PURPOSE_DISCONTINUATION): DocumentPackageSpec(
        "biologic-discontinuation",
        "Odjava biološke terapije",
        "bioloska_odjava",
        "za_zavod.pdf",
        short_label="Odjava",
        heading="BIOLOŠKA TERAPIJA - ODJAVA",
        filename="04_Bioloska_terapija_odjava.pdf",
    ),
    (PROGRAM_HEPATITIS_B, PURPOSE_CONTINUATION): DocumentPackageSpec(
        "hepatitis-b-continuation",
        "Produženje terapije za Hepatitis B",
        "hepatitis_b_produzenje",
        "za_zavod.pdf",
        short_label="Hepatitis B",
        heading="HEPATITIS B - PRODUŽENJE",
        filename="05_Hepatitis_B_produzenje.pdf",
    ),
}

LEGACY_TO_CANONICAL = {
    spec.legacy_request_type: key
    for key, spec in DOCUMENT_PACKAGE_SPECS.items()
    if spec.legacy_request_type
}


def request_type_label(program_type, request_purpose):
    program = PROGRAM_LABELS.get(program_type, "Nedefinisan program")
    purpose = PURPOSE_LABELS.get(request_purpose, "potrebna potvrda")
    return f"{program} — {purpose}"


def document_package_for(program_type, request_purpose):
    spec = DOCUMENT_PACKAGE_SPECS.get((program_type, request_purpose))
    if spec:
        return spec
    return DocumentPackageSpec(
        key=f"missing:{program_type or 'unknown'}:{request_purpose or 'unknown'}",
        label="Nedostaje predložak dokumentacije",
        legacy_request_type=None,
        template_name=None,
    )


def canonical_from_legacy(legacy_request_type):
    return LEGACY_TO_CANONICAL.get(legacy_request_type, ("", ""))


def configured_legacy_categories():
    return tuple(
        spec for spec in DOCUMENT_PACKAGE_SPECS.values() if spec.configured
    )


@dataclass(frozen=True)
class ClassificationResult:
    program_type: str
    request_purpose: str
    reason_code: str
    reason: str
    source_therapy_change_id: Optional[int] = None

    @property
    def requires_confirmation(self):
        return self.request_purpose == PURPOSE_REQUIRES_CONFIRMATION

    @property
    def label(self):
        return request_type_label(self.program_type, self.request_purpose)

    @property
    def package(self):
        return document_package_for(self.program_type, self.request_purpose)

    @property
    def legacy_request_type(self):
        return self.package.legacy_request_type


def _patient_program(patient):
    patient_program = getattr(patient, "terapijski_program", None)
    medicine = getattr(patient, "lijek", None)
    medicine_program = getattr(medicine, "terapijski_program", None) if medicine else None
    if (
        patient_program
        and medicine_program
        and patient_program.pk != medicine_program.pk
    ):
        return None, "PROGRAM_CONFLICT"
    return patient_program or medicine_program, ""


def _same_program_medicine_ids(program):
    return program.proizvodi.values_list("pk", flat=True)


def classify_commission_request(patient):
    """Classify from durable clinical history; never from a patient name/SKU."""

    from .models import (
        AktivnostLog,
        Komisija,
        KomisijskiZahtjev,
        KucnoIzdavanje,
        MigracijskiSnapshotPacijenta,
        PromjenaTerapije,
        Terapija,
    )

    program, conflict = _patient_program(patient)
    if conflict:
        return ClassificationResult(
            PROGRAM_UNCONFIGURED,
            PURPOSE_REQUIRES_CONFIRMATION,
            conflict,
            "Terapijski program pacijenta i trenutni proizvod nisu usklađeni.",
        )
    if not program:
        return ClassificationResult(
            PROGRAM_UNCONFIGURED,
            PURPOSE_REQUIRES_CONFIRMATION,
            "PROGRAM_MISSING",
            "Terapijski program nije definisan.",
        )

    program_type = getattr(program, "commission_program_type", "") or PROGRAM_UNCONFIGURED
    if program_type == PROGRAM_UNCONFIGURED:
        return ClassificationResult(
            program_type,
            PURPOSE_REQUIRES_CONFIRMATION,
            "PROGRAM_CATEGORY_MISSING",
            "Za terapijski program nije konfigurirana komisijska kategorija.",
        )

    # Permanent deactivation is an explicit administrative event.  A pause or
    # absence of future appointments is intentionally not used here.
    if (
        not patient.aktivan
        and AktivnostLog.objects.filter(
            pacijent=patient,
            akcija="Deaktivacija pacijenta",
        ).exists()
    ):
        return ClassificationResult(
            program_type,
            PURPOSE_DISCONTINUATION,
            "EXPLICIT_PERMANENT_DISCONTINUATION",
            "Evidentirana je trajna deaktivacija pacijenta sa administrativnim razlogom.",
        )

    changes = list(
        PromjenaTerapije.objects.filter(pacijent=patient)
        .select_related(
            "stari_lijek__terapijski_program",
            "novi_lijek__terapijski_program",
        )
        .order_by("-datum_pocetka_nove_terapije", "-pk")
    )
    real_change = next(
        (
            change
            for change in changes
            if change.stari_lijek.terapijski_program_id
            and change.novi_lijek.terapijski_program_id == program.pk
            and change.stari_lijek.terapijski_program_id != program.pk
        ),
        None,
    )
    if real_change:
        already_requested = KomisijskiZahtjev.objects.filter(
            pacijent=patient,
        ).filter(
            source_therapy_change=real_change
        ).exists()
        if not already_requested:
            already_requested = KomisijskiZahtjev.objects.filter(
                pacijent=patient,
                vrsta_zahtjeva="bioloska_switch",
                novi_lijek__terapijski_program=program,
                datum_kreiranja__date__gte=real_change.datum_odluke,
            ).exists()
        therapy_started = Terapija.objects.filter(
            pacijent=patient,
            lijek__terapijski_program=program,
            datum__gte=real_change.datum_pocetka_nove_terapije,
            workflow_status=Terapija.STATUS_POTVRDJENA,
        ).exists()
        if not already_requested and not therapy_started:
            return ClassificationResult(
                program_type,
                PURPOSE_SWITCH,
                "UNCONSUMED_CANONICAL_THERAPY_CHANGE",
                (
                    "Evidentirana je promjena canonical terapije: "
                    f"{real_change.stari_lijek.terapijski_program.naziv} → "
                    f"{program.naziv}."
                ),
                real_change.pk,
            )

    medicine_ids = _same_program_medicine_ids(program)
    historical_other_program = (
        Terapija.objects.filter(pacijent=patient)
        .exclude(lijek__terapijski_program=program)
        .filter(lijek__terapijski_program__isnull=False)
        .exists()
        or Komisija.objects.filter(pacijent=patient)
        .exclude(lijek__terapijski_program=program)
        .filter(lijek__terapijski_program__isnull=False)
        .exists()
    )
    if historical_other_program and not real_change:
        return ClassificationResult(
            program_type,
            PURPOSE_REQUIRES_CONFIRMATION,
            "THERAPY_HISTORY_CONFLICT_WITHOUT_CHANGE",
            "Trenutna terapija se razlikuje od historije, ali promjena terapije nije evidentirana.",
        )

    try:
        migration = patient.migracijski_snapshot
    except MigracijskiSnapshotPacijenta.DoesNotExist:
        migration = None
    if migration:
        if (
            migration.lijek.terapijski_program_id
            and migration.lijek.terapijski_program_id != program.pk
        ):
            return ClassificationResult(
                program_type,
                PURPOSE_REQUIRES_CONFIRMATION,
                "MIGRATION_PROGRAM_CONFLICT",
                "Migracijski snapshot pripada drugom terapijskom programu.",
            )
        if (
            migration.datum_posljednje_terapije
            or migration.broj_odobrenih_doza > 0
            or migration.broj_iskoristenih_doza > 0
        ):
            return ClassificationResult(
                program_type,
                PURPOSE_CONTINUATION,
                "MIGRATED_EXISTING_TREATMENT",
                "Migracijski snapshot potvrđuje da je pacijent terapiju primao prije unosa u TheraFlow.",
            )
        return ClassificationResult(
            program_type,
            PURPOSE_REQUIRES_CONFIRMATION,
            "MIGRATION_HISTORY_INCOMPLETE",
            "Migrirani pacijent nema dovoljno podataka o prethodnom liječenju.",
        )

    same_program_history = (
        Terapija.objects.filter(
            pacijent=patient,
            lijek_id__in=medicine_ids,
            workflow_status=Terapija.STATUS_POTVRDJENA,
        ).exists()
        or KucnoIzdavanje.objects.filter(
            pacijent=patient,
            lijek_id__in=medicine_ids,
        ).exists()
        or Komisija.objects.filter(
            pacijent=patient,
            lijek_id__in=medicine_ids,
        ).exists()
        or KomisijskiZahtjev.objects.filter(
            pacijent=patient,
            program_type=program_type,
        ).exists()
    )
    if same_program_history or patient.pocetna_faza_terapije != patient.FAZA_INDUKCIJA:
        reason = (
            "Pacijent već prima istu canonical terapiju i nema novu, nepotrošenu promjenu terapije."
        )
        if real_change:
            reason = "Promjena terapije je već iskorištena ili je nova terapija započeta; naredni zahtjev je produženje."
        return ClassificationResult(
            program_type,
            PURPOSE_CONTINUATION,
            "EXISTING_SAME_PROGRAM_HISTORY",
            reason,
        )

    return ClassificationResult(
        program_type,
        PURPOSE_NEW,
        "NO_RELEVANT_PRIOR_HISTORY",
        f"Pacijent tek započinje {program.naziv} i nema prethodnu relevantnu terapijsku ili komisijsku historiju.",
    )


def request_document_snapshot(program_type, request_purpose):
    package = document_package_for(program_type, request_purpose)
    return {
        "package_key": package.key,
        "package_label": package.label,
        "template_name": package.template_name or "",
        "template_configured": package.configured,
        "required_document_types": list(package.required_document_types or ()),
        "captured_at": timezone.now().isoformat(),
    }
