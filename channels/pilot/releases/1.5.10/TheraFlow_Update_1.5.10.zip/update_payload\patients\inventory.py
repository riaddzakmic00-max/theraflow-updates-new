import logging
from decimal import Decimal, ROUND_FLOOR, ROUND_HALF_UP
from datetime import timedelta
from math import ceil

from django.db import transaction
from django.db.models import Count, Max, Q, Sum
from django.utils import timezone

from .package_sizes import (
    procurement_breakdown,
    procurement_unit_display_label,
)


logger = logging.getLogger(__name__)


def patient_reservation_breakdown(pacijent, *, medicine_ids=None, termin=None):
    from .request_cache import get_or_set

    if not pacijent or not getattr(pacijent, "pk", None):
        return _patient_reservation_breakdown_uncached(
            pacijent,
            medicine_ids=medicine_ids,
            termin=termin,
        )
    resolved_ids = list(
        medicine_ids
        if medicine_ids is not None
        else _physical_medicine_ids(pacijent.lijek) if pacijent.lijek_id else []
    )
    if termin is not None:
        return _patient_reservation_breakdown_uncached(
            pacijent,
            medicine_ids=resolved_ids,
            termin=termin,
        )
    return get_or_set(
        "patient_reservation_breakdown",
        (pacijent.pk, tuple(sorted(resolved_ids))),
        lambda: _patient_reservation_breakdown_uncached(
            pacijent,
            medicine_ids=resolved_ids,
        ),
    )


def _patient_reservation_breakdown_uncached(pacijent, *, medicine_ids=None, termin=None):
    """Vrati efektivne fizičke rezervacije bez zastarjelih ili duplih količina.

    ``PacijentRezervacija`` je fizički zapis vezan za pacijenta, ne za termin.
    Komisijska veza određuje samo administrativno preklapanje; ne smije ukloniti
    aktivnu fizičku količinu iz pacijentove pokrivenosti.
    """
    from .models import Komisija, PacijentRezervacija

    if not pacijent or not pacijent.pk:
        return {"items": [], "total_effective": Decimal("0"), "linked_overlap": Decimal("0")}
    if medicine_ids is None:
        medicine_ids = _physical_medicine_ids(pacijent.lijek) if pacijent.lijek_id else []

    commission_capacity = {}
    prefetched = getattr(pacijent, "_workflow_reservations", None)
    if prefetched is not None:
        medicine_ids_set = set(medicine_ids)
        reservations = [
            item for item in prefetched if item.lijek_id in medicine_ids_set
        ]
    else:
        reservations = list(PacijentRezervacija.objects.filter(
            pacijent=pacijent,
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
        )
        .select_related("komisija", "trebovanje", "termin")
            .order_by("datum_rezervacije", "id")
        )
    items = []
    total_effective = Decimal("0")
    linked_overlap = Decimal("0")

    for reservation in reservations:
        raw_quantity = Decimal(str(reservation.kolicina or 0))
        effective_quantity = raw_quantity
        exclusion_reason = ""
        commission = reservation.komisija
        if commission:
            if commission.status in Komisija.VAZECI_STATUSI and commission.preostale_doze > 0:
                remaining_capacity = commission_capacity.setdefault(
                    commission.pk,
                    Decimal(str(commission.preostale_doze or 0)),
                )
                commission_backed = min(raw_quantity, remaining_capacity)
                commission_capacity[commission.pk] = max(
                    Decimal("0"), remaining_capacity - commission_backed
                )
                linked_overlap += commission_backed
                if commission_backed < raw_quantity:
                    exclusion_reason = (
                        "Dio fizičke rezervacije nema povezanu komisijsku osnovu."
                    )
            else:
                exclusion_reason = (
                    "Fizička rezervacija postoji bez važeće komisijske osnove."
                )

        source = (
            f"trebovanje:{reservation.trebovanje_id}"
            if reservation.trebovanje_id
            else (f"komisija:{reservation.komisija_id}" if reservation.komisija_id else "ručna rezervacija")
        )
        item = {
            "reservation_id": reservation.pk,
            "termin_id": reservation.termin_id,
            "termin_datum": (
                reservation.termin.datum if reservation.termin_id else None
            ),
            "termin_status": (
                reservation.termin.status
                if reservation.termin_id else "NIJE_VEZANO_ZA_TERMIN"
            ),
            "workflow_termin_id": getattr(termin, "pk", None),
            "workflow_termin_datum": getattr(termin, "datum", None),
            "workflow_termin_status": getattr(termin, "status", None),
            "quantity": raw_quantity,
            "effective_quantity": effective_quantity,
            "active": reservation.aktivno,
            "source": source,
            "commission_id": reservation.komisija_id,
            "exclusion_reason": exclusion_reason,
        }
        items.append(item)
        total_effective += effective_quantity
        logger.info(
            "Rezervacija pacijent_id=%s rezervacija_id=%s termin_id=%s datum=%s "
            "status=%s kolicina=%s efektivno=%s aktivno=%s izvor=%s razlog=%s "
            "workflow_termin_id=%s workflow_datum=%s workflow_status=%s",
            pacijent.pk,
            item["reservation_id"],
            item["termin_id"],
            item["termin_datum"],
            item["termin_status"],
            item["quantity"],
            item["effective_quantity"],
            item["active"],
            item["source"],
            item["exclusion_reason"] or "uključena",
            item["workflow_termin_id"],
            item["workflow_termin_datum"],
            item["workflow_termin_status"],
        )

    return {
        "items": items,
        "total_effective": total_effective,
        "linked_overlap": linked_overlap,
    }


def lijek_je_kucna_terapija(lijek):
    from .therapy_regimens import TYPE_HOME_SC, therapy_regimen_type

    return therapy_regimen_type(lijek) == TYPE_HOME_SC


def _physical_medicine_ids(lijek):
    from .medication_groups import strict_equivalent_medicine_ids

    return strict_equivalent_medicine_ids(lijek)


def potreba_lijeka_za_sedmice(lijek, broj_sedmica):
    from .models import Pacijent

    ukupno = Decimal("0")
    pacijenti = Pacijent.objects.filter(
        aktivan=True,
        lijek=lijek,
    ).exclude(pauze_terapije__aktivna=True).select_related("lijek", "terapijski_protokol")

    for pacijent in pacijenti:
        ukupno += Decimal(str(pacijent.doze_za_period(broj_sedmica) or 0))

    return ukupno, pacijenti.count()


def potreba_lijeka_za_dana(lijek, broj_dana):
    return potreba_lijeka_za_sedmice(lijek, ceil(Decimal(str(broj_dana)) / Decimal("7")))


def izracunaj_potrebe_zalihe(lijek):
    minimum_30_dana, broj_pacijenata = potreba_lijeka_za_dana(lijek, 30)
    potreba_3_mjeseca, _ = potreba_lijeka_za_sedmice(lijek, 13)

    return {
        "broj_aktivnih_pacijenata": broj_pacijenata,
        "minimum_30_dana": minimum_30_dana,
        "potreba_3_mjeseca": potreba_3_mjeseca,
    }


def operativni_podaci_zaliha(lijek_ids, stanje_u_frizideru=None, danas=None):
    """Vrati fizičke operativne pokazatelje grupisane po lijeku.

    Izvor su isključivo transakcije koje su već promijenile frižider:
    ambulantna potrošnja, kućno izdavanje i fizičko zaprimanje. Termini i
    migracijske terapije zato se ne mogu slučajno uračunati.
    """
    from .models import ZalihaTransakcija

    danas = danas or timezone.localdate()
    pocetak_perioda = danas - timedelta(days=29)
    stanje_u_frizideru = stanje_u_frizideru or {}
    rezultat = {
        lijek_id: {
            "potrosnja_30_dana": Decimal("0"),
            "prosjecna_sedmicna_potrosnja": Decimal("0.0"),
            "dani_pokrivenosti": None,
            "dani_pokrivenosti_status": "Nema dovoljno podataka",
            "datum_posljednje_potrosnje": None,
            "datum_posljednje_isporuke": None,
        }
        for lijek_id in lijek_ids
    }

    grupisano = ZalihaTransakcija.objects.filter(lijek_id__in=lijek_ids).values(
        "lijek_id"
    ).annotate(
        potrosnja_30=Sum(
            "kolicina",
            filter=Q(
                tip__in=(
                    ZalihaTransakcija.TIP_AMBULANTNA_POTROSNJA,
                    ZalihaTransakcija.TIP_KUCNO_IZDAVANJE,
                ),
                datum__gte=pocetak_perioda,
                datum__lte=danas,
            ),
        ),
        posljednja_potrosnja=Max(
            "datum",
            filter=Q(
                tip__in=(
                    ZalihaTransakcija.TIP_AMBULANTNA_POTROSNJA,
                    ZalihaTransakcija.TIP_KUCNO_IZDAVANJE,
                ),
                datum__lte=danas,
            ),
        ),
        posljednja_isporuka=Max(
            "datum",
            filter=Q(tip=ZalihaTransakcija.TIP_ZAPRIMANJE, datum__lte=danas),
        ),
    )

    for zapis in grupisano:
        lijek_id = zapis["lijek_id"]
        potrosnja = Decimal(str(zapis["potrosnja_30"] or 0))
        sedmicna = (potrosnja / Decimal("30") * Decimal("7")).quantize(
            Decimal("0.1"), rounding=ROUND_HALF_UP
        )
        u_frizideru = Decimal(str(stanje_u_frizideru.get(lijek_id, 0) or 0))
        dani_pokrivenosti = None
        status_pokrivenosti = "Nema dovoljno podataka"
        if u_frizideru <= 0:
            dani_pokrivenosti = 0
            status_pokrivenosti = None
        elif potrosnja > 0:
            dnevna = potrosnja / Decimal("30")
            dani_pokrivenosti = int(
                (u_frizideru / dnevna).to_integral_value(rounding=ROUND_FLOOR)
            )
            status_pokrivenosti = None

        rezultat[lijek_id] = {
            "potrosnja_30_dana": potrosnja,
            "prosjecna_sedmicna_potrosnja": sedmicna,
            "dani_pokrivenosti": dani_pokrivenosti,
            "dani_pokrivenosti_status": status_pokrivenosti,
            "datum_posljednje_potrosnje": zapis["posljednja_potrosnja"],
            "datum_posljednje_isporuke": zapis["posljednja_isporuka"],
        }

    # Lijek bez ijedne transakcije, ali sa stanjem 0, ima tačno 0 dana zalihe.
    for lijek_id, podaci in rezultat.items():
        if Decimal(str(stanje_u_frizideru.get(lijek_id, 0) or 0)) <= 0:
            podaci["dani_pokrivenosti"] = 0
            podaci["dani_pokrivenosti_status"] = None

    return rezultat


def inventory_position(lijek, *, today=None, include_planned_need=True):
    """Kanonski fizički pregled jedne generičke grupe lijeka.

    Komisijska prava namjerno nisu dio fizičkog stanja. Aktivne
    ``PacijentRezervacija`` količine su fizičke rezervacije unutar frižidera,
    a kućne doze su zasebna fizička lokacija. Zbir rezervacija može biti veći
    od trenutnog stanja zbog historijskih ili neusaglašenih zapisa; taj manjak
    se izlaže zasebno i ne gubi se clampom slobodne zalihe na nulu.
    """
    from .medication_groups import strict_equivalent_medicine_ids
    from .models import Pacijent, PacijentRezervacija, PacijentZaduzenje, Termin, Zaliha

    from .request_cache import get_or_set

    today = today or timezone.localdate()
    medicine_ids = strict_equivalent_medicine_ids(lijek)
    cache_key = (tuple(sorted(medicine_ids)), today, bool(include_planned_need))
    return get_or_set(
        "inventory_position",
        cache_key,
        lambda: _inventory_position_uncached(
            lijek,
            today=today,
            medicine_ids=medicine_ids,
            include_planned_need=include_planned_need,
        ),
    )


def _inventory_position_uncached(lijek, *, today, medicine_ids, include_planned_need):
    from .models import (
        Pacijent,
        PacijentZaduzenje,
        PotrebaFizickogPokrica,
        Termin,
        Zaliha,
    )
    from .therapy_regimens import TYPE_HOME_SC, TYPE_ORAL, therapy_regimen_type

    in_fridge = Decimal(str(
        Zaliha.objects.filter(lijek_id__in=medicine_ids).aggregate(total=Sum("u_frizideru"))["total"] or 0
    ))
    reservation_patients = Pacijent.objects.filter(
        rezervacije_lijeka__lijek_id__in=medicine_ids,
        rezervacije_lijeka__aktivno=True,
        rezervacije_lijeka__kolicina__gt=0,
    ).distinct()
    reserved = sum(
        (
            patient_reservation_breakdown(
                patient,
                medicine_ids=medicine_ids,
            )["total_effective"]
            for patient in reservation_patients
        ),
        Decimal("0"),
    )
    at_patient = Decimal("0")
    regimen_type = therapy_regimen_type(lijek)
    if regimen_type == TYPE_HOME_SC:
        at_patient = Decimal(str(
            PacijentZaduzenje.objects.filter(
                lijek_id__in=medicine_ids,
                aktivno=True,
                preostalo__gt=0,
            ).aggregate(total=Sum("preostalo"))["total"] or 0
        ))
    elif regimen_type == TYPE_ORAL:
        from .oral_therapy import oral_quantity_at_patient

        at_patient = oral_quantity_at_patient(
            medicine_ids=medicine_ids,
            today=today,
        )
    planned_need = Decimal("0")
    if include_planned_need:
        # Jedan pacijent moĹľe imati viĹˇe buduÄ‡ih termina. Protokol se uÄŤita
        # jednom po pacijentu, umjesto jednom po svakom terminu.
        appointment_counts = Termin.objects.filter(
            lijek_id__in=medicine_ids,
            status="ZAKAZAN",
            datum__gte=today,
        ).values("pacijent_id").annotate(total=Count("id"))
        counts_by_patient = {
            row["pacijent_id"]: row["total"] for row in appointment_counts
        }
        if counts_by_patient:
            from .querysets import with_workflow_data

            patients = with_workflow_data(Pacijent.objects.filter(
                pk__in=counts_by_patient
            ))
            for patient in patients:
                planned_need += (
                    Decimal(str(patient.doza_po_aplikaciji() or 0))
                    * counts_by_patient[patient.pk]
                )

    freely_available = max(Decimal("0"), in_fridge - reserved)
    physical_reservation_shortfall = max(
        Decimal("0"),
        reserved - in_fridge,
    )
    awaiting_physical_coverage = Decimal(str(
        PotrebaFizickogPokrica.objects.filter(
            lijek_id__in=medicine_ids,
            status=PotrebaFizickogPokrica.STATUS_CEKA,
            preostala_kolicina__gt=0,
        ).aggregate(total=Sum("preostala_kolicina"))["total"] or 0
    ))

    return {
        "in_fridge": in_fridge,
        "reserved_in_fridge": reserved,
        "covered_reservations_in_fridge": min(in_fridge, reserved),
        "physical_reservation_shortfall": physical_reservation_shortfall,
        "awaiting_physical_coverage": awaiting_physical_coverage,
        "at_patient": at_patient,
        "total_physical": in_fridge + at_patient,
        "freely_available": freely_available,
        "planned_therapy_need": planned_need,
    }


def inventory_position_for_patient(pacijent, *, today=None):
    from .request_cache import get_or_set

    today = today or timezone.localdate()
    if pacijent and getattr(pacijent, "pk", None):
        medicine = pacijent.lijek
        phase_state = pacijent.aktivni_fazni_protokol()
        if phase_state:
            from .phased_protocols import current_phase_details

            medicine = current_phase_details(phase_state)["medicine"]
        medicine_ids = tuple(sorted(
            _physical_medicine_ids(medicine) if medicine else []
        ))
        return get_or_set(
            "inventory_position_for_patient",
            (pacijent.pk, getattr(medicine, "pk", None), medicine_ids, today),
            lambda: _inventory_position_for_patient_uncached(
                pacijent,
                medicine_ids=medicine_ids,
                today=today,
            ),
        )
    return _inventory_position_for_patient_uncached(pacijent, today=today)


def _inventory_position_for_patient_uncached(
    pacijent,
    *,
    medicine_ids=None,
    today=None,
):
    from .models import (
        PacijentRezervacija,
        PacijentZaduzenje,
        PotrebaFizickogPokrica,
    )
    from .therapy_regimens import TYPE_HOME_SC, TYPE_ORAL, therapy_regimen_type

    today = today or timezone.localdate()
    if not pacijent or not pacijent.lijek_id:
        return {
            "reserved_in_fridge": Decimal("0"),
            "awaiting_physical_coverage": Decimal("0"),
            "at_patient": Decimal("0"),
        }
    if medicine_ids is None:
        medicine = pacijent.lijek
        phase_state = pacijent.aktivni_fazni_protokol()
        if phase_state:
            from .phased_protocols import current_phase_details

            medicine = current_phase_details(phase_state)["medicine"]
        medicine_ids = _physical_medicine_ids(medicine)
    reserved = patient_reservation_breakdown(
        pacijent,
        medicine_ids=medicine_ids,
    )["total_effective"]
    prefetched_physical_needs = getattr(
        pacijent,
        "_workflow_physical_needs",
        None,
    )
    if prefetched_physical_needs is not None:
        medicine_ids_set = set(medicine_ids)
        awaiting_physical_coverage = sum(
            (
                Decimal(str(item.preostala_kolicina or 0))
                for item in prefetched_physical_needs
                if item.lijek_id in medicine_ids_set
            ),
            Decimal("0"),
        )
    else:
        awaiting_physical_coverage = Decimal(str(
            PotrebaFizickogPokrica.objects.filter(
                pacijent=pacijent,
                lijek_id__in=medicine_ids,
                status=PotrebaFizickogPokrica.STATUS_CEKA,
                preostala_kolicina__gt=0,
            ).aggregate(total=Sum("preostala_kolicina"))["total"] or 0
        ))
    at_patient = Decimal("0")
    regimen_type = therapy_regimen_type(pacijent.lijek)
    if regimen_type == TYPE_HOME_SC:
        prefetched = getattr(pacijent, "_workflow_assignments", None)
        if prefetched is not None:
            at_patient = sum(
                (
                    Decimal(str(item.preostalo or 0))
                    for item in prefetched
                    if item.lijek_id in medicine_ids
                ),
                Decimal("0"),
            )
        else:
            at_patient = Decimal(str(
                PacijentZaduzenje.objects.filter(
                    pacijent=pacijent,
                    lijek_id__in=medicine_ids,
                    aktivno=True,
                    preostalo__gt=0,
                ).aggregate(total=Sum("preostalo"))["total"] or 0
            ))
    elif regimen_type == TYPE_ORAL:
        from .oral_therapy import oral_quantity_at_patient

        at_patient = oral_quantity_at_patient(
            medicine_ids=medicine_ids,
            patient=pacijent,
            today=today,
        )
    return {
        "reserved_in_fridge": reserved,
        "awaiting_physical_coverage": awaiting_physical_coverage,
        "at_patient": at_patient,
    }


def free_stock_quantity(lijek, *, lock=False):
    """Vrati stvarnu nedodijeljenu količinu generičke grupe lijeka."""
    from .models import PacijentRezervacija, Zaliha

    medicine_ids = _physical_medicine_ids(lijek)
    stocks = Zaliha.objects.filter(lijek_id__in=medicine_ids)
    reservations = PacijentRezervacija.objects.filter(
        lijek_id__in=medicine_ids,
        aktivno=True,
        kolicina__gt=0,
    )
    if lock:
        # Agregatni SELECT ne garantuje zaključavanje redova na svim bazama.
        # Materijalizujemo ključeve prije obračuna kako dvije istovremene
        # dodjele ne bi potrošile istu slobodnu količinu.
        list(stocks.select_for_update().values_list("pk", flat=True))
        list(reservations.select_for_update().values_list("pk", flat=True))
    physical = Decimal(str(
        stocks.aggregate(total=Sum("u_frizideru"))["total"] or 0
    ))
    reserved = Decimal(str(
        reservations.aggregate(total=Sum("kolicina"))["total"] or 0
    ))
    return max(Decimal("0"), physical - reserved)


def free_stock_source_rows(lijek, *, lock=False):
    """FIFO porijeklo trenutno raspoloživog slobodnog salda."""
    from .medication_groups import strict_equivalent_medicine_ids
    from .models import ZalihaTransakcija

    medicine_ids = strict_equivalent_medicine_ids(lijek)
    queryset = ZalihaTransakcija.objects.filter(
        lijek_id__in=medicine_ids,
        tip=ZalihaTransakcija.TIP_OSLOBADJANJE_U_SLOBODNU_ZALIHU,
    ).order_by("kreirano", "id")
    if lock:
        queryset = queryset.select_for_update()
    releases = list(queryset)
    assigned_by_release = {
        row["referenca_id"]: Decimal(str(row["total"] or 0))
        for row in ZalihaTransakcija.objects.filter(
            lijek_id__in=medicine_ids,
            tip=ZalihaTransakcija.TIP_DODJELA_SLOBODNE_ZALIHE,
            referenca_tip="ZalihaTransakcija",
            referenca_id__isnull=False,
        ).values("referenca_id").annotate(total=Sum("kolicina"))
    }
    free_remaining = free_stock_quantity(lijek, lock=lock)
    rows = []
    for release in releases:
        source_remaining = max(
            Decimal("0"),
            Decimal(str(release.kolicina or 0))
            - assigned_by_release.get(release.pk, Decimal("0")),
        )
        if source_remaining <= 0 or free_remaining <= 0:
            continue
        visible_remaining = min(source_remaining, free_remaining)
        rows.append({
            "transaction": release,
            "patient": release.pacijent,
            "medicine": release.lijek,
            "quantity": visible_remaining,
            "released_quantity": Decimal(str(release.kolicina or 0)),
            "reason_code": release.razlog_kod,
            "reason_label": (
                release.get_razlog_kod_display()
                if release.razlog_kod else "Administrativna korekcija"
            ),
            "note": release.napomena,
            "event": (
                f"{release.referenca_tip} #{release.referenca_id}"
                if release.referenca_tip and release.referenca_id else
                release.referenca_tip or "Oslobađanje rezervacije"
            ),
            "created_at": release.kreirano,
        })
        free_remaining -= visible_remaining
    if free_remaining > 0:
        rows.append({
            "transaction": None,
            "patient": None,
            "medicine": lijek,
            "quantity": free_remaining,
            "released_quantity": free_remaining,
            "reason_code": "",
            "reason_label": "Ranije evidentirana slobodna zaliha",
            "note": "Izvor nije dostupan u historijskim zapisima.",
            "event": "Historijsko stanje",
            "created_at": None,
        })
    return tuple(rows)


def _validated_physical_quantity(quantity):
    try:
        quantity = Decimal(str(quantity or 0))
    except (TypeError, ValueError, ArithmeticError):
        raise ValueError("Količina mora biti pozitivan broj.") from None
    if not quantity.is_finite() or quantity <= 0:
        raise ValueError("Količina mora biti veća od nule.")
    return quantity


def _recalculate_patient_draft_after_inventory(
    patient,
    *,
    user=None,
    reason="Komisijski prijedlog preračunat nakon promjene rezervacije.",
):
    """Pozovi kanonski planner tek nakon uspješne fizičke mutacije."""

    if not patient or not getattr(patient, "pk", None):
        return None
    if (
        not getattr(patient, "lijek_id", None)
        or not patient.trenutni_korak_je_kucna_terapija()
    ):
        return None
    from .commission_planning import recalculate_patient_commission_drafts

    return recalculate_patient_commission_drafts(
        patient,
        user=user,
        reason=reason,
    )


def _lock_physical_inventory(lijek):
    """Zaključaj fizički saldo i sve alokacije ekvivalentne grupe."""
    from .models import PacijentRezervacija, Zaliha

    medicine_ids = _physical_medicine_ids(lijek)
    stocks = list(
        Zaliha.objects.select_for_update()
        .filter(lijek_id__in=medicine_ids)
        .order_by("lijek_id", "id")
    )
    reservations = list(
        PacijentRezervacija.objects.select_for_update()
        .filter(
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
        )
        .order_by("id")
    )
    physical = sum(
        (Decimal(str(stock.u_frizideru or 0)) for stock in stocks),
        Decimal("0"),
    )
    reserved = sum(
        (Decimal(str(item.kolicina or 0)) for item in reservations),
        Decimal("0"),
    )
    return medicine_ids, stocks, reservations, physical, reserved


def _pending_need_for_source(
    *,
    medicine_ids,
    pacijent,
    trebovanje=None,
    migracijski_snapshot=None,
    termin=None,
):
    from .models import PotrebaFizickogPokrica

    needs = PotrebaFizickogPokrica.objects.select_for_update().filter(
        pacijent=pacijent,
        lijek_id__in=medicine_ids,
        status=PotrebaFizickogPokrica.STATUS_CEKA,
        preostala_kolicina__gt=0,
    )
    if trebovanje is not None:
        return needs.filter(trebovanje=trebovanje).order_by("id").first()
    if migracijski_snapshot is not None:
        return needs.filter(
            migracijski_snapshot=migracijski_snapshot
        ).order_by("id").first()
    if termin is not None:
        return needs.filter(termin=termin).order_by("id").first()
    return None


@transaction.atomic
def reserve_physical_stock(
    *,
    pacijent,
    lijek,
    quantity,
    komisija=None,
    trebovanje=None,
    migracijski_snapshot=None,
    migracijsko_pocetno_stanje=None,
    termin=None,
    priority_date=None,
    user=None,
    note="",
):
    """Alociraj samo postojeću fizičku zalihu, a višak ostavi na čekanju.

    Funkcija je jedini write-path za nove fizičke rezervacije. Zaključavanje
    salda i svih aktivnih rezervacija iste generičke grupe sprečava da dvije
    sesije potroše istu posljednju slobodnu jedinicu.
    """
    from .models import Pacijent, PacijentRezervacija, PotrebaFizickogPokrica
    from .utils import upisi_log

    quantity = _validated_physical_quantity(quantity)
    pacijent = Pacijent.objects.select_for_update().get(pk=pacijent.pk)
    medicine_ids, _stocks, reservations, physical, reserved = (
        _lock_physical_inventory(lijek)
    )
    available = max(Decimal("0"), physical - reserved)
    allocated = min(quantity, available)
    waiting = quantity - allocated

    source_need = _pending_need_for_source(
        medicine_ids=medicine_ids,
        pacijent=pacijent,
        trebovanje=trebovanje,
        migracijski_snapshot=migracijski_snapshot,
        termin=termin,
    )
    source_reservation = None
    if source_need is not None:
        source_reservation = getattr(source_need, "fizicka_rezervacija", None)
    if source_reservation is None:
        source_reservations = PacijentRezervacija.objects.select_for_update().filter(
            pacijent=pacijent,
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
        )
        if trebovanje is not None:
            source_reservation = source_reservations.filter(
                trebovanje=trebovanje
            ).order_by("id").first()
        elif migracijski_snapshot is not None:
            source_reservation = source_reservations.filter(
                migracijski_snapshot=migracijski_snapshot
            ).order_by("id").first()
        elif termin is not None:
            source_reservation = source_reservations.filter(
                termin=termin
            ).order_by("id").first()
    if source_reservation is None and migracijski_snapshot is not None:
        # OneToOne migracijski izvor može već imati potrošenu/deaktiviranu
        # rezervaciju. Reaktiviraj isti red umjesto kreiranja paralelnog reda
        # (i kršenja jedinstvenosti snapshot-a).
        source_reservation = (
            PacijentRezervacija.objects.select_for_update()
            .filter(migracijski_snapshot=migracijski_snapshot)
            .order_by("id")
            .first()
        )

    if allocated > 0:
        if source_reservation is None:
            source_reservation = PacijentRezervacija.objects.create(
                pacijent=pacijent,
                lijek=lijek,
                komisija=komisija,
                trebovanje=trebovanje,
                migracijski_snapshot=migracijski_snapshot,
                migracijsko_pocetno_stanje=migracijsko_pocetno_stanje,
                potreba_fizickog_pokrica=source_need,
                termin=termin,
                kolicina=allocated,
                aktivno=True,
                napomena=note,
            )
        else:
            source_reservation.lijek = lijek
            source_reservation.komisija = komisija or source_reservation.komisija
            source_reservation.trebovanje = (
                trebovanje or source_reservation.trebovanje
            )
            source_reservation.migracijski_snapshot = (
                migracijski_snapshot or source_reservation.migracijski_snapshot
            )
            source_reservation.migracijsko_pocetno_stanje = (
                migracijsko_pocetno_stanje
                or source_reservation.migracijsko_pocetno_stanje
            )
            source_reservation.potreba_fizickog_pokrica = (
                source_need or source_reservation.potreba_fizickog_pokrica
            )
            source_reservation.termin = termin or source_reservation.termin
            source_reservation.kolicina = (
                Decimal(str(source_reservation.kolicina or 0)) + allocated
            )
            source_reservation.aktivno = True
            source_reservation.potrosena_at = None
            source_reservation.napomena = note or source_reservation.napomena
            source_reservation.save(update_fields=[
                "lijek",
                "komisija",
                "trebovanje",
                "migracijski_snapshot",
                "migracijsko_pocetno_stanje",
                "potreba_fizickog_pokrica",
                "termin",
                "kolicina",
                "aktivno",
                "potrosena_at",
                "napomena",
            ])

    pending_need = source_need
    if waiting > 0:
        if pending_need is None:
            pending_need = PotrebaFizickogPokrica.objects.create(
                pacijent=pacijent,
                lijek=lijek,
                komisija=komisija,
                trebovanje=trebovanje,
                migracijski_snapshot=migracijski_snapshot,
                termin=termin,
                trazena_kolicina=waiting,
                preostala_kolicina=waiting,
                prioritet_datum=priority_date,
                napomena=note,
            )
            if source_reservation is not None:
                source_reservation.potreba_fizickog_pokrica = pending_need
                source_reservation.save(
                    update_fields=["potreba_fizickog_pokrica"]
                )
        else:
            pending_need.trazena_kolicina = (
                Decimal(str(pending_need.trazena_kolicina or 0)) + waiting
            )
            pending_need.preostala_kolicina = (
                Decimal(str(pending_need.preostala_kolicina or 0)) + waiting
            )
            if priority_date and (
                not pending_need.prioritet_datum
                or priority_date < pending_need.prioritet_datum
            ):
                pending_need.prioritet_datum = priority_date
            pending_need.napomena = note or pending_need.napomena
            pending_need.save(update_fields=[
                "trazena_kolicina",
                "preostala_kolicina",
                "prioritet_datum",
                "napomena",
                "izmijenjeno",
            ])

    upisi_log(
        user,
        "Fizička alokacija lijeka",
        pacijent=pacijent,
        objekat=source_reservation or pending_need,
        opis=(
            f"{lijek.naziv}: traženo {quantity:g}; fizički rezervisano "
            f"{allocated:g}; čeka fizičko pokriće {waiting:g}; slobodno "
            f"prije alokacije {available:g}."
        ),
    )
    _recalculate_patient_draft_after_inventory(
        pacijent,
        user=user,
        reason="Komisijski prijedlog preračunat nakon promjene rezervacije.",
    )
    return {
        "requested": quantity,
        "allocated": allocated,
        "waiting": waiting,
        "reservation": source_reservation,
        "pending_need": pending_need,
    }


def _pending_physical_needs_for_update(medicine_ids):
    """Minimalni lock-query bez nullable relacijskih JOIN-ova."""

    from django.db.models import F

    from .models import PotrebaFizickogPokrica
    from .transaction_locking import select_for_update_self

    queryset = PotrebaFizickogPokrica.objects.filter(
        lijek_id__in=medicine_ids,
        status=PotrebaFizickogPokrica.STATUS_CEKA,
        preostala_kolicina__gt=0,
    ).order_by(
        F("prioritet_datum").asc(nulls_last=True),
        "kreirano",
        "id",
    )
    return select_for_update_self(queryset)


@transaction.atomic
def cover_pending_physical_needs(*, lijek, user=None):
    """Pretvori najstarije/datumom najbliže potrebe u fizičke rezervacije."""

    from .models import (
        MigracijskoPocetnoStanjeZalihe,
        PacijentRezervacija,
        PotrebaFizickogPokrica,
    )
    from .utils import upisi_log

    medicine_ids, _stocks, reservations, physical, reserved = (
        _lock_physical_inventory(lijek)
    )
    available = max(Decimal("0"), physical - reserved)
    if available <= 0:
        return {"allocated": Decimal("0"), "remaining_free": Decimal("0"), "items": []}

    # Zaključavamo samo PotrebaFizickogPokrica redove. Komisija, trebovanje,
    # migracijski snapshot i termin su opcioni FK-ovi; select_related nad njima
    # bi proizveo LEFT OUTER JOIN i nevažeći PostgreSQL ``FOR UPDATE``.
    needs = list(_pending_physical_needs_for_update(medicine_ids))
    total_allocated = Decimal("0")
    covered_items = []
    for need in needs:
        if available <= 0:
            break
        amount = min(available, Decimal(str(need.preostala_kolicina or 0)))
        reservation = PacijentRezervacija.objects.select_for_update().filter(
            potreba_fizickog_pokrica=need
        ).first()
        if reservation is None:
            migration_initial_state = (
                MigracijskoPocetnoStanjeZalihe.objects.filter(
                    lijek_id=need.lijek_id
                ).first()
                if need.migracijski_snapshot_id else None
            )
            reservation = PacijentRezervacija.objects.create(
                pacijent=need.pacijent,
                lijek=need.lijek,
                komisija=need.komisija,
                trebovanje=need.trebovanje,
                migracijski_snapshot=need.migracijski_snapshot,
                migracijsko_pocetno_stanje=migration_initial_state,
                potreba_fizickog_pokrica=need,
                termin=need.termin,
                kolicina=amount,
                aktivno=True,
                napomena="Pokriveno nakon fizičkog zaprimanja.",
            )
        else:
            reservation.kolicina = Decimal(str(reservation.kolicina or 0)) + amount
            reservation.aktivno = True
            reservation.potrosena_at = None
            reservation.save(update_fields=["kolicina", "aktivno", "potrosena_at"])
        need.preostala_kolicina = Decimal(str(need.preostala_kolicina)) - amount
        if need.preostala_kolicina <= 0:
            need.preostala_kolicina = Decimal("0")
            need.status = PotrebaFizickogPokrica.STATUS_POKRIVENA
        need.save(update_fields=["preostala_kolicina", "status", "izmijenjeno"])
        available -= amount
        total_allocated += amount
        covered_items.append((need, reservation, amount))

    if total_allocated > 0:
        upisi_log(
            user,
            "Pokrivanje potreba fizičkom zalihom",
            objekat=covered_items[0][0],
            opis=(
                f"{lijek.naziv}: iz novog slobodnog fizičkog stanja "
                f"alocirano {total_allocated:g}; preostalo slobodno "
                f"{available:g}. Prioritet: najbliži datum potrebe, zatim "
                "vrijeme nastanka zapisa."
            ),
        )
        for patient_id in {item[0].pacijent_id for item in covered_items}:
            patient = next(
                item[0].pacijent
                for item in covered_items
                if item[0].pacijent_id == patient_id
            )
            _recalculate_patient_draft_after_inventory(
                patient,
                user=user,
                reason=(
                    "Komisijski prijedlog preračunat nakon fizičkog "
                    "rezervisanja zaprimljenih doza."
                ),
            )
    return {
        "allocated": total_allocated,
        "remaining_free": available,
        "items": covered_items,
    }


@transaction.atomic
def consume_patient_physical_reservation(*, pacijent, lijek, quantity, termin=None):
    """Potroši pacijentovu alokaciju; ostatak smije doći samo iz free stocka."""
    from .models import PacijentRezervacija

    quantity = _validated_physical_quantity(quantity)
    medicine_ids, _stocks, all_reservations, physical, reserved = (
        _lock_physical_inventory(lijek)
    )
    patient_reservations = [
        item for item in all_reservations if item.pacijent_id == pacijent.pk
    ]
    if termin is not None:
        patient_reservations.sort(
            key=lambda item: (item.termin_id != termin.pk, item.datum_rezervacije, item.pk)
        )
    patient_reserved = sum(
        (Decimal(str(item.kolicina or 0)) for item in patient_reservations),
        Decimal("0"),
    )
    from_reservation = min(quantity, patient_reserved)
    from_free_stock = quantity - from_reservation
    free_before = max(Decimal("0"), physical - reserved)
    if from_free_stock > free_before:
        raise ValueError(
            "Terapija nema dovoljno fizičkog pokrića za ovog pacijenta. "
            f"Rezervisano {patient_reserved:g}, slobodno {free_before:g}, "
            f"potrebno {quantity:g}."
        )

    remaining = from_reservation
    changes = []
    for reservation in patient_reservations:
        if remaining <= 0:
            break
        current = Decimal(str(reservation.kolicina or 0))
        consumed = min(current, remaining)
        reservation.kolicina = current - consumed
        if reservation.kolicina <= 0:
            reservation.kolicina = Decimal("0")
            reservation.aktivno = False
            reservation.potrosena_at = timezone.now()
        reservation.save(update_fields=["kolicina", "aktivno", "potrosena_at"])
        changes.append({
            "rezervacija_id": reservation.pk,
            "kolicina": str(consumed),
        })
        remaining -= consumed
    _recalculate_patient_draft_after_inventory(
        pacijent,
        reason="Komisijski prijedlog preračunat nakon potrošnje rezervacije.",
    )
    return {
        "from_reservation": from_reservation,
        "from_free_stock": from_free_stock,
        "changes": changes,
    }


def _free_stock_candidate_from_planning_row(
    lijek,
    row,
    *,
    compatible_ids=None,
):
    """Prevedi kanonski planski red u sigurnu ručnu fizičku dodjelu.

    Ručna dodjela nije isto što i izvršenje već evidentirane
    ``PotrebaFizickogPokrica``. Kandidat mora imati datiranu fizički nepokrivenu
    potrebu u istom planskom horizontu koji koriste Zalihe, karton i komisijski
    planner, a konkretni proizvod mora odgovarati fizičkoj prezentaciji/SKU-u.
    """
    from .medication_groups import strict_equivalent_medicine_ids

    patient = row.get("pacijent") if row else None
    if (
        not patient
        or not patient.aktivan
        or patient.na_aktivnoj_pauzi()
    ):
        return None

    required_product = row.get("potreban_proizvod") or row.get("lijek")
    compatible_ids = (
        set(strict_equivalent_medicine_ids(lijek))
        if compatible_ids is None else compatible_ids
    )
    if not required_product or required_product.pk not in compatible_ids:
        return None

    events = tuple(row.get("buduci_fizicki_nepokriveni_detalji") or ())
    first = next(
        (
            item for item in events
            if item.get("datum")
            and Decimal(str(item.get("buduca_nepokrivena_potreba", 0) or 0)) > 0
        ),
        None,
    )
    if not first:
        return None

    missing = Decimal(str(first["buduca_nepokrivena_potreba"] or 0))
    required = Decimal(str(first.get("potrebna_kolicina", 0) or 0))
    if missing <= 0 or required <= 0:
        return None
    return {
        "pacijent": patient,
        "sljedeca_potreba": first["datum"],
        "potrebno": required,
        "nedostaje": missing,
        "maksimalno": missing,
        "potreban_proizvod": required_product,
        "terapijska_faza": row.get("terapijska_faza") or "",
    }


def free_stock_recipient_candidates(lijek, *, today=None, planning_rows=None):
    """Phase/SKU-aware kandidati izvedeni iz centralnog planning enginea."""
    if planning_rows is None:
        from .commission_planning import commission_planning_rows

        planning_rows = commission_planning_rows(today=today)
    from .medication_groups import strict_equivalent_medicine_ids

    compatible_ids = set(strict_equivalent_medicine_ids(lijek))
    candidates = []
    for row in planning_rows:
        candidate = _free_stock_candidate_from_planning_row(
            lijek,
            row,
            compatible_ids=compatible_ids,
        )
        if candidate:
            candidates.append(candidate)
    return tuple(sorted(
        candidates,
        key=lambda item: (
            item["sljedeca_potreba"],
            item["pacijent"].prezime,
            item["pacijent"].ime,
            item["pacijent"].pk,
        ),
    ))


def eligible_free_stock_recipients(lijek, *, today=None):
    """QuerySet pacijenata sa stvarnom budućom potrebom za ovim SKU-om."""
    from .models import Pacijent

    patient_ids = [
        item["pacijent"].pk
        for item in free_stock_recipient_candidates(lijek, today=today)
    ]
    return (
        Pacijent.objects.filter(pk__in=patient_ids)
        .select_related("lijek", "terapijski_protokol", "individualni_protokol")
        .order_by("prezime", "ime", "id")
    )


def active_reservation_details(lijek):
    """Operativni trag svih aktivnih rezervacija grupe lijeka."""
    from .medication_groups import strict_equivalent_medicine_ids
    from .models import PacijentRezervacija

    medicine_ids = set(strict_equivalent_medicine_ids(lijek))
    reservations = PacijentRezervacija.objects.filter(
        lijek_id__in=medicine_ids,
        aktivno=True,
        kolicina__gt=0,
    ).select_related(
        "pacijent",
        "pacijent__lijek",
        "lijek",
        "komisija",
        "trebovanje",
        "migracijski_snapshot",
        "migracijsko_pocetno_stanje",
    ).order_by("datum_rezervacije", "id")
    rows = []
    for reservation in reservations:
        patient = reservation.pacijent
        phase_state = patient.aktivni_fazni_protokol()
        phase_medicine_id = None
        if phase_state:
            from .phased_protocols import current_phase_details

            phase_medicine_id = current_phase_details(phase_state)["medicine"].pk
        same_medicine = bool(
            patient.lijek_id and patient.lijek_id in medicine_ids
        ) or bool(
            phase_medicine_id and phase_medicine_id in medicine_ids
        )
        has_protocol = bool(
            phase_state or patient.aktivni_protokol()
        ) if same_medicine else False
        clinically_valid = bool(patient.aktivan and same_medicine and has_protocol)
        if reservation.migracijski_snapshot_id:
            source = "Migracijski snapshot pacijenta"
        elif reservation.migracijsko_pocetno_stanje_id:
            source = "Početno stanje migracije"
        elif reservation.trebovanje_id:
            source = f"Zaprimanje po zahtjevu #{reservation.trebovanje_id}"
        elif reservation.komisija_id:
            source = f"Komisijsko odobrenje #{reservation.komisija_id}"
        elif reservation.napomena:
            source = reservation.napomena
        else:
            source = "Izvor nije evidentiran"
        rows.append({
            "rezervacija": reservation,
            "pacijent": patient,
            "kolicina": Decimal(str(reservation.kolicina or 0)),
            "status_pacijenta": "Aktivan" if patient.aktivan else "Neaktivan",
            "trenutni_lijek": patient.lijek,
            "izvor": source,
            "datum": reservation.datum_rezervacije,
            "opravdan_aktivni_izvor": clinically_valid,
            "razlog_nevazece": (
                "Pacijent više nije na ovom lijeku."
                if not same_medicine else
                "Pacijent nije aktivan."
                if not patient.aktivan else
                "Pacijent nema aktivan ili pripremljen protokol."
                if not has_protocol else ""
            ),
        })
    return rows


def _release_reason(reason_code, note, *, reference=None, patient=None):
    from .models import PromjenaTerapije, ZalihaTransakcija

    explicitly_selected = bool(reason_code)
    note = (note or "").strip()
    valid_codes = {
        ZalihaTransakcija.RAZLOG_PREKID_TERAPIJE,
        ZalihaTransakcija.RAZLOG_PROMJENA_LIJEKA,
        ZalihaTransakcija.RAZLOG_SMRTNI_SLUCAJ,
        ZalihaTransakcija.RAZLOG_DRUGO,
    }
    if not reason_code:
        folded = note.casefold()
        if isinstance(reference, PromjenaTerapije) or "promjen" in folded:
            reason_code = ZalihaTransakcija.RAZLOG_PROMJENA_LIJEKA
        elif "smrt" in folded or "premin" in folded:
            reason_code = ZalihaTransakcija.RAZLOG_SMRTNI_SLUCAJ
        elif "prekid" in folded or "deaktiv" in folded or (
            patient is not None and not patient.aktivan
        ):
            reason_code = ZalihaTransakcija.RAZLOG_PREKID_TERAPIJE
        else:
            reason_code = ZalihaTransakcija.RAZLOG_DRUGO
    if reason_code not in valid_codes:
        raise ValueError("Odaberite ispravan razlog oslobađanja doza.")
    if reason_code == ZalihaTransakcija.RAZLOG_DRUGO and not note:
        if explicitly_selected:
            raise ValueError("Za razlog ‘Drugo’ unesite napomenu.")
        # Kompatibilnost za ranije interne pozive i historijske zapise koji
        # nisu imali strukturirani razlog. Novi UI kod DRUGO uvijek zahtijeva
        # konkretnu napomenu.
        note = "Administrativno oslobađanje rezervacije."
    if not note:
        note = dict(ZalihaTransakcija.RAZLOZI_SLOBODNE_ZALIHE)[reason_code]
    return reason_code, note


@transaction.atomic
def release_patient_reservations_to_free_stock(
    *,
    pacijent,
    lijek,
    user=None,
    reason="",
    reason_code="",
    reference=None,
    event_date=None,
):
    """Ukloni pacijentsku raspodjelu bez promjene fizičkog salda."""
    from .medication_groups import strict_equivalent_medicine_ids
    from .models import PacijentRezervacija, ZalihaTransakcija
    from .utils import upisi_log

    medicine_ids = strict_equivalent_medicine_ids(lijek)
    before_free = free_stock_quantity(lijek, lock=True)
    reservations = list(
        PacijentRezervacija.objects.select_for_update().filter(
            pacijent=pacijent,
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
        ).order_by("datum_rezervacije", "id")
    )
    released = sum(
        (Decimal(str(item.kolicina or 0)) for item in reservations),
        Decimal("0"),
    )
    if released <= 0:
        return Decimal("0")
    for reservation in reservations:
        reservation.kolicina = Decimal("0")
        reservation.aktivno = False
        reservation.save(update_fields=["kolicina", "aktivno"])

    reason_code, note = _release_reason(
        reason_code,
        reason,
        reference=reference,
        patient=pacijent,
    )
    release = ZalihaTransakcija.objects.create(
        lijek=lijek,
        tip=ZalihaTransakcija.TIP_OSLOBADJANJE_U_SLOBODNU_ZALIHU,
        kolicina=released,
        promjena_salda=Decimal("0"),
        datum=event_date or timezone.localdate(),
        pacijent=pacijent,
        referenca_tip=reference.__class__.__name__ if reference else "",
        referenca_id=getattr(reference, "pk", None),
        korisnik=user if getattr(user, "is_authenticated", False) else None,
        napomena=note,
        razlog_kod=reason_code,
        lokacija=ZalihaTransakcija.LOKACIJA_FRIZIDER,
        rezervisana_pacijentu=False,
    )
    after_free = before_free + released
    upisi_log(
        user,
        "Oslobađanje doza u slobodnu zalihu",
        pacijent=pacijent,
        objekat=release,
        opis=(
            f"{lijek.naziv}: oslobođeno {released} sa pacijenta {pacijent}. "
            f"Rezervisano pacijentu {released} → 0; slobodno {before_free} → "
            f"{after_free}. Razlog: {note}"
        ),
    )
    _recalculate_patient_draft_after_inventory(
        pacijent,
        user=user,
        reason="Komisijski prijedlog preračunat nakon povrata rezervacije.",
    )
    return released


@transaction.atomic
def assign_free_stock_to_patient(
    *,
    pacijent,
    lijek,
    quantity,
    user=None,
    reason="",
    source_release=None,
):
    """Dodijeli slobodnu fizičku zalihu bez ulaza, isporuke ili komisije."""
    from .medication_groups import strict_equivalent_medicine_ids
    from .models import Pacijent, PacijentRezervacija, ZalihaTransakcija
    from .utils import upisi_log

    try:
        quantity = Decimal(str(quantity or 0))
    except (TypeError, ValueError, ArithmeticError):
        raise ValueError("Količina mora biti pozitivan cijeli broj.") from None
    if not quantity.is_finite():
        raise ValueError("Količina mora biti pozitivan cijeli broj.")
    if quantity <= 0:
        raise ValueError("Količina mora biti veća od 0.")
    if not lijek.dozvoljava_decimalnu_kolicinu and quantity != quantity.to_integral_value():
        raise ValueError("Za ovaj lijek količina mora biti cijeli broj.")
    # Ponovo učitavamo i zaključavamo primaoca unutar iste transakcije.
    # Tako validacije ne rade nad zastarjelim stanjem pacijenta dok drugi
    # zahtjev mijenja terapiju, pauzu ili status pacijenta.
    pacijent = Pacijent.objects.select_for_update().get(pk=pacijent.pk)
    medicine_ids = strict_equivalent_medicine_ids(lijek)
    if (
        not pacijent.aktivan
        or not pacijent.lijek_id
        or pacijent.lijek_id not in medicine_ids
        or not (
            pacijent.aktivni_protokol()
            or pacijent.aktivni_fazni_protokol()
        )
        or pacijent.na_aktivnoj_pauzi()
    ):
        raise ValueError("Odabrani pacijent nema aktivnu terapiju i protokol za ovaj lijek.")
    available = free_stock_quantity(lijek, lock=True)
    if quantity > available:
        raise ValueError(
            f"Dostupno je {available:g}, a zatraženo {quantity:g}."
        )
    candidate = next(
        (
            item for item in free_stock_recipient_candidates(lijek)
            if item["pacijent"].pk == pacijent.pk
        ),
        None,
    )
    if not candidate:
        raise ValueError(
            "Odabrani pacijent nema buduću fizički nepokrivenu potrebu za ovim proizvodom."
        )
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("Razlog dodjele je obavezan.")
    # Slobodan fizički saldo nije dovoljan dokaz porijekla. Dodjela je
    # dozvoljena samo do neiskorištenog zbira eksplicitnih događaja
    # oslobađanja (prekid/switch/smrt/drugo uz audit).
    releases = list(
        ZalihaTransakcija.objects.select_for_update().filter(
            lijek_id__in=medicine_ids,
            tip=ZalihaTransakcija.TIP_OSLOBADJANJE_U_SLOBODNU_ZALIHU,
        ).order_by("kreirano", "id")
    )
    release_balances = []
    proven_available = Decimal("0")
    for release in releases:
        already_assigned = Decimal(str(
            ZalihaTransakcija.objects.filter(
                tip=ZalihaTransakcija.TIP_DODJELA_SLOBODNE_ZALIHE,
                referenca_tip="ZalihaTransakcija",
                referenca_id=release.pk,
            ).aggregate(total=Sum("kolicina"))["total"] or 0
        ))
        source_available = max(
            Decimal("0"), Decimal(str(release.kolicina or 0)) - already_assigned
        )
        release_balances.append((release, source_available))
        proven_available += source_available
    if quantity > proven_available:
        raise ValueError(
            "Slobodna zaliha nema dokazano porijeklo za traženu količinu."
        )
    recipient_reservations = PacijentRezervacija.objects.select_for_update().filter(
            pacijent=pacijent,
            lijek_id__in=medicine_ids,
            aktivno=True,
            kolicina__gt=0,
    )
    locked_recipient_reservations = list(recipient_reservations.order_by("id"))
    previous_reserved = sum(
        (Decimal(str(item.kolicina or 0)) for item in locked_recipient_reservations),
        Decimal("0"),
    )
    free_stock_reservation = next(
        (
            item for item in locked_recipient_reservations
            if not item.komisija_id
            and not item.trebovanje_id
            and not item.migracijski_snapshot_id
            and not item.migracijsko_pocetno_stanje_id
        ),
        None,
    )
    note = reason
    if free_stock_reservation:
        reservation = free_stock_reservation
        reservation.kolicina = Decimal(str(reservation.kolicina or 0)) + quantity
        reservation.napomena = note
        reservation.save(update_fields=["kolicina", "napomena"])
    else:
        reservation = PacijentRezervacija.objects.create(
            pacijent=pacijent,
            lijek=pacijent.lijek,
            kolicina=quantity,
            aktivno=True,
            napomena=note,
        )

    # VAŽNO: ovaj QuerySet mora ostati bez select_related() i drugih
    # JOIN-ova. pacijent na ZalihaTransakcija je nullable FK; PostgreSQL ne
    # dozvoljava FOR UPDATE nad nullable stranom LEFT OUTER JOIN-a.
    remaining = quantity
    assignment_events = []
    source_labels = []
    for release, source_available in release_balances:
        if source_available <= 0:
            continue
        allocated = min(remaining, source_available)
        assignment_events.append(ZalihaTransakcija.objects.create(
            lijek=pacijent.lijek,
            tip=ZalihaTransakcija.TIP_DODJELA_SLOBODNE_ZALIHE,
            kolicina=allocated,
            promjena_salda=Decimal("0"),
            datum=timezone.localdate(),
            pacijent=pacijent,
            referenca_tip="ZalihaTransakcija",
            referenca_id=release.pk,
            korisnik=user if getattr(user, "is_authenticated", False) else None,
            napomena=reason,
            razlog_kod=ZalihaTransakcija.RAZLOG_DODJELA,
            lokacija=ZalihaTransakcija.LOKACIJA_FRIZIDER,
            rezervisana_pacijentu=True,
        ))
        source_patient = (
            f"pacijenta {release.pacijent}"
            if release.pacijent_id else "historijske slobodne zalihe"
        )
        source_reason = (
            release.get_razlog_kod_display()
            if release.razlog_kod else "razlog nije strukturirano evidentiran"
        )
        source_event = (
            f"{release.referenca_tip} #{release.referenca_id}"
            if release.referenca_tip and release.referenca_id else
            release.referenca_tip or "bez povezane poslovne reference"
        )
        source_labels.append(
            f"{allocated:g} od {source_patient} ({source_reason}; {source_event})"
        )
        remaining -= allocated
        if remaining <= 0:
            break

    source_label = "; ".join(source_labels)
    upisi_log(
        user,
        "Dodjela slobodne zalihe pacijentu",
        pacijent=pacijent,
        objekat=assignment_events[0],
        opis=(
            f"Dodjela slobodnih doza pacijentu. {lijek.naziv}: dodijeljeno "
            f"{quantity} pacijentu {pacijent}; izvor: {source_label}; "
            "izvorna slobodna zaliha: automatski FIFO (najstarije prvo); "
            f"odredišna rezervacija ID: {reservation.pk}; "
            f"slobodno {available} → {available - quantity}; "
            f"rezervisano primaocu {previous_reserved} → "
            f"{previous_reserved + quantity}; razlog: {reason}"
        ),
    )
    _recalculate_patient_draft_after_inventory(
        pacijent,
        user=user,
        reason="Komisijski prijedlog preračunat nakon dodjele slobodne doze.",
    )
    return reservation


def _inventory_rows_for_stock_risk(*, today=None):
    from .models import Komisija, Lijek, Pacijent, PacijentRezervacija, PacijentZaduzenje, PotrebaFizickogPokrica, Terapija, Termin, Zaliha
    from .medication_groups import therapy_group_bucket_key
    from .querysets import with_workflow_data
    from .services import izracunaj_status_pacijenta
    from .commission_demand import commission_demand_v2_enabled
    from .therapy_regimens import (
        TYPE_ORAL,
        inventory_behavior,
        therapy_regimen_type,
    )

    today = today or timezone.localdate()
    planning_by_patient = {}
    commission_draft = None
    if commission_demand_v2_enabled():
        from .commission_planning import (
            commission_draft_snapshot,
            commission_planning_rows,
        )

        planning_rows = commission_planning_rows(today=today)
        planning_by_patient = {
            row["pacijent"].pk: row for row in planning_rows
        }
        commission_draft = commission_draft_snapshot(rows=planning_rows)

    svi_lijekovi = list(Lijek.objects.filter(
        Q(zaliha__isnull=False)
        | Q(pacijent__aktivan=True)
        | Q(pacijentzaduzenje__aktivno=True, pacijentzaduzenje__preostalo__gt=0)
        | Q(zaliha_transakcije__isnull=False)
    ).distinct().order_by("genericki_naziv", "naziv"))
    lijekovi_po_grupi = {}
    for lijek in svi_lijekovi:
        lijekovi_po_grupi.setdefault(therapy_group_bucket_key(lijek), []).append(lijek)

    zalihe_po_lijeku = {
        zaliha.lijek_id: zaliha
        for zaliha in Zaliha.objects.filter(lijek__in=svi_lijekovi).select_related("lijek")
    }
    stanje_po_lijeku = {
        lijek.id: Decimal(str(zalihe_po_lijeku[lijek.id].u_frizideru or 0))
        if lijek.id in zalihe_po_lijeku else Decimal("0")
        for lijek in svi_lijekovi
    }
    operativni_po_lijeku = operativni_podaci_zaliha(
        [lijek.id for lijek in svi_lijekovi],
        stanje_u_frizideru=stanje_po_lijeku,
    )
    redovi = []

    for lijekovi_grupe in lijekovi_po_grupi.values():
        lijek_ids = [item.id for item in lijekovi_grupe]
        pacijenti = list(with_workflow_data(
            Pacijent.objects.filter(aktivan=True, lijek_id__in=lijek_ids).exclude(
                pauze_terapije__aktivna=True
            )
        ).order_by("prezime", "ime"))
        # Za prikaz preferiramo konkretan lijek aktivnog pacijenta, zatim lijek sa
        # zalihom. Poslovni zbir ispod uvijek obuhvata cijelu genericku grupu.
        lijek = (
            pacijenti[0].lijek if pacijenti
            else next((item for item in lijekovi_grupe if item.id in zalihe_po_lijeku), lijekovi_grupe[0])
        )
        aktivni_pacijenti = bool(pacijenti)
        aktivna_zaduzenja = PacijentZaduzenje.objects.filter(
            lijek_id__in=lijek_ids,
            aktivno=True,
            preostalo__gt=0,
        ).exists()
        fizicko_stanje = inventory_position(lijek)
        u_frizideru = fizicko_stanje["in_fridge"]
        regimen_type = therapy_regimen_type(lijek)
        behavior = inventory_behavior(lijek)
        # SC prezentacija sama po sebi nije kućni workflow. Ustekinumab može
        # istovremeno imati ambulantne i kućne pacijente na istom SKU-u, pa
        # projekciju uključujemo prema trenutnom stanju svakog pacijenta.
        kucni_pacijenti = [
            pacijent
            for pacijent in pacijenti
            if pacijent.trenutni_korak_je_kucna_terapija()
        ]
        grupa_je_kucna = bool(lijek.kucna_terapija or kucni_pacijenti)
        grupa_je_oralna = regimen_type == TYPE_ORAL
        ima_aktivnu_osnovu = bool(
            aktivni_pacijenti
            or aktivna_zaduzenja
            or fizicko_stanje["at_patient"] > 0
        )
        kod_pacijenata = (
            fizicko_stanje["at_patient"]
            if behavior.patient_quantity_applicable and ima_aktivnu_osnovu
            else Decimal("0")
        )
        minimum_30_dana = sum(
            (Decimal(str(pacijent.doze_za_period(ceil(Decimal("30") / Decimal("7"))) or 0)) for pacijent in pacijenti),
            Decimal("0"),
        )
        potreba_3_mjeseca = sum(
            (Decimal(str(pacijent.doze_za_period(13) or 0)) for pacijent in pacijenti),
            Decimal("0"),
        )

        detalji = []
        za_novu_komisiju = Decimal("0")
        izracunata_potreba_komisije = Decimal("0")
        broj_terapija_komisije = 0
        broj_terapija_nepoznat = False
        komisijska_osnovna_potreba = Decimal("0")
        komisijska_sigurnosna_rezerva = Decimal("0")
        jedinica_nabavke = None
        potreba_do_ocekivane_isporuke = Decimal("0")
        buduca_nepokrivena_potreba = Decimal("0")
        buduca_potreba_pokrivena_slobodnom_zalihom = Decimal("0")
        buduca_potreba_pokrivena_incoming = Decimal("0")
        buduca_potreba_bez_pouzdanog_pokrica = Decimal("0")
        pokriveno_postojecim_zahtjevima = Decimal("0")
        odobreno_u_postojecim_zahtjevima = Decimal("0")
        odobreno_ceka_zaprimanje = Decimal("0")
        rezervisano = fizicko_stanje["reserved_in_fridge"]
        fizicki_pokrivene_rezervacije = fizicko_stanje[
            "covered_reservations_in_fridge"
        ]
        physical_shortfall = fizicko_stanje[
            "physical_reservation_shortfall"
        ]
        awaiting_physical_coverage = fizicko_stanje[
            "awaiting_physical_coverage"
        ]
        pending_by_patient = {
            item["pacijent_id"]: Decimal(str(item["total"] or 0))
            for item in PotrebaFizickogPokrica.objects.filter(
                lijek_id__in=lijek_ids,
                status=PotrebaFizickogPokrica.STATUS_CEKA,
                preostala_kolicina__gt=0,
            ).values("pacijent_id").annotate(total=Sum("preostala_kolicina"))
        }
        rezervacije_detalji = active_reservation_details(lijek)
        nevazece_rezervacije = [
            item for item in rezervacije_detalji
            if not item["opravdan_aktivni_izvor"]
        ]
        ceka_zaprimanje = False
        nepotpun_komisijski_plan = False
        rizik_dostave = False
        rizicna_terapija = None
        rizicna_isporuka = None
        planirana_fizicka_potreba = Decimal("0")
        datum_sljedece_komisije = None
        ima_poznat_buduci_raspored = False
        prvi_bez_pokrica_detalj = None
        potrebe_po_komisijskom_ciklusu = {}
        kucne_projekcije = []
        rezultati_planiranja = []
        danas = today

        for pacijent in pacijenti:
            workflow = izracunaj_status_pacijenta(pacijent)
            planning = planning_by_patient.get(pacijent.pk)
            home_projection = None
            pacijent_je_kucni = pacijent.trenutni_korak_je_kucna_terapija()
            if pacijent_je_kucni:
                from .home_therapy import calculate_home_therapy_projection

                home_projection = (
                    planning.get("home_projection") if planning else None
                ) or calculate_home_therapy_projection(
                    pacijent,
                    today=today,
                )
                kucne_projekcije.append(home_projection)
            if planning:
                planning_result = planning["planning_result"]
                commission_decision = planning.get("commission_decision")
                if commission_decision is not None:
                    pokriveno_postojecim_zahtjevima += Decimal(str(
                        commission_decision.existing_request_quantity or 0
                    ))
                    if commission_decision.existing_request_state_code in {
                        "APPROVED",
                        "PARTIALLY_RECEIVED",
                    }:
                        odobreno_u_postojecim_zahtjevima += Decimal(str(
                            commission_decision.existing_request_approved_quantity
                            or commission_decision.existing_request_quantity
                            or 0
                        ))
                        awaiting_for_patient = Decimal(str(
                            commission_decision
                            .existing_request_awaiting_receipt_quantity
                            or 0
                        ))
                        odobreno_ceka_zaprimanje += awaiting_for_patient
                        ceka_zaprimanje = (
                            ceka_zaprimanje or awaiting_for_patient > 0
                        )
                rezultati_planiranja.append(planning_result)
                nepotpun_komisijski_plan = nepotpun_komisijski_plan or (
                    not planning_result.planiranje_moguce
                )
                pacijent_za_komisiju = Decimal(str(planning["za_novu_komisiju"] or 0))
                izracunata_potreba_komisije += Decimal(str(planning["neto_nedostatak"] or 0))
                if pacijent_za_komisiju > 0:
                    broj_terapija = planning.get("broj_terapija_za_komisiju")
                    if broj_terapija is None:
                        broj_terapija_nepoznat = True
                    else:
                        broj_terapija_komisije += int(broj_terapija)
                    jedinica_nabavke = (
                        planning.get("jedinica_nabavke") or jedinica_nabavke
                    )
                if planning.get("rizik_dostave"):
                    terapija_rizika = planning.get("rizicna_terapija")
                    if (
                        not rizik_dostave
                        or (
                            terapija_rizika
                            and (
                                rizicna_terapija is None
                                or terapija_rizika < rizicna_terapija
                            )
                        )
                    ):
                        rizicna_terapija = terapija_rizika
                        rizicna_isporuka = (
                            planning.get("ocekivani_datum_dolaska")
                            or planning.get("procijenjeni_datum_dolaska")
                        )
                    rizik_dostave = True
                potreba_do_ocekivane_isporuke += Decimal(str(planning["ukupno_potrebno"] or 0))
                buduca_nepokrivena_potreba += Decimal(str(
                    planning.get("buduca_nepokrivena_potreba", 0) or 0
                ))
                buduca_potreba_pokrivena_slobodnom_zalihom += Decimal(str(
                    planning.get(
                        "buduca_potreba_pokrivena_slobodnom_zalihom", 0
                    ) or 0
                ))
                buduca_potreba_pokrivena_incoming += Decimal(str(
                    planning.get("buduca_potreba_pokrivena_incoming", 0) or 0
                ))
                buduca_potreba_bez_pouzdanog_pokrica += Decimal(str(
                    planning.get(
                        "buduca_potreba_bez_pouzdanog_pokrica", 0
                    ) or 0
                ))
                pacijent_rezervisano = Decimal(str(
                    planning["coverage"]["reserved_in_fridge"] or 0
                ))
                ima_poznat_buduci_raspored = (
                    ima_poznat_buduci_raspored
                    or bool(planning.get("ima_poznat_buduci_raspored"))
                    or home_projection is not None
                )
                selected_cycle = planning.get("preporuceni_komisijski_ciklus")
                selected_cycle_quantity = Decimal(str(
                    planning.get("kolicina_za_sljedecu_komisiju", 0) or 0
                ))
                if selected_cycle and selected_cycle_quantity > 0:
                    cycle_entry = potrebe_po_komisijskom_ciklusu.setdefault(
                        selected_cycle.datum_komisije,
                        {
                            "ciklus": selected_cycle,
                            "kolicina": Decimal("0"),
                            "upozorenje": False,
                        },
                    )
                    cycle_entry["kolicina"] += selected_cycle_quantity
                    cycle_entry["upozorenje"] = bool(
                        cycle_entry["upozorenje"]
                        or planning.get("isporuka_preblizu_terapiji")
                    )
            else:
                pacijent_za_komisiju = Decimal(str(workflow.get("za_novu_komisiju") or 0))
                izracunata_potreba_komisije += Decimal(str(
                    workflow.get("potrebe_komisije", {}).get("izracunata_potreba") or 0
                ))
                potreba_do_ocekivane_isporuke += Decimal(str(
                    workflow.get("potrebe_komisije", {}).get("ukupno_potrebno") or 0
                ))
                pacijent_rezervisano = Decimal(str(
                    workflow.get("rezervisano_u_frizideru_za_pacijenta") or 0
                ))
            za_novu_komisiju += pacijent_za_komisiju
            ceka_zaprimanje = ceka_zaprimanje or (
                workflow.get("status") in {
                    "Komisijski pokriven - ceka zaprimanje",
                    "Potrebno zaprimanje pošiljke",
                    "Potrebno zaprimanje poĹˇiljke",
                }
            )
            pokriven_do = planning["pokriven_do"] if planning else workflow.get("pokriven_do")
            if pokriven_do and (
                datum_sljedece_komisije is None or pokriven_do < datum_sljedece_komisije
            ):
                datum_sljedece_komisije = pokriven_do

            prefetched_appointments = getattr(pacijent, "_workflow_appointments", None)
            if prefetched_appointments is not None:
                sljedeci_termin = next((
                    item for item in prefetched_appointments
                    if item.lijek_id in lijek_ids and item.datum >= danas
                ), None)
            else:
                sljedeci_termin = Termin.objects.filter(
                    pacijent=pacijent,
                    lijek_id__in=lijek_ids,
                    status="ZAKAZAN",
                    datum__gte=danas,
                ).order_by("datum", "vrijeme").first()
            sljedeca_terapija = (
                sljedeci_termin.datum if sljedeci_termin else workflow.get("sljedeca_terapija")
            )
            if home_projection:
                # Kućna terapija ima protokolarni raspored i kada nema
                # ambulantnog Termina. Centralna projekcija je jedini izvor
                # datuma pokrivenosti i narednog izdavanja.
                sljedeca_terapija = home_projection.first_uncovered_therapy
            if not pacijent_je_kucni and sljedeci_termin:
                planirana_fizicka_potreba += Decimal(str(pacijent.doza_po_aplikaciji() or 0))
                ima_poznat_buduci_raspored = True

            komisijsko_odobrenje_evidentirano = Komisija.objects.filter(
                pacijent=pacijent,
                lijek_id__in=lijek_ids,
                status__in=Komisija.VAZECI_STATUSI,
                preostale_doze__gt=0,
            ).exists()
            detalj_pokrivenosti = {
                "pacijent": pacijent,
                "oralna_terapija": grupa_je_oralna,
                "dnevna_potrosnja_tableta": (
                    Decimal(str(planning.get("dnevna_potrosnja_tableta", 0) or 0))
                    if grupa_je_oralna and planning else Decimal("0")
                ),
                "nova_komisija_potrebna": bool(
                    planning and planning.get("nova_komisija_potrebna")
                ),
                "oralno_preostalo_odobreno": (
                    Decimal(str(planning.get("odobreno_preostalo", 0) or 0))
                    if grupa_je_oralna and planning else Decimal("0")
                ),
                "preostalo_na_komisiji": (
                    planning["odobreno_preostalo"]
                    if planning else workflow.get("preostalo_na_komisiji") or Decimal("0")
                ),
                "kod_pacijenta": (
                    home_projection.patient_quantity
                    if home_projection else (
                        Decimal(str(
                            (planning.get("oralni_obracun") or {}).get(
                                "trenutno_kod_pacijenta", 0
                            ) or 0
                        ))
                        if grupa_je_oralna and planning else
                        workflow.get("kod_pacijenta") or Decimal("0")
                    )
                ),
                "rezervisano": pacijent_rezervisano,
                "ceka_fizicko_pokrice": pending_by_patient.get(
                    pacijent.pk, Decimal("0")
                ),
                "buduca_nepokrivena_potreba": (
                    Decimal(str(
                        planning.get("buduca_nepokrivena_potreba", 0) or 0
                    ))
                    if planning else Decimal("0")
                ),
                "buduca_potreba_pokrivena_slobodnom_zalihom": (
                    Decimal(str(planning.get(
                        "buduca_potreba_pokrivena_slobodnom_zalihom", 0
                    ) or 0))
                    if planning else Decimal("0")
                ),
                "buduca_potreba_pokrivena_incoming": (
                    Decimal(str(planning.get(
                        "buduca_potreba_pokrivena_incoming", 0
                    ) or 0))
                    if planning else Decimal("0")
                ),
                "buduca_potreba_bez_pouzdanog_pokrica": (
                    Decimal(str(planning.get(
                        "buduca_potreba_bez_pouzdanog_pokrica", 0
                    ) or 0))
                    if planning else Decimal("0")
                ),
                "komisijsko_odobrenje_evidentirano": (
                    komisijsko_odobrenje_evidentirano
                ),
                "fizicki_bez_komisijske_osnove": bool(
                    pacijent_rezervisano > 0
                    and not komisijsko_odobrenje_evidentirano
                ),
                "sljedeca_terapija": sljedeca_terapija,
                "sljedece_izdavanje": (
                    home_projection.next_dispensing
                    if home_projection else (
                        planning.get("sljedece_potrebno_izdavanje")
                        if grupa_je_oralna and planning else
                        workflow.get("sljedece_izdavanje")
                    )
                ),
                "workflow_status": workflow.get("status"),
                "planning_result": (
                    planning["planning_result"] if planning else None
                ),
                "ukljucen_u_nacrt": bool(
                    planning and planning.get("ukljucen_u_nacrt")
                ),
                "rizik_dostave": bool(
                    planning and planning.get("rizik_dostave")
                ),
                "ima_poznat_buduci_raspored": bool(
                    home_projection
                    or sljedeci_termin
                    or (planning and planning.get("ima_poznat_buduci_raspored"))
                ),
                "pocetak_nije_zakazan": bool(
                    planning and planning.get("relativna_pocetna_projekcija")
                ),
                "prva_nepokrivena_terapija": (
                    home_projection.first_uncovered_therapy
                    if home_projection else (
                        planning.get("prva_fizicki_nepokrivena_terapija")
                        if planning else None
                    )
                ),
                "potrebno_za_prvu_nepokrivenu": (
                    home_projection.units_per_application
                    if home_projection else (
                        planning.get("prva_fizicki_nepokrivena_potrebno")
                        if planning else Decimal("0")
                    )
                ),
                "nedostaje_za_prvu_nepokrivenu": (
                    home_projection.units_per_application
                    if home_projection else (
                        planning.get("prva_fizicki_nepokrivena_nedostaje")
                        if planning else Decimal("0")
                    )
                ),
                "fizicki_pokriven_do": (
                    home_projection.physical_covered_until
                    if home_projection else (
                        planning.get("fizicki_pokriven_do_operativno")
                        if planning else None
                    )
                ),
                "planirano_pokriven_do": (
                    home_projection.planned_covered_until
                    if home_projection else (
                        planning.get("planirano_pokriven_do_operativno")
                        if planning else None
                    )
                ),
                "home_projection": home_projection,
                "najkasniji_komisijski_ciklus": (
                    planning.get("posljednja_sigurna_komisija")
                    if planning else None
                ),
                "preporuceni_komisijski_ciklus": (
                    planning.get("preporuceni_komisijski_ciklus")
                    if planning else None
                ),
                "posljednji_siguran_datum_za_ukljucivanje": (
                    planning.get("posljednji_siguran_datum_za_ukljucivanje")
                    if planning else None
                ),
                "ocekivana_pouzdana_isporuka": (
                    planning.get("ocekivana_pouzdana_isporuka")
                    if planning else None
                ),
                "isporuka_preblizu_terapiji": bool(
                    planning and planning.get("isporuka_preblizu_terapiji")
                ),
                "preporuka_za_preporuceni_ciklus": (
                    Decimal(str(planning.get("kolicina_za_sljedecu_komisiju", 0) or 0))
                    if planning else Decimal("0")
                ),
                "komisijska_preporuka": (
                    Decimal(str(
                        planning["commission_decision"].additional_quantity_current_cycle
                        if planning and planning.get("commission_decision")
                        else planning.get("final_procurement_units", 0)
                        if planning else 0
                    ))
                    if planning and (
                        planning.get("included_in_draft")
                        or planning.get("commission_decision")
                    )
                    else Decimal("0")
                ),
                "komisijska_osnovna_potreba": (
                    Decimal(str(planning.get("minimalno_potrebno", 0) or 0))
                    if planning and planning.get("included_in_draft")
                    else Decimal("0")
                ),
                "komisijska_sigurnosna_rezerva": (
                    Decimal(str(planning.get("sigurnosna_rezerva", 0) or 0))
                    if planning and planning.get("included_in_draft")
                    else Decimal("0")
                ),
            }
            if (
                detalj_pokrivenosti["planirano_pokriven_do"]
                == detalj_pokrivenosti["fizicki_pokriven_do"]
            ):
                detalj_pokrivenosti["planirano_pokriven_do"] = None
            detalji.append(detalj_pokrivenosti)
            if detalj_pokrivenosti["prva_nepokrivena_terapija"] and (
                prvi_bez_pokrica_detalj is None
                or detalj_pokrivenosti["prva_nepokrivena_terapija"]
                < prvi_bez_pokrica_detalj["prva_nepokrivena_terapija"]
            ):
                prvi_bez_pokrica_detalj = detalj_pokrivenosti

        if commission_draft is not None:
            draft_group = commission_draft["groups"].get(
                therapy_group_bucket_key(lijek)
            )
            za_novu_komisiju = (
                draft_group["final_requested_quantity"]
                if draft_group else Decimal("0")
            )
            komisijska_osnovna_potreba = (
                draft_group["base_required_quantity"]
                if draft_group else Decimal("0")
            )
            komisijska_sigurnosna_rezerva = (
                draft_group["safety_reserve_quantity"]
                if draft_group else Decimal("0")
            )
        preporucena_potreba_ciklusa = (
            potrebe_po_komisijskom_ciklusu[
                min(potrebe_po_komisijskom_ciklusu)
            ]
            if potrebe_po_komisijskom_ciklusu else None
        )
        nabavka_komisije = procurement_breakdown(za_novu_komisiju, lijek)
        # Sve prikaze i izvještaje hranimo istom, paketno zaokruženom količinom.
        # Neto potreba ostaje dostupna zasebno u
        # ``izracunata_potreba_komisije``.
        za_novu_komisiju = nabavka_komisije["rounded_procurement_units"]

        for detalj in detalji:
            detalj["prvi_bez_pokrica"] = bool(
                prvi_bez_pokrica_detalj
                and detalj is prvi_bez_pokrica_detalj
            )

        odobreno_preostalo_za_buduce_pokrice = sum(
            (
                Decimal(str(detalj["preostalo_na_komisiji"] or 0))
                for detalj in detalji
            ),
            Decimal("0"),
        )
        kandidati_slobodne_zalihe = free_stock_recipient_candidates(
            lijek,
            today=today,
            planning_rows=planning_by_patient.values(),
        )

        if physical_shortfall > 0:
            status = "Fizički manjak rezervacija"
        elif awaiting_physical_coverage > 0:
            status = "Još nije fizički osigurano"
        elif not aktivni_pacijenti:
            status = "Nema aktivnih pacijenata"
        elif nepotpun_komisijski_plan:
            status = "Za pregled"
        elif planirana_fizicka_potreba > u_frizideru:
            # Fizički manjak za sljedeći termin nije isto što i komisijska
            # nepokrivenost. Ako kanonski plan ne traži novu komisiju, pravo
            # pacijenta još pokriva plan i korisniku treba prikazati operativno
            # upozorenje, a ne kontradiktoran kritični status.
            status = (
                "Niska fizička zaliha — trenutno pokriveno"
                if za_novu_komisiju <= 0
                else "Kritično"
            )
        elif za_novu_komisiju > 0:
            status = "Potrebna komisija"
        elif grupa_je_kucna and rezervisano > 0:
            status = "Spremno za izdavanje"
        elif ceka_zaprimanje:
            status = "Čeka zaprimanje"
        else:
            status = "U redu"

        status_css = {
            "U redu": "ok",
            "Fizički manjak rezervacija": "critical",
            "Još nije fizički osigurano": "waiting",
            "Kritično": "critical",
            "Potrebna komisija": "commission",
            "Čeka zaprimanje": "waiting",
            "Spremno za izdavanje": "ready",
            "Niska fizička zaliha — trenutno pokriveno": "waiting",
            "Nema aktivnih pacijenata": "neutral",
            "Za pregled": "neutral",
        }[status]

        operativni_podaci_primjenjivi = aktivni_pacijenti
        if operativni_podaci_primjenjivi:
            potrosnja_30_dana = sum(
                (operativni_po_lijeku[item.id]["potrosnja_30_dana"] for item in lijekovi_grupe),
                Decimal("0"),
            )
            prosjecna_sedmicna = (potrosnja_30_dana / Decimal("30") * Decimal("7")).quantize(
                Decimal("0.1"), rounding=ROUND_HALF_UP
            )
            if u_frizideru <= 0:
                dani_pokrivenosti = 0
                dani_pokrivenosti_status = None
            elif potrosnja_30_dana > 0:
                dani_pokrivenosti = int(
                    (u_frizideru / (potrosnja_30_dana / Decimal("30"))).to_integral_value(rounding=ROUND_FLOOR)
                )
                dani_pokrivenosti_status = None
            else:
                dani_pokrivenosti = None
                dani_pokrivenosti_status = "Nema dovoljno podataka"

            posljednje_potrosnje = [
                operativni_po_lijeku[item.id]["datum_posljednje_potrosnje"]
                for item in lijekovi_grupe
                if operativni_po_lijeku[item.id]["datum_posljednje_potrosnje"]
            ]
            posljednje_isporuke = [
                operativni_po_lijeku[item.id]["datum_posljednje_isporuke"]
                for item in lijekovi_grupe
                if operativni_po_lijeku[item.id]["datum_posljednje_isporuke"]
            ]
            if grupa_je_kucna:
                stvarne_primjene = Terapija.objects.filter(
                    pacijent__in=kucni_pacijenti,
                    lijek_id__in=lijek_ids,
                    workflow_status=Terapija.STATUS_POTVRDJENA,
                    is_migration=False,
                    kucno_izdavanje__isnull=True,
                    datum__gte=today - timedelta(days=29),
                    datum__lte=today,
                )
                potrosnja_30_dana = Decimal(str(
                    stvarne_primjene.aggregate(total=Sum("kolicina"))["total"] or 0
                ))
                prosjecna_sedmicna = (
                    potrosnja_30_dana / Decimal("30") * Decimal("7")
                ).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
                posljednje_potrosnje = [
                    projection.last_administered_on
                    for projection in kucne_projekcije
                    if projection.last_administered_on
                ]
        else:
            # Historijski ledger može namjerno ostati nakon reseta pacijenata,
            # ali bez aktivnog kliničkog konteksta ne predstavlja operativnu
            # prognozu. Fizičko stanje ostaje prikazano zasebno i ne mijenja se.
            potrosnja_30_dana = Decimal("0")
            prosjecna_sedmicna = Decimal("0.0")
            dani_pokrivenosti = None
            dani_pokrivenosti_status = "Nije primjenjivo"
            posljednje_potrosnje = []
            posljednje_isporuke = []

        redovi.append({
            "lijek": lijek,
            "lijekovi_u_grupi": lijekovi_grupe,
            "therapy_type": regimen_type,
            "inventory_behavior": behavior,
            "inventory_stock_label": behavior.stock_label,
            "inventory_reserved_label": behavior.reserved_label,
            "inventory_free_label": behavior.free_label,
            "inventory_patient_label": behavior.patient_quantity_label,
            "inventory_patient_help": behavior.patient_quantity_help,
            "inventory_patient_source": behavior.patient_quantity_source,
            "u_frizideru": u_frizideru,
            "kod_pacijenata": kod_pacijenata,
            "kod_pacijenata_primjenjivo": (
                behavior.patient_quantity_applicable
            ),
            "kucna_terapija": grupa_je_kucna,
            "oralna_terapija": grupa_je_oralna,
            "jedinica_kod_pacijenata": lijek.jedinica_zalihe_za_kolicinu(
                kod_pacijenata
            ),
            "za_novu_komisiju": za_novu_komisiju,
            "izracunata_potreba_komisije": izracunata_potreba_komisije,
            "neto_jedinica_prikaza": procurement_unit_display_label(
                izracunata_potreba_komisije,
                lijek,
            ),
            "nabavka_komisije": nabavka_komisije,
            "broj_pakovanja_komisije": nabavka_komisije["package_count"],
            "velicina_pakovanja_komisije": nabavka_komisije["units_per_package"],
            "komisijska_osnovna_potreba": komisijska_osnovna_potreba,
            "komisijska_sigurnosna_rezerva": komisijska_sigurnosna_rezerva,
            "broj_terapija_komisije": (
                None if broj_terapija_nepoznat else broj_terapija_komisije
            ),
            "jedinica_nabavke": (
                jedinica_nabavke
                or nabavka_komisije["unit_display_label"]
            ),
            "potreba_do_ocekivane_isporuke": potreba_do_ocekivane_isporuke,
            "buduca_nepokrivena_potreba": buduca_nepokrivena_potreba,
            "buduca_potreba_pokrivena_slobodnom_zalihom": (
                buduca_potreba_pokrivena_slobodnom_zalihom
            ),
            "buduca_potreba_pokrivena_incoming": (
                buduca_potreba_pokrivena_incoming
            ),
            "buduca_potreba_bez_pouzdanog_pokrica": (
                buduca_potreba_bez_pouzdanog_pokrica
            ),
            "pokriveno_postojecim_zahtjevima": (
                pokriveno_postojecim_zahtjevima
            ),
            "odobreno_u_postojecim_zahtjevima": (
                odobreno_u_postojecim_zahtjevima
            ),
            "odobreno_ceka_zaprimanje": odobreno_ceka_zaprimanje,
            "ceka_zaprimanje": ceka_zaprimanje,
            "rezervisano": rezervisano,
            "fizicki_pokrivene_rezervacije": fizicki_pokrivene_rezervacije,
            "physical_shortfall": physical_shortfall,
            "ceka_fizicko_pokrice": awaiting_physical_coverage,
            "odobreno_preostalo_za_buduce_pokrice": (
                odobreno_preostalo_za_buduce_pokrice
            ),
            "rezervacije_detalji": rezervacije_detalji,
            "broj_nevazecih_rezervacija": sum(
                1 for item in rezervacije_detalji
                if not item["opravdan_aktivni_izvor"]
            ),
            "nevazeca_rezervisana_kolicina": sum(
                (item["kolicina"] for item in nevazece_rezervacije),
                Decimal("0"),
            ),
            "planirana_fizicka_potreba": planirana_fizicka_potreba,
            "ukupno_fizicko_stanje": fizicko_stanje["total_physical"],
            "slobodno_raspolozivo": fizicko_stanje["freely_available"],
            "broj_kandidata_za_slobodnu_dodjelu": len(
                kandidati_slobodne_zalihe
            ),
            "detalji": detalji,
            "minimum_30_dana": minimum_30_dana,
            "potreba_3_mjeseca": potreba_3_mjeseca,
            "broj_aktivnih_pacijenata": len(pacijenti),
            "status": status,
            "status_css": status_css,
            "planiranje_nepotpuno": nepotpun_komisijski_plan,
            "procjena_moguca": not nepotpun_komisijski_plan,
            "razlozi_nepotpunog_planiranja": tuple(dict.fromkeys(
                result.razlog
                for result in rezultati_planiranja
                if not result.planiranje_moguce
            )),
            "tipovi_planiranja": tuple(dict.fromkeys(
                result.tip_terapije for result in rezultati_planiranja
            )),
            "neklasicno_planiranje": any(
                not result.klasicna_ambulantna_terapija
                for result in rezultati_planiranja
            ),
            "rizik_dostave": rizik_dostave,
            "rizicna_terapija": rizicna_terapija,
            "rizicna_isporuka": rizicna_isporuka,
            "datum_sljedece_komisije": datum_sljedece_komisije,
            "preporuceni_komisijski_ciklus": (
                preporucena_potreba_ciklusa["ciklus"]
                if preporucena_potreba_ciklusa else None
            ),
            "kolicina_za_preporuceni_ciklus": (
                preporucena_potreba_ciklusa["kolicina"]
                if preporucena_potreba_ciklusa else Decimal("0")
            ),
            "preporuceni_ciklus_isporuka_preblizu": bool(
                preporucena_potreba_ciklusa
                and preporucena_potreba_ciklusa["upozorenje"]
            ),
            "ima_poznat_buduci_raspored": ima_poznat_buduci_raspored,
            "prvi_pacijent_bez_pokrica": (
                prvi_bez_pokrica_detalj["pacijent"]
                if prvi_bez_pokrica_detalj else None
            ),
            "prvi_pacijent_bez_pokrica_datum": (
                prvi_bez_pokrica_detalj["prva_nepokrivena_terapija"]
                if prvi_bez_pokrica_detalj else None
            ),
            "prvi_pacijent_bez_pokrica_potrebno": (
                prvi_bez_pokrica_detalj["potrebno_za_prvu_nepokrivenu"]
                if prvi_bez_pokrica_detalj else Decimal("0")
            ),
            "prvi_pacijent_bez_pokrica_nedostaje": (
                prvi_bez_pokrica_detalj["nedostaje_za_prvu_nepokrivenu"]
                if prvi_bez_pokrica_detalj else Decimal("0")
            ),
            "prvi_pacijent_fizicki_pokriven_do": (
                prvi_bez_pokrica_detalj["fizicki_pokriven_do"]
                if prvi_bez_pokrica_detalj else None
            ),
            "prvi_pacijent_planirano_pokriven_do": (
                prvi_bez_pokrica_detalj["planirano_pokriven_do"]
                if prvi_bez_pokrica_detalj else None
            ),
            "prvi_pacijent_najkasniji_komisijski_ciklus": (
                prvi_bez_pokrica_detalj["najkasniji_komisijski_ciklus"]
                if prvi_bez_pokrica_detalj else None
            ),
            "operativni_podaci_primjenjivi": operativni_podaci_primjenjivi,
            "potrosnja_30_dana": potrosnja_30_dana,
            "prosjecna_sedmicna_potrosnja": prosjecna_sedmicna,
            "dani_pokrivenosti": dani_pokrivenosti,
            "dani_pokrivenosti_status": dani_pokrivenosti_status,
            "datum_posljednje_potrosnje": max(posljednje_potrosnje) if posljednje_potrosnje else None,
            "datum_posljednje_isporuke": max(posljednje_isporuke) if posljednje_isporuke else None,
            "home_physical_covered_until": min(
                (item.physical_covered_until for item in kucne_projekcije if item.physical_covered_until),
                default=None,
            ),
            "home_first_uncovered_therapy": min(
                (item.first_uncovered_therapy for item in kucne_projekcije if item.first_uncovered_therapy),
                default=None,
            ),
            "home_next_dispensing": min(
                (item.next_dispensing for item in kucne_projekcije if item.next_dispensing),
                default=None,
            ),
        })

    return redovi


def zalihe_sa_potrebama():
    """Kompatibilni javni ulaz; statusi uvijek dolaze iz StockRiskService-a."""
    from .stock_risk import StockRiskService

    return StockRiskService().rows()


def _kod_pacijenata_za_lijek(lijek):
    from .models import PacijentZaduzenje
    from .therapy_regimens import TYPE_HOME_SC, TYPE_ORAL, therapy_regimen_type

    regimen_type = therapy_regimen_type(lijek)
    if regimen_type == TYPE_HOME_SC:
        return Decimal(str(
            PacijentZaduzenje.objects.filter(
                lijek=lijek,
                aktivno=True,
                preostalo__gt=0,
            ).aggregate(total=Sum("preostalo"))["total"] or 0
        ))
    if regimen_type == TYPE_ORAL:
        from .oral_therapy import oral_quantity_at_patient

        return oral_quantity_at_patient(medicine_ids=(lijek.pk,))
    return Decimal("0")


def izracunaj_frizider_iz_transakcija(lijek):
    from .models import MigracijskoPocetnoStanjeZalihe, ZalihaTransakcija

    initial_state = MigracijskoPocetnoStanjeZalihe.objects.filter(
        lijek=lijek
    ).first()
    ukupno = (
        Decimal(str(initial_state.kolicina or 0))
        if initial_state is not None
        else Decimal("0")
    )
    transactions = ZalihaTransakcija.objects.filter(lijek=lijek)
    if initial_state is not None:
        # NULL znači da prije snapshotovanja nije postojala nijedna
        # transakcija; buduće transakcije zato počinju od ID-a većeg od 0.
        transactions = transactions.filter(
            id__gt=(initial_state.ledger_checkpoint_id or 0)
        )
    for transakcija in transactions:
        ukupno += transakcija.frizider_delta()
    return ukupno


def rekalkulisi_fizicke_zalihe(*, commit=False, korisnik=None):
    from .models import Lijek, Zaliha, ZalihaTransakcija
    from .utils import upisi_log

    lijekovi = Lijek.objects.filter(
        Q(zaliha__isnull=False)
        | Q(zaliha_transakcije__isnull=False)
        | Q(pacijentzaduzenje__aktivno=True, pacijentzaduzenje__preostalo__gt=0)
    ).distinct().order_by("naziv")
    rezultat = []

    with transaction.atomic():
        for lijek in lijekovi:
            zaliha = Zaliha.objects.select_for_update().filter(lijek=lijek).first()
            prije_frizider = Decimal(str(zaliha.u_frizideru or 0)) if zaliha else Decimal("0")
            prije_kod = Decimal(str(zaliha.kod_pacijenata or 0)) if zaliha else Decimal("0")
            izracunati_frizider = izracunaj_frizider_iz_transakcija(lijek)
            izracunati_kod = _kod_pacijenata_za_lijek(lijek)
            upozorenja = []
            poslije_frizider = izracunati_frizider
            if izracunati_frizider < 0:
                upozorenja.append("Transakcije daju negativnu zalihu; vrijednost je zaustavljena na 0.")
                poslije_frizider = Decimal("0")

            if commit:
                zaliha, _ = Zaliha.objects.select_for_update().get_or_create(
                    lijek=lijek,
                    defaults={"minimum": 2},
                )
                zaliha.u_frizideru = poslije_frizider
                zaliha.kod_pacijenata = izracunati_kod
                zaliha.save(update_fields=["u_frizideru", "kod_pacijenata", "ukupno"])

            rezultat.append({
                "lijek": lijek,
                "prije_frizider": prije_frizider,
                "poslije_frizider": poslije_frizider,
                "prije_kod": prije_kod,
                "poslije_kod": izracunati_kod,
                "broj_transakcija": ZalihaTransakcija.objects.filter(lijek=lijek).count(),
                "upozorenja": upozorenja,
            })

        if commit:
            upisi_log(
                korisnik,
                "Rekalkulacija fizickih zaliha",
                opis=f"Rekalkulisano {len(rezultat)} lijekova iz transakcija zalihe.",
            )

    return rezultat


def kriticne_zalihe_iz_potreba():
    from .stock_risk import StockRiskService

    return StockRiskService().critical_rows()


def status_zalihe_iz_potreba(u_frizideru, minimum_30_dana, potreba_3_mjeseca):
    u_frizideru = Decimal(str(u_frizideru or 0))
    minimum_30_dana = Decimal(str(minimum_30_dana or 0))
    potreba_3_mjeseca = Decimal(str(potreba_3_mjeseca or 0))

    if u_frizideru < minimum_30_dana:
        return "Kritično"
    if u_frizideru < potreba_3_mjeseca:
        return "Planirati nabavku"
    return "U redu"
