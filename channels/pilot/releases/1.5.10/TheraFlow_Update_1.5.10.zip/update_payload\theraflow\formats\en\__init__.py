"""English locale overrides used by the current TheraFlow installation."""
