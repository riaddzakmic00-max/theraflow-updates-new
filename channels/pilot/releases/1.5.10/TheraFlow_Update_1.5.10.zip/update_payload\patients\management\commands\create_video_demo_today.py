from datetime import datetime

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from patients.models import Terapija, TerapijaStatusHistorija, Termin, ZalihaTransakcija
from patients.utils import upisi_log
from patients.video_demo import (
    VIDEO_DEMO_MARKER,
    VIDEO_DEMO_NOTE,
    find_demo_patient,
    today,
    validate_demo_patient_for_appointment,
    video_demo_environment_allowed,
)


class Command(BaseCommand):
    help = "Kreira jedan strogo ograničen termin za današnje video snimanje."

    def add_arguments(self, parser):
        parser.add_argument("--jmbg", required=True)
        parser.add_argument("--time", default="09:00")

    @transaction.atomic
    def handle(self, *args, **options):
        if not video_demo_environment_allowed():
            raise CommandError(
                "Video demo komanda je dozvoljena samo lokalno ili uz DEBUG=True."
            )

        try:
            appointment_time = datetime.strptime(options["time"], "%H:%M").time()
        except ValueError as exc:
            raise CommandError("Vrijeme mora biti u formatu HH:MM, npr. 09:00.") from exc

        try:
            patient = find_demo_patient(options["jmbg"])
            _protocol, quantity = validate_demo_patient_for_appointment(patient)
        except ValueError as exc:
            raise CommandError(str(exc)) from exc

        patient = patient.__class__.objects.select_for_update().get(pk=patient.pk)
        appointment_date = today()
        existing = list(
            Termin.objects.select_for_update()
            .filter(pacijent=patient, datum=appointment_date)
            .order_by("id")
        )
        if existing:
            if (
                len(existing) == 1
                and existing[0].historija_statusa.filter(
                    razlog__startswith=VIDEO_DEMO_MARKER
                ).exists()
            ):
                self.stdout.write(
                    self.style.WARNING(
                        f"Video demo termin već postoji: {patient}, "
                        f"{appointment_date:%d.%m.%Y.} u "
                        f"{existing[0].vrijeme:%H:%M}."
                    )
                )
                return
            raise CommandError(
                "Pacijent već ima termin za današnji datum; novi demo termin "
                "nije kreiran."
            )

        counts_before = {
            "therapies": Terapija.objects.filter(pacijent=patient).count(),
            "transactions": ZalihaTransakcija.objects.filter(pacijent=patient).count(),
        }
        appointment = Termin(
            pacijent=patient,
            lijek=patient.lijek,
            datum=appointment_date,
            vrijeme=appointment_time,
            kolicina_po_terapiji=quantity,
            status=Termin.STATUS_PLANIRANA,
        )
        # Jedini izuzetak: model dobija prolaznu oznaku za vikend validaciju.
        # Oznaka se ne sprema u bazu i nijedan drugi put zakazivanja je ne koristi.
        appointment._allow_demo_weekend_validation = True
        try:
            appointment.full_clean()
        finally:
            delattr(appointment, "_allow_demo_weekend_validation")
        appointment.save()

        TerapijaStatusHistorija.objects.create(
            pacijent=patient,
            termin=appointment,
            novi_status=Termin.STATUS_PLANIRANA,
            razlog=VIDEO_DEMO_NOTE,
            novo_stanje={
                "tip_dogadjaja": TerapijaStatusHistorija.DOGADJAJ_NOVI_TERMIN,
                "datum": appointment_date.isoformat(),
                "vrijeme": appointment_time.isoformat(timespec="minutes"),
                "video_demo": True,
            },
        )
        upisi_log(
            None,
            "Kreiran video demo termin",
            pacijent=patient,
            objekat=appointment,
            opis=VIDEO_DEMO_NOTE,
        )

        if (
            Terapija.objects.filter(pacijent=patient).count()
            != counts_before["therapies"]
            or ZalihaTransakcija.objects.filter(pacijent=patient).count()
            != counts_before["transactions"]
        ):
            raise CommandError(
                "Sigurnosna provjera nije prošla; transakcija je vraćena."
            )

        self.stdout.write(
            self.style.SUCCESS(
                f"Kreiran VIDEO DEMO TERMIN za {patient}: "
                f"{appointment_date:%d.%m.%Y.} u {appointment_time:%H:%M}."
            )
        )
        self.stdout.write(VIDEO_DEMO_NOTE)
        self.stdout.write("Nisu kreirani budući termini niti terapijska potrošnja.")
