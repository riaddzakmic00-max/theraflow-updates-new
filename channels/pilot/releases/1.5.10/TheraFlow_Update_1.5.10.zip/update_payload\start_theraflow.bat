@echo off
setlocal EnableExtensions
set "APP_URL=http://127.0.0.1:8000/"
set "LOG_DIR=%ProgramData%\TheraFlow\logs\application"

sc query "TheraFlow" >nul 2>&1
if errorlevel 1 goto service_error
sc query "TheraFlow" | find /I "RUNNING" >nul 2>&1
if errorlevel 1 sc start "TheraFlow" >nul 2>&1

for /l %%I in (1,1,30) do (
    powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri '%APP_URL%login/' -TimeoutSec 3; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 400){exit 0} } catch {}; exit 1" >nul 2>&1
    if not errorlevel 1 (
        start "" "%APP_URL%"
        exit /b 0
    )
    timeout /t 2 /nobreak >nul
)
echo TheraFlow nije odgovorio na lokalnom URL-u.
echo Provjerite: %LOG_DIR%
exit /b 1

:service_error
echo TheraFlow Windows servis nije instaliran.
echo Provjerite: %ProgramData%\TheraFlow\logs\install_runtime.log
exit /b 1
