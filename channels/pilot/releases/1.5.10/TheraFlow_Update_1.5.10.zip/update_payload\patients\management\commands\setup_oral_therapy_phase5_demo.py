from datetime import date
from decimal import Decimal
from pathlib import Path
import uuid

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from patients.models import (
    IzdavanjeOralneTerapije,
    KomisijskaSaglasnost,
    KomisijskaStavkaLijeka,
    KomisijskiCiklus,
    KomisijskiZahtjev,
    Lijek,
    OralniTerapijskiRezim,
    Pacijent,
    Terapija,
    Termin,
    Zaliha,
)
from patients.oral_therapy import confirm_oral_regimen, issue_oral_therapy


DEMO_USERNAME = "phase5-demo"
DEMO_PASSWORD = "Phase5Demo!2026"
ISSUE_DATE = date(2026, 8, 10)
DEMO_SPECS = (
    {
        "key": "xeljanz",
        "jmbg": "9905000000001",
        "patient": ("Amina", "Xeljanz Demo"),
        "name": "Xeljanz Phase 5 Demo 5 mg",
        "brand": "Xeljanz",
        "generic": "Tofacitinib",
        "strength": Decimal("5"),
        "stock": Decimal("300"),
        "approved": Decimal("168"),
        "tablets_per_intake": Decimal("1"),
        "intakes_per_day": 2,
        "package": 56,
        "diagnosis": "Ulcerozni kolitis",
        "mkb": "K51.9",
    },
    {
        "key": "entecavir",
        "jmbg": "9905000000002",
        "patient": ("Emir", "Entecavir Demo"),
        "name": "Entecavir Phase 5 Demo 0.5 mg",
        "brand": "Entecavir",
        "generic": "Entecavir",
        "strength": Decimal("0.5"),
        "stock": Decimal("260"),
        "approved": Decimal("180"),
        "tablets_per_intake": Decimal("1"),
        "intakes_per_day": 1,
        "package": 30,
        "diagnosis": "Hronični hepatitis B",
        "mkb": "B18.1",
    },
    {
        "key": "tenofovir",
        "jmbg": "9905000000003",
        "patient": ("Lejla", "Tenofovir Demo"),
        "name": "Tenofovir Phase 5 Demo 245 mg",
        "brand": "Tenofovir",
        "generic": "Tenofovir disoproxil",
        "strength": Decimal("245"),
        "stock": Decimal("180"),
        "approved": Decimal("90"),
        "tablets_per_intake": Decimal("1"),
        "intakes_per_day": 1,
        "package": 30,
        "diagnosis": "Hronični hepatitis B",
        "mkb": "B18.1",
    },
)


class Command(BaseCommand):
    help = "Priprema testni Phase 5 demo za tri oralna lijeka istim engineom."

    def add_arguments(self, parser):
        parser.add_argument(
            "--stage",
            choices=("ready", "issued"),
            default="ready",
        )

    def _assert_test_database(self):
        database_name = str(settings.DATABASES["default"]["NAME"])
        if Path(database_name).name != ".test_theraflow.sqlite3":
            raise CommandError(
                "Demo komanda je dozvoljena samo nad .test_theraflow.sqlite3 bazom."
            )

    def _user(self):
        user, _created = get_user_model().objects.get_or_create(
            username=DEMO_USERNAME,
            defaults={
                "email": "phase5-demo@theraflow.local",
                "is_staff": True,
                "is_superuser": True,
            },
        )
        user.is_staff = True
        user.is_superuser = True
        user.set_password(DEMO_PASSWORD)
        user.save()
        return user

    @transaction.atomic
    def _ready(self):
        user = self._user()
        existing_patients = Pacijent.objects.filter(
            jmbg__in=[spec["jmbg"] for spec in DEMO_SPECS]
        )
        IzdavanjeOralneTerapije.objects.filter(
            pacijent__in=existing_patients
        ).delete()
        KomisijskiZahtjev.objects.filter(pacijent__in=existing_patients).delete()
        existing_patients.delete()
        KomisijskiCiklus.objects.filter(naziv__startswith="KOM-PHASE5-DEMO-").delete()

        patients = []
        for index, spec in enumerate(DEMO_SPECS, start=1):
            medicine, _created = Lijek.objects.update_or_create(
                naziv=spec["name"],
                defaults={
                    "zasticeno_ime": spec["brand"],
                    "genericki_naziv": spec["generic"],
                    "jacina_mg": spec["strength"],
                    "put_primjene": Lijek.PUT_PO,
                    "farmaceutski_oblik": Lijek.OBLIK_TABLETA,
                    "nacin_primjene": Lijek.NACIN_ORALNA_TERAPIJA,
                    "jedinica_terapije": "tableta",
                    "jedinica_terapije_mnozina": "tablete",
                    "jedinica_zalihe": "tableta",
                    "jedinica_zalihe_mnozina": "tablete",
                    "broj_tableta_u_pakovanju": spec["package"],
                    "izdavanje_cijelih_pakovanja": True,
                    "aktivan": True,
                },
            )
            Zaliha.objects.update_or_create(
                lijek=medicine,
                defaults={
                    "u_frizideru": spec["stock"],
                    "kod_pacijenata": Decimal("0"),
                },
            )
            patient = Pacijent.objects.create(
                ime=spec["patient"][0],
                prezime=spec["patient"][1],
                jmbg=spec["jmbg"],
                dijagnoza=spec["diagnosis"],
                mkb_sifra=spec["mkb"],
                lijek=medicine,
                aktivan=True,
            )
            confirm_oral_regimen(
                patient=patient,
                medicine=medicine,
                tablets_per_intake=spec["tablets_per_intake"],
                intakes_per_day=spec["intakes_per_day"],
                effective_from=ISSUE_DATE,
                phase=(
                    OralniTerapijskiRezim.FAZA_INDUKCIJA
                    if spec["key"] == "xeljanz"
                    else OralniTerapijskiRezim.FAZA_ODRZAVANJE
                ),
                doctor_note="Doktorski potvrđen Phase 5 demo režim.",
                user=user,
            )
            cycle = KomisijskiCiklus.objects.create(
                naziv=f"KOM-PHASE5-DEMO-{index}",
                mjesec=8,
                godina=2026,
                status="zavrseno",
            )
            request = KomisijskiZahtjev.objects.create(
                komisijski_ciklus=cycle,
                pacijent=patient,
                vrsta_zahtjeva=(
                    KomisijskiZahtjev.VrstaZahtjeva.HEPATITIS_B_PRODUZENJE
                    if spec["key"] != "xeljanz"
                    else KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_PRODUZENJE
                ),
                status=KomisijskiZahtjev.Status.ODLUCENO,
                finalna_kolicina=spec["approved"],
            )
            KomisijskaStavkaLijeka.objects.create(
                komisijski_zahtjev=request,
                lijek=medicine,
                jacina=f"{spec['strength']:g} mg",
                oblik="tableta",
                kolicina=spec["approved"],
                odobrena_kolicina=spec["approved"],
                jedinica=KomisijskaStavkaLijeka.Jedinica.TABLETA,
                redoslijed=1,
            )
            KomisijskaSaglasnost.objects.create(
                komisijski_zahtjev=request,
                broj_saglasnosti=f"P5-{spec['key'].upper()}-2026",
                datum_saglasnosti=ISSUE_DATE,
                odluka=KomisijskaSaglasnost.Odluka.ODOBRENO,
            )
            patients.append(patient)
        return patients, user

    @transaction.atomic
    def _issued(self):
        patients = list(
            Pacijent.objects.filter(
                jmbg__in=[spec["jmbg"] for spec in DEMO_SPECS]
            ).select_related("lijek")
        )
        if len(patients) != len(DEMO_SPECS):
            patients, user = self._ready()
        else:
            user = self._user()
        patient_by_jmbg = {patient.jmbg: patient for patient in patients}
        for spec in DEMO_SPECS:
            patient = patient_by_jmbg[spec["jmbg"]]
            regimen = patient.oralni_rezimi.get(aktivan=True)
            item = patient.komisijski_zahtjevi_faza1.get().stavke_lijeka.get(
                lijek=patient.lijek
            )
            issue_oral_therapy(
                patient=patient,
                regimen=regimen,
                approval_source=f"stavka:{item.pk}",
                quantity=int(spec["approved"]),
                issued_on=ISSUE_DATE,
                idempotency_key=uuid.uuid5(
                    uuid.NAMESPACE_URL,
                    f"theraflow-phase5-demo-{spec['key']}",
                ),
                batch=f"LOT-{spec['key'].upper()}-2026",
                note="Phase 5 demonstracijsko izdavanje.",
                user=user,
            )
        return list(patient_by_jmbg.values()), user

    def handle(self, *args, **options):
        self._assert_test_database()
        stage = options["stage"]
        patients, _user = self._ready() if stage == "ready" else self._issued()
        ordered = {patient.jmbg: patient for patient in patients}
        summaries = []
        for spec in DEMO_SPECS:
            patient = ordered[spec["jmbg"]]
            stock = Zaliha.objects.get(lijek=patient.lijek)
            issue = patient.oralna_izdavanja.filter(status="AKTIVNO").first()
            summaries.append(
                f"{spec['key']}#patient={patient.pk}:stock={stock.u_frizideru:g}:"
                f"coverage_days={issue.pokrivenost_dana if issue else 0}"
            )
        self.stdout.write(
            self.style.SUCCESS(
                f"Phase 5 demo stage={stage}; " + "; ".join(summaries)
            )
        )
        self.stdout.write(f"Login: {DEMO_USERNAME} / {DEMO_PASSWORD}")
        self.stdout.write(
            f"Safety: Termin={Termin.objects.filter(pacijent__in=patients).count()}, "
            f"Terapija={Terapija.objects.filter(pacijent__in=patients).count()}."
        )
