from django.db import migrations


def backfill_free_stock_reasons(apps, schema_editor):
    StockTransaction = apps.get_model("patients", "ZalihaTransakcija")
    releases = StockTransaction.objects.filter(
        tip="RELEASE_TO_FREE_STOCK",
        razlog_kod="",
    )
    for row in releases.iterator():
        note = (row.napomena or "").casefold()
        if "smrt" in note or "premin" in note:
            reason = "SMRTNI_SLUCAJ"
        elif "promjen" in note or "stari lijek" in note:
            reason = "PROMJENA_LIJEKA"
        elif "prekid" in note or "deaktiv" in note:
            reason = "PREKID_TERAPIJE"
        else:
            reason = "DRUGO"
            if not row.napomena:
                row.napomena = "Historijsko administrativno oslobađanje."
        row.razlog_kod = reason
        row.save(update_fields=["razlog_kod", "napomena"])

    StockTransaction.objects.filter(
        tip="ASSIGN_FREE_STOCK_TO_PATIENT",
        razlog_kod="",
    ).update(razlog_kod="DODJELA")


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0090_zalihatransakcija_razlog_kod"),
    ]

    operations = [
        migrations.RunPython(
            backfill_free_stock_reasons,
            migrations.RunPython.noop,
        ),
    ]
