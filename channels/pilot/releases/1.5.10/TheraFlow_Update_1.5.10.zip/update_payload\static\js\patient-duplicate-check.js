(function () {
    "use strict";

    const form = document.querySelector("[data-duplicate-check-url]");
    if (!form) return;

    const fields = {
        jmbg: form.querySelector("#id_jmbg"),
        ime: form.querySelector("#id_ime"),
        prezime: form.querySelector("#id_prezime"),
        datum_rodenja: form.querySelector("#id_datum_rodenja"),
    };
    const warning = form.querySelector("[data-patient-duplicate-warning]");
    const warningText = form.querySelector("[data-patient-duplicate-text]");
    const warningLink = form.querySelector("[data-patient-duplicate-link]");
    const jmbgStatus = form.querySelector("[data-patient-jmbg-status]");
    if (!fields.jmbg || !warning || !warningText || !warningLink) return;

    let timer = null;
    let requestVersion = 0;

    function hideWarning() {
        warning.hidden = true;
        warningLink.removeAttribute("href");
        fields.jmbg.setCustomValidity("");
        if (jmbgStatus) jmbgStatus.textContent = "";
    }

    async function checkDuplicate() {
        const params = new URLSearchParams({
            jmbg: fields.jmbg.value.trim(),
            ime: fields.ime?.value.trim() || "",
            prezime: fields.prezime?.value.trim() || "",
            datum_rodenja: fields.datum_rodenja?.value || "",
        });
        if (
            !params.get("jmbg")
            && !(params.get("ime") && params.get("prezime") && params.get("datum_rodenja"))
        ) {
            hideWarning();
            return;
        }

        const version = ++requestVersion;
        try {
            const response = await fetch(`${form.dataset.duplicateCheckUrl}?${params}`, {
                headers: {"X-Requested-With": "XMLHttpRequest"},
                credentials: "same-origin",
            });
            if (!response.ok) return;
            const result = await response.json();
            if (version !== requestVersion) return;
            if (!result.exists) {
                hideWarning();
                return;
            }

            warning.hidden = false;
            warningLink.href = result.profile_url;
            if (result.blocking) {
                const message = "Pacijent sa ovim JMBG-om već postoji.";
                warningText.textContent = message;
                fields.jmbg.setCustomValidity(message);
                if (jmbgStatus) jmbgStatus.textContent = message;
            } else {
                warningText.textContent = (
                    `Mogući duplikat: ${result.patient_name} ima isto ime, prezime i datum rođenja. `
                    + "Provjerite postojeći karton prije nastavka."
                );
                fields.jmbg.setCustomValidity("");
            }
        } catch (_) {
            fields.jmbg.setCustomValidity("");
        }
    }

    function scheduleCheck() {
        window.clearTimeout(timer);
        timer = window.setTimeout(checkDuplicate, 350);
    }

    Object.values(fields).filter(Boolean).forEach((field) => {
        field.addEventListener("input", scheduleCheck);
        field.addEventListener("change", scheduleCheck);
    });
})();
