from django.db import migrations, models
from django.db.models import F, Q


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0070_korisnickipristup"),
    ]

    operations = [
        migrations.AddField(
            model_name="zalihatransakcija",
            name="lokacija",
            field=models.CharField(
                blank=True,
                choices=[("FRIZIDER", "Frižider")],
                max_length=30,
            ),
        ),
        migrations.AlterField(
            model_name="zalihatransakcija",
            name="tip",
            field=models.CharField(
                choices=[
                    ("ZAPRIMANJE", "Zaprimanje"),
                    ("AMBULANTNA_POTROSNJA", "Ambulantna potrosnja"),
                    ("KUCNO_IZDAVANJE", "Kucno izdavanje"),
                    ("POVRAT", "Povrat"),
                    ("OTPIS", "Otpis"),
                    ("KOREKCIJA", "Korekcija"),
                    (
                        "POCETNO_STANJE_MIGRACIJE",
                        "Početno stanje migracije",
                    ),
                ],
                max_length=30,
            ),
        ),
        migrations.AddConstraint(
            model_name="migracijskisnapshotpacijenta",
            constraint=models.CheckConstraint(
                condition=Q(
                    broj_odobrenih_doza__gte=(
                        F("broj_iskoristenih_doza")
                        + F("fizicki_u_frizideru")
                        + F("kod_pacijenta")
                    )
                ),
                name="migracijski_snapshot_fizicko_lte_preostalo",
            ),
        ),
    ]
