"""Centralni javni identitet TheraFlow aplikacije.

Ovaj modul je namjerno odvojen od PDF generatora: vrijednosti su namijenjene
isključivo aplikacijskom interfejsu, installeru i pomoćnim sistemskim ekranima.
"""

from datetime import date

from .version import __version__


PRODUCT_NAME = "TheraFlow™"
PRODUCT_NAME_PLAIN = "TheraFlow"
PRODUCT_DESCRIPTION = "Sistem za upravljanje biološkom terapijom"
AUTHOR = "Riad Džakmić"
COPYRIGHT_START_YEAR = 2026
VERSION = __version__


def copyright_year(current_year=None):
    """Vrati početnu godinu ili raspon godina za javni copyright tekst."""
    year = max(COPYRIGHT_START_YEAR, current_year or date.today().year)
    if year == COPYRIGHT_START_YEAR:
        return str(COPYRIGHT_START_YEAR)
    return f"{COPYRIGHT_START_YEAR}–{year}"


def copyright_text(current_year=None, *, rights_reserved=False):
    text = f"© {copyright_year(current_year)} {AUTHOR}"
    if rights_reserved:
        return f"{text}. Sva prava zadržana."
    return text


def branding_context(*, build=""):
    """Vrijednosti koje UI koristi bez ponavljanja verzije i potpisa."""
    return {
        "product_name": PRODUCT_NAME,
        "product_name_plain": PRODUCT_NAME_PLAIN,
        "product_description": PRODUCT_DESCRIPTION,
        "product_version": VERSION,
        "product_build": str(build).strip(),
        "product_author": AUTHOR,
        "product_copyright": copyright_text(),
        "product_copyright_full": copyright_text(rights_reserved=True),
        "product_rights_reserved": "Sva prava zadržana.",
    }
