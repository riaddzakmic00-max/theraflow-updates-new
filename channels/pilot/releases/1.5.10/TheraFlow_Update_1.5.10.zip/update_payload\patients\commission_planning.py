"""Jedini prezentacijski adapter za komisijsko planiranje Faze 4."""

from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal, InvalidOperation

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Exists, OuterRef, Q
from django.utils import timezone

from .commission_demand import (
    APPROVED_WAITING_AVAILABLE_ON,
    AVAILABLE_FREE_FRIDGE,
    SOURCE_ACTIVE_COMMISSION,
    SOURCE_APPROVED_WAITING,
    SOURCE_AT_PATIENT,
    SOURCE_FREE_FRIDGE,
    SOURCE_NEW_COMMISSION,
    SOURCE_RESERVED,
    SOURCE_SUBMITTED,
    calculate_patient_demands,
    commission_demand_v2_enabled,
    demand_for_reliable_delivery_planning,
)
from .commission_logistics import (
    STATUS_KRITICNO,
    STATUS_POKRIVEN,
    STATUS_PRATITI,
    STATUS_ZA_KOMISIJU,
    determine_logistics_status,
    resolve_logistics_parameters,
)
from .coverage_calculation import (
    allocate_approved_awaiting_receipt,
    allocate_existing_request_pending,
    build_home_coverage_calculation,
)
from .commission_decision import (
    INCLUDE_IN_COMMISSION,
    NOT_REQUIRED,
    build_commission_decision,
)
from .commission_request_state import (
    APPROVED,
    CONFIRMED,
    DRAFT,
    PARTIALLY_RECEIVED,
    RECEIVED,
    REJECTED,
    SENT,
    resolve_commission_request_state,
)
from .future_therapy_planning import active_patients_for_planning
from .commission_service import get_commission_schedule
from .transaction_locking import select_for_update_self
from .commission_eligibility import (
    CommissionEligibilityService,
    STATUS_MORA_TRENUTNA,
    STATUS_PLANIRATI_KASNIJE,
    STATUS_RIZIK_PREKIDA,
    WORKFLOW_AWAITING_COMMISSION_DECISION,
    WORKFLOW_AWAITING_DELIVERY,
    WORKFLOW_NEW_AWAITING_INITIAL_COMMISSION,
    WORKFLOW_READY_TO_SCHEDULE,
    new_patient_workflow_status,
    patient_therapy_workflow_state,
)
from .models import (
    AktivnostLog,
    KomisijskiCiklus,
    KomisijskiRucniUnos,
    KomisijskaStavkaLijeka,
    KomisijskiZahtjev,
    PotrebaFizickogPokrica,
    Trebovanje,
)
from .medication_groups import (
    THERAPY_GROUP_REMSIMA,
    get_therapy_group,
    therapy_group_bucket_key,
)
from .package_sizes import (
    package_multiple_error,
    procurement_breakdown,
    validate_package_multiple,
)
from .phased_protocols import phased_planning_configuration
from .therapy_regimens import TYPE_INFUSION, TYPE_ORAL, therapy_regimen_type
from .utils import upisi_log


SOURCE_LABELS = {
    SOURCE_AT_PATIENT: "Kod pacijenta",
    SOURCE_RESERVED: "Fizički rezervisano u frižideru",
    SOURCE_FREE_FRIDGE: "Fizička slobodna zaliha",
    SOURCE_ACTIVE_COMMISSION: "Odobreno – nije naručeno",
    SOURCE_APPROVED_WAITING: "Potvrđena isporuka",
    SOURCE_SUBMITTED: "zahtjev već predat",
    SOURCE_NEW_COMMISSION: "nova komisija",
}

STATUS_PRESENTATION = {
    STATUS_POKRIVEN: ("Pokriven", "green"),
    STATUS_PRATITI: ("Pratiti", "blue"),
    STATUS_ZA_KOMISIJU: ("Za komisiju", "amber"),
    STATUS_KRITICNO: ("Kritično", "red"),
}

PLANNING_STATUS_READY = "READY"
PLANNING_STATUS_PROTOCOL_INCOMPLETE = "PROTOCOL_INCOMPLETE"
PLANNING_STATUS_ORAL_REGIMEN_NOT_CONFIGURED = "ORAL_REGIMEN_NOT_CONFIGURED"
PLANNING_STATUS_ORAL_REGIMEN_NOT_CONFIRMED = "ORAL_REGIMEN_NOT_CONFIRMED"
PLANNING_STATUS_ORAL_CALCULATION_INVALID = "ORAL_CALCULATION_INVALID"


@dataclass(frozen=True)
class PlanningResult:
    """Kanonski ugovor sposobnosti planiranja za svaki komisijski red.

    ``demand`` ostaje detalj biološkog enginea i zato nije prisutan kod svih
    vrsta terapije. Potrošači koji odlučuju smije li se plan koristiti moraju
    čitati ovaj rezultat, koji nikada nije ``None`` na vraćenom redu.
    """

    planiranje_moguce: bool
    status: str
    razlog: str
    tip_terapije: str
    konfiguracija_nepotpuna: bool = False

    @property
    def klasicna_ambulantna_terapija(self):
        return self.tip_terapije == TYPE_INFUSION


def _demand_planning_result(patient, demand):
    therapy_type = therapy_regimen_type(patient.lijek)
    if demand.planiranje_moguce:
        return PlanningResult(
            planiranje_moguce=True,
            status=PLANNING_STATUS_READY,
            razlog="Terapijski protokol je kompletan i obračun je moguć.",
            tip_terapije=therapy_type,
        )
    return PlanningResult(
        planiranje_moguce=False,
        status=PLANNING_STATUS_PROTOCOL_INCOMPLETE,
        razlog=(
            demand.upozorenje_planiranja
            or "Terapijski protokol nije kompletno definisan."
        ),
        tip_terapije=therapy_type,
        konfiguracija_nepotpuna=True,
    )


def _oral_planning_result(*, status, regimen, plan):
    if regimen and plan:
        return PlanningResult(
            planiranje_moguce=True,
            status=PLANNING_STATUS_READY,
            razlog="Potvrđeni oralni režim omogućava obračun u tabletama.",
            tip_terapije=TYPE_ORAL,
        )
    if status["regimen_configuration_status"] == "NOT_CONFIGURED":
        return PlanningResult(
            planiranje_moguce=False,
            status=PLANNING_STATUS_ORAL_REGIMEN_NOT_CONFIGURED,
            razlog=(
                "Komisijska potreba se ne računa dok lijek nema konfigurisan "
                "standardni oralni režim. Ovo nije dokaz pokrivenosti niti nestašice."
            ),
            tip_terapije=TYPE_ORAL,
            konfiguracija_nepotpuna=True,
        )
    if not regimen:
        return PlanningResult(
            planiranje_moguce=False,
            status=PLANNING_STATUS_ORAL_REGIMEN_NOT_CONFIRMED,
            razlog=(
                "Ljekar mora potvrditi dnevni oralni režim prije obračuna. "
                "Ovo nije dokaz pokrivenosti niti nestašice."
            ),
            tip_terapije=TYPE_ORAL,
            konfiguracija_nepotpuna=True,
        )
    return PlanningResult(
        planiranje_moguce=False,
        status=PLANNING_STATUS_ORAL_CALCULATION_INVALID,
        razlog=(
            "Potvrđeni oralni režim ne daje validan cjelobrojni obračun tableta; "
            "potrebna je ručna provjera režima."
        ),
        tip_terapije=TYPE_ORAL,
    )


def _latest_therapy_date(patient):
    """Čitaj kanonsku posljednju primjenu iz prefetcheovane historije."""

    therapy = patient.posljednja_stvarno_primljena_terapija()
    return therapy.datum if therapy else None


def _natural_recommendation(*, status, first_uncovered, commission_date):
    commission_label = (
        f"komisiju {commission_date:%d/%m/%Y}"
        if commission_date
        else "narednu komisiju"
    )
    if status == STATUS_KRITICNO:
        therapy_label = (
            f" planiranu {first_uncovered:%d/%m/%Y}"
            if first_uncovered else ""
        )
        return {
            "title": "Postoji rizik prekida terapije",
            "text": (
                "Ako se pacijent ne uključi u narednu komisiju, postoji rizik "
                f"da neće imati lijek za terapiju{therapy_label}."
            ),
            "class": "critical",
            "icon": "bi-exclamation-triangle",
        }
    if status == STATUS_ZA_KOMISIJU:
        uncovered_label = (
            f"Prva nepokrivena doza je {first_uncovered:%d/%m/%Y}."
            if first_uncovered else "Postoji nepokrivena doza u planskom periodu."
        )
        return {
            "title": "Pacijenta uključiti u komisiju",
            "text": (
                f"{uncovered_label} "
                f"Preporučujemo uključivanje u {commission_label}. "
                "Ako pouzdani rok isporuke prelazi prvu nepokrivenu terapiju, "
                "potrebno je osigurati raniju isporuku, postojeću zalihu ili "
                "vanredni zahtjev."
            ),
            "class": "attention",
            "icon": "bi-clock-history",
        }
    if status == STATUS_PRATITI:
        return {
            "title": "Pokrivenost treba pratiti",
            "text": (
                "Pacijent je trenutno pokriven, ali se približava roku za novi "
                "komisijski postupak. Sistem će označiti kada je potrebno uključivanje."
            ),
            "class": "watch",
            "icon": "bi-eye",
        }
    return {
        "title": "Pacijent je trenutno potpuno pokriven",
        "text": "Nova komisija još nije potrebna.",
        "class": "covered",
        "icon": "bi-check2-circle",
    }


def _planning_status(demand, *, today):
    parameters = resolve_logistics_parameters(demand.lijek)
    if not demand.planiranje_moguce:
        return (
            parameters,
            None,
            today + timedelta(days=parameters.total_lead_days),
            STATUS_PRATITI,
            demand.upozorenje_planiranja,
        )
    first_uncovered = demand.datum_prve_nepokrivene_terapije
    latest_start = (
        first_uncovered - timedelta(days=parameters.total_planning_days)
        if first_uncovered
        else None
    )
    expected_arrival = today + timedelta(days=parameters.total_lead_days)
    first_waiting_delivery_therapy = next(
        (
            detail.datum_terapije
            for detail in demand.detalji
            if any(
                allocation.source == SOURCE_APPROVED_WAITING
                for allocation in detail.izvori_pokrica
            )
        ),
        None,
    )
    if first_waiting_delivery_therapy:
        approved_arrival = today + timedelta(days=parameters.delivery_days)
        if approved_arrival >= first_waiting_delivery_therapy:
            return (
                parameters,
                latest_start,
                approved_arrival,
                STATUS_KRITICNO,
                f"Odobreni lijek se očekuje {approved_arrival:%d/%m/%Y}, nakon ili na datum "
                f"planirane terapije {first_waiting_delivery_therapy:%d/%m/%Y}",
            )
    status, reason = determine_logistics_status(
        today=today,
        first_uncovered_date=first_uncovered,
        latest_start_date=latest_start,
        expected_arrival_date=expected_arrival,
        target_coverage_days=parameters.target_coverage_days,
    )
    if status == STATUS_KRITICNO and first_uncovered:
        reason = (
            f"Procijenjena dostava {expected_arrival:%d/%m/%Y} je nakon ili na datum "
            f"planirane terapije {first_uncovered:%d/%m/%Y}"
        )
    return parameters, latest_start, expected_arrival, status, reason


def _detail_for_display(
    detail,
    *,
    expected_delivery=None,
    requires_current_commission=False,
    patient_physical_semantics=False,
    today=None,
    received=False,
):
    allocations = tuple({
        "izvor": item.source,
        "oznaka": SOURCE_LABELS[item.source],
        "kolicina": item.quantity,
    } for item in detail.izvori_pokrica)
    incoming_quantity = _allocated_from_sources(
        detail,
        {SOURCE_APPROVED_WAITING},
    )
    patient_physical_quantity = _allocated_from_sources(
        detail,
        {SOURCE_AT_PATIENT, SOURCE_RESERVED},
    )
    free_quantity = _allocated_from_sources(
        detail,
        {SOURCE_FREE_FRIDGE},
    )
    physical_gap = max(
        Decimal("0"),
        Decimal(str(detail.potrebna_kolicina or 0)) - patient_physical_quantity,
    )
    if received:
        detail_status = "Primljeno"
        coverage_state = "received"
        coverage_description = "Terapija je evidentirana kao primljena"
    elif today and detail.datum_terapije < today:
        detail_status = "Propuštena / nepotvrđena"
        coverage_state = "missed"
        coverage_description = "Nema potvrđene primjene za ovaj datum"
    elif patient_physical_semantics and patient_physical_quantity >= detail.potrebna_kolicina:
        detail_status = "Osigurano"
        coverage_state = "covered"
        coverage_description = (
            "Kod pacijenta"
            if _allocated_from_sources(detail, {SOURCE_AT_PATIENT}) > 0
            else "Rezervisano u frižideru"
        )
    elif (
        patient_physical_semantics
        and physical_gap > 0
        and free_quantity >= physical_gap
    ):
        detail_status = "Može se dodijeliti"
        coverage_state = "available"
        coverage_description = "Može se dodijeliti iz slobodne zalihe"
    elif (
        patient_physical_semantics
        and physical_gap > 0
        and expected_delivery
        and detail.datum_terapije >= expected_delivery
        and incoming_quantity >= physical_gap
    ):
        detail_status = "Očekuje se isporukom"
        coverage_state = "planned"
        coverage_description = (
            f"Potvrđena isporuka {expected_delivery:%d/%m/%Y}"
            if expected_delivery else "Potvrđena isporuka"
        )
    elif patient_physical_semantics:
        detail_status = "Nije osigurano"
        coverage_state = "uncovered"
        coverage_description = "Nije fizički pokriveno"
    elif detail.nedostatak > 0:
        detail_status = (
            "Zahtijeva trenutnu komisiju"
            if requires_current_commission
            else "Nepokriveno – planirati komisiju"
        )
        coverage_state = "uncovered"
        coverage_description = "Nije fizički pokriveno"
    elif incoming_quantity >= detail.potrebna_kolicina:
        detail_status = "Pokriveno najavljenom isporukom"
        coverage_state = "planned"
        coverage_description = "Pokriveno najavljenom isporukom"
    elif (
        patient_physical_quantity + free_quantity
        >= detail.potrebna_kolicina
    ):
        detail_status = "Fizički pokriveno"
        coverage_state = "covered"
        coverage_description = "Fizički pokriveno"
    else:
        detail_status = "Planirano pokriveno"
        coverage_state = "planned"
        coverage_description = "Pokriveno prema postojećem planu"
    return {
        "datum": detail.datum_terapije,
        "potrebna_kolicina": detail.potrebna_kolicina,
        "izvori": allocations,
        "nedostatak": detail.nedostatak,
        "termin_postoji": detail.termin_postoji,
        "razlog_datuma": detail.razlog_datuma,
        "status_oznaka": detail_status,
        "status_kod": coverage_state,
        "status_opis": coverage_description,
        "fizicki_dodijeljeno": patient_physical_quantity,
        "slobodna_zaliha_dostupna": free_quantity,
        "fizicki_pokriveno": physical_gap <= 0,
        "incoming_kolicina": incoming_quantity,
        "hitno_nepokriveno_prije_isporuke": bool(
            detail.nedostatak > 0
            and expected_delivery
            and detail.datum_terapije < expected_delivery
        ),
    }


def _decision_relevant_details(details, *, physical_only=False):
    """Prikaži cijeli trag do događaja koji određuje odluku."""

    relevant = []
    for detail in details:
        relevant.append(detail)
        if physical_only:
            physically_assigned = _allocated_from_sources(
                detail,
                {SOURCE_AT_PATIENT, SOURCE_RESERVED},
            )
            if physically_assigned < detail.potrebna_kolicina:
                break
        elif detail.nedostatak > 0:
            break
    return tuple(relevant)


def _modal_plan_details(
    details,
    *,
    today,
    display_horizon=None,
    delivery_split=None,
    confirmed_delivery=None,
    approved_not_ordered_quantity=Decimal("0"),
    calculation_start=None,
    patient_physical_semantics=False,
    last_administered_on=None,
    minimum_items=0,
):
    """Prikaži cijeli operativni niz do kraja količinskog horizonta.

    Skraćeni ``decision_relevant`` niz završava na prvom manjku i zato nije
    dovoljan za objašnjenje rizika kontinuiteta. Procijenjena isporuka samo
    dijeli prikaz na dvije sekcije; status "očekuje se isporukom" nastaje
    isključivo iz konkretne potvrđene incoming količine.
    """

    visible = []
    for detail in sorted(details, key=lambda item: item.datum_terapije):
        if (
            display_horizon
            and detail.datum_terapije > display_horizon
            and len(visible) >= minimum_items
        ):
            break
        visible.append(detail)
        if not display_horizon and len(visible) >= max(6, minimum_items):
            break
    rendered = []
    approved_not_ordered_remaining = Decimal(str(
        approved_not_ordered_quantity or 0
    ))
    for index, detail in enumerate(visible, start=1):
        item = _detail_for_display(
            detail,
            expected_delivery=confirmed_delivery,
            patient_physical_semantics=patient_physical_semantics,
            today=today,
            received=bool(
                last_administered_on
                and detail.datum_terapije == last_administered_on
            ),
        )
        # Administrativno odobrenje ne rješava hitnu dozu prije najavljene
        # isporuke. Nakon što se potroši stvarno potvrđena količina, preostale
        # buduće doze mogu se jasno označiti kao odobrene, ali još nenaručene.
        if (
            approved_not_ordered_remaining > 0
            and confirmed_delivery
            and detail.datum_terapije >= confirmed_delivery
            and item["status_kod"] == "uncovered"
        ):
            approved_quantity = min(
                approved_not_ordered_remaining,
                Decimal(str(detail.potrebna_kolicina or 0)),
            )
            if approved_quantity > 0:
                approved_not_ordered_remaining -= approved_quantity
                item["izvori"] = (*item["izvori"], {
                    "izvor": SOURCE_ACTIVE_COMMISSION,
                    "oznaka": SOURCE_LABELS[SOURCE_ACTIVE_COMMISSION],
                    "kolicina": approved_quantity,
                })
                item["status_oznaka"] = "Odobreno – nije naručeno"
                item["status_kod"] = "approved"
                item["status_opis"] = "Odobreno – nije naručeno"
        item["is_today"] = detail.datum_terapije == today
        item["redni_broj"] = index
        item["u_obracunu"] = bool(
            calculation_start
            and detail.datum_terapije >= calculation_start
        )
        item["segment"] = (
            "nakon_isporuke"
            if delivery_split and detail.datum_terapije >= delivery_split
            else "do_isporuke"
        )
        rendered.append(item)
    return tuple(rendered)


def _quantity_breakdown(patient, demand, quantity):
    if get_therapy_group(patient.lijek) != THERAPY_GROUP_REMSIMA:
        return ""
    quantity = Decimal(str(quantity or 0))
    first_quantity = next(
        (
            Decimal(str(item.potrebna_kolicina or 0))
            for item in demand.detalji
            if Decimal(str(item.potrebna_kolicina or 0)) > 0
        ),
        Decimal("0"),
    )
    if quantity <= 0 or first_quantity <= 0:
        return ""
    therapy_count = quantity / first_quantity
    if therapy_count != therapy_count.to_integral_value():
        return ""
    return (
        f"{int(therapy_count)} terapije × {int(first_quantity)} bočice "
        f"= {int(quantity)} bočica"
    )


def _procurement_display(patient, demand, quantity):
    """Strukturirani prikaz iste količine za sve komisijske ekrane."""
    quantity = Decimal(str(quantity or 0))
    first_quantity = next(
        (
            Decimal(str(item.potrebna_kolicina or 0))
            for item in demand.detalji
            if Decimal(str(item.potrebna_kolicina or 0)) > 0
        ),
        Decimal("0"),
    )
    therapy_count = None
    if quantity > 0 and first_quantity > 0:
        calculated = quantity / first_quantity
        if calculated == calculated.to_integral_value():
            therapy_count = int(calculated)
    procurement = procurement_breakdown(quantity, patient.lijek)
    return {
        "broj_terapija": therapy_count,
        "kolicina_nabavke": quantity,
        "jedinica_jednina": procurement["unit_label"],
        "jedinica_mnozina": procurement["unit_display_label"],
        "tekst": procurement["display_text"],
    }


def _covered_prefix(details, *, physical_only=False):
    """Vrati uzastopne buduće terapije pokrivene iz dozvoljenih izvora."""

    covered = []
    physical_sources = {SOURCE_AT_PATIENT, SOURCE_RESERVED}
    for detail in details:
        if physical_only:
            allocated = sum(
                (
                    item.quantity
                    for item in detail.izvori_pokrica
                    if item.source in physical_sources
                ),
                Decimal("0"),
            )
            is_covered = allocated >= detail.potrebna_kolicina
        else:
            is_covered = detail.nedostatak <= 0
        if not is_covered:
            break
        covered.append(detail)
    return covered


def _allocated_from_sources(detail, sources):
    return sum(
        (
            Decimal(str(item.quantity or 0))
            for item in detail.izvori_pokrica
            if item.source in sources
        ),
        Decimal("0"),
    )


def _annotate_inventory_semantics(rows, *, today):
    """Razdvoji stvarni pending allocation od buduće fizičke potrebe.

    ``PotrebaFizickogPokrica`` je jedini autoritativni izvor za količinu koja
    već čeka izvršenje fizičke alokacije. Buduća terapija koja još nije
    pacijentski rezervisana ostaje zasebna planska veličina, čak i kada je
    pokriva slobodna zaliha ili pouzdana incoming isporuka.
    """

    patient_ids = [row["pacijent"].pk for row in rows]
    pending_by_patient_and_group = {}
    pending_records = PotrebaFizickogPokrica.objects.filter(
            pacijent_id__in=patient_ids,
            status=PotrebaFizickogPokrica.STATUS_CEKA,
            preostala_kolicina__gt=0,
        ).select_related("lijek")
    for item in pending_records:
        key = (item.pacijent_id, therapy_group_bucket_key(item.lijek))
        pending_by_patient_and_group[key] = (
            pending_by_patient_and_group.get(key, Decimal("0"))
            + Decimal(str(item.preostala_kolicina or 0))
        )
    physical_sources = {SOURCE_AT_PATIENT, SOURCE_RESERVED}
    for row in rows:
        pending_medicine = row.get("potreban_proizvod") or row["lijek"]
        row["ceka_fizicko_pokrice"] = pending_by_patient_and_group.get(
            (
                row["pacijent"].pk,
                therapy_group_bucket_key(pending_medicine),
            ),
            Decimal("0"),
        )
        future_uncovered = Decimal("0")
        covered_by_free = Decimal("0")
        covered_by_incoming = Decimal("0")
        without_reliable_coverage = Decimal("0")
        events = []
        demand = row.get("demand")
        if (
            demand is not None
            and demand.planiranje_moguce
            and not row.get("relativna_pocetna_projekcija")
        ):
            for detail in demand.detalji:
                if detail.datum_terapije < today:
                    continue
                required = Decimal(str(detail.potrebna_kolicina or 0))
                physically_assigned = min(
                    required,
                    _allocated_from_sources(detail, physical_sources),
                )
                uncovered = max(Decimal("0"), required - physically_assigned)
                if uncovered <= 0:
                    continue
                free = min(
                    uncovered,
                    _allocated_from_sources(detail, {SOURCE_FREE_FRIDGE}),
                )
                incoming = min(
                    max(Decimal("0"), uncovered - free),
                    _allocated_from_sources(detail, {SOURCE_APPROVED_WAITING}),
                )
                unresolved = max(
                    Decimal("0"),
                    uncovered - free - incoming,
                )
                future_uncovered += uncovered
                covered_by_free += free
                covered_by_incoming += incoming
                without_reliable_coverage += unresolved
                events.append({
                    "datum": detail.datum_terapije,
                    "potrebna_kolicina": required,
                    "fizicki_dodijeljeno": physically_assigned,
                    "buduca_nepokrivena_potreba": uncovered,
                    "pokriveno_slobodnom_zalihom": free,
                    "pokriveno_incoming": incoming,
                    "bez_pouzdanog_pokrica": unresolved,
                })
        row.update(
            buduca_nepokrivena_potreba=future_uncovered,
            buduca_potreba_pokrivena_slobodnom_zalihom=covered_by_free,
            buduca_potreba_pokrivena_incoming=covered_by_incoming,
            buduca_potreba_bez_pouzdanog_pokrica=without_reliable_coverage,
            buduci_fizicki_nepokriveni_detalji=tuple(events),
        )
    return rows


def _annotate_stock_coverage(rows, *, today):
    """Dodaj zajednički operativni pogled fizičke i planirane pokrivenosti.

    Slobodna zaliha lijeka nije fizičko pokriće nijednog konkretnog pacijenta.
    Operativni datumi zato se izvode isključivo iz pacijentskih fizičkih izvora
    koji su već raspoređeni u centralnom demand rezultatu.
    """

    groups = {}
    for row in rows:
        groups.setdefault(therapy_group_bucket_key(row["lijek"]), []).append(row)

    physical_sources = {SOURCE_AT_PATIENT, SOURCE_RESERVED}
    scenarios = (
        (
            "fizicki",
            lambda detail: max(
                Decimal("0"),
                Decimal(str(detail.potrebna_kolicina or 0))
                - _allocated_from_sources(detail, physical_sources),
            ),
        ),
        (
            "planirano",
            lambda detail: max(
                Decimal("0"),
                Decimal(str(detail.nedostatak or 0)),
            ),
        ),
    )

    for group_rows in groups.values():
        events = []
        for row in group_rows:
            details = tuple(row.pop("_projekcija_zalihe_detalji", ()) or ())
            has_schedule = bool(details) and not row["relativna_pocetna_projekcija"]
            row["ima_poznat_buduci_raspored"] = has_schedule
            if not has_schedule:
                continue
            for index, detail in enumerate(details):
                if detail.datum_terapije >= today:
                    events.append((
                        detail.datum_terapije,
                        row["pacijent"].pk,
                        index,
                        row,
                        detail,
                    ))
        events.sort(key=lambda item: (item[0], item[1], item[2]))

        for scenario, remaining_for_detail in scenarios:
            state_by_patient = {
                row["pacijent"].pk: {
                    "covered_until": None,
                    "first_uncovered": None,
                    "required": Decimal("0"),
                    "missing": Decimal("0"),
                }
                for row in group_rows
            }
            for _, patient_id, _, _, detail in events:
                state = state_by_patient[patient_id]
                remaining = remaining_for_detail(detail)
                if remaining <= 0:
                    if state["first_uncovered"] is None:
                        state["covered_until"] = detail.datum_terapije
                    continue
                if state["first_uncovered"] is None:
                    state["first_uncovered"] = detail.datum_terapije
                    state["required"] = Decimal(str(detail.potrebna_kolicina or 0))
                    state["missing"] = remaining

            for row in group_rows:
                state = state_by_patient[row["pacijent"].pk]
                row[f"{scenario}_pokriven_do_operativno"] = state["covered_until"]
                row[f"prva_{scenario}_nepokrivena_terapija"] = (
                    state["first_uncovered"]
                )
                row[f"prva_{scenario}_nepokrivena_potrebno"] = state["required"]
                row[f"prva_{scenario}_nepokrivena_nedostaje"] = state["missing"]
        # Za kućnu terapiju ambulantni event-list nije autoritativan. Vratiti
        # datume iz iste centralne projekcije koju koriste karton i Zalihe.
        for row in group_rows:
            if therapy_regimen_type(row["lijek"]) == TYPE_ORAL:
                # Oralna terapija nema niz ambulantnih događaja. Njena fizička
                # pokrivenost dolazi isključivo iz preostalih izdatih tableta.
                row["ima_poznat_buduci_raspored"] = False
                row["fizicki_pokriven_do_operativno"] = row.get(
                    "fizicki_pokriven_do"
                )
                row["planirano_pokriven_do_operativno"] = None
                row["prva_fizicki_nepokrivena_terapija"] = row.get(
                    "sljedece_potrebno_izdavanje"
                )
                row["prva_fizicki_nepokrivena_potrebno"] = row.get(
                    "dnevna_potrosnja_tableta", Decimal("0")
                )
                row["prva_fizicki_nepokrivena_nedostaje"] = row.get(
                    "dnevna_potrosnja_tableta", Decimal("0")
                )
                continue
            home_projection = row.get("home_projection")
            if not home_projection:
                continue
            row["ima_poznat_buduci_raspored"] = bool(
                home_projection.first_uncovered_therapy
            )
            row["fizicki_pokriven_do_operativno"] = (
                home_projection.physical_covered_until
            )
            row["prva_fizicki_nepokrivena_terapija"] = (
                home_projection.first_uncovered_therapy
            )
            row["prva_fizicki_nepokrivena_potrebno"] = (
                home_projection.units_per_application
            )
            row["prva_fizicki_nepokrivena_nedostaje"] = (
                home_projection.units_per_application
            )
    return rows


def _existing_request_for_final_decision(
    *,
    patient,
    medicine_ids,
    cycle_date,
    workflow_requests,
):
    """Vrati stvarni aktivni prijedlog/zahtjev baš za planirani ciklus.

    Raniji zaprimljeni ili potvrđeni zahtjev ne smije zamijeniti odluku za
    naredni ciklus. Phase 2 zahtjev je kanonski kada postoji; legacy zapis je
    kompatibilni fallback.
    """

    if cycle_date is None:
        return None

    prefetched_phase2 = getattr(
        patient,
        "_planning_phase2_requests",
        None,
    )
    phase2_requests = (
        [
            request
            for request in prefetched_phase2
            if request.komisijski_ciklus.datum_komisije == cycle_date
        ]
        if prefetched_phase2 is not None
        else (
            KomisijskiZahtjev.objects.filter(
                pacijent=patient,
                komisijski_ciklus__datum_komisije=cycle_date,
            )
            .select_related("komisijski_ciklus", "saglasnost")
            .prefetch_related("stavke_lijeka")
            .order_by("-pk")
        )
    )
    phase2_request = None
    for request in phase2_requests:
        matching_items = tuple(
            item
            for item in request.stavke_lijeka.all()
            if item.lijek_id in medicine_ids
        )
        if not matching_items and request.novi_lijek_id not in medicine_ids:
            continue
        phase2_request = request
        break

    legacy_candidates = sorted(
        (
            request
            for request in workflow_requests
            if request.lijek_id in medicine_ids
            and request.komisijski_ciklus_id
            and request.komisijski_ciklus.datum_komisije == cycle_date
        ),
        key=lambda request: request.pk,
        reverse=True,
    )
    legacy_request = legacy_candidates[0] if legacy_candidates else None
    if phase2_request is None and legacy_request is None:
        return None

    request_state = resolve_commission_request_state(
        phase2_request=phase2_request,
        legacy_request=legacy_request,
        medicine_ids=medicine_ids,
    )
    if request_state.code in {APPROVED, PARTIALLY_RECEIVED}:
        committed_quantity = request_state.awaiting_receipt_quantity
    elif request_state.code in {DRAFT, CONFIRMED, SENT}:
        committed_quantity = request_state.request_quantity
    else:
        committed_quantity = Decimal("0")

    return {
        "quantity": request_state.display_quantity,
        "committed_quantity": committed_quantity,
        "approved_quantity": request_state.approved_quantity,
        "received_quantity": request_state.received_quantity,
        "awaiting_receipt_quantity": request_state.awaiting_receipt_quantity,
        "status": (
            phase2_request.status if phase2_request is not None
            else legacy_request.status
        ),
        "status_label": request_state.status_label,
        "state": request_state,
        "state_code": request_state.code,
        "cycle_date": cycle_date,
        "request_id": (
            phase2_request.pk if phase2_request is not None else legacy_request.pk
        ),
        "legacy_request_id": legacy_request.pk if legacy_request else None,
        "source": (
            "PHASE2+LEGACY"
            if phase2_request is not None and legacy_request is not None
            else "PHASE2" if phase2_request is not None else "LEGACY"
        ),
    }


def _oral_commission_planning_row(
    patient,
    *,
    today,
    administrative_schedule,
    override=None,
):
    """Prevedi potvrđeni dnevni oralni režim u postojeći komisijski red.

    Adapter ne kreira termine i ne modelira tablete kao infuzijske aplikacije.
    Horizont od 90 dana je postojeći Phase 5 oralni planski horizont.
    """

    from .oral_therapy import oral_therapy_status

    status = oral_therapy_status(patient, today=today)
    regimen = status["regimen"]
    plan = status["commission_plan"]
    timeline = status.get("commission_timeline")
    planning_result = _oral_planning_result(
        status=status,
        regimen=regimen,
        plan=plan,
    )
    requires_review = not planning_result.planiranje_moguce
    system_quantity = (
        Decimal(str(plan["procurement_tablets"]))
        if plan
        else Decimal("0")
    )
    manual_quantity = (
        Decimal(str(override.ljekar_trazi))
        if override
        else system_quantity
    )
    final_quantity = max(Decimal("0"), manual_quantity)
    needs_commission = bool(timeline and timeline["needs_commission"])
    delivery_risk = bool(timeline and timeline["delivery_risk"])
    due_now = bool(timeline and timeline["due_now"])
    included = bool(
        not requires_review
        and final_quantity > 0
        and (due_now or delivery_risk or override is not None)
    )
    action_quantity = final_quantity if included else Decimal("0")
    net_need = (
        Decimal(str(plan["tablets_to_request"]))
        if plan
        else Decimal("0")
    )
    approved = Decimal(str(status["approved_remaining"] or 0))
    at_patient = Decimal(str(status["quantity_at_patient"] or 0))
    # UI coverage opisuje trenutno stvarno stanje prava + tableta kod
    # pacijenta. Plan može oduzeti očekivanu potrošnju do buduće isporuke,
    # ali ta projekcija ne smije prepisati današnji saldo.
    total_covered = approved + at_patient
    gross = Decimal(str(plan["gross_tablets"])) if plan else Decimal("0")
    remaining_at_delivery = Decimal(str(
        timeline["remaining_at_delivery"] if timeline else total_covered
    ))
    consumed_until_delivery = max(
        Decimal("0"),
        total_covered - remaining_at_delivery,
    )
    days_until_delivery = (
        max((timeline["expected_delivery"] - today).days, 0)
        if timeline and timeline.get("expected_delivery")
        else 0
    )
    def date_label(value):
        return value.strftime("%d/%m/%Y") if value else "nije konfigurisan"

    recommended_window = timeline["recommended_cycle"] if timeline else None
    first_safe_window = timeline["first_safe_cycle"] if timeline else None
    latest_safe_window = timeline["latest_safe_cycle"] if timeline else None
    first_uncovered = (
        timeline["first_uncovered"] if timeline else status["next_uncovered"]
    )
    commission_first_uncovered = (
        timeline["commission_first_uncovered"] if timeline else first_uncovered
    )
    expected_delivery = timeline["expected_delivery"] if timeline else None
    preparation_deadline = (
        timeline["preparation_deadline"] if timeline else None
    )
    delivery_gap_days = (
        (commission_first_uncovered - expected_delivery).days
        if commission_first_uncovered and expected_delivery
        else None
    )

    if requires_review:
        status_code = STATUS_PRATITI
        status_label = (
            "Režim nije konfigurisan"
            if status["regimen_configuration_status"] == "NOT_CONFIGURED"
            else "Potrebna potvrda oralnog režima"
        )
        status_class = "red"
        status_reason = planning_result.razlog
        next_action = "Dovršiti i potvrditi oralni režim"
        category = "pregled"
    elif delivery_risk:
        status_code = STATUS_KRITICNO
        status_label = "Rizik prekida oralnog pokrića"
        status_class = "red"
        status_reason = (
            "Ni najranija raspoloživa očekivana isporuka ne stiže prije "
            "isteka postojeće fizičke pokrivenosti i odobrenog prava "
            f"{timeline['commission_first_uncovered']:%d/%m/%Y}."
        )
        next_action = "Uključiti u najraniji ciklus i provjeriti vanrednu nabavku"
        category = "ukljuciti"
    elif included:
        status_code = STATUS_ZA_KOMISIJU
        status_label = "Potrebno pripremiti zahtjev"
        status_class = "amber"
        status_reason = (
            f"Potvrđeni režim troši {regimen.tableta_dnevno:g} tableta/dan. "
            f"Pripremu treba pokrenuti najkasnije "
            f"{date_label(preparation_deadline)}; očekivana "
            f"isporuka je {date_label(expected_delivery)}."
        )
        next_action = (
            f"Za komisiju {date_label(recommended_window.datum_komisije)}"
            if recommended_window else "Pripremiti komisijski zahtjev"
        )
        category = "ukljuciti"
    elif needs_commission:
        status_code = STATUS_POKRIVEN
        status_label = (
            "Pokriven postojećim odobrenjem"
            if approved > 0 else "Komisija trenutno nije potrebna"
        )
        status_class = "green"
        status_reason = (
            "Nova komisija trenutno nije potrebna. Sistem će automatski "
            "upozoriti kada dospije rok pripreme izračunatog sigurnog ciklusa."
        )
        next_action = "Nije potrebna trenutna akcija"
        category = "pokriveni"
    else:
        status_code = STATUS_POKRIVEN
        status_label = "Pokriven postojećim odobrenjem"
        status_class = "green"
        status_reason = (
            "Za ciljni period nije potreban novi komisijski zahtjev. "
            "Fizička pokrivenost i naredno izdavanje prate se odvojeno."
        )
        next_action = "Nije potrebna trenutna akcija"
        category = "pokriveni"

    system_procurement = procurement_breakdown(system_quantity, patient.lijek)
    base_procurement = procurement_breakdown(net_need, patient.lijek)
    zero_procurement = procurement_breakdown(Decimal("0"), patient.lijek)
    final_procurement = procurement_breakdown(final_quantity, patient.lijek)
    draft_procurement = procurement_breakdown(action_quantity, patient.lijek)
    recommendation = {
        "class": "attention" if included else "watch" if requires_review else "covered",
        "icon": "bi-capsule-pill",
        "title": status_label,
        "text": status_reason,
    }
    return {
        "pacijent": patient,
        "lijek": patient.lijek,
        "oralna_terapija": True,
        "terapija_naziv": patient.terapija_za_prikaz,
        "potreban_proizvod": patient.trenutni_proizvod,
        "terapijska_faza": (
            regimen.get_faza_display() if regimen is not None else patient.terapijska_faza()
        ),
        "oralni_plan": plan,
        "oralni_rezim": regimen,
        "oralni_obracun": (
            {
                "dnevna_potrosnja": Decimal(str(regimen.tableta_dnevno)),
                "trenutno_kod_pacijenta": at_patient,
                "trenutno_odobreno_preostalo": approved,
                "trenutno_ukupno_pokriveno": total_covered,
                "dana_do_ocekivane_isporuke": days_until_delivery,
                "projektovana_potrosnja_do_isporuke": consumed_until_delivery,
                "projektovano_preostalo_na_isporuku": remaining_at_delivery,
                "ciljni_period_dana": int(plan["days"]),
                "bruto_potreba": gross,
                "neto_potreba": net_need,
                "velicina_pakovanja": Decimal(str(plan["package_size"])),
                "broj_pakovanja": int(plan["packages_to_request"]),
                "zaokruzeno_za_komisiju": system_quantity,
                "fizicki_slobodno_u_kabinetu": Decimal(str(
                    status["physical_available"] or 0
                )),
                "fizicka_zaliha_smanjuje_individualni_zahtjev": False,
                "objasnjenje_fizicke_zalihe": (
                    "Fizički slobodna zaliha u kabinetu nije individualno "
                    "odobrenje pacijenta. Može se izdati tek uz važeći izvor "
                    "prava i zato sama ne umanjuje komisijski zahtjev."
                ),
            }
            if plan and regimen is not None
            else None
        ),
        "planning_result": planning_result,
        "pokriven_do": status["coverage_until"],
        "fizicki_pokriven_do": status["coverage_until"],
        "fizicki_pokriven_do_operativno": status["coverage_until"],
        "planirano_pokriven_do": None,
        "planirano_pokriven_do_operativno": None,
        "dnevna_potrosnja_tableta": (
            Decimal(str(regimen.tableta_dnevno)) if regimen else Decimal("0")
        ),
        "sljedece_potrebno_izdavanje": first_uncovered,
        "nova_komisija_potrebna": included,
        "buduca_komisija_izracunata": needs_commission,
        "rok_pripreme_dospio": bool(needs_commission and due_now),
        "postojecim_odobrenjem_pokriven": bool(
            not included and approved > 0
        ),
        "broj_pokrivenih_terapija": 0,
        "broj_fizicki_pokrivenih_terapija": 0,
        "fizicki_pokrivena_kolicina": Decimal("0"),
        "home_projection": None,
        "fizicki_pokriveni_detalji": (),
        "relevantni_plan_detalji": (),
        "prva_nepokrivena_terapija": first_uncovered,
        "komisiju_pokrenuti_najkasnije": preparation_deadline,
        "ocekivani_datum_dolaska": expected_delivery,
        "procijenjeni_datum_dolaska": expected_delivery,
        "ocekivani_datum_dolaska_je_procjena": bool(expected_delivery),
        "rizicna_terapija": first_uncovered if delivery_risk else None,
        "posljednja_terapija": None,
        "sljedeca_planirana_terapija": None,
        "sljedeca_stvarno_zakazana_terapija": None,
        "naredna_administrativna_komisija": administrative_schedule.effective_next_date,
        "pouzdana_isporuka_trenutne_komisije": expected_delivery,
        "naredna_komisija": first_safe_window,
        "pouzdana_isporuka_naredne_komisije": (
            first_safe_window.najkasnija_isporuka if first_safe_window else None
        ),
        "preporuceni_komisijski_ciklus": recommended_window,
        "posljednji_siguran_datum_za_ukljucivanje": preparation_deadline,
        "ocekivana_pouzdana_isporuka": expected_delivery,
        "isporuka_preblizu_terapiji": delivery_risk,
        "razmak_isporuke_do_terapije_dana": delivery_gap_days,
        "objasnjenje_preporuke": recommendation,
        "sistem_predlaze": system_quantity,
        "minimalno_potrebno": net_need,
        "nepokrivene_doze_do_naredne_pouzdane_isporuke": net_need,
        "sigurnosna_rezerva": Decimal("0"),
        "prikaz_osnovno": net_need,
        "prikaz_rezerva": Decimal("0"),
        "vec_pokriveno_za_preporuku": total_covered,
        "preporuceno_traziti": system_quantity,
        "ljekar_trazi": manual_quantity,
        "za_novu_komisiju": action_quantity,
        "kolicina_za_komisiju": action_quantity,
        # Operativna neto potreba postoji tek kada je centralni planner
        # zaista aktivirao komisijsku akciju. Buduća matematička projekcija
        # ostaje odvojeno dostupna kroz ``buduca_nepokrivena_potreba``.
        "trenutna_neto_potreba": (
            net_need if included else Decimal("0")
        ),
        "izracunata_potreba": net_need,
        "matematicka_kolicina_za_komisiju": net_need,
        "buduca_preporucena_kolicina": (
            final_quantity if needs_commission and not included else Decimal("0")
        ),
        "buduca_nepokrivena_potreba": net_need,
        "buduca_potreba_pokrivena_slobodnom_zalihom": Decimal("0"),
        "buduca_potreba_pokrivena_incoming": Decimal("0"),
        "buduca_potreba_bez_pouzdanog_pokrica": (
            net_need if not included else Decimal("0")
        ),
        "komisijska_akcija_aktivna": included,
        "komisijska_akcija_razlog": status_reason,
        "rucni_unos": override,
        "razlog_odstupanja": override.razlog if override else "",
        "status": status_code,
        "status_oznaka": status_label,
        "status_klasa": status_class,
        "status_razlog": status_reason,
        "commission_eligibility": None,
        "trenutna_komisija": None,
        "eligibility_status": None,
        "eligibility_status_oznaka": "",
        "posljednja_sigurna_komisija": latest_safe_window,
        "planirati_za_komisiju": recommended_window,
        "moze_preskociti_trenutnu": bool(
            recommended_window and not included and not delivery_risk
        ),
        "novi_pacijent_workflow": None,
        "ukljucen_u_nacrt": included,
        "eligible_for_current_cycle": included,
        "proposed_procurement_units": system_quantity,
        "final_procurement_units": final_quantity,
        "included_in_draft": included,
        "vanredni_zahtjev_u_toku": False,
        "za_pregled": requires_review,
        "dokumentacija_kompletna": True,
        "dokumentacija_oznaka": "",
        "blokira_predaju": False,
        "rizik_dostave": delivery_risk,
        "relativna_pocetna_projekcija": False,
        "sljedeci_korak": next_action,
        "rok_propusten": bool(
            needs_commission
            and preparation_deadline
            and preparation_deadline < today
        ),
        "ukupan_deficit_do_sljedece_isporuke": net_need,
        "hitna_kolicina_prije_isporuke": (
            net_need if delivery_risk else Decimal("0")
        ),
        "ima_stvarno_zakazanu_buducu_terapiju": False,
        "kolicina_za_sljedecu_komisiju": (
            final_quantity if needs_commission else Decimal("0")
        ),
        "obracun_jedinica": "",
        "prikaz_nabavke": {
            "broj_terapija": None,
            "kolicina_nabavke": system_quantity,
            "jedinica_jednina": "tableta",
            "jedinica_mnozina": system_procurement["unit_display_label"],
            "tekst": system_procurement["display_text"],
        },
        "sistemska_nabavka": system_procurement,
        "osnovna_nabavka": base_procurement,
        "rezervna_nabavka": zero_procurement,
        "konacna_nabavka": final_procurement,
        "nabavka_komisije": draft_procurement,
        "broj_terapija_za_komisiju": None,
        "jedinica_nabavke": system_procurement["unit_display_label"],
        "kategorija": category,
        "ukupno_potrebno": gross,
        "vec_pokriveno": total_covered,
        "trenutno_dostupno": total_covered,
        "neto_nedostatak": net_need,
        "broj_pakovanja": draft_procurement["package_count"],
        "velicina_pakovanja": draft_procurement["units_per_package"],
        "poruka_validacije_pakovanja": package_multiple_error(
            patient.lijek,
            label="Konačna količina",
        ),
        "detalji": (),
        "_projekcija_zalihe_detalji": (),
        "coverage": {
            "unused_approved": approved,
            "reserved_in_fridge": Decimal("0"),
            "at_patient": at_patient,
            "approved_waiting_delivery": Decimal("0"),
            "submitted": Decimal("0"),
            "free_fridge": Decimal(str(status["physical_available"] or 0)),
            "total_covered": total_covered,
        },
        "odobreno_ceka_isporuku_uslovno": False,
        "odobreno_ceka_isporuku_napomena": "",
        "odobreno_preostalo": approved,
        "odobreno_ceka_isporuku": Decimal("0"),
        "planirani_koraci": (),
        "demand": None,
        "logisticke_postavke": resolve_logistics_parameters(patient.lijek),
    }


def commission_planning_rows(*, today=None):
    from .request_cache import get_or_set

    today = today or timezone.localdate()
    return get_or_set(
        "commission_planning_rows",
        today,
        lambda: _commission_planning_rows_uncached(today=today),
    )


def _commission_planning_rows_uncached(*, today):
    """Vrati identične redove za Centar, karton i Dashboard.

    Uvijek se obrađuju svi aktivni pacijenti zajedno kako zajednička fizička
    zaliha ne bi bila dodijeljena više puta kada se otvara karton jednog
    pacijenta.
    """

    administrative_schedule = get_commission_schedule(today=today)
    patients = [
        patient
        for patient in active_patients_for_planning()
        if not patient.na_aktivnoj_pauzi()
    ]
    demands = calculate_patient_demands(patients, today=today)
    eligibility_demands = calculate_patient_demands(
        patients,
        today=today,
        target_date=today + timedelta(days=365),
    )
    eligibility_service = CommissionEligibilityService(today=today)
    overrides = {
        (item.pacijent_id, item.lijek_id): item
        for item in KomisijskiRucniUnos.objects.filter(
            pacijent_id__in=[patient.pk for patient in patients],
            aktivan_nacrt=True,
            komisijski_ciklus__isnull=True,
        ).select_related("korisnik")
    }
    extraordinary_patient_ids = set(
        Trebovanje.objects.filter(
            pacijent_id__in=[patient.pk for patient in patients],
            tip_zahtjeva=Trebovanje.TIP_VANREDNI,
            status__in=(
                Trebovanje.STATUS_NACRT,
                Trebovanje.STATUS_SPREMAN,
                Trebovanje.STATUS_POSLAN_KOMISIJI,
                "ODOBRENO",
                Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
                Trebovanje.STATUS_CEKA_ISPORUKU,
            ),
        ).values_list("pacijent_id", flat=True)
    )
    rows = []
    for patient in patients:
        if patient.lijek.oralna_terapija:
            rows.append(
                _oral_commission_planning_row(
                    patient,
                    today=today,
                    administrative_schedule=administrative_schedule,
                    override=overrides.get((patient.pk, patient.lijek_id)),
                )
            )
            continue
        # Za svaki neoralni pacijent iz prethodno normalizovanog skupa engine
        # garantuje strukturirani PatientDoseDemand, uključujući nemoguć plan.
        demand = demands[patient.pk]
        eligibility_demand = eligibility_demands[patient.pk]
        administrative_eligibility_demand = eligibility_demand
        if not demand.relativna_pocetna_projekcija:
            # Planner smije preskočiti ciklus samo na osnovu fizičkog ili
            # vremenski pouzdanog incoming pokrića. Isto pravilo važi i za
            # kućnu terapiju: slobodna zaliha ostaje samo moguća dodjela, a
            # aktivno pravo bez narudžbe nije isporuka.
            demand = demand_for_reliable_delivery_planning(demand)
            eligibility_demand = demand_for_reliable_delivery_planning(
                eligibility_demand
            )
        planning_result = _demand_planning_result(patient, demand)
        # Komisijska kolicina koristi i postojece administrativno pravo, dok
        # fizicki timeline ispod ostaje konzervativan i priznaje samo stvarno
        # dodijeljene doze ili pouzdanu potvrdenu isporuku.
        # Kućna terapija odvojeno koristi postojeće administrativno pravo za
        # redovnu komisijsku količinu. Za ambulantni IV/SC tok preskakanje
        # ciklusa i dalje smije počivati samo na fizičkom ili vremenski
        # potvrđenom incoming izvoru; samo odobrenje bez narudžbe ne može
        # osigurati narednu ambulantnu primjenu.
        eligibility = eligibility_service.evaluate(
            administrative_eligibility_demand
            if patient.trenutni_korak_je_kucna_terapija()
            else eligibility_demand
        )
        parameters = resolve_logistics_parameters(demand.lijek)
        preapproval_arrival_estimate = None
        approved_delivery_date = eligibility_demand.dostupno_po_izvoru.get(
            APPROVED_WAITING_AVAILABLE_ON
        )
        approved_for_delivery = bool(
            approved_delivery_date
            and Decimal(str(
                eligibility_demand.dostupno_po_izvoru.get(
                    SOURCE_APPROVED_WAITING,
                    0,
                ) or 0
            )) > 0
        )
        current_window = eligibility.trenutna_komisija
        if current_window:
            planning_window = (
                eligibility.planirati_za_komisiju
                if eligibility.status == STATUS_PLANIRATI_KASNIJE
                and eligibility.planirati_za_komisiju
                else current_window
            )
            latest_start = planning_window.rok_pripreme
            preapproval_arrival_estimate = planning_window.najkasnija_isporuka
            expected_arrival = (
                approved_delivery_date
                if approved_for_delivery
                else None
            )
            status = {
                STATUS_RIZIK_PREKIDA: STATUS_KRITICNO,
                STATUS_MORA_TRENUTNA: STATUS_ZA_KOMISIJU,
                STATUS_PLANIRATI_KASNIJE: STATUS_PRATITI,
            }.get(eligibility.status, STATUS_POKRIVEN)
            status_reason = eligibility.razlog
            if (
                status == STATUS_KRITICNO
                and demand.kolicina_odobrena_nedostavljena > 0
                and expected_arrival
            ):
                status_reason = (
                    f"Odobreni lijek se očekuje najkasnije "
                    f"{expected_arrival:%d/%m/%Y}. {status_reason}"
                )
            system_suggestion = eligibility.preporucena_kolicina
            _legacy_status_label, status_class = STATUS_PRESENTATION[status]
            status_label = eligibility.status_label
        else:
            planning_window = None
            (
                parameters,
                latest_start,
                preapproval_arrival_estimate,
                status,
                status_reason,
            ) = _planning_status(demand, today=today)
            expected_arrival = (
                approved_delivery_date
                if approved_for_delivery
                else None
            )
            status_label, status_class = STATUS_PRESENTATION[status]
            system_suggestion = demand.kolicina_koju_treba_traziti
        home_therapy_step = patient.trenutni_korak_je_kucna_terapija()
        planned_covered_details = _covered_prefix(eligibility_demand.detalji)
        physical_covered_details = _covered_prefix(
            eligibility_demand.detalji,
            physical_only=True,
        )
        physical_covered_quantity = sum(
            (
                Decimal(str(item.potrebna_kolicina or 0))
                for item in physical_covered_details
            ),
            Decimal("0"),
        )
        physical_covered_display_details = tuple(
            _detail_for_display(
                item,
                patient_physical_semantics=home_therapy_step,
            )
            for item in physical_covered_details
        )
        decision_relevant_details = _decision_relevant_details(
            eligibility_demand.detalji,
            physical_only=home_therapy_step,
        )
        decision_relevant_display_details = tuple(
            _detail_for_display(
                item,
                expected_delivery=approved_delivery_date,
                requires_current_commission=(
                    eligibility.treba_na_trenutnu_komisiju
                ),
                patient_physical_semantics=home_therapy_step,
            )
            for item in decision_relevant_details
        )
        incoming_covered_details = tuple(
            item
            for item in decision_relevant_display_details
            if item["incoming_kolicina"] > 0
        )
        planned_covered_until = (
            planned_covered_details[-1].datum_terapije
            if planned_covered_details else None
        )
        physical_covered_until = (
            physical_covered_details[-1].datum_terapije
            if physical_covered_details else None
        )
        override = overrides.get((patient.pk, patient.lijek_id))
        manual_quantity = (
            Decimal(str(override.ljekar_trazi))
            if override
            else system_suggestion
        )
        total_covered = max(
            Decimal("0"),
            demand.ukupna_potrebna_kolicina - demand.neto_nedostatak,
        )
        effective_quantity = manual_quantity
        requires_review = not planning_result.planiranje_moguce
        coverage = {
            "unused_approved": demand.neiskoristene_odobrene_doze,
            # Fizičko stanje nije količina potrošena unutar trenutnog
            # komisijskog horizonta. Prikaz mora koristiti cijeli aktivni
            # rezervisani pool, dok obračun i dalje raspoređuje samo doze
            # potrebne unutar svog zaključanog planskog perioda.
            "reserved_in_fridge": Decimal(str(
                demand.dostupno_po_izvoru.get(SOURCE_RESERVED, 0) or 0
            )),
            "at_patient": demand.kolicina_kod_pacijenta,
            "approved_waiting_delivery": demand.kolicina_odobrena_nedostavljena,
            "submitted": demand.kolicina_vec_predata_komisiji,
            # Slobodna zaliha je informativno vidljiva, ali nije automatsko
            # pokriÄ‡e pacijenta i ne ulazi u alokacije do ruÄŤne rezervacije.
            "free_fridge": Decimal(str(
                demand.dostupno_po_izvoru.get(AVAILABLE_FREE_FRIDGE, 0) or 0
            )),
            "total_covered": total_covered,
        }
        next_planned_therapy = (
            eligibility_demand.detalji[0].datum_terapije
            if eligibility_demand.detalji else None
        )
        next_scheduled_future_therapy = next(
            (
                item.datum_terapije
                for item in eligibility_demand.detalji
                if (
                    getattr(item, "termin_postoji", False)
                    and item.datum_terapije >= today
                )
            ),
            None,
        )
        has_scheduled_future_therapy = next_scheduled_future_therapy is not None
        workflow = new_patient_workflow_status(patient)
        workflow_code = workflow[0] if workflow else None
        workflow_state = patient_therapy_workflow_state(
            patient,
            planning_possible=planning_result.planiranje_moguce,
            planning_reason=planning_result.razlog,
        )
        phased_configuration = phased_planning_configuration(patient)
        next_action = (
            "Rok propušten – hitna provjera i planiranje sljedeće komisije"
            if eligibility.rok_propusten
            else ""
        )
        expected_arrival_estimate = (
            preapproval_arrival_estimate
            if not approved_for_delivery
            else None
        )
        expected_arrival_is_estimate = bool(expected_arrival_estimate)
        display_first_uncovered = (
            eligibility_demand.datum_prve_nepokrivene_terapije
        )
        display_details = tuple(
            _detail_for_display(
                item,
                expected_delivery=(
                    expected_arrival or preapproval_arrival_estimate
                ),
                patient_physical_semantics=home_therapy_step,
            )
            for item in demand.detalji
        )
        relative_initial_projection = bool(
            demand.relativna_pocetna_projekcija
            and not (
                home_therapy_step
                and eligibility.pokriven_do
            )
        )
        if relative_initial_projection:
            # Relativni dan 0 služi samo za količinu. Ne predstavlja
            # zakazanu terapiju niti stvarni datum pokrivenosti.
            system_suggestion = demand.kolicina_koju_treba_traziti
            manual_quantity = (
                Decimal(str(override.ljekar_trazi))
                if override else system_suggestion
            )
            effective_quantity = manual_quantity
            planned_covered_until = None
            physical_covered_until = None
            planned_covered_details = []
            physical_covered_details = []
            next_planned_therapy = None
            display_first_uncovered = None
            display_details = ()
            expected_arrival_estimate = (
                expected_arrival_estimate
                or preapproval_arrival_estimate
                or expected_arrival
            )
            expected_arrival_is_estimate = bool(expected_arrival_estimate)
        extraordinary_in_progress = patient.pk in extraordinary_patient_ids
        workflow_requests = getattr(patient, "_workflow_requests", None)
        if workflow_requests is None:
            workflow_requests = list(
                Trebovanje.objects.filter(pacijent=patient).select_related(
                    "komisijski_ciklus", "komisija"
                )
            )
        else:
            workflow_requests = list(workflow_requests)
        confirmed_delivery_request = next(
            (
                item for item in workflow_requests
                if item.lijek_id in set(patient.lijek.equivalent_ids())
                and item.status in {
                    "ODOBRENO",
                    Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
                    Trebovanje.STATUS_CEKA_ISPORUKU,
                }
                and (
                    item.ocekivana_najranija_isporuka
                    or (
                        item.komisijski_ciklus.najkasniji_ocekivani_datum_isporuke
                        or item.komisijski_ciklus.najraniji_ocekivani_datum_isporuke
                        if item.komisijski_ciklus_id else None
                    )
                ) == approved_delivery_date
                and Decimal(str(item.broj_doza or 0))
                > Decimal(str(item.zaprimljene_doze or 0))
            ),
            None,
        )
        coverage_confirmed_source_id = (
            confirmed_delivery_request.pk
            if confirmed_delivery_request is not None else None
        )
        coverage_approved_source_id = (
            confirmed_delivery_request.komisija_id
            if confirmed_delivery_request is not None
            and confirmed_delivery_request.komisija_id
            else coverage_confirmed_source_id
        )
        current_cycle_request_exists = bool(
            current_window
            and current_window.ciklus
            and any(
                request.komisijski_ciklus_id == current_window.ciklus.pk
                and request.status not in {"OTKAZANO", "ODBIJENO"}
                for request in workflow_requests
            )
        )
        eligible_for_current_cycle = bool(
            planning_result.planiranje_moguce
            and (
                eligibility.treba_na_trenutnu_komisiju
                if current_window
                else status in {STATUS_ZA_KOMISIJU, STATUS_KRITICNO}
            )
            and not extraordinary_in_progress
            and not current_cycle_request_exists
        )
        proposed_procurement_units = max(
            Decimal("0"),
            Decimal(str(system_suggestion or 0)),
        )
        final_procurement_units = max(
            Decimal("0"),
            Decimal(str(effective_quantity or 0)),
        )
        included_in_draft = bool(
            eligible_for_current_cycle
            and final_procurement_units > 0
        )
        action_quantity = (
            final_procurement_units if included_in_draft else Decimal("0")
        )
        category = (
            "ukljuciti"
            if included_in_draft
            else "pregled"
            if requires_review
            else "pokriveni"
        )
        if extraordinary_in_progress:
            status = STATUS_PRATITI
            status_label = "Vanredni zahtjev u toku"
            status_class = "blue"
            status_reason = (
                "Potreba se obrađuje kroz odvojeni vanredni zahtjev i nije "
                "uključena u zbir redovnog ciklusa."
            )
            next_action = "Otvori vanredni zahtjev"
            category = "pokriveni"
        elif requires_review:
            status = STATUS_PRATITI
            status_label = "Potrebna provjera"
            status_class = "red"
            status_reason = (
                planning_result.razlog
            )
            next_action = status_reason
        elif included_in_draft:
            status = STATUS_ZA_KOMISIJU
            status_label = (
                "Početna nabavka potrebna"
                if relative_initial_projection
                else "Uključen u nacrt"
            )
            status_class = "amber"
            if not eligibility.rok_propusten:
                next_action = (
                    "Uključiti u trenutni ciklus"
                    if relative_initial_projection
                    else "Otvori karton"
                )
            if (
                eligibility.status == STATUS_RIZIK_PREKIDA
                and patient.trenutni_korak_je_kucna_terapija()
                and not relative_initial_projection
                and not eligibility.rok_propusten
            ):
                next_action = (
                    "Rizik prekida terapije – potrebna ranija isporuka, "
                    "postojeća zaliha ili vanredni zahtjev."
                )
            if relative_initial_projection:
                latest_start = None
                status_reason = (
                    "Pacijent ima validan lijek i aktivni protokol. Početna "
                    "količina je uključena bez automatskog zakazivanja terapije."
                )
        else:
            status = STATUS_POKRIVEN
            if final_procurement_units <= 0 and incoming_covered_details:
                # Već potvrđena isporuka iz ranijeg odobrenja zatvara trenutnu
                # operativnu potrebu. Budući ciklus ostaje vidljiv kao plan,
                # ali status pacijenta ne smije sugerisati novo uključivanje.
                status_label = "Nije potrebno uključiti u trenutni ciklus"
                status_class = "blue"
            elif (
                eligibility.status == STATUS_PLANIRATI_KASNIJE
                or (
                    eligibility.moze_preskociti_trenutnu
                    and eligibility.planirati_za_komisiju
                )
            ):
                status_label = "Planirati u narednom ciklusu"
                status_class = "blue"
            elif final_procurement_units <= 0:
                status_label = "Nije potrebno uključiti u trenutni ciklus"
                status_class = "blue"
            else:
                status_label = (
                    "Pokriven postojećim odobrenjem"
                    if incoming_covered_details
                    else "Pokriven – nije potreban trenutni ciklus"
                )
                status_class = "green"
            next_action = "Nije potrebna trenutna akcija"
        if (
            workflow_state.code == WORKFLOW_NEW_AWAITING_INITIAL_COMMISSION
            and relative_initial_projection
            and included_in_draft
            and phased_configuration is not None
        ):
            status_label = "Za prvo uključivanje"
            next_action = "Uvrstiti u prijedlog komisije"
            status_reason = (
                "Početna faza, ljekarski propisana doza i podaci o lijeku su "
                "kompletni. Termin se zakazuje tek nakon fizičkog zaprimanja."
            )
        elif (
            workflow_state.code == WORKFLOW_AWAITING_COMMISSION_DECISION
            and relative_initial_projection
            and not included_in_draft
        ):
            status = STATUS_PRATITI
            status_label = "Čeka odluku komisije"
            status_class = "blue"
            status_reason = "Početni zahtjev je predat komisiji."
            next_action = "Pratiti odluku komisije"
        elif (
            workflow_state.code == WORKFLOW_AWAITING_DELIVERY
            and relative_initial_projection
            and not included_in_draft
        ):
            status = STATUS_PRATITI
            status_label = "Čeka isporuku"
            status_class = "blue"
            status_reason = workflow_state.reason
            next_action = "Sačekati fizičko zaprimanje"
        if (
            workflow_state.code == WORKFLOW_READY_TO_SCHEDULE
            and relative_initial_projection
        ):
            # Zaprimanje završava logistički korak, ali ne određuje klinički
            # dan 0. Sestra ručno zakazuje početak terapije.
            status = STATUS_POKRIVEN
            status_label = (
                "Spreman za zakazivanje"
                if phased_configuration is not None
                else "Lijek zaprimljen – čeka zakazivanje"
            )
            status_class = "blue"
            status_reason = (
                "Lijek je fizički zaprimljen. Datum prve terapije određuje se "
                "ručno, bez automatskog kreiranja termina."
            )
            next_action = (
                "Zakazati prvu terapiju"
                if phased_configuration is not None
                else "Ručno zakazati prvu terapiju"
            )
        recommendation = _natural_recommendation(
            status=status,
            first_uncovered=eligibility.prva_nepokrivena_terapija,
            commission_date=(
                planning_window.datum_komisije
                if planning_window else administrative_schedule.effective_next_date
            ),
        )
        if relative_initial_projection and included_in_draft:
            recommendation = {
                "class": "commission",
                "icon": "bi-clipboard2-check",
                "title": (
                    "Za prvo uključivanje"
                    if phased_configuration is not None
                    else "Početna nabavka potrebna"
                ),
                "text": (
                    "Količina je izračunata iz početne faze aktivnog protokola. "
                    "Prva terapija ostaje za ručno zakazivanje."
                ),
            }
        delivery_date_for_risk = (
            expected_arrival or expected_arrival_estimate
        )
        delivery_risk_detail = next(
            (
                detail
                for detail in demand.detalji
                if detail.termin_postoji
                and detail.nedostatak > 0
                and delivery_date_for_risk
                and delivery_date_for_risk > detail.datum_terapije
            ),
            None,
        )
        delivery_risk_therapy = (
            delivery_risk_detail.datum_terapije
            if delivery_risk_detail and not relative_initial_projection
            else None
        )
        has_delivery_risk = bool(delivery_risk_therapy)
        procurement_display = _procurement_display(
            patient,
            demand,
            system_suggestion,
        )
        system_procurement = procurement_breakdown(
            system_suggestion,
            patient.lijek,
        )
        base_procurement = procurement_breakdown(
            eligibility.minimalna_potrebna_kolicina,
            patient.lijek,
        )
        reserve_procurement = procurement_breakdown(
            eligibility.sigurnosna_rezerva_kolicina,
            patient.lijek,
        )
        final_procurement = procurement_breakdown(
            effective_quantity,
            patient.lijek,
        )
        draft_procurement = procurement_breakdown(
            action_quantity,
            patient.lijek,
        )
        calculation_raw_quantity = max(
            Decimal("0"),
            eligibility.minimalna_potrebna_kolicina
            + eligibility.sigurnosna_rezerva_kolicina
            - eligibility.vec_pokriveno,
        )
        calculation_recommended_quantity = (
            eligibility.preporucena_kolicina_za_komisiju
        )
        calculation_procurement = procurement_breakdown(
            calculation_recommended_quantity,
            patient.lijek,
        )
        last_administered_on = _latest_therapy_date(patient)
        modal_plan_details = decision_relevant_display_details
        modal_plan_horizon = expected_arrival or expected_arrival_estimate
        modal_plan_before_delivery = decision_relevant_display_details
        modal_plan_after_delivery = ()
        commission_quantity_explanation = None
        home_projection = None
        home_continuity = None
        coverage_calculation = None
        calculation_period_start = eligibility.obracunski_period_pocetak
        calculation_period_end = eligibility.obracunski_period_kraj
        calculation_period_display_end = (
            eligibility.obracunski_prikaz_period_kraj
            or calculation_period_end
        )
        decision_physically_covered = min(
            Decimal(str(eligibility.vec_pokriveno or 0)),
            physical_covered_quantity,
        )
        decision_confirmed_delivery = Decimal(str(
            eligibility_demand.dostupno_po_izvoru.get(
                SOURCE_APPROVED_WAITING,
                0,
            ) or 0
        ))
        decision_usable_approval = max(
            Decimal("0"),
            Decimal(str(eligibility.vec_pokriveno or 0))
            - decision_physically_covered
            - decision_confirmed_delivery,
        )
        continuity_warning_text = ""
        urgent_action_text = ""
        regular_plan_text = ""
        if home_therapy_step:
            from .home_therapy import (
                calculate_home_therapy_continuity,
                calculate_home_therapy_projection,
                format_stock_quantity,
            )

            home_projection = calculate_home_therapy_projection(
                patient,
                today=today,
                expected_delivery=(
                    expected_arrival or expected_arrival_estimate
                ),
            )
            physical_covered_until = home_projection.physical_covered_until
            planned_covered_until = home_projection.planned_covered_until
            physical_covered_quantity = (
                home_projection.patient_quantity
                + home_projection.reserved_quantity
            )
            home_continuity = calculate_home_therapy_continuity(
                patient,
                projection=home_projection,
                planned_commission_window=(
                    eligibility.planirati_za_komisiju or planning_window
                ),
                estimated_delivery=expected_arrival_estimate,
                confirmed_delivery=expected_arrival,
                confirmed_incoming_quantity=(
                    eligibility_demand.dostupno_po_izvoru.get(
                        SOURCE_APPROVED_WAITING,
                        0,
                    )
                ),
                available_free_quantity=(
                    eligibility_demand.dostupno_po_izvoru.get(
                        AVAILABLE_FREE_FRIDGE,
                        0,
                    )
                ),
                coverage_details=eligibility_demand.detalji,
                usable_active_approval_quantity=(
                    eligibility_demand.kolicina_pokrivena_aktivnom_komisijom
                ),
                extraordinary_in_progress=extraordinary_in_progress,
                today=today,
            )
            display_first_uncovered = home_continuity.first_uncovered_therapy
            modal_plan_horizon = (
                eligibility.obracunski_prikaz_period_kraj
                or eligibility.obracunski_period_kraj
            )
            units_per_application = Decimal(str(
                home_projection.units_per_application or 0
            ))
            physical_remainder = (
                (
                    Decimal(str(home_projection.patient_quantity or 0))
                    + Decimal(str(home_projection.reserved_quantity or 0))
                ) % units_per_application
                if units_per_application > 0 else Decimal("0")
            )
            covered_for_formula = Decimal(str(
                eligibility.vec_pokriveno or 0
            ))
            physically_counted = min(
                covered_for_formula,
                physical_remainder,
            )
            covered_after_physical = max(
                Decimal("0"),
                covered_for_formula - physically_counted,
            )
            confirmed_incoming_available = Decimal(str(
                demand.kolicina_odobrena_nedostavljena or 0
            ))
            confirmed_incoming_counted = min(
                covered_after_physical,
                confirmed_incoming_available,
            )
            approved_for_new_plan = max(
                Decimal("0"),
                covered_after_physical - confirmed_incoming_counted,
            )
            decision_physically_covered = physically_counted
            decision_confirmed_delivery = confirmed_incoming_counted
            decision_usable_approval = approved_for_new_plan
            approved_remaining = Decimal(str(
                demand.neiskoristene_odobrene_doze or 0
            ))
            approval_overlap = Decimal(str(
                demand.dostupno_po_izvoru.get(
                    "linked_approval_overlap_excluded",
                    0,
                ) or 0
            ))
            if approved_for_new_plan > 0 and confirmed_incoming_counted > 0:
                approval_note = (
                    "Odobrenje pripada ovom pacijentu i važeće je. "
                    f"{confirmed_incoming_counted:g} je već vezano za odobreno "
                    "trebovanje sa poznatim datumom isporuke. "
                    f"Preostalih {approved_for_new_plan:g} može se naručiti po "
                    "važećem odobrenju i uračunato je u novi planski period, "
                    "ali još nije fizički osigurano."
                )
                approval_counted = True
                approval_plan_status = "Djelimično naručeno"
            elif approved_for_new_plan > 0:
                approval_note = (
                    "Odobrenje pripada ovom pacijentu, važeće je i nije već "
                    "uključeno u potvrđeno trebovanje ili pošiljku. Može se "
                    "odmah naručiti i uračunato je "
                    "u količinu za novi planski period. Još nije fizički "
                    "osigurano dok ne postoji potvrđena isporuka."
                )
                approval_counted = True
                approval_plan_status = "Raspoloživo za novi plan"
            elif confirmed_incoming_counted > 0:
                approval_note = (
                    "Najavljena količina vezana je za odobreno trebovanje sa "
                    "poznatim datumom isporuke i uračunata je samo jednom, "
                    "kao buduća isporuka."
                )
                approval_counted = True
                approval_plan_status = "Već naručeno"
            elif approved_remaining > 0 and approval_overlap >= approved_remaining:
                approval_note = (
                    "Odobrenje pripada ovom pacijentu, ali se ne može ponovo "
                    "iskoristiti za novi planski period: "
                    "preostala količina već je vezana za postojeće fizičke "
                    "rezervacije ovog pacijenta."
                )
                approval_counted = False
                approval_plan_status = "Nije raspoloživo za novi plan"
            elif approved_remaining > 0:
                approval_note = (
                    "Nije raspoloživo za novi planski period prema važećem "
                    "stanju odobrenja. Potrebna je provjera veze sa zahtjevom "
                    "ili završenim ciklusom."
                )
                approval_counted = False
                approval_plan_status = "Potrebna provjera"
            else:
                approval_note = "Nema preostale količine iz ranijeg odobrenja."
                approval_counted = False
                approval_plan_status = "Nema preostalog odobrenja"
            minimum_quantity = Decimal(str(
                eligibility.minimalna_potrebna_kolicina or 0
            ))
            calculation_application_count = (
                int(minimum_quantity // units_per_application)
                if units_per_application > 0 else 0
            )
            calculation_period_start = eligibility.obracunski_period_pocetak
            calculation_period_end = eligibility.obracunski_period_kraj
            calculation_period_display_end = (
                eligibility.obracunski_prikaz_period_kraj
                or calculation_period_end
            )
            future_after_first = max(
                Decimal("0"),
                minimum_quantity - units_per_application,
            )
            modal_plan_details = _modal_plan_details(
                eligibility_demand.detalji,
                today=today,
                display_horizon=calculation_period_end,
                delivery_split=home_continuity.expected_delivery,
                confirmed_delivery=(
                    home_continuity.expected_delivery
                    if home_continuity.expected_delivery_confirmed else None
                ),
                approved_not_ordered_quantity=(
                    approved_for_new_plan
                ),
                calculation_start=calculation_period_start,
                patient_physical_semantics=True,
                last_administered_on=last_administered_on,
                minimum_items=(
                    int(
                        (
                            physical_covered_quantity
                            + confirmed_incoming_available
                            + approved_for_new_plan
                        ) // units_per_application
                    )
                    + sum(
                        1
                        for detail in eligibility_demand.detalji
                        if expected_arrival
                        and detail.datum_terapije < expected_arrival
                        and (
                            not physical_covered_until
                            or detail.datum_terapije > physical_covered_until
                        )
                    )
                    if units_per_application > 0 else 0
                ),
            )
            commission_quantity_explanation = {
                "period_start": calculation_period_start,
                "period_end": calculation_period_end,
                "display_period_end": calculation_period_display_end,
                "target_date": eligibility.obracunski_ciljni_datum,
                "target_reason": eligibility.obracunski_razlog,
                "application_count": calculation_application_count,
                "delivery_horizon": home_continuity.expected_delivery,
                "needed": minimum_quantity,
                "future_after_first": future_after_first,
                "physically_secured_total": physical_covered_quantity,
                "physically_secured": physically_counted,
                "confirmed_incoming": confirmed_incoming_counted,
                "confirmed_incoming_total": confirmed_incoming_available,
                "approved_remaining": approved_remaining,
                "approved_for_new_plan": approved_for_new_plan,
                "already_secured_or_approved": min(
                    minimum_quantity,
                    physically_counted
                    + confirmed_incoming_counted
                    + approved_for_new_plan,
                ),
                "uncovered_need": max(
                    Decimal("0"),
                    minimum_quantity
                    - physically_counted
                    - confirmed_incoming_counted
                    - approved_for_new_plan,
                ),
                "approval_linked_overlap": approval_overlap,
                "approval_counted": approval_counted,
                "approval_plan_status": approval_plan_status,
                "approval_note": approval_note,
                # Slobodna fiziÄŤka zaliha ostaje vidljiva kao moguÄ‡a ruÄŤna
                # dodjela, ali nije ukljuÄŤena u pokriÄ‡e ni u formulu dok
                # konkretna rezervacija pacijenta zaista ne postoji.
                "free_assignable": home_continuity.free_stock_quantity,
                "free_replenished_in_period": bool(
                    home_continuity.free_stock_bridge_quantity > 0
                ),
                "reserve": Decimal(str(
                    eligibility.sigurnosna_rezerva_kolicina or 0
                )),
                "raw_request": calculation_raw_quantity,
                "request": calculation_recommended_quantity,
                "request_procurement": calculation_procurement,
                "rounded_to_package": bool(
                    calculation_recommended_quantity
                    != calculation_raw_quantity
                ),
                "dose_dates": tuple(
                    item["datum"]
                    for item in modal_plan_details
                    if item["u_obracunu"]
                ),
            }
            coverage_calculation = build_home_coverage_calculation(
                patient=patient,
                projection=home_projection,
                dose_plan=modal_plan_details,
                confirmed_delivery_date=expected_arrival,
                estimated_delivery_date=expected_arrival_estimate,
                confirmed_delivery_quantity=(
                    eligibility_demand.dostupno_po_izvoru.get(
                        SOURCE_APPROVED_WAITING,
                        0,
                    )
                ),
                approved_not_ordered_quantity=(
                    approved_for_new_plan
                ),
                new_commission_quantity=calculation_recommended_quantity,
                calculation_period_start=calculation_period_start,
                current_window=current_window,
                next_window=eligibility.naredna_komisija,
                planned_window=eligibility.planirati_za_komisiju,
                risk_action=home_continuity.recommended_action_label,
                confirmed_delivery_source_id=(
                    coverage_confirmed_source_id
                ),
                approved_not_ordered_source_id=(
                    coverage_approved_source_id
                ),
            )
            modal_plan_details = coverage_calculation.dose_plan
            modal_plan_before_delivery = tuple(
                item for item in modal_plan_details
                if (
                    not coverage_calculation.expected_delivery
                    or item["datum"] < coverage_calculation.expected_delivery
                )
            )
            modal_plan_after_delivery = tuple(
                item for item in modal_plan_details
                if coverage_calculation.expected_delivery
                and item["datum"] >= coverage_calculation.expected_delivery
            )
            modal_plan_horizon = (
                calculation_period_display_end
                or calculation_period_end
                or coverage_calculation.expected_delivery
            )
            physical_covered_until = (
                coverage_calculation.physically_secured_until
            )
            display_first_uncovered = (
                coverage_calculation.first_without_available_source
            )
            home_continuity = home_continuity.__class__(
                **{
                    **home_continuity.__dict__,
                    "risk": coverage_calculation.immediate_risk,
                    "status_code": (
                        "RISK" if coverage_calculation.immediate_risk else "COVERED"
                    ),
                    "status_label": (
                        "Rizik prekida terapije"
                        if coverage_calculation.immediate_risk
                        else "Kontinuitet osiguran"
                    ),
                    "safely_covered_until": (
                        coverage_calculation.physically_secured_until
                    ),
                    "first_uncovered_therapy": (
                        coverage_calculation.first_risk_dose
                        or coverage_calculation.first_without_available_source
                    ),
                    "planned_commission_date": (
                        coverage_calculation.commission_date
                    ),
                    "expected_delivery": coverage_calculation.expected_delivery,
                    "expected_delivery_confirmed": (
                        coverage_calculation.expected_delivery_confirmed
                    ),
                    "recommended_action_label": (
                        coverage_calculation.current_action
                    ),
                    "uncovered_therapy_dates": (
                        coverage_calculation.uncovered_before_delivery_dates
                    ),
                    "uncovered_quantity": (
                        coverage_calculation.uncovered_before_delivery_quantity
                    ),
                }
            )
            # Najavljena isporuka iz ranijeg prava i redovni novi zahtjev nisu
            # isti workflow. Centralni rezultat određuje oba datuma i time
            # uklanja 03/09 kao lažni datum nove komisije kada je stvarni
            # naredni ciklus 14/10.
            if coverage_calculation.commission_window is not None:
                planning_window = coverage_calculation.commission_window
                latest_start = coverage_calculation.preparation_date
            if (
                current_window
                and coverage_calculation.commission_date
                and coverage_calculation.commission_date
                != current_window.datum_komisije
            ):
                eligible_for_current_cycle = False
                included_in_draft = False
                action_quantity = Decimal("0")
                category = (
                    "pregled"
                    if coverage_calculation.immediate_risk else "pokriveni"
                )
                draft_procurement = procurement_breakdown(
                    Decimal("0"),
                    patient.lijek,
                )
            if home_projection.date_plan_reliable:
                status_label = coverage_calculation.status_label
                status_class = (
                    "red" if coverage_calculation.immediate_risk else "blue"
                )
                status = (
                    STATUS_KRITICNO
                    if coverage_calculation.immediate_risk else STATUS_PRATITI
                )
                next_action = coverage_calculation.current_action
            else:
                next_action = home_continuity.recommended_action_label
            modal_plan_before_delivery = tuple(
                item for item in modal_plan_details
                if item["segment"] == "do_isporuke"
            )
            modal_plan_after_delivery = tuple(
                item for item in modal_plan_details
                if item["segment"] == "nakon_isporuke"
            )
            if (
                home_projection.date_plan_reliable
                and coverage_calculation.immediate_risk
            ):
                has_delivery_risk = True
                delivery_risk_therapy = coverage_calculation.first_risk_dose
                status = STATUS_KRITICNO
                status_label = coverage_calculation.status_label
                status_class = "red"
                next_action = coverage_calculation.current_action
                category = "pregled"
                missing_dates = ", ".join(
                    value.strftime("%d/%m/%Y")
                    for value in home_continuity.uncovered_therapy_dates
                )
                status_reason = (
                    f"Prva nepokrivena terapija je "
                    f"{coverage_calculation.first_risk_dose:%d/%m/%Y}. "
                    f"Do očekivane isporuke nedostaje "
                    f"{home_continuity.uncovered_quantity:g} jedinica"
                    f"{f' ({missing_dates})' if missing_dates else ''}. "
                    f"Preporučena radnja: {next_action}."
                )
                first_gap_detail = next(
                    (
                        item for item in eligibility_demand.detalji
                    if item.datum_terapije
                        == coverage_calculation.first_risk_dose
                    ),
                    None,
                )
                urgent_missing_quantity = (
                    Decimal(str(first_gap_detail.nedostatak or 0))
                    if first_gap_detail else units_per_application
                )
                urgent_missing_text = format_stock_quantity(
                    patient.lijek,
                    urgent_missing_quantity,
                )
                continuity_warning_text = coverage_calculation.warning_text
                urgent_action_text = (
                    coverage_calculation.immediate_action_text
                    or (
                        f"Potrebna akcija: osigurati {urgent_missing_text} za dozu "
                        f"{coverage_calculation.first_risk_dose:%d/%m/%Y}."
                    )
                )
                if coverage_calculation.commission_date:
                    package_count = calculation_procurement["package_count"]
                    package_label = (
                        "pakovanje" if package_count == 1 else "pakovanja"
                    )
                    regular_plan_text = (
                        f"Uključiti {format_stock_quantity(patient.lijek, calculation_recommended_quantity)} "
                        f"/ {package_count} {package_label} u komisiju "
                        f"{coverage_calculation.commission_date:%d/%m/%Y}."
                    )
                recommendation = {
                    "title": "Postoji rizik prekida terapije",
                    "text": continuity_warning_text,
                    "class": "critical",
                    "icon": "bi-exclamation-triangle",
                }
        existing_request = confirmed_delivery_request or next(
            (
                item for item in workflow_requests
                if item.lijek_id in set(patient.lijek.equivalent_ids())
                and item.status not in {
                    Trebovanje.STATUS_OTKAZANO,
                    "ODBIJENO",
                    "ZAPRIMLJENO",
                }
                and item.komisijski_ciklus_id
            ),
            None,
        )
        existing_request_summary = None
        if existing_request is not None:
            existing_approved = Decimal(str(
                existing_request.odobrene_doze
                if existing_request.odobrene_doze is not None
                else existing_request.broj_doza
                or 0
            ))
            existing_ordered = Decimal(str(existing_request.broj_doza or 0))
            existing_received = Decimal(str(
                existing_request.zaprimljene_doze or 0
            ))
            existing_pending = max(
                Decimal("0"),
                min(existing_approved, existing_ordered) - existing_received,
            )
            existing_cycle = existing_request.komisijski_ciklus
            existing_delivery = (
                existing_request.ocekivana_najranija_isporuka
                or (
                    existing_cycle.najkasniji_ocekivani_datum_isporuke
                    or existing_cycle.najraniji_ocekivani_datum_isporuke
                    if existing_cycle else None
                )
            )
            existing_request_summary = {
                "request_id": existing_request.pk,
                "cycle_date": (
                    existing_cycle.datum_komisije if existing_cycle else None
                ),
                "quantity": existing_pending,
                "procurement": procurement_breakdown(
                    existing_pending, patient.lijek
                ),
                "status": existing_request.status,
                "status_label": (
                    "Zahtjev potvrđen"
                    if existing_request.status in {
                        "ODOBRENO",
                        Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
                        Trebovanje.STATUS_CEKA_ISPORUKU,
                    }
                    else existing_request.get_status_display()
                ),
                "expected_delivery": existing_delivery,
            }
        recommended_commission_window = (
            coverage_calculation.commission_window
            if coverage_calculation is not None
            else eligibility.planirati_za_komisiju
        )
        decision_cycle_date = (
            coverage_calculation.commission_date
            if coverage_calculation is not None else (
                recommended_commission_window.datum_komisije
                if recommended_commission_window else None
            )
        )
        current_cycle_date = (
            administrative_schedule.active_cycle.datum_komisije
            if administrative_schedule.active_cycle else None
        )
        existing_current_request = _existing_request_for_final_decision(
            patient=patient,
            medicine_ids=set(patient.lijek.equivalent_ids()),
            cycle_date=current_cycle_date,
            workflow_requests=workflow_requests,
        )
        existing_planned_request = (
            _existing_request_for_final_decision(
                patient=patient,
                medicine_ids=set(patient.lijek.equivalent_ids()),
                cycle_date=decision_cycle_date,
                workflow_requests=workflow_requests,
            )
            if decision_cycle_date != current_cycle_date else None
        )
        # Potpuno realizovan ili odbijen raniji ciklus je historijski kontekst,
        # a ne trenutna komisijska odluka. U tom slučaju naredni planski ciklus
        # (i njegov eventualni nacrt) mora imati prednost. Aktivni odobreni ili
        # djelimično zaprimljeni zahtjev i dalje ostaje primarna odluka dok se
        # njegova isporuka ne završi.
        current_request_is_operational = bool(
            existing_current_request
            and existing_current_request["state_code"] not in {
                RECEIVED,
                REJECTED,
            }
        )
        existing_decision_request = (
            existing_current_request
            if current_request_is_operational
            else existing_planned_request
        )
        if existing_decision_request is not None:
            # Sažetak postojećeg zahtjeva prikazuje samo količinu koja je
            # stvarno naručena i još čeka prijem. Odobreno komisijsko pravo
            # ostaje zaseban izvor i ne smije se ponovo prikazati kao incoming.
            existing_committed_quantity = existing_decision_request[
                "committed_quantity"
            ]
            existing_request_summary = {
                **(existing_request_summary or {}),
                "request_id": existing_decision_request["request_id"],
                "cycle_date": existing_decision_request["cycle_date"],
                "quantity": existing_committed_quantity,
                "procurement": procurement_breakdown(
                    existing_committed_quantity, patient.lijek
                ),
                "status": existing_decision_request["state_code"],
                "status_label": existing_decision_request["status_label"],
            }
        forecast_only = bool(
            decision_cycle_date
            and (
                (
                    not home_therapy_step
                    and eligibility.status == STATUS_PLANIRATI_KASNIJE
                )
                or (
                    current_request_is_operational
                    and current_cycle_date
                    and decision_cycle_date != current_cycle_date
                )
            )
        )
        forecast_quantity = (
            calculation_recommended_quantity if forecast_only else Decimal("0")
        )
        forecast_cycle_date = decision_cycle_date if forecast_only else None
        if (
            existing_decision_request
            and forecast_cycle_date == existing_decision_request["cycle_date"]
        ):
            forecast_quantity = Decimal("0")
            forecast_cycle_date = None
        gross_required_quantity = max(
            Decimal("0"),
            Decimal(str(eligibility.minimalna_potrebna_kolicina or 0))
            + Decimal(str(eligibility.sigurnosna_rezerva_kolicina or 0))
            - decision_physically_covered,
        )
        committed_current_quantity = max(
            Decimal(str(
                existing_decision_request["committed_quantity"]
                if existing_decision_request else 0
            )),
            decision_confirmed_delivery,
        )
        additional_raw_quantity = (
            Decimal("0")
            if forecast_only else max(
                Decimal("0"),
                gross_required_quantity
                - committed_current_quantity
                - decision_usable_approval,
            )
        )
        additional_quantity = procurement_breakdown(
            additional_raw_quantity,
            patient.lijek,
        )["rounded_procurement_units"]
        calculation_dose_dates = tuple(
            (commission_quantity_explanation or {}).get("dose_dates", ())
            or tuple(
                item.get("datum")
                for item in modal_plan_details
                if item.get("datum") is not None
            )
        )
        commission_decision = build_commission_decision(
            medicine=patient.lijek,
            calculated_quantity=calculation_raw_quantity,
            rounded_quantity=calculation_recommended_quantity,
            cycle_date=decision_cycle_date,
            period_start=calculation_period_start,
            base_period_end=calculation_period_display_end,
            calculated_period_end=calculation_period_end,
            first_uncovered_dose=(
                coverage_calculation.first_without_available_source
                if coverage_calculation is not None else display_first_uncovered
            ),
            doses_used_in_calculation=calculation_dose_dates,
            existing_proposal_quantity=(
                existing_decision_request["quantity"]
                if existing_decision_request else None
            ),
            existing_request_quantity=(
                existing_decision_request["quantity"]
                if existing_decision_request else None
            ),
            existing_request_status=(
                existing_decision_request["status"]
                if existing_decision_request else None
            ),
            existing_cycle_date=(
                existing_decision_request["cycle_date"]
                if existing_decision_request else None
            ),
            existing_status_label=(
                existing_decision_request["status_label"]
                if existing_decision_request else ""
            ),
            existing_request_state=(
                existing_decision_request["state"]
                if existing_decision_request else None
            ),
            existing_request_approved_quantity=(
                existing_decision_request["approved_quantity"]
                if existing_decision_request else 0
            ),
            existing_request_received_quantity=(
                existing_decision_request["received_quantity"]
                if existing_decision_request else 0
            ),
            existing_request_awaiting_receipt_quantity=(
                existing_decision_request["awaiting_receipt_quantity"]
                if existing_decision_request else 0
            ),
            minimum_required_quantity=(
                eligibility.minimalna_potrebna_kolicina
            ),
            gross_required_quantity=gross_required_quantity,
            physically_covered_quantity=decision_physically_covered,
            confirmed_delivery_quantity=decision_confirmed_delivery,
            usable_existing_approval_quantity=decision_usable_approval,
            additional_quantity_current_cycle=additional_quantity,
            forecast_quantity_next_cycle=forecast_quantity,
            forecast_cycle=forecast_cycle_date,
            safety_reserve_quantity=(
                eligibility.sigurnosna_rezerva_kolicina
            ),
            reasons=tuple(
                value for value in (
                    eligibility.razlog,
                    eligibility.obracunski_razlog,
                ) if value
            ),
        )
        if (
            not home_therapy_step
            and existing_decision_request
            and existing_decision_request["state_code"] == CONFIRMED
            and existing_decision_request["committed_quantity"] > 0
            and decision_confirmed_delivery <= 0
        ):
            # Isti kanonski plan koriste karton i modal. Potvrđeni zahtjev je
            # administrativni izvor za narednu nepokrivenu dozu, ali nije ni
            # fizička zaliha ni potvrđena isporuka.
            modal_plan_details = allocate_existing_request_pending(
                modal_plan_details,
                request_quantity=existing_decision_request["committed_quantity"],
                request_id=existing_decision_request["request_id"],
            )
            decision_relevant_display_details = modal_plan_details
            modal_plan_before_delivery = tuple(
                item for item in modal_plan_details
                if item.get("segment") == "do_isporuke"
            )
            modal_plan_after_delivery = tuple(
                item for item in modal_plan_details
                if item.get("segment") == "nakon_isporuke"
            )
        elif (
            not home_therapy_step
            and existing_decision_request
            and existing_decision_request["state_code"]
            in {APPROVED, PARTIALLY_RECEIVED}
            and existing_decision_request["awaiting_receipt_quantity"] > 0
            and decision_confirmed_delivery <= 0
        ):
            modal_plan_details = allocate_approved_awaiting_receipt(
                modal_plan_details,
                request_quantity=existing_decision_request[
                    "awaiting_receipt_quantity"
                ],
                request_id=(
                    existing_decision_request["legacy_request_id"]
                    or existing_decision_request["request_id"]
                ),
            )
            decision_relevant_display_details = modal_plan_details
            modal_plan_before_delivery = tuple(
                item for item in modal_plan_details
                if item.get("segment") == "do_isporuke"
            )
            modal_plan_after_delivery = tuple(
                item for item in modal_plan_details
                if item.get("segment") == "nakon_isporuke"
            )

        has_existing_request_pending_doses = any(
            item.get("status_kod") == "existing-request-pending"
            for item in modal_plan_details
        )
        has_approved_awaiting_receipt_doses = any(
            item.get("status_kod") == "approved-awaiting-receipt"
            for item in modal_plan_details
        )
        has_unsecured_doses = any(
            item.get("status_kod") == "uncovered"
            for item in modal_plan_details
        )
        has_other_nonphysical_doses = any(
            item.get("status_kod")
            not in {
                "covered",
                "existing-request-pending",
                "approved-awaiting-receipt",
                "uncovered",
            }
            for item in modal_plan_details
        )
        if commission_quantity_explanation is not None:
            commission_quantity_explanation.update({
                "base_period_end": commission_decision.base_period_end,
                "effective_period_end": (
                    commission_decision.effective_period_end
                ),
                "display_period_end": commission_decision.period_end,
                "period_extension_reason": (
                    commission_decision.period_extension_reason
                ),
            })
            if commission_decision.period_extension_reason:
                original_reason = (
                    commission_quantity_explanation.get("target_reason") or ""
                )
                commission_quantity_explanation["target_reason"] = " ".join(
                    value for value in (
                        original_reason,
                        commission_decision.period_extension_reason,
                    ) if value
                )

        if (
            not relative_initial_projection
            and not requires_review
            and not has_delivery_risk
            and not (
                coverage_calculation is not None
                and coverage_calculation.immediate_risk
            )
        ):
            status_label = commission_decision.status_label
            status_class = commission_decision.status_tone
            next_action = commission_decision.action_label
            status = (
                STATUS_ZA_KOMISIJU
                if commission_decision.is_action_required
                else STATUS_POKRIVEN
                if commission_decision.decision_status == NOT_REQUIRED
                else STATUS_PRATITI
            )
            recommendation = {
                "title": commission_decision.status_label,
                "text": commission_decision.recommendation_text,
                "class": (
                    "commission"
                    if commission_decision.status_tone == "amber" else "covered"
                ),
                "icon": (
                    "bi-clipboard2-check"
                    if commission_decision.status_tone == "amber"
                    else "bi-check2-circle"
                ),
            }

        next_proposal_summary = None
        if (
            commission_decision.forecast_cycle
            and commission_decision.forecast_quantity_next_cycle > 0
        ):
            next_proposal_summary = {
                "cycle_date": commission_decision.forecast_cycle,
                "quantity": commission_decision.forecast_quantity_next_cycle,
                "procurement": commission_decision.forecast_procurement,
                "status_label": "Buduća procjena",
                "decision_status": commission_decision.decision_status,
            }
        reliable_delivery_for_recommended_cycle = (
            recommended_commission_window.najkasnija_isporuka
            if recommended_commission_window else None
        )
        delivery_margin_days = (
            (display_first_uncovered - reliable_delivery_for_recommended_cycle).days
            if display_first_uncovered and reliable_delivery_for_recommended_cycle
            else None
        )
        delivery_too_close = bool(
            delivery_margin_days is not None
            and delivery_margin_days >= 0
            and delivery_margin_days <= parameters.safety_reserve_days
        )
        rows.append({
            "danas": today,
            "pacijent": patient,
            "lijek": patient.lijek,
            # Patient-facing identity is the canonical therapy.  The concrete
            # product remains a separate logistics/SKU concern.
            "terapija_naziv": patient.terapija_za_prikaz,
            "potreban_proizvod": (
                phased_configuration.medicine
                if phased_configuration is not None
                else patient.trenutni_proizvod
            ),
            "fazni_protokol": phased_configuration is not None,
            "komisija_trenutno_nije_potrebna": bool(
                phased_configuration is not None
                and action_quantity <= 0
                and not requires_review
            ),
            "planning_result": planning_result,
            # Kompatibilni ključ sada uvijek znači centralno planirano pokriće.
            "pokriven_do": planned_covered_until,
            "fizicki_pokriven_do": physical_covered_until,
            "planirano_pokriven_do": planned_covered_until,
            "broj_pokrivenih_terapija": len(planned_covered_details),
            "broj_fizicki_pokrivenih_terapija": (
                int(
                    (
                        home_projection.patient_quantity
                        + home_projection.reserved_quantity
                    )
                    // home_projection.units_per_application
                )
                if home_projection and home_projection.units_per_application > 0
                else len(physical_covered_details)
            ),
            "fizicki_pokrivena_kolicina": physical_covered_quantity,
            "home_projection": home_projection,
            "coverage_calculation": coverage_calculation,
            "commission_decision": commission_decision,
            "prikazana_komisijska_kolicina": (
                commission_decision.displayed_quantity
            ),
            "prikazana_komisijska_nabavka": commission_decision.procurement,
            "finalni_status_komisijske_odluke": (
                commission_decision.decision_status
            ),
            "datum_komisijskog_ciklusa": (
                commission_decision.cycle_date
            ),
            "datum_pripreme_zahtjeva": (
                coverage_calculation.preparation_date
                if coverage_calculation is not None else latest_start
            ),
            "prva_doza_obracunskog_perioda": (
                coverage_calculation.first_commission_calculation_dose
                if coverage_calculation is not None else calculation_period_start
            ),
            "kanonski_ocekivana_isporuka": (
                coverage_calculation.expected_delivery
                if coverage_calculation is not None else (
                    expected_arrival or expected_arrival_estimate
                )
            ),
            "kontinuitet_terapije": home_continuity,
            "rizik_prekida_terapije": bool(
                coverage_calculation.immediate_risk
                if coverage_calculation is not None
                else home_continuity and home_continuity.risk
            ),
            "nepokrivene_doze_do_isporuke": (
                home_continuity.uncovered_quantity
                if home_continuity else Decimal("0")
            ),
            "nepokriveni_datumi_do_isporuke": (
                home_continuity.uncovered_therapy_dates
                if home_continuity else ()
            ),
            "sigurno_pokriven_do": (
                coverage_calculation.physically_secured_until
                if coverage_calculation is not None else
                home_continuity.safely_covered_until
                if home_continuity else physical_covered_until
            ),
            "moguce_pokriveno_slobodnom_zalihom_do": (
                home_continuity.coverable_with_free_stock_until
                if home_continuity else None
            ),
            "ocekivano_pokriven_nakon_isporuke_do": (
                home_continuity.expected_covered_after_delivery_until
                if home_continuity else None
            ),
            "prva_fizicki_nedodijeljena_terapija": (
                home_continuity.first_physically_uncovered_therapy
                if home_continuity else display_first_uncovered
            ),
            "prva_bez_dostupnog_izvora": (
                coverage_calculation.first_without_available_source
                if coverage_calculation is not None else
                home_continuity.first_uncovered_therapy
                if home_continuity else display_first_uncovered
            ),
            "fizicki_pokriveni_detalji": physical_covered_display_details,
            "relevantni_plan_detalji": decision_relevant_display_details,
            "modal_plan_detalji": modal_plan_details,
            "ima_doze_u_postojecem_zahtjevu": (
                has_existing_request_pending_doses
            ),
            "ima_doze_odobrene_ceka_zaprimanje": (
                has_approved_awaiting_receipt_doses
            ),
            "ima_doze_bez_izvora": has_unsecured_doses,
            "ima_druge_nefizicke_doze": has_other_nonphysical_doses,
            "modal_plan_do_isporuke": modal_plan_before_delivery,
            "modal_plan_nakon_isporuke": modal_plan_after_delivery,
            "modal_plan_horizont": modal_plan_horizon,
            "objasnjenje_kolicine_komisije": (
                commission_quantity_explanation
            ),
            "prva_nepokrivena_terapija": (
                coverage_calculation.first_without_available_source
                if coverage_calculation is not None else
                (
                    home_continuity.first_uncovered_therapy
                    or home_continuity.first_physically_uncovered_therapy
                )
                if home_continuity else
                home_projection.first_uncovered_therapy
                if home_projection else display_first_uncovered
            ),
            "komisiju_pokrenuti_najkasnije": latest_start,
            "ocekivani_datum_dolaska": expected_arrival,
            "procijenjeni_datum_dolaska": expected_arrival_estimate,
            "ocekivani_datum_dolaska_je_procjena": expected_arrival_is_estimate,
            "rizicna_terapija": delivery_risk_therapy,
            "posljednja_terapija": last_administered_on,
            "sljedeca_planirana_terapija": next_planned_therapy,
            "sljedeca_stvarno_zakazana_terapija": (
                next_scheduled_future_therapy
            ),
            "naredna_administrativna_komisija": (
                planning_window.datum_komisije
                if planning_window else administrative_schedule.effective_next_date
            ),
            "otvoreni_komisijski_ciklus": administrative_schedule.active_cycle,
            "otvoreni_komisijski_ciklus_datum": (
                administrative_schedule.active_cycle.datum_komisije
                if administrative_schedule.active_cycle else None
            ),
            "prvi_relevantni_komisijski_ciklus": recommended_commission_window,
            "najavljena_isporuka_iz_ranijeg_odobrenja": (
                expected_arrival if approved_for_delivery else None
            ),
            "postojeci_zahtjev_u_otvorenom_ciklusu": (
                current_cycle_request_exists
            ),
            "pouzdana_isporuka_trenutne_komisije": (
                eligibility.pouzdana_isporuka_trenutne_komisije
            ),
            "naredna_komisija": eligibility.naredna_komisija,
            "pouzdana_isporuka_naredne_komisije": (
                eligibility.pouzdana_isporuka_naredne_komisije
            ),
            "preporuceni_komisijski_ciklus": recommended_commission_window,
            "posljednji_siguran_datum_za_ukljucivanje": (
                recommended_commission_window.rok_pripreme
                if recommended_commission_window else None
            ),
            "ocekivana_pouzdana_isporuka": (
                reliable_delivery_for_recommended_cycle
            ),
            "isporuka_preblizu_terapiji": delivery_too_close,
            "razmak_isporuke_do_terapije_dana": delivery_margin_days,
            "objasnjenje_preporuke": recommendation,
            "upozorenje_kontinuiteta": continuity_warning_text,
            "hitna_akcija_tekst": urgent_action_text,
            "redovni_plan_tekst": regular_plan_text,
            "hitne_opcije": (
                coverage_calculation.action_options
                if coverage_calculation is not None else ()
            ),
            "postojeci_zahtjev_sazetak": existing_request_summary,
            "sljedeci_prijedlog_sazetak": next_proposal_summary,
            "sistem_predlaze": system_suggestion,
            "minimalno_potrebno": (
                eligibility.minimalna_potrebna_kolicina
            ),
            "nepokrivene_doze_do_naredne_pouzdane_isporuke": (
                eligibility.minimalna_potrebna_kolicina
            ),
            "sigurnosna_rezerva": (
                eligibility.sigurnosna_rezerva_kolicina
            ),
            "prikaz_osnovno": eligibility.minimalna_potrebna_kolicina,
            "prikaz_rezerva": eligibility.sigurnosna_rezerva_kolicina,
            "vec_pokriveno_za_preporuku": eligibility.vec_pokriveno,
            "obracunska_sirova_preporuka": calculation_raw_quantity,
            "obracunska_preporucena_kolicina": (
                calculation_recommended_quantity
            ),
            "obracunska_nabavka": calculation_procurement,
            "preporuceno_traziti": (
                eligibility.preporucena_kolicina_za_komisiju
            ),
            "ljekar_trazi": manual_quantity,
            # Kompatibilni ključevi za postojeće izvještaje i integracije.
            # Vrijednosti dolaze isključivo iz V2 rezultata.
            "za_novu_komisiju": action_quantity,
            "kolicina_za_komisiju": action_quantity,
            "nova_komisija_potrebna": action_quantity > 0,
            "izracunata_potreba": demand.neto_nedostatak,
            "matematicka_kolicina_za_komisiju": system_suggestion,
            "buduca_preporucena_kolicina": eligibility.buduca_preporucena_kolicina,
            "komisijska_akcija_aktivna": category == "ukljuciti",
            "komisijska_akcija_razlog": status_reason,
            "rucni_unos": override,
            "razlog_odstupanja": override.razlog if override else "",
            "status": status,
            "status_oznaka": status_label,
            "status_klasa": status_class,
            "status_razlog": status_reason,
            "commission_eligibility": eligibility,
            "trenutna_komisija": eligibility.trenutna_komisija,
            "eligibility_status": eligibility.status,
            "eligibility_status_oznaka": eligibility.status_label,
            "posljednja_sigurna_komisija": eligibility.posljednja_sigurna_komisija,
            "planirati_za_komisiju": recommended_commission_window,
            "moze_preskociti_trenutnu": eligibility.moze_preskociti_trenutnu,
            "novi_pacijent_workflow": workflow_code,
            "workflow_state": workflow_state.code,
            "workflow_state_oznaka": workflow_state.label,
            "terapijska_faza": (
                phased_configuration.phase_label
                if phased_configuration is not None else patient.terapijska_faza()
            ),
            "propisana_pocetna_doza_mg": (
                phased_configuration.prescribed_dose_mg
                if phased_configuration is not None else None
            ),
            "ukljucen_u_nacrt": included_in_draft,
            "eligible_for_current_cycle": eligible_for_current_cycle,
            "proposed_procurement_units": proposed_procurement_units,
            "final_procurement_units": final_procurement_units,
            "included_in_draft": included_in_draft,
            "vanredni_zahtjev_u_toku": extraordinary_in_progress,
            "za_pregled": requires_review,
            # Zadržano samo kao neutralna kompatibilnost za starije integracije.
            # Komisijski workflow više ne čita niti prikazuje dokumentaciju.
            "dokumentacija_kompletna": True,
            "dokumentacija_oznaka": "",
            "blokira_predaju": False,
            "rizik_dostave": has_delivery_risk,
            "relativna_pocetna_projekcija": relative_initial_projection,
            "sljedeci_korak": next_action,
            "rok_propusten": eligibility.rok_propusten,
            "ukupan_deficit_do_sljedece_isporuke": (
                eligibility.ukupan_deficit_do_sljedece_isporuke
            ),
            "hitna_kolicina_prije_isporuke": (
                eligibility.hitna_kolicina_prije_isporuke
            ),
            "ima_stvarno_zakazanu_buducu_terapiju": (
                has_scheduled_future_therapy
            ),
            "kolicina_za_sljedecu_komisiju": (
                eligibility.kolicina_za_sljedecu_komisiju
            ),
            "obracun_jedinica": _quantity_breakdown(
                patient,
                demand,
                system_suggestion,
            ),
            "prikaz_nabavke": procurement_display,
            "sistemska_nabavka": system_procurement,
            "osnovna_nabavka": base_procurement,
            "rezervna_nabavka": reserve_procurement,
            "konacna_nabavka": final_procurement,
            "nabavka_komisije": draft_procurement,
            "broj_terapija_za_komisiju": procurement_display["broj_terapija"],
            "jedinica_nabavke": procurement_display["jedinica_mnozina"],
            "kategorija": category,
            "ukupno_potrebno": demand.ukupna_potrebna_kolicina,
            "vec_pokriveno": total_covered,
            "trenutno_dostupno": total_covered,
            "neto_nedostatak": demand.neto_nedostatak,
            "broj_pakovanja": draft_procurement["package_count"],
            "velicina_pakovanja": draft_procurement["units_per_package"],
            "poruka_validacije_pakovanja": package_multiple_error(
                patient.lijek,
                label="Konačna količina",
            ),
            "detalji": display_details,
            "_projekcija_zalihe_detalji": eligibility_demand.detalji,
            "coverage": coverage,
            "fizicka_zaliha_semantika": (
                {
                    "fizicki_slobodno_u_kabinetu": (
                        home_projection.free_fridge_quantity
                        if home_projection is not None else Decimal("0")
                    ),
                    "fizicki_dodijeljeno_pacijentu": (
                        home_projection.fridge_quantity
                        if home_projection is not None else Decimal("0")
                    ),
                    "smanjuje_komisijski_zahtjev": False,
                    "objasnjenje": (
                        "Slobodna zaliha može pokriti dozu tek nakon što je "
                        "sestra dodijeli ovom pacijentu. Do tada ne produžava "
                        "datum sigurnog pokrića niti umanjuje količinu koju "
                        "treba planirati."
                    ),
                }
                if home_therapy_step
                else None
            ),
            "odobreno_ceka_isporuku_uslovno": (
                demand.kolicina_odobrena_nedostavljena_rasporedjena > 0
            ),
            "odobreno_ceka_isporuku_napomena": (
                "Najavljena isporuka pokriva: "
                f"{demand.kolicina_odobrena_nedostavljena_rasporedjena:g} "
                f"{patient.lijek.jedinica_za_kolicinu(demand.kolicina_odobrena_nedostavljena_rasporedjena)} "
                "pod uslovom da stignu najkasnije "
                f"{approved_delivery_date:%d/%m/%Y}."
                if incoming_covered_details and approved_delivery_date
                else ""
            ),
            "odobreno_preostalo": demand.neiskoristene_odobrene_doze,
            "odobreno_preostalo_napomena": (
                "Ne računa se kao fizičko pokriće dok ne postoji potvrđena "
                "narudžba i datum isporuke."
                if demand.neiskoristene_odobrene_doze > 0
                else ""
            ),
            "odobreno_ceka_isporuku": demand.kolicina_odobrena_nedostavljena,
            "odobreno_ceka_isporuku_dostupno_od": approved_delivery_date,
            "incoming_pokrivene_terapije": incoming_covered_details,
            "planirani_koraci": (),
            "demand": demand,
            "logisticke_postavke": parameters,
        })
    rows = _annotate_stock_coverage(rows, today=today)
    needs_extended_outlook = any(
        row.get("ima_poznat_buduci_raspored")
        and (
            row.get("prva_fizicki_nepokrivena_terapija") is None
            or (
                row.get("odobreno_ceka_isporuku", 0) > 0
                and row.get("prva_planirano_nepokrivena_terapija") is None
            )
        )
        for row in rows
    )
    if not needs_extended_outlook:
        return _annotate_inventory_semantics(rows, today=today)

    # Duži horizont se računa samo kada je cijela prva godina zaista pokrivena.
    # Uobičajeni komisijski prikaz tako ostaje brz, a velika zaliha i dalje
    # dobija stvarni prvi datum umjesto generičke procjene “više od 90 dana”.
    extended_demands = calculate_patient_demands(
        patients,
        today=today,
        target_date=today + timedelta(days=3650),
    )
    for row in rows:
        extended = extended_demands.get(row["pacijent"].pk)
        row["_projekcija_zalihe_detalji"] = (
            extended.detalji if extended else ()
        )
    rows = _annotate_stock_coverage(rows, today=today)
    return _annotate_inventory_semantics(rows, today=today)


def commission_planning_row_for_patient(pacijent, *, today=None):
    return next(
        (row for row in commission_planning_rows(today=today) if row["pacijent"].pk == pacijent.pk),
        None,
    )


def _phase2_drafts_for_update(*, pacijent, medicine_ids):
    """Zaključavajući Phase 2 queryset bez ``DISTINCT``.

    Raniji JOIN preko ``stavke_lijeka`` zahtijevao je ``distinct()`` i na
    PostgreSQLu završavao kao nedozvoljeni ``SELECT DISTINCT ... FOR UPDATE``.
    ``Exists`` zadržava istu semantiku pripadnosti lijeku, ali vanjski SELECT
    ostaje nad osnovnim ``KomisijskiZahtjev`` redovima koje stvarno želimo
    zaključati.
    """

    matching_item = KomisijskaStavkaLijeka.objects.filter(
        komisijski_zahtjev_id=OuterRef("pk"),
        lijek_id__in=medicine_ids,
    )
    queryset = (
        KomisijskiZahtjev.objects.filter(
            pacijent=pacijent,
            status=KomisijskiZahtjev.Status.NACRT,
        )
        .annotate(_has_matching_medicine=Exists(matching_item))
        .filter(
            Q(_has_matching_medicine=True)
            | Q(novi_lijek_id__in=medicine_ids)
        )
        .select_related("komisijski_ciklus")
        .order_by("pk")
    )
    return select_for_update_self(queryset)


@transaction.atomic
def recalculate_patient_commission_drafts(
    pacijent,
    *,
    user=None,
    reason="Komisijski prijedlog preračunat nakon promjene fizičkog pokrića.",
    today=None,
):
    """Uskladi postojeće sistemske nacrte bez kreiranja novog zahtjeva.

    Fizička mutacija (izdavanje, povrat ili rezervacija) prvo se knjiži, a
    zatim ovaj servis ponovo poziva isti planner koji koriste karton i
    Komisijski centar. Ručno izmijenjena ljekarska količina ostaje sačuvana;
    automatski se mijenja samo nacrt čija je konačna količina još jednaka
    prethodnom sistemskom prijedlogu.
    """

    row = commission_planning_row_for_patient(pacijent, today=today)
    if not row or not row.get("lijek"):
        return {"updated": 0, "created": 0, "quantity": Decimal("0")}

    desired = max(
        Decimal("0"),
        Decimal(str(row.get("final_procurement_units") or 0)),
    )
    medicine = row.get("potreban_proizvod") or row["lijek"]
    medicine_ids = medicine.equivalent_ids()
    planned_window = (
        row.get("planirati_za_komisiju")
        or row.get("preporuceni_komisijski_ciklus")
    )
    planned_date = getattr(planned_window, "datum_komisije", None)

    phase2 = list(_phase2_drafts_for_update(
        pacijent=pacijent,
        medicine_ids=medicine_ids,
    ))
    if planned_date:
        matching = [
            draft for draft in phase2
            if draft.komisijski_ciklus.datum_komisije == planned_date
        ]
        if matching:
            phase2 = matching

    updated = 0
    for draft in phase2:
        previous_system = Decimal(str(draft.sistem_predlozio or 0))
        previous_final = Decimal(str(
            draft.finalna_kolicina
            if draft.finalna_kolicina is not None
            else draft.ljekar_trazi
            if draft.ljekar_trazi is not None
            else previous_system
        ))
        manually_adjusted = bool(
            draft.ljekar_trazi is not None
            and Decimal(str(draft.ljekar_trazi)) != previous_system
        )
        draft.sistem_predlozio = desired
        fields = ["sistem_predlozio"]
        if not manually_adjusted:
            draft.ljekar_trazi = desired
            draft.finalna_kolicina = desired
            draft.print_snapshot = {}
            draft.print_snapshot_at = None
            fields.extend([
                "ljekar_trazi",
                "finalna_kolicina",
                "print_snapshot",
                "print_snapshot_at",
            ])
            draft.stavke_lijeka.filter(
                lijek_id__in=medicine_ids,
            ).update(kolicina=desired)
        draft.save(update_fields=fields)
        if previous_system != desired or (
            not manually_adjusted and previous_final != desired
        ):
            cycle_date = draft.komisijski_ciklus.datum_komisije
            cycle_label = (
                f"Ciklus {cycle_date:%d/%m/%Y}; "
                if cycle_date is not None
                else f"Ciklus {draft.komisijski_ciklus.naziv} (datum nije evidentiran); "
            )
            upisi_log(
                user,
                "Komisijski prijedlog preračunat",
                pacijent=pacijent,
                objekat=draft,
                opis=(
                    f"{reason} {cycle_label}"
                    f"sistemski prijedlog {previous_system:g} → {desired:g}; "
                    + (
                        "ručna količina je sačuvana."
                        if manually_adjusted
                        else f"nacrt {previous_final:g} → {desired:g}."
                    )
                ),
            )
            updated += 1

    legacy_candidates = Trebovanje.objects.filter(
        pacijent=pacijent,
        lijek_id__in=medicine_ids,
        tip_zahtjeva=Trebovanje.TIP_REDOVNI,
        status__in=[
            "U_PRIPREMI",
            Trebovanje.STATUS_NACRT,
            Trebovanje.STATUS_SPREMAN,
        ],
    )
    if planned_date:
        matching_ids = list(
            legacy_candidates.filter(
                komisijski_ciklus__datum_komisije=planned_date,
            )
            .order_by()
            .values_list("pk", flat=True)
            .distinct()
        )
    else:
        matching_ids = []
    legacy_candidate_ids = matching_ids or list(
        legacy_candidates.order_by().values_list("pk", flat=True).distinct()
    )
    legacy_qs = select_for_update_self(
        Trebovanje.objects.filter(pk__in=legacy_candidate_ids).order_by("pk")
    )
    assert legacy_qs.query.distinct is False, str(legacy_qs.query)
    legacy = list(legacy_qs)
    for draft in legacy:
        previous_system = Decimal(str(draft.sistemski_prijedlog or 0))
        previous_final = Decimal(str(draft.broj_doza or 0))
        override = KomisijskiRucniUnos.objects.filter(
            pacijent=pacijent,
            lijek_id__in=medicine_ids,
            komisijski_ciklus=draft.komisijski_ciklus,
            rucni_override=True,
        ).first()
        draft.sistemski_prijedlog = desired
        fields = ["sistemski_prijedlog"]
        if override is None:
            draft.broj_doza = desired
            fields.append("broj_doza")
        draft.save(update_fields=fields)
        if previous_system != desired or (
            override is None and previous_final != desired
        ):
            upisi_log(
                user,
                "Komisijski prijedlog preračunat",
                pacijent=pacijent,
                objekat=draft,
                opis=(
                    f"{reason} Sistemski prijedlog {previous_system:g} → "
                    f"{desired:g}; "
                    + (
                        "ručna količina je sačuvana."
                        if override else f"nacrt {previous_final:g} → {desired:g}."
                    )
                ),
            )
            updated += 1

    return {"updated": updated, "created": 0, "quantity": desired, "row": row}


def commission_draft_snapshot(*, rows=None, today=None):
    """Kanonski zbir trenutnog redovnog komisijskog nacrta.

    Svi potrošači dobijaju iste konačne količine po pacijentu i terapijskoj
    grupi. Sistemski prijedlog ostaje zaseban podatak i nikada se ne sabira
    paralelno sa konačnom količinom.
    """

    rows = list(rows if rows is not None else commission_planning_rows(today=today))
    included = [
        row
        for row in rows
        if (
            row.get("included_in_draft", row.get("ukljucen_u_nacrt", False))
            and row.get(
                "eligible_for_current_cycle",
                row.get("ukljucen_u_nacrt", False),
            )
            and Decimal(str(row.get("final_procurement_units", 0) or 0)) > 0
        )
    ]
    groups = {}
    patient_quantities = {}
    for row in included:
        quantity = Decimal(str(row["final_procurement_units"] or 0))
        key = therapy_group_bucket_key(row["lijek"])
        group = groups.setdefault(
            key,
            {
                "key": key,
                "lijek": row["lijek"],
                "final_requested_quantity": Decimal("0"),
                "base_required_quantity": Decimal("0"),
                "safety_reserve_quantity": Decimal("0"),
                "patient_count": 0,
                "patient_ids": [],
                "patient_rows": [],
            },
        )
        group["final_requested_quantity"] += quantity
        group["base_required_quantity"] += Decimal(str(
            row.get("minimalno_potrebno", 0) or 0
        ))
        group["safety_reserve_quantity"] += Decimal(str(
            row.get("sigurnosna_rezerva", 0) or 0
        ))
        group["patient_count"] += 1
        group["patient_ids"].append(row["pacijent"].pk)
        group["patient_rows"].append({
            "pacijent": row["pacijent"],
            "final_requested_quantity": quantity,
            "base_required_quantity": Decimal(str(
                row.get("minimalno_potrebno", 0) or 0
            )),
            "safety_reserve_quantity": Decimal(str(
                row.get("sigurnosna_rezerva", 0) or 0
            )),
        })
        patient_quantities[(row["pacijent"].pk, key)] = quantity

    for group in groups.values():
        procurement = procurement_breakdown(
            group["final_requested_quantity"],
            group["lijek"],
        )
        group["procurement"] = procurement
        group["final_requested_quantity"] = procurement[
            "rounded_procurement_units"
        ]

    return {
        "rows": rows,
        "included_rows": included,
        "groups": groups,
        "patient_quantities": patient_quantities,
        "patient_count": len(included),
        "total_quantity": sum(
            (
                Decimal(str(row["final_procurement_units"] or 0))
                for row in included
            ),
            Decimal("0"),
        ),
    }


def commission_request_snapshot(requests):
    """Kanonski persisted prikaz jednog komisijskog nacrta/PDF skupa."""

    request_rows = list(requests)
    groups = {}
    patient_quantities = {}
    duplicates = []
    for request in request_rows:
        key = therapy_group_bucket_key(request.lijek)
        patient_key = (request.pacijent_id, key)
        quantity = Decimal(str(request.broj_doza or 0))
        if patient_key in patient_quantities:
            duplicates.append({
                "patient_id": request.pacijent_id,
                "medicine_group": key,
                "request_id": request.pk,
            })
        else:
            patient_quantities[patient_key] = quantity
        group = groups.setdefault(
            key,
            {
                "key": key,
                "lijek": request.lijek,
                "final_requested_quantity": Decimal("0"),
                "patient_count": 0,
                "request_ids": [],
            },
        )
        group["final_requested_quantity"] += quantity
        group["patient_count"] += 1
        group["request_ids"].append(request.pk)

    for group in groups.values():
        group["procurement"] = procurement_breakdown(
            group["final_requested_quantity"],
            group["lijek"],
        )

    return {
        "requests": request_rows,
        "groups": groups,
        "patient_quantities": patient_quantities,
        "duplicates": duplicates,
        "patient_count": len(patient_quantities),
        "total_quantity": sum(
            patient_quantities.values(),
            Decimal("0"),
        ),
    }


def validate_commission_request_snapshot(requests, expected_patient_quantities):
    snapshot = commission_request_snapshot(requests)
    expected = {
        key: Decimal(str(value or 0))
        for key, value in expected_patient_quantities.items()
    }
    if snapshot["duplicates"] or snapshot["patient_quantities"] != expected:
        raise ValidationError(
            "Greška integriteta komisijskog nacrta: konačne količine redova, "
            "sažetka i zahtjeva nisu jednake."
        )
    return snapshot


@transaction.atomic
def reconcile_stale_draft_membership(rows, *, user=None):
    """Ukloni samo zastarjelo članstvo, bez brisanja historijskih zahtjeva.

    Ručna odluka ostaje sačuvana, ali joj se osvježava sistemska osnova kako se
    isti prelaz sa pozitivnog prijedloga na nulu ne bi auditirao više puta.
    Nevezani nacrti koje je kreirao Komisijski centar se otkazuju, ne brišu.
    """

    reconciled = 0
    for row in rows:
        if row.get("included_in_draft"):
            continue
        current_system = Decimal(str(
            row.get("proposed_procurement_units", 0) or 0
        ))
        override = row.get("rucni_unos")
        stale_override = bool(
            override
            and Decimal(str(override.sistemski_prijedlog or 0)) > 0
            and current_system <= 0
        )
        stale_requests = list(
            Trebovanje.objects.select_for_update().filter(
                pacijent=row["pacijent"],
                lijek=row["lijek"],
                tip_zahtjeva=Trebovanje.TIP_REDOVNI,
                status="U_PRIPREMI",
                komisijski_ciklus__isnull=True,
                napomena__contains="Komisijski centar",
            )
        )
        if not stale_override and not stale_requests:
            continue

        if stale_override:
            previous_system = override.sistemski_prijedlog
            override.sistemski_prijedlog = current_system
            override.aktivan_nacrt = False
            override.save(update_fields=[
                "sistemski_prijedlog",
                "aktivan_nacrt",
                "izmijenjeno",
            ])
            upisi_log(
                user,
                "Pacijent uklonjen iz komisijskog nacrta",
                pacijent=row["pacijent"],
                objekat=override,
                opis=(
                    f"Sistemski prijedlog je promijenjen sa {previous_system} "
                    f"na {current_system}. Ručna vrijednost "
                    f"{override.ljekar_trazi} je sačuvana u audit tragu, ali "
                    "pacijent više nije podoban za aktivni ciklus."
                ),
            )
            reconciled += 1

        for request in stale_requests:
            request.status = Trebovanje.STATUS_OTKAZANO
            request.napomena = (
                f"{request.napomena}\n"
                "Automatski uklonjeno iz aktivnog nacrta nakon ponovnog "
                "obračuna: konačna količina za trenutni ciklus je 0."
            ).strip()
            request.save(update_fields=["status", "napomena"])
            upisi_log(
                user,
                "Zastarjeli komisijski nacrt uklonjen",
                pacijent=request.pacijent,
                objekat=request,
                opis=(
                    f"Zahtjev {request.pk} je otkazan bez brisanja jer je "
                    "ponovni obračun vratio 0 nabavnih jedinica."
                ),
            )
            reconciled += 1
    return reconciled


@transaction.atomic
def reconcile_active_commission_drafts(*, user=None, commit=True, today=None):
    """Idempotentno uskladi samo aktivne redovne persisted nacrte."""

    rows = commission_planning_rows(today=today)
    row_by_scope = {
        (row["pacijent"].pk, row["lijek"].pk): row for row in rows
    }
    requests = list(
        select_for_update_self(
            Trebovanje.objects.filter(
            tip_zahtjeva=Trebovanje.TIP_REDOVNI,
            status__in=[
                "U_PRIPREMI",
                Trebovanje.STATUS_NACRT,
                Trebovanje.STATUS_SPREMAN,
            ],
            komisijski_ciklus__status="SIMULACIJA",
            komisijski_ciklus__tip_ciklusa=KomisijskiCiklus.TIP_REDOVNI,
            ).select_related("pacijent", "lijek", "komisijski_ciklus")
        )
        .order_by(
            "pacijent_id",
            "lijek_id",
            "komisijski_ciklus_id",
            "-id",
        )
    )
    cycle_ids = {item.komisijski_ciklus_id for item in requests}
    explicit_overrides = {
        (item.pacijent_id, item.lijek_id, item.komisijski_ciklus_id): item
        for item in KomisijskiRucniUnos.objects.filter(
            komisijski_ciklus_id__in=cycle_ids,
            rucni_override=True,
        )
    }
    seen = set()
    report = {
        "active_requests": len(requests),
        "audited_legacy_overrides": 0,
        "updated_system_drafts": 0,
        "preserved_manual_overrides": 0,
        "closed_duplicates": 0,
        "unchanged": 0,
        "changes": [],
    }
    legacy_overrides = KomisijskiRucniUnos.objects.filter(
        aktivan_nacrt=False,
        rucni_override=False,
        komisijski_ciklus_id__isnull=False,
    ).select_related("pacijent", "komisijski_ciklus")
    for override in legacy_overrides:
        if override.ljekar_trazi == override.sistemski_prijedlog:
            continue
        already_audited = AktivnostLog.objects.filter(
            akcija="Naslijeđeni komisijski override arhiviran",
            objekat_tip=override.__class__.__name__,
            objekat_id=override.pk,
        ).exists()
        if already_audited:
            continue
        if commit:
            upisi_log(
                user,
                "Naslijeđeni komisijski override arhiviran",
                pacijent=override.pacijent,
                objekat=override,
                opis=(
                    f"Zapis je vezan za završeni ciklus "
                    f"{override.komisijski_ciklus_id} i više nije aktivni "
                    f"nacrt. Sačuvano: sistem {override.sistemski_prijedlog}, "
                    f"konačno {override.ljekar_trazi}."
                ),
            )
        report["audited_legacy_overrides"] += 1

    for request in requests:
        scope = (
            request.pacijent_id,
            request.lijek_id,
            request.komisijski_ciklus_id,
        )
        if scope in seen:
            before = Decimal(str(request.broj_doza or 0))
            request.status = Trebovanje.STATUS_OTKAZANO
            request.napomena = (
                f"{request.napomena or ''}\n"
                "Deaktiviran dupli aktivni nacrt tokom komisijskog "
                "reconciliationa."
            ).strip()
            if commit:
                request.save(update_fields=["status", "napomena"])
                upisi_log(
                    user,
                    "Dupli komisijski nacrt deaktiviran",
                    pacijent=request.pacijent,
                    objekat=request,
                    opis=(
                        f"Trebovanje {request.pk}, ciklus "
                        f"{request.komisijski_ciklus_id}, količina {before}."
                    ),
                )
            report["closed_duplicates"] += 1
            report["changes"].append({
                "request_id": request.pk,
                "patient_id": request.pacijent_id,
                "before": before,
                "after": Decimal("0"),
                "action": "duplicate_closed",
            })
            continue
        seen.add(scope)

        row = row_by_scope.get((request.pacijent_id, request.lijek_id))
        if row is None:
            report["unchanged"] += 1
            continue
        system_quantity = Decimal(str(row["sistem_predlaze"] or 0))
        explicit_override = explicit_overrides.get(scope)
        desired_quantity = (
            Decimal(str(explicit_override.ljekar_trazi or 0))
            if explicit_override else system_quantity
        )
        before = Decimal(str(request.broj_doza or 0))
        previous_system = Decimal(str(request.sistemski_prijedlog or 0))
        if explicit_override:
            report["preserved_manual_overrides"] += 1
        if before == desired_quantity and previous_system == system_quantity:
            report["unchanged"] += 1
            continue

        request.broj_doza = desired_quantity
        request.sistemski_prijedlog = system_quantity
        if commit:
            request.save(update_fields=["broj_doza", "sistemski_prijedlog"])
            upisi_log(
                user,
                "Komisijski nacrt usklađen",
                pacijent=request.pacijent,
                objekat=request,
                opis=(
                    f"Ciklus {request.komisijski_ciklus_id}: količina "
                    f"{before} → {desired_quantity}; sistemski prijedlog "
                    f"{previous_system} → {system_quantity}; "
                    f"{'ručni override sačuvan' if explicit_override else 'sistemski nacrt osvježen'}."
                ),
            )
        if not explicit_override:
            report["updated_system_drafts"] += 1
        report["changes"].append({
            "request_id": request.pk,
            "patient_id": request.pacijent_id,
            "before": before,
            "after": desired_quantity,
            "action": (
                "manual_override_preserved"
                if explicit_override else "system_draft_refreshed"
            ),
        })

    if not commit:
        transaction.set_rollback(True)
    return report


def delivery_risk_rows(rows):
    def arrival(row):
        return (
            row.get("ocekivani_datum_dolaska")
            or row.get("procijenjeni_datum_dolaska")
        )

    """Pacijenti kojima procijenjena dostava stiže nakon potrebne terapije."""
    return sorted(
        (
            row
            for row in rows
            if arrival(row)
            and row.get("rizicna_terapija")
            and arrival(row) > row["rizicna_terapija"]
        ),
        key=lambda row: (
            row["rizicna_terapija"],
            -(arrival(row) - row["rizicna_terapija"]).days,
            getattr(row["pacijent"], "pk", 0) or 0,
        ),
    )


def commission_patient_status_snapshot(*, rows=None, today=None):
    """Kanonske grupe pacijenata za KPI-je, filtere i statusne oznake.

    Snapshot ne računa novu poslovnu odluku: koristi ista V2 planiranja i isti
    nacrt koji već koriste Komisijski centar i njegovi zbirni prikazi.
    """

    rows = list(rows if rows is not None else commission_planning_rows(today=today))
    draft = commission_draft_snapshot(rows=rows, today=today)
    risk_rows = delivery_risk_rows(rows)
    row_by_patient_id = {
        row["pacijent"].pk: row
        for row in rows
        if getattr(row.get("pacijent"), "aktivan", False)
    }
    included_ids = {
        row["pacijent"].pk for row in draft["included_rows"]
    }
    delivery_risk_ids = {
        row["pacijent"].pk
        for row in risk_rows
        if getattr(row.get("pacijent"), "aktivan", False)
    }
    review_ids = {
        row["pacijent"].pk
        for row in rows
        if (
            getattr(row.get("pacijent"), "aktivan", False)
            and row.get("za_pregled")
        )
    }
    return {
        "rows": rows,
        "row_by_patient_id": row_by_patient_id,
        "included_ids": included_ids,
        "delivery_risk_ids": delivery_risk_ids,
        "review_ids": review_ids,
        "covered_ids": set(row_by_patient_id) - included_ids - review_ids,
    }


def commission_dashboard_summary(rows, *, today=None):
    today = today or timezone.localdate()
    review = [row for row in rows if row.get("za_pregled")]
    soon = [
        row
        for row in rows
        if not row.get("za_pregled")
        and row["status"] in {STATUS_PRATITI, STATUS_ZA_KOMISIJU}
    ]
    delivery_risks = delivery_risk_rows(rows)
    critical = [
        row
        for row in rows
        if (
            row.get("status") == STATUS_KRITICNO
            or row.get("rizik_dostave")
            or row.get("rok_propusten")
        )
    ]
    deadlines = [
        row["komisiju_pokrenuti_najkasnije"]
        for row in rows
        if row["komisiju_pokrenuti_najkasnije"] is not None
    ]
    future_deadlines = [deadline for deadline in deadlines if deadline >= today]
    overdue_deadlines = [deadline for deadline in deadlines if deadline < today]
    most_overdue = min(overdue_deadlines) if overdue_deadlines else None
    risk = delivery_risks[0] if delivery_risks else None
    risk_therapy = risk.get("rizicna_terapija") if risk else None
    risk_arrival = (
        (
            risk.get("ocekivani_datum_dolaska")
            or risk.get("procijenjeni_datum_dolaska")
        )
        if risk else None
    )
    return {
        "broj_uskoro": len(soon),
        "broj_za_pregled": len(review),
        "broj_kriticnih": len(critical),
        "broj_rizik_dostave": len(delivery_risks),
        "broj_ostalih_rizik_dostave": max(len(delivery_risks) - 1, 0),
        "rizici_dostave": delivery_risks,
        "najblizi_rok": min(future_deadlines) if future_deadlines else None,
        "rok_prekoracen": most_overdue,
        "dana_kasnjenja": (today - most_overdue).days if most_overdue else 0,
        "rizik": risk,
        "rizik_poruka": (
            f"Procijenjena dostava {risk_arrival:%d/%m/%Y} dolazi nakon "
            f"planirane terapije {risk_therapy:%d/%m/%Y}."
            if risk_arrival and risk_therapy
            else risk.get("status_razlog", "")
            if risk
            else ""
        ),
        "rizik_preporuka": (
            "Potrebno provjeriti postojeću zalihu ili raniju nabavku."
            if risk
            else ""
        ),
    }


@transaction.atomic
def save_commission_manual_override(
    *,
    pacijent,
    system_quantity,
    manual_quantity,
    reason,
    user,
    reason_code="",
    commission_cycle=None,
    decision_context=None,
):
    if not commission_demand_v2_enabled():
        raise ValidationError("Novi komisijski obračun nije uključen.")
    try:
        system_quantity = Decimal(str(system_quantity))
        manual_quantity = Decimal(str(manual_quantity))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValidationError("Količina mora biti ispravan broj doza.") from exc
    if system_quantity < 0 or manual_quantity < 0:
        raise ValidationError("Količina ne može biti negativna.")
    try:
        validate_package_multiple(
            manual_quantity,
            pacijent.lijek,
            label="Tražena količina",
        )
    except ValueError as exc:
        raise ValidationError(str(exc)) from exc
    reason = (reason or "").strip()
    if manual_quantity != system_quantity and not (reason or reason_code):
        raise ValidationError(
            "Razlog je obavezan kada tražena količina odstupa od sistemskog prijedloga."
        )
    from .models import AdaptiveDecisionRecord

    reason_labels = dict(AdaptiveDecisionRecord.OVERRIDE_REASONS)
    stored_reason = reason or reason_labels.get(reason_code, reason_code)

    authenticated_user = (
        user if getattr(user, "is_authenticated", False) else None
    )
    is_manual_override = manual_quantity != system_quantity
    if commission_cycle is not None:
        KomisijskiRucniUnos.objects.select_for_update().filter(
            pacijent=pacijent,
            lijek=pacijent.lijek,
            aktivan_nacrt=True,
        ).update(aktivan_nacrt=False)
        previous = KomisijskiRucniUnos.objects.select_for_update().filter(
            pacijent=pacijent,
            lijek=pacijent.lijek,
            komisijski_ciklus=commission_cycle,
        ).first()
        record, _ = KomisijskiRucniUnos.objects.update_or_create(
            pacijent=pacijent,
            lijek=pacijent.lijek,
            komisijski_ciklus=commission_cycle,
            defaults={
                "sistemski_prijedlog": system_quantity,
                "ljekar_trazi": manual_quantity,
                "razlog": stored_reason,
                "rucni_override": is_manual_override,
                "aktivan_nacrt": False,
                "korisnik": authenticated_user,
            },
        )
    else:
        previous = KomisijskiRucniUnos.objects.select_for_update().filter(
            pacijent=pacijent,
            lijek=pacijent.lijek,
            aktivan_nacrt=True,
            komisijski_ciklus__isnull=True,
        ).first()
        if previous:
            record = previous
            record.sistemski_prijedlog = system_quantity
            record.ljekar_trazi = manual_quantity
            record.razlog = stored_reason
            record.rucni_override = is_manual_override
            record.korisnik = authenticated_user
            record.save(update_fields=[
                "sistemski_prijedlog",
                "ljekar_trazi",
                "razlog",
                "rucni_override",
                "korisnik",
                "izmijenjeno",
            ])
        else:
            record = KomisijskiRucniUnos.objects.create(
                pacijent=pacijent,
                lijek=pacijent.lijek,
                sistemski_prijedlog=system_quantity,
                ljekar_trazi=manual_quantity,
                razlog=stored_reason,
                rucni_override=is_manual_override,
                aktivan_nacrt=True,
                korisnik=authenticated_user,
            )
    previous_text = (
        f"prethodno ljekar {previous.ljekar_trazi}, sistem {previous.sistemski_prijedlog}; "
        if previous
        else "prvi ručni unos; "
    )
    upisi_log(
        user,
        "Izmijenjena komisijska količina",
        pacijent=pacijent,
        objekat=record,
        opis=(
            f"{previous_text}sistem predlaže {system_quantity}, konačno je traženo "
            f"{manual_quantity}. Razlog: {stored_reason or 'nema odstupanja'}."
        ),
    )
    if decision_context:
        from .adaptive_assistant import observe_commission_decision_safely

        observe_commission_decision_safely(
            row=decision_context,
            final_quantity=manual_quantity,
            user=user,
            reason_code=reason_code,
            note=reason,
            commission_cycle=commission_cycle,
        )
    return record
