from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0031_postavke_pg_dump_path"),
    ]

    operations = [
        migrations.AddField(
            model_name="terapija",
            name="is_migration",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="postavkesistema",
            name="migracija_zakljucana",
            field=models.BooleanField(default=False),
        ),
    ]
