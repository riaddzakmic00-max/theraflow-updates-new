from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("patients", "0040_pacijentrezervacija"),
    ]

    operations = [
        migrations.CreateModel(
            name="ZalihaTransakcija",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("tip", models.CharField(choices=[("ZAPRIMANJE", "Zaprimanje"), ("AMBULANTNA_POTROSNJA", "Ambulantna potrosnja"), ("KUCNO_IZDAVANJE", "Kucno izdavanje"), ("POVRAT", "Povrat"), ("OTPIS", "Otpis"), ("KOREKCIJA", "Korekcija")], max_length=30)),
                ("kolicina", models.DecimalField(decimal_places=2, max_digits=8)),
                ("datum", models.DateField(default=django.utils.timezone.localdate)),
                ("referenca_tip", models.CharField(blank=True, max_length=100)),
                ("referenca_id", models.PositiveIntegerField(blank=True, null=True)),
                ("napomena", models.TextField(blank=True)),
                ("kreirano", models.DateTimeField(auto_now_add=True)),
                ("komisija", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="zaliha_transakcije", to="patients.komisija")),
                ("korisnik", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
                ("lijek", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="zaliha_transakcije", to="patients.lijek")),
                ("pacijent", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="zaliha_transakcije", to="patients.pacijent")),
            ],
            options={
                "verbose_name": "Transakcija zalihe",
                "verbose_name_plural": "Transakcije zaliha",
                "ordering": ["datum", "id"],
            },
        ),
    ]
