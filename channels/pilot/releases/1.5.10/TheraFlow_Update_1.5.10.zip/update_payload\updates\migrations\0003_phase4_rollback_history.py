from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ("updates", "0002_phase3_install_state"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AlterField(
            model_name="updatesession", name="status",
            field=models.CharField(default="package_downloaded", max_length=48),
        ),
        migrations.CreateModel(
            name="UpdateHistory",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("source_version", models.CharField(max_length=50)),
                ("target_version", models.CharField(max_length=50)),
                ("started_at", models.DateTimeField(blank=True, null=True)),
                ("completed_at", models.DateTimeField(blank=True, null=True)),
                ("status", models.CharField(choices=[("successful", "Uspješno"), ("failed_before_install", "Neuspješno prije instalacije"), ("failed_rolled_back", "Neuspješno · prethodna verzija vraćena"), ("failed_manual_recovery", "Potrebna ručna intervencija"), ("cancelled", "Otkazano"), ("rollback_successful", "Rollback uspješan"), ("rollback_failed", "Rollback neuspješan")], max_length=32)),
                ("mandatory", models.BooleanField(default=False)),
                ("package_sha256", models.CharField(blank=True, max_length=64)),
                ("backup_created", models.BooleanField(default=False)),
                ("backup_validated", models.BooleanField(default=False)),
                ("files_installed", models.BooleanField(default=False)),
                ("migrations_executed", models.BooleanField(default=False)),
                ("health_check_result", models.CharField(blank=True, max_length=64)),
                ("rollback_executed", models.BooleanField(default=False)),
                ("rollback_type", models.CharField(blank=True, max_length=20)),
                ("rollback_result", models.CharField(blank=True, max_length=64)),
                ("final_active_version", models.CharField(blank=True, max_length=50)),
                ("duration_seconds", models.PositiveIntegerField(blank=True, null=True)),
                ("safe_error_summary", models.TextField(blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("initiated_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="update_history", to=settings.AUTH_USER_MODEL)),
                ("session", models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="history", to="updates.updatesession")),
            ],
            options={"ordering": ("-started_at", "-created_at")},
        ),
    ]
