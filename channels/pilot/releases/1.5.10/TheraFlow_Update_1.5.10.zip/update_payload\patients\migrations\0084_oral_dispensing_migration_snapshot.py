from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0083_canonical_therapy_phases"),
    ]

    operations = [
        migrations.AddField(
            model_name="izdavanjeoralneterapije",
            name="is_migration_snapshot",
            field=models.BooleanField(
                default=False,
                help_text=(
                    "Historijsko izdavanje uneseno migracijom; nema retroaktivni "
                    "efekat na trenutnu zalihu ni komisijsko pravo."
                ),
            ),
        ),
        migrations.RemoveConstraint(
            model_name="izdavanjeoralneterapije",
            name="oral_issue_one_approval_source",
        ),
        migrations.AddConstraint(
            model_name="izdavanjeoralneterapije",
            constraint=models.CheckConstraint(
                condition=(
                    (
                        models.Q(komisija__isnull=False)
                        & models.Q(komisijska_stavka__isnull=True)
                    )
                    | (
                        models.Q(komisija__isnull=True)
                        & models.Q(komisijska_stavka__isnull=False)
                    )
                    | models.Q(
                        is_migration_snapshot=True,
                        komisija__isnull=True,
                        komisijska_stavka__isnull=True,
                    )
                ),
                name="oral_issue_one_approval_source",
            ),
        ),
    ]
