import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


def populate_ustekinumab_presentations(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    for lijek in Lijek.objects.all():
        identity = " ".join(
            filter(
                None,
                (lijek.naziv, lijek.genericki_naziv, lijek.zasticeno_ime),
            )
        ).casefold()
        if not any(
            token in identity
            for token in ("ustekinumab", "stelara", "uzpruvo", "upruva")
        ):
            continue
        update_fields = []
        if "130" in identity:
            lijek.jacina_mg = 130
            lijek.put_primjene = "IV"
            update_fields = ["jacina_mg", "put_primjene"]
        elif "90" in identity:
            lijek.jacina_mg = 90
            lijek.put_primjene = "SC"
            update_fields = ["jacina_mg", "put_primjene"]
        if update_fields:
            lijek.save(update_fields=update_fields)


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0077_alter_komisijskasaglasnost_broj_saglasnosti"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AddField(
            model_name="lijek",
            name="jacina_mg",
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                max_digits=8,
                null=True,
                verbose_name="Jačina prezentacije (mg)",
            ),
        ),
        migrations.AddField(
            model_name="lijek",
            name="put_primjene",
            field=models.CharField(
                blank=True,
                choices=[
                    ("IV", "Intravenozno (IV)"),
                    ("SC", "Supkutano (SC)"),
                ],
                max_length=8,
                verbose_name="Put primjene",
            ),
        ),
        migrations.AddField(
            model_name="terapija",
            name="tezina_izmjerena_at_snapshot",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="terapija",
            name="tezina_kg_snapshot",
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                max_digits=6,
                null=True,
            ),
        ),
        migrations.CreateModel(
            name="FazniProtokolPacijenta",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "protokol_kljuc",
                    models.CharField(default="ustekinumab", max_length=40),
                ),
                (
                    "faza",
                    models.CharField(
                        choices=[
                            ("CEKA_IV_INDUKCIJU", "Čeka IV indukciju"),
                            (
                                "CEKA_PRVU_SC",
                                "IV završena / čeka prvu SC dozu",
                            ),
                            ("ODRZAVANJE", "SC održavanje"),
                        ],
                        default="CEKA_IV_INDUKCIJU",
                        max_length=32,
                    ),
                ),
                (
                    "tezina_kg",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=6,
                        null=True,
                    ),
                ),
                (
                    "tezina_izmjerena_at",
                    models.DateTimeField(blank=True, null=True),
                ),
                (
                    "indukcijska_doza_mg",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=8,
                        null=True,
                    ),
                ),
                (
                    "indukcijski_broj_jedinica",
                    models.PositiveSmallIntegerField(blank=True, null=True),
                ),
                (
                    "interval_odrzavanja_sedmica",
                    models.PositiveSmallIntegerField(
                        choices=[(8, "8 sedmica"), (12, "12 sedmica")],
                        default=8,
                    ),
                ),
                ("datum_iv_primjene", models.DateField(blank=True, null=True)),
                (
                    "datum_prve_sc_primjene",
                    models.DateField(blank=True, null=True),
                ),
                (
                    "datum_posljednje_primjene",
                    models.DateField(blank=True, null=True),
                ),
                ("sljedeci_datum", models.DateField(blank=True, null=True)),
                ("aktivan", models.BooleanField(default=True)),
                ("kreirano", models.DateTimeField(auto_now_add=True)),
                ("izmijenjeno", models.DateTimeField(auto_now=True)),
                (
                    "iv_lijek",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="fazni_protokoli_iv",
                        to="patients.lijek",
                    ),
                ),
                (
                    "sc_lijek",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="fazni_protokoli_sc",
                        to="patients.lijek",
                    ),
                ),
                (
                    "pacijent",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="fazni_protokol",
                        to="patients.pacijent",
                    ),
                ),
                (
                    "pocetni_komisijski_zahtjev",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="pokrenuti_fazni_protokoli",
                        to="patients.komisijskizahtjev",
                    ),
                ),
                (
                    "kreirao",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="kreirani_fazni_protokoli",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "izmijenio",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="izmijenjeni_fazni_protokoli",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "verbose_name": "Fazni protokol pacijenta",
                "verbose_name_plural": "Fazni protokoli pacijenata",
                "constraints": [
                    models.CheckConstraint(
                        condition=(
                            models.Q(tezina_kg__isnull=True)
                            | models.Q(tezina_kg__gt=0)
                        ),
                        name="fazni_protokol_tezina_pozitivna",
                    ),
                    models.CheckConstraint(
                        condition=models.Q(
                            interval_odrzavanja_sedmica__in=(8, 12)
                        ),
                        name="fazni_protokol_interval_8_ili_12",
                    ),
                ],
            },
        ),
        migrations.RunPython(
            populate_ustekinumab_presentations,
            migrations.RunPython.noop,
        ),
    ]
