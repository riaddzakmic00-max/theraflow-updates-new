from django.db import migrations
from django.db.models import Q


ADALIMUMAB_BRANDS = ("Hyrimoz",)


def enable_hyrimoz_whole_package_dispensing(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    hyrimoz = (
        Q(zasticeno_ime__in=ADALIMUMAB_BRANDS)
        | Q(naziv__iexact="Hyrimoz")
        | Q(naziv__icontains="Hyrimoz")
    )
    Lijek.objects.filter(hyrimoz).update(
        package_size_in_doses=2,
        izdavanje_cijelih_pakovanja=True,
    )


class Migration(migrations.Migration):
    dependencies = [("patients", "0092_normalize_hyrimoz_home_capability")]

    operations = [
        migrations.RunPython(
            enable_hyrimoz_whole_package_dispensing,
            migrations.RunPython.noop,
        ),
    ]
