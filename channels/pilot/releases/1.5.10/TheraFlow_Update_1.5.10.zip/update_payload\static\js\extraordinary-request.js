(() => {
    const dialog = document.getElementById("extraordinary-request-dialog");
    if (!dialog) return;

    let trigger = null;

    function openDialog(opener) {
        trigger = opener || null;
        if (typeof dialog.showModal === "function") {
            dialog.showModal();
        } else {
            dialog.setAttribute("open", "");
        }
        requestAnimationFrame(() => {
            dialog.querySelector("select:not([disabled]), button[data-extraordinary-close]")?.focus({
                preventScroll: true,
            });
        });
    }

    function closeDialog() {
        if (typeof dialog.close === "function") {
            dialog.close();
        } else {
            dialog.removeAttribute("open");
            trigger?.focus({ preventScroll: true });
        }
    }

    document.querySelectorAll("[data-extraordinary-open]").forEach((button) => {
        button.addEventListener("click", () => openDialog(button));
    });
    dialog.querySelectorAll("[data-extraordinary-close]").forEach((button) => {
        button.addEventListener("click", closeDialog);
    });
    dialog.addEventListener("click", (event) => {
        if (event.target === dialog) closeDialog();
    });
    dialog.addEventListener("close", () => {
        trigger?.focus({ preventScroll: true });
        trigger = null;
    });

    const reason = dialog.querySelector("[data-extraordinary-reason]");
    const other = dialog.querySelector("[data-extraordinary-other]");
    const otherInput = other?.querySelector("textarea");

    function updateOtherReason() {
        if (!reason || !other || !otherInput) return;
        const visible = reason.value === "DRUGI";
        other.hidden = !visible;
        otherInput.required = visible;
        if (!visible) otherInput.value = "";
    }
    reason?.addEventListener("change", updateOtherReason);
    updateOtherReason();

    const params = new URLSearchParams(window.location.search);
    if (params.get("otvori_vanredni") === "1") {
        openDialog(document.querySelector("[data-extraordinary-open]"));
    }
})();
