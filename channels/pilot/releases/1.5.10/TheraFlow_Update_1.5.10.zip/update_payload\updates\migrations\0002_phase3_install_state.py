from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [("updates", "0001_initial"), migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.AddField(model_name="updatesession", name="install_plan_sha256", field=models.CharField(blank=True, max_length=64)),
        migrations.AddField(model_name="updatesession", name="install_started_at", field=models.DateTimeField(blank=True, null=True)),
        migrations.AddField(model_name="updatesession", name="install_completed_at", field=models.DateTimeField(blank=True, null=True)),
        migrations.AddField(model_name="updatesession", name="updater_pid", field=models.PositiveIntegerField(blank=True, null=True)),
        migrations.AddField(model_name="updatesession", name="install_started_by", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="started_updates", to=settings.AUTH_USER_MODEL)),
        migrations.AlterField(model_name="updatesession", name="status", field=models.CharField(default="package_downloaded", max_length=32)),
    ]
