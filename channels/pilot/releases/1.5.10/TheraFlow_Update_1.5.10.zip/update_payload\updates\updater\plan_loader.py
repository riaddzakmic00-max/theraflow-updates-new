import hashlib
import json
import re
from pathlib import Path, PurePosixPath, PureWindowsPath

from packaging.requirements import InvalidRequirement, Requirement
from packaging.utils import canonicalize_name


REQUIRED_FIELDS = {
    "session_id", "current_version", "target_version", "application_root", "staging_root",
    "payload_root", "backup_root", "database_backup_path", "config_backup_path",
    "preserve_paths", "replace_paths", "delete_paths", "migration_required",
    "collectstatic_required", "service_name", "health_check_url", "created_at",
    "package_sha256", "package_manifest_sha256", "python_executable", "canonical_env_path",
}


class PlanValidationError(RuntimeError):
    pass


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_local(path, label):
    path = Path(path)
    if not path.is_absolute() or str(path).startswith("\\\\"):
        raise PlanValidationError(f"{label} nije dozvoljena lokalna apsolutna putanja.")
    return path.resolve()


def child(path, parent, label):
    path, parent = safe_local(path, label), safe_local(parent, label)
    if path == parent or parent not in path.parents:
        raise PlanValidationError(f"{label} izlazi iz dozvoljenog direktorija.")
    return path


def safe_relative(value, label):
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise PlanValidationError(f"Neispravna {label}.")
    posix, windows = PurePosixPath(value), PureWindowsPath(value)
    if posix.is_absolute() or windows.is_absolute() or windows.drive or ".." in posix.parts:
        raise PlanValidationError(f"Neispravna {label}.")
    return posix


def read_version(path):
    match = re.search(r"__version__\s*=\s*['\"]([^'\"]+)['\"]", Path(path).read_text(encoding="utf-8"))
    if not match:
        raise PlanValidationError("version.py nema validnu verziju.")
    return match.group(1)


def _json(path, label):
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError) as exc:
        raise PlanValidationError(f"{label} nije validan JSON.") from exc
    if not isinstance(value, dict):
        raise PlanValidationError(f"{label} nije JSON objekat.")
    return value


def load_and_validate(plan_path, rollback=False):
    plan_path = safe_local(plan_path, "Install plan")
    plan = _json(plan_path, "Install plan")
    if REQUIRED_FIELDS - plan.keys():
        raise PlanValidationError("Install plan nema sva obavezna polja.")
    session_root = plan_path.parent
    sessions_root = session_root.parent
    data_root = sessions_root.parent.parent
    canonical_env = safe_local(plan["canonical_env_path"], "Canonical env")
    if canonical_env != (data_root / "config" / ".env").resolve():
        raise PlanValidationError("Canonical env putanja nije očekivana ProgramData konfiguracija.")
    state_path = sessions_root / f"{plan['session_id']}.json"
    state = _json(state_path, "Update state")
    if state.get("session_id") != plan["session_id"] or session_root.name != plan["session_id"]:
        raise PlanValidationError("Session identitet se ne podudara.")
    if state.get("install_plan_sha256") != sha256_file(plan_path):
        raise PlanValidationError("Install plan je izmijenjen nakon pripreme.")
    app = safe_local(plan["application_root"], "Application root")
    if str(app) != str(Path(state.get("application_root", "")).resolve()) or not (app / "manage.py").is_file():
        raise PlanValidationError("Application root nije očekivana instalacija.")
    staging = child(plan["staging_root"], data_root / "updates" / "staging", "Staging root")
    payload = child(plan["payload_root"], staging, "Payload root")
    backup = child(plan["backup_root"], data_root / "backups" / "updates", "Backup root")
    if not payload.is_dir() or not backup.is_dir():
        raise PlanValidationError("Staging ili backup direktorij ne postoji.")
    if state.get("service_name") != plan["service_name"] or state.get("health_check_url") != plan["health_check_url"]:
        raise PlanValidationError("Servisna konfiguracija se ne podudara.")
    current_version = read_version(app / "theraflow" / "version.py")
    target_version = read_version(payload / "theraflow" / "version.py")
    package_manifest_path = staging / "theraflow-update.json"
    package_manifest = _json(package_manifest_path, "Package manifest")
    allowed_current = {plan["current_version"], plan["target_version"]} if rollback else {plan["current_version"]}
    if current_version not in allowed_current or target_version != plan["target_version"] or str(package_manifest.get("version")) != plan["target_version"]:
        raise PlanValidationError("Verzije install plana, aplikacije i staginga se ne podudaraju.")
    if sha256_file(package_manifest_path) != plan["package_manifest_sha256"]:
        raise PlanValidationError("Package manifest SHA-256 nije ispravan.")
    package_path = safe_local(state.get("package_path", ""), "Update paket")
    if package_path.parent != data_root / "updates" / "packages" or not package_path.is_file() or sha256_file(package_path) != plan["package_sha256"]:
        raise PlanValidationError("Update paket SHA-256 nije ispravan.")
    db_path = safe_local(plan["database_backup_path"], "Database backup")
    config_path = safe_local(plan["config_backup_path"], "Config backup")
    metadata = _json(backup / "backup_metadata.json", "Backup metadata")
    if not db_path.is_file() or metadata.get("validation") != "pg_restore_list_passed" or sha256_file(db_path) != metadata.get("dump_sha256"):
        raise PlanValidationError("Database backup nije validiran.")
    if not config_path.is_file():
        raise PlanValidationError("Config backup nije pronađen.")
    for key in ("preserve_paths", "replace_paths", "delete_paths"):
        if not isinstance(plan[key], list):
            raise PlanValidationError(f"{key} mora biti lista.")
        plan[key] = [str(safe_relative(item, key)) for item in plan[key]]
    python = safe_local(plan["python_executable"], "Python runtime")
    if not python.is_file():
        raise PlanValidationError("Python runtime nije pronađen.")
    plan.update({"_plan_path": str(plan_path), "_state_path": str(state_path), "_data_root": str(data_root), "_package_path": str(package_path)})
    return plan, state


def _dependency_snapshot(path):
    path = Path(path)
    snapshot = {
        "path": str(path),
        "exists": path.is_file(),
        "raw_sha256": None,
        "fingerprint": None,
        "packages": {},
        "errors": [],
    }
    if not snapshot["exists"]:
        return snapshot

    snapshot["raw_sha256"] = sha256_file(path)
    try:
        text = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        snapshot["errors"].append(f"requirements se ne može pročitati: {type(exc).__name__}")
        return snapshot

    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            requirement = Requirement(line)
        except InvalidRequirement:
            snapshot["errors"].append(f"neispravna stavka u redu {line_number}")
            continue
        name = canonicalize_name(requirement.name)
        normalized = {
            "extras": sorted(canonicalize_name(extra) for extra in requirement.extras),
            "specifier": sorted(str(item) for item in requirement.specifier),
            "marker": str(requirement.marker) if requirement.marker else "",
            "url": requirement.url or "",
        }
        if name in snapshot["packages"]:
            snapshot["errors"].append(f"dupla zavisnost: {name}")
            continue
        snapshot["packages"][name] = normalized

    canonical = json.dumps(
        snapshot["packages"],
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    snapshot["fingerprint"] = hashlib.sha256(canonical).hexdigest()
    return snapshot


def _offline_dependency_details(plan):
    root = Path(plan["payload_root"]) / "offline_dependencies"
    wheels = sorted(root.glob("*.whl")) if root.is_dir() else []
    entries = [f"{wheel.name}:{sha256_file(wheel)}" for wheel in wheels]
    fingerprint = hashlib.sha256("\n".join(entries).encode("utf-8")).hexdigest() if entries else None
    return {
        "expected_path": str(root),
        "exists": root.is_dir(),
        "wheel_count": len(wheels),
        "sha256": fingerprint,
    }


def dependency_diagnostics(plan):
    current = _dependency_snapshot(Path(plan["application_root"]) / "requirements.txt")
    target = _dependency_snapshot(Path(plan["payload_root"]) / "requirements.txt")
    current_packages = current["packages"]
    target_packages = target["packages"]
    added = sorted(set(target_packages) - set(current_packages))
    removed = sorted(set(current_packages) - set(target_packages))
    changed = sorted(
        name
        for name in set(current_packages) & set(target_packages)
        if current_packages[name] != target_packages[name]
    )
    offline = _offline_dependency_details(plan)

    if not target["exists"]:
        supported = True
        reason = "Update payload ne mijenja requirements.txt."
    elif not current["exists"]:
        supported = False
        reason = "Instalirani requirements.txt nije pronađen."
    elif current["errors"] or target["errors"]:
        supported = False
        reason = "Dependency fajl nije moguće sigurno normalizovati."
    elif not added and not removed and not changed:
        supported = True
        reason = (
            "Python zavisnosti su semantički identične; razlika u kodiranju "
            "ili završecima redova se ignoriše."
        )
    else:
        supported = False
        reason = (
            "Stvarna promjena Python zavisnosti je pronađena, a ovaj updater "
            "nema validiran offline dependency install plan."
        )

    return {
        "supported": supported,
        "reason": reason,
        "current": current,
        "target": target,
        "added": added,
        "removed": removed,
        "changed": changed,
        "offline": offline,
    }


def dependencies_supported(plan):
    return dependency_diagnostics(plan)["supported"]


def validate_database_backup(plan):
    backup = Path(plan["backup_root"])
    db_path = Path(plan["database_backup_path"])
    metadata = _json(backup / "backup_metadata.json", "Backup metadata")
    if not db_path.is_file() or metadata.get("validation") != "pg_restore_list_passed" or sha256_file(db_path) != metadata.get("dump_sha256"):
        raise PlanValidationError("Database backup više nije validan.")
    return True
