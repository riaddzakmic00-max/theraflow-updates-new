from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0094_hyrimoz_single_pen_dispensing"),
    ]

    operations = [
        migrations.AddField(
            model_name="pacijentsaglasnost",
            name="izvorna_komisija",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="saglasnosti_pacijenata",
                to="patients.komisija",
            ),
        ),
    ]
