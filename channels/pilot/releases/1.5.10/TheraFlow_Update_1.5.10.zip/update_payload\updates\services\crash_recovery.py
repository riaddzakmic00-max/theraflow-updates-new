import os

from django.utils import timezone

from updates.models import UpdateSession
from updates.updater.state_writer import read_state, write_state

from .update_history import sync_history
from .update_paths import get_update_paths


TERMINAL = {
    "update_completed",
    "rollback_completed",
    "manual_recovery_required",
    "dry_run_completed",
    "install_failed",
    "validation_failed",
    "dependency_update_unsupported",
    "service_stop_failed",
    "snapshot_failed",
    "backup_failed",
    "staging_failed",
    "interrupted",
    "updater_service_failed",
}


def _clear_owned_locks(session):
    for name in ("install.lock", "rollback.lock"):
        lock = get_update_paths().sessions / name
        try:
            if lock.is_file() and lock.read_text(encoding="utf-8").strip() == str(
                session.pk
            ):
                lock.unlink()
        except OSError:
            pass


def pid_alive(pid):
    if not pid:
        return False
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, ValueError, TypeError):
        return False


def reconcile_session(session):
    path = get_update_paths().sessions / f"{session.pk}.json"
    try:
        state = read_state(path)
    except Exception:
        return None

    if state.get("status") in TERMINAL:
        session.status = str(state["status"])[:48]
        if session.status in {
            UpdateSession.UPDATE_COMPLETED,
            UpdateSession.ROLLBACK_COMPLETED,
            UpdateSession.INSTALL_FAILED,
            UpdateSession.VALIDATION_FAILED,
            UpdateSession.DEPENDENCY_UNSUPPORTED,
            UpdateSession.SERVICE_STOP_FAILED,
            UpdateSession.SNAPSHOT_FAILED,
            UpdateSession.BACKUP_FAILED,
            UpdateSession.STAGING_FAILED,
            UpdateSession.INTERRUPTED,
            "updater_service_failed",
        }:
            session.is_active = False
        session.save(update_fields=["status", "is_active", "updated_at"])
        if session.status in {
            UpdateSession.UPDATE_COMPLETED,
            UpdateSession.ROLLBACK_COMPLETED,
        }:
            _clear_owned_locks(session)
        sync_history(session, state)
        return state

    if pid_alive(state.get("updater_pid") or session.updater_pid):
        return state

    active_steps = {
        UpdateSession.INSTALL_STARTING,
        "validating_plan",
        "plan_validated",
        "service_stopping",
        "service_stopped",
        "creating_snapshot",
        "snapshot_completed",
        "files_installing",
        "files_installed",
        "django_check_running",
        "django_check_passed",
        "migrations_running",
        "migrations_completed",
        "collectstatic_running",
        "collectstatic_completed",
        "service_starting",
        "service_running",
        "health_check_running",
        "health_check_passed",
        "finalizing",
        "rollback_starting",
        "rollback_validating",
        "rollback_service_stopping",
        "rollback_files_restoring",
        "rollback_config_restoring",
        "rollback_database_backing_up",
        "rollback_database_restoring",
        "rollback_application_check",
        "rollback_service_starting",
        "rollback_health_check",
    }
    if state.get("status") not in active_steps:
        return state

    completed_at = timezone.now().isoformat()
    failed_step = state.get("last_attempted_step") or state.get("status") or "unknown"
    if state.get("rollback_started_at"):
        state = write_state(
            path,
            status="manual_recovery_required",
            current_step="Rollback je prekinut; potrebna je administratorska provjera",
            error_code="rollback_interrupted",
            error_message=f"Rollback proces je prekinut tokom koraka: {failed_step}.",
            rollback_error_code="rollback_interrupted",
            rollback_error_message=f"Rollback proces je prekinut tokom koraka: {failed_step}.",
            manual_action_required=True,
            completed_at=completed_at,
            step_completed_at=completed_at,
            failed_step=failed_step,
        )
    elif state.get("files_changed") and not state.get("rollback_started_at"):
        # Target version.py sam nije dovoljan dokaz uspjeha. Migracije, restart
        # i health check možda nisu završeni, zato prekinuti proces zahtijeva
        # kontrolisani rollback umjesto lažnog update_completed statusa.
        state = write_state(
            path,
            status="rollback_required",
            current_step="Updater je prekinut; potreban je siguran rollback",
            error_code="update_interrupted",
            error_message=f"Updater proces je prekinut tokom koraka: {failed_step}.",
            rollback_reason=f"Updater proces je prekinut tokom koraka: {failed_step}.",
            failed_step=failed_step,
            completed_at=completed_at,
            step_completed_at=completed_at,
        )
    else:
        state = write_state(
            path,
            status="interrupted",
            current_step="Updater je prekinut prije promjene aplikacijskih fajlova",
            error_code="update_interrupted",
            error_message=f"Updater proces je prekinut tokom koraka: {failed_step}.",
            failed_step=failed_step,
            completed_at=completed_at,
            step_completed_at=completed_at,
            manual_action_required=False,
        )

    sync_history(session, state)
    session.status = str(state["status"])[:48]
    if session.status in {
        UpdateSession.UPDATE_COMPLETED,
        UpdateSession.ROLLBACK_COMPLETED,
        UpdateSession.INTERRUPTED,
    }:
        session.is_active = False
    if session.status in {
        UpdateSession.UPDATE_COMPLETED,
        UpdateSession.ROLLBACK_COMPLETED,
    }:
        _clear_owned_locks(session)
    session.save(update_fields=["status", "is_active", "updated_at"])
    return state
