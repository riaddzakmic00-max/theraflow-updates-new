import json
import os
import shutil
from datetime import timedelta
from pathlib import Path

from django.conf import settings
from django.utils import timezone

from updates.models import UpdateHistory, UpdateSession

from .update_paths import ensure_child, get_update_paths


class CleanupError(RuntimeError):
    pass


def _safe_remove(path, parent):
    path = ensure_child(path, parent)
    if path.is_symlink():
        raise CleanupError("Cleanup neće pratiti simbolički link.")
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()


def cleanup_old_artifacts(now=None):
    paths = get_update_paths()
    lock = paths.sessions / "cleanup.lock"
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(descriptor)
    except FileExistsError as exc:
        raise CleanupError("Cleanup je već aktivan.") from exc
    now = now or timezone.now()
    cutoff = now - timedelta(days=getattr(settings, "THERAFLOW_UPDATE_ARTIFACT_RETENTION_DAYS", 14))
    removed = []
    try:
        protected_objects = list(UpdateSession.objects.filter(is_active=True)) + list(
            UpdateSession.objects.filter(status=UpdateSession.MANUAL_RECOVERY_REQUIRED, is_active=False)
        )
        protected_sessions = {item.pk for item in protected_objects}
        protected_text = {str(value) for value in protected_sessions}
        protected_paths = {
            str(Path(value).resolve())
            for item in protected_objects
            for value in (item.package_path, item.staging_directory, item.backup_directory)
            if value
        }
        for root in (paths.packages, paths.staging):
            for candidate in list(root.iterdir()):
                if candidate.is_symlink() or str(candidate.resolve()) in protected_paths or any(session_id in candidate.name for session_id in protected_text):
                    continue
                modified = timezone.datetime.fromtimestamp(candidate.stat().st_mtime, tz=timezone.get_current_timezone())
                if modified < cutoff:
                    _safe_remove(candidate, root)
                    removed.append(str(candidate.relative_to(paths.data_root)))

        successful = list(
            UpdateHistory.objects.filter(status=UpdateHistory.SUCCESSFUL, session__isnull=False)
            .select_related("session").order_by("-completed_at")
        )
        keep_backup_ids = {str(item.session_id) for item in successful[:3]}
        for item in successful[3:]:
            session = item.session
            if not session or str(session.pk) in protected_text or not session.backup_directory:
                continue
            backup = Path(session.backup_directory).resolve()
            if str(session.pk) in keep_backup_ids or not backup.exists():
                continue
            # Nikada ne briši jedini validni backup: uklanjanje počinje tek nakon tri novija uspješna.
            _safe_remove(backup, paths.backups)
            removed.append(str(backup.relative_to(paths.data_root)))
        report = {"completed_at": now.isoformat(), "removed": removed}
        report_path = paths.sessions / "cleanup_report.json"
        report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        return report
    finally:
        lock.unlink(missing_ok=True)
