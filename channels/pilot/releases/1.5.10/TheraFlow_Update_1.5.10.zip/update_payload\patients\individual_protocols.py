"""Jedini operativni izvor terapijskog protokola pacijenta.

Modul normalizuje standardne i individualne korake u isti read-only interfejs.
Pozivaoci zato ne moraju znati iz kojeg modela protokol dolazi, a historijski
zapisi terapija ostaju snapshot podataka koji su važili u trenutku primjene.
"""

import logging
from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal
from math import ceil

from django.utils import timezone

from .models import IndividualniKorakProtokola, IndividualniProtokolPacijenta
from .migration_calculations import validate_individual_interval


PROTOCOL_SOURCE_STANDARD = "STANDARDNI"
PROTOCOL_SOURCE_INDIVIDUAL = "INDIVIDUALNI"
logger = logging.getLogger(__name__)


class ProtocolStepCollection(list):
    """Lista sa malim QuerySet-kompatibilnim API-jem za postojeće pozivaoce."""

    def count(self, value=...):
        return len(self) if value is ... else super().count(value)

    def exists(self):
        return bool(self)

    def first(self):
        return self[0] if self else None

    def last(self):
        return self[-1] if self else None


@dataclass(frozen=True)
class EffectiveProtocolStep:
    source: str
    source_object: object
    faza: str
    redoslijed: int
    sedmica_od_pocetka: int | None
    doza_mg: Decimal | None
    broj_jedinica: Decimal
    interval_sedmica: int | None
    nacin_primjene_koraka: str

    FAZA_INDUKCIJA = "INDUKCIJA"
    FAZA_ODRZAVANJE = "ODRZAVANJE"
    NACIN_AMBULANTA = "AMBULANTA"
    NACIN_KUCNA_TERAPIJA = "KUCNA_TERAPIJA"

    @property
    def id(self):
        return getattr(self.source_object, "id", None)

    @property
    def pk(self):
        return self.id

    @property
    def nacin_primjene(self):
        return self.nacin_primjene_koraka

    def get_faza_display(self):
        return "Indukcija" if self.faza == self.FAZA_INDUKCIJA else "Održavanje"

    def get_nacin_primjene_koraka_display(self):
        return "Kućna terapija" if self.nacin_primjene_koraka == self.NACIN_KUCNA_TERAPIJA else "Ambulanta"

    def get_nacin_primjene_display(self):
        return self.get_nacin_primjene_koraka_display()

    @staticmethod
    def _format(value):
        value = Decimal(str(value or 0))
        return str(int(value)) if value == value.to_integral_value() else str(value.normalize())

    def opis_za_prikaz(self):
        doza = []
        if self.doza_mg is not None:
            doza.append(f"{self._format(self.doza_mg)} mg")
        doza.append(f"{self._format(self.broj_jedinica)} jedinica")
        opis = " / ".join(doza)
        mjesto = self.get_nacin_primjene_koraka_display()
        if self.faza == self.FAZA_INDUKCIJA:
            return f"Indukcija sedmica {self.sedmica_od_pocetka or 0} — {opis} ({mjesto})"
        return f"Održavanje — {opis} svake {self.interval_sedmica} sedmice ({mjesto})"

    def opis_doze(self):
        dijelovi = []
        if self.doza_mg is not None:
            dijelovi.append(f"{self._format(self.doza_mg)} mg")
        dijelovi.append(f"{self._format(self.broj_jedinica)} jedinica")
        return " / ".join(dijelovi)


@dataclass(frozen=True)
class EffectiveProtocol:
    source: str
    source_object: object
    steps: tuple
    warning: str = ""

    @property
    def is_individual(self):
        return self.source == PROTOCOL_SOURCE_INDIVIDUAL

    @property
    def naziv(self):
        return self.source_object.naziv

    @property
    def aktivan(self):
        return bool(self.source_object.aktivan)

    @property
    def doza_po_aplikaciji(self):
        step = self.korak_odrzavanja()
        return step.broj_jedinica if step else getattr(self.source_object, "doza_po_aplikaciji", 1)

    @property
    def interval_odrzavanja_sedmica(self):
        step = self.korak_odrzavanja()
        return step.interval_sedmica if step else getattr(self.source_object, "interval_odrzavanja_sedmica", None)

    @property
    def tip_terapije(self):
        return getattr(self.source_object, "tip_terapije", "KOMBINOVANO")

    def ima_korake(self):
        return bool(self.steps)

    def aktivni_koraci(self):
        return ProtocolStepCollection(self.steps)

    def indukcijski_koraci(self):
        return ProtocolStepCollection(step for step in self.steps if step.faza == "INDUKCIJA")

    def odrzavajuci_koraci(self):
        return ProtocolStepCollection(step for step in self.steps if step.faza == "ODRZAVANJE")

    def korak_odrzavanja(self):
        return self.odrzavajuci_koraci().last()

    def indukcijske_sedmice_lista(self):
        return [step.sedmica_od_pocetka for step in self.indukcijski_koraci() if step.sedmica_od_pocetka is not None]

    def ima_indukciju(self):
        return bool(self.indukcijski_koraci())

    def faza_za_broj_aplikacija(self, broj_aplikacija):
        return "Indukcija" if broj_aplikacija < len(self.indukcijski_koraci()) else "Održavanje"

    def sedmica_do_sljedece_aplikacije(self, broj_aplikacija_nakon_terapije):
        indukcija = self.indukcijski_koraci()
        if 0 < broj_aplikacija_nakon_terapije < len(indukcija):
            return max(indukcija[broj_aplikacija_nakon_terapije].sedmica_od_pocetka - indukcija[broj_aplikacija_nakon_terapije - 1].sedmica_od_pocetka, 1)
        return self.interval_odrzavanja_sedmica

    def doze_za_period(self, broj_sedmica):
        step = self.korak_odrzavanja()
        if not step or not step.interval_sedmica:
            return 0
        return ceil(int(broj_sedmica or 0) / step.interval_sedmica) * step.broj_jedinica


@dataclass(frozen=True)
class PatientProtocolSelection:
    source: str
    protocol: object | None
    warning: str = ""

    @property
    def is_individual(self):
        return self.source == PROTOCOL_SOURCE_INDIVIDUAL


def get_standard_protocol(pacijent):
    """Vrati sirovi standardni model bez pozivanja efektivnog resolvera."""
    assigned = getattr(pacijent, "terapijski_protokol", None)
    lijek = getattr(pacijent, "lijek", None)
    if assigned and assigned.aktivan and (
        not lijek or assigned.lijek_id in lijek.equivalent_ids()
    ):
        return assigned
    return lijek.aktivni_protokol() if lijek else None


def create_migrated_individual_protocol(
    pacijent,
    *,
    naziv,
    interval_sedmica,
    broj_jedinica,
    razlog="",
    user=None,
):
    """Kreiraj minimalan, važeći individualni režim za migriranog pacijenta.

    Migracija nema napredni editor koraka, zato se klinički detalji preuzimaju
    iz aktivnog standardnog protokola lijeka kada postoje, dok uneseni interval
    ostaje individualna vrijednost. Standardni protokol se ne dodjeljuje
    pacijentu i ne mijenja se.
    """
    interval_sedmica = validate_individual_interval(interval_sedmica)
    standardni = get_standard_protocol(pacijent)
    standardni_korak = standardni.korak_odrzavanja() if standardni else None
    lijek = getattr(pacijent, "lijek", None)

    broj_jedinica = Decimal(str(broj_jedinica))
    if broj_jedinica <= 0:
        raise ValueError("Količina po jednoj terapiji mora biti veća od nule.")
    doza_mg = Decimal(str(getattr(standardni_korak, "doza_mg", None) or 0))
    mjesto_primjene = (
        getattr(standardni_korak, "nacin_primjene_koraka", None)
        or getattr(lijek, "nacin_primjene", None)
        or IndividualniProtokolPacijenta.MJESTO_AMBULANTA
    )
    sedmica_od_pocetka = getattr(standardni_korak, "sedmica_od_pocetka", None) or 0

    protokol = IndividualniProtokolPacijenta.objects.create(
        pacijent=pacijent,
        standardni_protokol=standardni,
        naziv=(naziv or "").strip(),
        interval_odrzavanja_sedmica=interval_sedmica,
        doza_po_aplikaciji=broj_jedinica,
        mjesto_primjene=mjesto_primjene,
        aktivan=True,
        razlog_posljednje_izmjene=(razlog or "").strip(),
        kreirao=user,
        izmijenio=user,
    )
    korak = IndividualniKorakProtokola.objects.create(
        protokol=protokol,
        faza=IndividualniKorakProtokola.FAZA_ODRZAVANJE,
        redoslijed=1,
        sedmica_od_pocetka=sedmica_od_pocetka,
        doza_mg=doza_mg,
        broj_jedinica=broj_jedinica,
        nacin_primjene=mjesto_primjene,
        interval_sedmica=interval_sedmica,
    )
    protokol.faza_odrzavanja = korak.opis_za_prikaz()
    protokol.save(update_fields=["faza_odrzavanja", "datum_izmjene"])
    return protokol


def _adapt_step(step, source):
    return EffectiveProtocolStep(
        source=source,
        source_object=step,
        faza=step.faza,
        redoslijed=step.redoslijed,
        sedmica_od_pocetka=step.sedmica_od_pocetka,
        doza_mg=step.doza_mg,
        broj_jedinica=step.broj_jedinica,
        interval_sedmica=step.interval_sedmica,
        nacin_primjene_koraka=getattr(step, "nacin_primjene_koraka", None) or step.nacin_primjene,
    )


def _individual_validation_error(protokol):
    steps = list(
        protokol._workflow_steps
        if hasattr(protokol, "_workflow_steps")
        else protokol.koraci.all()
    )
    maintenance = [step for step in steps if step.faza == "ODRZAVANJE"]
    induction = [step for step in steps if step.faza == "INDUKCIJA"]
    if len(maintenance) != 1:
        return "individualni protokol mora imati tačno jedan korak održavanja"
    step = maintenance[0]
    if (
        not step.interval_sedmica
        or not 1 <= step.interval_sedmica <= 52
        or step.broj_jedinica <= 0
    ):
        return "održavanje nema ispravan interval ili broj jedinica"
    orders = [item.redoslijed for item in induction]
    weeks = [item.sedmica_od_pocetka for item in induction]
    if len(orders) != len(set(orders)) or len(weeks) != len(set(weeks)):
        return "indukcijski koraci imaju dupli redoslijed ili sedmicu"
    return ""


def resolve_patient_protocol(pacijent):
    """Vrati individualni protokol kada je aktivan, inace standardni."""
    try:
        individualni = pacijent.individualni_protokol
    except IndividualniProtokolPacijenta.DoesNotExist:
        individualni = None

    if individualni and individualni.aktivan:
        error = _individual_validation_error(individualni)
        if not error:
            return PatientProtocolSelection(PROTOCOL_SOURCE_INDIVIDUAL, individualni)
        warning = (
            "Individualni protokol nije kompletan; privremeno se koristi "
            "standardni protokol. Obratite se doktoru ili administratoru."
        )
        logger.error(
            "Neispravan individualni protokol pacijenta id=%s: %s; koristi se standardni protokol.",
            getattr(pacijent, "id", None), error,
        )
        return PatientProtocolSelection(
            PROTOCOL_SOURCE_STANDARD,
            get_standard_protocol(pacijent),
            warning,
        )

    return PatientProtocolSelection(PROTOCOL_SOURCE_STANDARD, get_standard_protocol(pacijent))


def get_effective_protocol(pacijent):
    from .request_cache import get_or_set

    if getattr(pacijent, "pk", None):
        return get_or_set(
            "effective_protocol",
            pacijent.pk,
            lambda: _get_effective_protocol_uncached(pacijent),
        )
    return _get_effective_protocol_uncached(pacijent)


def _get_effective_protocol_uncached(pacijent):

    selection = resolve_patient_protocol(pacijent)
    source = selection.source
    protocol = selection.protocol
    if protocol is None:
        return None
    if hasattr(protocol, "_workflow_steps"):
        raw_steps = protocol._workflow_steps
    elif source == PROTOCOL_SOURCE_INDIVIDUAL:
        raw_steps = protocol.koraci.order_by("faza", "redoslijed", "sedmica_od_pocetka", "id")
    else:
        raw_steps = protocol.koraci.filter(aktivan=True).order_by("faza", "redoslijed", "sedmica_od_pocetka", "id")
    effective = EffectiveProtocol(
        source,
        protocol,
        tuple(_adapt_step(step, source) for step in raw_steps),
        selection.warning,
    )
    # Jedan request često pita za fazu, interval, dozu i sljedeći termin istog
    # pacijenta. Svi ti podaci koriste isti nepromjenjivi snapshot protokola.
    return effective


def get_effective_protocol_steps(pacijent):
    protocol = get_effective_protocol(pacijent)
    return protocol.aktivni_koraci() if protocol else ProtocolStepCollection()


def get_step_for_application_number(pacijent, application_number):
    protocol = get_effective_protocol(pacijent)
    if not protocol or not protocol.ima_korake():
        return None
    if pacijent.pocetna_faza_terapije == pacijent.FAZA_ODRZAVANJE:
        return protocol.korak_odrzavanja()
    index = max(int(application_number or 1), 1) - 1
    induction = protocol.indukcijski_koraci()
    if index < len(induction):
        return induction[index]
    maintenance = protocol.odrzavajuci_koraci()
    return maintenance[min(index - len(induction), len(maintenance) - 1)] if maintenance else None


def get_current_step(pacijent, datum=None):
    return get_step_for_application_number(pacijent, pacijent.broj_dosadasnjih_aplikacija() + 1)


def get_current_therapy_phase(pacijent, datum=None):
    step = get_current_step(pacijent, datum)
    if step:
        return step.get_faza_display()
    protocol = get_effective_protocol(pacijent)
    if protocol:
        return protocol.faza_za_broj_aplikacija(pacijent.broj_aplikacija_za_protokol())
    return "Nije definisan protokol"


def get_units_per_application(pacijent, datum=None):
    definition = get_therapy_quantity_definition(pacijent)
    if definition["status"] == "FIXED":
        return definition["quantity"]
    if definition["status"] == "VARIABLE":
        step = get_current_step(pacijent, datum)
        return Decimal(str(step.broj_jedinica)) if step else Decimal("0")
    return Decimal("0")


def get_therapy_quantity_definition(pacijent):
    """Centralni strukturirani opis fizičke količine jedne primjene.

    Potvrđena pacijentska količina ima prednost jer predstavlja individualno
    odstupanje. Kada nije unesena, koriste se aktivni koraci efektivnog
    protokola, a tek zatim standardna količina samog protokola.
    """
    explicit = getattr(pacijent, "kolicina_po_terapiji", None)
    if explicit is not None and explicit > 0:
        quantity = Decimal(str(explicit))
        return {
            "status": "FIXED",
            "quantity": quantity,
            "unit": pacijent.jedinica_terapije_za_prikaz(quantity),
            "source": "PATIENT",
        }

    protocol = get_effective_protocol(pacijent)
    steps = list(protocol.aktivni_koraci()) if protocol else []
    if steps:
        quantities = []
        for step in steps:
            value = getattr(step, "broj_jedinica", None)
            if value is None or value <= 0:
                return {
                    "status": "MISSING",
                    "quantity": None,
                    "unit": "",
                    "source": "PROTOCOL_STEPS",
                }
            quantities.append(Decimal(str(value)))
        unique = set(quantities)
        if len(unique) == 1:
            quantity = quantities[0]
            return {
                "status": "FIXED",
                "quantity": quantity,
                "unit": pacijent.jedinica_terapije_za_prikaz(quantity),
                "source": "PROTOCOL_STEPS",
            }
        return {
            "status": "VARIABLE",
            "quantity": None,
            "unit": "",
            "source": "PROTOCOL_STEPS",
        }

    fallback = getattr(protocol, "doza_po_aplikaciji", None) if protocol else None
    if fallback is not None and fallback > 0:
        quantity = Decimal(str(fallback))
        return {
            "status": "FIXED",
            "quantity": quantity,
            "unit": pacijent.jedinica_terapije_za_prikaz(quantity),
            "source": "PROTOCOL",
        }
    return {
        "status": "MISSING",
        "quantity": None,
        "unit": "",
        "source": "NONE",
    }


def get_maintenance_interval_weeks(pacijent):
    """Vrati interval ponavljajućeg održavanja, ne razmak indukcijskih koraka."""
    protocol = get_effective_protocol(pacijent)
    maintenance = protocol.korak_odrzavanja() if protocol else None
    interval = (
        maintenance.interval_sedmica
        if maintenance and maintenance.interval_sedmica
        else protocol.interval_odrzavanja_sedmica if protocol else None
    )
    return int(interval or pacijent.interval_sedmica or 8)


def get_home_therapy_regimen(pacijent):
    """Vrati ponavljajući kućni režim koji troši izdate kućne doze.

    Kućna zaliha pokriva buduće ponavljajuće aplikacije, pa se koristi korak
    održavanja. Trenutni indukcijski korak može imati veću jednokratnu dozu i
    ne smije skratiti procjenu cijele izdate kućne zalihe.
    """
    phased_state = pacijent.aktivni_fazni_protokol()
    if phased_state and phased_state.sc_je_kucna_terapija:
        from .phased_protocols import current_phase_details

        details = current_phase_details(phased_state)
        return (
            Decimal(str(details["units"] or 0)),
            int(phased_state.interval_odrzavanja_sedmica),
        )

    protocol = get_effective_protocol(pacijent)
    explicit_quantity = getattr(pacijent, "kolicina_po_terapiji", None)
    maintenance = protocol.korak_odrzavanja() if protocol else None
    if maintenance and maintenance.nacin_primjene_koraka == maintenance.NACIN_KUCNA_TERAPIJA:
        units = Decimal(str(explicit_quantity or maintenance.broj_jedinica or 0))
        return units, get_maintenance_interval_weeks(pacijent)

    # Migrirani Hyrimoz pacijent može imati ispravno konfigurisan capability,
    # ali još nemati eksplicitno vezan standardni protokol. Read-path tada
    # koristi canonical registry konfiguraciju umjesto naziva proizvoda i ne
    # ostavlja pacijenta bez režima/pokrivenosti.
    medicine = getattr(pacijent, "lijek", None)
    if not protocol and medicine and medicine.kucna_terapija:
        from .standard_protocols import STANDARD_PROTOCOLS, standard_key_for_lijek

        key = standard_key_for_lijek(medicine)
        config = STANDARD_PROTOCOLS.get(key or "", {})
        if config.get("kucna_terapija"):
            units = Decimal(str(
                explicit_quantity or config.get("doza_po_aplikaciji") or 0
            ))
            interval = int(
                config.get("interval_odrzavanja_sedmica")
                or pacijent.interval_sedmica
                or 8
            )
            return units, interval

    current = get_current_step(pacijent)
    units = Decimal(str(current.broj_jedinica if current else get_units_per_application(pacijent)))
    interval = get_interval_weeks(pacijent)
    return units, int(interval or pacijent.interval_sedmica or 8)


def get_interval_weeks(pacijent, datum=None, after_application=False):
    protocol = get_effective_protocol(pacijent)
    if not protocol:
        return pacijent.interval_sedmica or 8
    current_number = pacijent.broj_dosadasnjih_aplikacija() + 1
    current = get_step_for_application_number(pacijent, current_number)
    previous = get_step_for_application_number(pacijent, current_number - 1) if current_number > 1 else None
    following = get_step_for_application_number(pacijent, current_number + (1 if after_application else 0))
    if after_application and current and following and current.id != following.id:
        if current.sedmica_od_pocetka is not None and following.sedmica_od_pocetka is not None:
            return max(following.sedmica_od_pocetka - current.sedmica_od_pocetka, 1)
    if not after_application and previous and current and previous.id != current.id:
        if previous.sedmica_od_pocetka is not None and current.sedmica_od_pocetka is not None:
            return max(current.sedmica_od_pocetka - previous.sedmica_od_pocetka, 1)
    if not after_application and not previous and current:
        next_step = get_step_for_application_number(pacijent, current_number + 1)
        if next_step and current.id != next_step.id:
            if current.sedmica_od_pocetka is not None and next_step.sedmica_od_pocetka is not None:
                return max(next_step.sedmica_od_pocetka - current.sedmica_od_pocetka, 1)
    target = following or current or protocol.korak_odrzavanja()
    return (target.interval_sedmica if target else None) or protocol.interval_odrzavanja_sedmica or pacijent.interval_sedmica or 8


def get_application_location(pacijent, datum=None):
    step = get_current_step(pacijent, datum)
    if step:
        return step.nacin_primjene_koraka
    return getattr(getattr(pacijent, "lijek", None), "nacin_primjene", "AMBULANTA")


def get_next_therapy_date(pacijent, from_date=None):
    from .models import Termin

    reference = from_date
    if reference is None:
        active_statuses = {Termin.STATUS_PLANIRANA}
        today = timezone.localdate()
        prefetched = getattr(pacijent, "_workflow_appointments", None)
        future = (
            min(
                (
                    item
                    for item in prefetched
                    if item.status in active_statuses and item.datum >= today
                ),
                key=lambda item: (item.datum, item.id),
                default=None,
            )
            if prefetched is not None
            else pacijent.termin_set.filter(
                status__in=active_statuses,
                datum__gte=today,
            ).order_by("datum", "id").first()
        )
        if future:
            return future.datum

        last = pacijent.zadnja_terapija()
        if last and last.is_migration:
            # Migracija bez izričito potvrđenog Termina ne smije pretvoriti
            # informativni izračun u automatski zakazanu terapiju.
            return None
        reference = last.datum if last else None
    if reference is None:
        return None
    calculated = pacijent._datum_sljedeceg_koraka_iz_referentnog(
        pacijent.broj_dosadasnjih_aplikacija() + 1,
        reference,
    )
    return calculated or reference + timedelta(
        weeks=get_interval_weeks(pacijent, reference)
    )


def persistable_standard_step(step):
    """Vrati samo stvarni standardni ORM korak koji FK Terapija prihvata."""
    if step is None:
        return None

    from .models import TerapijskiKorakProtokola

    if isinstance(step, TerapijskiKorakProtokola):
        return step
    source_object = getattr(step, "source_object", None)
    if (
        getattr(step, "source", None) == PROTOCOL_SOURCE_STANDARD
        and isinstance(source_object, TerapijskiKorakProtokola)
    ):
        return source_object
    # IndividualniKorakProtokola ima zaseban model i ne smije se upisati u
    # ForeignKey koji referencira TerapijskiKorakProtokola. Klinički snapshot
    # terapije i dalje se čuva kroz fazu, dozu i interval.
    return None


def individual_protocol_initial_data(pacijent):
    """Pripremi editabilni početni snapshot bez izmjene standardnog protokola."""
    standardni = get_standard_protocol(pacijent)
    if not standardni:
        return {
            "naziv": f"Individualni protokol - {pacijent}",
            "interval_odrzavanja_sedmica": pacijent.efektivni_interval_sedmica(),
            "doza_po_aplikaciji": pacijent.doza_po_aplikaciji(),
            "mjesto_primjene": (
                IndividualniProtokolPacijenta.MJESTO_KUCNA_TERAPIJA
                if pacijent.trenutni_korak_je_kucna_terapija()
                else IndividualniProtokolPacijenta.MJESTO_AMBULANTA
            ),
            "aktivan": True,
        }

    indukcijski = list(standardni.indukcijski_koraci())
    odrzavanje = standardni.korak_odrzavanja()
    return {
        "naziv": f"{standardni.naziv} - individualno",
        "indukcijska_faza": "\n".join(
            korak.opis_za_prikaz() for korak in indukcijski
        ),
        "faza_odrzavanja": odrzavanje.opis_za_prikaz() if odrzavanje else "",
        "interval_odrzavanja_sedmica": (
            odrzavanje.interval_sedmica
            if odrzavanje and odrzavanje.interval_sedmica
            else standardni.interval_odrzavanja_sedmica
        ),
        "doza_po_aplikaciji": (
            odrzavanje.broj_jedinica
            if odrzavanje
            else standardni.doza_po_aplikaciji
        ),
        "mjesto_primjene": (
            odrzavanje.nacin_primjene_koraka
            if odrzavanje
            else IndividualniProtokolPacijenta.MJESTO_AMBULANTA
        ),
        "aktivan": True,
    }


def structured_protocol_initial_data(pacijent, individualni=None):
    """Vrati početne podatke za napredni editor bez parsiranja slobodnog teksta."""
    if individualni and individualni.pk and individualni.koraci.exists():
        indukcija = [
            korak.snapshot()
            for korak in individualni.koraci.filter(
                faza=IndividualniKorakProtokola.FAZA_INDUKCIJA
            ).order_by("redoslijed", "id")
        ]
        odrzavanje = individualni.koraci.filter(
            faza=IndividualniKorakProtokola.FAZA_ODRZAVANJE
        ).first()
        return indukcija, odrzavanje.snapshot() if odrzavanje else None

    standardni = get_standard_protocol(pacijent)
    if standardni and standardni.ima_korake():
        indukcija = [
            {
                "redoslijed": korak.redoslijed,
                "sedmica_od_pocetka": korak.sedmica_od_pocetka or 0,
                "doza_mg": korak.doza_mg or 0,
                "broj_jedinica": korak.broj_jedinica,
                "nacin_primjene": korak.nacin_primjene_koraka,
            }
            for korak in standardni.indukcijski_koraci()
        ]
        odrzavanje = standardni.korak_odrzavanja()
        if odrzavanje:
            return indukcija, {
                "sedmica_od_pocetka": odrzavanje.sedmica_od_pocetka or 0,
                "doza_mg": odrzavanje.doza_mg or 0,
                "broj_jedinica": odrzavanje.broj_jedinica,
                "interval_sedmica": (
                    odrzavanje.interval_sedmica
                    or standardni.interval_odrzavanja_sedmica
                ),
                "nacin_primjene": odrzavanje.nacin_primjene_koraka,
            }

    if individualni:
        return [], {
            "sedmica_od_pocetka": 0,
            "doza_mg": individualni.doza_po_aplikaciji,
            "broj_jedinica": individualni.doza_po_aplikaciji,
            "interval_sedmica": individualni.interval_odrzavanja_sedmica,
            "nacin_primjene": individualni.mjesto_primjene,
        }
    return [], None


def save_structured_protocol_steps(protokol, induction_forms, maintenance_data):
    """Atomski zamijeni indukciju i upsertuj jedino ponavljajuće održavanje."""
    protokol.koraci.filter(faza=IndividualniKorakProtokola.FAZA_INDUKCIJA).delete()
    indukcijski_koraci = []
    for cleaned_data in induction_forms:
        if not cleaned_data or cleaned_data.get("DELETE"):
            continue
        indukcijski_koraci.append(
            IndividualniKorakProtokola(
                protokol=protokol,
                faza=IndividualniKorakProtokola.FAZA_INDUKCIJA,
                redoslijed=cleaned_data["redoslijed"],
                sedmica_od_pocetka=cleaned_data["sedmica_od_pocetka"],
                doza_mg=cleaned_data["doza_mg"],
                broj_jedinica=cleaned_data["broj_jedinica"],
                nacin_primjene=cleaned_data["nacin_primjene"],
                interval_sedmica=None,
            )
        )
    IndividualniKorakProtokola.objects.bulk_create(indukcijski_koraci)

    odrzavanje, _ = IndividualniKorakProtokola.objects.update_or_create(
        protokol=protokol,
        faza=IndividualniKorakProtokola.FAZA_ODRZAVANJE,
        defaults={
            "redoslijed": len(indukcijski_koraci) + 1,
            "sedmica_od_pocetka": maintenance_data["sedmica_od_pocetka"],
            "doza_mg": maintenance_data["doza_mg"],
            "broj_jedinica": maintenance_data["broj_jedinica"],
            "nacin_primjene": maintenance_data["nacin_primjene"],
            "interval_sedmica": maintenance_data["interval_sedmica"],
        },
    )

    protokol.indukcijska_faza = "\n".join(
        korak.opis_za_prikaz()
        for korak in protokol.koraci.filter(
            faza=IndividualniKorakProtokola.FAZA_INDUKCIJA
        ).order_by("redoslijed", "id")
    )
    protokol.faza_odrzavanja = odrzavanje.opis_za_prikaz()
    protokol.interval_odrzavanja_sedmica = odrzavanje.interval_sedmica
    protokol.doza_po_aplikaciji = odrzavanje.broj_jedinica
    protokol.mjesto_primjene = odrzavanje.nacin_primjene
    protokol.save(update_fields=[
        "indukcijska_faza",
        "faza_odrzavanja",
        "interval_odrzavanja_sedmica",
        "doza_po_aplikaciji",
        "mjesto_primjene",
        "datum_izmjene",
    ])
    return odrzavanje


def patient_protocol_display_data(pacijent):
    phased_state = pacijent.aktivni_fazni_protokol()
    if phased_state:
        from .phased_protocols import current_phase_details

        details = current_phase_details(phased_state)
        units = Decimal(str(details["units"] or 0))
        interval = (
            phased_state.interval_odrzavanja_sedmica
            if phased_state.faza == phased_state.FAZA_ODRZAVANJE
            else details["interval_weeks"]
        )
        phase_label = (
            "SC održavanje"
            if phased_state.faza == phased_state.FAZA_ODRZAVANJE
            else details["label"]
        )
        is_waiting_iv = phased_state.faza == phased_state.FAZA_CEKA_IV
        protocol_name = (
            "Ustekinumab – IV indukcija → SC održavanje"
            if is_waiting_iv else
            f"Ustekinumab – {phase_label}"
        )
        place = (
            phased_state.get_sc_nacin_primjene_display()
            if details["medicine"].put_primjene == "SC"
            else "Ambulanta"
        )
        current_regimen = {
            "doza_mg": details["dose_mg"],
            "broj_jedinica": units,
            "interval_sedmica": interval,
            "mjesto_primjene": place,
        }
        maintenance = {
            "naziv": "SC održavanje",
            "sedmica": None,
            "doza_mg": Decimal("90"),
            "broj_jedinica": Decimal("1"),
            "jedinica": pacijent.jedinica_terapije_za_prikaz(Decimal("1")),
            "mjesto_primjene": phased_state.get_sc_nacin_primjene_display(),
            "interval_sedmica": phased_state.interval_odrzavanja_sedmica,
        }
        return {
            "source": "FAZNI",
            "source_label": "Fazni protokol",
            "naziv": protocol_name,
            "trenutni_rezim": current_regimen,
            "indukcijski_koraci": [],
            "odrzavanje": maintenance,
            "interval_odrzavanja_sedmica": (
                phased_state.interval_odrzavanja_sedmica
            ),
            "doza_po_aplikaciji": units,
            "jedinica_doze_po_aplikaciji": (
                pacijent.jedinica_terapije_za_prikaz(units)
            ),
            "kolicina_po_terapiji": {
                "status": "FIXED" if units > 0 else "MISSING",
                "quantity": units if units > 0 else None,
                "unit": (
                    pacijent.jedinica_terapije_za_prikaz(units)
                    if units > 0 else ""
                ),
                "source": "PHASED_PROTOCOL",
            },
            "doza_mg": details["dose_mg"],
            "mjesto_primjene": place,
            "pocetak_odrzavanja_sedmica": None,
            "datum_pocetka_odrzavanja": phased_state.datum_prve_sc_primjene,
            "indukcijska_faza": "Jedna IV indukcija",
            "faza_odrzavanja": "90 mg SC",
            "razlog_posljednje_izmjene": "",
            "datum_izmjene": phased_state.izmijenjeno,
            "warning": "",
            "incomplete_warning": "" if (
                units > 0
                and phased_state.interval_odrzavanja_sedmica in (8, 12)
            ) else (
                "Protokol nije kompletno definisan"
            ),
        }

    selection = resolve_patient_protocol(pacijent)
    protokol = selection.protocol
    if protokol is None:
        return {
            "source": selection.source,
            "source_label": "Standardni protokol",
            "naziv": "Nije definisan",
            "warning": selection.warning,
            "incomplete_warning": "Protokol nije kompletno definisan",
            "indukcijski_koraci": [],
            "odrzavanje": None,
            "trenutni_rezim": None,
            "kolicina_po_terapiji": {
                "status": "MISSING",
                "quantity": None,
                "unit": "",
                "source": "NONE",
            },
        }

    efektivni = get_effective_protocol(pacijent)
    indukcijski = list(efektivni.indukcijski_koraci()) if efektivni else []
    odrzavanje = efektivni.korak_odrzavanja() if efektivni else None
    trenutni_korak = get_current_step(pacijent)
    trenutni_rezim = (
        {
            "doza_mg": trenutni_korak.doza_mg,
            "broj_jedinica": trenutni_korak.broj_jedinica,
            # Kanonski operativni interval uključuje stvarni razmak između
            # indukcijskih koraka, a u održavanju ponavljajući interval.
            "interval_sedmica": get_interval_weeks(pacijent),
            "mjesto_primjene": trenutni_korak.get_nacin_primjene_koraka_display(),
        }
        if trenutni_korak
        else None
    )

    def korak_za_prikaz(korak, naziv):
        return {
            "naziv": naziv,
            "sedmica": korak.sedmica_od_pocetka,
            "doza_mg": korak.doza_mg,
            "broj_jedinica": korak.broj_jedinica,
            "jedinica": pacijent.jedinica_terapije_za_prikaz(
                korak.broj_jedinica
            ),
            "mjesto_primjene": korak.get_nacin_primjene_koraka_display(),
        }

    indukcijski_prikaz = [
        korak_za_prikaz(korak, f"Indukcija {index}")
        for index, korak in enumerate(indukcijski, start=1)
    ]
    odrzavanje_prikaz = (
        {
            **korak_za_prikaz(odrzavanje, "Održavanje"),
            "interval_sedmica": odrzavanje.interval_sedmica,
        }
        if odrzavanje
        else None
    )
    interval = (
        odrzavanje.interval_sedmica
        if odrzavanje and odrzavanje.interval_sedmica
        else efektivni.interval_odrzavanja_sedmica if efektivni else None
    )
    jedinice = (
        odrzavanje.broj_jedinica
        if odrzavanje
        else efektivni.doza_po_aplikaciji if efektivni else None
    )
    mjesto = (
        odrzavanje.get_nacin_primjene_koraka_display()
        if odrzavanje
        else ""
    )
    datum_pocetka = (
        getattr(protokol, "datum_pocetka_odrzavanja", None)
        if selection.is_individual
        else None
    )
    potpuno = bool(odrzavanje and interval and jedinice and mjesto)

    return {
        "source": selection.source,
        "source_label": (
            "Individualni protokol" if selection.is_individual else "Standardni protokol"
        ),
        "naziv": protokol.naziv,
        "trenutni_rezim": trenutni_rezim,
        "indukcijski_koraci": indukcijski_prikaz,
        "odrzavanje": odrzavanje_prikaz,
        "interval_odrzavanja_sedmica": interval,
        "doza_po_aplikaciji": jedinice,
        "jedinica_doze_po_aplikaciji": (
            pacijent.jedinica_terapije_za_prikaz(jedinice)
            if jedinice
            else ""
        ),
        "kolicina_po_terapiji": get_therapy_quantity_definition(pacijent),
        "doza_mg": odrzavanje.doza_mg if odrzavanje else None,
        "mjesto_primjene": mjesto,
        "pocetak_odrzavanja_sedmica": (
            odrzavanje.sedmica_od_pocetka if odrzavanje else None
        ),
        "datum_pocetka_odrzavanja": datum_pocetka,
        "indukcijska_faza": "\n".join(
            korak.opis_za_prikaz() for korak in indukcijski
        ),
        "faza_odrzavanja": odrzavanje.opis_za_prikaz() if odrzavanje else "",
        "razlog_posljednje_izmjene": (
            getattr(protokol, "razlog_posljednje_izmjene", "")
            if selection.is_individual
            else ""
        ),
        "datum_izmjene": (
            getattr(protokol, "datum_izmjene", None)
            if selection.is_individual
            else None
        ),
        "warning": selection.warning,
        "incomplete_warning": "" if potpuno else "Protokol nije kompletno definisan",
    }
