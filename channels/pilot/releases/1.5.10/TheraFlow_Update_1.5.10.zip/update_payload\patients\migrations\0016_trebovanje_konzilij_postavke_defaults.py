# Generated for TheraFlow konzilij fields

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0015_terapijskiprotokol_pacijent_terapijski_protokol"),
    ]

    operations = [
        migrations.AddField(
            model_name="trebovanje",
            name="predsjednik_konzilija",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="clan_konzilija_1",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="clan_konzilija_2",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.AddField(
            model_name="postavkesistema",
            name="default_predsjednik_konzilija",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.AddField(
            model_name="postavkesistema",
            name="default_clan_konzilija_1",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.AddField(
            model_name="postavkesistema",
            name="default_clan_konzilija_2",
            field=models.CharField(blank=True, max_length=150),
        ),
    ]
