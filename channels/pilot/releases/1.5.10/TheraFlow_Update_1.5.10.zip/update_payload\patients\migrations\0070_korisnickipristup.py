from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("patients", "0069_coordinator_role_and_clinical_decision"),
    ]

    operations = [
        migrations.CreateModel(
            name="KorisnickiPristup",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("zahtijeva_promjenu_lozinke", models.BooleanField(default=False)),
                ("izmijenjeno", models.DateTimeField(auto_now=True)),
                (
                    "korisnik",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="theraflow_pristup",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "verbose_name": "Korisnički pristup",
                "verbose_name_plural": "Korisnički pristupi",
            },
        ),
    ]
