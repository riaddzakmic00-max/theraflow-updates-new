"""Observation-only adaptive layer.

This module may read deterministic engine output and append observations. It
must never be imported by demand, protocol, scheduling, inventory or approval
calculations as an input to a decision.
"""

import hashlib
import json
import logging
from collections import Counter, defaultdict
from datetime import date, datetime
from decimal import Decimal

from django.conf import settings
from django.db import transaction
from django.db.models import Min
from django.utils import timezone

from .models import (
    AdaptiveDecisionRecord,
    AdaptiveInsight,
    OperationalOutcome,
    TerapijaStatusHistorija,
    Termin,
)


MIN_PRELIMINARY_SAMPLE = 10
MIN_STABLE_SAMPLE = 20
MIN_DELIVERY_CYCLES = 2
logger = logging.getLogger(__name__)


def adaptive_enabled():
    return bool(getattr(settings, "ADAPTIVE_ASSISTANT_ENABLED", False))


def adaptive_mode():
    return getattr(settings, "ADAPTIVE_ASSISTANT_MODE", "observation")


def algorithm_version():
    return getattr(
        settings,
        "ADAPTIVE_ASSISTANT_ALGORITHM_VERSION",
        "commission-engine-v2-observation-1",
    )


def _json_safe(value):
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, dict):
        return {
            str(key): _json_safe(item)
            for key, item in value.items()
            if not str(key).startswith("_")
        }
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _snapshot_hash(payload):
    encoded = json.dumps(
        _json_safe(payload),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _override_reason(reason_code, note):
    valid = {code for code, _ in AdaptiveDecisionRecord.OVERRIDE_REASONS}
    if reason_code in valid:
        return reason_code
    return AdaptiveDecisionRecord.REASON_OTHER if (note or "").strip() else ""


def _detail_snapshot(detail):
    if not isinstance(detail, dict):
        return {}
    return {
        "date": detail.get("datum"),
        "required_quantity": detail.get("potrebna_kolicina"),
        "missing_quantity": detail.get("nedostatak"),
        "scheduled": detail.get("termin_postoji"),
        "date_reason": detail.get("razlog_datuma"),
    }


def record_commission_decision(
    *,
    row,
    final_quantity,
    user=None,
    reason_code="",
    note="",
    commission_cycle=None,
):
    """Append a snapshot after an explicit user confirmation."""

    if not adaptive_enabled() or adaptive_mode() != "observation" or not row:
        return None
    patient = row.get("pacijent")
    medicine = row.get("lijek")
    effective_protocol = patient.aktivni_protokol() if patient else None
    protocol = getattr(effective_protocol, "source_object", effective_protocol)
    system_quantity = Decimal(str(
        row.get(
            "proposed_procurement_units",
            row.get("sistem_predlaze", 0),
        ) or 0
    ))
    final_quantity = Decimal(str(final_quantity or 0))
    system_included = bool(
        row.get("eligible_for_current_cycle", True)
        and system_quantity > 0
    )
    final_included = final_quantity > 0
    coverage = row.get("coverage") or {}
    eligibility = row.get("commission_eligibility")
    selected_window = (
        row.get("planirati_za_komisiju")
        or getattr(eligibility, "trenutna_komisija", None)
    )
    expected_delivery = (
        row.get("ocekivani_datum_dolaska")
        or row.get("procijenjeni_datum_dolaska")
        or getattr(selected_window, "najkasnija_isporuka", None)
    )
    system_proposal = {
        "quantity": system_quantity,
        "included": system_included,
        "eligible_for_current_cycle": bool(
            row.get("eligible_for_current_cycle", False)
        ),
        "estimated_coverage_until": row.get("planirano_pokriven_do"),
        "first_uncovered_therapy": row.get("prva_nepokrivena_terapija"),
        "available_doses": {
            "at_patient": coverage.get("at_patient", 0),
            "reserved_in_fridge": coverage.get("reserved_in_fridge", 0),
            "approved_unused": coverage.get("unused_approved", 0),
            "approved_waiting_delivery": coverage.get(
                "approved_waiting_delivery",
                0,
            ),
            "submitted": coverage.get("submitted", 0),
            "free_fridge": coverage.get("free_fridge", 0),
        },
        "future_therapies": [
            _detail_snapshot(detail)
            for detail in (row.get("detalji") or ())
        ],
        "commission_date": getattr(selected_window, "datum_komisije", None),
        "expected_delivery_date": expected_delivery,
        "safety_reserve": row.get("sigurnosna_rezerva", 0),
        "minimal_required": row.get("minimalno_potrebno", 0),
        "delivery_risk": bool(row.get("rizik_dostave")),
        "protocol": {
            "id": getattr(protocol, "pk", None),
            "name": (
                getattr(effective_protocol, "naziv", "")
                or getattr(protocol, "naziv", "")
            ),
            "source": getattr(effective_protocol, "source", "STANDARDNI"),
        },
    }
    final_decision = {
        "quantity": final_quantity,
        "included": final_included,
        "confirmed_by_user": True,
    }
    difference = {
        "quantity_delta": final_quantity - system_quantity,
        "inclusion_changed": final_included != system_included,
        "system_included": system_included,
        "final_included": final_included,
        "direction": (
            "INCREASED"
            if final_quantity > system_quantity
            else "DECREASED"
            if final_quantity < system_quantity
            else "UNCHANGED"
        ),
    }
    hash_payload = {
        "patient_id": getattr(patient, "pk", None),
        "medicine_id": getattr(medicine, "pk", None),
        "protocol_id": getattr(protocol, "pk", None),
        "commission_cycle_id": getattr(commission_cycle, "pk", None),
        "system": system_proposal,
        "final": final_decision,
        "difference": difference,
        "algorithm_version": algorithm_version(),
    }
    return AdaptiveDecisionRecord.objects.create(
        decision_type=AdaptiveDecisionRecord.DECISION_COMMISSION,
        patient=patient,
        medicine=medicine,
        protocol=protocol,
        commission_cycle=commission_cycle,
        system_proposal_json=_json_safe(system_proposal),
        final_decision_json=_json_safe(final_decision),
        difference_json=_json_safe(difference),
        override_reason=_override_reason(reason_code, note),
        override_note=(note or "").strip(),
        user=user if getattr(user, "is_authenticated", False) else None,
        algorithm_version=algorithm_version(),
        data_snapshot_hash=_snapshot_hash(hash_payload),
        is_test_data=bool(
            patient and str(getattr(patient, "jmbg", "")).startswith("990")
        ),
    )


def observe_commission_decision_safely(**kwargs):
    """Fail-open adapter: observation must never block the confirmed decision."""

    try:
        with transaction.atomic():
            return record_commission_decision(**kwargs)
    except Exception:
        logger.exception(
            "Adaptivni asistent nije uspio evidentirati komisijsku odluku."
        )
        return None


def record_operational_outcomes(cycle, *, actual_delivery_date=None):
    """Observe a completed cycle without changing its workflow state."""

    if not adaptive_enabled() or adaptive_mode() != "observation":
        return []
    from .commission_service import expected_delivery_for_cycle

    actual_delivery_date = actual_delivery_date or cycle.datum_zaprimanja
    expected = expected_delivery_for_cycle(cycle)
    commission_date = cycle.datum_komisije or cycle.datum_odobrenja
    requests = list(
        cycle.trebovanja.select_related("pacijent", "lijek")
    )
    medicine_ids = {request.lijek_id for request in requests if request.lijek_id}
    outcomes = []
    for medicine_id in medicine_ids:
        scoped = [item for item in requests if item.lijek_id == medicine_id]
        medicine = scoped[0].lijek
        patient_ids = [item.pacijent_id for item in scoped]
        first_therapy = (
            Termin.objects.filter(
                pacijent_id__in=patient_ids,
                lijek_id__in=medicine.equivalent_ids(),
                datum__gte=actual_delivery_date,
            )
            .order_by("datum", "vrijeme", "id")
            .values_list("datum", flat=True)
            .first()
            if actual_delivery_date
            else None
        )
        event_history = TerapijaStatusHistorija.objects.filter(
            pacijent_id__in=patient_ids,
            novi_status__in=(
                Termin.STATUS_ODGODJENA,
                Termin.STATUS_NIJE_DOSAO,
            ),
        )
        if commission_date:
            event_history = event_history.filter(
                datum_vrijeme__date__gte=commission_date,
            )
        if actual_delivery_date:
            event_history = event_history.filter(
                datum_vrijeme__date__lte=actual_delivery_date,
            )
        postponed = event_history.filter(
            novi_status=Termin.STATUS_ODGODJENA
        )
        no_shows = event_history.filter(
            novi_status=Termin.STATUS_NIJE_DOSAO
        )
        defaults = {
            "commission_date": commission_date,
            "expected_delivery_date": expected,
            "actual_delivery_date": actual_delivery_date,
            "planned_lead_time_days": (
                (expected - commission_date).days
                if expected and commission_date else None
            ),
            "actual_lead_time_days": (
                (actual_delivery_date - commission_date).days
                if actual_delivery_date and commission_date else None
            ),
            "delivery_variance_days": (
                (actual_delivery_date - expected).days
                if actual_delivery_date and expected else None
            ),
            "receipt_date": actual_delivery_date,
            "first_scheduled_therapy_after_receipt": first_therapy,
            "postponed_therapy_count": postponed.count(),
            "no_show_count": no_shows.count(),
            "postponement_reasons_json": list(
                postponed.exclude(razlog="")
                .values_list("razlog", flat=True)
            ),
            "shortage_risk_observed": AdaptiveDecisionRecord.objects.filter(
                commission_cycle=cycle,
                medicine=medicine,
                system_proposal_json__delivery_risk=True,
            ).exists(),
            "algorithm_version": algorithm_version(),
            "is_test_data": all(
                str(getattr(item.pacijent, "jmbg", "")).startswith("990")
                for item in scoped
            ),
        }
        outcome, _ = OperationalOutcome.objects.update_or_create(
            medicine=medicine,
            commission_cycle=cycle,
            defaults=defaults,
        )
        outcomes.append(outcome)
    return outcomes


def observe_operational_outcomes_safely(cycle, *, actual_delivery_date=None):
    """Fail-open adapter: observation must never block receipt."""

    try:
        with transaction.atomic():
            return record_operational_outcomes(
                cycle,
                actual_delivery_date=actual_delivery_date,
            )
    except Exception:
        logger.exception(
            "Adaptivni asistent nije uspio evidentirati operativni ishod."
        )
        return []


def confidence_for_sample(sample_size, *, delivery=False):
    if delivery:
        if sample_size < MIN_DELIVERY_CYCLES:
            return AdaptiveInsight.CONFIDENCE_INSUFFICIENT
        if sample_size < MIN_PRELIMINARY_SAMPLE:
            return AdaptiveInsight.CONFIDENCE_PRELIMINARY
        return AdaptiveInsight.CONFIDENCE_STABLE
    if sample_size < MIN_PRELIMINARY_SAMPLE:
        return AdaptiveInsight.CONFIDENCE_INSUFFICIENT
    if sample_size < MIN_STABLE_SAMPLE:
        return AdaptiveInsight.CONFIDENCE_PRELIMINARY
    return AdaptiveInsight.CONFIDENCE_STABLE


def adaptive_summary():
    decisions = list(
        AdaptiveDecisionRecord.objects.filter(
            is_test_data=False,
        ).select_related("medicine")
    ) if adaptive_enabled() else []
    manual = [
        item for item in decisions
        if (
            Decimal(str(item.difference_json.get("quantity_delta", 0))) != 0
            or item.difference_json.get("inclusion_changed")
        )
    ]
    accepted = len(decisions) - len(manual)
    total = len(decisions)
    reasons = Counter(
        item.override_reason for item in manual if item.override_reason
    )
    increased_reserve = reasons.get(
        AdaptiveDecisionRecord.REASON_EXTRA_RESERVE,
        0,
    )
    unnecessary_inclusions = sum(
        bool(item.difference_json.get("system_included"))
        and not bool(item.difference_json.get("final_included"))
        for item in decisions
    )
    missed_inclusions = sum(
        not bool(item.difference_json.get("system_included"))
        and bool(item.difference_json.get("final_included"))
        for item in decisions
    )
    return {
        "enabled": adaptive_enabled(),
        "mode": adaptive_mode(),
        "mode_label": "Režim posmatranja",
        "started_at": AdaptiveDecisionRecord.objects.aggregate(
            value=Min("created_at")
        )["value"],
        "decision_count": total,
        "manual_change_count": len(manual),
        "accepted_percentage": (
            round(accepted * 100 / total, 1) if total else 0
        ),
        "delivery_count": OperationalOutcome.objects.filter(
            is_test_data=False,
            actual_delivery_date__isnull=False
        ).count(),
        "last_analysis": AdaptiveInsight.objects.order_by(
            "-generated_at"
        ).first(),
        "algorithm_version": algorithm_version(),
        "extra_reserve_count": increased_reserve,
        "system_included_user_excluded_count": unnecessary_inclusions,
        "system_excluded_user_included_count": missed_inclusions,
        "common_reasons": [
            {
                "code": code,
                "label": dict(AdaptiveDecisionRecord.OVERRIDE_REASONS).get(
                    code,
                    code,
                ),
                "count": count,
            }
            for code, count in reasons.most_common(5)
        ],
    }


def adaptive_summary_safely():
    """Service-center fallback; analytics failure must not crash the page."""

    try:
        return adaptive_summary()
    except Exception:
        logger.exception("Sažetak Adaptivnog asistenta trenutno nije dostupan.")
        return {
            "enabled": adaptive_enabled(),
            "mode": adaptive_mode(),
            "mode_label": "Režim posmatranja",
            "started_at": None,
            "decision_count": 0,
            "manual_change_count": 0,
            "accepted_percentage": 0,
            "delivery_count": 0,
            "last_analysis": None,
            "algorithm_version": algorithm_version(),
            "extra_reserve_count": 0,
            "system_included_user_excluded_count": 0,
            "system_excluded_user_included_count": 0,
            "common_reasons": [],
            "status_error": True,
        }


def calculate_descriptive_insights(*, persist=False):
    decisions = list(
        AdaptiveDecisionRecord.objects.filter(
            is_test_data=False,
        ).select_related("medicine")
    )
    outcomes = list(
        OperationalOutcome.objects.filter(
            is_test_data=False,
            actual_delivery_date__isnull=False,
        ).select_related("medicine")
    )
    insights = []
    total = len(decisions)
    changed = [
        record for record in decisions
        if (
            Decimal(str(record.difference_json.get("quantity_delta", 0))) != 0
            or record.difference_json.get("inclusion_changed")
        )
    ]
    insights.append({
        "insight_type": "ACCEPTANCE_RATE",
        "medicine": None,
        "title": "Prihvatanje sistemskih prijedloga",
        "explanation": (
            f"{total - len(changed)} od {total} prijedloga prihvaćeno je bez izmjene."
            if total else "Još nema evidentiranih odluka."
        ),
        "sample_size": total,
        "confidence_level": confidence_for_sample(total),
        "calculated_value": {
            "percentage": round((total - len(changed)) * 100 / total, 1)
            if total else 0,
        },
        "current_configured_value": {},
    })

    by_medicine = defaultdict(list)
    for record in decisions:
        by_medicine[record.medicine_id].append(record)
    for medicine_id, records in by_medicine.items():
        medicine = records[0].medicine
        deltas = [
            Decimal(str(item.difference_json.get("quantity_delta", 0)))
            for item in records
        ]
        correction_count = sum(delta != 0 for delta in deltas)
        average = sum(deltas, Decimal("0")) / len(deltas)
        insights.append({
            "insight_type": "QUANTITY_CHANGE_BY_MEDICINE",
            "medicine": medicine,
            "title": f"Ručne korekcije – {medicine.prikaz_naziv}",
            "explanation": (
                f"Prosječna promjena je {average:.2f} nabavnih jedinica; "
                f"{correction_count} od {len(records)} odluka je korigovano."
            ),
            "sample_size": len(records),
            "confidence_level": confidence_for_sample(len(records)),
            "calculated_value": {
                "average_quantity_delta": str(average),
                "correction_count": correction_count,
            },
            "current_configured_value": {},
        })

    completed_cycles = {
        outcome.commission_cycle_id
        for outcome in outcomes
        if outcome.commission_cycle_id
    }
    delivery_deltas = [
        (item.actual_delivery_date - item.expected_delivery_date).days
        for item in outcomes
        if item.actual_delivery_date and item.expected_delivery_date
    ]
    average_delivery_delta = (
        sum(delivery_deltas) / len(delivery_deltas)
        if delivery_deltas else 0
    )
    actual_lead_times = [
        item.actual_lead_time_days
        for item in outcomes
        if item.actual_lead_time_days is not None
    ]
    planned_lead_times = [
        item.planned_lead_time_days
        for item in outcomes
        if item.planned_lead_time_days is not None
    ]
    average_actual_lead_time = (
        sum(actual_lead_times) / len(actual_lead_times)
        if actual_lead_times else 0
    )
    average_planned_lead_time = (
        sum(planned_lead_times) / len(planned_lead_times)
        if planned_lead_times else 0
    )
    insights.append({
        "insight_type": "DELIVERY_TIMING",
        "medicine": None,
        "title": "Stvarno vrijeme isporuke",
        "explanation": (
            f"Prosječno vrijeme od komisije do stvarne isporuke je "
            f"{average_actual_lead_time:.1f} dana; odstupanje stvarne od "
            f"očekivane isporuke je {average_delivery_delta:.1f} dana."
            if delivery_deltas
            else "Još nema završenih isporuka za poređenje."
        ),
        "sample_size": len(completed_cycles),
        "confidence_level": (
            AdaptiveInsight.CONFIDENCE_INSUFFICIENT
            if len(completed_cycles) < MIN_DELIVERY_CYCLES
            else confidence_for_sample(len(completed_cycles), delivery=True)
        ),
        "calculated_value": {
            "average_delivery_delta_days": average_delivery_delta,
            "average_actual_lead_time_days": average_actual_lead_time,
            "completed_cycle_count": len(completed_cycles),
        },
        "current_configured_value": {
            "average_planned_lead_time_days": average_planned_lead_time,
        },
    })

    reasons = Counter(
        record.override_reason
        for record in changed
        if record.override_reason
    )
    if reasons:
        reason_code, reason_count = reasons.most_common(1)[0]
        reason_label = dict(AdaptiveDecisionRecord.OVERRIDE_REASONS).get(
            reason_code,
            reason_code,
        )
        insights.append({
            "insight_type": "COMMON_OVERRIDE_REASON",
            "medicine": None,
            "title": "Najčešći razlog izmjene",
            "explanation": f"{reason_label}: {reason_count} evidentiranih izmjena.",
            "sample_size": len(changed),
            "confidence_level": confidence_for_sample(len(changed)),
            "calculated_value": {
                "reason": reason_code,
                "count": reason_count,
            },
            "current_configured_value": {},
        })

    for insight in insights:
        insight["reliability_message"] = (
            "Nedovoljno podataka za pouzdan zaključak."
            if insight["confidence_level"]
            == AdaptiveInsight.CONFIDENCE_INSUFFICIENT
            else ""
        )
        if persist:
            AdaptiveInsight.objects.create(
                **{
                    key: value
                    for key, value in insight.items()
                    if key != "reliability_message"
                },
                algorithm_version=algorithm_version(),
            )
    return insights


def calculate_descriptive_insights_safely(*, persist=False):
    try:
        return calculate_descriptive_insights(persist=persist)
    except Exception:
        logger.exception("Deskriptivna analiza trenutno nije dostupna.")
        return []


def anonymized_aggregate_rows():
    decisions = list(
        AdaptiveDecisionRecord.objects.filter(
            is_test_data=False,
        ).select_related("medicine")
    )
    grouped = defaultdict(list)
    for item in decisions:
        grouped[item.medicine_id].append(item)
    rows = []
    for records in grouped.values():
        medicine = records[0].medicine
        deltas = [
            Decimal(str(item.difference_json.get("quantity_delta", 0)))
            for item in records
        ]
        changed = sum(
            delta != 0 or record.difference_json.get("inclusion_changed")
            for delta, record in zip(deltas, records)
        )
        rows.append({
            "medicine": medicine.prikaz_naziv if medicine else "Nepoznato",
            "decisions": len(records),
            "manual_changes": changed,
            "accepted_percentage": round(
                (len(records) - changed) * 100 / len(records),
                1,
            ),
            "average_quantity_delta": str(
                sum(deltas, Decimal("0")) / len(deltas)
            ),
        })
    return sorted(rows, key=lambda item: item["medicine"])


def anonymized_aggregate_rows_safely():
    try:
        return anonymized_aggregate_rows()
    except Exception:
        logger.exception("Anonimizirani adaptive izvoz trenutno nije dostupan.")
        return None
