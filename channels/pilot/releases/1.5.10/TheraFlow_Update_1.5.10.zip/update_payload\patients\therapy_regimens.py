"""Tipizirani resolver terapijskih režima i inventory ponašanja.

Ambulantni/SC protokoli ostaju u postojećem ``TerapijskiProtokol`` modelu,
fazni ustekinumab workflow u svom engineu, a oralne dnevne sheme u
``StandardniOralniRezim``. Resolver daje jedinstvenu ulaznu tačku bez
izjednačavanja semantički različitih polja.
"""

from dataclasses import dataclass

from django.db.models import Q

from .models import Lijek, StandardniOralniRezim, TerapijskiProtokol


TYPE_INFUSION = "INFUSION"
TYPE_HOME_SC = "HOME_SC"
TYPE_ORAL = "ORAL"


@dataclass(frozen=True)
class InventoryBehavior:
    """UI i izvor količine fizičke zalihe prema terapijskom tipu."""

    therapy_type: str
    stock_label: str
    reserved_label: str
    free_label: str
    patient_quantity_applicable: bool
    patient_quantity_label: str
    patient_quantity_help: str
    patient_quantity_source: str


INVENTORY_BEHAVIORS = {
    TYPE_INFUSION: InventoryBehavior(
        therapy_type=TYPE_INFUSION,
        stock_label="Ukupno u frižideru",
        reserved_label="Rezervisano pacijentima (fizički)",
        free_label="Slobodno za dodjelu",
        patient_quantity_applicable=False,
        patient_quantity_label="Kod pacijenata",
        patient_quantity_help="",
        patient_quantity_source="NOT_APPLICABLE",
    ),
    TYPE_HOME_SC: InventoryBehavior(
        therapy_type=TYPE_HOME_SC,
        stock_label="Ukupno u frižideru",
        reserved_label="Rezervisano pacijentima (fizički)",
        free_label="Slobodno za dodjelu",
        patient_quantity_applicable=True,
        patient_quantity_label="Kod pacijenata / izdato pacijentima",
        patient_quantity_help="Preostalo aktivno zaduženje kod pacijenata.",
        patient_quantity_source="PACIJENT_ZADUZENJE",
    ),
    TYPE_ORAL: InventoryBehavior(
        therapy_type=TYPE_ORAL,
        stock_label="U kabinetu",
        reserved_label="Rezervisano / planirano za izdavanje",
        free_label="Fizički slobodno u kabinetu",
        patient_quantity_applicable=True,
        patient_quantity_label="Kod pacijenta / izdato pacijentima",
        patient_quantity_help=(
            "Procijenjeno preostalo prema stvarnim oralnim izdavanjima i "
            "potvrđenom dnevnom režimu."
        ),
        patient_quantity_source="ORAL_DISPENSING",
    ),
}


def therapy_regimen_type(medicine):
    if not medicine:
        return None
    if medicine.oralna_terapija:
        return TYPE_ORAL
    if medicine.kucna_terapija or medicine.put_primjene == Lijek.PUT_SC:
        return TYPE_HOME_SC
    return TYPE_INFUSION


def therapy_regimen_type_q(therapy_type, *, prefix=""):
    """ORM ekvivalent canonical ``therapy_regimen_type`` klasifikacije.

    KPI-ji i drugi agregati moraju koristiti istu prioritetnu logiku kao
    pojedinačni lijek: oralno prvo, zatim SC/kućno, a sve ostalo je IV.
    """

    field_prefix = f"{prefix}__" if prefix else ""
    exists = (
        Q(**{f"{prefix}__isnull": False})
        if prefix
        else Q(pk__isnull=False)
    )
    oral = Q(**{
        f"{field_prefix}nacin_primjene": Lijek.NACIN_ORALNA_TERAPIJA,
    })
    sc_or_home = (
        Q(**{f"{field_prefix}kucna_primjena": True})
        | Q(**{
            f"{field_prefix}nacin_primjene": Lijek.NACIN_KUCNA_TERAPIJA,
        })
        | Q(**{f"{field_prefix}put_primjene": Lijek.PUT_SC})
    )
    if therapy_type == TYPE_ORAL:
        return exists & oral
    if therapy_type == TYPE_HOME_SC:
        return exists & ~oral & sc_or_home
    if therapy_type == TYPE_INFUSION:
        return exists & ~oral & ~sc_or_home
    return Q(pk__isnull=True)


def inventory_behavior(medicine):
    """Vrati jedini canonical inventory ugovor za prezentaciju lijeka."""

    return INVENTORY_BEHAVIORS[therapy_regimen_type(medicine) or TYPE_INFUSION]


def standard_regimens_for_medicine(medicine):
    """Vrati queryset odgovarajućeg postojećeg modela za vrstu lijeka."""

    if therapy_regimen_type(medicine) == TYPE_ORAL:
        return StandardniOralniRezim.objects.filter(
            lijek=medicine,
            aktivan=True,
            lijek__aktivan=True,
        ).select_related("lijek").order_by("naziv", "id")
    return TerapijskiProtokol.objects.filter(
        lijek=medicine,
        aktivan=True,
        lijek__aktivan=True,
    ).select_related("lijek").order_by("naziv", "id")


def oral_regimen_configuration(medicine, *, selected=None):
    """Vrati eksplicitno stanje oralne konfiguracije i siguran prijedlog."""

    options = list(standard_regimens_for_medicine(medicine))
    selected_regimen = next(
        (
            item
            for item in options
            if selected is not None and item.pk == getattr(selected, "pk", selected)
        ),
        None,
    )
    if selected_regimen:
        status = "SELECTED"
        suggested = selected_regimen
    elif len(options) == 1:
        status = "SINGLE_AVAILABLE"
        suggested = options[0]
    elif len(options) > 1:
        status = "MULTIPLE_REQUIRED"
        suggested = None
    else:
        status = "NOT_CONFIGURED"
        suggested = None
    return {
        "status": status,
        "options": options,
        "suggested": suggested,
    }
