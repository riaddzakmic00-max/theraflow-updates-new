import django.db.models.deletion
import django.utils.timezone
from django.db import migrations, models


def configure_known_stock_units(apps, schema_editor):
    Medicine = apps.get_model("patients", "Lijek")
    for medicine in Medicine.objects.all():
        identity = " ".join(
            filter(
                None,
                [medicine.naziv, medicine.genericki_naziv, medicine.zasticeno_ime],
            )
        ).casefold()
        if any(value in identity for value in ("adalimumab", "hyrimoz")):
            singular, plural = "pen", "penovi"
        elif any(value in identity for value in ("ustekinumab", "stelara")):
            singular, plural = "šprica", "šprice"
        else:
            continue
        medicine.jedinica_zalihe = singular
        medicine.jedinica_zalihe_mnozina = plural
        medicine.save(
            update_fields=["jedinica_zalihe", "jedinica_zalihe_mnozina"]
        )


class Migration(migrations.Migration):
    dependencies = [("patients", "0067_patient_therapy_quantity")]

    operations = [
        migrations.AddField(
            model_name="lijek",
            name="jedinica_zalihe",
            field=models.CharField(
                default="doza",
                max_length=40,
                verbose_name="Jedinica zalihe (jednina)",
            ),
        ),
        migrations.AddField(
            model_name="lijek",
            name="jedinica_zalihe_mnozina",
            field=models.CharField(
                default="doze",
                max_length=40,
                verbose_name="Jedinica zalihe (množina)",
            ),
        ),
        migrations.AlterField(
            model_name="pacijentzaduzenje",
            name="datum_zaduzenja",
            field=models.DateField(
                blank=True,
                default=django.utils.timezone.localdate,
                null=True,
            ),
        ),
        migrations.AddField(
            model_name="pacijentzaduzenje",
            name="migracijski_snapshot",
            field=models.OneToOneField(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="pocetno_kucno_zaduzenje",
                to="patients.migracijskisnapshotpacijenta",
            ),
        ),
        migrations.RunPython(configure_known_stock_units, migrations.RunPython.noop),
    ]
