import json

from django.core.management.base import BaseCommand

from patients.commission_planning import reconcile_active_commission_drafts


class Command(BaseCommand):
    help = (
        "Usklađuje samo aktivne redovne komisijske nacrte sa kanonskim "
        "prijedlogom i čuva eksplicitne ručne overridee."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--commit",
            action="store_true",
            help="Primijeni promjene. Bez ove opcije radi read-only provjeru.",
        )

    def handle(self, *args, **options):
        report = reconcile_active_commission_drafts(
            commit=options["commit"],
        )
        self.stdout.write(
            json.dumps(report, default=str, ensure_ascii=False, indent=2)
        )
        if options["commit"]:
            self.stdout.write(self.style.SUCCESS("Reconciliation je primijenjen."))
        else:
            self.stdout.write(
                self.style.WARNING(
                    "Dry-run: baza nije izmijenjena. Dodajte --commit za primjenu."
                )
            )
