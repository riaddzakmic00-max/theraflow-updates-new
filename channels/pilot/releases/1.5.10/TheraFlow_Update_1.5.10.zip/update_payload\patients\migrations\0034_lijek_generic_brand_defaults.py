from django.db import migrations


DEFAULT_NAMES = [
    (["remsima"], "Remsima", "Infliximab"),
    (["infliximab"], "Remsima", "Infliximab"),
    (["entyvio"], "Entyvio", "Vedolizumab"),
    (["vedolizumab"], "Entyvio", "Vedolizumab"),
    (["adalimumab"], "Adalimumab", "Adalimumab"),
]


def fill_lijek_names(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")

    for lijek in Lijek.objects.all():
        naziv = (lijek.naziv or "").lower()
        for keys, brand, generic in DEFAULT_NAMES:
            if any(key in naziv for key in keys):
                if not lijek.zasticeno_ime:
                    lijek.zasticeno_ime = brand
                if not lijek.genericki_naziv:
                    lijek.genericki_naziv = generic
                lijek.save(update_fields=["zasticeno_ime", "genericki_naziv"])
                break


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0033_default_therapeutic_protocols"),
    ]

    operations = [
        migrations.RunPython(fill_lijek_names, migrations.RunPython.noop),
    ]
