from django.contrib import admin
from django.contrib import messages
from decimal import Decimal
from .models import (
    AdaptiveDecisionRecord,
    AdaptiveInsight,
    Pacijent,
    Lijek,
    Komisija,
    KucnoIzdavanje,
    IzdavanjeOralneTerapije,
    OralniTerapijskiRezim,
    StandardniOralniRezim,
    IndividualniProtokolPacijenta,
    IndividualniKorakProtokola,
    IzmjenaIndividualnogProtokola,
    PacijentZaduzenje,
    OperationalOutcome,
    PacijentRezervacija,
    PotrebaFizickogPokrica,
    Termin,
    Terapija,
    Zaliha,
    DokumentSablon,
    DokumentPacijenta,
    AktivnostLog,
    KomisijskiRucniUnos,
    KomisijskiCiklus,
    KomisijskiZahtjev,
    KomisijskaStavkaLijeka,
    KomisijskaSaglasnost,
    FazniProtokolPacijenta,
    Trebovanje,
    Ljekar,
    LogistickePostavkeLijeka,
    PromjenaTerapije,
    TerapijskiProtokol,
    TerapijskiKorakProtokola,
    TerapijskaFaza,
    TerapijskiProgram,
    ZalihaTransakcija,
)
from .standard_protocols import load_standard_protocol_for_lijek
from .scheduling import weekend_appointments_queryset


@admin.register(Pacijent)
class PacijentAdmin(admin.ModelAdmin):
    list_display = (
        "ime",
        "prezime",
        "jmbg",
        "lijek",
        "terapijski_protokol",
        "pocetna_faza_terapije",
        "kolicina_po_terapiji",
        "aktivan",
    )

    search_fields = (
        "ime",
        "prezime",
        "jmbg",
    )

    list_filter = (
        "lijek",
        "terapijski_protokol",
        "pocetna_faza_terapije",
        "aktivan",
    )


class IzmjenaIndividualnogProtokolaInline(admin.TabularInline):
    model = IzmjenaIndividualnogProtokola
    extra = 0
    can_delete = False
    readonly_fields = (
        "datum_izmjene",
        "korisnik",
        "razlog",
        "prethodno_stanje",
        "novo_stanje",
    )

    def has_add_permission(self, request, obj=None):
        return False


class IndividualniKorakProtokolaInline(admin.TabularInline):
    model = IndividualniKorakProtokola
    extra = 0
    fields = (
        "faza",
        "redoslijed",
        "sedmica_od_pocetka",
        "doza_mg",
        "broj_jedinica",
        "interval_sedmica",
        "nacin_primjene",
    )


@admin.register(IndividualniProtokolPacijenta)
class IndividualniProtokolPacijentaAdmin(admin.ModelAdmin):
    list_display = (
        "pacijent",
        "naziv",
        "interval_odrzavanja_sedmica",
        "sigurnosna_rezerva_primjena",
        "maksimalna_sigurnosna_rezerva_primjena",
        "mjesto_primjene",
        "aktivan",
        "datum_izmjene",
    )
    list_filter = ("aktivan", "mjesto_primjene")
    search_fields = ("pacijent__ime", "pacijent__prezime", "naziv")
    readonly_fields = (
        "pacijent",
        "standardni_protokol",
        "kreirao",
        "izmijenio",
        "datum_kreiranja",
        "datum_izmjene",
    )
    inlines = [IndividualniKorakProtokolaInline, IzmjenaIndividualnogProtokolaInline]


@admin.register(IzmjenaIndividualnogProtokola)
class IzmjenaIndividualnogProtokolaAdmin(admin.ModelAdmin):
    list_display = ("protokol", "korisnik", "datum_izmjene", "razlog")
    readonly_fields = (
        "protokol",
        "korisnik",
        "datum_izmjene",
        "datum_odluke",
        "ljekar_koji_je_donio_odluku",
        "povezani_dokument",
        "razlog",
        "prethodno_stanje",
        "novo_stanje",
    )

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(AktivnostLog)
class AktivnostLogAdmin(admin.ModelAdmin):
    list_display = (
        "datum_vrijeme",
        "korisnik",
        "akcija",
        "pacijent",
        "objekat_tip",
        "objekat_id",
)

    search_fields = (
        "korisnik__username",
        "akcija",
        "opis",
        "pacijent__ime",
        "pacijent__prezime",
    )

    list_filter = (
        "akcija",
        "datum_vrijeme",
    )

    readonly_fields = (
        "datum_vrijeme",
        "korisnik",
        "akcija",
        "pacijent",
        "objekat_tip",
        "objekat_id",
        "opis",
    )

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class TerapijskiKorakProtokolaInline(admin.TabularInline):
    model = TerapijskiKorakProtokola
    extra = 1
    ordering = ("redoslijed", "sedmica_od_pocetka")
    fields = (
        "naziv_koraka",
        "faza",
        "sedmica_od_pocetka",
        "redoslijed",
        "doza_mg",
        "broj_jedinica",
        "interval_sedmica",
        "nacin_primjene_koraka",
        "aktivan",
    )


@admin.register(TerapijskiProtokol)
class TerapijskiProtokolAdmin(admin.ModelAdmin):
    change_form_template = "admin/patients/terapijskiprotokol/change_form.html"
    actions = ["ucitaj_standardni_protokol"]

    list_display = (
        "naziv",
        "lijek",
        "tip_terapije",
        "indukcijske_sedmice",
        "interval_odrzavanja_sedmica",
        "doza_po_aplikaciji",
        "sigurnosna_rezerva_primjena",
        "maksimalna_sigurnosna_rezerva_primjena",
        "aktivan",
    )

    list_filter = (
        "tip_terapije",
        "aktivan",
        "lijek",
    )

    search_fields = (
        "naziv",
        "lijek__naziv",
        "napomena",
    )
    inlines = [TerapijskiKorakProtokolaInline]

    def response_change(self, request, obj):
        if "_load_standard_protocol" in request.POST:
            return self._load_standard_and_return(request, obj)
        return super().response_change(request, obj)

    def response_add(self, request, obj, post_url_continue=None):
        if "_load_standard_protocol" in request.POST:
            return self._load_standard_and_return(request, obj)
        return super().response_add(request, obj, post_url_continue)

    def _load_standard_and_return(self, request, obj):
        protokol, created, koraci_count = load_standard_protocol_for_lijek(
            obj.lijek,
            protokol=obj,
        )

        if protokol:
            messages.success(
                request,
                f"Učitan standardni protokol za {obj.lijek.naziv}. Novih koraka: {koraci_count}."
            )
        else:
            messages.warning(
                request,
                f"Ne postoji standardni protokol za lijek {obj.lijek.naziv}."
            )

        return super().response_change(request, obj)

    @admin.action(description="Učitaj standardni protokol")
    def ucitaj_standardni_protokol(self, request, queryset):
        updated = 0
        skipped = 0

        for protokol in queryset.select_related("lijek"):
            result, created, koraci_count = load_standard_protocol_for_lijek(
                protokol.lijek,
                protokol=protokol,
            )
            if result:
                updated += 1
            else:
                skipped += 1

        if updated:
            self.message_user(
                request,
                f"Učitan standardni protokol za {updated} protokola.",
                messages.SUCCESS,
            )
        if skipped:
            self.message_user(
                request,
                f"Preskočeno {skipped} protokola bez standardne definicije.",
                messages.WARNING,
            )


@admin.register(TerapijskiKorakProtokola)
class TerapijskiKorakProtokolaAdmin(admin.ModelAdmin):
    list_display = (
        "protokol",
        "naziv_koraka",
        "faza",
        "sedmica_od_pocetka",
        "redoslijed",
        "doza_mg",
        "broj_jedinica",
        "interval_sedmica",
        "nacin_primjene_koraka",
        "aktivan",
    )
    list_filter = (
        "faza",
        "nacin_primjene_koraka",
        "aktivan",
        "protokol__lijek",
    )
    search_fields = (
        "naziv_koraka",
        "protokol__naziv",
        "protokol__lijek__naziv",
    )
    ordering = ("protokol", "redoslijed", "sedmica_od_pocetka")


@admin.register(Lijek)
class LijekAdmin(admin.ModelAdmin):
    list_display = ("prikaz_naziv", "terapijski_program", "naziv", "aktivan", "genericki_naziv", "zasticeno_ime", "package_size_in_doses", "jedinica_terapije", "jedinica_zalihe", "dozvoljava_decimalnu_kolicinu", "nacin_primjene", "kucna_primjena")
    list_filter = ("aktivan", "nacin_primjene", "kucna_primjena")
    search_fields = ("naziv", "genericki_naziv", "zasticeno_ime")


class TerapijskaFazaInline(admin.TabularInline):
    model = TerapijskaFaza
    extra = 0


@admin.register(TerapijskiProgram)
class TerapijskiProgramAdmin(admin.ModelAdmin):
    list_display = (
        "naziv",
        "kljuc",
        "aktivan",
        "commission_program_type",
        "protokol_kljuc",
        "default_lijek",
    )
    list_filter = ("aktivan", "commission_program_type", "protokol_kljuc")
    search_fields = ("naziv", "kljuc")
    inlines = (TerapijskaFazaInline,)


@admin.register(LogistickePostavkeLijeka)
class LogistickePostavkeLijekaAdmin(admin.ModelAdmin):
    list_display = (
        "lijek",
        "ciljni_broj_dana_pokrivenosti",
        "prosjecno_trajanje_odobrenja_komisije_dana",
        "prosjecno_trajanje_dostave_lijeka_dana",
        "sigurnosna_rezerva_dana",
        "sigurnosna_rezerva_primjena",
        "maksimalna_sigurnosna_rezerva_primjena",
        "maksimalni_rok_potrosnje_dana",
    )
    search_fields = ("lijek__naziv", "lijek__genericki_naziv", "lijek__zasticeno_ime")
admin.site.register(Komisija)
admin.site.register(PacijentZaduzenje)


class InventoryAllocationReadOnlyAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(PacijentRezervacija)
class PacijentRezervacijaAdmin(InventoryAllocationReadOnlyAdmin):
    list_display = (
        "pacijent",
        "lijek",
        "kolicina",
        "aktivno",
        "termin",
        "datum_rezervacije",
    )
    list_filter = ("aktivno", "lijek")
    search_fields = (
        "pacijent__ime",
        "pacijent__prezime",
        "pacijent__jmbg",
        "lijek__naziv",
    )


@admin.register(PotrebaFizickogPokrica)
class PotrebaFizickogPokricaAdmin(InventoryAllocationReadOnlyAdmin):
    list_display = (
        "pacijent",
        "lijek",
        "preostala_kolicina",
        "status",
        "prioritet_datum",
        "kreirano",
    )
    list_filter = ("status", "lijek")
    search_fields = (
        "pacijent__ime",
        "pacijent__prezime",
        "pacijent__jmbg",
        "lijek__naziv",
    )


@admin.register(KucnoIzdavanje)
class KucnoIzdavanjeAdmin(admin.ModelAdmin):
    list_display = ("datum", "pacijent", "lijek", "kolicina", "serija", "komisija", "korisnik_koji_je_izdao")
    list_filter = ("lijek", "datum")
    search_fields = ("pacijent__ime", "pacijent__prezime", "pacijent__jmbg", "serija")


@admin.register(OralniTerapijskiRezim)
class OralniTerapijskiRezimAdmin(admin.ModelAdmin):
    list_display = (
        "pacijent",
        "lijek",
        "tableta_po_uzimanju",
        "uzimanja_dnevno",
        "faza",
        "datum_od",
        "aktivan",
        "potvrdio",
    )
    list_filter = ("aktivan", "faza", "lijek")
    search_fields = (
        "pacijent__ime",
        "pacijent__prezime",
        "pacijent__jmbg",
        "lijek__naziv",
    )


@admin.register(StandardniOralniRezim)
class StandardniOralniRezimAdmin(admin.ModelAdmin):
    list_display = (
        "naziv",
        "lijek",
        "tableta_po_uzimanju",
        "uzimanja_dnevno",
        "faza",
        "aktivan",
        "izvor_konfiguracije",
    )
    list_filter = ("aktivan", "faza", "lijek")
    search_fields = (
        "naziv",
        "lijek__naziv",
        "lijek__genericki_naziv",
        "lijek__zasticeno_ime",
    )


@admin.register(IzdavanjeOralneTerapije)
class IzdavanjeOralneTerapijeAdmin(admin.ModelAdmin):
    list_display = (
        "datum_izdavanja",
        "pacijent",
        "lijek",
        "kolicina_tableta",
        "pokrivenost_od",
        "pokrivenost_do",
        "status",
        "korisnik_koji_je_izdao",
    )
    list_filter = ("status", "lijek", "datum_izdavanja")
    search_fields = (
        "pacijent__ime",
        "pacijent__prezime",
        "pacijent__jmbg",
        "serija",
        "broj_saglasnosti_snapshot",
    )
    readonly_fields = (
        "pokrivenost_od",
        "pokrivenost_do",
        "sljedeci_nepokriveni_datum",
        "pokrivenost_dana",
        "jacina_mg_snapshot",
        "tableta_po_uzimanju_snapshot",
        "uzimanja_dnevno_snapshot",
        "tableta_dnevno_snapshot",
        "odobreno_preostalo_prije",
        "odobreno_preostalo_poslije",
        "idempotency_key",
        "kreirano",
    )
admin.site.register(PromjenaTerapije)
class WeekendAppointmentFilter(admin.SimpleListFilter):
    title = "dozvoljeni radni dan"
    parameter_name = "radni_dan"

    def lookups(self, request, model_admin):
        return (
            ("invalid", "Van dozvoljenih dana"),
            ("valid", "Radni dan"),
        )

    def queryset(self, request, queryset):
        weekend = weekend_appointments_queryset(queryset)
        if self.value() == "invalid":
            return weekend
        if self.value() == "valid":
            return queryset.exclude(pk__in=weekend.values("pk"))
        return queryset


@admin.register(Termin)
class TerminAdmin(admin.ModelAdmin):
    list_display = (
        "datum",
        "vrijeme",
        "pacijent",
        "lijek",
        "status",
        "validnost_datuma",
    )
    list_filter = (WeekendAppointmentFilter, "status", "lijek")
    search_fields = (
        "pacijent__ime",
        "pacijent__prezime",
        "pacijent__jmbg",
        "lijek__naziv",
    )
    ordering = ("datum", "vrijeme")

    @admin.display(description="Validacija")
    def validnost_datuma(self, obj):
        return (
            "Van dozvoljenih dana"
            if obj.datum.weekday() >= 5
            else "Radni dan"
        )
admin.site.register(DokumentSablon)


@admin.register(Zaliha)
class ZalihaAdmin(admin.ModelAdmin):
    list_display = ("lijek", "u_frizideru", "kod_pacijenata", "ukupno_zaduzeno", "minimum")
    fields = ("lijek", "u_frizideru", "kod_pacijenata", "minimum")
    search_fields = ("lijek__naziv",)

    def save_model(self, request, obj, form, change):
        if change:
            stara = Zaliha.objects.get(pk=obj.pk)
            prije = (
                f"frižider {stara.u_frizideru}, "
                f"kod pacijenata/kućna terapija {stara.kod_pacijenata}, "
                f"minimum {stara.minimum}"
            )
        else:
            prije = "nova zaliha"

        super().save_model(request, obj, form, change)

        if change:
            delta_frizider = Decimal(str(obj.u_frizideru or 0)) - Decimal(str(stara.u_frizideru or 0))
        else:
            delta_frizider = Decimal(str(obj.u_frizideru or 0))
        if delta_frizider:
            ZalihaTransakcija.objects.create(
                lijek=obj.lijek,
                tip=ZalihaTransakcija.TIP_KOREKCIJA,
                kolicina=delta_frizider,
                korisnik=request.user if request.user.is_authenticated else None,
                referenca_tip="Zaliha",
                referenca_id=obj.id,
                napomena="Rucna korekcija zalihe kroz Django admin.",
            )

        AktivnostLog.objects.create(
            korisnik=request.user if request.user.is_authenticated else None,
            akcija="Ručna korekcija zalihe",
            objekat_tip="Zaliha",
            objekat_id=obj.id,
            opis=(
                f"{obj.lijek.naziv}: {prije} → "
                f"frižider {obj.u_frizideru}, "
                f"kod pacijenata/kućna terapija {obj.kod_pacijenata}, "
                f"minimum {obj.minimum}."
            ),
        )


@admin.register(ZalihaTransakcija)
class ZalihaTransakcijaAdmin(admin.ModelAdmin):
    list_display = ("datum", "lijek", "tip", "kolicina", "pacijent", "komisija", "korisnik")
    list_filter = ("tip", "datum", "lijek")
    search_fields = (
        "lijek__naziv",
        "pacijent__ime",
        "pacijent__prezime",
        "pacijent__jmbg",
        "napomena",
    )
    readonly_fields = ("kreirano",)


@admin.register(DokumentPacijenta)
class DokumentPacijentaAdmin(admin.ModelAdmin):
    list_display = (
        "naziv",
        "pacijent",
        "tip_dokumenta",
        "datum_dokumenta",
        "datum_uploada",
        "uploaded_by",
        "aktivan",
    )
    list_filter = (
        "tip_dokumenta",
        "aktivan",
        "datum_uploada",
    )
    search_fields = (
        "naziv",
        "pacijent__ime",
        "pacijent__prezime",
        "pacijent__jmbg",
        "napomena",
    )
    readonly_fields = (
        "datum_uploada",
        "uploaded_by",
    )

@admin.register(Terapija)
class TerapijaAdmin(admin.ModelAdmin):
    list_display = (
        "pacijent",
        "lijek",
        "datum",
        "kolicina",
        "faza_terapije",
        "doza_mg",
        "zakljucana",
    )

    list_filter = (
        "lijek",
        "datum",
        "zakljucana",
    )

    search_fields = (
        "pacijent__ime",
        "pacijent__prezime",
        "lijek__naziv",
        "serija",
    )

    readonly_fields = (
        "pacijent",
        "lijek",
        "datum",
        "serija",
        "kolicina",
        "faza_terapije",
        "doza_mg",
        "nuspojave",
        "laboratorija",
        "zakljucana",
    )

    def has_delete_permission(self, request, obj=None):
        if obj and obj.zakljucana:
            return False
        return super().has_delete_permission(request, obj)


@admin.register(Trebovanje)
class TrebovanjeAdmin(admin.ModelAdmin):
    list_display = (
        "pacijent",
        "lijek",
        "broj_doza",
        "datum_kreiranja",
        "status",
    )

    list_filter = (
        "status",
        "lijek",
        "datum_kreiranja",
    )

    search_fields = (
        "pacijent__ime",
        "pacijent__prezime",
        "lijek__naziv",
    )


@admin.register(KomisijskiRucniUnos)
class KomisijskiRucniUnosAdmin(admin.ModelAdmin):
    list_display = (
        "pacijent",
        "lijek",
        "sistemski_prijedlog",
        "ljekar_trazi",
        "korisnik",
        "izmijenjeno",
    )
    list_filter = ("lijek", "izmijenjeno")
    search_fields = ("pacijent__ime", "pacijent__prezime", "razlog")
    readonly_fields = ("izmijenjeno",)


class KomisijskaStavkaLijekaInline(admin.TabularInline):
    model = KomisijskaStavkaLijeka
    extra = 1
    ordering = ("redoslijed",)


class KomisijskaSaglasnostInline(admin.StackedInline):
    model = KomisijskaSaglasnost
    extra = 0
    max_num = 1


@admin.register(KomisijskiCiklus)
class KomisijskiCiklusAdmin(admin.ModelAdmin):
    list_display = ("naziv", "mjesec", "godina", "tip_ciklusa", "status")
    list_filter = ("status", "tip_ciklusa", "godina", "mjesec")
    search_fields = ("naziv", "napomena")
    readonly_fields = ("created_at", "updated_at")


@admin.register(KomisijskiZahtjev)
class KomisijskiZahtjevAdmin(admin.ModelAdmin):
    list_display = (
        "pacijent",
        "komisijski_ciklus",
        "vrsta_zahtjeva",
        "program_type",
        "request_purpose",
        "system_suggested_purpose",
        "status",
        "datum_kreiranja",
    )
    list_filter = (
        "program_type",
        "request_purpose",
        "system_suggested_purpose",
        "vrsta_zahtjeva",
        "status",
        "komisijski_ciklus",
    )
    search_fields = (
        "pacijent__ime",
        "pacijent__prezime",
        "pacijent__jmbg",
        "napomena",
    )
    readonly_fields = (
        "datum_kreiranja",
        "vrsta_zahtjeva",
        "program_type",
        "request_purpose",
        "system_suggested_purpose",
        "classification_reason_code",
        "classification_reason",
        "source_therapy_change",
        "final_user_decision",
        "request_type_override_reason",
        "request_type_finalized_by",
        "request_type_finalized_at",
        "document_package_key",
        "document_requirements_snapshot",
    )
    inlines = (KomisijskaStavkaLijekaInline, KomisijskaSaglasnostInline)


@admin.register(KomisijskaStavkaLijeka)
class KomisijskaStavkaLijekaAdmin(admin.ModelAdmin):
    list_display = (
        "komisijski_zahtjev",
        "lijek",
        "jacina",
        "kolicina",
        "odobrena_kolicina",
        "jedinica",
        "redoslijed",
    )
    list_filter = ("jedinica", "lijek")
    search_fields = (
        "komisijski_zahtjev__pacijent__ime",
        "komisijski_zahtjev__pacijent__prezime",
        "genericki_naziv",
        "zasticeni_naziv",
        "jacina",
    )


@admin.register(KomisijskaSaglasnost)
class KomisijskaSaglasnostAdmin(admin.ModelAdmin):
    list_display = (
        "broj_saglasnosti",
        "komisijski_zahtjev",
        "datum_saglasnosti",
        "odluka",
    )
    list_filter = ("odluka", "datum_saglasnosti")
    search_fields = (
        "broj_saglasnosti",
        "komisijski_zahtjev__pacijent__ime",
        "komisijski_zahtjev__pacijent__prezime",
    )
    readonly_fields = ("created_at", "updated_at")


@admin.register(FazniProtokolPacijenta)
class FazniProtokolPacijentaAdmin(admin.ModelAdmin):
    list_display = (
        "pacijent",
        "protokol_kljuc",
        "faza",
        "iv_lijek",
        "sc_lijek",
        "interval_odrzavanja_sedmica",
        "sljedeci_datum",
        "aktivan",
    )
    list_filter = ("protokol_kljuc", "faza", "interval_odrzavanja_sedmica", "aktivan")
    search_fields = ("pacijent__ime", "pacijent__prezime", "pacijent__jmbg")
    readonly_fields = ("kreirano", "izmijenjeno")

admin.site.register(Ljekar)


class ObservationReadOnlyAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(AdaptiveDecisionRecord)
class AdaptiveDecisionRecordAdmin(ObservationReadOnlyAdmin):
    list_display = (
        "created_at",
        "decision_type",
        "patient",
        "medicine",
        "override_reason",
        "user",
        "algorithm_version",
    )
    list_filter = ("decision_type", "override_reason", "medicine", "created_at")


@admin.register(OperationalOutcome)
class OperationalOutcomeAdmin(ObservationReadOnlyAdmin):
    list_display = (
        "commission_cycle",
        "medicine",
        "expected_delivery_date",
        "actual_delivery_date",
        "actual_lead_time_days",
    )


@admin.register(AdaptiveInsight)
class AdaptiveInsightAdmin(ObservationReadOnlyAdmin):
    list_display = (
        "generated_at",
        "insight_type",
        "medicine",
        "sample_size",
        "confidence_level",
        "status",
    )
