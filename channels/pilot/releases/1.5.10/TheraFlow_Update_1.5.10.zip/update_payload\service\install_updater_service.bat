@echo off
setlocal EnableExtensions

set "SERVICE_NAME=TheraFlowUpdaterService"
set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%..\..") do set "INSTALL_ROOT=%%~fI"
set "APP_ROOT=%INSTALL_ROOT%\app"
set "PROGRAM_DATA=%ProgramData%\TheraFlow"
set "PYTHON_EXE=%PROGRAM_DATA%\runtime\venv\Scripts\python.exe"
set "SERVICE_SCRIPT=%APP_ROOT%\updates\updater_service.py"
set "ENV_FILE=%PROGRAM_DATA%\config\.env"
set "KEY_FILE=%PROGRAM_DATA%\config\updater_service.key"
set "REQUEST_DIR=%PROGRAM_DATA%\updates\service_requests"
set "LOG_DIR=%PROGRAM_DATA%\logs"
set "INSTALLER_LOG=%LOG_DIR%\install_runtime.log"
set "STDOUT_LOG=%LOG_DIR%\updater_service_stdout.log"
set "STDERR_LOG=%LOG_DIR%\updater_service_stderr.log"
set "NSSM_EXE=%INSTALL_ROOT%\runtime\nssm\nssm.exe"

if not exist "%PYTHON_EXE%" exit /b 1
if not exist "%SERVICE_SCRIPT%" exit /b 1
if not exist "%ENV_FILE%" exit /b 1
if not exist "%NSSM_EXE%" exit /b 1
if not exist "%REQUEST_DIR%" mkdir "%REQUEST_DIR%" >nul 2>&1
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1

if not exist "%KEY_FILE%" (
  powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "$b=New-Object byte[] 48; $r=[Security.Cryptography.RandomNumberGenerator]::Create(); try{$r.GetBytes($b)}finally{$r.Dispose()}; [IO.File]::WriteAllText('%KEY_FILE%', [Convert]::ToBase64String($b), [Text.UTF8Encoding]::new($false))" >> "%INSTALLER_LOG%" 2>&1
  if errorlevel 1 exit /b 1
)

icacls "%KEY_FILE%" /inheritance:r /grant:r "*S-1-5-18:(F)" "*S-1-5-32-544:(F)" >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1
icacls "%REQUEST_DIR%" /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)(F)" "*S-1-5-32-544:(OI)(CI)(F)" >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1

sc query "%SERVICE_NAME%" >nul 2>&1
if not errorlevel 1 (
  sc qc "%SERVICE_NAME%" | findstr /I /L /C:"%NSSM_EXE%" >nul 2>&1
  if errorlevel 1 exit /b 1
  "%NSSM_EXE%" stop "%SERVICE_NAME%" >> "%INSTALLER_LOG%" 2>&1
) else (
  "%NSSM_EXE%" install "%SERVICE_NAME%" "%PYTHON_EXE%" >> "%INSTALLER_LOG%" 2>&1
  if errorlevel 1 exit /b 1
)

call :nssm_set Application "%PYTHON_EXE%"
if errorlevel 1 exit /b 1
call :nssm_set AppDirectory "%APP_ROOT%"
if errorlevel 1 exit /b 1
call :nssm_set AppParameters "updates\updater_service.py"
if errorlevel 1 exit /b 1
call :nssm_set DisplayName "TheraFlow Update Service"
if errorlevel 1 exit /b 1
call :nssm_set Description "Executes only signed and verified TheraFlow update sessions."
if errorlevel 1 exit /b 1
call :nssm_set Start SERVICE_AUTO_START
if errorlevel 1 exit /b 1
call :nssm_set ObjectName LocalSystem
if errorlevel 1 exit /b 1
call :nssm_set AppStdout "%STDOUT_LOG%"
if errorlevel 1 exit /b 1
call :nssm_set AppStderr "%STDERR_LOG%"
if errorlevel 1 exit /b 1
"%NSSM_EXE%" set "%SERVICE_NAME%" AppEnvironmentExtra "THERAFLOW_PRODUCTION=1" "THERAFLOW_ENV_FILE=%ENV_FILE%" "PYTHONUNBUFFERED=1" >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1
"%NSSM_EXE%" set "%SERVICE_NAME%" AppExit Default Restart >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1
sc.exe config "%SERVICE_NAME%" start= auto DisplayName= "TheraFlow Update Service" >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1
sc.exe failure "%SERVICE_NAME%" reset= 86400 actions= restart/5000/restart/15000/""/0 >> "%INSTALLER_LOG%" 2>&1
if errorlevel 1 exit /b 1
"%NSSM_EXE%" start "%SERVICE_NAME%" >> "%INSTALLER_LOG%" 2>&1

for /l %%I in (1,1,45) do (
  sc query "%SERVICE_NAME%" | find /I "RUNNING" >nul 2>&1
  if not errorlevel 1 exit /b 0
  timeout /t 1 /nobreak >nul
)
exit /b 1

:nssm_set
"%NSSM_EXE%" set "%SERVICE_NAME%" "%~1" "%~2" >> "%INSTALLER_LOG%" 2>&1
exit /b %ERRORLEVEL%
