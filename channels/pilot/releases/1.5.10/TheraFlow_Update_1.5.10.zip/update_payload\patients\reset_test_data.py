from pathlib import Path

from django.conf import settings
from django.db import transaction

from .models import (
    AdaptiveDecisionRecord,
    AdaptiveInsight,
    AktivnostLog,
    DokumentPacijenta,
    Komisija,
    KomisijskiCiklus,
    KucnoIzdavanje,
    IzdavanjeOralneTerapije,
    Pacijent,
    PacijentRezervacija,
    PacijentZaduzenje,
    OperationalOutcome,
    Terapija,
    Termin,
    Trebovanje,
    Zaliha,
    ZalihaTransakcija,
)
from .demo_reset import delete_demo_dataset


DEMO_JMBG_PREFIX = "990"
DEMO_EVENT_MARKER = "[THERAFLOW-DEMO]"
DEMO_MEDICINES = ["Entyvio", "Remsima", "Adalimumab", "Hyrimoz"]


RESET_MODELS = [
    ("adaptivnih odluka", AdaptiveDecisionRecord),
    ("operativnih ishoda", OperationalOutcome),
    ("adaptivnih uvida", AdaptiveInsight),
    ("dokumenata", DokumentPacijenta),
    ("kucnih izdavanja", KucnoIzdavanje),
    ("oralnih izdavanja", IzdavanjeOralneTerapije),
    ("rezervacija", PacijentRezervacija),
    ("terapija", Terapija),
    ("termina", Termin),
    ("zaduzenja", PacijentZaduzenje),
    ("komisija", Komisija),
    ("trebovanja", Trebovanje),
    ("komisijskih ciklusa / posiljki", KomisijskiCiklus),
    ("pacijenata", Pacijent),
]

STAT_ORDER = [
    "adaptivnih odluka",
    "operativnih ishoda",
    "adaptivnih uvida",
    "pacijenata",
    "terapija",
    "termina",
    "komisija",
    "trebovanja",
    "zaduzenja",
    "dokumenata",
    "kucnih izdavanja",
    "oralnih izdavanja",
    "rezervacija",
    "komisijskih ciklusa / posiljki",
]


def collect_reset_stats():
    return {
        label: model.objects.count()
        for label, model in RESET_MODELS
    }


def ordered_stats(stats):
    return {
        label: stats.get(label, 0)
        for label in STAT_ORDER
        if label in stats
    }


def _document_file_paths(patient_ids=None):
    media_root = Path(settings.MEDIA_ROOT).resolve()
    paths = []
    documents = DokumentPacijenta.objects.exclude(fajl="")
    if patient_ids is not None:
        documents = documents.filter(pacijent_id__in=patient_ids)

    for dokument in documents:
        try:
            path = Path(dokument.fajl.path).resolve()
        except Exception:
            continue

        if media_root in path.parents and "dokumenti_pacijenata" in path.parts:
            paths.append(path)

    return paths


def reset_test_data(delete_document_files=True):
    stats = ordered_stats(collect_reset_stats())
    document_paths = _document_file_paths() if delete_document_files else []

    with transaction.atomic():
        AdaptiveDecisionRecord.objects.filter(is_test_data=True).delete()
        OperationalOutcome.objects.filter(is_test_data=True).delete()
        AdaptiveInsight.objects.filter(is_test_data=True).delete()
        for label, model in RESET_MODELS:
            model.objects.all().delete()

    for path in document_paths:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass

    return stats


def collect_test_inventory_stats():
    test_pacijenti = Pacijent.objects.filter(jmbg__startswith=DEMO_JMBG_PREFIX)

    return {
        "testnih adaptivnih odluka": AdaptiveDecisionRecord.objects.filter(is_test_data=True).count(),
        "testnih zaduzenja": PacijentZaduzenje.objects.filter(pacijent__in=test_pacijenti).count(),
        "testnih rezervacija": PacijentRezervacija.objects.filter(pacijent__in=test_pacijenti).count(),
        "testnih kucnih izdavanja": KucnoIzdavanje.objects.filter(pacijent__in=test_pacijenti).count(),
        "testnih oralnih izdavanja": IzdavanjeOralneTerapije.objects.filter(pacijent__in=test_pacijenti).count(),
        "testnih terapija": Terapija.objects.filter(pacijent__in=test_pacijenti).count(),
        "testnih termina": Termin.objects.filter(pacijent__in=test_pacijenti).count(),
        "resetovanih fizickih zaliha": Zaliha.objects.count(),
        "obrisanih transakcija zaliha": ZalihaTransakcija.objects.count(),
    }


def reset_test_inventory():
    test_pacijenti = Pacijent.objects.filter(jmbg__startswith=DEMO_JMBG_PREFIX)
    stats = collect_test_inventory_stats()

    with transaction.atomic():
        AdaptiveDecisionRecord.objects.filter(is_test_data=True).delete()
        OperationalOutcome.objects.filter(is_test_data=True).delete()
        AdaptiveInsight.objects.filter(is_test_data=True).delete()
        KucnoIzdavanje.objects.filter(pacijent__in=test_pacijenti).delete()
        IzdavanjeOralneTerapije.objects.filter(pacijent__in=test_pacijenti).delete()
        PacijentRezervacija.objects.filter(pacijent__in=test_pacijenti).delete()
        PacijentZaduzenje.objects.filter(pacijent__in=test_pacijenti).delete()
        Terapija.objects.filter(pacijent__in=test_pacijenti).delete()
        Termin.objects.filter(pacijent__in=test_pacijenti).delete()
        ZalihaTransakcija.objects.all().delete()
        Zaliha.objects.all().update(
            ukupno=0,
            u_frizideru=0,
            kod_pacijenata=0,
        )

    return stats


def reset_demo_data(delete_document_files=True):
    """Ukloni samo legacy demo pacijente sa rezervisanim JMBG markerom."""

    return delete_demo_dataset(
        patient_queryset=Pacijent.objects.filter(
            jmbg__startswith=DEMO_JMBG_PREFIX
        ),
        cycle_queryset=KomisijskiCiklus.objects.filter(
            napomena__startswith=DEMO_EVENT_MARKER
        ),
        event_marker=DEMO_EVENT_MARKER,
        delete_document_files=delete_document_files,
    )
