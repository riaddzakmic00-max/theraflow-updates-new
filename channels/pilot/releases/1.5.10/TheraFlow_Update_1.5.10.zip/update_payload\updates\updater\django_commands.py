import os
import re
import subprocess
import getpass
import stat
from pathlib import Path

from .state_writer import trace_update_step


class DjangoCommandError(RuntimeError):
    def __init__(self, code, message, exit_code=None):
        self.code = code
        self.exit_code = exit_code
        super().__init__(message)


def canonical_env_file():
    program_data = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))
    return (program_data / "TheraFlow" / "config" / ".env").resolve()


def _process_identity():
    elevated = None
    if os.name == "nt":
        try:
            import ctypes

            elevated = bool(ctypes.windll.shell32.IsUserAnAdmin())
        except (AttributeError, OSError):
            elevated = None
    return getpass.getuser() or "unknown", elevated, os.getpid()


def _validate_env(path):
    try:
        parent_status = path.parent.stat()
    except FileNotFoundError as exc:
        raise DjangoCommandError("canonical_env_directory_not_found", f"Direktorij kanonske konfiguracije nije pronađen: {path.parent}", 1) from exc
    except PermissionError as exc:
        raise DjangoCommandError("canonical_env_unauthorized", f"Proces nema dozvolu za pristup direktoriju kanonske konfiguracije: {path.parent}", 1) from exc
    if not stat.S_ISDIR(parent_status.st_mode):
        raise DjangoCommandError("canonical_env_directory_not_found", f"Putanja kanonske konfiguracije nije direktorij: {path.parent}", 1)
    try:
        file_status = path.stat()
        if not stat.S_ISREG(file_status.st_mode):
            raise DjangoCommandError("canonical_env_invalid_content", "Kanonski produkcijski .env nije regularan fajl.", 1)
        text = path.read_text(encoding="utf-8-sig")
    except FileNotFoundError as exc:
        raise DjangoCommandError("canonical_env_file_not_found", f"Kanonski produkcijski .env nije pronađen: {path}", 1) from exc
    except PermissionError as exc:
        raise DjangoCommandError("canonical_env_unauthorized", f"Proces nema dozvolu za čitanje kanonskog produkcijskog .env: {path}", 1) from exc
    except UnicodeError as exc:
        raise DjangoCommandError("canonical_env_invalid_content", "Kanonski produkcijski .env nije validan UTF-8 tekst.", 1) from exc
    values = {}
    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise DjangoCommandError("canonical_env_invalid_content", f"Kanonski produkcijski .env ima neispravan red {line_number}.", 1)
        key, value = line.split("=", 1)
        key = key.strip()
        if not key:
            raise DjangoCommandError("canonical_env_invalid_content", f"Kanonski produkcijski .env ima prazan ključ u redu {line_number}.", 1)
        values[key] = value.strip()
    if not values.get("SECRET_KEY"):
        raise DjangoCommandError("canonical_env_invalid_content", "Kanonski produkcijski .env nema neprazan SECRET_KEY.", 1)
    return True


def clean_environment(env_file=None):
    allowed = ("SystemRoot", "WINDIR", "PATH", "PATHEXT", "COMSPEC", "TEMP", "TMP", "PROGRAMDATA")
    env = {key: os.environ[key] for key in allowed if key in os.environ}
    env_file = Path(env_file or canonical_env_file()).resolve()
    env.update({
        "DJANGO_SETTINGS_MODULE": "config.settings",
        "PYTHONUTF8": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "THERAFLOW_PRODUCTION": "1",
        "THERAFLOW_ENV_FILE": str(env_file),
    })
    return env


def safe_output(value):
    return re.sub(
        r"(?i)(password|secret_key|token)\s*[=:]\s*\S+",
        r"\1=[REDACTED]",
        value or "",
    )


def run_manage(plan, arguments, timeout=600):
    env_file = canonical_env_file()
    checked_paths = [env_file, Path(plan["application_root"]) / ".env"]
    identity, elevated, pid = _process_identity()
    try:
        _validate_env(env_file)
    except DjangoCommandError as error:
        trace_update_step(
            9,
            "FAIL",
            session_id=plan.get("session_id", "none"),
            function_name="updates.updater.django_commands.run_manage",
            paths={"canonical_env": env_file, "application_env_ignored": checked_paths[1]},
            exception=error,
            exit_code=1,
            message=f"process_identity={identity} elevated={elevated} pid={pid}",
            data_root=env_file.parents[1],
        )
        raise error

    child_env = clean_environment(env_file)
    command = [plan["python_executable"], str(Path(plan["application_root"]) / "manage.py"), *arguments]
    trace_update_step(
        9,
        "ENV",
        session_id=plan.get("session_id", "none"),
        function_name="updates.updater.django_commands.run_manage",
        paths={
            "canonical_env": env_file,
            "application_env_ignored": checked_paths[1],
            "manage_py": command[1],
            "working_directory": plan["application_root"],
        },
        message=(
            f"canonical_exists=true config_valid=true process_identity={identity} "
            f"elevated={elevated} pid={pid}"
        ),
        exit_code=0,
        data_root=env_file.parents[1],
    )
    result = subprocess.run(
        command, cwd=plan["application_root"], env=child_env,
        capture_output=True, text=True, check=False, timeout=timeout, shell=False,
    )
    output = safe_output((result.stdout or "") + "\n" + (result.stderr or ""))
    if result.returncode != 0:
        raise DjangoCommandError("django_command_failed", output or "Django komanda nije uspjela.", result.returncode)
    return {"exit_code": result.returncode, "output": output, "command": ["python", "manage.py", *arguments]}


def django_check(plan):
    try:
        return run_manage(plan, ["check", "--deploy"], timeout=180)
    except DjangoCommandError as exc:
        code = exc.code if exc.code.startswith("canonical_env_") else "django_check_failed"
        raise DjangoCommandError(code, str(exc), exc.exit_code) from exc


def migrate(plan, lock_path):
    lock_path = Path(lock_path)
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(descriptor)
    except FileExistsError as exc:
        raise DjangoCommandError("migration_locked", "Drugi migration proces je aktivan.") from exc
    try:
        try:
            migration_result = run_manage(
                plan, ["migrate", "--noinput"], timeout=900
            )
        except DjangoCommandError as exc:
            code = exc.code if exc.code.startswith("canonical_env_") else "migrations_failed"
            raise DjangoCommandError(code, str(exc), exc.exit_code) from exc
        try:
            gate_result = run_manage(plan, ["check_schema_gate"], timeout=300)
        except DjangoCommandError as exc:
            code = exc.code if exc.code.startswith("canonical_env_") else "schema_gate_failed"
            raise DjangoCommandError(code, str(exc), exc.exit_code) from exc
        migration_result["schema_gate_output"] = gate_result["output"]
        return migration_result
    finally:
        lock_path.unlink(missing_ok=True)


def collectstatic(plan):
    try:
        return run_manage(plan, ["collectstatic", "--noinput"], timeout=600)
    except DjangoCommandError as exc:
        code = exc.code if exc.code.startswith("canonical_env_") else "collectstatic_failed"
        raise DjangoCommandError(code, str(exc), exc.exit_code) from exc
