@echo off
setlocal EnableExtensions

set "SERVICE_NAME=TheraFlow"
set "UPDATER_SERVICE=TheraFlowUpdaterService"
set "BACKUP_SCHEDULER_SERVICE=TheraFlowBackupScheduler"
set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%..\..") do set "INSTALL_ROOT=%%~fI"
set "NSSM_EXE=%INSTALL_ROOT%\runtime\nssm\nssm.exe"

echo.
echo === TheraFlow Windows Service uninstall ===
echo.

if not exist "%NSSM_EXE%" (
    echo ERROR: NSSM nije pronadjen:
    echo "%NSSM_EXE%"
    exit /b 1
)

sc query "%BACKUP_SCHEDULER_SERVICE%" >nul 2>&1
if not errorlevel 1 (
    "%NSSM_EXE%" stop "%BACKUP_SCHEDULER_SERVICE%" >nul 2>&1
    "%NSSM_EXE%" remove "%BACKUP_SCHEDULER_SERVICE%" confirm >nul 2>&1
    if errorlevel 1 exit /b 1
)

sc query "%UPDATER_SERVICE%" >nul 2>&1
if not errorlevel 1 (
    echo Zaustavljam servis "%UPDATER_SERVICE%"...
    "%NSSM_EXE%" stop "%UPDATER_SERVICE%" >nul 2>&1
    for /l %%I in (1,1,45) do (
        sc query "%UPDATER_SERVICE%" | find /I "STOPPED" >nul 2>&1
        if not errorlevel 1 goto remove_updater_service
        timeout /t 1 /nobreak >nul
    )
    echo ERROR: Servis "%UPDATER_SERVICE%" se nije zaustavio.
    exit /b 1
)
goto updater_service_removed

:remove_updater_service
"%NSSM_EXE%" remove "%UPDATER_SERVICE%" confirm >nul 2>&1
if errorlevel 1 exit /b 1

:updater_service_removed

sc query "%SERVICE_NAME%" >nul 2>&1
if errorlevel 1 (
    echo Servis "%SERVICE_NAME%" nije instaliran.
    exit /b 0
)

echo Zaustavljam servis "%SERVICE_NAME%"...
"%NSSM_EXE%" stop "%SERVICE_NAME%" >nul 2>&1

for /l %%I in (1,1,45) do (
    sc query "%SERVICE_NAME%" | find /I "STOPPED" >nul 2>&1
    if not errorlevel 1 goto remove_service
    timeout /t 1 /nobreak >nul
)

echo ERROR: Servis "%SERVICE_NAME%" se nije zaustavio. Uklanjanje je prekinuto.
exit /b 1

:remove_service
echo Uklanjam servis "%SERVICE_NAME%"...
"%NSSM_EXE%" remove "%SERVICE_NAME%" confirm
if errorlevel 1 (
    echo ERROR: NSSM nije uspio ukloniti servis "%SERVICE_NAME%".
    exit /b 1
)

echo OK: Servis "%SERVICE_NAME%" je uklonjen.
exit /b 0
