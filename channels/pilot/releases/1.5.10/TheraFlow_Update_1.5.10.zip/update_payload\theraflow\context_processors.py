from django.conf import settings

from .branding import branding_context
from .version import __version__, version_label


def version_info(request):
    context = {
        "theraflow_version": __version__,
        "theraflow_version_label": version_label(),
    }
    context.update(
        branding_context(build=getattr(settings, "THERAFLOW_BUILD", ""))
    )
    context["theraflow_demo_weekend_appointments"] = bool(
        getattr(
            settings,
            "THERAFLOW_DEMO_ALLOW_WEEKEND_APPOINTMENTS",
            False,
        )
    )
    return context
