"""Read-only Phase 5 validation helpers for legacy/V2 comparison."""

from decimal import Decimal

from django.utils import timezone

from .commission_demand import calculate_patient_demands
from .commission_service import calculate_patient_commission_need
from .future_therapy_planning import active_patients_for_planning


def _difference_explanation(demand, legacy_data, legacy_quantity):
    new_quantity = demand.kolicina_koju_treba_traziti
    if new_quantity == legacy_quantity:
        return "Jednak rezultat nakon raspodjele po konkretnim datumima terapije."
    covered = (
        demand.kolicina_kod_pacijenta
        + demand.kolicina_rezervisana_u_frizideru
        + demand.kolicina_pokrivena_aktivnom_komisijom
        + demand.kolicina_odobrena_nedostavljena
        + demand.kolicina_vec_predata_komisiji
    )
    if new_quantity < legacy_quantity:
        legacy_target = legacy_data.get("pokrice_do")
        if legacy_target and legacy_target > demand.ciljni_datum:
            return (
                "Novi obračun koristi podešeni ciljni period do "
                f"{demand.ciljni_datum:%d/%m/%Y}, dok stari ciklus računa do "
                f"{legacy_target:%d/%m/%Y}; postojeće pokriće je raspoređeno "
                "po konkretnim datumima bez dvostrukog brojanja."
            )
        return (
            "Novi obračun je manji jer raspoređuje postojeće pokriće bez "
            f"dvostrukog brojanja (iskorišteno pokriće: {covered:g})."
        )
    return (
        "Novi obračun je veći jer je pronašao nepokrivene terapije do ciljnog "
        f"datuma {demand.ciljni_datum:%d/%m/%Y}."
    )


def compare_active_patient_demands(*, today=None):
    """Uporedi oba obračuna bez upisa ili promjene produkcijskog rezultata."""

    today = today or timezone.localdate()
    patients = list(active_patients_for_planning())
    demands = calculate_patient_demands(patients, today=today)
    rows = []
    for patient in patients:
        demand = demands.get(patient.pk)
        if demand is None:
            continue
        legacy_data = calculate_patient_commission_need(patient, today=today)
        legacy = Decimal(str(legacy_data.get("kolicina_za_komisiju", 0) or 0))
        new = demand.kolicina_koju_treba_traziti
        rows.append({
            "pacijent": patient,
            "lijek": patient.lijek,
            "stari_prijedlog": legacy,
            "novi_prijedlog": new,
            "razlika": new - legacy,
            "objasnjenje": _difference_explanation(demand, legacy_data, legacy),
            "prva_nepokrivena": demand.datum_prve_nepokrivene_terapije,
            "demand": demand,
        })
    return rows


def comparison_markdown(rows, *, generated_at=None):
    generated_at = generated_at or timezone.now()
    lines = [
        "# Poređenje starog i novog komisijskog obračuna",
        "",
        f"Generisano: {generated_at:%d/%m/%Y %H:%M}",
        "",
        "| Pacijent | Lijek | Stari prijedlog | Novi prijedlog | Razlika | Objašnjenje |",
        "|---|---|---:|---:|---:|---|",
    ]
    for row in rows:
        lines.append(
            "| {patient} | {medicine} | {old:g} | {new:g} | {difference:g} | {reason} |".format(
                patient=str(row["pacijent"]).replace("|", "\\|"),
                medicine=str(row["lijek"]).replace("|", "\\|"),
                old=row["stari_prijedlog"],
                new=row["novi_prijedlog"],
                difference=row["razlika"],
                reason=row["objasnjenje"].replace("|", "\\|"),
            )
        )
    if not rows:
        lines.append("| Nema aktivnih pacijenata | — | 0 | 0 | 0 | Nema podataka za poređenje. |")
    return "\n".join(lines) + "\n"
