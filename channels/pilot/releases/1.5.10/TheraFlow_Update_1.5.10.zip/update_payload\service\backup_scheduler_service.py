"""Install or repair the persistent TheraFlow backup scheduler service.

The module intentionally uses only the Python standard library because it is
executed during installation before the application service is considered
healthy.  The orchestration function is dependency-injected so lifecycle
ordering and failure behavior can be regression-tested without touching the
real Windows Service Control Manager.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


SERVICE_NAME = "TheraFlowBackupScheduler"
DISPLAY_NAME = "TheraFlow Backup Scheduler"
DATABASE_SERVICE = "TheraFlowPostgres"
STABLE_SECONDS = 15
START_TIMEOUT_SECONDS = 60
STOP_TIMEOUT_SECONDS = 60
HEARTBEAT_MAX_AGE_SECONDS = 120


def _safe_stderr(message: str) -> None:
    try:
        print(message, file=sys.stderr)
    except (OSError, ValueError):
        pass


class SchedulerServiceError(RuntimeError):
    pass


class SchedulerRestartDetected(SchedulerServiceError):
    pass


@dataclass(frozen=True)
class ServiceStatus:
    exists: bool
    state: str = "NOT_INSTALLED"
    pid: int = 0
    win32_exit_code: int = 0
    service_exit_code: int = 0


def _parse_number(output: str, label: str) -> int:
    match = re.search(rf"(?im)^\s*{re.escape(label)}\s*:\s*(\d+)", output)
    return int(match.group(1)) if match else 0


def parse_service_query(output: str, returncode: int = 0) -> ServiceStatus:
    if returncode == 1060 or "FAILED 1060" in output:
        return ServiceStatus(False)
    state_match = re.search(r"(?im)^\s*STATE\s*:\s*\d+\s+([A-Z_]+)", output)
    if returncode != 0 or not state_match:
        raise SchedulerServiceError("Windows service status could not be read.")
    return ServiceStatus(
        True,
        state_match.group(1).upper(),
        _parse_number(output, "PID"),
        _parse_number(output, "WIN32_EXIT_CODE"),
        _parse_number(output, "SERVICE_EXIT_CODE"),
    )


def reconcile_scheduler_service(controller) -> ServiceStatus:
    """Apply configuration while stopped, start once, then prove stability."""

    try:
        initial = controller.query()
        controller.log(
            "Scheduler initial state: "
            f"exists={initial.exists} state={initial.state} pid={initial.pid} "
            f"win32_exit={initial.win32_exit_code} "
            f"service_exit={initial.service_exit_code}"
        )
        if initial.exists:
            controller.ensure_owned()
            if initial.state != "STOPPED":
                controller.stop()
                controller.wait_for_state("STOPPED", STOP_TIMEOUT_SECONDS)
        else:
            controller.install()

        controller.configure()
        controller.ensure_database_running()
        controller.start_once()
        running = controller.wait_for_state("RUNNING", START_TIMEOUT_SECONDS)
        return controller.verify_stable(
            STABLE_SECONDS,
            expected_service_pid=running.pid,
        )
    except Exception:
        try:
            controller.collect_diagnostics()
        except Exception as diagnostics_error:
            _safe_controller_log(
                controller,
                "Scheduler diagnostics failed without replacing the original "
                f"installation error: {type(diagnostics_error).__name__}: "
                f"{diagnostics_error}",
            )
        raise


class WindowsSchedulerController:
    def __init__(self, script_path: Path):
        self.script_path = script_path.resolve()
        self.service_dir = self.script_path.parent
        self.install_root = self.service_dir.parent.parent
        self.app_root = self.install_root / "app"
        self.program_data = Path(
            os.environ.get("ProgramData", r"C:\ProgramData")
        ) / "TheraFlow"
        self.runtime_root = self.program_data / "runtime"
        self.python_exe = self.runtime_root / "venv" / "Scripts" / "python.exe"
        self.manage_py = self.app_root / "manage.py"
        self.env_file = self.program_data / "config" / ".env"
        self.log_dir = self.program_data / "logs" / "backup_scheduler"
        self.install_log = self.log_dir / "backup_scheduler_install.log"
        self.fallback_log = (
            Path(os.environ.get("TEMP", str(self.program_data / "runtime")))
            / "TheraFlow"
            / "backup_scheduler_install_fallback.log"
        )
        self.scheduler_log = self.log_dir / "backup_scheduler.log"
        self.stdout_log = self.log_dir / "backup_scheduler_stdout.log"
        self.stderr_log = self.log_dir / "backup_scheduler_stderr.log"
        self.nssm_exe = self.install_root / "runtime" / "nssm" / "nssm.exe"
        self.state_file = self._configured_state_file()

    def _configured_state_file(self) -> Path:
        default = self.program_data / "data" / "backup_scheduler_state.json"
        if not self.env_file.is_file():
            return default
        try:
            for raw_line in self.env_file.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines():
                line = raw_line.strip()
                if (
                    line
                    and not line.startswith("#")
                    and line.startswith("THERAFLOW_BACKUP_STATE=")
                ):
                    value = line.split("=", 1)[1].strip().strip("\"'")
                    if value:
                        configured = Path(value)
                        return (
                            configured
                            if configured.is_absolute()
                            else self.app_root / configured
                        )
        except OSError:
            pass
        return default

    @staticmethod
    def _append_log(path: Path, line: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as stream:
            stream.write(line)

    @staticmethod
    def _stderr(message: str) -> None:
        _safe_stderr(message)

    def log(self, message: str) -> bool:
        """Write diagnostics without ever becoming a service-install failure."""

        timestamp = datetime.now().astimezone().isoformat(timespec="milliseconds")
        line = f"[{timestamp}] {message}\n"
        failures = []
        for target in (self.install_log, self.fallback_log):
            try:
                self._append_log(target, line)
                return True
            except (PermissionError, OSError) as exc:
                failures.append(f"{target}: {type(exc).__name__}: {exc}")
        try:
            self._stderr(
                line.rstrip()
                + " [logging unavailable: "
                + "; ".join(failures)
                + "]"
            )
        except Exception:
            pass
        return False

    def _run(self, args, *, check=True, timeout=60):
        display = " ".join(str(item) for item in args)
        self.log(f"Service command: {display}")
        completed = subprocess.run(
            [str(item) for item in args],
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        combined = "\n".join(
            value.strip()
            for value in (completed.stdout, completed.stderr)
            if value and value.strip()
        )
        if combined:
            for line in combined.splitlines():
                self.log(f"Service command output: {line}")
        if check and completed.returncode != 0:
            raise SchedulerServiceError(
                f"Command failed with exit code {completed.returncode}: {display}"
            )
        return completed

    def validate_inputs(self) -> None:
        for path, label in (
            (self.python_exe, "private Python"),
            (self.manage_py, "manage.py"),
            (self.env_file, "canonical production .env"),
            (self.nssm_exe, "NSSM"),
        ):
            if not path.is_file():
                raise SchedulerServiceError(f"{label} does not exist: {path}")
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        self.stdout_log.touch(exist_ok=True)
        self.stderr_log.touch(exist_ok=True)
        self.log(
            "Scheduler executable and arguments: "
            f"{self.python_exe} manage.py run_backup_scheduler"
        )
        self.log(f"Scheduler working directory: {self.app_root}")
        self.log(f"Scheduler environment file: {self.env_file}")
        self.log("Scheduler Django settings: config.settings")

    def query(self, name=SERVICE_NAME) -> ServiceStatus:
        result = self._run(
            ["sc.exe", "queryex", name],
            check=False,
            timeout=15,
        )
        return parse_service_query(
            f"{result.stdout}\n{result.stderr}",
            result.returncode,
        )

    def ensure_owned(self) -> None:
        result = self._run(["sc.exe", "qc", SERVICE_NAME])
        normalized = f"{result.stdout}\n{result.stderr}".replace("/", "\\").lower()
        if str(self.nssm_exe).replace("/", "\\").lower() not in normalized:
            raise SchedulerServiceError(
                "Same-named backup scheduler service is not owned by TheraFlow."
            )

    def stop(self) -> None:
        state = self.query()
        self.log(f"Stopping scheduler from state {state.state}.")
        if state.state == "STOPPED":
            return
        if state.state == "STOP_PENDING":
            return
        if state.state == "START_PENDING":
            deadline = time.monotonic() + START_TIMEOUT_SECONDS
            while time.monotonic() < deadline:
                state = self.query()
                if state.state == "STOPPED":
                    return
                if state.state == "STOP_PENDING":
                    return
                if state.state not in {"START_PENDING", "CONTINUE_PENDING"}:
                    break
                time.sleep(1)
            else:
                raise SchedulerServiceError(
                    "Scheduler remained START_PENDING and could not be stopped."
                )
        result = self._run(
            ["sc.exe", "stop", SERVICE_NAME],
            check=False,
            timeout=30,
        )
        if result.returncode not in (0, 1062):
            raise SchedulerServiceError(
                f"Scheduler stop failed with exit code {result.returncode}."
            )

    def wait_for_state(self, expected: str, timeout: int) -> ServiceStatus:
        deadline = time.monotonic() + timeout
        last = None
        while time.monotonic() < deadline:
            last = self.query()
            if (
                last.state == expected
                and (expected != "RUNNING" or last.pid > 0)
            ):
                self.log(
                    f"Scheduler reached {expected}: pid={last.pid} "
                    f"win32_exit={last.win32_exit_code} "
                    f"service_exit={last.service_exit_code}"
                )
                return last
            if expected == "RUNNING" and last.state in {"PAUSED", "STOPPED"}:
                raise SchedulerServiceError(
                    f"Scheduler entered {last.state} before becoming stable."
                )
            time.sleep(1)
        raise SchedulerServiceError(
            f"Scheduler did not reach {expected}; last state="
            f"{last.state if last else 'UNKNOWN'}."
        )

    def install(self) -> None:
        self._run(
            [self.nssm_exe, "install", SERVICE_NAME, self.python_exe]
        )

    def _nssm_set(self, key: str, *values: str) -> None:
        self._run([self.nssm_exe, "set", SERVICE_NAME, key, *values])

    def configure(self) -> None:
        if self.query().state != "STOPPED":
            raise SchedulerServiceError(
                "NSSM parameters may only be changed while scheduler is STOPPED."
            )
        settings = (
            ("Application", str(self.python_exe)),
            ("AppDirectory", str(self.app_root)),
            ("AppParameters", "manage.py run_backup_scheduler"),
            ("DisplayName", DISPLAY_NAME),
            (
                "Description",
                "Runs scheduled PostgreSQL backups independently from "
                "the TheraFlow web application.",
            ),
            ("Start", "SERVICE_AUTO_START"),
            ("ObjectName", "LocalSystem"),
            ("DependOnService", DATABASE_SERVICE),
            ("AppStdout", str(self.stdout_log)),
            ("AppStderr", str(self.stderr_log)),
            ("AppRotateFiles", "1"),
            ("AppRotateOnline", "1"),
            ("AppRotateSeconds", "86400"),
            ("AppRotateBytes", "10485760"),
            ("AppThrottle", "1500"),
            ("AppRestartDelay", "5000"),
        )
        for key, value in settings:
            self._nssm_set(key, value)
        self._run(
            [
                self.nssm_exe,
                "set",
                SERVICE_NAME,
                "AppEnvironmentExtra",
                "THERAFLOW_PRODUCTION=1",
                f"THERAFLOW_ENV_FILE={self.env_file}",
                "DJANGO_SETTINGS_MODULE=config.settings",
                "PYTHONUNBUFFERED=1",
            ]
        )
        self._run(
            [self.nssm_exe, "set", SERVICE_NAME, "AppExit", "Default", "Restart"]
        )
        self._run(
            [
                "sc.exe",
                "config",
                SERVICE_NAME,
                "start=",
                "auto",
                "depend=",
                DATABASE_SERVICE,
                "DisplayName=",
                DISPLAY_NAME,
            ]
        )
        self._run(
            [
                "sc.exe",
                "failure",
                SERVICE_NAME,
                "reset=",
                "86400",
                "actions=",
                "restart/5000/restart/15000/restart/30000",
            ]
        )
        self._run(["sc.exe", "failureflag", SERVICE_NAME, "1"])
        self.log("All scheduler NSSM parameters were set while service was STOPPED.")

    def ensure_database_running(self) -> None:
        status = self.query(DATABASE_SERVICE)
        if not status.exists:
            raise SchedulerServiceError(
                f"Required database service {DATABASE_SERVICE} is missing."
            )
        if status.state != "RUNNING":
            self._run(["sc.exe", "start", DATABASE_SERVICE], check=False)
            deadline = time.monotonic() + START_TIMEOUT_SECONDS
            while time.monotonic() < deadline:
                status = self.query(DATABASE_SERVICE)
                if status.state == "RUNNING":
                    break
                time.sleep(1)
            else:
                raise SchedulerServiceError(
                    f"Database service did not reach RUNNING; state={status.state}."
                )

    def start_once(self) -> None:
        current = self.query()
        if current.state != "STOPPED":
            raise SchedulerServiceError(
                f"Scheduler start requires STOPPED state, got {current.state}."
            )
        self.log("Starting scheduler exactly once after complete configuration.")
        result = self._run(
            ["sc.exe", "start", SERVICE_NAME],
            check=False,
            timeout=30,
        )
        if result.returncode != 0:
            observed = self.query()
            if observed.state == "RUNNING" and observed.pid > 0:
                self.log(
                    "Scheduler start command reported a non-zero result, but "
                    f"the verified service state is RUNNING: pid={observed.pid}."
                )
                return
            raise SchedulerServiceError(
                f"Scheduler start failed with exit code {result.returncode}."
            )

    def _read_scheduler_state(self):
        try:
            payload = json.loads(self.state_file.read_text(encoding="utf-8"))
            scheduler = payload.get("scheduler")
            return scheduler if isinstance(scheduler, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    def _process_identity(self, pid: int):
        script = (
            f"$p=Get-CimInstance Win32_Process -Filter \"ProcessId={pid}\" "
            "-ErrorAction SilentlyContinue;"
            "if($null -eq $p){exit 3};"
            "$p | Select-Object ProcessId,ExecutablePath,CommandLine,CreationDate "
            "| ConvertTo-Json -Compress"
        )
        result = self._run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                script,
            ],
            check=False,
            timeout=15,
        )
        if result.returncode != 0:
            return None
        try:
            return json.loads(result.stdout)
        except (TypeError, ValueError, json.JSONDecodeError):
            return None

    @staticmethod
    def _parse_heartbeat(value):
        if not value:
            return None
        try:
            parsed = datetime.fromisoformat(str(value))
        except ValueError:
            return None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)

    def _health_sample(self):
        service = self.query()
        if service.state != "RUNNING" or service.pid <= 0:
            raise SchedulerServiceError(
                f"Scheduler is not RUNNING: state={service.state} pid={service.pid}."
            )
        scheduler = self._read_scheduler_state()
        child_pid = int(scheduler.get("pid") or 0)
        heartbeat = self._parse_heartbeat(scheduler.get("heartbeat_at"))
        age = (
            (datetime.now(timezone.utc) - heartbeat).total_seconds()
            if heartbeat
            else None
        )
        process = self._process_identity(child_pid) if child_pid > 0 else None
        command_line = str((process or {}).get("CommandLine") or "").lower()
        if not scheduler.get("running"):
            raise SchedulerServiceError("Scheduler state does not report running=true.")
        if age is None or age < 0 or age > HEARTBEAT_MAX_AGE_SECONDS:
            raise SchedulerServiceError(
                f"Scheduler heartbeat is missing or stale: age={age}."
            )
        if (
            not process
            or "manage.py" not in command_line
            or "run_backup_scheduler" not in command_line
            or "--once" in command_line
        ):
            raise SchedulerServiceError(
                f"Scheduler child process identity is invalid: pid={child_pid}."
            )
        return service, child_pid, age

    def verify_stable(
        self,
        stable_seconds: int,
        *,
        expected_service_pid: int,
    ) -> ServiceStatus:
        deadline = time.monotonic() + START_TIMEOUT_SECONDS
        first_service_pid = None
        first_child_pid = None
        stable_since = None
        last_error = ""
        while time.monotonic() < deadline:
            try:
                service, child_pid, heartbeat_age = self._health_sample()
                if service.pid != expected_service_pid:
                    raise SchedulerRestartDetected(
                        "Scheduler service PID changed after initial RUNNING "
                        f"state: {expected_service_pid}->{service.pid}."
                    )
                if first_service_pid is None:
                    first_service_pid = service.pid
                    first_child_pid = child_pid
                    stable_since = time.monotonic()
                    self.log(
                        "Scheduler stable probe started: "
                        f"service_pid={service.pid} child_pid={child_pid} "
                        f"heartbeat_age={heartbeat_age:.1f}s"
                    )
                elif (
                    service.pid != first_service_pid
                    or child_pid != first_child_pid
                ):
                    raise SchedulerRestartDetected(
                        "Scheduler PID changed during stable probe: "
                        f"service {first_service_pid}->{service.pid}, "
                        f"child {first_child_pid}->{child_pid}."
                    )
                if (
                    stable_since is not None
                    and time.monotonic() - stable_since >= stable_seconds
                ):
                    self.log(
                        "Scheduler is stable RUNNING: "
                        f"service_pid={service.pid} child_pid={child_pid} "
                        f"heartbeat_age={heartbeat_age:.1f}s "
                        f"stable_seconds={stable_seconds}"
                    )
                    return service
            except SchedulerRestartDetected:
                raise
            except SchedulerServiceError as exc:
                last_error = str(exc)
                if first_service_pid is not None:
                    raise
            time.sleep(1)
        raise SchedulerServiceError(
            f"Scheduler did not become stable within timeout: {last_error}"
        )

    def _tail(self, path: Path, lines=80):
        if not path.is_file():
            self.log(f"Diagnostic log missing: {path}")
            return
        try:
            content = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError as exc:
            self.log(f"Diagnostic log unreadable: {path} ({type(exc).__name__})")
            return
        self.log(f"Diagnostic tail start: {path}")
        for line in content[-lines:]:
            self.log(f"Diagnostic: {line}")
        self.log(f"Diagnostic tail end: {path}")

    def collect_diagnostics(self) -> None:
        self.log("Collecting TheraFlowBackupScheduler failure diagnostics.")
        for args in (
            ["sc.exe", "queryex", SERVICE_NAME],
            ["sc.exe", "qc", SERVICE_NAME],
            ["sc.exe", "qfailure", SERVICE_NAME],
            [self.nssm_exe, "get", SERVICE_NAME, "Application"],
            [self.nssm_exe, "get", SERVICE_NAME, "AppDirectory"],
            [self.nssm_exe, "get", SERVICE_NAME, "AppParameters"],
            [self.nssm_exe, "get", SERVICE_NAME, "DependOnService"],
            [self.nssm_exe, "get", SERVICE_NAME, "AppExit", "Default"],
            [self.nssm_exe, "get", SERVICE_NAME, "AppThrottle"],
            [self.nssm_exe, "get", SERVICE_NAME, "AppRestartDelay"],
            [self.nssm_exe, "get", SERVICE_NAME, "AppEnvironmentExtra"],
        ):
            try:
                self._run(args, check=False, timeout=15)
            except Exception as exc:
                self.log(
                    f"Diagnostic command failed: {type(exc).__name__}"
                )
        try:
            state = self._read_scheduler_state()
            self.log(
                "Scheduler state diagnostic: "
                f"running={state.get('running')} pid={state.get('pid')} "
                f"heartbeat_at={state.get('heartbeat_at')} "
                f"next_run={state.get('next_run')}"
            )
        except Exception as exc:
            self.log(f"Scheduler state diagnostic failed: {type(exc).__name__}")
        for path in (self.stdout_log, self.stderr_log, self.scheduler_log):
            self._tail(path)
        event_script = (
            "$events=Get-WinEvent -FilterHashtable "
            "@{LogName='Application';StartTime=(Get-Date).AddMinutes(-20)} "
            "-ErrorAction SilentlyContinue | Where-Object "
            "{$_.ProviderName -match 'nssm|Service Control Manager' -or "
            "$_.Message -match 'TheraFlowBackupScheduler'} | "
            "Select-Object -First 20 TimeCreated,ProviderName,Id,"
            "LevelDisplayName,Message;"
            "$events | ConvertTo-Json -Compress"
        )
        try:
            self._run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    event_script,
                ],
                check=False,
                timeout=30,
            )
        except Exception as exc:
            self.log(f"Event Log diagnostic failed: {type(exc).__name__}")


def _safe_controller_log(controller, message: str) -> None:
    try:
        controller.log(message)
    except Exception as log_error:
        _safe_stderr(
            "TheraFlowBackupScheduler diagnostic logging failed: "
            f"{type(log_error).__name__}: {log_error}"
        )


def main() -> int:
    controller = WindowsSchedulerController(Path(__file__))
    try:
        controller.validate_inputs()
        final = reconcile_scheduler_service(controller)
    except Exception as exc:
        _safe_controller_log(
            controller,
            f"TheraFlowBackupScheduler installation failed: "
            f"{type(exc).__name__}: {exc}",
        )
        _safe_stderr(
            f"TheraFlowBackupScheduler installation failed: {exc}",
        )
        return 1
    _safe_controller_log(
        controller,
        f"TheraFlowBackupScheduler service is stable RUNNING: pid={final.pid}.",
    )
    print("TheraFlowBackupScheduler service is stable RUNNING.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
