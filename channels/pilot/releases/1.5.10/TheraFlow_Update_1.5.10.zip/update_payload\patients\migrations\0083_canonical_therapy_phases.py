from decimal import Decimal
import re
import unicodedata

import django.db.models.deletion
from django.db import migrations, models


KNOWN_PROGRAMS = {
    "adalimumab": "Adalimumab",
    "vedolizumab": "Vedolizumab",
    "infliximab": "Infliximab",
    "ustekinumab": "Ustekinumab",
    "risankizumab": "Risankizumab",
    "tofacitinib": "Tofacitinib",
    "entecavir": "Entecavir",
    "tenofovir-disoproxil": "Tenofovir disoproxil",
}


def _normalized(value):
    value = unicodedata.normalize("NFKD", str(value or ""))
    value = "".join(char for char in value if not unicodedata.combining(char))
    return re.sub(r"[^a-z0-9]+", " ", value.casefold()).strip()


def _program_identity(medicine):
    text = _normalized(
        " ".join(
            filter(
                None,
                (
                    medicine.genericki_naziv,
                    medicine.naziv,
                    medicine.zasticeno_ime,
                ),
            )
        )
    )
    aliases = (
        ("ustekinumab", ("ustekinumab", "stelara", "uzpruvo", "upruva")),
        ("adalimumab", ("adalimumab", "hyrimoz", "humira", "amgevita", "imraldi")),
        ("vedolizumab", ("vedolizumab", "entyvio")),
        ("infliximab", ("infliximab", "infliksimab", "remsima", "remicade")),
        ("risankizumab", ("risankizumab", "skyrizi")),
        ("tofacitinib", ("tofacitinib", "xeljanz")),
        ("entecavir", ("entecavir",)),
        ("tenofovir-disoproxil", ("tenofovir disoproxil", "tenofovir")),
    )
    words = set(text.split())
    for key, candidates in aliases:
        if any(candidate in text or candidate in words for candidate in candidates):
            return key, KNOWN_PROGRAMS[key]
    generic = _normalized(medicine.genericki_naziv or medicine.naziv)
    key = re.sub(r"[^a-z0-9]+", "-", generic).strip("-") or f"lijek-{medicine.pk}"
    label = (medicine.genericki_naziv or medicine.naziv).strip() or f"Terapija {medicine.pk}"
    return key[:80], label[:120]


def seed_canonical_therapies(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    Pacijent = apps.get_model("patients", "Pacijent")
    Program = apps.get_model("patients", "TerapijskiProgram")
    Faza = apps.get_model("patients", "TerapijskaFaza")
    FazniState = apps.get_model("patients", "FazniProtokolPacijenta")

    fake_iv = Lijek.objects.filter(naziv="Uzpruvo 130 mg IV").first()
    real_iv = Lijek.objects.filter(naziv="Stelara 130 mg IV").first()
    iv_defaults = {
        "genericki_naziv": "Ustekinumab",
        "zasticeno_ime": "Stelara",
        "jacina_mg": Decimal("130"),
        "put_primjene": "IV",
        "nacin_primjene": "AMBULANTA",
        "kucna_primjena": False,
        "package_size_in_doses": 1,
        "jedinica_terapije": "bočica",
        "jedinica_terapije_mnozina": "bočice",
        "jedinica_zalihe": "bočica",
        "jedinica_zalihe_mnozina": "bočice",
        "aktivan": True,
    }
    if fake_iv and not real_iv:
        for field, value in iv_defaults.items():
            setattr(fake_iv, field, value)
        fake_iv.naziv = "Stelara 130 mg IV"
        fake_iv.save(update_fields=("naziv", *iv_defaults.keys()))
        real_iv = fake_iv
    elif fake_iv and real_iv and fake_iv.pk != real_iv.pk:
        # Ne prepisuj historijske FK-ove ni zalihe. Stari red ostaje čitljiv,
        # ali se više ne nudi kao valjan novi SKU.
        fake_iv.naziv = f"Legacy Uzpruvo 130 mg IV #{fake_iv.pk}"
        fake_iv.aktivan = False
        fake_iv.save(update_fields=("naziv", "aktivan"))
    elif not real_iv:
        real_iv = Lijek.objects.create(naziv="Stelara 130 mg IV", **iv_defaults)

    for legacy_iv in Lijek.objects.filter(
        genericki_naziv__iexact="Ustekinumab",
        jacina_mg=Decimal("130"),
        put_primjene="IV",
    ).exclude(pk=real_iv.pk):
        if _normalized(legacy_iv.zasticeno_ime) not in {"uzpruvo", "upruva"}:
            continue
        proposed_name = re.sub(
            r"(?i)\b(?:uzpruvo|upruva)\b",
            "Stelara",
            legacy_iv.naziv,
            count=1,
        )
        if (
            proposed_name != legacy_iv.naziv
            and not Lijek.objects.filter(naziv=proposed_name).exclude(
                pk=legacy_iv.pk
            ).exists()
        ):
            legacy_iv.naziv = proposed_name
        legacy_iv.zasticeno_ime = "Stelara"
        legacy_iv.save(update_fields=("naziv", "zasticeno_ime"))

    sc = Lijek.objects.filter(naziv="Uzpruvo 90 mg SC").first()
    if not sc:
        sc = Lijek.objects.create(
            naziv="Uzpruvo 90 mg SC",
            genericki_naziv="Ustekinumab",
            zasticeno_ime="Uzpruvo",
            jacina_mg=Decimal("90"),
            put_primjene="SC",
            nacin_primjene="AMBULANTA",
            kucna_primjena=False,
            package_size_in_doses=1,
            jedinica_terapije="šprica",
            jedinica_terapije_mnozina="šprice",
            jedinica_zalihe="šprica",
            jedinica_zalihe_mnozina="šprice",
            aktivan=True,
        )

    programs = {}
    for medicine in Lijek.objects.order_by("pk"):
        key, label = _program_identity(medicine)
        program, _ = Program.objects.get_or_create(
            kljuc=key,
            defaults={
                "naziv": label,
                "aktivan": medicine.aktivan,
                "protokol_kljuc": "ustekinumab" if key == "ustekinumab" else "",
                "zahtijeva_tezinu_za_pocetak": key == "ustekinumab",
            },
        )
        programs[key] = program
        if medicine.terapijski_program_id != program.pk:
            medicine.terapijski_program_id = program.pk
            medicine.save(update_fields=("terapijski_program",))
        if not program.default_lijek_id and medicine.aktivan:
            program.default_lijek_id = medicine.pk
            program.save(update_fields=("default_lijek",))

    preferred_products = {
        "adalimumab": "Hyrimoz",
        "vedolizumab": "Entyvio",
        "infliximab": "Remsima",
        "tofacitinib": "Xeljanz 5 mg",
        "entecavir": "Entecavir 0.5 mg",
        "tenofovir-disoproxil": "Tenofovir 245 mg",
    }
    for key, product_name in preferred_products.items():
        program = programs.get(key)
        product = Lijek.objects.filter(
            naziv=product_name,
            aktivan=True,
            terapijski_program=program,
        ).first()
        if program and product and program.default_lijek_id != product.pk:
            program.default_lijek_id = product.pk
            program.save(update_fields=("default_lijek",))

    ustekinumab = programs["ustekinumab"]
    ustekinumab.naziv = "Ustekinumab"
    ustekinumab.protokol_kljuc = "ustekinumab"
    ustekinumab.zahtijeva_tezinu_za_pocetak = True
    ustekinumab.default_lijek_id = real_iv.pk
    ustekinumab.aktivan = True
    ustekinumab.save(
        update_fields=(
            "naziv",
            "protokol_kljuc",
            "zahtijeva_tezinu_za_pocetak",
            "default_lijek",
            "aktivan",
        )
    )
    for product in (real_iv, sc):
        if product.terapijski_program_id != ustekinumab.pk:
            product.terapijski_program_id = ustekinumab.pk
            product.save(update_fields=("terapijski_program",))

    phase_specs = (
        ("CEKA_IV_INDUKCIJU", "IV indukcija", 1, real_iv, "IV", True, None),
        (
            "CEKA_PRVU_SC",
            "Prijelaz — čeka prvu SC nakon indukcije",
            2,
            sc,
            "SC",
            False,
            8,
        ),
        ("ODRZAVANJE", "SC održavanje", 3, sc, "SC", False, 8),
    )
    phases = {}
    for key, label, order, product, route, needs_weight, interval in phase_specs:
        phase, _ = Faza.objects.update_or_create(
            program=ustekinumab,
            kljuc=key,
            defaults={
                "naziv": label,
                "redoslijed": order,
                "lijek": product,
                "put_primjene": route,
                "zahtijeva_tezinu": needs_weight,
                "interval_sedmica": interval,
                "aktivna": True,
            },
        )
        phases[key] = phase

    for patient in Pacijent.objects.select_related("lijek").iterator():
        program_id = getattr(patient.lijek, "terapijski_program_id", None)
        if program_id and patient.terapijski_program_id != program_id:
            patient.terapijski_program_id = program_id
            patient.save(update_fields=("terapijski_program",))

    for state in FazniState.objects.select_related("pacijent").iterator():
        phase = phases.get(state.faza)
        state.terapijski_program_id = ustekinumab.pk
        state.trenutna_faza_id = phase.pk if phase else None
        state.save(update_fields=("terapijski_program", "trenutna_faza"))
        if state.pacijent.terapijski_program_id != ustekinumab.pk:
            state.pacijent.terapijski_program_id = ustekinumab.pk
            state.pacijent.save(update_fields=("terapijski_program",))


class Migration(migrations.Migration):
    dependencies = [("patients", "0082_hard_inventory_invariant")]

    operations = [
        migrations.CreateModel(
            name="TerapijskiProgram",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("kljuc", models.SlugField(max_length=80, unique=True)),
                ("naziv", models.CharField(max_length=120)),
                ("aktivan", models.BooleanField(default=True)),
                ("protokol_kljuc", models.CharField(blank=True, help_text="Ključ faznog/calculator enginea; prazan za jednofaznu terapiju.", max_length=80)),
                ("zahtijeva_tezinu_za_pocetak", models.BooleanField(default=False)),
                ("default_lijek", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="zadani_za_terapijske_programe", to="patients.lijek")),
            ],
            options={"verbose_name": "Terapijski program", "verbose_name_plural": "Terapijski programi", "ordering": ("naziv", "id")},
        ),
        migrations.AddField(
            model_name="lijek",
            name="terapijski_program",
            field=models.ForeignKey(blank=True, help_text="Kanonska terapija kojoj ovaj fizički proizvod/SKU pripada.", null=True, on_delete=django.db.models.deletion.PROTECT, related_name="proizvodi", to="patients.terapijskiprogram"),
        ),
        migrations.CreateModel(
            name="TerapijskaFaza",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("kljuc", models.CharField(max_length=40)),
                ("naziv", models.CharField(max_length=120)),
                ("redoslijed", models.PositiveSmallIntegerField(default=1)),
                ("put_primjene", models.CharField(blank=True, choices=[("IV", "Intravenozno (IV)"), ("SC", "Supkutano (SC)"), ("PO", "Peroralno (PO)")], max_length=8)),
                ("zahtijeva_tezinu", models.BooleanField(default=False)),
                ("interval_sedmica", models.PositiveSmallIntegerField(blank=True, null=True)),
                ("aktivna", models.BooleanField(default=True)),
                ("lijek", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="terapijske_faze", to="patients.lijek")),
                ("program", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="faze", to="patients.terapijskiprogram")),
            ],
            options={"ordering": ("program", "redoslijed", "id")},
        ),
        migrations.AddConstraint(model_name="terapijskafaza", constraint=models.UniqueConstraint(fields=("program", "kljuc"), name="uniq_terapijski_program_faza_kljuc")),
        migrations.AddConstraint(model_name="terapijskafaza", constraint=models.UniqueConstraint(fields=("program", "redoslijed"), name="uniq_terapijski_program_faza_redoslijed")),
        migrations.AddField(
            model_name="pacijent",
            name="terapijski_program",
            field=models.ForeignKey(blank=True, help_text="Autoritativni identitet terapije; lijek je trenutni/legacy SKU.", null=True, on_delete=django.db.models.deletion.PROTECT, related_name="pacijenti", to="patients.terapijskiprogram"),
        ),
        migrations.AddField(
            model_name="fazniprotokolpacijenta",
            name="terapijski_program",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="fazni_protokoli_pacijenata", to="patients.terapijskiprogram"),
        ),
        migrations.AddField(
            model_name="fazniprotokolpacijenta",
            name="trenutna_faza",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="stanja_pacijenata", to="patients.terapijskafaza"),
        ),
        migrations.RunPython(seed_canonical_therapies, migrations.RunPython.noop),
    ]
