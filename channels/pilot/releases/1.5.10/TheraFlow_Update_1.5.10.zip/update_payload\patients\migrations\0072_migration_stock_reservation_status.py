from django.db import migrations, models
from django.db.models import Sum


def mark_existing_migration_stock(apps, schema_editor):
    StockTransaction = apps.get_model("patients", "ZalihaTransakcija")
    StockTransaction.objects.filter(
        tip="POCETNO_STANJE_MIGRACIJE",
        pacijent_id__isnull=False,
        lokacija="FRIZIDER",
    ).update(rezervisana_pacijentu=True)

    Reservation = apps.get_model("patients", "PacijentRezervacija")
    Stock = apps.get_model("patients", "Zaliha")
    InitialStock = apps.get_model("patients", "MigracijskoPocetnoStanjeZalihe")
    medicine_ids = Reservation.objects.filter(
        aktivno=True,
        kolicina__gt=0,
        migracijski_snapshot_id__isnull=False,
    ).values_list("lijek_id", flat=True).distinct()
    for medicine_id in medicine_ids:
        stock, _ = Stock.objects.get_or_create(lijek_id=medicine_id)
        reserved_total = Reservation.objects.filter(
            lijek_id=medicine_id,
            aktivno=True,
            kolicina__gt=0,
        ).aggregate(total=Sum("kolicina"))["total"] or 0
        deficit = max(reserved_total - stock.u_frizideru, 0)
        reservations = Reservation.objects.filter(
            lijek_id=medicine_id,
            aktivno=True,
            kolicina__gt=0,
            migracijski_snapshot_id__isnull=False,
        ).select_related("migracijski_snapshot").order_by("id")
        last_transaction = None
        for reservation in reservations:
            snapshot = reservation.migracijski_snapshot
            if StockTransaction.objects.filter(
                tip="POCETNO_STANJE_MIGRACIJE",
                referenca_tip="MigracijskiSnapshotPacijenta",
                referenca_id=snapshot.pk,
            ).exists():
                continue
            quantity = reservation.kolicina
            balance_delta = min(quantity, deficit)
            last_transaction = StockTransaction.objects.create(
                lijek_id=medicine_id,
                tip="POCETNO_STANJE_MIGRACIJE",
                kolicina=quantity,
                promjena_salda=balance_delta,
                datum=snapshot.kreirano.date(),
                pacijent_id=reservation.pacijent_id,
                komisija_id=reservation.komisija_id,
                referenca_tip="MigracijskiSnapshotPacijenta",
                referenca_id=snapshot.pk,
                korisnik_id=snapshot.kreirao_id,
                lokacija="FRIZIDER",
                rezervisana_pacijentu=True,
                napomena=(
                    "Historijska migracijska rezervacija povezana s fizičkim "
                    "početnim stanjem."
                ),
            )
            stock.u_frizideru += balance_delta
            deficit -= balance_delta
        stock.save(update_fields=["u_frizideru", "ukupno"])
        initial, _ = InitialStock.objects.get_or_create(
            lijek_id=medicine_id,
            defaults={"kolicina": stock.u_frizideru},
        )
        initial.kolicina = stock.u_frizideru
        if last_transaction is not None:
            initial.ledger_checkpoint_id = last_transaction.pk
        initial.save(update_fields=["kolicina", "ledger_checkpoint_id", "izmijenjeno"])


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0071_migration_opening_stock_transaction"),
    ]

    operations = [
        migrations.AddField(
            model_name="zalihatransakcija",
            name="rezervisana_pacijentu",
            field=models.BooleanField(
                default=False,
                help_text=(
                    "Fizička količina u frižideru dodijeljena konkretnom pacijentu."
                ),
            ),
        ),
        migrations.AddField(
            model_name="zalihatransakcija",
            name="promjena_salda",
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                help_text=(
                    "Stvarna promjena centralnog salda; prazno koristi količinu transakcije."
                ),
                max_digits=8,
                null=True,
            ),
        ),
        migrations.RunPython(
            mark_existing_migration_stock,
            migrations.RunPython.noop,
        ),
    ]
