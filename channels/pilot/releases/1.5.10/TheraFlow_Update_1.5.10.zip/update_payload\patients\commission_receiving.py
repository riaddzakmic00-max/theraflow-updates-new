"""Canonical approval metadata and patient agreements used during receiving."""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from .models import (
    EvidencijaSaglasnostiZaprimanja,
    Komisija,
    KomisijskaSaglasnost,
    PacijentSaglasnost,
    Trebovanje,
)


@dataclass(frozen=True)
class ReceiptApprovalContext:
    approval_date: date | None
    approval_number: str
    source: str
    source_label: str


@dataclass(frozen=True)
class PatientAgreementSuggestion:
    number: str
    valid_from: date | None
    source: str
    persisted: PacijentSaglasnost | None = None

    @property
    def exists(self):
        return bool(self.number)


def normalize_agreement_number(value):
    return " ".join(str(value or "").strip().split())


def validate_agreement_number(value):
    number = normalize_agreement_number(value)
    if not number:
        raise ValueError("Unesite prvi broj saglasnosti.")
    if len(number) > 100:
        raise ValueError("Broj saglasnosti može sadržavati najviše 100 znakova.")
    if any(not (character.isalnum() or character in " /-.") for character in number):
        raise ValueError(
            "Broj saglasnosti može sadržavati slova, brojeve, razmake, "
            "kose crte, crtice i tačke."
        )
    return number


def patient_agreement_suggestion(patient):
    """Return current patient agreement, falling back to legacy patient data."""

    current = (
        PacijentSaglasnost.objects.filter(
            pacijent=patient,
            trenutno_vazeca=True,
        )
        .order_by("-vazi_od", "-pk")
        .first()
    )
    if current:
        return PatientAgreementSuggestion(
            number=current.broj_saglasnosti,
            valid_from=current.vazi_od,
            source="PATIENT_AGREEMENT",
            persisted=current,
        )

    legacy_commission = (
        Komisija.objects.filter(pacijent=patient)
        .exclude(broj_saglasnosti__isnull=True)
        .exclude(broj_saglasnosti="")
        .order_by("-datum_odobrenja", "-pk")
        .first()
    )
    phase_three = (
        KomisijskaSaglasnost.objects.filter(
            komisijski_zahtjev__pacijent=patient,
            odluka__in=(
                KomisijskaSaglasnost.Odluka.ODOBRENO,
                KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
            ),
        )
        .exclude(broj_saglasnosti__isnull=True)
        .exclude(broj_saglasnosti="")
        .order_by("-datum_saglasnosti", "-pk")
        .first()
    )
    candidates = []
    if legacy_commission:
        candidates.append(
            (
                legacy_commission.datum_odobrenja,
                legacy_commission.pk,
                legacy_commission.broj_saglasnosti,
                "LEGACY_COMMISSION",
            )
        )
    if phase_three:
        candidates.append(
            (
                phase_three.datum_saglasnosti,
                phase_three.pk,
                phase_three.broj_saglasnosti,
                "PHASE_THREE",
            )
        )
    if not candidates:
        return PatientAgreementSuggestion("", None, "MISSING")
    valid_from, _, number, source = max(candidates, key=lambda item: item[:2])
    return PatientAgreementSuggestion(
        normalize_agreement_number(number),
        valid_from,
        source,
    )


def agreement_number_conflicts(number, *, patient):
    """Other patients currently or historically associated with this number."""

    normalized = normalize_agreement_number(number)
    if not normalized:
        return []
    patient_ids = set(
        PacijentSaglasnost.objects.filter(
            broj_saglasnosti__iexact=normalized,
        )
        .exclude(pacijent=patient)
        .values_list("pacijent_id", flat=True)
    )
    patient_ids.update(
        Komisija.objects.filter(broj_saglasnosti__iexact=normalized)
        .exclude(pacijent=patient)
        .values_list("pacijent_id", flat=True)
    )
    phase_three_ids = KomisijskaSaglasnost.objects.filter(
        broj_saglasnosti__iexact=normalized,
    ).exclude(
        komisijski_zahtjev__pacijent=patient,
    ).values_list("komisijski_zahtjev__pacijent_id", flat=True)
    patient_ids.update(phase_three_ids)
    from .models import Pacijent

    return list(Pacijent.objects.filter(pk__in=patient_ids).order_by(
        "prezime", "ime", "pk"
    ))


def agreement_number_owners():
    """Small client-side warning map; duplicate values are warnings, not locks."""

    owners = {}
    rows = PacijentSaglasnost.objects.filter(trenutno_vazeca=True).select_related(
        "pacijent"
    )
    for row in rows:
        key = normalize_agreement_number(row.broj_saglasnosti).casefold()
        owners.setdefault(key, []).append(
            {"id": row.pacijent_id, "name": str(row.pacijent)}
        )
    for row in Komisija.objects.exclude(broj_saglasnosti__isnull=True).exclude(
        broj_saglasnosti=""
    ).select_related("pacijent").order_by("-datum_odobrenja", "-pk"):
        key = normalize_agreement_number(row.broj_saglasnosti).casefold()
        owner = {"id": row.pacijent_id, "name": str(row.pacijent)}
        if owner not in owners.setdefault(key, []):
            owners[key].append(owner)
    phase_three_rows = KomisijskaSaglasnost.objects.exclude(
        broj_saglasnosti__isnull=True
    ).exclude(broj_saglasnosti="").select_related("komisijski_zahtjev__pacijent")
    for row in phase_three_rows:
        patient = row.komisijski_zahtjev.pacijent
        key = normalize_agreement_number(row.broj_saglasnosti).casefold()
        owner = {"id": patient.pk, "name": str(patient)}
        if owner not in owners.setdefault(key, []):
            owners[key].append(owner)
    return owners


@transaction.atomic
def update_patient_agreement(
    *,
    patient,
    number,
    user=None,
    source_commission=None,
):
    """Evidentiraj ili verzioniraj saglasnost direktno iz kartona pacijenta."""

    number = validate_agreement_number(number)
    suggestion = patient_agreement_suggestion(patient)
    current = (
        PacijentSaglasnost.objects.select_for_update()
        .filter(pacijent=patient, trenutno_vazeca=True)
        .order_by("-vazi_od", "-pk")
        .first()
    )
    if (
        current
        and normalize_agreement_number(current.broj_saglasnosti).casefold()
        == number.casefold()
    ):
        return current, False

    today = timezone.localdate()
    old_number = suggestion.number
    if current:
        current.trenutno_vazeca = False
        current.vazi_do = today
        current.save(update_fields=["trenutno_vazeca", "vazi_do", "izmijenjeno"])
    elif suggestion.exists and suggestion.number.casefold() != number.casefold():
        legacy_source = (
            Komisija.objects.filter(
                pacijent=patient,
                broj_saglasnosti__iexact=suggestion.number,
            )
            .order_by("-datum_odobrenja", "-pk")
            .first()
        )
        PacijentSaglasnost.objects.create(
            pacijent=patient,
            broj_saglasnosti=suggestion.number,
            vazi_od=suggestion.valid_from or today,
            vazi_do=today,
            trenutno_vazeca=False,
            izvorna_komisija=legacy_source,
        )

    agreement = PacijentSaglasnost.objects.create(
        pacijent=patient,
        broj_saglasnosti=number,
        vazi_od=(
            source_commission.datum_odobrenja
            if source_commission and source_commission.datum_odobrenja
            else today
        ),
        trenutno_vazeca=True,
        izmijenio=user if getattr(user, "is_authenticated", False) else None,
        izvorna_komisija=source_commission,
    )
    from .utils import upisi_log

    upisi_log(
        user,
        "Promjena broja saglasnosti pacijenta",
        pacijent=patient,
        objekat=agreement,
        opis=(
            f"Broj saglasnosti ažuriran sa {old_number} na {number}."
            if old_number else
            f"Evidentiran prvi broj saglasnosti {number}."
        ),
    )
    return agreement, True


@transaction.atomic
def use_patient_agreement_for_receipt(
    *, patient, number, request, quantity, user=None
):
    """Version a changed number and snapshot exactly what one receipt used."""

    number = validate_agreement_number(number)
    suggestion = patient_agreement_suggestion(patient)
    current = (
        PacijentSaglasnost.objects.select_for_update()
        .filter(pacijent=patient, trenutno_vazeca=True)
        .order_by("-vazi_od", "-pk")
        .first()
    )
    today = timezone.localdate()
    old_number = suggestion.number

    unchanged_current = (
        current
        and normalize_agreement_number(current.broj_saglasnosti).casefold()
        == number.casefold()
    )
    unchanged_legacy = (
        not current
        and suggestion.exists
        and suggestion.number.casefold() == number.casefold()
    )
    if unchanged_current:
        agreement = current
    elif unchanged_legacy:
        agreement = PacijentSaglasnost.objects.create(
            pacijent=patient,
            broj_saglasnosti=number,
            vazi_od=suggestion.valid_from or today,
            trenutno_vazeca=True,
            izmijenio=user if user and user.is_authenticated else None,
            izvorni_ciklus=request.komisijski_ciklus,
            izvorno_trebovanje=request,
        )
    else:
        if current:
            current.trenutno_vazeca = False
            current.vazi_do = today
            current.save(update_fields=["trenutno_vazeca", "vazi_do", "izmijenjeno"])
        elif suggestion.exists:
            # Preserve a legacy number before creating the first explicit
            # patient-centric version with a different number.
            PacijentSaglasnost.objects.create(
                pacijent=patient,
                broj_saglasnosti=suggestion.number,
                vazi_od=suggestion.valid_from or today,
                vazi_do=today,
                trenutno_vazeca=False,
            )

        agreement = PacijentSaglasnost.objects.create(
            pacijent=patient,
            broj_saglasnosti=number,
            vazi_od=(suggestion.valid_from or today) if not suggestion.exists else today,
            trenutno_vazeca=True,
            izmijenio=user if user and user.is_authenticated else None,
            izvorni_ciklus=request.komisijski_ciklus,
            izvorno_trebovanje=request,
        )

        from .utils import upisi_log

        if old_number:
            description = (
                f"Broj saglasnosti ažuriran sa {old_number} na {number} kroz "
                f"zaprimanje pošiljke {request.komisijski_ciklus}."
            )
        else:
            description = (
                f"Evidentiran prvi broj saglasnosti {number} kroz zaprimanje "
                f"pošiljke {request.komisijski_ciklus}."
            )
        upisi_log(
            user,
            "Promjena broja saglasnosti pacijenta",
            pacijent=patient,
            objekat=agreement,
            opis=description,
        )

    EvidencijaSaglasnostiZaprimanja.objects.create(
        saglasnost=agreement,
        pacijent=patient,
        trebovanje=request,
        komisijski_ciklus=request.komisijski_ciklus,
        broj_saglasnosti_snapshot=number,
        zaprimljena_kolicina=Decimal(str(quantity)),
        korisnik=user if user and user.is_authenticated else None,
    )
    return agreement


def resolve_receipt_approval_context(cycle, *, requests=None):
    """Resolve the shipment approval date; agreement numbers are per patient."""

    requests = list(
        requests
        if requests is not None
        else Trebovanje.objects.filter(komisijski_ciklus=cycle).select_related(
            "komisija"
        )
    )
    linked_approvals = sorted(
        (
            request.komisija
            for request in requests
            if request.komisija_id
            and request.komisija
            and request.komisija.datum_odobrenja
            and request.komisija.status != "PONISTENA"
        ),
        key=lambda approval: (approval.datum_odobrenja, approval.pk),
        reverse=True,
    )
    agreement = (
        KomisijskaSaglasnost.objects.filter(
            komisijski_zahtjev__komisijski_ciklus=cycle,
            odluka__in=(
                KomisijskaSaglasnost.Odluka.ODOBRENO,
                KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
            ),
        )
        .order_by("-datum_saglasnosti", "-pk")
        .first()
    )

    if cycle.datum_odobrenja:
        return ReceiptApprovalContext(
            approval_date=cycle.datum_odobrenja,
            approval_number="",
            source="CYCLE",
            source_label="Automatski preuzeto iz komisijskog ciklusa.",
        )
    if linked_approvals:
        return ReceiptApprovalContext(
            approval_date=linked_approvals[0].datum_odobrenja,
            approval_number="",
            source="PATIENT_APPROVAL",
            source_label="Automatski preuzeto iz odobrenog zahtjeva.",
        )
    if agreement:
        return ReceiptApprovalContext(
            approval_date=agreement.datum_saglasnosti,
            approval_number="",
            source="AGREEMENT",
            source_label="Automatski preuzeto iz komisijske saglasnosti.",
        )
    return ReceiptApprovalContext(
        approval_date=None,
        approval_number="",
        source="MISSING",
        source_label="Datum odobrenja nije pronađen u komisijskim podacima.",
    )
