import logging
import os
import time

os.environ.setdefault("THERAFLOW_PRODUCTION", "1")
os.environ.setdefault(
    "THERAFLOW_ENV_FILE",
    os.path.join(os.environ.get("PROGRAMDATA", r"C:\ProgramData"), "TheraFlow", "config", ".env"),
)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

import django
from django.db import connection
from waitress import serve

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("theraflow.startup")

django.setup()
for attempt in range(1, 31):
    try:
        connection.ensure_connection()
        logger.info("Private database connection is ready.")
        break
    except Exception as exc:  # credentials are intentionally not logged
        logger.warning("Database is not ready (attempt %s/30): %s", attempt, type(exc).__name__)
        if attempt == 30:
            logger.error("Database did not become ready within 60 seconds.")
            raise
        time.sleep(2)

from config.wsgi import application


serve(
    application,
    host="127.0.0.1",
    port=8000,
    threads=8,
)
