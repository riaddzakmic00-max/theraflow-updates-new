from datetime import timedelta
from decimal import Decimal, InvalidOperation
from math import floor


MIN_INDIVIDUAL_INTERVAL_WEEKS = 1
MAX_INDIVIDUAL_INTERVAL_WEEKS = 52


def validate_individual_interval(interval_weeks):
    """Vrati interval kao cijeli broj ili podigni jasnu grešku raspona."""
    if isinstance(interval_weeks, bool):
        raise ValueError("Interval terapije mora biti cijeli broj sedmica.")
    try:
        interval = int(interval_weeks)
    except (TypeError, ValueError):
        raise ValueError("Interval terapije mora biti cijeli broj sedmica.") from None

    if str(interval).strip() != str(interval_weeks).strip():
        raise ValueError("Interval terapije mora biti cijeli broj sedmica.")
    if not MIN_INDIVIDUAL_INTERVAL_WEEKS <= interval <= MAX_INDIVIDUAL_INTERVAL_WEEKS:
        raise ValueError(
            f"Interval terapije mora biti između {MIN_INDIVIDUAL_INTERVAL_WEEKS} "
            f"i {MAX_INDIVIDUAL_INTERVAL_WEEKS} sedmice."
        )
    return interval


def calculate_next_therapy_date(last_therapy_date, interval_weeks):
    """Izračun koji koriste migracijski pregled i kreiranje prvog termina."""
    if last_therapy_date is None:
        return None
    interval = validate_individual_interval(interval_weeks)
    return last_therapy_date + timedelta(weeks=interval)


def calculate_commission_coverage_until(
    next_therapy_date,
    interval_weeks,
    remaining_doses,
    units_per_application=1,
):
    """Vrati datum posljednje aplikacije koju preostale doze mogu pokriti.

    Prva raspoloživa aplikacija pada na ``next_therapy_date``. Funkcija samo
    procjenjuje datum i ne mijenja komisiju, zalihe niti zaduženja.
    """
    if next_therapy_date is None or remaining_doses is None:
        return None
    interval = validate_individual_interval(interval_weeks)
    try:
        remaining = Decimal(str(remaining_doses))
        units = Decimal(str(units_per_application))
    except (InvalidOperation, TypeError, ValueError):
        return None
    if remaining <= 0 or units <= 0:
        return None

    applications = floor(remaining / units)
    if applications < 1:
        return None
    return next_therapy_date + timedelta(weeks=interval * (applications - 1))
