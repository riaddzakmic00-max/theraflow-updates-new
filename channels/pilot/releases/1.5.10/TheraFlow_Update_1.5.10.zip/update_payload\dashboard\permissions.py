ROLE_COORDINATOR = "Koordinator biološke terapije"


def je_admin(user):
    return user.is_authenticated and (
        user.is_superuser or user.groups.filter(name="Admin").exists()
    )


def je_doktor(user):
    return user.is_authenticated and user.groups.filter(name="Doktor").exists()


def je_sestra(user):
    return user.is_authenticated and user.groups.filter(name="Sestra").exists()


def je_koordinator(user):
    return bool(
        user.is_authenticated
        and user.groups.filter(name=ROLE_COORDINATOR).exists()
    )


def je_koordinator_ili_admin(user):
    return je_admin(user) or je_koordinator(user)


def je_doktor_ili_admin(user):
    return je_admin(user) or je_doktor(user) or je_koordinator(user)


def je_sestra_ili_admin(user):
    return je_admin(user) or je_sestra(user) or je_koordinator(user)


def je_terapijski_tim(user):
    """Klinički tim koji smije potvrditi mjesto primjene terapije."""

    return (
        je_admin(user)
        or je_doktor(user)
        or je_sestra(user)
        or je_koordinator(user)
    )

def korisnik_uloga(user):
    if je_admin(user):
        return "Admin"
    if je_doktor(user):
        return "Doktor"
    if je_koordinator(user):
        return ROLE_COORDINATOR
    if je_sestra(user):
        return "Sestra"
    return "Korisnik"
