from datetime import date

from django.core.management.base import BaseCommand, CommandError

from patients.demo_dataset_v2 import (
    generate_demo_dataset_v2,
)
from patients.demo_reset import DemoDatasetResetError


def parse_bool(value):
    if isinstance(value, bool):
        return value
    normalized = str(value).strip().lower()
    if normalized in ["1", "true", "yes", "da"]:
        return True
    if normalized in ["0", "false", "no", "ne"]:
        return False
    raise CommandError("Boolean opcije moraju biti true ili false.")


class Command(BaseCommand):
    help = "Idempotentno generise sigurni TheraFlow demo dataset (28 aktivnih scenarija)."

    def add_arguments(self, parser):
        # Legacy opcije ostaju prihvaćene zbog postojećih lokalnih skripti, ali
        # V2 je namjerno fiksan i deterministički.
        parser.add_argument("--patients", type=int, default=28)
        parser.add_argument("--reset", default="false")
        parser.add_argument("--stock", default="false")
        parser.add_argument(
            "--yes",
            action="store_true",
            help="Preskoci interaktivnu DEMO potvrdu.",
        )
        parser.add_argument(
            "--continue-existing",
            action="store_true",
            help="Dozvoli generisanje ako demo pacijenti vec postoje.",
        )
        parser.add_argument(
            "--include-free-stock-edge-case",
            action="store_true",
            help="Dodaj tačno jednu oslobođenu Entyvio dozu sa audit tragom.",
        )
        parser.add_argument(
            "--reference-date",
            type=date.fromisoformat,
            help="Opcioni deterministički referentni datum u ISO formatu YYYY-MM-DD.",
        )

    def handle(self, *args, **options):
        parse_bool(options["reset"])
        parse_bool(options["stock"])
        if options["patients"] != 28:
            raise CommandError("Novi demo dataset uvijek sadrži tačno 28 aktivnih pacijenata.")

        if not options["yes"]:
            confirm = input(
                "Generator će zamijeniti samo označene demo zapise i kreirati 28 aktivnih scenarija. "
                "Upisite DEMO za nastavak: "
            )
            if confirm.strip() != "DEMO":
                raise CommandError("Generisanje demo podataka je otkazano.")

        try:
            stats = generate_demo_dataset_v2(
                reference_date=options["reference_date"],
                include_free_stock_edge_case=options["include_free_stock_edge_case"],
            )
        except (ValueError, DemoDatasetResetError) as exc:
            raise CommandError(str(exc)) from exc

        self.stdout.write(self.style.SUCCESS("Generisan Demo Dataset V2:"))
        self.stdout.write(f"- kreirano pacijenata: {stats['pacijenti']}")
        self.stdout.write(f"- kreirano termina: {stats['termini']}")
        self.stdout.write(f"- kreirano terapija: {stats['terapije']}")
        self.stdout.write(f"- kreirano komisija: {stats['komisije']}")
        self.stdout.write(f"- kreirano zaduzenja: {stats['zaduzenja']}")
        self.stdout.write(f"- zalihe promijenjene: {'da' if stats['zalihe_promijenjene'] else 'ne'}")
        self.stdout.write(f"- referentni datum: {stats['reference_date']:%d.%m.%Y}.")
        self.stdout.write(f"- integrity: {stats['integrity']['status']}")
        self.stdout.write("- sažetak po terapijskom programu:")
        for key, count in stats["clinical_summary"]["by_program"].items():
            self.stdout.write(f"  {key}: {count}")
        self.stdout.write("- sažetak po operativnoj fazi/scenariju:")
        for key, count in stats["clinical_summary"]["by_state"].items():
            self.stdout.write(f"  {key}: {count}")
        self.stdout.write("- komisijski ciklusi:")
        for key, cycle in stats["ciklusi"].items():
            delivery = (
                cycle["expected_delivery"].strftime("%d.%m.%Y.")
                if cycle["expected_delivery"] else "-"
            )
            self.stdout.write(
                f"  {key}: {cycle['date']:%d.%m.%Y.}; priprema "
                f"{cycle['preparation']:%d.%m.%Y.}; status={cycle['status']}; "
                f"očekivana isporuka={delivery}"
            )
        self.stdout.write(
            f"- zahtjevi u otvorenom ciklusu: {stats['trenutni_zahtjevi']}"
        )
        self.stdout.write("- kontrola fizičkih tokova:")
        for row in stats["inventory_summary"]:
            self.stdout.write(
                "  {medicine}: zaprimljeno={received:g}; dodijeljeno={assigned:g}; "
                "u ustanovi={institution:g}; kod pacijenta={at_patient:g}; "
                "rezervisano={reserved:g}; potrošeno={consumed:g}; slobodno={free:g}".format(**row)
            )

        for warning in stats["warnings"]:
            self.stdout.write(self.style.WARNING(f"Upozorenje: {warning}"))
        for info in stats["info"]:
            self.stdout.write(f"Info: {info}")
