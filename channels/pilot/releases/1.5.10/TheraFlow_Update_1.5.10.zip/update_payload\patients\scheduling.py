"""Centralna pravila za dozvoljene dane zakazivanja terapija."""

from dataclasses import dataclass
from datetime import date, timedelta

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db.models import Q
from django.utils import timezone


WEEKEND_MESSAGE = (
    "Terapije se ne mogu zakazivati subotom ili nedjeljom. "
    "Odaberite radni dan."
)
DISALLOWED_DAY_MESSAGE = (
    "Odabrani datum nije dozvoljeni terapijski dan. "
    "Odaberite drugi radni dan."
)
DEMO_WEEKEND_AUDIT_MESSAGE = "Vikend termin kreiran u demo režimu."
DEMO_WEEKEND_PERMISSION_MESSAGE = (
    "Vikend termin u demo režimu može ručno kreirati samo administrator."
)


@dataclass(frozen=True)
class ScheduledDate:
    datum: date
    prilagodjen: bool
    razlog: str = ""


def _normalized_weekdays(values):
    return tuple(
        sorted(
            {
                int(value)
                for value in values
                if 0 <= int(value) <= 4
            }
        )
    )


def _specific_weekdays(mapping, obj, *, names=()):
    if not mapping or obj is None:
        return None
    keys = [getattr(obj, "pk", None), str(getattr(obj, "pk", ""))]
    keys.extend(getattr(obj, name, None) for name in names)
    for key in keys:
        if key not in (None, "") and key in mapping:
            return _normalized_weekdays(mapping[key])
    return None


def allowed_therapy_weekdays(*, lijek=None, protokol=None):
    """Vrati Python weekday vrijednosti; vikend se uvijek uklanja."""

    protocol_days = _specific_weekdays(
        getattr(settings, "THERAFLOW_THERAPY_WEEKDAYS_BY_PROTOCOL", {}),
        protokol,
        names=("naziv",),
    )
    if protocol_days is not None:
        return protocol_days

    medicine_days = _specific_weekdays(
        getattr(settings, "THERAFLOW_THERAPY_WEEKDAYS_BY_MEDICINE", {}),
        lijek,
        names=("naziv", "zasticeno_ime", "genericki_naziv"),
    )
    if medicine_days is not None:
        return medicine_days

    primary = getattr(
        settings,
        "THERAFLOW_THERAPY_PRIMARY_WEEKDAYS",
        (0, 2, 3),
    )
    overflow = getattr(
        settings,
        "THERAFLOW_THERAPY_OVERFLOW_WEEKDAYS",
        (1, 4),
    )
    return _normalized_weekdays((*primary, *overflow))


def is_allowed_therapy_date(datum, *, lijek=None, protokol=None):
    if datum is None or datum.weekday() >= 5:
        return False
    return datum.weekday() in allowed_therapy_weekdays(
        lijek=lijek,
        protokol=protokol,
    )


def demo_weekend_appointments_enabled():
    """Centralni opt-in prekidač; nikada ne utiče na automatski raspored."""

    return bool(
        getattr(
            settings,
            "THERAFLOW_DEMO_ALLOW_WEEKEND_APPOINTMENTS",
            False,
        )
    )


def user_can_create_demo_weekend_appointment(user):
    """Dozvoli ručni demo izuzetak isključivo administratoru."""

    if not demo_weekend_appointments_enabled():
        return False
    if not getattr(user, "is_authenticated", False):
        return False
    return bool(
        getattr(user, "is_superuser", False)
        or user.groups.filter(name="Admin").exists()
    )


def is_demo_weekend_calendar_date(datum):
    """Vikend zapis je vidljiv kao redovan samo dok je demo režim aktivan."""

    return bool(
        datum is not None
        and datum.weekday() >= 5
        and demo_weekend_appointments_enabled()
    )


def validate_therapy_date(
    datum,
    *,
    lijek=None,
    protokol=None,
    allow_demo_weekend=False,
):
    if datum is None:
        return datum
    if datum.weekday() >= 5 and allow_demo_weekend:
        return datum
    if datum.weekday() >= 5:
        raise ValidationError(WEEKEND_MESSAGE)
    if not is_allowed_therapy_date(
        datum,
        lijek=lijek,
        protokol=protokol,
    ):
        raise ValidationError(DISALLOWED_DAY_MESSAGE)
    return datum


def validate_new_active_appointment_date(datum, *, today=None):
    """Aktivan termin se ne smije kreirati retroaktivno."""

    today = today or timezone.localdate()
    if datum is not None and datum < today:
        raise ValidationError(
            "Novi aktivni termin ne može biti kreiran u prošlosti. "
            "Unesite historijski događaj ili odaberite današnji/budući datum."
        )
    return datum


def adjust_to_allowed_therapy_date(
    datum,
    *,
    lijek=None,
    protokol=None,
    direction=1,
):
    """Pomjeri na prvi konfiguracijom dozvoljen terapijski dan.

    Produkcijsko planiranje koristi podrazumijevano pomjeranje unaprijed.
    ``direction=-1`` postoji samo za sigurno datiranje historijskih/demo zapisa.
    """

    if is_allowed_therapy_date(datum, lijek=lijek, protokol=protokol):
        return ScheduledDate(datum=datum, prilagodjen=False)

    step = 1 if direction >= 0 else -1
    candidate = datum
    for _ in range(14):
        candidate += timedelta(days=step)
        if is_allowed_therapy_date(
            candidate,
            lijek=lijek,
            protokol=protokol,
        ):
            return ScheduledDate(
                datum=candidate,
                prilagodjen=True,
                razlog=(
                    "Datum je automatski prilagođen na dozvoljeni terapijski "
                    "dan jer je izračunati datum bio neradni ili nedozvoljeni dan."
                ),
            )
    raise ValidationError(
        "Nije pronađen dozvoljeni terapijski dan u naredne dvije sedmice."
    )


def weekend_appointments_queryset(queryset):
    """Administrativna provjera postojećih subotnjih i nedjeljnih termina."""

    return queryset.filter(
        Q(datum__week_day=1) | Q(datum__week_day=7)
    )
