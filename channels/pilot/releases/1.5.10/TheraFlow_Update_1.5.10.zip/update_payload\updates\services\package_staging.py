import json
import logging
import os
import re
import shutil
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath

from django.conf import settings
from django.utils import timezone
from packaging.version import InvalidVersion

from theraflow.version import __version__, parse_version, validate_version_identifier

from .preparation_backup import sha256_file
from .preparation_backup import canonical_env_file
from .update_paths import ensure_child, get_update_paths


logger = logging.getLogger(__name__)
UPDATER_VERSION = "1.0.0"
PACKAGE_FORMAT = 1
MAX_ZIP_FILES = 10_000
MAX_UNCOMPRESSED_SIZE = 2 * 1024 * 1024 * 1024
MAX_COMPRESSION_RATIO = 200
ALLOWED_PRESERVE_PATHS = {".env", "media", "backups", "logs", "data", "staticfiles"}
REQUIRED_PRESERVE_PATHS = {".env", "media", "backups", "logs", "data"}
PROTECTED_DELETE_PATHS = ALLOWED_PRESERVE_PATHS | {".venv", "vendor", "service"}
ALLOWED_EXECUTABLES = {
    "update_payload/start_theraflow.bat",
    "update_payload/install_runtime.bat",
    "update_payload/install_runtime.ps1",
    "update_payload/verify_test_update.bat",
    "update_payload/verify_test_update.ps1",
    "update_payload/service/install_service.bat",
    "update_payload/service/install_backup_scheduler_service.bat",
    "update_payload/service/backup_scheduler_service.py",
    "update_payload/service/install_updater_service.bat",
    "update_payload/service/restart_service.bat",
    "update_payload/service/uninstall_service.bat",
}
EXPECTED_PACKAGE_FIELDS = {
    "package_format", "version", "application", "entrypoint", "required_files",
    "preserve_paths", "delete_paths", "migration_required", "collectstatic_required",
    "minimum_updater_version",
}


class PackageValidationError(RuntimeError):
    pass


class StagingError(RuntimeError):
    pass


def _validate_install_service_batch(path):
    try:
        raw = Path(path).read_bytes()
    except OSError as exc:
        raise PackageValidationError(
            "Update paket nema citljiv install_service.bat."
        ) from exc
    if raw.startswith((b"\xef\xbb\xbf", b"\xff\xfe", b"\xfe\xff")):
        raise PackageValidationError("install_service.bat ne smije sadrzavati BOM.")
    if any(byte > 127 for byte in raw):
        raise PackageValidationError(
            "install_service.bat mora koristiti ASCII-safe cmd.exe encoding."
        )
    if b"\r\n" not in raw or re.search(rb"(?<!\r)\n", raw):
        raise PackageValidationError(
            "install_service.bat mora koristiti iskljucivo CRLF zavrsetke."
        )
    text = raw.decode("ascii")
    calls = re.findall(r"(?im)^\s*call\s+:nssm_set\b", text)
    labels = re.findall(r"(?im)^:nssm_set\s*\r?$", text)
    if not calls or len(labels) != 1:
        raise PackageValidationError(
            "install_service.bat nema pouzdan nssm_set call/label ugovor."
        )
    if "INSTALL_SERVICE_SELF_TEST_PASS" not in text:
        raise PackageValidationError(
            "install_service.bat nema obavezni cmd.exe self-test."
        )


def safe_relative_path(value, label="putanja"):
    if not isinstance(value, str) or not value or "\x00" in value or "\\" in value:
        raise PackageValidationError(f"Neispravna {label}.")
    posix = PurePosixPath(value)
    windows = PureWindowsPath(value)
    if posix.is_absolute() or windows.is_absolute() or windows.drive or ".." in posix.parts:
        raise PackageValidationError(f"Neispravna {label}.")
    if any(part in {"", "."} for part in posix.parts):
        raise PackageValidationError(f"Neispravna {label}.")
    return posix


def revalidate_package(session):
    paths = get_update_paths()
    package = Path(session.package_path).resolve()
    if package.parent != paths.packages.resolve() or not package.is_file():
        raise PackageValidationError("Validirani update paket nije pronađen.")
    try:
        target = validate_version_identifier(session.target_version)
        current = parse_version(__version__)
    except InvalidVersion as exc:
        raise PackageValidationError("Update verzija nije ispravna.") from exc
    if parse_version(target) <= current:
        raise PackageValidationError("Ciljna verzija nije novija od instalirane verzije.")
    expected_name = f"TheraFlow_Update_{target}.zip"
    snapshot_version = str(session.manifest_snapshot.get("version", ""))
    snapshot_hash = str(session.manifest_snapshot.get("sha256", "")).lower()
    if package.name != expected_name or snapshot_version != target or snapshot_hash != session.package_sha256:
        raise PackageValidationError("Paket i validirani manifest se ne podudaraju.")
    if sha256_file(package) != session.package_sha256:
        raise PackageValidationError("SHA-256 update paketa više nije ispravan.")
    logger.info("Update paket verzije %s je ponovo SHA-256 validiran.", target)
    return package


def inspect_zip(package_path, max_files=MAX_ZIP_FILES, max_size=MAX_UNCOMPRESSED_SIZE, max_ratio=MAX_COMPRESSION_RATIO):
    try:
        archive = zipfile.ZipFile(package_path, "r")
    except (OSError, zipfile.BadZipFile) as exc:
        raise StagingError("Update paket nije validan ZIP dokument.") from exc
    infos = archive.infolist()
    files = [info for info in infos if not info.is_dir()]
    if len(files) > max_files:
        archive.close()
        raise StagingError("Update paket sadrži previše fajlova.")
    total_size = sum(info.file_size for info in files)
    total_compressed = sum(info.compress_size for info in files)
    if total_size > max_size:
        archive.close()
        raise StagingError("Raspakovana veličina update paketa prelazi sigurnosni limit.")
    if total_size and (total_compressed == 0 or total_size / max(total_compressed, 1) > max_ratio):
        archive.close()
        raise StagingError("Update paket ima sumnjiv omjer kompresije.")
    try:
        for info in infos:
            safe_relative_path(info.filename, "ZIP putanja")
            mode = (info.external_attr >> 16) & 0o170000
            if mode == stat.S_IFLNK:
                raise StagingError("Simbolički linkovi nisu dozvoljeni u update paketu.")
    except Exception:
        archive.close()
        raise
    return archive, infos, total_size


def safe_extract(package_path, staging_root, **limits):
    staging_root = Path(staging_root).resolve()
    if staging_root.exists():
        raise StagingError("Staging direktorij već postoji.")
    staging_root.mkdir(parents=True)
    written = 0
    try:
        archive, infos, declared_total = inspect_zip(package_path, **limits)
        with archive:
            for info in infos:
                relative = Path(*PurePosixPath(info.filename).parts)
                target = (staging_root / relative).resolve()
                if staging_root != target and staging_root not in target.parents:
                    raise StagingError("ZIP putanja izlazi iz staging direktorija.")
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info, "r") as source, target.open("wb") as output:
                    while True:
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        written += len(chunk)
                        if written > declared_total or written > limits.get("max_size", MAX_UNCOMPRESSED_SIZE):
                            raise StagingError("Raspakovana veličina prelazi deklarisani sigurnosni limit.")
                        output.write(chunk)
        return staging_root
    except Exception:
        shutil.rmtree(staging_root, ignore_errors=True)
        raise


def _validate_list_of_paths(values, label):
    if not isinstance(values, list):
        raise PackageValidationError(f"{label} mora biti lista.")
    return [str(safe_relative_path(value, label)) for value in values]


def validate_package_manifest(staging_root, target_version):
    staging_root = Path(staging_root).resolve()
    manifest_path = staging_root / "theraflow-update.json"
    if not manifest_path.is_file():
        raise PackageValidationError("Nedostaje theraflow-update.json.")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise PackageValidationError("Package manifest nije validan JSON.") from exc
    if not isinstance(manifest, dict) or EXPECTED_PACKAGE_FIELDS - manifest.keys():
        raise PackageValidationError("Package manifest nema sva obavezna polja.")
    if manifest["application"] != "TheraFlow" or manifest["package_format"] != PACKAGE_FORMAT:
        raise PackageValidationError("Package format ili aplikacija nisu podržani.")
    try:
        if parse_version(manifest["version"]) != parse_version(target_version):
            raise PackageValidationError("Verzija paketa ne odgovara validiranom manifestu.")
        if parse_version(manifest["minimum_updater_version"]) > parse_version(UPDATER_VERSION):
            raise PackageValidationError("Paket zahtijeva noviju verziju update helpera.")
    except InvalidVersion as exc:
        raise PackageValidationError("Verzija u package manifestu nije ispravna.") from exc
    if type(manifest["migration_required"]) is not bool or type(manifest["collectstatic_required"]) is not bool:
        raise PackageValidationError("Migration i collectstatic oznake moraju biti boolean.")
    entrypoint = str(safe_relative_path(manifest["entrypoint"], "entrypoint putanja"))
    payload_root = (staging_root / Path(*PurePosixPath(entrypoint).parts)).resolve()
    if not payload_root.is_dir() or staging_root not in payload_root.parents:
        raise PackageValidationError("Package entrypoint ne postoji.")
    required = _validate_list_of_paths(manifest["required_files"], "required_files")
    preserve = _validate_list_of_paths(manifest["preserve_paths"], "preserve_paths")
    delete = _validate_list_of_paths(manifest["delete_paths"], "delete_paths")
    if any(PurePosixPath(path).parts[0] not in ALLOWED_PRESERVE_PATHS for path in preserve):
        raise PackageValidationError("Package sadrži nedozvoljenu preserve putanju.")
    if not REQUIRED_PRESERVE_PATHS.issubset({PurePosixPath(path).parts[0] for path in preserve}):
        raise PackageValidationError("Package ne štiti sve obavezne lokalne putanje.")
    if any(PurePosixPath(path).parts[0].lower() in PROTECTED_DELETE_PATHS for path in delete):
        raise PackageValidationError("Package pokušava obrisati zaštićenu lokalnu putanju.")
    for relative in required:
        candidate = (payload_root / Path(*PurePosixPath(relative).parts)).resolve()
        if payload_root not in candidate.parents or not candidate.is_file():
            raise PackageValidationError(f"Nedostaje obavezni package fajl: {relative}")
    manifest.update({"entrypoint": entrypoint, "required_files": required, "preserve_paths": preserve, "delete_paths": delete})
    return manifest, manifest_path, payload_root


def validate_staging(staging_root, target_version):
    manifest, manifest_path, payload_root = validate_package_manifest(staging_root, target_version)
    if not (payload_root / "manage.py").is_file():
        raise PackageValidationError("Novi payload nema manage.py.")
    version_path = payload_root / "theraflow" / "version.py"
    if not version_path.is_file():
        raise PackageValidationError("Novi payload nema theraflow/version.py.")
    version_match = re.search(r"__version__\s*=\s*['\"]([^'\"]+)['\"]", version_path.read_text(encoding="utf-8"))
    if not version_match or parse_version(version_match.group(1)) != parse_version(target_version):
        raise PackageValidationError("version.py u payloadu ne odgovara ciljnoj verziji.")
    install_service_batch = payload_root / "service" / "install_service.bat"
    if install_service_batch.is_file():
        _validate_install_service_batch(install_service_batch)
    allowed = set(getattr(settings, "THERAFLOW_UPDATE_ALLOWED_EXECUTABLES", ALLOWED_EXECUTABLES))
    for path in Path(staging_root).rglob("*"):
        if path.is_dir() and path.name.lower() == ".git":
            raise PackageValidationError("Update paket sadrži zabranjeni .git direktorij.")
        if not path.is_file():
            continue
        relative = path.relative_to(staging_root).as_posix()
        payload_relative = path.relative_to(payload_root) if payload_root in path.parents else None
        lowered_parts = {part.lower() for part in path.relative_to(staging_root).parts}
        suffix = path.suffix.lower()
        if ".git" in lowered_parts or path.name.lower() == ".env":
            raise PackageValidationError("Update paket sadrži zabranjeni lokalni ili repository fajl.")
        if payload_relative and payload_relative.parts and payload_relative.parts[0].lower() in ALLOWED_PRESERVE_PATHS:
            raise PackageValidationError("Update payload pokušava direktno uključiti lokalne korisničke podatke.")
        if suffix in {".dump", ".backup", ".sql", ".mdf", ".ldf"} or "pg_wal" in lowered_parts or "base" in lowered_parts and "postgres" in lowered_parts:
            raise PackageValidationError("Update paket sadrži database ili PostgreSQL data fajl.")
        if suffix in {".exe", ".bat", ".ps1"} and relative not in allowed:
            raise PackageValidationError(f"Nedozvoljeni izvršni fajl u update paketu: {relative}")
    logger.info("Package manifest i staging sadržaj su validirani.")
    return manifest, manifest_path, payload_root


def create_install_plan(session, package_manifest, package_manifest_path, payload_root, database_backup_path, config_backup_path, postgres_tools=None):
    paths = get_update_paths()
    plan_dir = paths.sessions / str(session.pk)
    plan_dir.mkdir(parents=True, exist_ok=False)
    replace_paths = sorted(path.name for path in payload_root.iterdir() if path.name not in package_manifest["preserve_paths"])
    plan = {
        "session_id": str(session.pk),
        "current_version": __version__,
        "target_version": session.target_version,
        "application_root": str(Path(settings.BASE_DIR).resolve()),
        "staging_root": str(Path(session.staging_directory).resolve()),
        "payload_root": str(Path(payload_root).resolve()),
        "backup_root": str(Path(session.backup_directory).resolve()),
        "database_backup_path": str(Path(database_backup_path).resolve()),
        "config_backup_path": str(Path(config_backup_path).resolve()),
        "canonical_env_path": str(canonical_env_file()),
        "preserve_paths": package_manifest["preserve_paths"],
        "replace_paths": replace_paths,
        "delete_paths": package_manifest["delete_paths"],
        "migration_required": package_manifest["migration_required"],
        "collectstatic_required": package_manifest["collectstatic_required"],
        "service_name": settings.THERAFLOW_SERVICE_NAME,
        "health_check_url": settings.THERAFLOW_HEALTH_CHECK_URL,
        "created_at": timezone.now().isoformat(),
        "package_sha256": session.package_sha256,
        "package_manifest_sha256": sha256_file(package_manifest_path),
        "python_executable": str(Path(sys.executable).resolve()),
        "postgres_tools": dict(postgres_tools or {}),
    }
    plan_path = plan_dir / "install_plan.json"
    plan_path.write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding="utf-8")
    return plan_path, plan
