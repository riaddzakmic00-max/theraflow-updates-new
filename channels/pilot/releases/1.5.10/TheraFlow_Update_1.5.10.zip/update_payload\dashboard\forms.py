from django import forms
from django.contrib.auth import get_user_model, password_validation
from django.core.exceptions import ValidationError
from decimal import Decimal
import uuid

from django.utils import timezone
from django.db.models import Q

from patients.models import (
    DokumentPacijenta,
    IndividualniProtokolPacijenta,
    KucnoIzdavanje,
    Komisija,
    KomisijskiCiklus,
    KomisijskaSaglasnost,
    KomisijskaStavkaLijeka,
    KomisijskiZahtjev,
    Lijek,
    OralniTerapijskiRezim,
    StandardniOralniRezim,
    FazniProtokolPacijenta,
    MigracijskoPocetnoStanjeZalihe,
    MigracijskiSnapshotPacijenta,
    Pacijent,
    PromjenaTerapije,
    TerapijskaFaza,
    TerapijskiProgram,
    TerapijskiProtokol,
    Termin,
)
from patients.migration_calculations import (
    MAX_INDIVIDUAL_INTERVAL_WEEKS,
    MIN_INDIVIDUAL_INTERVAL_WEEKS,
    calculate_next_therapy_date,
)
from patients.medicine_registry import (
    active_products_for_program,
    active_therapy_programs,
    active_therapy_medicines,
    default_product_for_program,
    ensure_program_for_product,
    initial_phase_for_program,
    uses_specialized_protocol_engine,
)
from patients.scheduling import (
    adjust_to_allowed_therapy_date,
    validate_therapy_date,
)
from dashboard.user_access import ROLE_CHOICES


class KomisijskiZahtjevPhase2Form(forms.ModelForm):
    class Meta:
        model = KomisijskiZahtjev
        fields = (
            "vrsta_zahtjeva",
            "request_type_override_reason",
            "ljekar_trazi",
            "finalna_kolicina",
            "prethodni_lijek",
            "novi_lijek",
            "preostala_kolicina_prethodnog_lijeka",
            "razlog_odjave",
            "napomena",
        )
        labels = {
            "vrsta_zahtjeva": "Vrsta zahtjeva",
            "request_type_override_reason": "Razlog izmjene vrste zahtjeva",
            "ljekar_trazi": "Ljekar traži",
            "finalna_kolicina": "Konačna količina",
            "prethodni_lijek": "Prethodni lijek",
            "novi_lijek": "Novi lijek",
            "preostala_kolicina_prethodnog_lijeka": "Preostalo starog lijeka",
            "razlog_odjave": "Razlog odjave",
            "napomena": "Napomena",
        }
        widgets = {
            "ljekar_trazi": forms.NumberInput(attrs={"min": "0", "step": "0.01"}),
            "finalna_kolicina": forms.NumberInput(attrs={"min": "0", "step": "0.01"}),
            "preostala_kolicina_prethodnog_lijeka": forms.NumberInput(
                attrs={"min": "0", "step": "0.01"}
            ),
            "razlog_odjave": forms.Textarea(attrs={"rows": 3}),
            "request_type_override_reason": forms.Textarea(attrs={"rows": 2}),
            "napomena": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["novi_lijek"].queryset = active_therapy_medicines(
            include_ids=(getattr(self.instance, "novi_lijek_id", None),)
        )
        for name in (
            "ljekar_trazi",
            "finalna_kolicina",
            "preostala_kolicina_prethodnog_lijeka",
        ):
            self.fields[name].min_value = Decimal("0")

    def clean(self):
        cleaned = super().clean()
        selected = cleaned.get("vrsta_zahtjeva")
        original = (
            KomisijskiZahtjev.objects.filter(pk=self.instance.pk)
            .values_list("vrsta_zahtjeva", flat=True)
            .first()
            if self.instance.pk
            else None
        )
        if (
            original
            and selected
            and selected != original
            and not (cleaned.get("request_type_override_reason") or "").strip()
        ):
            self.add_error(
                "request_type_override_reason",
                "Navedite razlog izmjene vrste zahtjeva.",
            )
        return cleaned
        return cleaned


class KomisijskaStavkaLijekaPhase2Form(forms.ModelForm):
    class Meta:
        model = KomisijskaStavkaLijeka
        fields = (
            "lijek",
            "jacina",
            "oblik",
            "kolicina",
            "jedinica",
            "redoslijed",
        )
        labels = {
            "lijek": "Lijek / proizvod",
            "jacina": "Jačina",
            "oblik": "Oblik",
            "kolicina": "Tražena količina",
            "jedinica": "Jedinica",
            "redoslijed": "Redoslijed",
        }
        widgets = {
            "kolicina": forms.NumberInput(attrs={"min": "0", "step": "0.01"}),
            "redoslijed": forms.NumberInput(attrs={"min": "1", "max": "3"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["lijek"].queryset = active_therapy_medicines(
            include_ids=(getattr(self.instance, "lijek_id", None),)
        )
        self.fields["kolicina"].min_value = Decimal("0")
        if not self.instance.pk:
            # Model default 1 ne smije učiniti praznu dodatnu formu "izmijenjenom".
            self.initial["redoslijed"] = None
            self.fields["redoslijed"].initial = None

    def save(self, commit=True):
        instance = super().save(commit=False)
        if instance.lijek_id and (
            "lijek" in self.changed_data
            or not instance.genericki_naziv
            or not instance.zasticeni_naziv
        ):
            instance.genericki_naziv = instance.lijek.genericki_naziv
            instance.zasticeni_naziv = (
                instance.lijek.zasticeno_ime or instance.lijek.naziv
            )
        if commit:
            instance.save()
            self.save_m2m()
        return instance


KomisijskaStavkaLijekaPhase2FormSet = forms.inlineformset_factory(
    KomisijskiZahtjev,
    KomisijskaStavkaLijeka,
    form=KomisijskaStavkaLijekaPhase2Form,
    extra=1,
    can_delete=True,
    max_num=3,
    validate_max=True,
)


class KomisijskaSaglasnostPhase3Form(forms.ModelForm):
    class Meta:
        model = KomisijskaSaglasnost
        fields = (
            "broj_saglasnosti",
            "datum_saglasnosti",
            "odluka",
            "napomena",
        )
        labels = {
            "broj_saglasnosti": "Broj saglasnosti",
            "datum_saglasnosti": "Datum",
            "odluka": "Odluka",
            "napomena": "Napomena / razlog",
        }
        widgets = {
            "datum_saglasnosti": forms.DateInput(attrs={"type": "date"}),
            "napomena": forms.Textarea(attrs={"rows": 2}),
        }

    def __init__(self, *args, commission_request, form_id=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.commission_request = commission_request
        self.form_id = form_id or f"phase3-agreement-{commission_request.pk}"
        self.fields["broj_saglasnosti"].required = False
        self.fields["datum_saglasnosti"].required = True
        self.fields["odluka"].widget.attrs["data-agreement-decision"] = ""
        self.approved_field_names = []

        for field in self.fields.values():
            field.widget.attrs["form"] = self.form_id

        for item in commission_request.stavke_lijeka.order_by("redoslijed", "pk"):
            name = f"odobreno_{item.pk}"
            self.fields[name] = forms.DecimalField(
                label=f"Odobreno – {item.zasticeni_naziv or item.lijek}",
                required=False,
                min_value=Decimal("0"),
                max_digits=10,
                decimal_places=2,
                initial=item.odobrena_kolicina,
                widget=forms.NumberInput(
                    attrs={
                        "min": "0",
                        "step": "0.01",
                        "form": self.form_id,
                        "data-approved-quantity": "",
                        "data-requested": str(item.kolicina),
                    }
                ),
            )
            self.approved_field_names.append(name)

    def clean(self):
        cleaned = super().clean()
        decision = cleaned.get("odluka")
        if not decision:
            return cleaned
        if decision in {
            KomisijskaSaglasnost.Odluka.ODOBRENO,
            KomisijskaSaglasnost.Odluka.DJELIMICNO_ODOBRENO,
        } and not (cleaned.get("broj_saglasnosti") or "").strip():
            self.add_error(
                "broj_saglasnosti",
                "Broj saglasnosti je obavezan za ovu odluku.",
            )
        quantities = {
            int(name.removeprefix("odobreno_")): cleaned.get(name)
            for name in self.approved_field_names
        }
        from dashboard.commission_phase2 import normalize_agreement_quantities

        try:
            self.normalized_quantities = normalize_agreement_quantities(
                self.commission_request,
                decision,
                quantities,
            )
        except ValidationError as exc:
            self.add_error(None, exc)
        return cleaned


class UstekinumabProtocolSetupForm(forms.Form):
    faza = forms.ChoiceField(
        label="Trenutna faza",
        choices=FazniProtokolPacijenta.FAZE,
    )
    iv_lijek = forms.ModelChoiceField(
        label="Ustekinumab 130 mg IV",
        queryset=Lijek.objects.none(),
    )
    sc_lijek = forms.ModelChoiceField(
        label="Ustekinumab 90 mg SC",
        queryset=Lijek.objects.none(),
    )
    pocetna_iv_doza_mg = forms.DecimalField(
        label="Početna IV doza određena od ljekara",
        help_text="Unesite dozu koju je odredio ljekar.",
        required=False,
        min_value=Decimal("0.01"),
        max_digits=8,
        decimal_places=2,
        widget=forms.NumberInput(
            attrs={"min": "0.01", "step": "0.01", "inputmode": "decimal"}
        ),
    )
    interval_odrzavanja_sedmica = forms.TypedChoiceField(
        label="Potvrđeni interval održavanja",
        choices=FazniProtokolPacijenta.INTERVALI_ODRZAVANJA,
        coerce=int,
        initial=8,
    )
    datum_zadnje_stvarne_doze = forms.DateField(
        label="Datum zadnje stvarne doze",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    planirani_datum = forms.DateField(
        label="Planirani datum trenutne faze",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    planirano_vrijeme = forms.TimeField(
        label="Vrijeme",
        required=False,
        widget=forms.TimeInput(attrs={"type": "time"}),
    )
    kreiraj_komisijski_prijedlog = forms.BooleanField(
        label="Kreiraj komisijski prijedlog koji ljekar potvrđuje",
        required=False,
    )
    komisijski_ciklus = forms.ModelChoiceField(
        label="Komisijski ciklus",
        queryset=KomisijskiCiklus.objects.none(),
        required=False,
    )
    vrsta_zahtjeva = forms.ChoiceField(
        label="Vrsta komisijskog zahtjeva",
        choices=(
            (
                KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_NOVI,
                "Biološka terapija – novi",
            ),
            (
                KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH,
                "Biološka terapija – promjena/switch",
            ),
        ),
        initial=KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_NOVI,
    )
    ukljuci_prvu_sc = forms.BooleanField(
        label="Uključi 1 × 90 mg SC ako projekcija ciklusa to zahtijeva",
        required=False,
    )
    prethodni_lijek = forms.ModelChoiceField(
        label="Prethodni lijek kod switcha",
        queryset=Lijek.objects.none(),
        required=False,
    )

    def __init__(self, *args, patient, state=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.patient = patient
        self.state = state
        from patients.medication_groups import (
            medicine_group_q,
            medicine_presentation_key,
        )

        candidates = list(
            active_therapy_medicines().filter(medicine_group_q("ustekinumab"))
        )
        iv_ids = [
            item.pk
            for item in candidates
            if medicine_presentation_key(item) == "ustekinumab:IV:130"
        ]
        sc_ids = [
            item.pk
            for item in candidates
            if medicine_presentation_key(item) == "ustekinumab:SC:90"
        ]
        self.fields["iv_lijek"].queryset = Lijek.objects.filter(pk__in=iv_ids)
        self.fields["sc_lijek"].queryset = Lijek.objects.filter(pk__in=sc_ids)
        self.fields["komisijski_ciklus"].queryset = KomisijskiCiklus.objects.order_by(
            "-datum_komisije", "-pk"
        )
        self.fields["prethodni_lijek"].queryset = Lijek.objects.order_by("naziv")
        if state and not self.is_bound:
            self.initial.update(
                {
                    "faza": state.faza,
                    "iv_lijek": state.iv_lijek_id,
                    "sc_lijek": state.sc_lijek_id,
                    "pocetna_iv_doza_mg": state.indukcijska_doza_mg,
                    "interval_odrzavanja_sedmica": (
                        state.interval_odrzavanja_sedmica
                    ),
                    "datum_zadnje_stvarne_doze": (
                        state.datum_posljednje_primjene
                    ),
                    "komisijski_ciklus": (
                        state.pocetni_komisijski_zahtjev.komisijski_ciklus_id
                        if state.pocetni_komisijski_zahtjev_id else None
                    ),
                }
            )

    def clean(self):
        cleaned = super().clean()
        phase = cleaned.get("faza")
        if phase == FazniProtokolPacijenta.FAZA_CEKA_IV:
            prescribed_dose = cleaned.get("pocetna_iv_doza_mg")
            if prescribed_dose is None:
                self.add_error(
                    "pocetna_iv_doza_mg",
                    "Unesite početnu IV dozu koju je odredio ljekar.",
                )
            elif cleaned.get("iv_lijek"):
                from patients.phased_protocols import ustekinumab_iv_logistics

                try:
                    ustekinumab_iv_logistics(
                        prescribed_dose,
                        cleaned["iv_lijek"],
                    )
                except ValidationError as exc:
                    self.add_error("pocetna_iv_doza_mg", exc)
        elif not cleaned.get("datum_zadnje_stvarne_doze"):
            self.add_error(
                "datum_zadnje_stvarne_doze",
                "Za postojeći protokol unesite datum zadnje stvarne doze.",
            )
        if bool(cleaned.get("planirani_datum")) != bool(
            cleaned.get("planirano_vrijeme")
        ):
            self.add_error(
                "planirano_vrijeme",
                "Za termin unesite i datum i vrijeme.",
            )
        if (
            cleaned.get("kreiraj_komisijski_prijedlog")
            and not cleaned.get("komisijski_ciklus")
        ):
            self.add_error(
                "komisijski_ciklus",
                "Odaberite ciklus za komisijski prijedlog.",
            )
        if (
            cleaned.get("vrsta_zahtjeva")
            == KomisijskiZahtjev.VrstaZahtjeva.BIOLOSKA_SWITCH
            and cleaned.get("kreiraj_komisijski_prijedlog")
            and not cleaned.get("prethodni_lijek")
        ):
            self.add_error(
                "prethodni_lijek",
                "Kod switcha odaberite prethodni lijek.",
            )
        return cleaned


class UstekinumabPhaseScheduleForm(forms.Form):
    datum = forms.DateField(
        label="Datum",
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    vrijeme = forms.TimeField(
        label="Vrijeme",
        widget=forms.TimeInput(attrs={"type": "time"}),
    )


class UstekinumabIntervalChangeForm(forms.Form):
    interval_odrzavanja_sedmica = forms.TypedChoiceField(
        label="Novi interval",
        choices=FazniProtokolPacijenta.INTERVALI_ODRZAVANJA,
        coerce=int,
    )
    razlog = forms.CharField(
        label="Razlog promjene",
        widget=forms.Textarea(attrs={"rows": 2}),
    )


class DodjelaSlobodneZaliheForm(forms.Form):
    """Cjelobrojna operativna količina za fizički nedjeljive jedinice."""

    def __init__(self, *args, max_quantity=0, **kwargs):
        super().__init__(*args, **kwargs)
        available = Decimal(str(max_quantity or 0))
        normalized_max = max(0, int(available))
        self.fields["kolicina"] = forms.IntegerField(
            label="Količina",
            min_value=1,
            max_value=normalized_max,
            error_messages={
                "invalid": "Unesite cijeli broj.",
                "min_value": "Količina mora biti najmanje 1.",
                "max_value": f"Dostupno je najviše {normalized_max} jedinica.",
            },
            widget=forms.NumberInput(attrs={
                "min": "1",
                "max": str(normalized_max),
                "step": "1",
                "inputmode": "numeric",
            }),
        )


class IndividualniProtokolPacijentaForm(forms.ModelForm):
    razlog_izmjene = forms.CharField(
        label="Razlog izmjene",
        widget=forms.Textarea(attrs={"rows": 3}),
        help_text="Obavezno za audit trag. Ne unositi nepotrebne osjetljive podatke.",
        error_messages={"required": "Ovo polje je obavezno."},
    )
    datum_odluke = forms.DateField(
        label="Datum odluke",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    ljekar_koji_je_donio_odluku = forms.CharField(
        label="Ljekar koji je donio odluku",
        required=False,
        max_length=150,
    )
    povezani_dokument = forms.ModelChoiceField(
        label="Povezani dokument",
        required=False,
        queryset=DokumentPacijenta.objects.none(),
    )

    class Meta:
        model = IndividualniProtokolPacijenta
        fields = [
            "aktivan",
            "naziv",
            "sigurnosna_rezerva_primjena",
            "maksimalna_sigurnosna_rezerva_primjena",
        ]
        labels = {
            "aktivan": "Koristi individualni protokol",
            "naziv": "Naziv protokola",
            "sigurnosna_rezerva_primjena": "Sigurnosna rezerva (primjena)",
            "maksimalna_sigurnosna_rezerva_primjena": (
                "Maksimalna rezerva (primjena)"
            ),
        }

    def __init__(self, *args, pacijent=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["datum_odluke"].initial = timezone.localdate()
        if pacijent:
            self.fields["povezani_dokument"].queryset = (
                DokumentPacijenta.objects.filter(pacijent=pacijent).order_by(
                    "-datum_dokumenta", "-id"
                )
            )

    def clean(self):
        cleaned = super().clean()
        reserve = cleaned.get("sigurnosna_rezerva_primjena")
        maximum = cleaned.get("maksimalna_sigurnosna_rezerva_primjena")
        if reserve is not None and maximum is not None and reserve > maximum:
            self.add_error(
                "sigurnosna_rezerva_primjena",
                "Sigurnosna rezerva ne može biti veća od maksimalne rezerve.",
            )
        return cleaned



class IndukcijskiKorakForm(forms.Form):
    redoslijed = forms.IntegerField(label="Redoslijed", min_value=1)
    sedmica_od_pocetka = forms.IntegerField(label="Sedmica od početka", min_value=0)
    doza_mg = forms.DecimalField(label="Doza (mg)", min_value=Decimal("0.01"), decimal_places=2)
    broj_jedinica = forms.DecimalField(
        label="Broj jedinica",
        min_value=Decimal("0.01"),
        decimal_places=2,
    )
    nacin_primjene = forms.ChoiceField(
        label="Način primjene",
        choices=IndividualniProtokolPacijenta.MJESTA_PRIMJENE,
    )
    DELETE = forms.BooleanField(required=False, widget=forms.HiddenInput)


class BaseIndukcijskiKorakFormSet(forms.BaseFormSet):
    def clean(self):
        super().clean()
        if any(self.errors):
            return

        redoslijedi = set()
        sedmice = set()
        for form in self.forms:
            if not form.cleaned_data or form.cleaned_data.get("DELETE"):
                continue
            redoslijed = form.cleaned_data["redoslijed"]
            sedmica = form.cleaned_data["sedmica_od_pocetka"]
            if redoslijed in redoslijedi:
                raise ValidationError("Redoslijed indukcijskih koraka ne smije biti dupliran.")
            if sedmica in sedmice:
                raise ValidationError("Sedmica indukcijskog koraka ne smije biti duplirana.")
            redoslijedi.add(redoslijed)
            sedmice.add(sedmica)


IndukcijskiKorakFormSet = forms.formset_factory(
    IndukcijskiKorakForm,
    formset=BaseIndukcijskiKorakFormSet,
    extra=0,
    max_num=50,
    validate_max=True,
)


class OdrzavanjeIndividualnogProtokolaForm(forms.Form):
    sedmica_od_pocetka = forms.IntegerField(
        label="Početak održavanja (sedmica)",
        min_value=0,
    )
    doza_mg = forms.DecimalField(
        label="Doza (mg)",
        min_value=Decimal("0.01"),
        decimal_places=2,
    )
    broj_jedinica = forms.DecimalField(
        label="Broj jedinica",
        min_value=Decimal("0.01"),
        decimal_places=2,
    )
    interval_sedmica = forms.IntegerField(
        label="Interval održavanja (sedmice)",
        min_value=1,
        max_value=52,
    )
    nacin_primjene = forms.ChoiceField(
        label="Način primjene",
        choices=IndividualniProtokolPacijenta.MJESTA_PRIMJENE,
    )


class FirstAdminSetupForm(forms.Form):
    first_name = forms.CharField(
        label="Ime",
        max_length=150,
    )
    last_name = forms.CharField(
        label="Prezime",
        max_length=150,
    )
    username = forms.CharField(
        label="Korisnicko ime",
        max_length=150,
    )
    email = forms.EmailField(
        label="Email",
        required=False,
    )
    password1 = forms.CharField(
        label="Lozinka",
        strip=False,
        widget=forms.PasswordInput,
    )
    password2 = forms.CharField(
        label="Potvrda lozinke",
        strip=False,
        widget=forms.PasswordInput,
    )

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        User = get_user_model()
        if User.objects.filter(username__iexact=username).exists():
            raise ValidationError("Korisnicko ime je vec zauzeto.")
        return username

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get("password1")
        password2 = cleaned_data.get("password2")

        if password1 and password2 and password1 != password2:
            self.add_error("password2", "Lozinke se ne podudaraju.")

        if password1:
            user_data = get_user_model()(
                username=cleaned_data.get("username", ""),
                first_name=cleaned_data.get("first_name", ""),
                last_name=cleaned_data.get("last_name", ""),
                email=cleaned_data.get("email", ""),
            )
            try:
                password_validation.validate_password(password1, user=user_data)
            except ValidationError as exc:
                self.add_error("password1", exc)

        return cleaned_data

    def save(self):
        User = get_user_model()
        return User.objects.create_superuser(
            username=self.cleaned_data["username"],
            email=self.cleaned_data.get("email", ""),
            password=self.cleaned_data["password1"],
            first_name=self.cleaned_data["first_name"],
            last_name=self.cleaned_data["last_name"],
        )


class UserCreateForm(forms.Form):
    first_name = forms.CharField(label="Ime", max_length=150)
    last_name = forms.CharField(label="Prezime", max_length=150)
    username = forms.CharField(label="Korisničko ime", max_length=150)
    role = forms.ChoiceField(label="Uloga", choices=ROLE_CHOICES)
    temporary_password = forms.CharField(
        label="Privremena lozinka", strip=False, widget=forms.PasswordInput
    )
    temporary_password_confirm = forms.CharField(
        label="Ponovi privremenu lozinku", strip=False, widget=forms.PasswordInput
    )
    is_active = forms.BooleanField(label="Aktivan korisnik", required=False, initial=True)
    require_password_change = forms.BooleanField(
        label="Zahtijevaj promjenu lozinke pri prvoj prijavi",
        required=False,
        initial=True,
    )

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        if get_user_model().objects.filter(username__iexact=username).exists():
            raise ValidationError("Korisničko ime je već zauzeto.")
        return username

    def clean(self):
        cleaned = super().clean()
        password = cleaned.get("temporary_password")
        confirmation = cleaned.get("temporary_password_confirm")
        if password and confirmation and password != confirmation:
            self.add_error("temporary_password_confirm", "Lozinke se ne podudaraju.")
        if password:
            candidate = get_user_model()(
                username=cleaned.get("username", ""),
                first_name=cleaned.get("first_name", ""),
                last_name=cleaned.get("last_name", ""),
            )
            try:
                password_validation.validate_password(password, user=candidate)
            except ValidationError as exc:
                self.add_error("temporary_password", exc)
        return cleaned


class UserEditForm(forms.Form):
    first_name = forms.CharField(label="Ime", max_length=150)
    last_name = forms.CharField(label="Prezime", max_length=150)
    role = forms.ChoiceField(label="Uloga", choices=ROLE_CHOICES)

    def __init__(self, *args, user_instance=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.user_instance = user_instance
        if user_instance and not self.is_bound:
            from dashboard.user_access import user_role

            self.initial.update({
                "first_name": user_instance.first_name,
                "last_name": user_instance.last_name,
                "role": user_role(user_instance),
            })


class UserPasswordResetForm(forms.Form):
    temporary_password = forms.CharField(
        label="Nova privremena lozinka", strip=False, widget=forms.PasswordInput
    )
    temporary_password_confirm = forms.CharField(
        label="Ponovi privremenu lozinku", strip=False, widget=forms.PasswordInput
    )

    def __init__(self, *args, user_instance=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.user_instance = user_instance

    def clean(self):
        cleaned = super().clean()
        password = cleaned.get("temporary_password")
        confirmation = cleaned.get("temporary_password_confirm")
        if password and confirmation and password != confirmation:
            self.add_error("temporary_password_confirm", "Lozinke se ne podudaraju.")
        if password:
            try:
                password_validation.validate_password(password, user=self.user_instance)
            except ValidationError as exc:
                self.add_error("temporary_password", exc)
        return cleaned


class TerapijskiProtokolChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return f"{obj.lijek.naziv} - {obj.naziv}"


class TerapijskiProtokolSelect(forms.Select):
    def __init__(self, *args, **kwargs):
        self.protocol_option_attrs = kwargs.pop("protocol_option_attrs", {})
        super().__init__(*args, **kwargs)

    def create_option(self, name, value, label, selected, index, subindex=None, attrs=None):
        option = super().create_option(name, value, label, selected, index, subindex, attrs)
        option_value = str(value) if value is not None else ""

        if option_value in self.protocol_option_attrs:
            option["attrs"].update(self.protocol_option_attrs[option_value])

        return option


class TherapyMedicineSelect(forms.Select):
    def __init__(self, *args, **kwargs):
        self.medicine_option_attrs = kwargs.pop("medicine_option_attrs", {})
        super().__init__(*args, **kwargs)

    def create_option(self, name, value, label, selected, index, subindex=None, attrs=None):
        option = super().create_option(name, value, label, selected, index, subindex, attrs)
        option_value = str(value) if value is not None else ""
        if option_value in self.medicine_option_attrs:
            option["attrs"].update(self.medicine_option_attrs[option_value])
        return option


class StandardniOralniRezimChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        tablets = format(obj.tableta_po_uzimanju.normalize(), "f")
        daily = format(obj.tableta_dnevno.normalize(), "f")
        tablet_word = "tableta" if obj.tableta_po_uzimanju == 1 else "tablete"
        daily_word = "tableta" if obj.tableta_dnevno == 1 else "tablete"
        times_word = "put" if obj.uzimanja_dnevno == 1 else "puta"
        return (
            f"{obj.naziv} — {tablets} {tablet_word}, "
            f"{obj.uzimanja_dnevno} {times_word} dnevno — "
            f"ukupno {daily} {daily_word} dnevno"
        )


class TerapijskiProgramChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return obj.prikaz_naziv


class PacijentForm(forms.ModelForm):
    migration_mode = False
    lijek = TerapijskiProgramChoiceField(
        label="Terapija",
        queryset=TerapijskiProgram.objects.none(),
        empty_label="Odaberite terapiju",
    )
    pocetna_iv_doza_mg = forms.DecimalField(
        label="Početna IV doza određena od ljekara",
        help_text="Unesite dozu koju je odredio ljekar.",
        required=False,
        min_value=Decimal("0.01"),
        max_digits=8,
        decimal_places=2,
        widget=forms.NumberInput(
            attrs={"min": "0.01", "step": "0.01", "inputmode": "decimal"}
        ),
    )
    terapijski_protokol = TerapijskiProtokolChoiceField(
        queryset=TerapijskiProtokol.objects.filter(aktivan=True).select_related("lijek"),
        required=False,
        empty_label="Bez definisanog plana",
    )
    predlozeni_oralni_rezim = StandardniOralniRezimChoiceField(
        label="Način uzimanja",
        queryset=StandardniOralniRezim.objects.none(),
        required=False,
        empty_label="Odaberite način uzimanja",
    )

    class Meta:
        model = Pacijent
        fields = [
            "ime",
            "prezime",
            "jmbg",
            "broj_kartona",
            "spol",
            "datum_rodenja",
            "adresa",
            "kanton",
            "telefon",
            "dijagnoza",
            "mkb_sifra",
            "terapijski_protokol",
            "predlozeni_oralni_rezim",
            "pocetna_faza_terapije",
            "interval_sedmica",
            "aktivan",
        ]

        labels = {
            "ime": "Ime",
            "prezime": "Prezime",
            "jmbg": "JMBG",
            "broj_kartona": "Karton",
            "telefon": "Telefon",
            "dijagnoza": "Dijagnoza",
            "lijek": "Lijek",
            "terapijski_protokol": "Plan terapije",
            "predlozeni_oralni_rezim": "Način uzimanja",
            "pocetna_faza_terapije": "Pacijent dolazi kao",
            "interval_sedmica": "Trenutni interval terapije",
            "aktivan": "Aktivan pacijent",
        }

        widgets = {
            "datum_rodenja": forms.DateInput(attrs={"type": "date"}),
        }

    def __init__(self, *args, **kwargs):
        self._legacy_selected_product = None
        self.duplicate_patient = None
        data = kwargs.get("data")
        positional_data = data is None and bool(args)
        if positional_data:
            data = args[0]
        if data and data.get("therapy_selection_kind") != "program":
            legacy_product = Lijek.objects.filter(pk=data.get("lijek")).first()
            if legacy_product:
                program = ensure_program_for_product(legacy_product)
                data = data.copy()
                data["lijek"] = str(program.pk)
                self._legacy_selected_product = legacy_product
                if positional_data:
                    args = (data, *args[1:])
                else:
                    kwargs["data"] = data
        super().__init__(*args, **kwargs)
        self.fields["jmbg"].required = not self.migration_mode
        if self.migration_mode:
            self.fields["jmbg"].help_text = (
                "Ako demo/migracijski karton nema JMBG, ostavite polje prazno. "
                "Sistem će upozoriti na podudaranje ličnih podataka."
            )
        current_program_id = getattr(self.instance, "terapijski_program_id", None)
        if not current_program_id and getattr(self.instance, "lijek_id", None):
            current_program_id = self.instance.lijek.terapijski_program_id
        self.fields["lijek"].queryset = active_therapy_programs(
            include_ids=(current_program_id,)
        )
        if current_program_id:
            self.fields["lijek"].initial = current_program_id
        medicine_attrs = {
            str(program.pk): {
                "data-therapy-type": (
                    "oral"
                    if program.default_lijek_id and program.default_lijek.oralna_terapija
                    else "home"
                    if program.default_lijek_id and program.default_lijek.kucna_terapija
                    else "ambulatory"
                ),
                "data-route": (
                    program.default_lijek.put_primjene
                    if program.default_lijek_id else ""
                ),
                "data-phased": "true" if program.protokol_kljuc else "false",
                "data-requires-prescribed-iv-dose": (
                    "true" if program.protokol_kljuc == "ustekinumab" else "false"
                ),
                "data-default-product-id": str(program.default_lijek_id or ""),
            }
            for program in self.fields["lijek"].queryset
        }
        self.fields["lijek"].widget = TherapyMedicineSelect(
            medicine_option_attrs=medicine_attrs
        )
        self.fields["lijek"].widget.choices = self.fields["lijek"].choices

        selected_oral_product = self._legacy_selected_product
        if selected_oral_product is None and data:
            selected_product_id = data.get("trenutni_proizvod")
            if selected_product_id:
                selected_oral_product = Lijek.objects.filter(
                    pk=selected_product_id
                ).first()
            if selected_oral_product is None:
                selected_program = TerapijskiProgram.objects.filter(
                    pk=data.get("lijek")
                ).first()
                if selected_program:
                    selected_oral_product = default_product_for_program(
                        selected_program,
                        phase=initial_phase_for_program(selected_program),
                    )
        if (
            selected_oral_product is None
            and not data
            and getattr(self.instance, "lijek_id", None)
        ):
            selected_oral_product = self.instance.lijek

        oral_queryset = StandardniOralniRezim.objects.filter(
            aktivan=True,
            lijek__aktivan=True,
        ).select_related("lijek").order_by("lijek__naziv", "naziv", "id")
        if selected_oral_product is not None:
            oral_queryset = oral_queryset.filter(lijek=selected_oral_product)
        current_standard_id = getattr(self.instance, "predlozeni_oralni_rezim_id", None)
        if current_standard_id and not data:
            oral_queryset = StandardniOralniRezim.objects.filter(
                Q(
                    aktivan=True,
                    lijek__aktivan=True,
                    lijek=selected_oral_product,
                )
                | Q(pk=current_standard_id)
            ).select_related("lijek").distinct().order_by(
                "lijek__naziv", "naziv", "id"
            )
        self.fields["predlozeni_oralni_rezim"].queryset = oral_queryset
        self.fields["terapijski_protokol"].queryset = (
            TerapijskiProtokol.objects
            .filter(aktivan=True, lijek__aktivan=True)
            .select_related("lijek")
            .distinct()
            .order_by("lijek__naziv", "naziv")
        )
        self.fields["pocetna_faza_terapije"].choices = [
            (Pacijent.FAZA_INDUKCIJA, "Novi pacijent / počinje terapiju"),
            (Pacijent.FAZA_ODRZAVANJE, "Nastavlja standardni protokol"),
            (Pacijent.FAZA_INDIVIDUALNI, "Nastavlja individualni protokol"),
        ]
        self.fields["interval_sedmica"].widget = forms.Select(
            choices=[
                (2, "2 sedmice"),
                (4, "4 sedmice"),
                (6, "6 sedmica"),
                (8, "8 sedmica"),
                (12, "12 sedmica"),
            ]
        )

        protocol_attrs = {}

        for protokol in self.fields["terapijski_protokol"].queryset:
            value = str(protokol.pk)
            indukcijski_koraci = list(protokol.indukcijski_koraci())
            odrzavanje = protokol.korak_odrzavanja()
            if indukcijski_koraci:
                indukcija = "; ".join(korak.opis_za_prikaz() for korak in indukcijski_koraci)
            else:
                indukcija = ", ".join(
                    str(sedmica) for sedmica in protokol.indukcijske_sedmice_lista()
                )
            interval = (
                odrzavanje.interval_sedmica
                if odrzavanje and odrzavanje.interval_sedmica
                else protokol.interval_odrzavanja_sedmica
            )
            doza = (
                odrzavanje.broj_jedinica
                if odrzavanje
                else protokol.doza_po_aplikaciji
            )
            protocol_attrs[value] = {
                "data-lijek-id": str(protokol.lijek.terapijski_program_id or ""),
                "data-naziv": protokol.naziv,
                "data-indukcija": indukcija,
                "data-interval": str(interval),
                "data-doza": str(doza),
                "data-tip": protokol.get_tip_terapije_display(),
                "data-odrzavanje": odrzavanje.opis_za_prikaz() if odrzavanje else "",
            }

        self.fields["terapijski_protokol"].widget = TerapijskiProtokolSelect(
            protocol_option_attrs=protocol_attrs,
            attrs={"data-protocol-select": "true"},
        )
        self.fields["terapijski_protokol"].widget.choices = (
            self.fields["terapijski_protokol"].choices
        )

        oral_attrs = {
            str(regimen.pk): {
                "data-lijek-id": str(regimen.lijek.terapijski_program_id or ""),
                "data-product-id": str(regimen.lijek_id),
                "data-product-name": regimen.lijek.naziv,
                "data-naziv": regimen.naziv,
                "data-tablets-per-intake": format(
                    regimen.tableta_po_uzimanju.normalize(), "f"
                ),
                "data-intakes-per-day": str(regimen.uzimanja_dnevno),
                "data-tablets-daily": format(
                    regimen.tableta_dnevno.normalize(), "f"
                ),
                "data-phase": regimen.get_faza_display(),
                "data-package-size": str(regimen.lijek.broj_tableta_u_pakovanju or ""),
            }
            for regimen in self.fields["predlozeni_oralni_rezim"].queryset
        }
        self.fields["predlozeni_oralni_rezim"].widget = TerapijskiProtokolSelect(
            protocol_option_attrs=oral_attrs,
            attrs={"data-oral-regimen-select": "true"},
        )
        self.fields["predlozeni_oralni_rezim"].widget.choices = (
            self.fields["predlozeni_oralni_rezim"].choices
        )

    def clean_jmbg(self):
        jmbg = (self.cleaned_data.get("jmbg") or "").strip()
        if not jmbg:
            if self.migration_mode:
                return None
            raise ValidationError("Unesite JMBG pacijenta.")
        duplicate = Pacijent.objects.filter(jmbg=jmbg)
        if self.instance.pk:
            duplicate = duplicate.exclude(pk=self.instance.pk)
        self.duplicate_patient = duplicate.order_by("pk").first()
        if self.duplicate_patient:
            raise ValidationError(
                "Pacijent sa ovim JMBG-om već postoji. Otvorite postojeći karton."
            )
        return jmbg

    def clean(self):
        cleaned_data = super().clean()
        program = cleaned_data.get("lijek")
        initial_phase = initial_phase_for_program(program)
        product = (
            self._legacy_selected_product
            if self._legacy_selected_product
            and self._legacy_selected_product.terapijski_program_id
            == getattr(program, "pk", None)
            else default_product_for_program(program, phase=initial_phase)
        )
        cleaned_data["odabrani_proizvod"] = product
        protokol = cleaned_data.get("terapijski_protokol")
        oralni_rezim = cleaned_data.get("predlozeni_oralni_rezim")
        faza = cleaned_data.get("pocetna_faza_terapije")

        if (
            faza != Pacijent.FAZA_INDIVIDUALNI
            and program
            and protokol
            and protokol.lijek.terapijski_program_id != program.id
        ):
            self.add_error(
                "terapijski_protokol",
                "Izabrani plan terapije ne pripada izabranom lijeku.",
            )

        if product and faza != Pacijent.FAZA_INDIVIDUALNI:
            from patients.medication_groups import maintenance_interval_weeks

            cleaned_data["interval_sedmica"] = maintenance_interval_weeks(
                product,
                cleaned_data.get("interval_sedmica"),
            )

        if program and program.protokol_kljuc and not self.migration_mode:
            cleaned_data["pocetna_faza_terapije"] = Pacijent.FAZA_INDUKCIJA
            cleaned_data["terapijski_protokol"] = None

        if product and product.oralna_terapija:
            from patients.therapy_regimens import oral_regimen_configuration

            individual_oral = bool(cleaned_data.get("individualni_oralni_rezim"))
            configuration = oral_regimen_configuration(
                product,
                selected=oralni_rezim,
            )
            if oralni_rezim and oralni_rezim.lijek_id != product.pk:
                self.add_error(
                    "predlozeni_oralni_rezim",
                    "Izabrani oralni režim ne pripada izabranom lijeku.",
                )
            elif oralni_rezim and not oralni_rezim.aktivan:
                self.add_error(
                    "predlozeni_oralni_rezim",
                    "Izabrani standardni oralni režim više nije aktivan.",
                )
            elif individual_oral:
                cleaned_data["predlozeni_oralni_rezim"] = None
            elif not oralni_rezim and configuration["status"] == "SINGLE_AVAILABLE":
                cleaned_data["predlozeni_oralni_rezim"] = configuration["suggested"]
            elif not oralni_rezim and configuration["status"] == "MULTIPLE_REQUIRED":
                self.add_error(
                    "predlozeni_oralni_rezim",
                    "Za ovaj lijek postoji više režima. Odaberite odgovarajući prijedlog.",
                )
            cleaned_data["terapijski_protokol"] = None
        else:
            cleaned_data["predlozeni_oralni_rezim"] = None

        if program and not product:
            self.add_error(
                "lijek",
                "Podaci o lijeku nisu potpuni i terapija se ne može dodijeliti.",
            )
        if program and program.protokol_kljuc == "ustekinumab" and not self.migration_mode:
            prescribed_dose = cleaned_data.get("pocetna_iv_doza_mg")
            if prescribed_dose is None:
                self.add_error(
                    "pocetna_iv_doza_mg",
                    "Unesite početnu IV dozu koju je odredio ljekar.",
                )
            elif product:
                from patients.phased_protocols import ustekinumab_iv_logistics

                try:
                    ustekinumab_iv_logistics(prescribed_dose, product)
                except ValidationError as exc:
                    self.add_error("pocetna_iv_doza_mg", exc)

        return cleaned_data

    def save(self, commit=True):
        program = self.cleaned_data.get("lijek")
        product = (
            self.cleaned_data.get("trenutni_proizvod")
            or self.cleaned_data.get("odabrani_proizvod")
        )
        self.instance.terapijski_program = program
        self.instance.lijek = product
        return super().save(commit=commit)


class MigracijaPacijentaForm(PacijentForm):
    migration_mode = True
    FAZA_POSTOJECI_ODRZAVANJE = "POSTOJECI_ODRZAVANJE"
    FAZA_POSTOJECI_INDUKCIJA = "POSTOJECI_INDUKCIJA"
    STANJE_ODOBRENO_CEKA_ISPORUKU = "ODOBRENO_CEKA_ISPORUKU"
    STANJE_ZAPRIMLJENO_CEKA_ZAKAZIVANJE = "ZAPRIMLJENO_CEKA_ZAKAZIVANJE"
    STANJE_PRIVREMENO_PAUZIRAN = "PRIVREMENO_PAUZIRAN"
    # Kompatibilnost s postojećim pozivima/testovima za pacijenta koji još
    # nije započeo terapiju. Novi naziv preciznije opisuje stvarni workflow.
    FAZA_NOVI_BEZ_TERAPIJE = STANJE_ODOBRENO_CEKA_ISPORUKU
    TRENUTNE_FAZE = [
        (FAZA_POSTOJECI_ODRZAVANJE, "Prima terapiju – održavanje"),
        (FAZA_POSTOJECI_INDUKCIJA, "Prima terapiju – indukcija"),
        (STANJE_ODOBRENO_CEKA_ISPORUKU, "Odobreno – čeka isporuku"),
        (
            STANJE_ZAPRIMLJENO_CEKA_ZAKAZIVANJE,
            "Lijek zaprimljen – čeka zakazivanje",
        ),
        (STANJE_PRIVREMENO_PAUZIRAN, "Privremeno pauziran"),
    ]

    trenutna_faza_pacijenta = forms.ChoiceField(
        label="Trenutno stanje pacijenta",
        choices=TRENUTNE_FAZE,
        initial=FAZA_POSTOJECI_ODRZAVANJE,
    )
    individualni_interval_aktivan = forms.BooleanField(
        label="Individualni interval",
        required=False,
    )
    individualni_interval_sedmica = forms.IntegerField(
        label="Interval terapije",
        required=False,
        min_value=MIN_INDIVIDUAL_INTERVAL_WEEKS,
        max_value=MAX_INDIVIDUAL_INTERVAL_WEEKS,
        widget=forms.NumberInput(
            attrs={
                "min": str(MIN_INDIVIDUAL_INTERVAL_WEEKS),
                "max": str(MAX_INDIVIDUAL_INTERVAL_WEEKS),
                "step": "1",
                "inputmode": "numeric",
            }
        ),
        error_messages={
            "invalid": "Interval terapije mora biti cijeli broj sedmica.",
            "min_value": "Interval terapije mora biti najmanje 1 sedmica.",
            "max_value": "Interval terapije može biti najviše 52 sedmice.",
        },
    )
    kolicina_po_terapiji = forms.DecimalField(
        label="Količina po jednoj terapiji",
        required=True,
        min_value=Decimal("0.01"),
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(
            attrs={"min": "1", "step": "1", "inputmode": "numeric"}
        ),
        error_messages={
            "required": (
                "Unesite količinu lijeka koju pacijent prima po jednoj terapiji."
            ),
            "invalid": "Količina po jednoj terapiji mora biti broj.",
            "min_value": "Količina po jednoj terapiji mora biti veća od nule.",
        },
    )
    naziv_individualnog_protokola = forms.CharField(
        label="Naziv individualnog protokola",
        required=False,
        max_length=150,
    )
    razlog_individualnog_protokola = forms.CharField(
        label="Razlog individualnog protokola",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
    )

    datum_zadnje_terapije = forms.DateField(
        label="Datum zadnje primljene terapije",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    oralni_rezim_potvrdjen = forms.BooleanField(
        label="Potvrđujem stvarni način uzimanja",
        required=False,
    )
    individualni_oralni_rezim = forms.BooleanField(
        required=False,
        widget=forms.HiddenInput,
    )
    oralne_tablete_po_uzimanju = forms.DecimalField(
        label="Tableta po uzimanju",
        required=False,
        min_value=Decimal("0.01"),
        max_digits=6,
        decimal_places=2,
        widget=forms.NumberInput(
            attrs={"min": "0.01", "step": "0.01", "inputmode": "decimal"}
        ),
    )
    oralna_uzimanja_dnevno = forms.IntegerField(
        label="Broj uzimanja dnevno",
        required=False,
        min_value=1,
        widget=forms.NumberInput(
            attrs={"min": "1", "step": "1", "inputmode": "numeric"}
        ),
    )
    oralna_napomena_rezima = forms.CharField(
        label="Kratka napomena",
        required=False,
        max_length=500,
        widget=forms.Textarea(attrs={"rows": 2}),
    )
    datum_posljednjeg_oralnog_izdavanja = forms.DateField(
        label="Datum posljednjeg izdavanja tableta",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    kolicina_posljednjeg_oralnog_izdavanja = forms.IntegerField(
        label="Količina posljednjeg izdavanja",
        required=False,
        min_value=1,
        widget=forms.NumberInput(
            attrs={"min": "1", "step": "1", "inputmode": "numeric"}
        ),
    )
    broj_pakovanja_posljednjeg_izdavanja = forms.IntegerField(
        label="Količina posljednjeg izdavanja",
        required=False,
        min_value=1,
        widget=forms.NumberInput(
            attrs={"min": "1", "step": "1", "inputmode": "numeric"}
        ),
        error_messages={
            "invalid": "Unesite cijeli broj pakovanja.",
            "min_value": "Unesite cijeli broj pakovanja.",
        },
    )
    oralno_preostalo_odobreno = forms.DecimalField(
        label="Preostalo odobreno tableta",
        required=False,
        min_value=0,
        decimal_places=0,
        max_digits=10,
        initial=0,
        widget=forms.NumberInput(
            attrs={"min": "0", "step": "1", "inputmode": "numeric"}
        ),
    )
    broj_pakovanja_preostalog_prava = forms.IntegerField(
        label="Preostalo komisijsko pravo",
        required=False,
        min_value=0,
        initial=0,
        widget=forms.NumberInput(
            attrs={"min": "0", "step": "1", "inputmode": "numeric"}
        ),
        error_messages={
            "invalid": "Unesite cijeli broj pakovanja.",
            "min_value": "Unesite cijeli broj pakovanja.",
        },
    )
    oralni_direktan_unos_tableta = forms.BooleanField(
        required=False,
        widget=forms.HiddenInput,
    )
    kreiraj_sljedeci_termin = forms.BooleanField(
        label="Kreiraj sljedeći termin nakon migracije",
        required=False,
        initial=False,
    )
    datum_sljedece_terapije = forms.DateField(
        label="Datum sljedeće terapije",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    broj_odobrenih_doza = forms.DecimalField(
        label="Broj odobrenih doza po trenutnoj komisiji",
        required=False,
        min_value=0,
        decimal_places=2,
        max_digits=8,
    )
    broj_iskoristenih_doza = forms.DecimalField(
        label="Broj već iskorištenih doza",
        required=False,
        min_value=0,
        decimal_places=2,
        max_digits=8,
        initial=0,
    )
    status_preostalih_odobrenih_doza = forms.ChoiceField(
        label="Status preostalih odobrenih doza",
        choices=MigracijskiSnapshotPacijenta.STATUSI_PREOSTALIH_DOZA,
        initial=(
            MigracijskiSnapshotPacijenta.STATUS_PREOSTALIH_CEKA_ISPORUKU
        ),
        required=False,
        widget=forms.HiddenInput,
    )
    # Kompatibilnost sa ranijim integracijama; novo korisničko sučelje ovo
    # polje ne prikazuje i koristi eksplicitni broj iskorištenih doza.
    preostale_doze = forms.DecimalField(
        required=False,
        min_value=0,
        decimal_places=2,
        max_digits=8,
        widget=forms.HiddenInput,
    )
    rezervisano_za_pacijenta = forms.DecimalField(
        label="U frižideru za ovog pacijenta",
        required=False,
        min_value=0,
        decimal_places=2,
        max_digits=8,
        initial=0,
        help_text=(
            "Tražena alokacija iz već evidentiranog fizičkog stanja. "
            "Sistem rezerviše najviše raspoloživu količinu; višak ostaje "
            "kao 'Čeka fizičko pokriće' i ne povećava centralni saldo."
        ),
    )
    # Kompatibilnost sa ranijim POST payloadima i već primijenjenom 0065
    # infrastrukturom. Polje se više ne prikazuje korisniku.
    fizicki_u_frizideru = forms.DecimalField(
        required=False,
        min_value=0,
        decimal_places=2,
        max_digits=8,
        widget=forms.HiddenInput,
    )
    kod_pacijenta = forms.DecimalField(
        label="Količina trenutno kod pacijenta",
        required=False,
        min_value=0,
        decimal_places=0,
        max_digits=8,
        initial=0,
        widget=forms.NumberInput(
            attrs={"min": "0", "step": "1", "inputmode": "numeric"}
        ),
        error_messages={
            "invalid": "Količina kod pacijenta mora biti cijeli broj.",
            "min_value": "Količina kod pacijenta mora biti veća ili jednaka nuli.",
        },
    )
    napomena_migracije = forms.CharField(
        label="Napomena migracije",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
    )
    fazna_faza = forms.ModelChoiceField(
        label="Faza terapijskog programa",
        queryset=TerapijskaFaza.objects.none(),
        required=False,
        empty_label="Odaberite trenutnu fazu",
    )
    trenutni_proizvod = forms.ModelChoiceField(
        label="Trenutni lijek i pakovanje",
        queryset=Lijek.objects.none(),
        required=False,
        empty_label="Odaberite lijek i pakovanje",
    )

    def __init__(self, *args, **kwargs):
        data = kwargs.get("data")
        positional_data = data is None and bool(args)
        if positional_data:
            data = args[0]

        if data:
            data = data.copy()
            if (
                not data.get("rezervisano_za_pacijenta")
                and "fizicki_u_frizideru" in data
            ):
                data["rezervisano_za_pacijenta"] = data.get(
                    "fizicki_u_frizideru"
                )
            if (
                "fizicki_u_frizideru" not in data
                and "rezervisano_za_pacijenta" in data
            ):
                data["fizicki_u_frizideru"] = data.get(
                    "rezervisano_za_pacijenta"
                )
            legacy_phase = data.get("pocetna_faza_terapije")
            current_phase = data.get("trenutna_faza_pacijenta")
            if current_phase == "NOVI_BEZ_TERAPIJE":
                current_phase = self.STANJE_ODOBRENO_CEKA_ISPORUKU
                data["trenutna_faza_pacijenta"] = current_phase
            new_phase_submitted = bool(current_phase)
            if not current_phase:
                if legacy_phase == Pacijent.FAZA_ODRZAVANJE:
                    current_phase = self.FAZA_POSTOJECI_ODRZAVANJE
                elif data.get("datum_zadnje_terapije"):
                    current_phase = self.FAZA_POSTOJECI_INDUKCIJA
                else:
                    current_phase = self.STANJE_ODOBRENO_CEKA_ISPORUKU
                data["trenutna_faza_pacijenta"] = current_phase

            individual_active = (
                (
                    legacy_phase == Pacijent.FAZA_INDIVIDUALNI
                    and not new_phase_submitted
                )
                or str(data.get("individualni_interval_aktivan", "")).lower()
                in {"1", "true", "on", "yes"}
            )
            if individual_active:
                data["individualni_interval_aktivan"] = "on"
                data["pocetna_faza_terapije"] = Pacijent.FAZA_INDIVIDUALNI
            elif current_phase == self.FAZA_POSTOJECI_ODRZAVANJE:
                data["pocetna_faza_terapije"] = Pacijent.FAZA_ODRZAVANJE
            else:
                data["pocetna_faza_terapije"] = Pacijent.FAZA_INDUKCIJA

            individualni_interval = data.get(
                "individualni_interval_sedmica",
                data.get("interval_sedmica", ""),
            )
            if individual_active:
                data["terapijski_protokol"] = ""
                data["individualni_interval_sedmica"] = individualni_interval
                data["interval_sedmica"] = individualni_interval
            if positional_data:
                args = (data, *args[1:])
            else:
                kwargs["data"] = data
        super().__init__(*args, **kwargs)
        # Migracija opisuje zatečeno stanje i nikada retroaktivno ne traži
        # početnu IV dozu. Faza i trenutni SKU ostaju eksplicitni izbori.
        self.fields.pop("pocetna_iv_doza_mg", None)
        # Oralni workflow nema koncept "količine po terapiji". Polje ostaje
        # obavezno samo za neoralne migracije i provjerava se u clean().
        self.fields["kolicina_po_terapiji"].required = False
        self.fields["interval_sedmica"].required = False
        self.fields["pocetna_faza_terapije"].widget = forms.HiddenInput()
        self.fields["pocetna_faza_terapije"].initial = Pacijent.FAZA_ODRZAVANJE
        self.fields["trenutna_faza_pacijenta"].initial = (
            self.FAZA_POSTOJECI_ODRZAVANJE
        )
        self.fields["aktivan"].initial = True
        self.fields["kreiraj_sljedeci_termin"].initial = False
        self.fields["fazna_faza"].queryset = (
            TerapijskaFaza.objects.filter(aktivna=True, program__aktivan=True)
            .select_related("program", "lijek")
            .order_by("program__naziv", "redoslijed", "pk")
        )
        self.fields["trenutni_proizvod"].queryset = (
            active_therapy_medicines().filter(terapijski_program__isnull=False)
        )
        self.fields["fazna_faza"].widget = TerapijskiProtokolSelect(
            protocol_option_attrs={
                str(phase.pk): {
                    "data-program-id": str(phase.program_id),
                    "data-product-id": str(phase.lijek_id),
                    "data-phase-key": phase.kljuc,
                    "data-route": phase.put_primjene or "",
                    "data-interval": str(phase.interval_sedmica or ""),
                }
                for phase in self.fields["fazna_faza"].queryset
            }
        )
        self.fields["fazna_faza"].widget.choices = self.fields["fazna_faza"].choices
        self.fields["trenutni_proizvod"].widget = TerapijskiProtokolSelect(
            protocol_option_attrs={
                str(product.pk): {
                    "data-program-id": str(product.terapijski_program_id),
                    "data-route": product.put_primjene or "",
                }
                for product in self.fields["trenutni_proizvod"].queryset
            }
        )
        self.fields["trenutni_proizvod"].widget.choices = (
            self.fields["trenutni_proizvod"].choices
        )
        selected_phase_id = data.get("fazna_faza") if data else None
        selected_phase = (
            self.fields["fazna_faza"].queryset.filter(pk=selected_phase_id).first()
            if selected_phase_id else None
        )
        if (
            selected_phase
            and selected_phase.program.protokol_kljuc == "ustekinumab"
            and selected_phase.kljuc == FazniProtokolPacijenta.FAZA_CEKA_IV
        ):
            self.fields["kolicina_po_terapiji"].label = (
                "Odobrena količina za IV indukciju"
            )
            self.fields["kolicina_po_terapiji"].help_text = (
                "Ručno unesite broj bočica prema odobrenoj IV dozi."
            )

    def clean(self):
        cleaned_data = super().clean()
        program = cleaned_data.get("lijek")
        fazna_faza = cleaned_data.get("fazna_faza")
        current_product = cleaned_data.get("trenutni_proizvod")
        if program and program.protokol_kljuc:
            if not fazna_faza:
                self.add_error(
                    "fazna_faza",
                    "Odaberite tačnu fazu ovog terapijskog programa.",
                )
            elif fazna_faza.program_id != program.pk:
                self.add_error(
                    "fazna_faza",
                    "Odabrana faza ne pripada izabranoj terapiji.",
                )
            if not current_product:
                self.add_error(
                    "trenutni_proizvod",
                    "Odaberite proizvod koji pacijent trenutno prima.",
                )
            elif current_product.terapijski_program_id != program.pk:
                self.add_error(
                    "trenutni_proizvod",
                    "Odabrani proizvod ne pripada izabranoj terapiji.",
                )
            elif (
                fazna_faza
                and fazna_faza.put_primjene
                and current_product.put_primjene != fazna_faza.put_primjene
            ):
                self.add_error(
                    "trenutni_proizvod",
                    "Put primjene proizvoda ne odgovara odabranoj fazi.",
                )
            cleaned_data["odabrani_proizvod"] = current_product
        else:
            cleaned_data["fazna_faza"] = None
            cleaned_data["trenutni_proizvod"] = None
            current_product = cleaned_data.get("odabrani_proizvod")

        is_oral = bool(current_product and current_product.oralna_terapija)
        is_ustekinumab_iv = bool(
            program
            and program.protokol_kljuc == "ustekinumab"
            and fazna_faza
            and fazna_faza.kljuc == FazniProtokolPacijenta.FAZA_CEKA_IV
            and current_product
            and current_product.put_primjene == Lijek.PUT_IV
        )
        if is_ustekinumab_iv:
            from patients.phased_protocols import ustekinumab_iv_to_sc_protocol

            canonical_protocol = ustekinumab_iv_to_sc_protocol(current_product)
            if canonical_protocol is None:
                self.add_error(
                    "terapijski_protokol",
                    "Za Ustekinumab IV indukciju nije konfigurisan terapijski protokol.",
                )
            else:
                # Ne vjeruj praznoj ili ručno poslanoj vrijednosti: kombinacija
                # program/faza/SKU jednoznačno određuje fazni protokol.
                cleaned_data["terapijski_protokol"] = canonical_protocol
        if is_oral:
            regimen = cleaned_data.get("predlozeni_oralni_rezim")
            confirmed = bool(cleaned_data.get("oralni_rezim_potvrdjen"))
            individual_oral = bool(cleaned_data.get("individualni_oralni_rezim"))
            issued_on = cleaned_data.get(
                "datum_posljednjeg_oralnog_izdavanja"
            )
            package_size = int(
                current_product.broj_tableta_u_pakovanju
                or current_product.effective_package_size
                or 1
            )
            direct_tablet_input = bool(
                cleaned_data.get("oralni_direktan_unos_tableta")
            )
            if (
                "broj_pakovanja_posljednjeg_izdavanja" not in self.data
                and "broj_pakovanja_preostalog_prava" not in self.data
                and (
                    self.data.get("kolicina_posljednjeg_oralnog_izdavanja")
                    or self.data.get("oralno_preostalo_odobreno")
                )
            ):
                # Kompatibilnost sa ranijim integracijama koje direktno šalju
                # broj tableta umjesto primarnog broja pakovanja.
                direct_tablet_input = True
                cleaned_data["oralni_direktan_unos_tableta"] = True

            if direct_tablet_input:
                issued_quantity = cleaned_data.get(
                    "kolicina_posljednjeg_oralnog_izdavanja"
                )
                remaining_quantity = cleaned_data.get(
                    "oralno_preostalo_odobreno"
                )
                brand = current_product.zasticeno_ime or current_product.naziv
                multiple_error = (
                    f"{brand} dolazi u pakovanju od {package_size} tableta. "
                    f"Unesite {package_size}, {package_size * 2}, "
                    f"{package_size * 3}… tableta."
                )
                if issued_quantity and issued_quantity % package_size:
                    self.add_error(
                        "kolicina_posljednjeg_oralnog_izdavanja",
                        multiple_error,
                    )
                if remaining_quantity and remaining_quantity % package_size:
                    self.add_error("oralno_preostalo_odobreno", multiple_error)
            else:
                issued_packages = cleaned_data.get(
                    "broj_pakovanja_posljednjeg_izdavanja"
                )
                remaining_packages = cleaned_data.get(
                    "broj_pakovanja_preostalog_prava"
                )
                issued_quantity = (
                    issued_packages * package_size
                    if issued_packages is not None else None
                )
                remaining_quantity = (remaining_packages or 0) * package_size
                cleaned_data["kolicina_posljednjeg_oralnog_izdavanja"] = (
                    issued_quantity
                )
                cleaned_data["oralno_preostalo_odobreno"] = remaining_quantity
            if not confirmed:
                self.add_error(
                    "oralni_rezim_potvrdjen",
                    "Potvrdite stvarni zatečeni oralni režim pacijenta.",
                )
            if confirmed and not regimen and not individual_oral:
                self.add_error(
                    "predlozeni_oralni_rezim",
                    "Odaberite standardni režim koji je stvarno potvrđen.",
                )
            if individual_oral:
                cleaned_data["predlozeni_oralni_rezim"] = None
                if not cleaned_data.get("oralne_tablete_po_uzimanju"):
                    self.add_error(
                        "oralne_tablete_po_uzimanju",
                        "Unesite broj tableta po uzimanju.",
                    )
                if not cleaned_data.get("oralna_uzimanja_dnevno"):
                    self.add_error(
                        "oralna_uzimanja_dnevno",
                        "Unesite broj uzimanja dnevno.",
                    )
            elif regimen:
                cleaned_data["oralne_tablete_po_uzimanju"] = (
                    regimen.tableta_po_uzimanju
                )
                cleaned_data["oralna_uzimanja_dnevno"] = regimen.uzimanja_dnevno
            quantity_input_has_error = bool(
                self.errors.get("kolicina_posljednjeg_oralnog_izdavanja")
                or self.errors.get("broj_pakovanja_posljednjeg_izdavanja")
            )
            if not quantity_input_has_error and bool(issued_on) != bool(issued_quantity):
                missing_field = (
                    "kolicina_posljednjeg_oralnog_izdavanja"
                    if issued_on
                    else "datum_posljednjeg_oralnog_izdavanja"
                )
                self.add_error(
                    missing_field,
                    "Datum i količina posljednjeg izdavanja unose se zajedno.",
                )
            if issued_on and issued_on > timezone.localdate():
                self.add_error(
                    "datum_posljednjeg_oralnog_izdavanja",
                    "Datum posljednjeg izdavanja ne može biti u budućnosti.",
                )
            cleaned_data["datum_zadnje_terapije"] = None
            cleaned_data["kreiraj_sljedeci_termin"] = False
            cleaned_data["datum_sljedece_terapije"] = None
            cleaned_data["kolicina_po_terapiji"] = Decimal("1")
            cleaned_data["interval_sedmica"] = 1
            # Oralni unos daje dvije odvojene činjenice: koliko je već izdato
            # i koliko prava ostaje. Prethodno se sačuvalo samo preostalo
            # pravo kao ukupno odobrenje, pa je servis kasnije prikazivao nulu
            # ili pogrešan ukupni iznos. Rekonstruiši kanonsku komisijsku
            # semantiku: ukupno = već izdato + preostalo.
            oral_issued = Decimal(str(issued_quantity or 0))
            oral_remaining = Decimal(str(remaining_quantity or 0))
            cleaned_data["broj_odobrenih_doza"] = (
                oral_issued + oral_remaining
            )
            cleaned_data["broj_iskoristenih_doza"] = oral_issued
            cleaned_data["rezervisano_za_pacijenta"] = Decimal("0")
            cleaned_data["fizicki_u_frizideru"] = Decimal("0")
            cleaned_data["kod_pacijenta"] = Decimal("0")
        elif cleaned_data.get("kolicina_po_terapiji") is None:
            self.add_error(
                "kolicina_po_terapiji",
                (
                    "Unesite odobrenu količinu IV indukcije."
                    if is_ustekinumab_iv else
                    "Unesite količinu lijeka koju pacijent prima po jednoj terapiji."
                ),
            )

        faza = cleaned_data.get("pocetna_faza_terapije")
        trenutna_faza = cleaned_data.get("trenutna_faza_pacijenta")
        protokol = cleaned_data.get("terapijski_protokol")
        individualni_interval = cleaned_data.get("individualni_interval_sedmica")

        if faza == Pacijent.FAZA_INDIVIDUALNI:
            cleaned_data["terapijski_protokol"] = None
            if not (cleaned_data.get("naziv_individualnog_protokola") or "").strip():
                self.add_error(
                    "naziv_individualnog_protokola",
                    "Unesite naziv individualnog protokola.",
                )
            if individualni_interval is None and "individualni_interval_sedmica" not in self.errors:
                self.add_error(
                    "individualni_interval_sedmica",
                    "Unesite trenutni interval individualnog protokola.",
                )
            elif individualni_interval is not None:
                cleaned_data["interval_sedmica"] = individualni_interval
        elif faza == Pacijent.FAZA_ODRZAVANJE:
            if not protokol and not uses_specialized_protocol_engine(
                cleaned_data.get("lijek")
            ):
                self.add_error(
                    "terapijski_protokol",
                    "Izaberite standardni terapijski protokol.",
                )
            cleaned_data["naziv_individualnog_protokola"] = ""
            cleaned_data["razlog_individualnog_protokola"] = ""
            cleaned_data["individualni_interval_sedmica"] = None
        else:
            cleaned_data["naziv_individualnog_protokola"] = ""
            cleaned_data["razlog_individualnog_protokola"] = ""
            cleaned_data["individualni_interval_sedmica"] = None

        stanja_bez_historijske_terapije = {
            self.STANJE_ODOBRENO_CEKA_ISPORUKU,
            self.STANJE_ZAPRIMLJENO_CEKA_ZAKAZIVANJE,
        }
        stanja_bez_automatskog_termina = {
            *stanja_bez_historijske_terapije,
            self.STANJE_PRIVREMENO_PAUZIRAN,
        }
        if trenutna_faza in stanja_bez_historijske_terapije:
            cleaned_data["datum_zadnje_terapije"] = None
            cleaned_data["kreiraj_sljedeci_termin"] = False
            cleaned_data["datum_sljedece_terapije"] = None
            cleaned_data["broj_iskoristenih_doza"] = Decimal("0")
        elif trenutna_faza in stanja_bez_automatskog_termina:
            cleaned_data["kreiraj_sljedeci_termin"] = False
            cleaned_data["datum_sljedece_terapije"] = None

        datum_zadnje = cleaned_data.get("datum_zadnje_terapije")
        if fazna_faza:
            if fazna_faza.kljuc in {
                FazniProtokolPacijenta.FAZA_CEKA_PRVU_SC,
                FazniProtokolPacijenta.FAZA_ODRZAVANJE,
            } and not datum_zadnje:
                self.add_error(
                    "datum_zadnje_terapije",
                    (
                        "Unesite datum stvarne IV primjene."
                        if fazna_faza.kljuc
                        == FazniProtokolPacijenta.FAZA_CEKA_PRVU_SC
                        else "Unesite datum zadnje stvarne SC doze."
                    ),
                )
            if fazna_faza.kljuc == FazniProtokolPacijenta.FAZA_CEKA_IV:
                cleaned_data["pocetna_faza_terapije"] = Pacijent.FAZA_INDUKCIJA
                # Trenutna IV faza zaista nema interval. Servis migracije
                # zasebno postavlja podrazumijevani SC interval održavanja,
                # bez pretvaranja tog podatka u interval IV indukcije.
                cleaned_data["interval_sedmica"] = None
            else:
                cleaned_data["pocetna_faza_terapije"] = Pacijent.FAZA_ODRZAVANJE
            if fazna_faza.interval_sedmica:
                cleaned_data["interval_sedmica"] = (
                    cleaned_data.get("interval_sedmica")
                    or fazna_faza.interval_sedmica
                )
        if datum_zadnje and datum_zadnje > timezone.localdate():
            self.add_error(
                "datum_zadnje_terapije",
                "Datum posljednje terapije ne može biti u budućnosti.",
            )

        kreiraj_termin = bool(cleaned_data.get("kreiraj_sljedeci_termin"))
        datum_sljedece = cleaned_data.get("datum_sljedece_terapije")
        interval = cleaned_data.get("interval_sedmica")
        lijek = current_product
        protokol_za_raspored = cleaned_data.get("terapijski_protokol")
        kolicina_po_terapiji = cleaned_data.get("kolicina_po_terapiji")

        if (
            lijek
            and kolicina_po_terapiji is not None
            and not lijek.dozvoljava_decimalnu_kolicinu
            and kolicina_po_terapiji != kolicina_po_terapiji.to_integral_value()
        ):
            self.add_error(
                "kolicina_po_terapiji",
                "Za odabrani lijek unesite pozitivan cijeli broj.",
            )

        if not datum_zadnje:
            # Novi pacijent bez stvarne historijske terapije ne dobija
            # automatski datum prve terapije.
            cleaned_data["kreiraj_sljedeci_termin"] = False
            cleaned_data["datum_sljedece_terapije"] = None
        elif kreiraj_termin and interval:
            if datum_sljedece is None:
                izracunati = calculate_next_therapy_date(datum_zadnje, interval)
                datum_sljedece = adjust_to_allowed_therapy_date(
                    izracunati,
                    lijek=lijek,
                    protokol=protokol_za_raspored,
                ).datum
                cleaned_data["datum_sljedece_terapije"] = datum_sljedece

            if datum_sljedece <= datum_zadnje:
                self.add_error(
                    "datum_sljedece_terapije",
                    "Sljedeći termin mora biti nakon posljednje evidentirane terapije.",
                )
            else:
                try:
                    validate_therapy_date(
                        datum_sljedece,
                        lijek=lijek,
                        protokol=protokol_za_raspored,
                    )
                except ValidationError as exc:
                    self.add_error("datum_sljedece_terapije", exc)
        elif not kreiraj_termin:
            cleaned_data["datum_sljedece_terapije"] = None

        broj_odobrenih = cleaned_data.get("broj_odobrenih_doza")
        iskoristene = cleaned_data.get("broj_iskoristenih_doza")
        if trenutna_faza in stanja_bez_historijske_terapije:
            iskoristene = Decimal("0")
        legacy_preostale = cleaned_data.get("preostale_doze")
        if iskoristene is None and broj_odobrenih is not None and legacy_preostale is not None:
            iskoristene = broj_odobrenih - legacy_preostale
        iskoristene = iskoristene or Decimal("0")
        kod_pacijenta = cleaned_data.get("kod_pacijenta")
        if kod_pacijenta is None and legacy_preostale is not None:
            kod_pacijenta = legacy_preostale
        kod_pacijenta = kod_pacijenta or Decimal("0")
        lijek = current_product
        if lijek and not lijek.kucna_terapija:
            kod_pacijenta = Decimal("0")
        if trenutna_faza in {
            self.STANJE_ODOBRENO_CEKA_ISPORUKU,
            self.STANJE_ZAPRIMLJENO_CEKA_ZAKAZIVANJE,
        }:
            kod_pacijenta = Decimal("0")
        cleaned_data["broj_iskoristenih_doza"] = iskoristene
        cleaned_data["kod_pacijenta"] = kod_pacijenta
        preostalo_odobreno = max(
            Decimal("0"),
            Decimal(str(broj_odobrenih or 0)) - iskoristene,
        )
        rezervisano_za_pacijenta = Decimal(str(
            cleaned_data.get("rezervisano_za_pacijenta") or 0
        ))
        if trenutna_faza == self.STANJE_ODOBRENO_CEKA_ISPORUKU:
            rezervisano_za_pacijenta = Decimal("0")
            cleaned_data["rezervisano_za_pacijenta"] = Decimal("0")
        cleaned_data["fizicki_u_frizideru"] = rezervisano_za_pacijenta
        if (
            preostalo_odobreno > 0
            and trenutna_faza
            == self.STANJE_ZAPRIMLJENO_CEKA_ZAKAZIVANJE
        ):
            status_preostalih = (
                MigracijskiSnapshotPacijenta.STATUS_PREOSTALIH_ZAPRIMLJENE
            )
        elif (
            preostalo_odobreno > 0
            and lijek
            and lijek.kucna_terapija
            and kod_pacijenta >= preostalo_odobreno
        ):
            status_preostalih = (
                MigracijskiSnapshotPacijenta.STATUS_PREOSTALIH_KOD_PACIJENTA
            )
        elif preostalo_odobreno > 0 and rezervisano_za_pacijenta > 0:
            status_preostalih = (
                MigracijskiSnapshotPacijenta.STATUS_PREOSTALIH_ZAPRIMLJENE
            )
        else:
            status_preostalih = (
                MigracijskiSnapshotPacijenta.STATUS_PREOSTALIH_CEKA_ISPORUKU
            )
        cleaned_data["status_preostalih_odobrenih_doza"] = status_preostalih

        if broj_odobrenih is None and (iskoristene > 0 or kod_pacijenta > 0):
            self.add_error(
                "broj_odobrenih_doza",
                "Unesite broj odobrenih doza ako unosite iskorištene doze ili kućnu terapiju.",
            )
        if broj_odobrenih is not None and iskoristene > broj_odobrenih:
            self.add_error(
                "broj_iskoristenih_doza",
                "Broj iskorištenih doza ne može biti veći od broja odobrenih doza.",
            )
        if broj_odobrenih is not None and kod_pacijenta > broj_odobrenih:
            self.add_error(
                "kod_pacijenta",
                "Količina kod pacijenta ne može biti veća od ukupnog broja odobrenih doza.",
            )
        if rezervisano_za_pacijenta > preostalo_odobreno:
            self.add_error(
                "rezervisano_za_pacijenta",
                "Rezervacija ne može biti veća od preostalih odobrenih doza.",
            )
        ukupno_fizicki = kod_pacijenta + rezervisano_za_pacijenta
        if ukupno_fizicki > preostalo_odobreno:
            self.add_error(
                None,
                (
                    "Zbir fizičkih doza kod pacijenta i u frižideru "
                    f"({ukupno_fizicki:g}) ne može biti veći od "
                    f"neiskorištenog odobrenja ({preostalo_odobreno:g}). "
                    "Ispravite količine prije završetka migracije."
                ),
            )
        return cleaned_data


class OralniTerapijskiRezimForm(forms.ModelForm):
    class Meta:
        model = OralniTerapijskiRezim
        fields = (
            "standardni_rezim",
            "tableta_po_uzimanju",
            "uzimanja_dnevno",
            "datum_od",
            "faza",
            "napomena_ljekara",
        )
        labels = {
            "standardni_rezim": "Standardni prijedlog",
            "tableta_po_uzimanju": "Tableta po uzimanju",
            "uzimanja_dnevno": "Uzimanja dnevno",
            "datum_od": "Režim važi od",
            "faza": "Faza režima",
            "napomena_ljekara": "Napomena ljekara",
        }
        widgets = {
            "tableta_po_uzimanju": forms.NumberInput(
                attrs={"min": "0.25", "step": "0.25"}
            ),
            "uzimanja_dnevno": forms.NumberInput(
                attrs={"min": "1", "step": "1"}
            ),
            "datum_od": forms.DateInput(
                format="%Y-%m-%d",
                attrs={"type": "date"},
            ),
            "napomena_ljekara": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, patient=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.patient = patient
        queryset = StandardniOralniRezim.objects.none()
        if patient and patient.lijek_id:
            queryset = StandardniOralniRezim.objects.filter(
                lijek=patient.lijek,
                aktivan=True,
            ).select_related("lijek").order_by("naziv", "id")
        self.fields["standardni_rezim"].queryset = queryset
        self.fields["standardni_rezim"].required = False
        self.fields["standardni_rezim"].empty_label = "Prilagođeni režim"
        selected = getattr(patient, "predlozeni_oralni_rezim", None) if patient else None
        if selected and queryset.filter(pk=selected.pk).exists():
            self.initial.setdefault("standardni_rezim", selected)
        elif queryset.count() == 1:
            self.initial.setdefault("standardni_rezim", queryset.first())
        self.initial.setdefault("datum_od", timezone.localdate())
        self.fields["datum_od"].initial = self.initial["datum_od"]

    def clean(self):
        cleaned = super().clean()
        standard = cleaned.get("standardni_rezim")
        if not standard:
            return cleaned
        if not self.patient or standard.lijek_id != self.patient.lijek_id:
            self.add_error(
                "standardni_rezim",
                "Standardni režim ne pripada trenutnom lijeku pacijenta.",
            )
            return cleaned
        expected = {
            "tableta_po_uzimanju": Decimal(str(standard.tableta_po_uzimanju)),
            "uzimanja_dnevno": int(standard.uzimanja_dnevno),
            "faza": standard.faza,
        }
        if any(cleaned.get(field) != value for field, value in expected.items()):
            self.add_error(
                None,
                (
                    "Vrijednosti ne odgovaraju izabranom standardnom prijedlogu. "
                    "Vratite standardne vrijednosti ili odaberite prilagođeni režim."
                ),
            )
        return cleaned


class OralnoIzdavanjeForm(forms.Form):
    RAZLOZI_RANIJEG_IZDAVANJA = [
        ("", "Izaberite razlog"),
        ("RANIJI_DOLAZAK", "Raniji dolazak pacijenta"),
        ("PUTOVANJE", "Putovanje"),
        ("ORGANIZACIJSKI", "Organizacijski razlog"),
        ("KOREKCIJA", "Korekcija prethodnog stanja"),
        ("DRUGO", "Drugo"),
    ]

    datum_izdavanja = forms.DateField(
        label="Datum izdavanja",
        widget=forms.DateInput(format="%Y-%m-%d", attrs={"type": "date"}),
        input_formats=["%Y-%m-%d", "%d/%m/%Y"],
    )
    zeljeni_broj_dana = forms.IntegerField(
        label="Izdati terapiju za",
        min_value=1,
        required=False,
        widget=forms.NumberInput(attrs={"min": "1", "step": "1"}),
    )
    kolicina_tableta = forms.IntegerField(
        label="Ručna količina tableta",
        min_value=1,
        required=False,
        widget=forms.NumberInput(attrs={"min": "1", "step": "1"}),
    )
    rucna_korekcija = forms.BooleanField(required=False, widget=forms.HiddenInput)
    razlog_korekcije = forms.CharField(
        label="Razlog korekcije",
        max_length=300,
        required=False,
        widget=forms.Textarea(attrs={"rows": 2}),
    )
    izvor_odobrenja = forms.ChoiceField(
        label="Saglasnost / komisijsko pravo",
        required=False,
    )
    serija = forms.CharField(label="Serija / lot", max_length=100, required=False)
    napomena = forms.CharField(
        label="Napomena",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
    )
    razlog_ranijeg_izdavanja = forms.ChoiceField(
        label="Razlog ranijeg izdavanja",
        choices=RAZLOZI_RANIJEG_IZDAVANJA,
        required=False,
    )
    napomena_ranijeg_izdavanja = forms.CharField(
        label="Napomena uz drugi razlog",
        max_length=300,
        required=False,
        widget=forms.Textarea(attrs={"rows": 2}),
    )
    idempotency_key = forms.UUIDField(widget=forms.HiddenInput)

    def __init__(
        self,
        *args,
        regimen=None,
        approval_options=None,
        physical_available=None,
        next_planned_issue=None,
        quantity_at_patient=None,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.regimen = regimen
        self.approval_options = approval_options or []
        self.physical_available = (
            Decimal(str(physical_available))
            if physical_available is not None
            else None
        )
        self.next_planned_issue = next_planned_issue
        self.quantity_at_patient = Decimal(str(quantity_at_patient or 0))
        self.auto_approval = (
            self.approval_options[0] if len(self.approval_options) == 1 else None
        )
        default_issue_date = timezone.localdate()
        if regimen and regimen.datum_od > default_issue_date:
            default_issue_date = regimen.datum_od
        self.initial.setdefault("datum_izdavanja", default_issue_date)
        self.initial.setdefault("zeljeni_broj_dana", 30)
        self.initial.setdefault("idempotency_key", uuid.uuid4())
        self.fields["datum_izdavanja"].initial = self.initial["datum_izdavanja"]
        self.fields["idempotency_key"].initial = self.initial["idempotency_key"]
        self.fields["izvor_odobrenja"].choices = [
            (item["value"], item["label"]) for item in self.approval_options
        ]
        if not self.approval_options:
            self.fields["izvor_odobrenja"].choices = [
                ("", "Nema raspoloživog odobrenja")
            ]
        elif self.auto_approval:
            self.initial.setdefault(
                "izvor_odobrenja",
                self.auto_approval["value"],
            )
        else:
            self.fields["izvor_odobrenja"].choices = [
                ("", "Izaberite saglasnost")
            ] + list(self.fields["izvor_odobrenja"].choices)

    def clean(self):
        cleaned = super().clean()
        days = cleaned.get("zeljeni_broj_dana")
        quantity = cleaned.get("kolicina_tableta")
        manual = bool(cleaned.get("rucna_korekcija"))
        if days and self.regimen:
            from patients.oral_therapy import oral_issue_projection

            try:
                projection = oral_issue_projection(self.regimen, days)
            except ValueError as exc:
                self.add_error("zeljeni_broj_dana", str(exc))
            else:
                suggested_quantity = projection["quantity"]
                cleaned["projekcija"] = projection
                cleaned["predlozena_kolicina"] = suggested_quantity
                if manual:
                    if not quantity:
                        self.add_error(
                            "kolicina_tableta",
                            "Unesite ručno korigiranu količinu tableta.",
                        )
                    elif quantity != suggested_quantity and not (
                        cleaned.get("razlog_korekcije") or ""
                    ).strip():
                        self.add_error(
                            "razlog_korekcije",
                            "Navedite razlog promjene sistemski izračunate količine.",
                        )
                else:
                    # Standardni workflow uvijek koristi server-side projekciju,
                    # bez povjerenja u eventualno izmijenjenu vrijednost iz browsera.
                    quantity = suggested_quantity
                    cleaned["kolicina_tableta"] = quantity
        if not quantity and not days:
            self.add_error(
                "kolicina_tableta",
                "Odaberite period izdavanja.",
            )

        selected_approval = cleaned.get("izvor_odobrenja") or ""
        option_map = {item["value"]: item for item in self.approval_options}
        if self.auto_approval and not selected_approval:
            selected_approval = self.auto_approval["value"]
            cleaned["izvor_odobrenja"] = selected_approval
        if not self.approval_options:
            self.add_error(
                "izvor_odobrenja",
                "Nema važeće saglasnosti sa preostalom količinom za ovu terapiju.",
            )
        elif len(self.approval_options) > 1 and not selected_approval:
            self.add_error(
                "izvor_odobrenja",
                "Postoji više važećih saglasnosti. Izaberite onu koju koristite.",
            )
        elif selected_approval and selected_approval not in option_map:
            self.add_error(
                "izvor_odobrenja",
                "Izabrana saglasnost više nije raspoloživa.",
            )

        selected_option = option_map.get(selected_approval)
        if quantity and selected_option and selected_option["remaining"] < quantity:
            self.add_error(
                "izvor_odobrenja",
                f"Saglasnost ima još {selected_option['remaining']:g} tableta, "
                f"a za odabrani period je potrebno {quantity}.",
            )
        if (
            quantity
            and self.physical_available is not None
            and self.physical_available < quantity
        ):
            self.add_error(
                "kolicina_tableta",
                f"U kabinetu je dostupno {self.physical_available:g} tableta, "
                f"a za odabrani period je potrebno {quantity}.",
            )
        if quantity and self.regimen:
            daily = Decimal(str(self.regimen.tableta_dnevno or 0))
            if daily > 0 and Decimal(quantity) % daily != 0:
                cleaned["upozorenje_nepotpun_dan"] = (
                    "Količina nije djeljiva dnevnom dozom. "
                    "Pokrivenost prikazuje samo pune dane, bez tihog zaokruživanja."
                )

        issued_on = cleaned.get("datum_izdavanja")
        is_early = bool(
            issued_on
            and self.next_planned_issue
            and issued_on < self.next_planned_issue
            and self.quantity_at_patient > 0
        )
        cleaned["ranije_izdavanje"] = is_early
        if is_early:
            reason = cleaned.get("razlog_ranijeg_izdavanja") or ""
            reason_note = (
                cleaned.get("napomena_ranijeg_izdavanja") or ""
            ).strip()
            if not reason:
                self.add_error(
                    "razlog_ranijeg_izdavanja",
                    "Izaberite razlog ranijeg izdavanja.",
                )
            elif reason == "DRUGO" and not reason_note:
                self.add_error(
                    "napomena_ranijeg_izdavanja",
                    "Unesite kratku napomenu za razlog ‘Drugo’.",
                )
            else:
                reason_labels = dict(self.RAZLOZI_RANIJEG_IZDAVANJA)
                audit_note = f"Ranije izdavanje: {reason_labels[reason]}."
                if reason_note:
                    audit_note += f" Napomena: {reason_note}"
                cleaned["audit_ranijeg_izdavanja"] = audit_note
        return cleaned


class KucnoIzdavanjeForm(forms.ModelForm):
    idempotency_key = forms.UUIDField(widget=forms.HiddenInput)
    kolicina = forms.IntegerField(
        label="Broj izdanih doza",
        min_value=1,
        widget=forms.NumberInput(
            attrs={
                "min": "1",
                "step": "1",
                "inputmode": "numeric",
            }
        ),
        error_messages={
            "required": "Unesite količinu za izdavanje.",
            "invalid": "Količina za izdavanje mora biti cijeli broj.",
            "min_value": "Broj izdanih doza mora biti veći od nule.",
        },
    )

    class Meta:
        model = KucnoIzdavanje
        fields = [
            "datum",
            "kolicina",
            "komisija",
            "serija",
            "rok_trajanja",
            "napomena",
            "idempotency_key",
        ]
        labels = {
            "datum": "Datum izdavanja",
            "kolicina": "Broj izdanih doza",
            "komisija": "Komisija",
            "serija": "Serija / lot lijeka",
            "rok_trajanja": "Rok trajanja",
            "napomena": "Napomena",
        }
        widgets = {
            "datum": forms.DateInput(attrs={"type": "date"}),
            "rok_trajanja": forms.DateInput(attrs={"type": "date"}),
            "napomena": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(
        self,
        *args,
        pacijent=None,
        lijek=None,
        max_quantity=None,
        commission_medicine_ids=None,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.pacijent = pacijent
        self.lijek = lijek
        self.package_size = (
            int(lijek.effective_package_size)
            if lijek and lijek.izdavanje_cijelih_pakovanja else 1
        )
        self.max_quantity = (
            Decimal(str(max_quantity)) if max_quantity is not None else None
        )
        self.commission_medicine_ids = set(
            commission_medicine_ids
            if commission_medicine_ids is not None
            else lijek.equivalent_ids() if lijek else []
        )
        self.fields["datum"].initial = timezone.localdate()
        self.fields["idempotency_key"].initial = uuid.uuid4()
        self.fields["komisija"].queryset = Komisija.objects.none()
        self.fields["komisija"].required = True
        self.fields["komisija"].empty_label = None
        self.fields["serija"].required = True
        self.fields["rok_trajanja"].required = True
        if pacijent and lijek:
            from patients.home_therapy import format_stock_quantity

            queryset = pacijent.komisija_set.filter(
                lijek_id__in=self.commission_medicine_ids,
                status__in=Komisija.VAZECI_STATUSI,
                preostale_doze__gt=0,
            ).order_by("datum_odobrenja", "id")
            self.fields["komisija"].queryset = queryset
            self.fields["komisija"].initial = queryset.first()
            self.fields["kolicina"].label = (
                f"Količina za izdavanje ({lijek.jedinice_zalihe[1]})"
            )
            self.fields["kolicina"].help_text = (
                f"Izdaje se cijelo pakovanje: 1 pakovanje = "
                f"{format_stock_quantity(lijek, self.package_size)}."
            )
            self.fields["kolicina"].widget.attrs.update({
                "min": str(self.package_size),
                "step": str(self.package_size),
            })
        if self.max_quantity is not None:
            self.fields["kolicina"].widget.attrs["max"] = str(
                max(0, int(self.max_quantity))
            )

    def clean_datum(self):
        datum = self.cleaned_data["datum"]
        from patients.scheduling import is_allowed_therapy_date

        if not is_allowed_therapy_date(
            datum,
            lijek=self.lijek,
            protokol=self.pacijent.aktivni_protokol() if self.pacijent else None,
        ):
            raise forms.ValidationError(
                "Izdavanje lijeka u ambulanti mora biti evidentirano na radni dan."
            )
        return datum

    def clean_kolicina(self):
        kolicina = self.cleaned_data["kolicina"]
        if kolicina <= 0:
            raise forms.ValidationError("Broj izdanih doza mora biti veći od nule.")
        if self.max_quantity is not None and Decimal(kolicina) > self.max_quantity:
            raise forms.ValidationError(
                f"Nema dovoljno fizičke zalihe u frižideru. "
                f"Dostupno {self.max_quantity:g}, traženo {kolicina}."
            )
        if self.lijek and self.lijek.izdavanje_cijelih_pakovanja:
            from patients.package_sizes import validate_package_multiple

            try:
                validate_package_multiple(
                    kolicina,
                    self.lijek,
                    label="Količina kućnog izdavanja",
                )
            except ValueError as exc:
                raise forms.ValidationError(str(exc)) from exc
        return kolicina

    def clean(self):
        cleaned_data = super().clean()
        kolicina = cleaned_data.get("kolicina")
        komisija = cleaned_data.get("komisija")
        if (
            kolicina is not None
            and komisija is not None
            and Decimal(kolicina) > Decimal(str(komisija.preostale_doze or 0))
        ):
            self.add_error(
                "kolicina",
                "Količina je veća od raspoloživih doza pacijenta po komisiji.",
            )
        return cleaned_data

    def clean_komisija(self):
        komisija = self.cleaned_data["komisija"]
        if self.pacijent and komisija.pacijent_id != self.pacijent.id:
            raise forms.ValidationError("Izabrana komisija ne pripada ovom pacijentu.")
        if (
            self.lijek
            and komisija.lijek_id not in self.commission_medicine_ids
        ):
            raise forms.ValidationError("Izabrana komisija ne pripada ovom lijeku.")
        if not komisija.je_vazeca():
            raise forms.ValidationError("Izabrana komisija nema raspolozivih odobrenih doza.")
        return komisija


class TerminForm(forms.ModelForm):
    def __init__(self, *args, user=None, allow_demo_weekend=False, **kwargs):
        super().__init__(*args, **kwargs)
        from patients.scheduling import user_can_create_demo_weekend_appointment

        self.demo_weekend_allowed = bool(
            allow_demo_weekend
            and user_can_create_demo_weekend_appointment(user)
        )

    def _post_clean(self):
        # ModelForm uvijek pokreće i Termin.clean(). Privremeni marker vrijedi
        # samo tokom ove autorizovane validacije i nikada se ne sprema u bazu.
        self.instance._allow_demo_weekend_validation = self.demo_weekend_allowed
        try:
            super()._post_clean()
        finally:
            delattr(self.instance, "_allow_demo_weekend_validation")

    def clean_datum(self):
        datum = self.cleaned_data["datum"]
        from patients.scheduling import (
            validate_new_active_appointment_date,
            validate_therapy_date,
        )

        patient = self.cleaned_data.get("pacijent")
        validate_therapy_date(
            datum,
            lijek=patient.lijek if patient else None,
            protokol=patient.aktivni_protokol() if patient else None,
            allow_demo_weekend=self.demo_weekend_allowed,
        )
        validate_new_active_appointment_date(datum)
        return datum

    class Meta:
        model = Termin
        fields = [
            "pacijent",
            "datum",
            "status",
        ]

        widgets = {
            "datum": forms.DateInput(attrs={"type": "date"}),
            "vrijeme": forms.TimeInput(attrs={"type": "time"}),
            "datum_rodenja": forms.DateInput(attrs={"type": "date"}),
        }


class OdobrenaKomisijaForm(forms.ModelForm):
    def clean_broj_odobrenih_doza(self):
        value = self.cleaned_data["broj_odobrenih_doza"]
        lijek = self.instance.lijek if self.instance and self.instance.lijek_id else None
        if lijek:
            from patients.package_sizes import validate_package_multiple
            try:
                validate_package_multiple(value, lijek, label="Broj odobrenih doza")
            except ValueError as exc:
                raise forms.ValidationError(str(exc)) from exc
        return value

    class Meta:
        model = Komisija
        fields = [
            "broj_saglasnosti",
            "datum_odobrenja",
            "broj_odobrenih_doza",
            "napomena",
        ]

        labels = {
            "broj_saglasnosti": "Broj saglasnosti",
            "datum_odobrenja": "Datum odobrenja komisije",
            "broj_odobrenih_doza": "Broj odobrenih doza",
            "napomena": "Napomena",
        }

        widgets = {
            "datum_odobrenja": forms.DateInput(attrs={"type": "date"}),
            "napomena": forms.Textarea(attrs={"rows": 3}),
        }


class PromjenaTerapijeForm(forms.ModelForm):
    nova_terapija = TerapijskiProgramChoiceField(
        queryset=TerapijskiProgram.objects.none(),
        label="Nova terapija",
        empty_label="Izaberite novu terapiju",
    )
    pocetna_iv_doza_mg = forms.DecimalField(
        label="Početna IV doza određena od ljekara",
        help_text="Unesite dozu koju je odredio ljekar.",
        required=False,
        min_value=Decimal("0.01"),
        max_digits=8,
        decimal_places=2,
        widget=forms.NumberInput(
            attrs={"min": "0.01", "step": "0.01", "inputmode": "decimal"}
        ),
    )

    class Meta:
        model = PromjenaTerapije
        fields = [
            "nova_terapija",
            "datum_odluke",
            "ljekar_koji_je_donio_odluku",
            "povezani_dokument",
            "datum_pocetka_nove_terapije",
            "razlog",
            "nova_terapija_pocinje",
            "postupanje_sa_preostalim_dozama",
            "napomena",
        ]
        labels = {
            "datum_odluke": "Datum odluke",
            "ljekar_koji_je_donio_odluku": "Ljekar koji je donio odluku",
            "povezani_dokument": "Povezani dokument",
            "datum_pocetka_nove_terapije": "Datum početka nove terapije",
            "razlog": "Razlog promjene",
            "nova_terapija_pocinje": "Nova terapija počinje",
            "postupanje_sa_preostalim_dozama": "Šta želite uraditi sa preostalim dozama?",
            "napomena": "Napomena",
        }
        widgets = {
            "datum_odluke": forms.DateInput(attrs={"type": "date"}),
            "datum_pocetka_nove_terapije": forms.DateInput(attrs={"type": "date"}),
            "napomena": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, pacijent=None, preostale_doze=0, **kwargs):
        self._legacy_selected_product = None
        data = kwargs.get("data")
        positional_data = data is None and bool(args)
        if positional_data:
            data = args[0]
        if data and data.get("therapy_selection_kind") != "program":
            legacy_product = Lijek.objects.filter(
                pk=data.get("nova_terapija")
            ).first()
            if legacy_product:
                program = ensure_program_for_product(legacy_product)
                data = data.copy()
                data["nova_terapija"] = str(program.pk)
                self._legacy_selected_product = legacy_product
                if positional_data:
                    args = (data, *args[1:])
                else:
                    kwargs["data"] = data
        super().__init__(*args, **kwargs)
        self.pacijent = pacijent
        self.preostale_doze = preostale_doze
        therapies = active_therapy_programs()
        current_program_id = None
        if pacijent:
            current_program_id = (
                pacijent.terapijski_program_id
                or (
                    pacijent.lijek.terapijski_program_id
                    if pacijent.lijek_id else None
                )
            )
        if current_program_id:
            therapies = therapies.exclude(id=current_program_id)
        self.fields["nova_terapija"].queryset = therapies
        self.fields["datum_pocetka_nove_terapije"].initial = timezone.localdate()
        self.fields["datum_odluke"].initial = timezone.localdate()
        self.fields["datum_odluke"].required = False
        self.fields["povezani_dokument"].queryset = DokumentPacijenta.objects.none()
        if pacijent:
            self.fields["povezani_dokument"].queryset = (
                DokumentPacijenta.objects.filter(pacijent=pacijent).order_by(
                    "-datum_dokumenta", "-id"
                )
            )
        self.fields["nova_terapija_pocinje"].initial = PromjenaTerapije.NOVA_FAZA_INDUKCIJA
        self.fields["razlog"].required = True
        self.fields["postupanje_sa_preostalim_dozama"].required = False

    def clean_nova_terapija(self):
        nova_terapija = self.cleaned_data.get("nova_terapija")
        current_program_id = (
            self.pacijent.terapijski_program_id
            or (
                self.pacijent.lijek.terapijski_program_id
                if self.pacijent and self.pacijent.lijek_id else None
            )
            if self.pacijent else None
        )
        if nova_terapija and nova_terapija.id == current_program_id:
            raise forms.ValidationError("Nova terapija mora biti različita od trenutne terapije.")
        return nova_terapija

    def clean(self):
        cleaned_data = super().clean()
        datum = cleaned_data.get("datum_pocetka_nove_terapije")
        nova_terapija = cleaned_data.get("nova_terapija")
        initial_phase = initial_phase_for_program(nova_terapija)
        product = (
            self._legacy_selected_product
            if self._legacy_selected_product
            and self._legacy_selected_product.terapijski_program_id
            == getattr(nova_terapija, "pk", None)
            else default_product_for_program(nova_terapija, phase=initial_phase)
        )
        cleaned_data["novi_proizvod"] = product
        if datum and product:
            from patients.scheduling import validate_therapy_date

            try:
                validate_therapy_date(datum, lijek=product)
            except ValidationError as exc:
                self.add_error(
                    "datum_pocetka_nove_terapije",
                    exc,
                )
        if nova_terapija and not product:
            self.add_error(
                "nova_terapija",
                "Podaci o lijeku nisu potpuni.",
            )
        if (
            nova_terapija
            and nova_terapija.protokol_kljuc == "ustekinumab"
        ):
            if (
                cleaned_data.get("nova_terapija_pocinje")
                != PromjenaTerapije.NOVA_FAZA_INDUKCIJA
            ):
                self.add_error(
                    "nova_terapija_pocinje",
                    "Ovaj terapijski program počinje prvom konfiguriranom fazom.",
                )
            if cleaned_data.get("pocetna_iv_doza_mg") is None:
                self.add_error(
                    "pocetna_iv_doza_mg",
                    "Unesite početnu IV dozu koju je odredio ljekar.",
                )
            elif product:
                from patients.phased_protocols import ustekinumab_iv_logistics

                try:
                    ustekinumab_iv_logistics(
                        cleaned_data["pocetna_iv_doza_mg"],
                        product,
                    )
                except ValidationError as exc:
                    self.add_error("pocetna_iv_doza_mg", exc)
        if self.preostale_doze and self.preostale_doze > 0 and not cleaned_data.get("postupanje_sa_preostalim_dozama"):
            self.add_error(
                "postupanje_sa_preostalim_dozama",
                "Odaberite šta želite uraditi sa preostalim dozama.",
            )
        return cleaned_data


class DokumentPacijentaForm(forms.ModelForm):
    MAX_FILE_SIZE = 10 * 1024 * 1024
    ALLOWED_EXTENSIONS = ["pdf", "jpg", "jpeg", "png"]

    class Meta:
        model = DokumentPacijenta
        fields = [
            "pacijent",
            "naziv",
            "tip_dokumenta",
            "datum_dokumenta",
            "fajl",
            "napomena",
        ]
        labels = {
            "pacijent": "Pacijent",
            "naziv": "Naziv dokumenta",
            "tip_dokumenta": "Tip dokumenta",
            "datum_dokumenta": "Datum dokumenta",
            "fajl": "Fajl",
            "napomena": "Napomena",
        }
        widgets = {
            "datum_dokumenta": forms.DateInput(attrs={"type": "date"}),
            "napomena": forms.Textarea(attrs={"rows": 4}),
        }

    def clean_fajl(self):
        fajl = self.cleaned_data.get("fajl")
        if not fajl:
            return fajl

        extension = fajl.name.rsplit(".", 1)[-1].lower() if "." in fajl.name else ""
        if extension not in self.ALLOWED_EXTENSIONS:
            raise forms.ValidationError("Dozvoljeni su samo PDF, JPG, JPEG i PNG fajlovi.")

        if fajl.size > self.MAX_FILE_SIZE:
            raise forms.ValidationError("Maksimalna veličina fajla je 10 MB.")

        return fajl

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["pacijent"].queryset = Pacijent.objects.filter(
            aktivan=True
        ).order_by("prezime", "ime")
