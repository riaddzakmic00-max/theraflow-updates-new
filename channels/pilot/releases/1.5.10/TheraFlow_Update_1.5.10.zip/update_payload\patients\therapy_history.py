"""Canonical rules for identifying an actually administered therapy.

Home dispensing is an inventory hand-off, not proof that every dispensed dose
was administered. Historical migration records are clinical history anchors,
but their creation deliberately has no operational inventory side effects.
"""

from django.db.models import Q


STATUS_CONFIRMED = "POTVRDJENA"
TYPE_AMBULATORY_APPLICATION = "PRIMJENA_U_AMBULANTI"


def actually_administered_therapy_query(queryset):
    """Return confirmed clinical applications, including migration history."""

    return queryset.filter(workflow_status=STATUS_CONFIRMED).filter(
        Q(is_migration=True) | Q(tip_evidencije=TYPE_AMBULATORY_APPLICATION)
    )


def is_actually_administered_therapy(therapy):
    """In-memory equivalent of ``actually_administered_therapy_query``."""

    return bool(
        therapy
        and therapy.workflow_status == STATUS_CONFIRMED
        and (
            therapy.is_migration
            or therapy.tip_evidencije == TYPE_AMBULATORY_APPLICATION
        )
    )
