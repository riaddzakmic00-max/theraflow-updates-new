(() => {
    const disclosure = document.querySelector("[data-extraordinary-disclosure]");
    if (!disclosure) return;

    const toggle = disclosure.querySelector("[data-extraordinary-toggle]");
    const content = disclosure.querySelector("[data-extraordinary-content]");
    const label = disclosure.querySelector("[data-extraordinary-toggle-label]");
    if (!toggle || !content) return;

    const storageKey = "theraflow:commission-center:extraordinary-expanded";

    function storedExpanded() {
        try {
            return window.sessionStorage.getItem(storageKey) === "true";
        } catch (_error) {
            return false;
        }
    }

    function remember(expanded) {
        try {
            window.sessionStorage.setItem(storageKey, String(expanded));
        } catch (_error) {
            // Sklapanje ostaje funkcionalno i kada browser blokira sessionStorage.
        }
    }

    function setExpanded(expanded, persist = true) {
        toggle.setAttribute("aria-expanded", String(expanded));
        content.hidden = !expanded;
        disclosure.classList.toggle("is-expanded", expanded);
        if (label) label.textContent = expanded ? "Sklopi" : "Otvori";
        if (persist) remember(expanded);
    }

    toggle.addEventListener("click", () => {
        setExpanded(toggle.getAttribute("aria-expanded") !== "true");
    });

    setExpanded(storedExpanded(), false);
})();
