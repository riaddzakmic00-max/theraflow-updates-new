from decimal import Decimal, InvalidOperation
from uuid import uuid4

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .commission_planning import commission_planning_row_for_patient
from .models import KomisijskiCiklus, Trebovanje
from .package_sizes import validate_package_multiple
from .transaction_locking import lock_instance, select_for_update_self
from .utils import upisi_log


ACTIVE_EXTRAORDINARY_STATUSES = (
    Trebovanje.STATUS_NACRT,
    Trebovanje.STATUS_SPREMAN,
    Trebovanje.STATUS_POSLAN_KOMISIJI,
    "ODOBRENO",
    Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
    Trebovanje.STATUS_CEKA_ISPORUKU,
)

EDITABLE_EXTRAORDINARY_STATUSES = (
    Trebovanje.STATUS_NACRT,
    Trebovanje.STATUS_SPREMAN,
)

REGULAR_CONFLICT_STATUSES = ("U_PRIPREMI", "PREDATO", "ODOBRENO")


def extraordinary_requests(*, active_only=False):
    queryset = Trebovanje.objects.filter(
        tip_zahtjeva=Trebovanje.TIP_VANREDNI,
    ).select_related(
        "pacijent",
        "pacijent__terapijski_program",
        "lijek",
        "lijek__terapijski_program",
        "protokol",
        "kreirao",
        "komisijski_ciklus",
        "komisija",
    )
    if active_only:
        queryset = queryset.filter(status__in=ACTIVE_EXTRAORDINARY_STATUSES)
    return queryset.order_by("-datum_kreiranja", "-id")


def find_conflicting_request(pacijent, *, exclude_request=None):
    if not pacijent or not pacijent.lijek_id:
        return None
    queryset = Trebovanje.objects.filter(
        pacijent=pacijent,
        lijek_id__in=pacijent.lijek.equivalent_ids(),
    ).exclude(status__in=("ODBIJENO", Trebovanje.STATUS_OTKAZANO, "ZAPRIMLJENO"))
    if exclude_request:
        queryset = queryset.exclude(pk=exclude_request.pk)
    return queryset.filter(
        models_q_extraordinary_or_regular()
    ).select_related("komisijski_ciklus").order_by("-datum_kreiranja", "-id").first()


def models_q_extraordinary_or_regular():
    from django.db.models import Q

    return (
        Q(
            tip_zahtjeva=Trebovanje.TIP_VANREDNI,
            status__in=ACTIVE_EXTRAORDINARY_STATUSES,
        )
        | Q(
            tip_zahtjeva=Trebovanje.TIP_REDOVNI,
            status__in=REGULAR_CONFLICT_STATUSES,
        )
    )


def extraordinary_request_context(pacijent, *, today=None):
    row = commission_planning_row_for_patient(pacijent, today=today)
    existing = find_conflicting_request(pacijent)
    planning_possible = bool(
        row and row["planning_result"].planiranje_moguce
    )
    return {
        "row": row,
        "system_quantity": (
            Decimal(str(row["sistem_predlaze"] or 0))
            if row else Decimal("0")
        ),
        "existing_request": existing,
        "can_start": bool(
            pacijent.aktivan
            and pacijent.lijek_id
            and row
            and planning_possible
            and Decimal(str(row["sistem_predlaze"] or 0)) > 0
            and existing is None
        ),
        "reason_choices": Trebovanje.RAZLOZI_VANREDNOG,
    }


def _validated_payload(*, pacijent, quantity, reason, other_reason, note):
    if not pacijent.aktivan:
        raise ValidationError(
            "Pacijent mora biti aktivan prije pokretanja novog komisijskog zahtjeva."
        )
    if not pacijent.lijek_id:
        raise ValidationError("Pacijent nema odabran lijek.")

    row = commission_planning_row_for_patient(pacijent)
    planning_possible = bool(
        row and row["planning_result"].planiranje_moguce
    )
    if not planning_possible:
        reason_text = (
            row["planning_result"].razlog
            if row
            else "Pacijent nema validan potvrđeni terapijski režim."
        )
        raise ValidationError(reason_text)

    valid_reasons = {value for value, _label in Trebovanje.RAZLOZI_VANREDNOG}
    if reason not in valid_reasons:
        raise ValidationError("Odaberite razlog vanrednog zahtjeva.")
    other_reason = (other_reason or "").strip()
    if reason == Trebovanje.RAZLOG_DRUGI and not other_reason:
        raise ValidationError("Za opciju „Drugi razlog“ unesite objašnjenje.")
    note = (note or "").strip()
    if not note:
        raise ValidationError("Kratka napomena je obavezna.")
    try:
        quantity = Decimal(str(quantity))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValidationError("Količina koja se traži nije ispravna.") from exc
    if quantity <= 0:
        raise ValidationError("Količina koja se traži mora biti veća od nule.")
    try:
        validate_package_multiple(
            quantity,
            pacijent.lijek,
            label="Količina koja se traži",
        )
    except ValueError as exc:
        raise ValidationError(str(exc)) from exc
    return row, quantity, reason, other_reason, note


@transaction.atomic
def create_extraordinary_request(
    *,
    pacijent,
    quantity,
    reason,
    other_reason="",
    note,
    user=None,
):
    row, quantity, reason, other_reason, note = _validated_payload(
        pacijent=pacijent,
        quantity=quantity,
        reason=reason,
        other_reason=other_reason,
        note=note,
    )
    conflict = find_conflicting_request(pacijent)
    if conflict:
        error = ValidationError(
            "Za ovog pacijenta već postoji aktivan zahtjev koji može pokriti istu potrebu."
        )
        error.existing_request = conflict
        raise error

    cycle = KomisijskiCiklus.objects.create(
        naziv=(
            f"VAN-{timezone.localdate():%Y}-"
            f"{pacijent.pk}-{uuid4().hex[:6].upper()}"
        ),
        tip_ciklusa=KomisijskiCiklus.TIP_VANREDNI,
        status="SIMULACIJA",
        napomena="Izdvojeni vanredni komisijski zahtjev.",
    )
    current_window = row["commission_eligibility"].trenutna_komisija
    request = Trebovanje.objects.create(
        pacijent=pacijent,
        lijek=pacijent.lijek,
        tip_zahtjeva=Trebovanje.TIP_VANREDNI,
        status=Trebovanje.STATUS_NACRT,
        broj_doza=quantity,
        razlog_vanrednog=reason,
        razlog_objasnjenje=other_reason,
        kratka_napomena=note,
        napomena=note,
        kreirao=user if getattr(user, "is_authenticated", False) else None,
        protokol=pacijent.terapijski_protokol,
        faza_terapije=pacijent.terapijska_faza() or "",
        sistemski_prijedlog=Decimal(str(row["sistem_predlaze"] or 0)),
        sljedeca_zakazana_terapija=row.get("sljedeca_stvarno_zakazana_terapija"),
        ocekivana_najranija_isporuka=(
            current_window.najranija_isporuka if current_window else None
        ),
        rizik_dostave_pri_kreiranju=bool(
            row.get("ima_stvarno_zakazanu_buducu_terapiju")
            and row.get("rizik_dostave")
        ),
        komisijski_ciklus=cycle,
    )
    upisi_log(
        user,
        "Kreiran vanredni komisijski zahtjev",
        pacijent=pacijent,
        objekat=request,
        opis=(
            f"{cycle.naziv}: nacrt za {pacijent.lijek.prikaz_naziv}; "
            f"traženo {quantity} doza; razlog {request.get_razlog_vanrednog_display()}."
        ),
    )
    return request


@transaction.atomic
def update_extraordinary_request(
    request,
    *,
    quantity,
    reason,
    other_reason="",
    note,
    user=None,
):
    request = select_for_update_self(
        Trebovanje.objects.select_related("pacijent", "lijek")
    ).get(pk=request.pk)
    if request.tip_zahtjeva != Trebovanje.TIP_VANREDNI:
        raise ValidationError("Zahtjev nije vanredni.")
    if request.status not in EDITABLE_EXTRAORDINARY_STATUSES:
        raise ValidationError("Poslani zahtjev više nije moguće uređivati.")
    _row, quantity, reason, other_reason, note = _validated_payload(
        pacijent=request.pacijent,
        quantity=quantity,
        reason=reason,
        other_reason=other_reason,
        note=note,
    )
    previous = (
        request.broj_doza,
        request.razlog_vanrednog,
        request.razlog_objasnjenje,
        request.kratka_napomena,
    )
    request.broj_doza = quantity
    request.razlog_vanrednog = reason
    request.razlog_objasnjenje = other_reason
    request.kratka_napomena = note
    request.napomena = note
    request.save(update_fields=[
        "broj_doza",
        "razlog_vanrednog",
        "razlog_objasnjenje",
        "kratka_napomena",
        "napomena",
    ])
    current = (quantity, reason, other_reason, note)
    if previous != current:
        upisi_log(
            user,
            "Izmijenjen vanredni komisijski zahtjev",
            pacijent=request.pacijent,
            objekat=request,
            opis=(
                f"Količina {previous[0]} → {quantity}; razlog/napomena ažurirani."
            ),
        )
    return request


@transaction.atomic
def mark_extraordinary_ready(request, *, user=None):
    request = Trebovanje.objects.select_for_update().get(pk=request.pk)
    if request.status != Trebovanje.STATUS_NACRT:
        raise ValidationError("Samo nacrt se može označiti spremnim za predaju.")
    request.status = Trebovanje.STATUS_SPREMAN
    request.save(update_fields=["status"])
    upisi_log(
        user,
        "Vanredni zahtjev spreman za predaju",
        pacijent=request.pacijent,
        objekat=request,
        opis="NACRT → SPREMAN.",
    )
    return request


@transaction.atomic
def cancel_extraordinary_request(request, *, user=None):
    request = lock_instance(Trebovanje, request.pk)
    cycle = (
        lock_instance(KomisijskiCiklus, request.komisijski_ciklus_id)
        if request.komisijski_ciklus_id
        else None
    )
    if request.status in ("ZAPRIMLJENO", "ODBIJENO", Trebovanje.STATUS_OTKAZANO):
        raise ValidationError("Završeni zahtjev nije moguće otkazati.")
    previous = request.status
    request.status = Trebovanje.STATUS_OTKAZANO
    request.save(update_fields=["status"])
    if cycle:
        cycle.status = "ZAVRSENO"
        cycle.save(update_fields=["status"])
    upisi_log(
        user,
        "Otkazan vanredni komisijski zahtjev",
        pacijent=request.pacijent,
        objekat=request,
        opis=f"{previous} → OTKAZANO.",
    )
    return request


@transaction.atomic
def move_extraordinary_to_regular(request, *, user=None):
    request = lock_instance(Trebovanje, request.pk)
    previous_cycle = (
        lock_instance(KomisijskiCiklus, request.komisijski_ciklus_id)
        if request.komisijski_ciklus_id
        else None
    )
    if request.status not in EDITABLE_EXTRAORDINARY_STATUSES:
        raise ValidationError(
            "Samo neposlan vanredni zahtjev može se prebaciti u redovni ciklus."
        )
    request.tip_zahtjeva = Trebovanje.TIP_REDOVNI
    request.status = "U_PRIPREMI"
    request.komisijski_ciklus = None
    request.save(update_fields=["tip_zahtjeva", "status", "komisijski_ciklus"])
    if previous_cycle:
        previous_cycle.status = "ZAVRSENO"
        previous_cycle.napomena = (
            f"Zahtjev #{request.pk} svjesno prebačen u redovni ciklus."
        )
        previous_cycle.save(update_fields=["status", "napomena"])
    upisi_log(
        user,
        "Vanredni zahtjev prebačen u redovni ciklus",
        pacijent=request.pacijent,
        objekat=request,
        opis="VANREDNI → REDOVNI; status U_PRIPREMI.",
    )
    return request
