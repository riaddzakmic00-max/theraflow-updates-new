from decimal import Decimal, ROUND_HALF_UP

from django.db import migrations, models
import django.db.models.deletion


def convert_settings_and_legacy_statuses(apps, schema_editor):
    Settings = apps.get_model("patients", "PostavkeSistema")
    for settings in Settings.objects.all():
        old_weeks = max(int(settings.komisijski_ciklus_mjeseci or 8), 1)
        settings.komisijski_ciklus_mjeseci = max(
            int((Decimal(old_weeks * 7) / Decimal("30")).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            1,
        )
        settings.vrijeme_isporuke_dana = max(int(settings.vrijeme_isporuke_dana or 4) * 7, 1)
        settings.save(update_fields=["komisijski_ciklus_mjeseci", "vrijeme_isporuke_dana"])

    Komisija = apps.get_model("patients", "Komisija")
    Komisija.objects.filter(status="ISTEKLA", preostale_doze__gt=0).update(status="AKTIVNA")
    Komisija.objects.filter(status="ISTEKLA", preostale_doze__lte=0).update(status="POTROSENA")


class Migration(migrations.Migration):
    dependencies = [("patients", "0046_migration_individual_protocol_fields")]

    operations = [
        migrations.RenameField(
            model_name="postavkesistema",
            old_name="komisijski_ciklus_sedmica",
            new_name="komisijski_ciklus_mjeseci",
        ),
        migrations.RenameField(
            model_name="postavkesistema",
            old_name="vrijeme_isporuke_sedmica",
            new_name="vrijeme_isporuke_dana",
        ),
        migrations.AddField(
            model_name="postavkesistema",
            name="priprema_zahtjeva_radnih_dana",
            field=models.PositiveIntegerField(default=5),
        ),
        migrations.AddField(
            model_name="postavkesistema",
            name="potvrdjeni_datum_naredne_komisije",
            field=models.DateField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="komisijskiciklus",
            name="datum_zaprimanja",
            field=models.DateField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="odobrene_doze",
            field=models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="zaprimljene_doze",
            field=models.DecimalField(decimal_places=2, default=0, max_digits=8),
        ),
        migrations.AddField(
            model_name="trebovanje",
            name="komisija",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="trebovanja",
                to="patients.komisija",
            ),
        ),
        migrations.AlterField(
            model_name="komisija",
            name="datum_isteka",
            field=models.DateField(blank=True, null=True),
        ),
        migrations.AlterField(
            model_name="komisija",
            name="status",
            field=models.CharField(
                choices=[
                    ("AKTIVNA", "Aktivna"), ("BUDUCA", "Buduća / odobrena"),
                    ("ODOBRENA", "Odobrena"), ("NOVA", "Potrebna nova komisija"),
                    ("POTROSENA", "Potrošena"), ("PONISTENA", "Poništena"),
                    ("ZAMIJENJENA", "Zamijenjena"),
                ],
                default="AKTIVNA",
                max_length=20,
            ),
        ),
        migrations.AlterField(
            model_name="postavkesistema",
            name="komisijski_ciklus_mjeseci",
            field=models.PositiveIntegerField(default=2),
        ),
        migrations.AlterField(
            model_name="postavkesistema",
            name="vrijeme_isporuke_dana",
            field=models.PositiveIntegerField(default=28),
        ),
        migrations.AddConstraint(
            model_name="trebovanje",
            constraint=models.CheckConstraint(
                condition=models.Q(odobrene_doze__isnull=True) | models.Q(odobrene_doze__gte=0),
                name="trebovanje_odobrene_doze_gte_0",
            ),
        ),
        migrations.AddConstraint(
            model_name="trebovanje",
            constraint=models.CheckConstraint(
                condition=models.Q(zaprimljene_doze__gte=0), name="trebovanje_zaprimljene_doze_gte_0"
            ),
        ),
        migrations.RunPython(convert_settings_and_legacy_statuses, migrations.RunPython.noop),
    ]
