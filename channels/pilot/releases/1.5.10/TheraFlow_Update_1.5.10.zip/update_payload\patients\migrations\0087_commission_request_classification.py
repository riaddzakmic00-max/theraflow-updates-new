import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models


LEGACY = {
    "bioloska_produzenje": ("BIOLOGIC", "CONTINUATION", "biologic-continuation"),
    "bioloska_novi": ("BIOLOGIC", "NEW", "biologic-new"),
    "bioloska_switch": ("BIOLOGIC", "SWITCH", "biologic-switch"),
    "bioloska_odjava": ("BIOLOGIC", "DISCONTINUATION", "biologic-discontinuation"),
    "hepatitis_b_produzenje": ("HEPATITIS_B", "CONTINUATION", "hepatitis-b-continuation"),
}


def backfill(apps, schema_editor):
    Program = apps.get_model("patients", "TerapijskiProgram")
    Request = apps.get_model("patients", "KomisijskiZahtjev")

    Program.objects.filter(kljuc__in=("entecavir", "tenofovir-disoproxil")).update(
        commission_program_type="HEPATITIS_B"
    )
    Program.objects.filter(kljuc__in=(
        "adalimumab",
        "vedolizumab",
        "infliximab",
        "ustekinumab",
        "risankizumab",
        "tofacitinib",
    )).update(
        commission_program_type="BIOLOGIC"
    )
    now = django.utils.timezone.now()
    for request in Request.objects.all().iterator():
        values = LEGACY.get(request.vrsta_zahtjeva)
        if not values:
            continue
        program_type, purpose, package_key = values
        request.program_type = program_type
        request.request_purpose = purpose
        request.system_suggested_purpose = purpose
        request.final_user_decision = purpose
        request.classification_reason_code = "LEGACY_BACKFILL"
        request.classification_reason = "Canonical snapshot preuzet iz postojećeg tipa zahtjeva."
        request.request_type_finalized_at = request.datum_kreiranja or now
        request.document_package_key = package_key
        request.document_requirements_snapshot = {
            "package_key": package_key,
            "captured_at": (request.datum_kreiranja or now).isoformat(),
            "legacy_backfill": True,
        }
        request.save(
            update_fields=(
                "program_type",
                "request_purpose",
                "system_suggested_purpose",
                "final_user_decision",
                "classification_reason_code",
                "classification_reason",
                "request_type_finalized_at",
                "document_package_key",
                "document_requirements_snapshot",
            )
        )


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0086_ustekinumab_sc_home_mode"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AddField(
            model_name="terapijskiprogram",
            name="commission_program_type",
            field=models.CharField(
                choices=[
                    ("BIOLOGIC", "Biološka terapija"),
                    ("HEPATITIS_B", "Hepatitis B"),
                    ("UNCONFIGURED", "Nije konfigurirano"),
                ],
                default="UNCONFIGURED",
                help_text="Canonical administrativni program za komisijske zahtjeve.",
                max_length=24,
            ),
        ),
        migrations.AddField(model_name="komisijskizahtjev", name="program_type", field=models.CharField(blank=True, choices=[("BIOLOGIC", "Biološka terapija"), ("HEPATITIS_B", "Hepatitis B"), ("UNCONFIGURED", "Nije konfigurirano")], default="", max_length=24)),
        migrations.AddField(model_name="komisijskizahtjev", name="request_purpose", field=models.CharField(blank=True, choices=[("NEW", "Novi"), ("CONTINUATION", "Produženje"), ("SWITCH", "Promjena/switch"), ("DISCONTINUATION", "Odjava")], default="", max_length=24)),
        migrations.AddField(model_name="komisijskizahtjev", name="system_suggested_purpose", field=models.CharField(blank=True, choices=[("NEW", "Novi"), ("CONTINUATION", "Produženje"), ("SWITCH", "Promjena/switch"), ("DISCONTINUATION", "Odjava"), ("REQUIRES_CONFIRMATION", "Potrebna potvrda")], default="", max_length=32)),
        migrations.AddField(model_name="komisijskizahtjev", name="classification_reason_code", field=models.CharField(blank=True, max_length=64)),
        migrations.AddField(model_name="komisijskizahtjev", name="classification_reason", field=models.TextField(blank=True)),
        migrations.AddField(model_name="komisijskizahtjev", name="final_user_decision", field=models.CharField(blank=True, choices=[("NEW", "Novi"), ("CONTINUATION", "Produženje"), ("SWITCH", "Promjena/switch"), ("DISCONTINUATION", "Odjava")], default="", max_length=24)),
        migrations.AddField(model_name="komisijskizahtjev", name="request_type_override_reason", field=models.TextField(blank=True)),
        migrations.AddField(model_name="komisijskizahtjev", name="request_type_finalized_at", field=models.DateTimeField(blank=True, null=True)),
        migrations.AddField(model_name="komisijskizahtjev", name="document_package_key", field=models.CharField(blank=True, max_length=80)),
        migrations.AddField(model_name="komisijskizahtjev", name="document_requirements_snapshot", field=models.JSONField(blank=True, default=dict)),
        migrations.AddField(model_name="komisijskizahtjev", name="request_type_finalized_by", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="finalizirane_vrste_komisijskih_zahtjeva", to=settings.AUTH_USER_MODEL)),
        migrations.AddField(model_name="komisijskizahtjev", name="source_therapy_change", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="komisijski_zahtjevi", to="patients.promjenaterapije")),
        migrations.RunPython(backfill, migrations.RunPython.noop),
    ]
