@echo off
setlocal EnableExtensions

set "SCRIPT_DIR=%~dp0"
set "LOG_DIR=%ProgramData%\TheraFlow\logs"
set "INSTALLER_LOG=%LOG_DIR%\install_runtime.log"

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1

echo.
echo Installing TheraFlow application...
set "RESET_OPTION="
set "UPDATE_MANIFEST_URL="
:parse_arguments
if "%~1"=="" goto arguments_parsed
if /I "%~1"=="--reset-orphaned-database" (
    set "RESET_OPTION=-ResetOrphanedDatabase"
    shift
    goto parse_arguments
)
if /I "%~1"=="--update-manifest-url" (
    set "UPDATE_MANIFEST_URL=%~2"
    shift
    shift
    goto parse_arguments
)
echo ERROR: Unknown runtime option: %~1
exit /b 2

:arguments_parsed
if "%UPDATE_MANIFEST_URL%"=="" (
    echo ERROR: Required update manifest URL was not provided.
    exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%install_runtime.ps1" -UpdateManifestUrl "%UPDATE_MANIFEST_URL%" %RESET_OPTION%
set "EXIT_CODE=%ERRORLEVEL%"

if not "%EXIT_CODE%"=="0" (
    echo.
    echo Instalacija nije uspjesno zavrsena.
    echo.
    echo Detalji su sacuvani u:
    echo %INSTALLER_LOG%
    echo.
)
exit /b %EXIT_CODE%
