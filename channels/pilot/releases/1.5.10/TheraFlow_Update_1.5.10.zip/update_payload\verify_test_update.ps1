param(
    [string]$ExpectedVersion = "1.5.1-test",
    [string]$ServiceName = "TheraFlow",
    [string]$HealthUrl = "http://127.0.0.1:8000/health/update/",
    [string]$DataDir = ""
)

$ErrorActionPreference = "Stop"
$ProjectRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$LogDirectory = Join-Path $ProjectRoot "logs"
$VerificationLog = Join-Path $LogDirectory "verify_test_update.log"
New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
[System.IO.File]::WriteAllText(
    $VerificationLog,
    "TheraFlow test update verification - $([DateTimeOffset]::Now.ToString('o'))`r`n",
    (New-Object System.Text.UTF8Encoding($false))
)

$script:FailureCount = 0
$script:SessionLog = Join-Path $LogDirectory "update_install.log"
$ServiceErrorLog = Join-Path $LogDirectory "service_error.log"

function Write-VerificationLine {
    param([string]$Text)
    Write-Host $Text
    Add-Content -LiteralPath $VerificationLog -Value $Text -Encoding UTF8
}

function Write-Result {
    param(
        [bool]$Passed,
        [string]$Check,
        [string]$Detail,
        [string]$RelevantLog = $VerificationLog
    )
    $label = if ($Passed) { "PASS" } else { "FAIL" }
    Write-VerificationLine "[$label] $Check - $Detail"
    if (-not $Passed) {
        $script:FailureCount++
        Write-VerificationLine "       Relevantni log: $RelevantLog"
    }
}

function Read-JsonFile {
    param([string]$Path)
    return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Resolve-Python {
    $venvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
    if (Test-Path -LiteralPath $venvPython -PathType Leaf) {
        return $venvPython
    }
    $command = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($command) {
        return $command.Source
    }
    return $null
}

function Test-ChildPath {
    param([string]$Path, [string]$Parent)
    $resolvedPath = [System.IO.Path]::GetFullPath($Path)
    $resolvedParent = [System.IO.Path]::GetFullPath($Parent).TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
    return $resolvedPath.StartsWith($resolvedParent, [System.StringComparison]::OrdinalIgnoreCase)
}

Write-VerificationLine ""
Write-VerificationLine "TheraFlow post-update provjera"
Write-VerificationLine "Ocekivana verzija: $ExpectedVersion"
Write-VerificationLine "Provjera je read-only za bazu i ne pristupa medicinskim podacima."
Write-VerificationLine ""

$healthUri = $null
$validHealthUrl = [System.Uri]::TryCreate($HealthUrl, [System.UriKind]::Absolute, [ref]$healthUri) -and
    $healthUri.Scheme -eq "http" -and $healthUri.Host -in @("127.0.0.1", "localhost", "::1")
if (-not $validHealthUrl) {
    Write-Result $false "Lokalni URL" "Health URL mora biti lokalni HTTP URL." $VerificationLog
}

if ([string]::IsNullOrWhiteSpace($DataDir)) {
    $DataDir = if ($env:THERAFLOW_DATA_DIR) { $env:THERAFLOW_DATA_DIR } else { Join-Path $ProjectRoot "data" }
}
$DataRoot = [System.IO.Path]::GetFullPath($DataDir)
$SessionsRoot = Join-Path $DataRoot "updates\sessions"
$TrustedBackupRoot = Join-Path $DataRoot "backups\updates"

$state = $null
$statePath = $null
$plan = $null
$planPath = $null
$sessionId = $null

if (Test-Path -LiteralPath $SessionsRoot -PathType Container) {
    $states = foreach ($candidate in Get-ChildItem -LiteralPath $SessionsRoot -Filter "*.json" -File -ErrorAction SilentlyContinue) {
        try {
            $value = Read-JsonFile $candidate.FullName
            if ([string]$value.target_version -eq $ExpectedVersion) {
                [pscustomobject]@{ Path = $candidate.FullName; Value = $value; Updated = [DateTimeOffset]::Parse([string]$value.updated_at) }
            }
        }
        catch {
            Add-Content -LiteralPath $VerificationLog -Value "Preskocen nevalidan state fajl: $($candidate.FullName)" -Encoding UTF8
        }
    }
    $latest = $states | Sort-Object Updated -Descending | Select-Object -First 1
    if ($latest) {
        $state = $latest.Value
        $statePath = $latest.Path
        $sessionId = if ($state.session_id) { [string]$state.session_id } else { [System.IO.Path]::GetFileNameWithoutExtension($statePath) }
        $planPath = Join-Path (Join-Path $SessionsRoot $sessionId) "install_plan.json"
        $script:SessionLog = Join-Path (Split-Path -Parent $planPath) "update_install.log"
        if (Test-Path -LiteralPath $planPath -PathType Leaf) {
            try { $plan = Read-JsonFile $planPath } catch { $plan = $null }
        }
    }
}

$statePassed = $null -ne $state -and [string]$state.status -eq "update_completed" -and
    [string]$state.target_version -eq $ExpectedVersion -and [bool]$state.files_changed -and
    [string]$state.health_check_status -eq "health_check_passed"
$stateDetail = if ($null -eq $state) { "Nije pronadjen update session za ciljnu verziju." } else { "Session $sessionId ima status $($state.status)." }
Write-Result $statePassed "Zavrsni status updatera" $stateDetail $script:SessionLog

try {
    $service = Get-Service -Name $ServiceName -ErrorAction Stop
    Write-Result ($service.Status -eq [System.ServiceProcess.ServiceControllerStatus]::Running) "Windows servis" "Servis $ServiceName je $($service.Status)." $ServiceErrorLog
}
catch {
    Write-Result $false "Windows servis" "Servis $ServiceName nije dostupan ili se stanje ne moze procitati." $ServiceErrorLog
}

$health = $null
if ($validHealthUrl) {
    try {
        $response = Invoke-WebRequest -Uri $HealthUrl -UseBasicParsing -TimeoutSec 15
        $health = $response.Content | ConvertFrom-Json
        Write-Result ($response.StatusCode -eq 200) "Lokalni HTTP odgovor" "HTTP $($response.StatusCode) sa $HealthUrl." $ServiceErrorLog
    }
    catch {
        Write-Result $false "Lokalni HTTP odgovor" "Aplikacija nije odgovorila na $HealthUrl." $ServiceErrorLog
    }
}

$healthVersion = if ($null -ne $health) { [string]$health.version } else { "" }
Write-Result ($healthVersion -eq $ExpectedVersion) "Verzija aplikacije" "Prijavljena verzija: $(if ($healthVersion) { $healthVersion } else { 'nema odgovora' })." $ServiceErrorLog

$healthDatabaseOk = $null -ne $health -and [string]$health.status -eq "ok" -and [string]$health.database -eq "ok"
Write-Result $healthDatabaseOk "Health provjera baze" "Health status=$(if ($health) { $health.status } else { 'nema odgovora' }), database=$(if ($health) { $health.database } else { 'nema odgovora' })." $ServiceErrorLog

$backupPassed = $false
$backupDetail = "Nema validnog install plana za ciljnu update sesiju."
if ($null -ne $plan) {
    try {
        $backupRoot = [System.IO.Path]::GetFullPath([string]$plan.backup_root)
        $dumpPath = [System.IO.Path]::GetFullPath([string]$plan.database_backup_path)
        $metadataPath = Join-Path $backupRoot "backup_metadata.json"
        $snapshotPath = Join-Path $backupRoot "application_snapshot_manifest.json"
        if (-not (Test-ChildPath $backupRoot $TrustedBackupRoot)) { throw "Backup je izvan dozvoljenog update backup direktorija." }
        if (-not (Test-ChildPath $dumpPath $backupRoot)) { throw "Database dump je izvan session backup direktorija." }
        if (-not (Test-Path -LiteralPath $dumpPath -PathType Leaf) -or (Get-Item -LiteralPath $dumpPath).Length -le 0) { throw "Database dump ne postoji ili je prazan." }
        if (-not (Test-Path -LiteralPath $metadataPath -PathType Leaf)) { throw "Backup metadata ne postoji." }
        if (-not (Test-Path -LiteralPath $snapshotPath -PathType Leaf)) { throw "Application snapshot metadata ne postoji." }
        $metadata = Read-JsonFile $metadataPath
        $snapshot = Read-JsonFile $snapshotPath
        $actualHash = (Get-FileHash -LiteralPath $dumpPath -Algorithm SHA256).Hash.ToLowerInvariant()
        $backupTime = [DateTimeOffset]::Parse([string]$metadata.created_at)
        $planTime = [DateTimeOffset]::Parse([string]$plan.created_at)
        $snapshotTime = [DateTimeOffset]::Parse([string]$snapshot.created_at)
        $backupPassed = [string]$metadata.validation -eq "pg_restore_list_passed" -and
            [string]$metadata.dump_sha256 -eq $actualHash -and
            [string]$metadata.session_id -eq $sessionId -and
            [string]$metadata.target_version -eq $ExpectedVersion -and
            [string]$snapshot.session_id -eq $sessionId -and
            $backupTime -le $planTime -and $planTime -le $snapshotTime
        $backupDetail = if ($backupPassed) {
            "Validirani PostgreSQL backup i snapshot postoje; backup je kreiran prije install plana i zamjene fajlova."
        } else {
            "Backup artefakti postoje, ali checksum, identitet sesije, validacija ili redoslijed vremena nije ispravan."
        }
    }
    catch {
        $backupDetail = $_.Exception.Message
    }
}
Write-Result $backupPassed "Backup prije zamjene fajlova" $backupDetail $script:SessionLog

$python = Resolve-Python
$managePy = Join-Path $ProjectRoot "manage.py"
$postgresPassed = $false
$migrationsPassed = $false
if ($python -and (Test-Path -LiteralPath $managePy -PathType Leaf)) {
    $oldBytecode = $env:PYTHONDONTWRITEBYTECODE
    $env:PYTHONDONTWRITEBYTECODE = "1"
    try {
        $databaseProbe = "from django.db import connection; connection.ensure_connection(); assert connection.vendor == 'postgresql'; cursor = connection.cursor(); cursor.execute('SELECT 1'); assert cursor.fetchone()[0] == 1; cursor.close()"
        $databaseOutput = & $python $managePy shell -c $databaseProbe 2>&1
        $postgresPassed = $LASTEXITCODE -eq 0
        Add-Content -LiteralPath $VerificationLog -Value ($databaseOutput | Out-String) -Encoding UTF8

        $migrationOutput = & $python $managePy migrate --check --noinput 2>&1
        $migrationsPassed = $LASTEXITCODE -eq 0
        Add-Content -LiteralPath $VerificationLog -Value ($migrationOutput | Out-String) -Encoding UTF8
        if ($migrationsPassed -and $null -ne $plan -and [bool]$plan.migration_required) {
            $migrationsPassed = [bool]$state.migration_completed
        }
    }
    catch {
        Add-Content -LiteralPath $VerificationLog -Value $_.Exception.Message -Encoding UTF8
    }
    finally {
        $env:PYTHONDONTWRITEBYTECODE = $oldBytecode
    }
}

Write-Result $postgresPassed "PostgreSQL baza" "Django PostgreSQL konekcija i read-only SELECT 1 $(if ($postgresPassed) { 'su uspjesni' } else { 'nisu uspjeli' })." $script:SessionLog
$migrationDetail = if ($migrationsPassed) { "Nema neprimijenjenih Django migracija." } else { "Postoje neprimijenjene migracije ili provjera nije mogla biti izvrsena." }
Write-Result $migrationsPassed "Django migracije" $migrationDetail $script:SessionLog

Write-VerificationLine ""
Write-VerificationLine "Verifikacijski log: $VerificationLog"
Write-VerificationLine "Updater log: $script:SessionLog"
Write-VerificationLine "Service log: $ServiceErrorLog"
Write-VerificationLine "Backup i stari fajlovi nisu mijenjani niti brisani."

if ($script:FailureCount -gt 0) {
    Write-VerificationLine "REZULTAT: FAIL ($script:FailureCount neuspjelih provjera)"
    exit 1
}

Write-VerificationLine "REZULTAT: PASS"
exit 0
