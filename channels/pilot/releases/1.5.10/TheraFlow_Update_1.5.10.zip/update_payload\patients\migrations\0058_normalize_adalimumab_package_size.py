from django.db import migrations
from django.db.models import Q


ADALIMUMAB_ALIASES = (
    "Hyrimoz",
    "Humira",
    "Amgevita",
    "Imraldi",
    "Yuflyma",
)


def normalize_adalimumab_package_size(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    adalimumab = Q(genericki_naziv__icontains="adalimumab")
    for alias in ADALIMUMAB_ALIASES:
        adalimumab |= Q(naziv__icontains=alias)
        adalimumab |= Q(zasticeno_ime__icontains=alias)
    Lijek.objects.filter(adalimumab).update(package_size_in_doses=2)


class Migration(migrations.Migration):
    dependencies = [("patients", "0057_commission_safety_reserve")]

    operations = [
        migrations.RunPython(
            normalize_adalimumab_package_size,
            migrations.RunPython.noop,
        ),
    ]
