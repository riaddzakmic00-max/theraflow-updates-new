import json
import os
import subprocess
from pathlib import Path

from .plan_loader import sha256_file


class DatabaseRestoreError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def _env_file(path):
    values = {}
    path = Path(path)
    if not path.is_file():
        return values
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _executable(name, plan=None):
    configured = (plan or {}).get("postgres_tools", {}).get(name)
    if configured:
        configured = Path(configured).resolve()
        if configured.is_file():
            return str(configured)
    if plan and plan.get("application_root"):
        candidate = Path(plan["application_root"]).resolve().parent / "runtime" / "postgresql" / "bin" / f"{name}.exe"
        if candidate.is_file():
            return str(candidate)
    raise DatabaseRestoreError("postgres_tool_missing", f"PostgreSQL alat {name} nije pronađen.")


def _database(plan, metadata):
    values = _env_file(plan["canonical_env_path"])
    expected = str(metadata.get("database_name") or "")
    actual = values.get("DB_NAME", expected or "theraflow")
    if not expected or actual != expected:
        raise DatabaseRestoreError("database_identity_mismatch", "Database backup ne odgovara lokalnoj bazi.")
    return {
        "name": actual,
        "user": values.get("DB_USER", "theraflow_user"),
        "password": values.get("DB_PASSWORD", ""),
        "host": values.get("DB_HOST", "127.0.0.1"),
        "port": values.get("DB_PORT", "5433"),
    }


def _run(command, database, timeout=900, runner=None):
    env = {key: os.environ[key] for key in ("SystemRoot", "WINDIR", "PATH", "PATHEXT", "COMSPEC", "TEMP", "TMP") if key in os.environ}
    if database["password"]:
        env["PGPASSWORD"] = database["password"]
    runner = runner or subprocess.run
    try:
        result = runner(command, env=env, capture_output=True, text=True, check=False, timeout=timeout, shell=False)
    except subprocess.TimeoutExpired as exc:
        raise DatabaseRestoreError("database_command_timeout", "PostgreSQL restore je prekoračio dozvoljeno vrijeme.") from exc
    if result.returncode:
        detail = ((result.stderr or result.stdout or "")[-2000:]).replace(database["password"], "[REDACTED]") if database["password"] else (result.stderr or result.stdout or "")[-2000:]
        raise DatabaseRestoreError("database_command_failed", detail or "PostgreSQL restore komanda nije uspjela.")
    return result


def validate_original_backup(plan, runner=None):
    backup = Path(plan["backup_root"]).resolve()
    dump = Path(plan["database_backup_path"]).resolve()
    try:
        metadata = json.loads((backup / "backup_metadata.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise DatabaseRestoreError("database_metadata_invalid", "Database backup metadata nije validan.") from exc
    if dump.parent != backup or not dump.is_file() or metadata.get("session_id") != plan["session_id"]:
        raise DatabaseRestoreError("database_session_mismatch", "Database backup ne pripada ovom update sessionu.")
    if metadata.get("validation") != "pg_restore_list_passed" or sha256_file(dump) != metadata.get("dump_sha256"):
        raise DatabaseRestoreError("database_backup_invalid", "Database backup hash nije ispravan.")
    database = _database(plan, metadata)
    _run([_executable("pg_restore", plan), "--list", str(dump)], database, timeout=120, runner=runner)
    return dump, metadata, database


def create_emergency_backup(plan, database, runner=None):
    destination = Path(plan["backup_root"]) / "pre_rollback_database.dump"
    command = [
        _executable("pg_dump", plan), "--format=custom", "--file", str(destination),
        "--dbname", database["name"], "--host", database["host"],
        "--port", str(database["port"]), "--username", database["user"], "--no-password",
    ]
    _run(command, database, runner=runner)
    if not destination.is_file() or destination.stat().st_size == 0:
        raise DatabaseRestoreError("emergency_backup_failed", "Emergency database backup nije kreiran.")
    _run([_executable("pg_restore", plan), "--list", str(destination)], database, timeout=120, runner=runner)
    return destination


def restore_original_database(plan, dump, database, runner=None):
    psql = _executable("psql", plan)
    terminate_sql = "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = current_database() AND pid <> pg_backend_pid();"
    _run([psql, "--dbname", database["name"], "--host", database["host"], "--port", str(database["port"]), "--username", database["user"], "--no-password", "--command", terminate_sql], database, timeout=60, runner=runner)
    command = [
        _executable("pg_restore", plan), "--clean", "--if-exists", "--no-owner", "--no-privileges",
        "--exit-on-error", "--dbname", database["name"], "--host", database["host"],
        "--port", str(database["port"]), "--username", database["user"], "--no-password", str(dump),
    ]
    _run(command, database, runner=runner)
    _run([psql, "--dbname", database["name"], "--host", database["host"], "--port", str(database["port"]), "--username", database["user"], "--no-password", "--command", "SELECT 1;"], database, timeout=60, runner=runner)
    return True


def restore_database(plan, runner=None):
    dump, _metadata, database = validate_original_backup(plan, runner=runner)
    emergency = create_emergency_backup(plan, database, runner=runner)
    restore_original_database(plan, dump, database, runner=runner)
    return {"database_restored": True, "emergency_backup_path": str(emergency)}
