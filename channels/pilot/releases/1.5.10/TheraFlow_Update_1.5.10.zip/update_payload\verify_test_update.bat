@echo off
setlocal
chcp 65001 >nul

set "SCRIPT_DIR=%~dp0"
set "VERIFY_SCRIPT=%SCRIPT_DIR%verify_test_update.ps1"

if not exist "%VERIFY_SCRIPT%" (
    echo [FAIL] Nedostaje PowerShell verifier: %VERIFY_SCRIPT%
    echo Relevantni log: %SCRIPT_DIR%logs\verify_test_update.log
    exit /b 2
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%VERIFY_SCRIPT%" %*
set "EXIT_CODE=%ERRORLEVEL%"

if not "%EXIT_CODE%"=="0" (
    echo.
    echo Verifikacija nije prosla. Nijedan backup niti stari fajl nije obrisan.
)

exit /b %EXIT_CODE%
