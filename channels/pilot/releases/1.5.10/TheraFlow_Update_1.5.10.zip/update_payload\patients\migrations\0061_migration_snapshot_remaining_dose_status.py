from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0060_normalize_procurement_package_sizes"),
    ]

    operations = [
        migrations.AddField(
            model_name="migracijskisnapshotpacijenta",
            name="status_preostalih_odobrenih_doza",
            field=models.CharField(
                choices=[
                    ("CEKA_ISPORUKU", "Odobrene, čekaju isporuku"),
                    ("ZAPRIMLJENE", "Zaprimljene i dostupne"),
                    ("KOD_PACIJENTA", "Već dodijeljene pacijentu"),
                ],
                default="CEKA_ISPORUKU",
                max_length=24,
            ),
        ),
    ]
