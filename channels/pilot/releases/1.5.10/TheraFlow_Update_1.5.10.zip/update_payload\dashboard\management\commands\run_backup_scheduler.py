import logging
import os
import sys
import traceback

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import connection
from django.utils import timezone

from dashboard.backup_scheduler import BackupScheduler
from dashboard.postgres_backup import (
    BackupBusyError,
    append_scheduler_log,
    next_automatic_backup,
    run_manual_backup_test,
)


logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = "Pokreće trajni TheraFlow scheduler automatskog PostgreSQL backupa."

    def add_arguments(self, parser):
        parser.add_argument(
            "--once",
            action="store_true",
            help=(
                "Izvrši ručni dijagnostički backup bez upisa scheduler "
                "heartbeat/PID stanja."
            ),
        )
        parser.add_argument(
            "--check-interval",
            type=int,
            default=None,
            help="Interval heartbeat/provjere u sekundama.",
        )

    def handle(self, *args, **options):
        if options["once"]:
            try:
                path = run_manual_backup_test()
            except BackupBusyError as exc:
                raise CommandError("Backup je već aktivan u drugom procesu.") from exc
            self.stdout.write(
                self.style.SUCCESS(f"Ručni dijagnostički backup je kreiran: {path}")
            )
            return
        database = settings.DATABASES["default"]
        env_file = os.environ.get("THERAFLOW_ENV_FILE", "")
        startup_details = {
            "pid": os.getpid(),
            "settings_module": os.environ.get(
                "DJANGO_SETTINGS_MODULE", "config.settings"
            ),
            "environment_file": env_file,
            "database_engine": database.get("ENGINE", ""),
            "database_host": database.get("HOST", ""),
            "database_port": str(database.get("PORT", "")),
            "database_name": database.get("NAME", ""),
            "database_user": database.get("USER", ""),
            "state_file": str(settings.THERAFLOW_BACKUP_STATE),
            "next_run": next_automatic_backup(timezone.now()).isoformat(),
        }
        # Never log the database password or the contents of the canonical .env.
        append_scheduler_log("scheduler_command_starting", **startup_details)
        self.stdout.write(
            "TheraFlow backup scheduler startup: "
            f"pid={startup_details['pid']} "
            f"settings={startup_details['settings_module']} "
            f"env={startup_details['environment_file']} "
            f"db={startup_details['database_host']}:"
            f"{startup_details['database_port']}/"
            f"{startup_details['database_name']} "
            f"state={startup_details['state_file']} "
            f"next_run={startup_details['next_run']}"
        )
        self.stdout.flush()
        try:
            connection.ensure_connection()
        except Exception as exc:
            append_scheduler_log(
                "scheduler_database_connection_failed",
                pid=os.getpid(),
                error_type=type(exc).__name__,
                traceback=traceback.format_exc(),
            )
            logger.exception("Backup scheduler database connection failed.")
            raise
        append_scheduler_log(
            "scheduler_database_connection_ready",
            pid=os.getpid(),
            database_name=database.get("NAME", ""),
        )
        scheduler = BackupScheduler(check_interval=options["check_interval"])
        try:
            scheduler.run()
        except BackupBusyError as exc:
            raise CommandError(
                "Backup scheduler je već aktivan u drugom procesu."
            ) from exc
        except KeyboardInterrupt:
            scheduler.stop()
            self.stdout.write(self.style.WARNING("Backup scheduler je zaustavljen."))
        except Exception as exc:
            append_scheduler_log(
                "scheduler_command_failed",
                pid=os.getpid(),
                error_type=type(exc).__name__,
                error=str(exc),
                traceback=traceback.format_exc(),
            )
            logger.exception("Backup scheduler terminated unexpectedly.")
            self.stderr.write(
                "TheraFlow backup scheduler fatal error:\n"
                f"{traceback.format_exc()}"
            )
            self.stderr.flush()
            raise
