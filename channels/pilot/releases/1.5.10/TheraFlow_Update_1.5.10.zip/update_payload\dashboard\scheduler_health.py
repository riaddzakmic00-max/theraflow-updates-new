import json
import os
import subprocess
from datetime import timedelta

from django.conf import settings
from django.utils import timezone


HEALTH_ACTIVE_SERVICE = "active_service"
HEALTH_ACTIVE_LOCAL = "active_local"
HEALTH_SERVICE_HEARTBEAT_LATE = "service_heartbeat_late"
HEALTH_INACTIVE = "inactive"
HEALTH_UNCONFIRMED = "unconfirmed"


def _parse_datetime(value):
    if not value:
        return None
    try:
        parsed = timezone.datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None
    if timezone.is_naive(parsed):
        parsed = timezone.make_aware(parsed, timezone.get_current_timezone())
    return parsed


def inspect_scheduler_process(pid):
    result = {
        "pid": pid,
        "check_status": "missing",
        "exists": False,
        "identity_valid": False,
        "executable": "",
        "command_line": "",
        "started_at": None,
        "reason": "process_missing",
    }
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return result
    if pid <= 0:
        return result

    if os.name != "nt":
        proc_path = f"/proc/{pid}"
        if not os.path.isdir(proc_path):
            return result
        result.update(check_status="unavailable", exists=True, identity_valid=None)
        try:
            with open(f"{proc_path}/cmdline", "rb") as handle:
                command = handle.read().replace(b"\0", b" ").decode(errors="replace").strip()
            executable = os.readlink(f"{proc_path}/exe")
            started_at = timezone.datetime.fromtimestamp(
                os.stat(proc_path).st_ctime,
                tz=timezone.get_current_timezone(),
            )
            result.update(
                check_status="ok",
                command_line=command,
                executable=executable,
                started_at=started_at,
            )
        except (OSError, PermissionError):
            return result
    else:
        script = (
            f"$p=Get-CimInstance Win32_Process -Filter \"ProcessId={pid}\" "
            "-ErrorAction Stop;"
            "if($null -eq $p){exit 3};"
            "$o=[ordered]@{ExecutablePath=$p.ExecutablePath;"
            "CommandLine=$p.CommandLine;CreationDate=$p.CreationDate};"
            "$o|ConvertTo-Json -Compress"
        )
        try:
            completed = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    script,
                ],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except (OSError, subprocess.TimeoutExpired):
            result.update(check_status="unavailable", identity_valid=None, reason="process_check_unavailable")
            return result
        if completed.returncode == 3:
            return result
        if completed.returncode != 0:
            # Get-CimInstance may require privileges. Get-Process still distinguishes a
            # missing PID from an identity check that cannot be completed.
            fallback = (
                f"$p=Get-Process -Id {pid} -ErrorAction SilentlyContinue;"
                "if($null -eq $p){exit 3}else{exit 0}"
            )
            fallback_result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", fallback],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if fallback_result.returncode == 3:
                return result
            result.update(
                check_status="unavailable",
                exists=True,
                identity_valid=None,
                reason="process_identity_unavailable",
            )
            return result
        try:
            payload = json.loads(completed.stdout)
        except (TypeError, ValueError, json.JSONDecodeError):
            result.update(check_status="unavailable", exists=True, identity_valid=None, reason="invalid_process_response")
            return result
        result.update(
            check_status="ok",
            exists=True,
            executable=payload.get("ExecutablePath") or "",
            command_line=payload.get("CommandLine") or "",
            started_at=_parse_datetime(payload.get("CreationDate")),
        )

    command = result["command_line"].replace("\\", "/").lower()
    valid = "manage.py" in command and "run_backup_scheduler" in command and "--once" not in command
    result["identity_valid"] = valid
    result["reason"] = "scheduler_process" if valid else "wrong_process_identity"
    return result


def inspect_windows_service(service_name):
    result = {
        "name": service_name,
        "installed": None,
        "state": "UNAVAILABLE",
        "pid": None,
        "check_status": "unavailable",
    }
    if os.name != "nt":
        return result
    try:
        completed = subprocess.run(
            ["sc.exe", "queryex", service_name],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except (OSError, subprocess.TimeoutExpired):
        return result
    output = f"{completed.stdout}\n{completed.stderr}"
    if completed.returncode == 1060 or "FAILED 1060" in output:
        result.update(installed=False, state="NOT_INSTALLED", check_status="ok")
        return result
    if completed.returncode != 0:
        return result
    state = "UNKNOWN"
    service_pid = None
    for line in output.splitlines():
        if "STATE" in line and ":" in line:
            state = line.split(":", 1)[1].strip().split()[-1]
        elif "PID" in line and ":" in line:
            try:
                service_pid = int(line.split(":", 1)[1].strip())
            except ValueError:
                service_pid = None
    result.update(
        installed=True,
        state=state,
        pid=service_pid,
        check_status="ok",
    )
    return result


def scheduler_health(
    scheduler,
    *,
    now=None,
    process_inspector=inspect_scheduler_process,
    service_inspector=inspect_windows_service,
):
    now = now or timezone.now()
    heartbeat = _parse_datetime(scheduler.get("heartbeat_at"))
    heartbeat_limit = int(
        getattr(settings, "THERAFLOW_BACKUP_HEARTBEAT_FRESH_SECONDS", 600)
    )
    heartbeat_age = None
    if heartbeat:
        heartbeat_age = (now - heartbeat).total_seconds()
    heartbeat_fresh = (
        heartbeat_age is not None
        and 0 <= heartbeat_age < heartbeat_limit
    )

    process = process_inspector(scheduler.get("pid"))
    service_name = scheduler.get("service_name") or getattr(
        settings,
        "THERAFLOW_BACKUP_SCHEDULER_SERVICE_NAME",
        "TheraFlowBackupScheduler",
    )
    service = service_inspector(service_name)
    process_valid = process.get("exists") and process.get("identity_valid") is True
    service_running = service.get("state") == "RUNNING"

    if service_running and process_valid and heartbeat_fresh and scheduler.get("running"):
        code = HEALTH_ACTIVE_SERVICE
        label = "Aktivan kao Windows servis"
        message = "Windows servis, scheduler proces i heartbeat su uredni."
    elif not service_running and process_valid and heartbeat_fresh and scheduler.get("running"):
        code = HEALTH_ACTIVE_LOCAL
        label = "Aktivan kao lokalni proces"
        message = "Scheduler radi kao lokalni proces, izvan Windows servisa."
    elif service_running and not heartbeat_fresh:
        code = HEALTH_SERVICE_HEARTBEAT_LATE
        label = "Servis radi, heartbeat kasni"
        message = "Windows servis je pokrenut, ali scheduler heartbeat kasni."
    elif process.get("check_status") == "unavailable" or service.get("check_status") == "unavailable":
        code = HEALTH_UNCONFIRMED
        label = "Status nije moguće potvrditi"
        message = "Provjera procesa ili Windows servisa nije dostupna."
    else:
        code = HEALTH_INACTIVE
        label = "Scheduler nije aktivan"
        if heartbeat_fresh and not process.get("exists"):
            message = "Posljednji heartbeat je svjež, ali proces više nije aktivan."
        elif process.get("exists") and process.get("identity_valid") is False:
            message = "Evidentirani PID ne pripada scheduler procesu."
        elif service.get("state") == "NOT_INSTALLED":
            message = "Windows servis nije instaliran i scheduler proces nije aktivan."
        else:
            message = "Scheduler proces nije aktivan."

    return {
        "code": code,
        "label": label,
        "message": message,
        "active": code in {HEALTH_ACTIVE_SERVICE, HEALTH_ACTIVE_LOCAL},
        "heartbeat": heartbeat,
        "heartbeat_age_seconds": max(0, heartbeat_age) if heartbeat_age is not None else None,
        "heartbeat_fresh": heartbeat_fresh,
        "heartbeat_limit_seconds": heartbeat_limit,
        "process": process,
        "service": service,
    }
