import json
import os
from pathlib import Path

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from updates.models import UpdateSession
from theraflow.version import __version__

from .update_paths import get_update_paths


class UpdateLockedError(RuntimeError):
    pass


SAFE_MANIFEST_FIELDS = (
    "version", "release_date", "mandatory", "sha256",
    "min_supported_version", "release_notes",
)


def sanitized_manifest(manifest):
    return {key: manifest[key] for key in SAFE_MANIFEST_FIELDS if key in manifest}


def state_payload(session):
    return {
        "session_id": str(session.pk),
        "target_version": session.target_version,
        "current_version": __version__,
        "status": session.status,
        "is_active": session.is_active,
        "package_path": session.package_path,
        "package_sha256": session.package_sha256,
        "backup_directory": session.backup_directory,
        "database_backup_path": session.database_backup_path,
        "config_backup_path": session.config_backup_path,
        "staging_directory": session.staging_directory,
        "install_plan_path": session.install_plan_path,
        "install_plan_sha256": session.install_plan_sha256,
        "application_root": str(Path(settings.BASE_DIR).resolve()),
        "data_root": str(get_update_paths().data_root),
        "service_name": settings.THERAFLOW_SERVICE_NAME,
        "health_check_url": settings.THERAFLOW_HEALTH_CHECK_URL,
        "manifest_snapshot": session.manifest_snapshot,
        "database_backup_validated": session.database_backup_validated,
        "staging_validated": session.staging_validated,
        "error_message": session.error_message,
        "prepared_at": session.prepared_at.isoformat() if session.prepared_at else None,
        "updated_at": session.updated_at.isoformat() if session.updated_at else timezone.now().isoformat(),
        "updater_pid": session.updater_pid,
        "install_started_at": session.install_started_at.isoformat() if session.install_started_at else None,
        "install_completed_at": session.install_completed_at.isoformat() if session.install_completed_at else None,
    }


def write_state_file(session):
    root = get_update_paths().sessions
    destination = root / f"{session.pk}.json"
    temporary = destination.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(state_payload(session), indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, destination)
    return destination


def save_session(session, update_fields=None):
    fields = list(update_fields or [])
    if fields and "updated_at" not in fields:
        fields.append("updated_at")
    session.save(update_fields=fields or None)
    write_state_file(session)
    return session


@transaction.atomic
def register_downloaded_package(manifest, package_path, user=None):
    active = UpdateSession.objects.select_for_update().filter(is_active=True).first()
    version = str(manifest["version"])
    if active:
        if active.target_version != version:
            raise UpdateLockedError("Drugi update proces je već aktivan.")
        active.package_path = str(Path(package_path).resolve())
        active.package_sha256 = str(manifest["sha256"]).lower()
        active.manifest_snapshot = sanitized_manifest(manifest)
        active.prepared_by = user
        return save_session(active, ["package_path", "package_sha256", "manifest_snapshot", "prepared_by"])
    session = UpdateSession.objects.create(
        target_version=version,
        status=UpdateSession.PACKAGE_DOWNLOADED,
        package_path=str(Path(package_path).resolve()),
        package_sha256=str(manifest["sha256"]).lower(),
        manifest_snapshot=sanitized_manifest(manifest),
        prepared_by=user,
    )
    write_state_file(session)
    return session
