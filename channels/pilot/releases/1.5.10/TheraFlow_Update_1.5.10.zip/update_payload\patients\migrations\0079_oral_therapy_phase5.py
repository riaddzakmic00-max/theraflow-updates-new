import django.core.validators
import django.db.models.deletion
import django.utils.timezone
import uuid
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0078_ustekinumab_phased_protocol"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AddField(
            model_name="lijek",
            name="broj_tableta_u_pakovanju",
            field=models.PositiveIntegerField(
                blank=True,
                null=True,
                validators=[django.core.validators.MinValueValidator(1)],
                verbose_name="Broj tableta u pakovanju",
            ),
        ),
        migrations.AddField(
            model_name="lijek",
            name="farmaceutski_oblik",
            field=models.CharField(
                blank=True,
                choices=[("TABLETA", "Tableta")],
                max_length=20,
                verbose_name="Farmaceutski oblik",
            ),
        ),
        migrations.AddField(
            model_name="lijek",
            name="izdavanje_cijelih_pakovanja",
            field=models.BooleanField(
                default=False,
                verbose_name="Izdavanje samo cijelih pakovanja",
            ),
        ),
        migrations.AlterField(
            model_name="lijek",
            name="nacin_primjene",
            field=models.CharField(
                choices=[
                    ("AMBULANTA", "Ambulanta"),
                    ("KUCNA_TERAPIJA", "Kućna terapija"),
                    ("ORALNA_TERAPIJA", "Oralna terapija"),
                ],
                default="AMBULANTA",
                max_length=20,
            ),
        ),
        migrations.AlterField(
            model_name="lijek",
            name="put_primjene",
            field=models.CharField(
                blank=True,
                choices=[
                    ("IV", "Intravenozno (IV)"),
                    ("SC", "Supkutano (SC)"),
                    ("PO", "Peroralno (PO)"),
                ],
                max_length=8,
                verbose_name="Put primjene",
            ),
        ),
        migrations.AlterField(
            model_name="zalihatransakcija",
            name="tip",
            field=models.CharField(
                choices=[
                    ("ZAPRIMANJE", "Zaprimanje"),
                    ("AMBULANTNA_POTROSNJA", "Ambulantna potrosnja"),
                    ("KUCNO_IZDAVANJE", "Kucno izdavanje"),
                    ("ORALNO_IZDAVANJE", "Oralno izdavanje"),
                    ("POVRAT", "Povrat"),
                    ("OTPIS", "Otpis"),
                    ("KOREKCIJA", "Korekcija"),
                    ("POCETNO_STANJE_MIGRACIJE", "Početno stanje migracije"),
                    ("RELEASE_TO_FREE_STOCK", "Oslobađanje u slobodnu zalihu"),
                    ("ASSIGN_FREE_STOCK_TO_PATIENT", "Dodjela slobodne zalihe pacijentu"),
                ],
                max_length=30,
            ),
        ),
        migrations.CreateModel(
            name="OralniTerapijskiRezim",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "tableta_po_uzimanju",
                    models.DecimalField(decimal_places=2, max_digits=6),
                ),
                ("uzimanja_dnevno", models.PositiveSmallIntegerField()),
                (
                    "datum_od",
                    models.DateField(default=django.utils.timezone.localdate),
                ),
                ("datum_do", models.DateField(blank=True, null=True)),
                (
                    "faza",
                    models.CharField(
                        choices=[
                            ("INDUKCIJA", "Indukcija"),
                            ("ODRZAVANJE", "Održavanje"),
                            ("PRILAGODJENO", "Prilagođeno"),
                        ],
                        default="ODRZAVANJE",
                        max_length=20,
                    ),
                ),
                ("napomena_ljekara", models.TextField(blank=True)),
                ("aktivan", models.BooleanField(default=True)),
                ("kreirano", models.DateTimeField(auto_now_add=True)),
                ("izmijenjeno", models.DateTimeField(auto_now=True)),
                (
                    "lijek",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="oralni_rezimi",
                        to="patients.lijek",
                    ),
                ),
                (
                    "pacijent",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="oralni_rezimi",
                        to="patients.pacijent",
                    ),
                ),
                (
                    "potvrdio",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="potvrdjeni_oralni_rezimi",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={"ordering": ["-datum_od", "-id"]},
        ),
        migrations.CreateModel(
            name="IzdavanjeOralneTerapije",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "kolicina_tableta",
                    models.PositiveIntegerField(
                        validators=[django.core.validators.MinValueValidator(1)]
                    ),
                ),
                (
                    "datum_izdavanja",
                    models.DateField(default=django.utils.timezone.localdate),
                ),
                ("pokrivenost_od", models.DateField()),
                ("pokrivenost_do", models.DateField(blank=True, null=True)),
                ("sljedeci_nepokriveni_datum", models.DateField()),
                (
                    "pokrivenost_dana",
                    models.DecimalField(decimal_places=4, max_digits=10),
                ),
                (
                    "jacina_mg_snapshot",
                    models.DecimalField(
                        blank=True,
                        decimal_places=2,
                        max_digits=8,
                        null=True,
                    ),
                ),
                (
                    "tableta_po_uzimanju_snapshot",
                    models.DecimalField(decimal_places=2, max_digits=6),
                ),
                ("uzimanja_dnevno_snapshot", models.PositiveSmallIntegerField()),
                (
                    "tableta_dnevno_snapshot",
                    models.DecimalField(decimal_places=2, max_digits=8),
                ),
                ("faza_snapshot", models.CharField(blank=True, max_length=20)),
                (
                    "broj_saglasnosti_snapshot",
                    models.CharField(blank=True, max_length=100),
                ),
                (
                    "odobreno_preostalo_prije",
                    models.DecimalField(decimal_places=2, max_digits=10),
                ),
                (
                    "odobreno_preostalo_poslije",
                    models.DecimalField(decimal_places=2, max_digits=10),
                ),
                ("serija", models.CharField(blank=True, max_length=100)),
                ("napomena", models.TextField(blank=True)),
                (
                    "status",
                    models.CharField(
                        choices=[("AKTIVNO", "Aktivno"), ("PONISTENO", "Poništeno")],
                        default="AKTIVNO",
                        max_length=20,
                    ),
                ),
                (
                    "idempotency_key",
                    models.UUIDField(default=uuid.uuid4, unique=True),
                ),
                ("ponisteno_at", models.DateTimeField(blank=True, null=True)),
                ("razlog_ponistavanja", models.TextField(blank=True)),
                ("kreirano", models.DateTimeField(auto_now_add=True)),
                (
                    "komisija",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="oralna_izdavanja",
                        to="patients.komisija",
                    ),
                ),
                (
                    "komisijska_stavka",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="oralna_izdavanja",
                        to="patients.komisijskastavkalijeka",
                    ),
                ),
                (
                    "korisnik_koji_je_izdao",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="izdata_oralna_terapija",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "lijek",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="oralna_izdavanja",
                        to="patients.lijek",
                    ),
                ),
                (
                    "pacijent",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="oralna_izdavanja",
                        to="patients.pacijent",
                    ),
                ),
                (
                    "pacijent_zaduzenje",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="oralna_izdavanja",
                        to="patients.pacijentzaduzenje",
                    ),
                ),
                (
                    "ponistio",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="ponistena_oralna_izdavanja",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "rezim",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="izdavanja",
                        to="patients.oralniterapijskirezim",
                    ),
                ),
            ],
            options={
                "verbose_name": "Izdavanje oralne terapije",
                "verbose_name_plural": "Izdavanja oralne terapije",
                "ordering": ["-datum_izdavanja", "-id"],
            },
        ),
        migrations.AddIndex(
            model_name="oralniterapijskirezim",
            index=models.Index(
                fields=["pacijent", "aktivan", "datum_od"],
                name="oral_reg_patient_active_idx",
            ),
        ),
        migrations.AddConstraint(
            model_name="oralniterapijskirezim",
            constraint=models.CheckConstraint(
                condition=models.Q(tableta_po_uzimanju__gt=0),
                name="oral_regimen_tablets_gt0",
            ),
        ),
        migrations.AddConstraint(
            model_name="oralniterapijskirezim",
            constraint=models.CheckConstraint(
                condition=models.Q(uzimanja_dnevno__gt=0),
                name="oral_regimen_intakes_gt0",
            ),
        ),
        migrations.AddConstraint(
            model_name="oralniterapijskirezim",
            constraint=models.CheckConstraint(
                condition=(
                    models.Q(datum_do__isnull=True)
                    | models.Q(datum_do__gte=models.F("datum_od"))
                ),
                name="oral_regimen_dates_valid",
            ),
        ),
        migrations.AddConstraint(
            model_name="oralniterapijskirezim",
            constraint=models.UniqueConstraint(
                condition=models.Q(aktivan=True),
                fields=("pacijent",),
                name="uniq_active_oral_regimen_patient",
            ),
        ),
        migrations.AddIndex(
            model_name="izdavanjeoralneterapije",
            index=models.Index(
                fields=["pacijent", "lijek", "status", "datum_izdavanja"],
                name="oral_issue_patient_drug_idx",
            ),
        ),
        migrations.AddConstraint(
            model_name="izdavanjeoralneterapije",
            constraint=models.CheckConstraint(
                condition=models.Q(kolicina_tableta__gt=0),
                name="oral_issue_quantity_gt0",
            ),
        ),
        migrations.AddConstraint(
            model_name="izdavanjeoralneterapije",
            constraint=models.CheckConstraint(
                condition=models.Q(tableta_dnevno_snapshot__gt=0),
                name="oral_issue_daily_gt0",
            ),
        ),
        migrations.AddConstraint(
            model_name="izdavanjeoralneterapije",
            constraint=models.CheckConstraint(
                condition=models.Q(pokrivenost_dana__gt=0),
                name="oral_issue_coverage_gt0",
            ),
        ),
        migrations.AddConstraint(
            model_name="izdavanjeoralneterapije",
            constraint=models.CheckConstraint(
                condition=models.Q(
                    sljedeci_nepokriveni_datum__gte=models.F("pokrivenost_od")
                ),
                name="oral_issue_next_date_valid",
            ),
        ),
        migrations.AddConstraint(
            model_name="izdavanjeoralneterapije",
            constraint=models.CheckConstraint(
                condition=(
                    (
                        models.Q(komisija__isnull=False)
                        & models.Q(komisijska_stavka__isnull=True)
                    )
                    | (
                        models.Q(komisija__isnull=True)
                        & models.Q(komisijska_stavka__isnull=False)
                    )
                ),
                name="oral_issue_one_approval_source",
            ),
        ),
    ]
