from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0064_pacijent_broj_kartona"),
    ]

    operations = [
        migrations.CreateModel(
            name="MigracijskoPocetnoStanjeZalihe",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "kolicina",
                    models.DecimalField(decimal_places=2, default=0, max_digits=8),
                ),
                ("kreirano", models.DateTimeField(auto_now_add=True)),
                ("izmijenjeno", models.DateTimeField(auto_now=True)),
                (
                    "izmijenio",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="izmijenjena_migracijska_stanja_zalihe",
                        to="auth.user",
                    ),
                ),
                (
                    "kreirao",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="kreirana_migracijska_stanja_zalihe",
                        to="auth.user",
                    ),
                ),
                (
                    "lijek",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="migracijsko_pocetno_stanje",
                        to="patients.lijek",
                    ),
                ),
            ],
            options={
                "verbose_name": "Migracijsko početno stanje zalihe",
                "verbose_name_plural": "Migracijska početna stanja zaliha",
            },
        ),
        migrations.AddField(
            model_name="pacijentrezervacija",
            name="migracijski_snapshot",
            field=models.OneToOneField(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="rezervacija_fizicke_zalihe",
                to="patients.migracijskisnapshotpacijenta",
            ),
        ),
        migrations.AddConstraint(
            model_name="migracijskopocetnostanjezalihe",
            constraint=models.CheckConstraint(
                condition=models.Q(("kolicina__gte", 0)),
                name="migracijsko_stanje_zalihe_gte_0",
            ),
        ),
    ]
