import glob
import json
import logging
import os
import shutil
import subprocess
import threading
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from django.conf import settings
from django.db import connections
from django.utils import timezone


BACKUP_DIR = Path(settings.THERAFLOW_BACKUP_DIR)
BACKUP_KEEP_COUNT = 30
AUTO_BACKUP_PREFIX = "theraflow_auto_backup"
MANUAL_BACKUP_PREFIX = "theraflow_backup"
MANUAL_TEST_BACKUP_PREFIX = "theraflow_manual_test"
TRIGGER_SCHEDULED = "SCHEDULED"
TRIGGER_CATCH_UP = "CATCH_UP"
TRIGGER_MANUAL = "MANUAL"
TRIGGER_MANUAL_TEST = "MANUAL_TEST"
TRIGGER_SYSTEM = "SYSTEM"
logger = logging.getLogger(__name__)
_state_lock = threading.RLock()


class BackupError(Exception):
    pass


class BackupBusyError(BackupError):
    pass


@dataclass
class BackupInfo:
    name: str
    path: Path
    size: int
    modified_at: object


def _configured_path(setting_name, default):
    return Path(getattr(settings, setting_name, default)).expanduser().resolve()


def backup_log_path():
    return _configured_path(
        "THERAFLOW_BACKUP_LOG",
        Path(getattr(settings, "BASE_DIR", Path.cwd())) / "logs" / "backup.log",
    )


def scheduler_log_path():
    return _configured_path(
        "THERAFLOW_BACKUP_SCHEDULER_LOG",
        backup_log_path().with_name("backup_scheduler.log"),
    )


def backup_state_path():
    data_dir = Path(getattr(settings, "THERAFLOW_DATA_DIR", Path.cwd() / "data"))
    return _configured_path(
        "THERAFLOW_BACKUP_STATE",
        data_dir / "backup_scheduler_state.json",
    )


def backup_lock_path():
    data_dir = Path(getattr(settings, "THERAFLOW_DATA_DIR", Path.cwd() / "data"))
    return _configured_path(
        "THERAFLOW_BACKUP_LOCK",
        data_dir / "backup_execution.lock",
    )


def scheduler_lock_path():
    data_dir = Path(getattr(settings, "THERAFLOW_DATA_DIR", Path.cwd() / "data"))
    return _configured_path(
        "THERAFLOW_BACKUP_SCHEDULER_LOCK",
        data_dir / "backup_scheduler.lock",
    )


def ensure_backup_dir():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    return BACKUP_DIR


def postgres_settings():
    database = settings.DATABASES["default"]
    engine = database.get("ENGINE", "")
    if "postgresql" not in engine:
        raise BackupError("Backup je podešen za PostgreSQL bazu.")
    return database


def _detected_mode():
    if getattr(settings, "PRODUCTION_MODE", False):
        return "installed"

    base_dir = Path(getattr(settings, "BASE_DIR", Path.cwd())).resolve()
    normalized = str(base_dir).replace("/", "\\").lower()
    if "\\program files\\theraflow\\app" in normalized:
        return "installed"
    return "development"


def _bundled_tool_path(name):
    bundled_bin = getattr(settings, "THERAFLOW_POSTGRES_BIN", None)
    if bundled_bin:
        return Path(bundled_bin).expanduser().resolve() / f"{name}.exe"

    base_dir = Path(getattr(settings, "BASE_DIR", Path.cwd())).resolve()
    return base_dir.parent / "runtime" / "postgresql" / "bin" / f"{name}.exe"


def _postgres_version_key(path):
    try:
        version = Path(path).parents[1].name
        return tuple(int(part) for part in version.split("."))
    except (IndexError, TypeError, ValueError):
        return (0,)


def _standard_postgres_tools(name):
    program_files = Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
    pattern = str(program_files / "PostgreSQL" / "*" / "bin" / f"{name}.exe")
    matches = [Path(path).resolve() for path in glob.glob(pattern) if Path(path).is_file()]
    return sorted(matches, key=_postgres_version_key, reverse=True)


def resolve_postgres_tool_path(name):
    mode = _detected_mode()
    bundled = _bundled_tool_path(name)
    logger.info(
        "PostgreSQL alat pretraga: detected_mode=%s bundled_path=%s",
        mode,
        bundled,
    )

    if mode == "installed" and bundled.is_file():
        selected = str(bundled)
        logger.info(
            "PostgreSQL alat pronađen: discovered_path=%s selected_path=%s source=bundled",
            bundled,
            selected,
        )
        return selected

    if mode == "installed":
        logger.warning("Bundled PostgreSQL alat ne postoji: %s", bundled)
    else:
        logger.info("Development mode: koristi se automatska pretraga PostgreSQL alata.")

    standard_matches = _standard_postgres_tools(name)
    for discovered in standard_matches:
        logger.info("PostgreSQL alat pronađen u standardnoj lokaciji: discovered_path=%s", discovered)
    if standard_matches:
        selected = str(standard_matches[0])
        logger.info("PostgreSQL alat odabran: selected_path=%s source=standard_location", selected)
        return selected

    path_match = shutil.which(f"{name}.exe") or shutil.which(name)
    logger.info("PostgreSQL PATH pretraga: discovered_path=%s", path_match or "NONE")
    if path_match:
        selected = str(Path(path_match).resolve())
        logger.info("PostgreSQL alat odabran: selected_path=%s source=PATH", selected)
        return selected

    reason = (
        f"PostgreSQL alat {name} nije pronađen: bundled={bundled}; "
        r"standardne lokacije=C:\Program Files\PostgreSQL\*\bin; PATH=nema rezultata."
    )
    logger.error(
        "PostgreSQL alat nije pronađen: detected_mode=%s bundled_path=%s "
        "discovered_path=NONE selected_path=NONE reason=%s",
        mode,
        bundled,
        reason,
    )
    raise BackupError(reason)


def resolve_pg_dump_path():
    return resolve_postgres_tool_path("pg_dump")


def executable_path(name):
    pg_dump_path = Path(resolve_pg_dump_path())
    if name == "pg_dump":
        return str(pg_dump_path)

    sibling = pg_dump_path.with_name(f"{name}.exe")
    if sibling.is_file():
        logger.info(
            "PostgreSQL alat odabran uz pg_dump: discovered_path=%s selected_path=%s",
            sibling,
            sibling,
        )
        return str(sibling)
    return resolve_postgres_tool_path(name)


def backup_environment(database):
    env = os.environ.copy()
    password = database.get("PASSWORD") or ""
    if password:
        env["PGPASSWORD"] = password
    return env


def timestamp():
    return _backup_localtime(timezone.now()).strftime("%Y-%m-%d_%H-%M-%S")


def _backup_timezone():
    return ZoneInfo(
        getattr(settings, "THERAFLOW_BACKUP_TIME_ZONE", "Europe/Sarajevo")
    )


def _backup_localtime(value):
    if timezone.is_naive(value):
        value = timezone.make_aware(value, _backup_timezone())
    return value.astimezone(_backup_timezone())


def _safe_command_detail(result, database):
    detail = (result.stderr or result.stdout or "").strip()
    password = str(database.get("PASSWORD") or "")
    if password:
        detail = detail.replace(password, "[REDACTED]")
    return detail


def run_command(command, database, timeout=300):
    try:
        result = subprocess.run(
            command,
            env=backup_environment(database),
            capture_output=True,
            text=True,
            check=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        raise BackupError("PostgreSQL backup komanda je prekoračila dozvoljeno vrijeme.") from exc
    if result.returncode != 0:
        detail = _safe_command_detail(result, database)
        raise BackupError(detail or "PostgreSQL backup komanda nije uspjela.")
    return result


def _iso_now():
    return timezone.now().isoformat()


def _read_state_unlocked():
    path = backup_state_path()
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        logger.warning("Backup scheduler state nije čitljiv: %s", path)
        return {}
    return value if isinstance(value, dict) else {}


def read_backup_state():
    with _state_lock:
        return _read_state_unlocked()


def update_backup_state(**changes):
    with _state_lock:
        state = _read_state_unlocked()
        state.update(changes)
        state["updated_at"] = _iso_now()
        destination = backup_state_path()
        temporary = destination.with_name(f"{destination.name}.{uuid.uuid4().hex}.tmp")
        try:
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary.write_text(
                json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True),
                encoding="utf-8",
            )
            os.replace(temporary, destination)
        except OSError:
            logger.exception("Backup scheduler state nije moguće zapisati: %s", destination)
            temporary.unlink(missing_ok=True)
        return state


def _append_backup_log(event, **details):
    database = {}
    try:
        database = postgres_settings()
    except BackupError:
        pass
    record = {
        "time": _iso_now(),
        "event": event,
        "database": database.get("NAME", ""),
        "host": database.get("HOST") or "localhost",
        "port": str(database.get("PORT") or "5432"),
        "user": database.get("USER", ""),
        **details,
    }
    path = backup_log_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
        return True
    except OSError:
        logger.exception("Stabilni backup log nije moguće zapisati: %s", path)
        return False


def append_scheduler_log(event, **details):
    record = {
        "time": _iso_now(),
        "event": event,
        **details,
    }
    path = scheduler_log_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
        return True
    except OSError:
        logger.exception("Scheduler log nije moguće zapisati: %s", path)
        return False


class FileLease:
    def __init__(self, path, stale_after_seconds):
        self.path = Path(path).resolve()
        self.stale_after_seconds = stale_after_seconds
        self.token = uuid.uuid4().hex
        self.acquired = False

    def acquire(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        for attempt in range(2):
            try:
                descriptor = os.open(
                    str(self.path),
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                )
            except FileExistsError as exc:
                try:
                    age = timezone.now().timestamp() - self.path.stat().st_mtime
                except OSError:
                    age = 0
                if attempt == 0 and age > self.stale_after_seconds:
                    self.path.unlink(missing_ok=True)
                    continue
                raise BackupBusyError("Drugi backup proces je već aktivan.") from exc
            else:
                with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                    json.dump(
                        {"pid": os.getpid(), "token": self.token, "created_at": _iso_now()},
                        stream,
                    )
                self.acquired = True
                return self
        raise BackupBusyError("Drugi backup proces je već aktivan.")

    def touch(self):
        if self.acquired and self.path.exists():
            os.utime(self.path, None)

    def release(self):
        if not self.acquired:
            return
        try:
            owner = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            owner = {}
        if owner.get("token") == self.token:
            self.path.unlink(missing_ok=True)
        self.acquired = False

    def __enter__(self):
        return self.acquire()

    def __exit__(self, exc_type, exc_value, traceback):
        self.release()


@contextmanager
def backup_execution_lease():
    with FileLease(
        backup_lock_path(),
        int(getattr(settings, "THERAFLOW_BACKUP_LOCK_STALE_SECONDS", 7200)),
    ) as lease:
        yield lease


def create_postgres_backup_at(output_path, timeout=300):
    output_path = Path(output_path).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    database = postgres_settings()
    pg_dump = executable_path("pg_dump")
    command = [
        pg_dump,
        "--format=custom",
        "--file",
        str(output_path),
        "--dbname",
        database.get("NAME", ""),
        "--host",
        database.get("HOST") or "localhost",
        "--port",
        str(database.get("PORT") or "5432"),
        "--username",
        database.get("USER", ""),
        "--no-password",
    ]
    try:
        run_command(command, database, timeout=timeout)
        if not output_path.is_file() or output_path.stat().st_size == 0:
            raise BackupError("pg_dump nije kreirao ispravan database dump.")
        with output_path.open("rb") as stream:
            if not stream.read(1):
                raise BackupError("pg_dump je kreirao nečitljiv database dump.")
        return output_path
    except Exception:
        if output_path.exists() and output_path.stat().st_size == 0:
            output_path.unlink(missing_ok=True)
        raise


def validate_postgres_backup(backup_path, timeout=120):
    backup_path = Path(backup_path).resolve()
    if not backup_path.is_file() or backup_path.stat().st_size == 0:
        raise BackupError("Database dump ne postoji ili je prazan.")
    try:
        with backup_path.open("rb") as stream:
            if not stream.read(1):
                raise BackupError("Database dump nije čitljiv.")
    except OSError as exc:
        raise BackupError("Database dump nije čitljiv.") from exc
    database = postgres_settings()
    pg_restore = executable_path("pg_restore")
    result = run_command([pg_restore, "--list", str(backup_path)], database, timeout=timeout)
    entries = [line for line in result.stdout.splitlines() if line.strip() and not line.lstrip().startswith(";")]
    expected = ("TABLE", "SCHEMA", "SEQUENCE", "FUNCTION", "TYPE", "DATABASE")
    if not entries or not any(any(marker in line.upper() for marker in expected) for line in entries):
        raise BackupError("pg_restore nije pronašao očekivane PostgreSQL objekte u dumpu.")
    return True


def _backup_kind(prefix):
    if prefix == AUTO_BACKUP_PREFIX:
        return "automatic"
    if prefix == MANUAL_TEST_BACKUP_PREFIX:
        return "manual_test"
    if prefix == MANUAL_BACKUP_PREFIX or prefix.startswith("theraflow_manual"):
        return "manual"
    return "system"


def _trigger_for_prefix(prefix):
    if prefix == AUTO_BACKUP_PREFIX:
        return TRIGGER_SCHEDULED
    if prefix == MANUAL_TEST_BACKUP_PREFIX:
        return TRIGGER_MANUAL_TEST
    if prefix == MANUAL_BACKUP_PREFIX or prefix.startswith("theraflow_manual"):
        return TRIGGER_MANUAL
    return TRIGGER_SYSTEM


def _unique_output_path(backup_dir, prefix):
    base = backup_dir / f"{prefix}_{timestamp()}.backup"
    if not base.exists() and not base.with_name(f"{base.name}.partial").exists():
        return base
    for suffix in range(1, 1000):
        candidate = base.with_name(f"{base.stem}_{suffix}{base.suffix}")
        if not candidate.exists() and not candidate.with_name(f"{candidate.name}.partial").exists():
            return candidate
    raise BackupError("Nije moguće kreirati jedinstven naziv backup fajla.")


def create_postgres_backup(prefix=MANUAL_BACKUP_PREFIX, prune=True, trigger_type=None):
    backup_dir = ensure_backup_dir()
    output_path = _unique_output_path(backup_dir, prefix)
    partial_path = output_path.with_name(f"{output_path.name}.partial")
    kind = _backup_kind(prefix)
    trigger_type = trigger_type or _trigger_for_prefix(prefix)
    started_at = _iso_now()
    attempt = {
        "kind": kind,
        "trigger_type": trigger_type,
        "result": "running",
        "started_at": started_at,
        "finished_at": None,
        "path": str(output_path),
        "size": 0,
        "error": "",
    }
    state_key = {
        TRIGGER_SCHEDULED: "last_scheduled_attempt",
        TRIGGER_CATCH_UP: "last_scheduled_attempt",
        TRIGGER_MANUAL_TEST: "last_manual_test_attempt",
        TRIGGER_MANUAL: "last_manual_attempt",
    }.get(trigger_type, "last_system_attempt")
    update_backup_state(last_attempt=attempt, **{state_key: attempt})
    pg_dump = ""

    try:
        pg_dump = executable_path("pg_dump")
        _append_backup_log(
            "backup_started",
            kind=kind,
            trigger_type=trigger_type,
            path=str(output_path),
            pg_dump=pg_dump,
        )
        with backup_execution_lease():
            create_postgres_backup_at(partial_path)
            validate_postgres_backup(partial_path)
            os.replace(partial_path, output_path)
            size = output_path.stat().st_size
            with output_path.open("rb") as stream:
                if size <= 0 or not stream.read(1):
                    raise BackupError("Validirani backup nije dostupan na konačnoj putanji.")
    except Exception as exc:
        partial_path.unlink(missing_ok=True)
        safe_error = str(exc) if isinstance(exc, BackupError) else type(exc).__name__
        attempt.update(
            result="failed",
            finished_at=_iso_now(),
            error=safe_error,
        )
        update_backup_state(last_attempt=attempt, **{state_key: attempt})
        _append_backup_log(
            "backup_failed",
            kind=kind,
            trigger_type=trigger_type,
            path=str(output_path),
            result="failed",
            error=safe_error,
            pg_dump=pg_dump,
            started_at=started_at,
            finished_at=attempt["finished_at"],
        )
        if isinstance(exc, BackupError):
            raise
        raise BackupError("Automatski backup nije uspješno završen.") from exc

    attempt.update(
        result="success",
        finished_at=_iso_now(),
        size=size,
        error="",
    )
    state_update = {"last_attempt": attempt, state_key: attempt}
    if trigger_type in {TRIGGER_SCHEDULED, TRIGGER_CATCH_UP}:
        state_update["last_scheduled_success"] = attempt
        # Kompatibilnost za starije čitaoce state fajla.
        state_update["last_automatic_success"] = attempt
    elif trigger_type == TRIGGER_MANUAL_TEST:
        state_update["last_manual_test_success"] = attempt
    elif trigger_type == TRIGGER_MANUAL:
        state_update["last_manual_success"] = attempt
    update_backup_state(**state_update)
    evidence_recorded = _append_backup_log(
        "backup_succeeded",
        kind=kind,
        trigger_type=trigger_type,
        path=str(output_path),
        result="success",
        size=size,
        pg_dump=pg_dump,
        started_at=started_at,
        finished_at=attempt["finished_at"],
        validated_with="pg_restore --list",
    )
    # Retencija se izvršava tek nakon kreiranja, validacije i trajne evidencije
    # uspjeha. Neuspjeh retencije ne pretvara validan novi backup u neuspješan.
    if prune and evidence_recorded:
        try:
            prune_old_backups()
        except OSError as exc:
            logger.exception("Retencija backup fajlova nije završena.")
            _append_backup_log(
                "backup_retention_failed",
                kind=kind,
                trigger_type=trigger_type,
                path=str(output_path),
                result="failed",
                error=type(exc).__name__,
            )
    return output_path


def list_postgres_backups():
    backup_dir = ensure_backup_dir()
    backups = []
    for path in backup_dir.iterdir():
        if path.is_file() and path.suffix in [".backup", ".sql"]:
            stat = path.stat()
            backups.append(
                BackupInfo(
                    name=path.name,
                    path=path,
                    size=stat.st_size,
                    modified_at=timezone.datetime.fromtimestamp(
                        stat.st_mtime,
                        tz=timezone.get_current_timezone(),
                    ),
                )
            )
    return sorted(backups, key=lambda item: item.modified_at, reverse=True)


def prune_old_backups(keep_count=BACKUP_KEEP_COUNT):
    backups = list_postgres_backups()
    for backup in backups[keep_count:]:
        backup.path.unlink(missing_ok=True)


def _latest_backup(prefixes):
    return next(
        (
            backup
            for backup in list_postgres_backups()
            if any(backup.name.startswith(prefix) for prefix in prefixes)
        ),
        None,
    )


def latest_automatic_backup():
    return _latest_backup((f"{AUTO_BACKUP_PREFIX}_",))


def latest_manual_test_backup():
    return _latest_backup((f"{MANUAL_TEST_BACKUP_PREFIX}_",))


def latest_manual_backup():
    return _latest_backup(
        (
            f"{MANUAL_BACKUP_PREFIX}_",
            "theraflow_manual_",
        )
    )


def _successful_scheduled_record(state=None):
    state = state or read_backup_state()
    record = state.get("last_scheduled_success")
    if (
        not isinstance(record, dict)
        or record.get("trigger_type") not in {TRIGGER_SCHEDULED, TRIGGER_CATCH_UP}
    ):
        return {}
    if record.get("result") != "success":
        return {}
    path = Path(record.get("path") or "")
    if not path.is_file() or path.stat().st_size <= 0:
        return {}
    return record


def last_scheduled_success_at(state=None):
    record = _successful_scheduled_record(state)
    return _parse_datetime(record.get("finished_at")) if record else None


def has_backup_for_today(now=None):
    """Samo dokazani SCHEDULED backup zadovoljava dnevni termin."""
    now = _backup_localtime(now or timezone.now())
    completed_at = last_scheduled_success_at()
    return bool(
        completed_at
        and _backup_localtime(completed_at).date() == now.date()
    )


def _scheduled_time_for(day):
    return day.replace(
        hour=int(getattr(settings, "THERAFLOW_BACKUP_HOUR", 4)),
        minute=int(getattr(settings, "THERAFLOW_BACKUP_MINUTE", 0)),
        second=0,
        microsecond=0,
    )


def automatic_backup_due(now=None):
    now = _backup_localtime(now or timezone.now())
    scheduled_for_today = _scheduled_time_for(now)
    if now < scheduled_for_today:
        return False
    completed_at = last_scheduled_success_at()
    return not completed_at or _backup_localtime(completed_at) < scheduled_for_today


def run_automatic_backup(force=False, prune=True, trigger_type=TRIGGER_SCHEDULED):
    if not force and not automatic_backup_due():
        return None
    if trigger_type not in {TRIGGER_SCHEDULED, TRIGGER_CATCH_UP}:
        raise ValueError("Automatski backup mora imati SCHEDULED ili CATCH_UP trigger.")
    return create_postgres_backup(
        prefix=AUTO_BACKUP_PREFIX,
        prune=prune,
        trigger_type=trigger_type,
    )


def ensure_daily_backup(trigger_type=TRIGGER_SCHEDULED):
    return run_automatic_backup(trigger_type=trigger_type)


def run_manual_backup_test(prune=True):
    """Testira cijeli backup tok bez predstavljanja schedulera kao aktivnog."""
    return create_postgres_backup(
        prefix=MANUAL_TEST_BACKUP_PREFIX,
        prune=prune,
        trigger_type=TRIGGER_MANUAL_TEST,
    )


def next_automatic_backup(now=None):
    now = _backup_localtime(now or timezone.now())
    if automatic_backup_due(now):
        return now
    today_schedule = _scheduled_time_for(now)
    if now < today_schedule:
        return today_schedule
    return today_schedule + timedelta(days=1)


def _parse_datetime(value):
    if not value:
        return None
    try:
        parsed = timezone.datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None
    if timezone.is_naive(parsed):
        parsed = timezone.make_aware(parsed, timezone.get_current_timezone())
    return parsed


def automatic_backup_status(now=None, process_inspector=None, service_inspector=None):
    from dashboard.scheduler_health import (
        HEALTH_ACTIVE_LOCAL,
        HEALTH_ACTIVE_SERVICE,
        HEALTH_INACTIVE,
        HEALTH_SERVICE_HEARTBEAT_LATE,
        scheduler_health,
    )

    now = _backup_localtime(now or timezone.now())
    latest_auto_file = latest_automatic_backup()
    latest_manual = latest_manual_backup()
    latest_manual_test = latest_manual_test_backup()
    state = read_backup_state()
    scheduler = state.get("scheduler") if isinstance(state.get("scheduler"), dict) else {}
    health_kwargs = {"now": now}
    if process_inspector is not None:
        health_kwargs["process_inspector"] = process_inspector
    if service_inspector is not None:
        health_kwargs["service_inspector"] = service_inspector
    health = scheduler_health(scheduler, **health_kwargs)
    heartbeat = health["heartbeat"]
    heartbeat_limit = health["heartbeat_limit_seconds"]
    scheduler_running = health["active"]
    scheduled_record = _successful_scheduled_record(state)
    scheduled_success_at = (
        _parse_datetime(scheduled_record.get("finished_at"))
        if scheduled_record
        else None
    )
    auto_age_hours = None
    if scheduled_success_at:
        auto_age_hours = max(
            0,
            (now - _backup_localtime(scheduled_success_at)).total_seconds() / 3600,
        )
    backup_fresh = auto_age_hours is not None and auto_age_hours <= 26
    late = not backup_fresh
    last_attempt = (
        state.get("last_scheduled_attempt")
        if isinstance(state.get("last_scheduled_attempt"), dict)
        else {}
    )
    last_attempt_finished = _parse_datetime(last_attempt.get("finished_at"))
    failed_after_last_success = bool(
        last_attempt.get("trigger_type") in {TRIGGER_SCHEDULED, TRIGGER_CATCH_UP}
        and last_attempt.get("result") == "failed"
        and (
            scheduled_success_at is None
            or (
                last_attempt_finished
                and _backup_localtime(last_attempt_finished)
                > _backup_localtime(scheduled_success_at)
            )
        )
    )
    if failed_after_last_success:
        status_code = "failed"
        status_label = "Planirani backup nije uspio"
    elif backup_fresh and scheduler_running:
        status_code = "ok"
        status_label = "Automatski backup uredan"
    elif backup_fresh:
        status_code = "warning"
        status_label = "Backup postoji, scheduler nije aktivan"
    elif scheduler_running:
        status_code = "warning"
        status_label = "Scheduler aktivan, backup kasni"
    else:
        status_code = "failed"
        status_label = "Automatski backup nije zaštićen"

    trigger_labels = {
        TRIGGER_SCHEDULED: "Zakazano",
        TRIGGER_CATCH_UP: "Catch-up nakon pokretanja",
        TRIGGER_MANUAL_TEST: "Ručni test",
        TRIGGER_MANUAL: "Ručni backup",
        TRIGGER_SYSTEM: "Sistemski",
    }
    execution_records = [
        record
        for record in (
            state.get("last_scheduled_success"),
            state.get("last_manual_test_success"),
            state.get("last_manual_success"),
        )
        if isinstance(record, dict) and record.get("result") == "success"
    ]
    latest_execution = max(
        execution_records,
        key=lambda item: _parse_datetime(item.get("finished_at"))
        or timezone.datetime.min.replace(tzinfo=ZoneInfo("UTC")),
        default={},
    )
    latest_execution_at = _parse_datetime(latest_execution.get("finished_at"))

    next_run = next_automatic_backup(now)
    return {
        "status_code": status_code,
        "status_label": status_label,
        "late": late,
        "backup_fresh": backup_fresh,
        "last_automatic": latest_auto_file if scheduled_record else None,
        "last_automatic_file": latest_auto_file,
        "last_scheduled_record": scheduled_record,
        "last_scheduled_at": scheduled_success_at,
        "last_scheduled_trigger_label": trigger_labels.get(
            scheduled_record.get("trigger_type"),
            "Nepoznato",
        ),
        "last_manual": latest_manual,
        "last_manual_test": latest_manual_test,
        "last_manual_attempt": (
            state.get("last_manual_attempt")
            if isinstance(state.get("last_manual_attempt"), dict)
            else {}
        ),
        "last_manual_test_attempt": (
            state.get("last_manual_test_attempt")
            if isinstance(state.get("last_manual_test_attempt"), dict)
            else {}
        ),
        "last_attempt": last_attempt,
        "next_run": next_run,
        "next_run_is_catchup": automatic_backup_due(now),
        "next_run_reliable": scheduler_running,
        "scheduler_running": scheduler_running,
        "scheduler_label": health["label"],
        "scheduler_health": health,
        "scheduler_health_message": health["message"],
        "heartbeat_at": heartbeat,
        "heartbeat_age_seconds": health["heartbeat_age_seconds"],
        "heartbeat_fresh_seconds": heartbeat_limit,
        "scheduler": scheduler,
        "process": health["process"],
        "windows_service": health["service"],
        "last_execution": latest_execution,
        "last_execution_at": latest_execution_at,
        "last_execution_trigger": latest_execution.get("trigger_type"),
        "last_execution_trigger_label": trigger_labels.get(
            latest_execution.get("trigger_type"),
            "Nepoznato",
        ),
        "last_scheduler_error": scheduler.get("last_scheduled_error") or (
            last_attempt.get("error")
            if last_attempt.get("result") == "failed"
            else ""
        ),
        "log_path": backup_log_path(),
        "scheduler_log_path": scheduler_log_path(),
        "state_path": backup_state_path(),
        "service_name": getattr(
            settings,
            "THERAFLOW_BACKUP_SCHEDULER_SERVICE_NAME",
            "TheraFlowBackupScheduler",
        ),
        "schedule_timezone": getattr(
            settings,
            "THERAFLOW_BACKUP_TIME_ZONE",
            "Europe/Sarajevo",
        ),
    }


def safe_backup_path(filename):
    if not filename:
        raise BackupError("Backup fajl nije odabran.")
    backup_dir = ensure_backup_dir().resolve()
    path = (backup_dir / filename).resolve()
    if backup_dir not in path.parents or not path.is_file():
        raise BackupError("Backup fajl nije pronađen.")
    if path.suffix not in [".backup", ".sql"]:
        raise BackupError("Nepodržan backup format.")
    return path


def restore_postgres_backup(filename):
    backup_path = safe_backup_path(filename)
    before_restore = create_postgres_backup(prefix="before_restore", prune=False)
    database = postgres_settings()

    connections.close_all()
    if backup_path.suffix == ".backup":
        pg_restore = executable_path("pg_restore")
        command = [
            pg_restore,
            "--clean",
            "--if-exists",
            "--no-owner",
            "--dbname",
            database.get("NAME", ""),
            "--host",
            database.get("HOST") or "localhost",
            "--port",
            str(database.get("PORT") or "5432"),
            "--username",
            database.get("USER", ""),
            "--no-password",
            str(backup_path),
        ]
    else:
        psql = executable_path("psql")
        command = [
            psql,
            "--dbname",
            database.get("NAME", ""),
            "--host",
            database.get("HOST") or "localhost",
            "--port",
            str(database.get("PORT") or "5432"),
            "--username",
            database.get("USER", ""),
            "--no-password",
            "--file",
            str(backup_path),
        ]
    run_command(command, database)
    prune_old_backups()
    return before_restore
