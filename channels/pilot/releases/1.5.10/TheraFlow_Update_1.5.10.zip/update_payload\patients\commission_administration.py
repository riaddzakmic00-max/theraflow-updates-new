"""Administrativni kalendar komisije bez kliničkih količinskih izračuna.

Ovaj modul namjerno ne uvozi servis potražnje, terapijske protokole ni stanje
zaliha. Njegova jedina odgovornost je pretvaranje administrativnih postavki u
datume pripreme, odobrenja i očekivane isporuke.
"""

from dataclasses import dataclass
from datetime import date, timedelta

from django.utils import timezone

from .commission_service import (
    get_commission_schedule,
)


@dataclass(frozen=True)
class AdministrativeTimelineStep:
    code: str
    label: str
    datum: date | None
    state: str


@dataclass(frozen=True)
class AdministrativeCommissionTimeline:
    commission_date: date | None
    preparation_start_date: date | None
    submission_date: date | None
    expected_approval_date: date | None
    expected_delivery_date: date | None
    safety_buffer_end_date: date | None
    active_phase: str
    steps: tuple[AdministrativeTimelineStep, ...]


def _phase_for_date(*, today, preparation, submission, approval, delivery):
    if not submission:
        return "NOT_CONFIGURED"
    if preparation and today < preparation:
        return "COMMISSION_SCHEDULED"
    if preparation and today < submission:
        return "PREPARATION"
    if approval and today < approval:
        return "SUBMITTED"
    if delivery and today < delivery:
        return "APPROVED"
    return "DELIVERY"


def _step_state(code, active_phase, *, today, event_date):
    if active_phase == code:
        return "active"
    if event_date and today >= event_date:
        return "completed"
    return "upcoming"


def get_administrative_commission_timeline(*, settings, today=None, holidays=None):
    """Vrati isključivo administrativne rokove za naredni komisijski ciklus."""

    today = today or timezone.localdate()
    schedule = get_commission_schedule(
        today=today,
        settings=settings,
        holidays=holidays,
    )
    commission_date = schedule.effective_next_date
    preparation = schedule.preparation_start_date
    submission = commission_date
    approval = (
        submission
        + timedelta(days=settings.prosjecno_trajanje_odobrenja_komisije_dana)
        if submission
        else None
    )
    delivery = (
        approval + timedelta(days=settings.vrijeme_isporuke_dana)
        if approval
        else None
    )
    safety_end = (
        delivery + timedelta(days=settings.sigurnosna_rezerva_dana)
        if delivery
        else None
    )
    active_phase = _phase_for_date(
        today=today,
        preparation=preparation,
        submission=submission,
        approval=approval,
        delivery=delivery,
    )
    raw_steps = (
        ("COMMISSION_SCHEDULED", "Komisija", commission_date),
        ("PREPARATION", "Početak pripreme", preparation),
        ("SUBMITTED", "Predaja zahtjeva", submission),
        ("APPROVED", "Očekivano odobrenje", approval),
        ("DELIVERY", "Očekivana isporuka", delivery),
    )
    steps = tuple(
        AdministrativeTimelineStep(
            code=code,
            label=label,
            datum=event_date,
            state=_step_state(
                code,
                active_phase,
                today=today,
                event_date=event_date,
            ),
        )
        for code, label, event_date in raw_steps
    )
    return AdministrativeCommissionTimeline(
        commission_date=commission_date,
        preparation_start_date=preparation,
        submission_date=submission,
        expected_approval_date=approval,
        expected_delivery_date=delivery,
        safety_buffer_end_date=safety_end,
        active_phase=active_phase,
        steps=steps,
    )
