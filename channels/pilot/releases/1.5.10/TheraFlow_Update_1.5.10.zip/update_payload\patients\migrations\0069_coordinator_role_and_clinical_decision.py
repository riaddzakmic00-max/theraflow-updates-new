import django.db.models.deletion
import django.utils.timezone
from django.db import migrations, models


ROLE_NAME = "Koordinator biološke terapije"


def create_coordinator_group(apps, schema_editor):
    Group = apps.get_model("auth", "Group")
    Group.objects.get_or_create(name=ROLE_NAME)


def remove_coordinator_group(apps, schema_editor):
    Group = apps.get_model("auth", "Group")
    Group.objects.filter(name=ROLE_NAME).delete()


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0068_migration_home_stock_balance"),
    ]

    operations = [
        migrations.AddField(
            model_name="izmjenaindividualnogprotokola",
            name="datum_odluke",
            field=models.DateField(default=django.utils.timezone.localdate),
        ),
        migrations.AddField(
            model_name="izmjenaindividualnogprotokola",
            name="ljekar_koji_je_donio_odluku",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.AddField(
            model_name="izmjenaindividualnogprotokola",
            name="povezani_dokument",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="izmjene_individualnog_protokola",
                to="patients.dokumentpacijenta",
            ),
        ),
        migrations.AddField(
            model_name="promjenaterapije",
            name="datum_odluke",
            field=models.DateField(default=django.utils.timezone.localdate),
        ),
        migrations.AddField(
            model_name="promjenaterapije",
            name="ljekar_koji_je_donio_odluku",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.AddField(
            model_name="promjenaterapije",
            name="povezani_dokument",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="klinicke_promjene_terapije",
                to="patients.dokumentpacijenta",
            ),
        ),
        migrations.RunPython(
            create_coordinator_group,
            remove_coordinator_group,
        ),
    ]
