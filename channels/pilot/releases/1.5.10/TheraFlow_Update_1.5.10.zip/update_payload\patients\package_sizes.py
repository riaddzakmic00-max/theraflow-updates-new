from decimal import Decimal, InvalidOperation, ROUND_CEILING

from .medication_groups import medicine_group_key


ADALIMUMAB_PACKAGE_SIZE = 2

_CANONICAL_PACKAGE_SIZES = {
    "adalimumab": ADALIMUMAB_PACKAGE_SIZE,
    "vedolizumab": 1,
    "infliximab": 1,
    "ustekinumab": 1,
}

_PROCUREMENT_METADATA = {
    "adalimumab": {
        "procurement_unit": "PEN",
        "unit_label": "pen",
        "package_label": "pakovanje",
        "show_package_count": True,
    },
    "vedolizumab": {
        "procurement_unit": "VIAL",
        "unit_label": "bočica",
        "package_label": "pakovanje",
        "show_package_count": False,
    },
    "infliximab": {
        "procurement_unit": "VIAL",
        "unit_label": "bočica",
        "package_label": "pakovanje",
        "show_package_count": False,
    },
}


def _procurement_metadata(lijek):
    group_key = medicine_group_key(lijek)
    if group_key == "ustekinumab":
        if getattr(lijek, "put_primjene", "") == "IV":
            return {
                "procurement_unit": "VIAL",
                "unit_label": "bočica",
                "package_label": "pakovanje",
                "show_package_count": False,
            }
        return {
            "procurement_unit": "SYRINGE",
            "unit_label": "šprica",
            "package_label": "pakovanje",
            "show_package_count": False,
        }
    metadata = _PROCUREMENT_METADATA.get(group_key)
    if metadata:
        return metadata
    if getattr(lijek, "oralna_terapija", False):
        return {
            "procurement_unit": "TABLET",
            "unit_label": "tableta",
            "package_label": "pakovanje",
            "show_package_count": True,
        }
    return {
        "procurement_unit": "DOSE",
        "unit_label": "doza",
        "package_label": "pakovanje",
        "show_package_count": True,
    }


class PackageConfigurationError(ValueError):
    """Lijek nema validnu konfiguraciju nabavnog pakovanja."""


def _configured_package_size(lijek):
    if lijek is None:
        raise PackageConfigurationError("Lijek nije definisan.")

    raw_size = getattr(lijek, "package_size_in_doses", None)
    if raw_size is None or isinstance(raw_size, bool):
        raise PackageConfigurationError(
            f"Veličina pakovanja za {getattr(lijek, 'prikaz_naziv', lijek)} "
            "nije konfigurisana."
        )
    try:
        size = int(raw_size)
    except (TypeError, ValueError, OverflowError) as exc:
        raise PackageConfigurationError(
            f"Veličina pakovanja za {getattr(lijek, 'prikaz_naziv', lijek)} "
            "mora biti pozitivan cijeli broj."
        ) from exc
    if size <= 0:
        raise PackageConfigurationError(
            f"Veličina pakovanja za {getattr(lijek, 'prikaz_naziv', lijek)} "
            "mora biti veća od nule."
        )
    return size


def canonical_package_size_for(lijek):
    """Vrati poznatu nabavnu veličinu, bez čitanja logističkih postavki."""
    return _CANONICAL_PACKAGE_SIZES.get(medicine_group_key(lijek))


def package_size_for(lijek):
    # Konfiguracija zapisa mora biti prisutna i validna čak i za poznate
    # terapijske grupe. Kanonska vrijednost štiti obračun od zastarjelog
    # zapisa do izvršenja data migracije; nikakva logistička postavka nije
    # dopuštena kao fallback.
    configured_size = _configured_package_size(lijek)
    return canonical_package_size_for(lijek) or configured_size


def _quantity_decimal(quantity):
    try:
        value = Decimal(str(quantity or 0))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError("Količina mora biti broj.") from exc
    if not value.is_finite():
        raise ValueError("Količina mora biti konačan broj.")
    if value < 0:
        raise ValueError("Količina ne može biti negativna.")
    return value


def _bosnian_quantity_label(quantity, singular, paucal, plural):
    if quantity != quantity.to_integral_value():
        return plural
    integer = abs(int(quantity))
    last_two = integer % 100
    if last_two in {11, 12, 13, 14}:
        return plural
    last = integer % 10
    if last == 1:
        return singular
    if last in {2, 3, 4}:
        return paucal
    return plural


def _format_quantity(quantity):
    value = _quantity_decimal(quantity)
    if value == value.to_integral_value():
        return str(int(value))
    return format(value.normalize(), "f")


def procurement_unit_display_label(quantity, lijek):
    """Vrati gramatički ispravan naziv nabavne jedinice za količinu."""
    value = _quantity_decimal(quantity)
    metadata = _procurement_metadata(lijek)
    if metadata["unit_label"] == "bočica":
        return _bosnian_quantity_label(
            value,
            "bočica",
            "bočice",
            "bočica",
        )
    if metadata["unit_label"] == "tableta":
        return _bosnian_quantity_label(value, "tableta", "tablete", "tableta")
    if metadata["unit_label"] == "pen":
        return _bosnian_quantity_label(value, "pen", "pena", "penova")
    if metadata["unit_label"] == "šprica":
        return _bosnian_quantity_label(value, "šprica", "šprice", "šprica")
    return _bosnian_quantity_label(value, "doza", "doze", "doza")


def procurement_breakdown(required_units, lijek):
    """Jedini backend obračun nabavne količine i broja pakovanja."""
    required = _quantity_decimal(required_units)
    units_per_package = package_size_for(lijek)
    package_size = Decimal(units_per_package)
    package_count_value = (
        int((required / package_size).to_integral_value(rounding=ROUND_CEILING))
        if required > 0
        else 0
    )
    rounded_units = Decimal(package_count_value) * package_size
    group_key = medicine_group_key(lijek)
    metadata = _procurement_metadata(lijek)
    unit_label = metadata["unit_label"]
    unit_display_label = procurement_unit_display_label(rounded_units, lijek)
    package_display_label = _bosnian_quantity_label(
        Decimal(package_count_value), "pakovanje", "pakovanja", "pakovanja"
    )
    show_package_count = bool(
        metadata.get("show_package_count")
        and units_per_package > 1
    )
    unit_display_text = (
        f"{_format_quantity(rounded_units)} {unit_display_label}"
    )
    display_text = unit_display_text
    if show_package_count:
        display_text = (
            f"{unit_display_text} · "
            f"{package_count_value} {package_display_label}"
        )

    return {
        "required_units": required,
        "rounded_procurement_units": rounded_units,
        "units_per_package": units_per_package,
        "package_count": package_count_value,
        "procurement_unit": metadata["procurement_unit"],
        "unit_label": unit_label,
        "unit_display_label": unit_display_label,
        "package_label": metadata["package_label"],
        "package_display_label": package_display_label,
        "show_package_count": show_package_count,
        "unit_display_text": unit_display_text,
        "display_text": display_text,
    }


def round_up_to_package(quantity, lijek):
    return procurement_breakdown(quantity, lijek)["rounded_procurement_units"]


def package_count(quantity, lijek):
    return procurement_breakdown(quantity, lijek)["package_count"]


def complete_package_count(quantity, lijek):
    quantity = _quantity_decimal(quantity)
    size = Decimal(package_size_for(lijek))
    if quantity % size != 0:
        return None
    return int(quantity / size)


def package_multiple_error(lijek, *, label="Količina"):
    if medicine_group_key(lijek) == "adalimumab":
        return (
            "Adalimumab se nabavlja u pakovanju od 2 pena. "
            "Unesite paran broj penova."
        )
    unit = "tableta" if getattr(lijek, "oralna_terapija", False) else "doza"
    return (
        f"{label} za {lijek.prikaz_naziv} mora biti višekratnik veličine "
        f"pakovanja ({package_size_for(lijek)} {unit})."
    )


def validate_package_multiple(quantity, lijek, *, label="Količina"):
    quantity = _quantity_decimal(quantity)
    size = Decimal(package_size_for(lijek))
    if quantity % size != 0:
        raise ValueError(package_multiple_error(lijek, label=label))
    return quantity
