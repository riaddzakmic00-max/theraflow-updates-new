from django.urls import path

from . import views


urlpatterns = [
    path("check/", views.check_update, name="update_check"),
    path("download/", views.download_update_package, name="update_download"),
    path("prepare/", views.prepare_update_package, name="update_prepare"),
    path("install/", views.install_update_package, name="update_install"),
    path("status/", views.update_status, name="update_status"),
    path("rollback/", views.rollback_update, name="update_rollback"),
    path("cleanup/", views.cleanup_updates, name="update_cleanup"),
]
