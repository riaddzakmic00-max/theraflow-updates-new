from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0021_lijek_nacin_primjene_terapija_tip_evidencije"),
    ]

    operations = [
        migrations.AddField(
            model_name="terapija",
            name="interval_sedmica",
            field=models.PositiveIntegerField(blank=True, null=True),
        ),
    ]
