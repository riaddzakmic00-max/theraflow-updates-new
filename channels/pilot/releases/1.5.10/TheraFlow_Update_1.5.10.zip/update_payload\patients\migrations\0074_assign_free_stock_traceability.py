from decimal import Decimal

from django.db import migrations, models
from django.db.models import Sum


RELEASE = "RELEASE_TO_FREE_STOCK"
ASSIGN = "ASSIGN_FREE_STOCK_TO_PATIENT"


def backfill_free_stock_assignments(apps, schema_editor):
    Reservation = apps.get_model("patients", "PacijentRezervacija")
    Transaction = apps.get_model("patients", "ZalihaTransakcija")

    reservations = Reservation.objects.filter(
        aktivno=True,
        kolicina__gt=0,
        komisija__isnull=True,
        trebovanje__isnull=True,
        migracijski_snapshot__isnull=True,
        migracijsko_pocetno_stanje__isnull=True,
    ).order_by("datum_rezervacije", "id")
    for reservation in reservations.iterator():
        if Transaction.objects.filter(
            tip=ASSIGN,
            pacijent_id=reservation.pacijent_id,
            lijek_id=reservation.lijek_id,
        ).exists():
            continue
        remaining = Decimal(str(reservation.kolicina or 0))
        releases = Transaction.objects.filter(
            tip=RELEASE,
            lijek_id=reservation.lijek_id,
            datum__lte=reservation.datum_rezervacije,
        ).order_by("kreirano", "id")
        for release in releases.iterator():
            used = Decimal(str(
                Transaction.objects.filter(
                    tip=ASSIGN,
                    referenca_tip="ZalihaTransakcija",
                    referenca_id=release.pk,
                ).aggregate(total=Sum("kolicina"))["total"] or 0
            ))
            available = max(Decimal("0"), Decimal(str(release.kolicina or 0)) - used)
            if available <= 0:
                continue
            allocated = min(remaining, available)
            Transaction.objects.create(
                lijek_id=reservation.lijek_id,
                tip=ASSIGN,
                kolicina=allocated,
                promjena_salda=Decimal("0"),
                datum=reservation.datum_rezervacije,
                pacijent_id=reservation.pacijent_id,
                referenca_tip="ZalihaTransakcija",
                referenca_id=release.pk,
                korisnik_id=release.korisnik_id,
                napomena=(
                    reservation.napomena
                    if reservation.napomena and reservation.napomena != "."
                    else "Naknadno povezana dodjela iz slobodne fizičke zalihe."
                ),
                lokacija="FRIZIDER",
                rezervisana_pacijentu=True,
            )
            remaining -= allocated
            if remaining <= 0:
                break


class Migration(migrations.Migration):
    dependencies = [("patients", "0073_release_to_free_stock_transaction")]

    operations = [
        migrations.AlterField(
            model_name="zalihatransakcija",
            name="tip",
            field=models.CharField(
                choices=[
                    ("ZAPRIMANJE", "Zaprimanje"),
                    ("AMBULANTNA_POTROSNJA", "Ambulantna potrosnja"),
                    ("KUCNO_IZDAVANJE", "Kucno izdavanje"),
                    ("POVRAT", "Povrat"),
                    ("OTPIS", "Otpis"),
                    ("KOREKCIJA", "Korekcija"),
                    ("POCETNO_STANJE_MIGRACIJE", "Početno stanje migracije"),
                    ("RELEASE_TO_FREE_STOCK", "Oslobađanje u slobodnu zalihu"),
                    ("ASSIGN_FREE_STOCK_TO_PATIENT", "Dodjela slobodne zalihe pacijentu"),
                ],
                max_length=30,
            ),
        ),
        migrations.RunPython(backfill_free_stock_assignments, migrations.RunPython.noop),
    ]
