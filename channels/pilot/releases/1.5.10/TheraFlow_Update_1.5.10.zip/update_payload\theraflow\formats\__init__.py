"""TheraFlow user-facing locale formats."""
