"""Sigurno i centralizovano brisanje označenog demo dataseta.

Ovaj servis namjerno ne mijenja ``on_delete`` pravila modela.  Produkcijski
``PROTECT`` ostaje posljednja linija odbrane, dok demo reset eksplicitno briše
zavisne redove prije pacijenta.
"""

from __future__ import annotations

from collections import defaultdict
from decimal import Decimal
from pathlib import Path

from django.conf import settings
from django.db import models, transaction
from django.db.models import Q

from .models import (
    AdaptiveDecisionRecord,
    AktivnostLog,
    DokumentPacijenta,
    EvidencijaSaglasnostiZaprimanja,
    FazniProtokolPacijenta,
    IndividualniKorakProtokola,
    IndividualniProtokolPacijenta,
    IzdavanjeOralneTerapije,
    IzmjenaIndividualnogProtokola,
    Komisija,
    KomisijskaSaglasnost,
    KomisijskaStavkaLijeka,
    KomisijskiCiklus,
    KomisijskiRucniUnos,
    KomisijskiZahtjev,
    KucnoIzdavanje,
    MigracijskiSnapshotPacijenta,
    OperationalOutcome,
    OralniTerapijskiRezim,
    Pacijent,
    PacijentRezervacija,
    PacijentSaglasnost,
    PacijentZaduzenje,
    PauzaTerapije,
    PotrebaFizickogPokrica,
    PromjenaTerapije,
    Terapija,
    TerapijaStatusHistorija,
    Termin,
    Trebovanje,
    Zaliha,
    ZalihaTransakcija,
)


class DemoDatasetResetError(RuntimeError):
    """Reset nije siguran ili nije mogao biti završen u cijelosti."""


class DemoDatasetProtectedReferences(DemoDatasetResetError):
    """Preostale PROTECT reference bi blokirale brisanje pacijenta."""

    def __init__(self, references):
        self.references = references
        details = ", ".join(
            f"{item['model']}.{item['field']}: {item['count']}"
            for item in references
        )
        super().__init__(
            "Preostale PROTECT reference prema demo pacijentima: " + details
        )


# Redoslijed je javna specifikacija servisa i koristi se u regresijskom testu.
# Pacijent je namjerno posljednji.
DEMO_DATASET_DELETION_ORDER = (
    "patients.TerapijaStatusHistorija",
    "patients.IzmjenaIndividualnogProtokola",
    "patients.AdaptiveDecisionRecord",
    "patients.AktivnostLog",
    "patients.EvidencijaSaglasnostiZaprimanja",
    "patients.IzdavanjeOralneTerapije",
    "patients.KucnoIzdavanje",
    "patients.KomisijskaSaglasnost",
    "patients.KomisijskaStavkaLijeka",
    "patients.PacijentRezervacija",
    "patients.PotrebaFizickogPokrica",
    "patients.Trebovanje",
    "patients.PacijentSaglasnost",
    "patients.KomisijskiZahtjev",
    "patients.Terapija",
    "patients.Termin",
    "patients.PacijentZaduzenje",
    "patients.PauzaTerapije",
    "patients.PromjenaTerapije",
    "patients.IndividualniKorakProtokola",
    "patients.IndividualniProtokolPacijenta",
    "patients.DokumentPacijenta",
    "patients.KomisijskiRucniUnos",
    "patients.FazniProtokolPacijenta",
    "patients.OralniTerapijskiRezim",
    "patients.MigracijskiSnapshotPacijenta",
    "patients.Komisija",
    "patients.ZalihaTransakcija",
    "patients.OperationalOutcome",
    "patients.KomisijskiCiklus",
    "patients.Pacijent",
)


_REGISTERED_PATIENT_DEPENDENCY_MODELS = {
    AdaptiveDecisionRecord,
    AktivnostLog,
    DokumentPacijenta,
    EvidencijaSaglasnostiZaprimanja,
    FazniProtokolPacijenta,
    IndividualniKorakProtokola,
    IndividualniProtokolPacijenta,
    IzdavanjeOralneTerapije,
    IzmjenaIndividualnogProtokola,
    Komisija,
    KomisijskaSaglasnost,
    KomisijskaStavkaLijeka,
    KomisijskiRucniUnos,
    KomisijskiZahtjev,
    KucnoIzdavanje,
    MigracijskiSnapshotPacijenta,
    OralniTerapijskiRezim,
    PacijentRezervacija,
    PacijentSaglasnost,
    PacijentZaduzenje,
    PauzaTerapije,
    PotrebaFizickogPokrica,
    PromjenaTerapije,
    Terapija,
    TerapijaStatusHistorija,
    Termin,
    Trebovanje,
    ZalihaTransakcija,
}


def _reverse_dependency_models(root_model):
    """Vrati sve konkretne FK/O2O potomke, uključujući indirektne."""

    discovered = set()
    queue = [root_model]
    while queue:
        parent = queue.pop(0)
        for relation in parent._meta.related_objects:
            field = relation.field
            if field.many_to_many:
                # Automatsku M2M spojnu tabelu Django čisti uz krajnji red;
                # eksplicitni through model se ionako pojavi kroz svoja FK polja.
                continue
            child = relation.related_model
            if child is root_model or child in discovered:
                continue
            discovered.add(child)
            queue.append(child)
    return discovered


def _assert_dependency_registry_is_complete():
    missing = (
        _reverse_dependency_models(Pacijent)
        - _REGISTERED_PATIENT_DEPENDENCY_MODELS
    )
    if missing:
        names = ", ".join(
            sorted(model._meta.label for model in missing)
        )
        raise DemoDatasetResetError(
            "Demo reset nema definisan siguran redoslijed za modele: " + names
        )


def _document_paths(patient_ids):
    media_root = Path(settings.MEDIA_ROOT).resolve()
    paths = []
    for document in DokumentPacijenta.objects.filter(
        pacijent_id__in=patient_ids
    ).exclude(fajl=""):
        try:
            path = Path(document.fajl.path).resolve()
        except Exception:
            continue
        if media_root in path.parents and "dokumenti_pacijenata" in path.parts:
            paths.append(path)
    return paths


def _remove_document_files(paths):
    for path in paths:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            # Baza je source of truth. Problem sa zasebnim filesystemom ne
            # smije poništiti već uspješno commitovan DB reset.
            pass


def _delete_queryset(label, queryset, stats):
    """Jedina tačka fizičkog brisanja; izdvojena i radi rollback testa."""

    count = queryset.count()
    stats[label] = count
    if count:
        queryset.delete()
    return count


def remaining_patient_protected_references(patient_ids):
    """Prijavi direktne PROTECT/RESTRICT redove prije brisanja pacijenta."""

    references = []
    patient_ids = tuple(patient_ids)
    if not patient_ids:
        return references

    protected_policies = {models.PROTECT, models.RESTRICT}
    for relation in Pacijent._meta.related_objects:
        field = relation.field
        if field.many_to_many or field.remote_field.on_delete not in protected_policies:
            continue
        count = relation.related_model._base_manager.filter(
            **{f"{field.name}_id__in": patient_ids}
        ).count()
        if count:
            references.append(
                {
                    "model": relation.related_model._meta.label,
                    "field": field.name,
                    "count": count,
                }
            )
    return references


def _safe_demo_cycle_ids(candidate_cycle_ids, patient_ids):
    """Ne briši označeni ciklus ako je naknadno dobio produkcijskog pacijenta."""

    candidate_cycle_ids = set(candidate_cycle_ids)
    if not candidate_cycle_ids:
        return []

    patient_ids = set(patient_ids)
    unsafe = set(
        Trebovanje.objects.filter(komisijski_ciklus_id__in=candidate_cycle_ids)
        .exclude(pacijent_id__in=patient_ids)
        .values_list("komisijski_ciklus_id", flat=True)
    )
    unsafe.update(
        KomisijskiZahtjev.objects.filter(
            komisijski_ciklus_id__in=candidate_cycle_ids
        )
        .exclude(pacijent_id__in=patient_ids)
        .values_list("komisijski_ciklus_id", flat=True)
    )
    unsafe.update(
        EvidencijaSaglasnostiZaprimanja.objects.filter(
            komisijski_ciklus_id__in=candidate_cycle_ids
        )
        .exclude(pacijent_id__in=patient_ids)
        .values_list("komisijski_ciklus_id", flat=True)
    )
    unsafe.update(
        KomisijskiRucniUnos.objects.filter(
            komisijski_ciklus_id__in=candidate_cycle_ids
        )
        .exclude(pacijent_id__in=patient_ids)
        .values_list("komisijski_ciklus_id", flat=True)
    )
    return sorted(candidate_cycle_ids - unsafe)


@transaction.atomic
def delete_demo_dataset(
    *,
    patient_queryset,
    cycle_queryset=None,
    event_marker="",
    delete_document_files=True,
):
    """Atomski ukloni jedan jasno označen demo dataset.

    ``patient_queryset`` je obavezan sigurnosni marker. Pozivaoci V2 koriste
    istovremeno tačan skup JMBG vrijednosti i ``DEMO-V2-`` broj kartona; legacy
    generator koristi svoj rezervisani JMBG prefiks. Nikakav filter po imenu ili
    prezimenu se ovdje ne koristi.
    """

    _assert_dependency_registry_is_complete()

    patient_ids = list(
        patient_queryset.select_for_update().values_list("pk", flat=True)
    )
    candidate_cycle_ids = list(
        (cycle_queryset or KomisijskiCiklus.objects.none())
        .select_for_update()
        .values_list("pk", flat=True)
    )
    cycle_ids = _safe_demo_cycle_ids(candidate_cycle_ids, patient_ids)
    document_paths = (
        _document_paths(patient_ids)
        if delete_document_files and patient_ids
        else []
    )

    movement_filter = Q(pacijent_id__in=patient_ids)
    log_filter = Q(pacijent_id__in=patient_ids)
    if event_marker:
        movement_filter |= Q(napomena__startswith=event_marker)
        log_filter |= Q(opis__startswith=event_marker)

    movements = list(
        ZalihaTransakcija.objects.select_for_update()
        .filter(movement_filter)
        .select_related("lijek")
        .order_by("pk")
    )
    movement_ids = [movement.pk for movement in movements]
    stock_deltas = defaultdict(
        lambda: {"fridge": Decimal("0"), "at_patient": Decimal("0")}
    )
    for movement in movements:
        quantity = Decimal(str(movement.kolicina or 0))
        stock_deltas[movement.lijek_id]["fridge"] += movement.frizider_delta()
        if movement.tip == ZalihaTransakcija.TIP_KUCNO_IZDAVANJE:
            stock_deltas[movement.lijek_id]["at_patient"] += quantity

    stats = {
        "pacijenti": len(patient_ids),
        "termini": Termin.objects.filter(pacijent_id__in=patient_ids).count(),
        "terapije": Terapija.objects.filter(pacijent_id__in=patient_ids).count(),
        "komisije": Komisija.objects.filter(pacijent_id__in=patient_ids).count(),
        "transakcije": len(movement_ids),
    }

    # 1) Audit/evidencijski i nepromjenjivi spojni redovi.
    _delete_queryset(
        "historija statusa terapije",
        TerapijaStatusHistorija.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "historija individualnog protokola",
        IzmjenaIndividualnogProtokola.objects.filter(
            protokol__pacijent_id__in=patient_ids
        ),
        stats,
    )
    _delete_queryset(
        "adaptivne odluke",
        AdaptiveDecisionRecord.objects.filter(
            Q(patient_id__in=patient_ids) | Q(commission_cycle_id__in=cycle_ids)
        ),
        stats,
    )
    _delete_queryset(
        "audit logovi",
        AktivnostLog.objects.filter(log_filter),
        stats,
    )
    _delete_queryset(
        "evidencije saglasnosti zaprimanja",
        EvidencijaSaglasnostiZaprimanja.objects.filter(
            pacijent_id__in=patient_ids
        ),
        stats,
    )

    # 2) Zaprimanja/izdavanja i stavke koje imaju PROTECT prema svojim izvorima.
    _delete_queryset(
        "oralna izdavanja",
        IzdavanjeOralneTerapije.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "kućna izdavanja",
        KucnoIzdavanje.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "komisijske saglasnosti",
        KomisijskaSaglasnost.objects.filter(
            komisijski_zahtjev__pacijent_id__in=patient_ids
        ),
        stats,
    )
    _delete_queryset(
        "komisijske stavke lijeka",
        KomisijskaStavkaLijeka.objects.filter(
            komisijski_zahtjev__pacijent_id__in=patient_ids
        ),
        stats,
    )

    # 3) Rezervacije i potrebe se skidaju prije vraćanja stock ledger efekta.
    _delete_queryset(
        "rezervacije",
        PacijentRezervacija.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "potrebe fizičkog pokrića",
        PotrebaFizickogPokrica.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )

    # 4) Legacy trebovanja, historija saglasnosti i moderni zahtjevi pacijenta.
    _delete_queryset(
        "trebovanja",
        Trebovanje.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "saglasnosti pacijenta",
        PacijentSaglasnost.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "komisijski zahtjevi pacijenta",
        KomisijskiZahtjev.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )

    # 5) Terapijski workflow, protokoli, dokumenti i administrativni redovi.
    _delete_queryset(
        "terapije",
        Terapija.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "termini",
        Termin.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "zaduženja",
        PacijentZaduzenje.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "pauze terapije",
        PauzaTerapije.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "promjene terapije",
        PromjenaTerapije.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "koraci individualnog protokola",
        IndividualniKorakProtokola.objects.filter(
            protokol__pacijent_id__in=patient_ids
        ),
        stats,
    )
    _delete_queryset(
        "individualni protokoli",
        IndividualniProtokolPacijenta.objects.filter(
            pacijent_id__in=patient_ids
        ),
        stats,
    )
    _delete_queryset(
        "dokumenti pacijenta",
        DokumentPacijenta.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "ručni komisijski unosi",
        KomisijskiRucniUnos.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "fazni protokoli",
        FazniProtokolPacijenta.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "oralni režimi",
        OralniTerapijskiRezim.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )
    _delete_queryset(
        "migracijski snapshoti pacijenta",
        MigracijskiSnapshotPacijenta.objects.filter(
            pacijent_id__in=patient_ids
        ),
        stats,
    )
    _delete_queryset(
        "komisijska odobrenja",
        Komisija.objects.filter(pacijent_id__in=patient_ids),
        stats,
    )

    # 6) Vrati isključivo ledger efekat označenih demo transakcija.
    for medicine_id, deltas in stock_deltas.items():
        stock = Zaliha.objects.select_for_update().filter(lijek_id=medicine_id).first()
        if not stock:
            continue
        stock.u_frizideru = Decimal(str(stock.u_frizideru or 0)) - deltas["fridge"]
        stock.kod_pacijenata = (
            Decimal(str(stock.kod_pacijenata or 0)) - deltas["at_patient"]
        )
        if stock.u_frizideru < 0 or stock.kod_pacijenata < 0:
            raise DemoDatasetResetError(
                "Demo reset bi proizveo negativno stanje zalihe za "
                f"{stock.lijek}; ledger ili zbirno stanje su ručno izmijenjeni."
            )
        stock.save(update_fields=["u_frizideru", "kod_pacijenata", "ukupno"])

    _delete_queryset(
        "transakcije zaliha",
        ZalihaTransakcija.objects.filter(pk__in=movement_ids),
        stats,
    )
    _delete_queryset(
        "operativni ishodi",
        OperationalOutcome.objects.filter(commission_cycle_id__in=cycle_ids),
        stats,
    )
    _delete_queryset(
        "komisijski ciklusi",
        KomisijskiCiklus.objects.filter(pk__in=cycle_ids),
        stats,
    )

    # 7) Posljednja provjera prije jedinog brisanja Pacijent redova.
    protected = remaining_patient_protected_references(patient_ids)
    if protected:
        raise DemoDatasetProtectedReferences(protected)
    _delete_queryset(
        "pacijenti",
        Pacijent.objects.filter(pk__in=patient_ids),
        stats,
    )

    if document_paths:
        transaction.on_commit(lambda: _remove_document_files(document_paths))
    return stats
