from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("patients", "0047_canonical_commission_cycle"),
    ]

    operations = [
        migrations.CreateModel(
            name="MigracijskiSnapshotPacijenta",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("datum_posljednje_terapije", models.DateField(blank=True, null=True)),
                ("interval_sedmica", models.PositiveSmallIntegerField()),
                ("broj_odobrenih_doza", models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ("broj_iskoristenih_doza", models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ("fizicki_u_frizideru", models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ("kod_pacijenta", models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ("sljedeca_terapija", models.DateField(blank=True, null=True)),
                ("napomena", models.TextField(blank=True)),
                ("kreirano", models.DateTimeField(auto_now_add=True)),
                ("kreirao", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
                ("lijek", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="patients.lijek")),
                ("pacijent", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name="migracijski_snapshot", to="patients.pacijent")),
            ],
            options={
                "verbose_name": "Migracijski snapshot pacijenta",
                "verbose_name_plural": "Migracijski snapshoti pacijenata",
            },
        ),
        migrations.AddConstraint(model_name="migracijskisnapshotpacijenta", constraint=models.CheckConstraint(condition=models.Q(("interval_sedmica__gte", 1), ("interval_sedmica__lte", 52)), name="migracijski_snapshot_interval_1_52")),
        migrations.AddConstraint(model_name="migracijskisnapshotpacijenta", constraint=models.CheckConstraint(condition=models.Q(("broj_odobrenih_doza__gte", 0)), name="migracijski_snapshot_odobreno_gte_0")),
        migrations.AddConstraint(model_name="migracijskisnapshotpacijenta", constraint=models.CheckConstraint(condition=models.Q(("broj_iskoristenih_doza__gte", 0)), name="migracijski_snapshot_iskoristeno_gte_0")),
        migrations.AddConstraint(model_name="migracijskisnapshotpacijenta", constraint=models.CheckConstraint(condition=models.Q(("fizicki_u_frizideru__gte", 0)), name="migracijski_snapshot_frizider_gte_0")),
        migrations.AddConstraint(model_name="migracijskisnapshotpacijenta", constraint=models.CheckConstraint(condition=models.Q(("kod_pacijenta__gte", 0)), name="migracijski_snapshot_kod_pacijenta_gte_0")),
        migrations.AddConstraint(model_name="migracijskisnapshotpacijenta", constraint=models.CheckConstraint(condition=models.Q(("broj_iskoristenih_doza__lte", models.F("broj_odobrenih_doza"))), name="migracijski_snapshot_iskoristeno_lte_odobreno")),
        migrations.AddConstraint(model_name="migracijskisnapshotpacijenta", constraint=models.CheckConstraint(condition=models.Q(("kod_pacijenta__lte", models.F("broj_odobrenih_doza"))), name="migracijski_snapshot_kod_pacijenta_lte_odobreno")),
    ]
