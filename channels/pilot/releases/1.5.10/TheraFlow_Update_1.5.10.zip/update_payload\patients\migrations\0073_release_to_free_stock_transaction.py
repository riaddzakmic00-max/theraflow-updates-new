from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0072_migration_stock_reservation_status"),
    ]

    operations = [
        migrations.AlterField(
            model_name="zalihatransakcija",
            name="tip",
            field=models.CharField(
                choices=[
                    ("ZAPRIMANJE", "Zaprimanje"),
                    ("AMBULANTNA_POTROSNJA", "Ambulantna potrosnja"),
                    ("KUCNO_IZDAVANJE", "Kucno izdavanje"),
                    ("POVRAT", "Povrat"),
                    ("OTPIS", "Otpis"),
                    ("KOREKCIJA", "Korekcija"),
                    ("POCETNO_STANJE_MIGRACIJE", "Početno stanje migracije"),
                    ("RELEASE_TO_FREE_STOCK", "Oslobađanje u slobodnu zalihu"),
                ],
                max_length=30,
            ),
        ),
    ]
