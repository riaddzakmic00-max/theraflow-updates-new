from django import template

from patients.home_therapy import format_stock_quantity
from patients.package_sizes import medicine_group_key, procurement_unit_display_label


register = template.Library()


@register.filter
def stock_quantity(value, medicine):
    return format_stock_quantity(medicine, value)


@register.filter
def commission_quantity(value, medicine):
    """Prikaži komisijsku količinu u jedinici lijeka, bez zaokruživanja vrijednosti."""

    if medicine_group_key(medicine) == "adalimumab":
        return format_stock_quantity(medicine, value)
    number = format_stock_quantity(None, value).split(" ", 1)[0]
    return f"{number} {procurement_unit_display_label(value, medicine)}"
