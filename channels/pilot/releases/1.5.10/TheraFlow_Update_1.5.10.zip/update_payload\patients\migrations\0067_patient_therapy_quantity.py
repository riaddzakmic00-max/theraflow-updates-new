from django.db import migrations, models


def configure_known_medicine_units(apps, schema_editor):
    Medicine = apps.get_model("patients", "Lijek")
    for medicine in Medicine.objects.all():
        identity = " ".join(
            filter(
                None,
                [medicine.naziv, medicine.genericki_naziv, medicine.zasticeno_ime],
            )
        ).casefold()
        if any(value in identity for value in ("infliximab", "infliksimab", "remsima")):
            singular, plural = "bočica", "bočice"
        elif any(value in identity for value in ("vedolizumab", "entyvio")):
            singular, plural = "bočica", "bočice"
        elif any(value in identity for value in ("adalimumab", "hyrimoz")):
            singular, plural = "pen", "penovi po jednoj primjeni"
        elif any(value in identity for value in ("ustekinumab", "stelara")):
            singular, plural = "šprica", "šprice"
        else:
            continue
        medicine.jedinica_terapije = singular
        medicine.jedinica_terapije_mnozina = plural
        medicine.save(
            update_fields=["jedinica_terapije", "jedinica_terapije_mnozina"]
        )


class Migration(migrations.Migration):
    dependencies = [("patients", "0066_link_migration_inventory_snapshots")]

    operations = [
        migrations.AddField(
            model_name="lijek",
            name="dozvoljava_decimalnu_kolicinu",
            field=models.BooleanField(
                default=False,
                verbose_name="Dozvoljava decimalnu količinu po terapiji",
            ),
        ),
        migrations.AddField(
            model_name="lijek",
            name="jedinica_terapije",
            field=models.CharField(
                default="jedinica",
                max_length=40,
                verbose_name="Jedinica terapije (jednina)",
            ),
        ),
        migrations.AddField(
            model_name="lijek",
            name="jedinica_terapije_mnozina",
            field=models.CharField(
                default="jedinice",
                max_length=60,
                verbose_name="Jedinica terapije (množina)",
            ),
        ),
        migrations.AddField(
            model_name="pacijent",
            name="kolicina_po_terapiji",
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                help_text="Potvrđena količina lijeka koju pacijent prima po jednoj terapiji.",
                max_digits=10,
                null=True,
                verbose_name="Količina po jednoj terapiji",
            ),
        ),
        migrations.AddField(
            model_name="termin",
            name="kolicina_po_terapiji",
            field=models.DecimalField(
                blank=True,
                decimal_places=2,
                max_digits=10,
                null=True,
                verbose_name="Količina po jednoj terapiji",
            ),
        ),
        migrations.AddConstraint(
            model_name="pacijent",
            constraint=models.CheckConstraint(
                condition=(
                    models.Q(kolicina_po_terapiji__isnull=True)
                    | models.Q(kolicina_po_terapiji__gt=0)
                ),
                name="pacijent_kolicina_po_terapiji_pozitivna",
            ),
        ),
        migrations.AddConstraint(
            model_name="termin",
            constraint=models.CheckConstraint(
                condition=(
                    models.Q(kolicina_po_terapiji__isnull=True)
                    | models.Q(kolicina_po_terapiji__gt=0)
                ),
                name="termin_kolicina_po_terapiji_pozitivna",
            ),
        ),
        migrations.RunPython(configure_known_medicine_units, migrations.RunPython.noop),
    ]
