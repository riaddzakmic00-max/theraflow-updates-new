from collections import Counter

from django.db.models import Count, F, Q

from .models import (
    DokumentPacijenta,
    Komisija,
    Lijek,
    Pacijent,
    PacijentRezervacija,
    PacijentZaduzenje,
    Terapija,
    TerapijskiProtokol,
    Termin,
    Zaliha,
)


CHECK_DEFINITIONS = [
    "Pacijenti bez lijeka",
    "Pacijenti sa lijekom bez aktivnog protokola",
    "Terapije bez pacijenta ili lijeka",
    "Terapije sa kolicinom <= 0",
    "Komisije sa negativnim preostalim dozama",
    "Zaduzenja gdje je preostalo vece od ukupno zaduzeno",
    "Zalihe sa negativnim stanjem",
    "Termini za neaktivne pacijente",
    "Protokoli bez aktivnih koraka",
    "Dokumenti ciji fajl ne postoji",
    "Duple JMBG vrijednosti",
    "Pacijenti u indukciji bez sljedeceg koraka terapije",
    "Pacijenti sa viskom indukcijskih terapija",
    "Fizicke rezervacije vece od stanja",
    "Duple aktivne rezervacije istog terapijskog dogadjaja",
    "Potrosene rezervacije koje su i dalje aktivne",
    "Rezervacije neaktivnih pacijenata ili promijenjenog lijeka",
]


def _problem(severity, problem_type, description, model, object_id, action):
    return {
        "severity": severity,
        "type": problem_type,
        "description": description,
        "model": model,
        "object_id": object_id or "-",
        "action": action,
    }


def _document_file_missing(document):
    if not document.fajl:
        return True

    try:
        return not document.fajl.storage.exists(document.fajl.name)
    except Exception:
        return True


def run_database_integrity_check():
    problems = []

    for pacijent in Pacijent.objects.filter(lijek__isnull=True).order_by("prezime", "ime"):
        problems.append(_problem(
            "warning",
            "Pacijent bez lijeka",
            f"{pacijent} nema izabran lijek.",
            "Pacijent",
            pacijent.id,
            "Otvoriti karton pacijenta i dodijeliti odgovarajuci lijek ili oznaciti pacijenta neaktivnim.",
        ))

    from .phased_protocols import phased_planning_configuration
    from .therapy_regimens import TYPE_ORAL, therapy_regimen_type

    for pacijent in Pacijent.objects.filter(lijek__isnull=False).select_related(
        "lijek",
        "terapijski_protokol",
        "terapijski_program",
    ):
        has_canonical_plan = bool(pacijent.aktivni_protokol())
        if therapy_regimen_type(pacijent.lijek) == TYPE_ORAL:
            has_canonical_plan = pacijent.oralni_rezimi.filter(
                aktivan=True,
                lijek=pacijent.lijek,
                datum_od__isnull=False,
            ).exists()
        elif pacijent.terapijski_program_id:
            phased = phased_planning_configuration(pacijent)
            if phased is not None:
                has_canonical_plan = phased.planning_possible
        if not has_canonical_plan:
            problems.append(_problem(
                "warning",
                "Lijek bez aktivnog protokola",
                (
                    f"{pacijent} koristi lijek {pacijent.lijek}, ali nema "
                    "kompletan canonical terapijski plan."
                ),
                "Pacijent",
                pacijent.id,
                (
                    "Definisati klasični protokol, potvrđeni oralni režim ili "
                    "kompletan fazni protokol, prema vrsti terapije."
                ),
            ))

    for terapija in Terapija.objects.filter(Q(pacijent__isnull=True) | Q(lijek__isnull=True)):
        problems.append(_problem(
            "critical",
            "Terapija bez veze",
            "Terapija nema povezanog pacijenta ili lijek.",
            "Terapija",
            terapija.id,
            "Provjeriti zapis terapije i rucno ga ispraviti iz administracije.",
        ))

    for terapija in Terapija.objects.filter(kolicina__lte=0).select_related("pacijent", "lijek"):
        problems.append(_problem(
            "critical",
            "Neispravna kolicina terapije",
            f"Terapija {terapija.id} za {terapija.pacijent} ima kolicinu {terapija.kolicina}.",
            "Terapija",
            terapija.id,
            "Provjeriti da li je terapija unesena greskom i korigovati kolicinu.",
        ))

    for komisija in Komisija.objects.filter(preostale_doze__lt=0).select_related("pacijent", "lijek"):
        problems.append(_problem(
            "critical",
            "Negativne preostale doze",
            f"Komisija za {komisija.pacijent} / {komisija.lijek} ima {komisija.preostale_doze} preostalih doza.",
            "Komisija",
            komisija.id,
            "Uskladiti preostale doze sa terapijama i zaduzenjima.",
        ))

    for zaduzenje in PacijentZaduzenje.objects.filter(preostalo__gt=F("ukupno_zaduzeno")).select_related("pacijent", "lijek"):
        problems.append(_problem(
            "warning",
            "Neispravno zaduzenje",
            f"{zaduzenje.pacijent} / {zaduzenje.lijek}: preostalo {zaduzenje.preostalo}, ukupno zaduzeno {zaduzenje.ukupno_zaduzeno}.",
            "PacijentZaduzenje",
            zaduzenje.id,
            "Provjeriti unos komisije ili zaprimanja i uskladiti stanje zaduzenja.",
        ))

    for zaliha in Zaliha.objects.filter(u_frizideru__lt=0).select_related("lijek"):
        problems.append(_problem(
            "critical",
            "Negativna zaliha",
            f"Zaliha za {zaliha.lijek} u frižideru je {zaliha.u_frizideru}.",
            "Zaliha",
            zaliha.id,
            "Provjeriti zadnje terapije/zaprimanja i korigovati stanje zalihe.",
        ))

    for zaliha in Zaliha.objects.filter(kod_pacijenata__lt=0).select_related("lijek"):
        problems.append(_problem(
            "critical",
            "Negativna zaliha kod pacijenata",
            f"Zaliha za {zaliha.lijek} kod pacijenata je {zaliha.kod_pacijenata}.",
            "Zaliha",
            zaliha.id,
            "Provjeriti kućna izdavanja i korigovati stanje zalihe.",
        ))

    # Agregatni hard invariant se ne može izraziti običnim SQL CHECK
    # constraintom preko dvije tabele. Svi operativni upisi koriste row-locking
    # servis, a ova provjera namjerno prijavljuje legacy/direct-ORM odstupanja
    # bez automatske izmjene podataka.
    from .inventory import active_reservation_details, inventory_position
    from .medication_groups import therapy_group_bucket_key

    checked_groups = set()
    inventory_medicines = Lijek.objects.filter(
        Q(zaliha__isnull=False)
        | Q(
            rezervacije_pacijenata__aktivno=True,
            rezervacije_pacijenata__kolicina__gt=0,
        )
    ).distinct().order_by("id")
    for medicine in inventory_medicines:
        group = therapy_group_bucket_key(medicine)
        if group in checked_groups:
            continue
        checked_groups.add(group)
        position = inventory_position(medicine, include_planned_need=False)
        if position["physical_reservation_shortfall"] > 0:
            problems.append(_problem(
                "critical",
                "Fizičke rezervacije prelaze stanje",
                (
                    f"{medicine}: fizički na stanju "
                    f"{position['in_fridge']}, aktivno rezervisano "
                    f"{position['reserved_in_fridge']}; prekoračenje "
                    f"{position['physical_reservation_shortfall']}."
                ),
                "Zaliha/PacijentRezervacija",
                medicine.pk,
                "Ne mijenjati automatski; provjeriti ledger i izvore rezervacija kroz reconciliation.",
            ))

        for detail in active_reservation_details(medicine):
            if detail["opravdan_aktivni_izvor"]:
                continue
            reservation = detail["rezervacija"]
            problems.append(_problem(
                "warning",
                "Nevažeća aktivna fizička rezervacija",
                (
                    f"Rezervacija #{reservation.pk} za {detail['pacijent']} / "
                    f"{reservation.lijek}: {detail['razlog_nevazece']}"
                ),
                "PacijentRezervacija",
                reservation.pk,
                "Provjeriti promjenu lijeka/status pacijenta i ručno potvrditi oslobađanje.",
            ))

    duplicate_events = (
        PacijentRezervacija.objects.filter(
            aktivno=True,
            kolicina__gt=0,
            termin__isnull=False,
        )
        .values("termin_id")
        .annotate(total=Count("id"))
        .filter(total__gt=1)
    )
    for item in duplicate_events:
        ids = list(PacijentRezervacija.objects.filter(
            termin_id=item["termin_id"],
            aktivno=True,
            kolicina__gt=0,
        ).values_list("id", flat=True))
        problems.append(_problem(
            "critical",
            "Dupla aktivna rezervacija terapijskog događaja",
            f"Termin #{item['termin_id']} ima aktivne rezervacije {ids}.",
            "PacijentRezervacija",
            ", ".join(map(str, ids)),
            "Ručno provjeriti događaj i zadržati samo opravdanu fizičku alokaciju.",
        ))

    consumed_active = PacijentRezervacija.objects.filter(
        Q(aktivno=True, potrosena_at__isnull=False)
        | Q(aktivno=True, kolicina__lte=0)
    ).select_related("pacijent", "lijek")
    for reservation in consumed_active:
        problems.append(_problem(
            "critical",
            "Potrošena rezervacija je ostala aktivna",
            f"Rezervacija #{reservation.pk} za {reservation.pacijent} / {reservation.lijek} nije zatvorena.",
            "PacijentRezervacija",
            reservation.pk,
            "Provjeriti povezanu terapiju i ručno uskladiti status rezervacije.",
        ))

    for termin in Termin.objects.filter(pacijent__aktivan=False).select_related("pacijent", "lijek"):
        problems.append(_problem(
            "info",
            "Termin za neaktivnog pacijenta",
            f"Termin {termin.datum} {termin.vrijeme} je vezan za neaktivnog pacijenta {termin.pacijent}.",
            "Termin",
            termin.id,
            "Provjeriti da li termin treba otkazati ili pacijenta ponovo aktivirati.",
        ))

    for protokol in TerapijskiProtokol.objects.filter(aktivan=True).annotate(
        active_steps=Count("koraci", filter=Q(koraci__aktivan=True))
    ).filter(active_steps=0).select_related("lijek"):
        problems.append(_problem(
            "warning",
            "Protokol bez aktivnih koraka",
            f"{protokol.lijek} / {protokol.naziv} nema aktivne korake protokola.",
            "TerapijskiProtokol",
            protokol.id,
            "Dodati indukcijske i/ili odrzavajuce korake protokola.",
        ))

    for document in DokumentPacijenta.objects.filter(aktivan=True).select_related("pacijent"):
        if _document_file_missing(document):
            problems.append(_problem(
                "warning",
                "Dokument bez fajla",
                f"Dokument '{document.naziv}' za {document.pacijent} nema dostupan fajl na disku.",
                "DokumentPacijenta",
                document.id,
                "Ponovo uploadovati dokument ili arhivirati neispravan zapis.",
            ))

    duplicate_jmbgs = (
        Pacijent.objects.exclude(jmbg="")
        .values("jmbg")
        .annotate(total=Count("id"))
        .filter(total__gt=1)
    )
    for item in duplicate_jmbgs:
        ids = list(Pacijent.objects.filter(jmbg=item["jmbg"]).values_list("id", flat=True))
        problems.append(_problem(
            "critical",
            "Dupli JMBG",
            f"JMBG {item['jmbg']} postoji kod vise pacijenata: {', '.join(map(str, ids))}.",
            "Pacijent",
            ", ".join(map(str, ids)),
            "Spojiti ili korigovati duple kartone pacijenata.",
        ))

    induction_patients = Pacijent.objects.filter(
        aktivan=True,
        pocetna_faza_terapije=Pacijent.FAZA_INDUKCIJA,
    ).select_related("lijek", "terapijski_protokol")
    for pacijent in induction_patients:
        protokol = pacijent.aktivni_protokol()
        if not protokol or not protokol.ima_korake():
            continue

        try:
            next_step = pacijent.sljedeci_korak_terapije()
        except Exception:
            next_step = None

        if next_step is None:
            problems.append(_problem(
                "warning",
                "Indukcija bez sljedeceg koraka",
                f"{pacijent} je oznacen kao indukcija, ali sistem ne moze odrediti sljedeci korak terapije.",
                "Pacijent",
                pacijent.id,
                "Provjeriti broj dosadasnjih terapija i korake aktivnog protokola.",
            ))

    for pacijent in Pacijent.objects.filter(lijek__isnull=False).select_related("lijek", "terapijski_protokol"):
        protokol = pacijent.aktivni_protokol()
        if not protokol or not protokol.ima_korake():
            continue

        dozvoljeno_indukcija = protokol.indukcijski_koraci().count()
        if dozvoljeno_indukcija <= 0:
            continue

        evidentirano_indukcija = Terapija.objects.filter(
            pacijent=pacijent,
            lijek=pacijent.lijek,
            faza_terapije__icontains="induk",
        ).count()

        if evidentirano_indukcija > dozvoljeno_indukcija:
            problems.append(_problem(
                "warning",
                "Visak indukcijskih terapija",
                (
                    f"{pacijent} ima {evidentirano_indukcija} terapija oznacenih kao indukcija, "
                    f"a protokol {protokol.naziv} dozvoljava {dozvoljeno_indukcija} indukcijskih koraka."
                ),
                "Pacijent",
                pacijent.id,
                "Provjeriti historiju terapija; terapije nakon zavrsene indukcije oznaciti kao odrzavanje.",
            ))

    severity_counts = Counter(problem["severity"] for problem in problems)
    problems_by_severity = {
        "critical": [problem for problem in problems if problem["severity"] == "critical"],
        "warning": [problem for problem in problems if problem["severity"] == "warning"],
        "info": [problem for problem in problems if problem["severity"] == "info"],
    }

    return {
        "total_checks": len(CHECK_DEFINITIONS),
        "problem_count": len(problems),
        "critical_count": severity_counts["critical"],
        "warning_count": severity_counts["warning"],
        "info_count": severity_counts["info"],
        "problems": problems,
        "problems_by_severity": problems_by_severity,
        "checks": CHECK_DEFINITIONS,
    }
