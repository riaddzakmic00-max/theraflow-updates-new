import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

from .file_installer import _atomic_copy, _target
from .plan_loader import safe_relative, sha256_file


class ConfigRestoreError(RuntimeError):
    pass


def restore_config(plan, critical_paths=(".env",)):
    backup = Path(plan["backup_root"]).resolve()
    archive = Path(plan["config_backup_path"]).resolve()
    manifest_path = backup / "config_backup_manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        entries = manifest["files"]
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise ConfigRestoreError("Config backup manifest nije validan.") from exc
    if manifest.get("session_id") != plan["session_id"]:
        raise ConfigRestoreError("Config backup ne pripada ovom update sessionu.")
    if not archive.is_file() or archive.parent != backup or not isinstance(entries, list):
        raise ConfigRestoreError("Config backup nije dostupan.")
    restored, unchanged, conflicts = [], [], []
    extraction = backup / ".config-restore"
    shutil.rmtree(extraction, ignore_errors=True)
    extraction.mkdir()
    try:
        with zipfile.ZipFile(archive) as zipped:
            names = set(zipped.namelist())
            for entry in entries:
                relative = str(safe_relative(entry.get("original_path"), "config putanja"))
                stored = str(safe_relative(entry.get("backup_path"), "config backup putanja"))
                target_scope = entry.get("target_scope", "application")
                if target_scope not in {"application", "canonical_env"}:
                    raise ConfigRestoreError("Config backup cilj nije dozvoljen.")
                if stored not in names:
                    raise ConfigRestoreError("Config backup zapis nedostaje u arhivi.")
                source = extraction / Path(*PurePosixPath(stored).parts)
                source.parent.mkdir(parents=True, exist_ok=True)
                with zipped.open(stored) as incoming, source.open("wb") as outgoing:
                    shutil.copyfileobj(incoming, outgoing)
                if sha256_file(source) != entry.get("sha256"):
                    raise ConfigRestoreError("Config backup hash nije ispravan.")
                target = (
                    Path(plan["canonical_env_path"]).resolve()
                    if target_scope == "canonical_env"
                    else _target(plan["application_root"], relative, "Config restore cilj")
                )
                if target.is_file() and sha256_file(target) == entry.get("sha256"):
                    unchanged.append(relative)
                    continue
                if target.exists():
                    if target.is_symlink() or not target.is_file():
                        raise ConfigRestoreError("Config restore cilj nije siguran fajl.")
                    conflict = backup / "config_conflicts" / Path(*PurePosixPath(relative).parts)
                    conflict = conflict.with_name(conflict.name + ".post-update")
                    conflict.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, conflict, follow_symlinks=False)
                    conflicts.append(relative)
                if target_scope == "canonical_env" or relative in critical_paths:
                    _atomic_copy(source, target)
                    restored.append(relative)
        report = {
            "created_at": datetime.now(timezone.utc).isoformat(),
            "restored": restored,
            "unchanged": unchanged,
            "conflicts": conflicts,
        }
        (backup / "rollback_config_report.json").write_text(
            json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        return report
    except (zipfile.BadZipFile, OSError) as exc:
        raise ConfigRestoreError("Vraćanje konfiguracije nije uspjelo.") from exc
    finally:
        shutil.rmtree(extraction, ignore_errors=True)
