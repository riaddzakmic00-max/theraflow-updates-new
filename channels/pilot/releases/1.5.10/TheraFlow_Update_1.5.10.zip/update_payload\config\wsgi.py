"""
WSGI config for config project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/6.0/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

application = get_wsgi_application()

# Fail before the first HTTP request if code, migration history and the
# physical database schema do not describe the same application state.
from patients.schema_gate import assert_startup_schema_gate

assert_startup_schema_gate()
