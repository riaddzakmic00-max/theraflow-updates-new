from datetime import timedelta
from django.utils import timezone
from patients.models import Trebovanje
from patients.models import Pacijent, Termin
from patients.services import izracunaj_status_pacijenta
from patients.commission_service import patients_for_next_commission
from patients.querysets import with_workflow_data


def lijek_pravila(lijek, pacijent=None):
    protokol = pacijent.aktivni_protokol() if pacijent else (lijek.aktivni_protokol() if lijek else None)
    status = izracunaj_status_pacijenta(pacijent) if pacijent else None
    potrebe = status["potrebe_komisije"] if status else None

    if protokol:
        return {
            "minimalno_za_terapiju": pacijent.doza_po_aplikaciji() if pacijent else protokol.doze_za_period(1),
            "planirati_doza": potrebe["ukupno_potrebno"] if potrebe else protokol.doze_za_period(13),
            "trenutno_dostupno": potrebe["trenutno_dostupno"] if potrebe else 0,
            "za_novu_komisiju": potrebe["za_novu_komisiju"] if potrebe else 0,
            "potrebe": potrebe,
            "protokol": protokol,
            "status": status,
        }

    return {
        "minimalno_za_terapiju": 1,
        "planirati_doza": potrebe["ukupno_potrebno"] if potrebe else 6,
        "trenutno_dostupno": potrebe["trenutno_dostupno"] if potrebe else 0,
        "za_novu_komisiju": potrebe["za_novu_komisiju"] if potrebe else 0,
        "potrebe": potrebe,
        "protokol": None,
        "status": status,
    }


def napravi_alarm_centar():
    danas = timezone.now().date()
    sutra = danas + timedelta(days=1)

    kriticni = []
    upozorenja = []
    informacije = []

    commission_needs = {
        item["pacijent"].id: item for item in patients_for_next_commission()
    }
    active_request_patient_ids = set(
        Trebovanje.objects.filter(
            status__in=["U_PRIPREMI", "PREDATO", "ODOBRENO"]
        ).values_list("pacijent_id", flat=True)
    )

    for pacijent in with_workflow_data(Pacijent.objects.filter(aktivan=True)):
        lijek = pacijent.lijek

        if not lijek:
            continue

        pravila = lijek_pravila(lijek, pacijent)

        status_pacijenta = pravila["status"]
        trenutno_doza = status_pacijenta["kod_pacijenta"] if status_pacijenta else 0

        minimalno = pravila["minimalno_za_terapiju"]
        canonical_need = commission_needs.get(pacijent.id)
        fali = canonical_need["za_novu_komisiju"] if canonical_need else 0

        if fali > 0:
            aktivno_trebovanje = pacijent.pk in active_request_patient_ids

            if aktivno_trebovanje:
                informacije.append({
                    "tip": "TREBOVANJE_U_TOKU",
                    "naslov": "Trebovanje u toku",
                    "pacijent": pacijent,
                    "lijek": lijek,
                    "status_pacijenta": status_pacijenta,
                })
            else:
                kriticni.append({
                    "tip": status_pacijenta["status"] if status_pacijenta else "NEDOVOLJNO_DOZA",
                    "naslov": status_pacijenta["status"] if status_pacijenta else "Pacijent nema dovoljno terapije",
                    "pacijent": pacijent,
                    "lijek": lijek,
                    "trenutno": pravila["trenutno_dostupno"],
                    "potrebno_u_periodu": pravila["planirati_doza"],
                    "minimalno": minimalno,
                    "fali": fali,
                    "potrebe": pravila["potrebe"],
                    "status_pacijenta": status_pacijenta,
                    "akcija": "Pripremi trebovanje",
                })

        elif status_pacijenta and status_pacijenta["status"] != "Uredno":
            upozorenja.append({
                "tip": status_pacijenta["status"],
                "naslov": status_pacijenta["status"],
                "pacijent": pacijent,
                "lijek": lijek,
                "trenutno": pravila["trenutno_dostupno"],
                "potrebno_u_periodu": pravila["planirati_doza"],
                "minimalno": minimalno,
                "fali": fali,
                "potrebe": pravila["potrebe"],
                "status_pacijenta": status_pacijenta,
                "akcija": "Provjeri",
            })

    informacije.append({
        "tip": "TERAPIJE_DANAS",
        "naslov": "Terapije danas",
        "broj": Termin.objects.filter(datum=danas, status="ZAKAZAN").count(),
    })

    informacije.append({
        "tip": "TERAPIJE_SUTRA",
        "naslov": "Terapije sutra",
        "broj": Termin.objects.filter(datum=sutra, status="ZAKAZAN").count(),
    })

    return {
        "kriticni": kriticni,
        "upozorenja": upozorenja,
        "informacije": informacije,
    }
