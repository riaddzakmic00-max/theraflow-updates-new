@echo off
setlocal EnableExtensions

set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%..\..") do set "INSTALL_ROOT=%%~fI"
set "PROGRAM_DATA=%ProgramData%\TheraFlow"
set "PYTHON_EXE=%PROGRAM_DATA%\runtime\venv\Scripts\python.exe"
set "INSTALLER=%SCRIPT_DIR%backup_scheduler_service.py"
set "LOG_DIR=%PROGRAM_DATA%\logs\backup_scheduler"
set "SCHEDULER_INSTALL_LOG=%LOG_DIR%\backup_scheduler_install.log"

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1
icacls "%LOG_DIR%" /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)(F)" "*S-1-5-32-544:(OI)(CI)(F)" /C /Q >nul 2>&1
if errorlevel 1 (
    >&2 echo ERROR: Could not configure protected Backup Scheduler log directory: %LOG_DIR%
    exit /b 1
)
if not exist "%PYTHON_EXE%" (
    >> "%SCHEDULER_INSTALL_LOG%" echo [%DATE% %TIME%] ERROR: Private Python not found: %PYTHON_EXE%
    >&2 echo ERROR: Private Python not found: %PYTHON_EXE%
    exit /b 1
)
if not exist "%INSTALLER%" (
    >> "%SCHEDULER_INSTALL_LOG%" echo [%DATE% %TIME%] ERROR: Backup scheduler service installer not found: %INSTALLER%
    >&2 echo ERROR: Backup scheduler service installer not found: %INSTALLER%
    exit /b 1
)

"%PYTHON_EXE%" "%INSTALLER%"
exit /b %ERRORLEVEL%
