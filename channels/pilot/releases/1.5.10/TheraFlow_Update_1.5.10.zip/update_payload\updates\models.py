import uuid

from django.conf import settings
from django.db import models
from django.db.models import Q


class UpdateSession(models.Model):
    PACKAGE_DOWNLOADED = "package_downloaded"
    BACKUP_IN_PROGRESS = "backup_in_progress"
    BACKUP_COMPLETED = "backup_completed"
    STAGING_IN_PROGRESS = "staging_in_progress"
    READY_TO_INSTALL = "ready_to_install"
    BACKUP_FAILED = "backup_failed"
    STAGING_FAILED = "staging_failed"
    VALIDATION_FAILED = "validation_failed"
    ERROR = "error"
    INSTALL_STARTING = "install_starting"
    VALIDATING_PLAN = "validating_plan"
    CREATING_SNAPSHOT = "creating_snapshot"
    SNAPSHOT_COMPLETED = "snapshot_completed"
    SERVICE_STOPPING = "service_stopping"
    SERVICE_STOPPED = "service_stopped"
    FILES_INSTALLING = "files_installing"
    FILES_INSTALLED = "files_installed"
    DJANGO_CHECK_RUNNING = "django_check_running"
    DJANGO_CHECK_PASSED = "django_check_passed"
    MIGRATIONS_RUNNING = "migrations_running"
    MIGRATIONS_COMPLETED = "migrations_completed"
    COLLECTSTATIC_RUNNING = "collectstatic_running"
    COLLECTSTATIC_COMPLETED = "collectstatic_completed"
    SERVICE_STARTING = "service_starting"
    SERVICE_RUNNING = "service_running"
    HEALTH_CHECK_RUNNING = "health_check_running"
    HEALTH_CHECK_PASSED = "health_check_passed"
    UPDATE_COMPLETED = "update_completed"
    ROLLBACK_REQUIRED = "rollback_required"
    INSTALL_FAILED = "install_failed"
    SNAPSHOT_FAILED = "snapshot_failed"
    SERVICE_STOP_FAILED = "service_stop_failed"
    SERVICE_START_FAILED = "service_start_failed"
    DJANGO_CHECK_FAILED = "django_check_failed"
    MIGRATIONS_FAILED = "migrations_failed"
    COLLECTSTATIC_FAILED = "collectstatic_failed"
    DEPENDENCY_UNSUPPORTED = "dependency_update_unsupported"
    ROLLBACK_STARTING = "rollback_starting"
    ROLLBACK_COMPLETED = "rollback_completed"
    ROLLBACK_FAILED = "rollback_failed"
    MANUAL_RECOVERY_REQUIRED = "manual_recovery_required"
    INTERRUPTED = "interrupted"

    ACTIVE_STATUSES = (
        PACKAGE_DOWNLOADED,
        BACKUP_IN_PROGRESS,
        BACKUP_COMPLETED,
        STAGING_IN_PROGRESS,
        READY_TO_INSTALL,
    )
    STATUS_CHOICES = [(status, status.replace("_", " ").title()) for status in (
        *ACTIVE_STATUSES, BACKUP_FAILED, STAGING_FAILED, VALIDATION_FAILED, ERROR,
        INSTALL_STARTING, VALIDATING_PLAN, CREATING_SNAPSHOT, SNAPSHOT_COMPLETED,
        SERVICE_STOPPING, SERVICE_STOPPED, FILES_INSTALLING, FILES_INSTALLED,
        DJANGO_CHECK_RUNNING, DJANGO_CHECK_PASSED, MIGRATIONS_RUNNING,
        MIGRATIONS_COMPLETED, COLLECTSTATIC_RUNNING, COLLECTSTATIC_COMPLETED,
        SERVICE_STARTING, SERVICE_RUNNING, HEALTH_CHECK_RUNNING, HEALTH_CHECK_PASSED,
        UPDATE_COMPLETED, ROLLBACK_REQUIRED, INSTALL_FAILED, SNAPSHOT_FAILED,
        SERVICE_STOP_FAILED, SERVICE_START_FAILED, DJANGO_CHECK_FAILED,
        MIGRATIONS_FAILED, COLLECTSTATIC_FAILED, DEPENDENCY_UNSUPPORTED,
        ROLLBACK_STARTING, ROLLBACK_COMPLETED, ROLLBACK_FAILED,
        MANUAL_RECOVERY_REQUIRED, INTERRUPTED,
    )]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    target_version = models.CharField(max_length=50)
    status = models.CharField(max_length=48, default=PACKAGE_DOWNLOADED)
    is_active = models.BooleanField(default=True)
    package_path = models.TextField()
    package_sha256 = models.CharField(max_length=64)
    backup_directory = models.TextField(blank=True)
    database_backup_path = models.TextField(blank=True)
    config_backup_path = models.TextField(blank=True)
    staging_directory = models.TextField(blank=True)
    install_plan_path = models.TextField(blank=True)
    install_plan_sha256 = models.CharField(max_length=64, blank=True)
    manifest_snapshot = models.JSONField(default=dict)
    database_backup_validated = models.BooleanField(default=False)
    staging_validated = models.BooleanField(default=False)
    error_message = models.TextField(blank=True)
    prepared_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    prepared_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="prepared_updates",
    )
    install_started_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
        related_name="started_updates",
    )
    install_started_at = models.DateTimeField(null=True, blank=True)
    install_completed_at = models.DateTimeField(null=True, blank=True)
    updater_pid = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        ordering = ("-created_at",)
        constraints = [
            models.UniqueConstraint(
                fields=("is_active",),
                condition=Q(is_active=True),
                name="updates_only_one_active_session",
            ),
        ]

    def __str__(self):
        return f"TheraFlow {self.target_version} ({self.status})"


class UpdateHistory(models.Model):
    SUCCESSFUL = "successful"
    FAILED_BEFORE_INSTALL = "failed_before_install"
    FAILED_ROLLED_BACK = "failed_rolled_back"
    FAILED_MANUAL_RECOVERY = "failed_manual_recovery"
    CANCELLED = "cancelled"
    ROLLBACK_SUCCESSFUL = "rollback_successful"
    ROLLBACK_FAILED = "rollback_failed"
    STATUS_CHOICES = (
        (SUCCESSFUL, "Uspješno"),
        (FAILED_BEFORE_INSTALL, "Neuspješno prije instalacije"),
        (FAILED_ROLLED_BACK, "Neuspješno · prethodna verzija vraćena"),
        (FAILED_MANUAL_RECOVERY, "Potrebna ručna intervencija"),
        (CANCELLED, "Otkazano"),
        (ROLLBACK_SUCCESSFUL, "Rollback uspješan"),
        (ROLLBACK_FAILED, "Rollback neuspješan"),
    )

    session = models.OneToOneField(UpdateSession, null=True, blank=True, on_delete=models.SET_NULL, related_name="history")
    source_version = models.CharField(max_length=50)
    target_version = models.CharField(max_length=50)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=32, choices=STATUS_CHOICES)
    initiated_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="update_history")
    mandatory = models.BooleanField(default=False)
    package_sha256 = models.CharField(max_length=64, blank=True)
    backup_created = models.BooleanField(default=False)
    backup_validated = models.BooleanField(default=False)
    files_installed = models.BooleanField(default=False)
    migrations_executed = models.BooleanField(default=False)
    health_check_result = models.CharField(max_length=64, blank=True)
    rollback_executed = models.BooleanField(default=False)
    rollback_type = models.CharField(max_length=20, blank=True)
    rollback_result = models.CharField(max_length=64, blank=True)
    final_active_version = models.CharField(max_length=50, blank=True)
    duration_seconds = models.PositiveIntegerField(null=True, blank=True)
    safe_error_summary = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-started_at", "-created_at")

    def __str__(self):
        return f"{self.source_version} → {self.target_version} ({self.status})"
