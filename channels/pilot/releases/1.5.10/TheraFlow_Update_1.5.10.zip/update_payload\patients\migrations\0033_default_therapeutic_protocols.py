from decimal import Decimal

from django.db import migrations


PROTOCOLS = [
    {
        "keys": ["remsima", "infliximab"],
        "lijek_naziv": "Remsima",
        "naziv": "Standardni plan",
        "tip": "KOMBINOVANO",
        "indukcija": "0,2,6",
        "interval": 8,
        "doza": 4,
        "kucna": False,
        "napomena": "Default protokol: indukcija 0,2,6; odrzavanje svakih 8 sedmica.",
        "koraci": [
            ("Indukcija 1", "INDUKCIJA", 0, 1, None, Decimal("4"), None, "AMBULANTA"),
            ("Indukcija 2", "INDUKCIJA", 2, 2, None, Decimal("4"), None, "AMBULANTA"),
            ("Indukcija 3", "INDUKCIJA", 6, 3, None, Decimal("4"), None, "AMBULANTA"),
            ("Odrzavanje", "ODRZAVANJE", 14, 4, None, Decimal("4"), 8, "AMBULANTA"),
        ],
    },
    {
        "keys": ["entyvio", "vedolizumab"],
        "lijek_naziv": "Entyvio",
        "naziv": "Standardni plan",
        "tip": "KOMBINOVANO",
        "indukcija": "0,2,6",
        "interval": 8,
        "doza": 1,
        "kucna": False,
        "napomena": "Default protokol: indukcija 0,2,6; odrzavanje svakih 8 sedmica.",
        "koraci": [
            ("Indukcija 1", "INDUKCIJA", 0, 1, Decimal("300"), Decimal("1"), None, "AMBULANTA"),
            ("Indukcija 2", "INDUKCIJA", 2, 2, Decimal("300"), Decimal("1"), None, "AMBULANTA"),
            ("Indukcija 3", "INDUKCIJA", 6, 3, Decimal("300"), Decimal("1"), None, "AMBULANTA"),
            ("Odrzavanje", "ODRZAVANJE", 14, 4, Decimal("300"), Decimal("1"), 8, "AMBULANTA"),
        ],
    },
    {
        "keys": ["adalimumab"],
        "lijek_naziv": "Adalimumab",
        "naziv": "Odrzavanje kucne terapije",
        "tip": "ODRZAVANJE",
        "indukcija": "",
        "interval": 2,
        "doza": 1,
        "kucna": True,
        "napomena": "Default protokol: kucna terapija svakih 2 sedmice.",
        "koraci": [
            ("Odrzavanje kuci", "ODRZAVANJE", 0, 1, Decimal("40"), Decimal("1"), 2, "KUCNA_TERAPIJA"),
        ],
    },
]


def find_or_create_lijek(Lijek, config):
    for key in config["keys"]:
        lijek = Lijek.objects.filter(naziv__icontains=key).first()
        if lijek:
            return lijek
    lijek, _ = Lijek.objects.get_or_create(naziv=config["lijek_naziv"])
    return lijek


def upsert_protocols(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    Pacijent = apps.get_model("patients", "Pacijent")
    TerapijskiProtokol = apps.get_model("patients", "TerapijskiProtokol")
    TerapijskiKorakProtokola = apps.get_model("patients", "TerapijskiKorakProtokola")

    for config in PROTOCOLS:
        lijek = find_or_create_lijek(Lijek, config)
        if config["kucna"]:
            lijek.kucna_primjena = True
            lijek.nacin_primjene = "KUCNA_TERAPIJA"
            lijek.save(update_fields=["kucna_primjena", "nacin_primjene"])

        protokoli = list(
            TerapijskiProtokol.objects.filter(
                lijek=lijek,
                naziv=config["naziv"],
            ).order_by("-aktivan", "id")
        )
        if protokoli:
            protokol = protokoli[0]
            duplicate_ids = [duplikat.id for duplikat in protokoli[1:]]
            if duplicate_ids:
                Pacijent.objects.filter(
                    terapijski_protokol_id__in=duplicate_ids
                ).update(terapijski_protokol=protokol)
                TerapijskiProtokol.objects.filter(id__in=duplicate_ids).delete()
        else:
            protokol = TerapijskiProtokol.objects.create(
                lijek=lijek,
                naziv=config["naziv"],
                tip_terapije=config["tip"],
                indukcijske_sedmice=config["indukcija"],
                interval_odrzavanja_sedmica=config["interval"],
                doza_po_aplikaciji=config["doza"],
                napomena=config["napomena"],
                aktivan=True,
            )
        protokol.tip_terapije = config["tip"]
        protokol.indukcijske_sedmice = config["indukcija"]
        protokol.interval_odrzavanja_sedmica = config["interval"]
        protokol.doza_po_aplikaciji = config["doza"]
        protokol.napomena = config["napomena"]
        protokol.aktivan = True
        protokol.save()

        active_orders = []
        for naziv, faza, sedmica, redoslijed, doza_mg, jedinice, interval, nacin in config["koraci"]:
            active_orders.append(redoslijed)
            koraci = list(
                TerapijskiKorakProtokola.objects.filter(
                    protokol=protokol,
                    redoslijed=redoslijed,
                ).order_by("id")
            )
            if koraci:
                korak = koraci[0]
                if len(koraci) > 1:
                    TerapijskiKorakProtokola.objects.filter(
                        id__in=[duplikat.id for duplikat in koraci[1:]]
                    ).update(aktivan=False)
            else:
                korak = TerapijskiKorakProtokola(
                    protokol=protokol,
                    redoslijed=redoslijed,
                )
            korak.naziv_koraka = naziv
            korak.faza = faza
            korak.sedmica_od_pocetka = sedmica
            korak.doza_mg = doza_mg
            korak.broj_jedinica = jedinice
            korak.interval_sedmica = interval
            korak.nacin_primjene_koraka = nacin
            korak.aktivan = True
            korak.save()

        TerapijskiKorakProtokola.objects.filter(protokol=protokol).exclude(
            redoslijed__in=active_orders
        ).update(aktivan=False)
        Pacijent.objects.filter(lijek=lijek, terapijski_protokol__isnull=True).update(
            terapijski_protokol=protokol
        )


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0032_migration_workflow_flags"),
    ]

    operations = [
        migrations.RunPython(upsert_protocols, migrations.RunPython.noop),
    ]
