from .models import AktivnostLog

def upisi_log(korisnik, akcija, pacijent=None, objekat=None, opis=""):
    AktivnostLog.objects.create(
        korisnik=korisnik if korisnik and korisnik.is_authenticated else None,
        akcija=akcija,
        pacijent=pacijent,
        objekat_tip=objekat.__class__.__name__ if objekat else "",
        objekat_id=objekat.id if objekat else None,
        opis=opis,
    )