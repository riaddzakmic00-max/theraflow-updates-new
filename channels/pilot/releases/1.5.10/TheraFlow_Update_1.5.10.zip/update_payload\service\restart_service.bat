@echo off
setlocal EnableExtensions

set "SERVICE_NAME=TheraFlow"
set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%..") do set "PROJECT_DIR=%%~fI"
set "NSSM_EXE=%PROJECT_DIR%\vendor\nssm\nssm.exe"
set "STDOUT_LOG=%PROJECT_DIR%\logs\service_output.log"
set "STDERR_LOG=%PROJECT_DIR%\logs\service_error.log"

echo.
echo === TheraFlow Windows Service restart ===
echo.

if not exist "%NSSM_EXE%" (
    echo ERROR: NSSM nije pronadjen:
    echo "%NSSM_EXE%"
    exit /b 1
)

sc query "%SERVICE_NAME%" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Servis "%SERVICE_NAME%" nije instaliran.
    exit /b 1
)

echo Restartujem servis "%SERVICE_NAME%"...
"%NSSM_EXE%" restart "%SERVICE_NAME%" >nul 2>&1

for /l %%I in (1,1,45) do (
    sc query "%SERVICE_NAME%" | find /I "RUNNING" >nul 2>&1
    if not errorlevel 1 (
        echo OK: Servis "%SERVICE_NAME%" je SERVICE_RUNNING.
        exit /b 0
    )
    timeout /t 1 /nobreak >nul
)

echo.
echo ERROR: Servis "%SERVICE_NAME%" nije u SERVICE_RUNNING stanju.
echo Provjerite logove:
echo "%STDOUT_LOG%"
echo "%STDERR_LOG%"
exit /b 1
