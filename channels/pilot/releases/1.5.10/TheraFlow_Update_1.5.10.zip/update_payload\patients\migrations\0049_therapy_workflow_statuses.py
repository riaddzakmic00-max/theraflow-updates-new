from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("patients", "0048_migracijski_snapshot_pacijenta"),
    ]

    operations = [
        migrations.AlterField(
            model_name="termin",
            name="status",
            field=models.CharField(choices=[("ZAKAZAN", "Planirana"), ("OBAVLJEN", "Potvrđena"), ("ODGODJENA", "Odgođena"), ("NIJE_DOSAO", "Nije došao"), ("PAUZIRANA", "Privremeno pauzirana"), ("OTKAZAN", "Otkazana"), ("PONISTENA", "Poništena")], default="ZAKAZAN", max_length=20),
        ),
        migrations.AddField(model_name="terapija", name="workflow_status", field=models.CharField(choices=[("POTVRDJENA", "Potvrđena"), ("PONISTENA", "Poništena")], default="POTVRDJENA", max_length=20)),
        migrations.AddField(model_name="terapija", name="workflow_snapshot", field=models.JSONField(blank=True, default=dict)),
        migrations.AddField(model_name="terapija", name="razlog_ponistavanja", field=models.TextField(blank=True)),
        migrations.AddField(model_name="terapija", name="ponistena_at", field=models.DateTimeField(blank=True, null=True)),
        migrations.AddField(model_name="terapija", name="finansijski_status", field=models.CharField(default="NIJE_KREIRAN", max_length=20)),
        migrations.AddField(model_name="terapija", name="ponistio", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="ponistene_terapije", to=settings.AUTH_USER_MODEL)),
        migrations.CreateModel(
            name="PauzaTerapije",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("datum_pocetka", models.DateField()),
                ("planirani_datum_zavrsetka", models.DateField(blank=True, null=True)),
                ("datum_nastavka", models.DateField(blank=True, null=True)),
                ("razlog", models.TextField()),
                ("aktivna", models.BooleanField(default=True)),
                ("kreirano", models.DateTimeField(auto_now_add=True)),
                ("kreirao", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="kreirane_pauze_terapije", to=settings.AUTH_USER_MODEL)),
                ("pacijent", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="pauze_terapije", to="patients.pacijent")),
                ("zavrsio", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="zavrsene_pauze_terapije", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-datum_pocetka", "-id"]},
        ),
        migrations.AddConstraint(model_name="pauzaterapije", constraint=models.CheckConstraint(condition=models.Q(("planirani_datum_zavrsetka__isnull", True), ("planirani_datum_zavrsetka__gte", models.F("datum_pocetka")), _connector="OR"), name="pauza_planirani_kraj_nakon_pocetka")),
        migrations.CreateModel(
            name="TerapijaStatusHistorija",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("prethodni_status", models.CharField(blank=True, max_length=30)),
                ("novi_status", models.CharField(max_length=30)),
                ("razlog", models.TextField(blank=True)),
                ("prethodno_stanje", models.JSONField(blank=True, default=dict)),
                ("novo_stanje", models.JSONField(blank=True, default=dict)),
                ("datum_vrijeme", models.DateTimeField(auto_now_add=True)),
                ("korisnik", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
                ("pacijent", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="historija_statusa_terapije", to="patients.pacijent")),
                ("terapija", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="historija_statusa", to="patients.terapija")),
                ("termin", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="historija_statusa", to="patients.termin")),
            ],
            options={"ordering": ["-datum_vrijeme", "-id"]},
        ),
    ]
