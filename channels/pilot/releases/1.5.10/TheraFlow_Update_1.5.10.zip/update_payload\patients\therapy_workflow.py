from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .transaction_locking import select_for_update_self

from .models import (
    Komisija,
    Pacijent,
    PacijentZaduzenje,
    PacijentRezervacija,
    PauzaTerapije,
    Terapija,
    TerapijaStatusHistorija,
    Termin,
    Zaliha,
    ZalihaTransakcija,
)
from .utils import upisi_log


def _validate_requested_therapy_date(datum, termin):
    from .scheduling import validate_therapy_date

    try:
        validate_therapy_date(
            datum,
            lijek=termin.lijek,
            protokol=termin.pacijent.aktivni_protokol(),
        )
    except ValidationError as exc:
        raise ValueError(exc.messages[0]) from exc


def _audit_user(user):
    return user if getattr(user, "is_authenticated", False) else None


def _debug_reservations_for_appointment(termin):
    from .inventory import patient_reservation_breakdown

    return patient_reservation_breakdown(termin.pacijent, termin=termin)


def record_status_history(
    *, pacijent, new_status, reason, user=None, termin=None, terapija=None,
    previous_status="", previous_state=None, new_state=None, event_type=None,
):
    state = dict(new_state or {})
    if event_type:
        state["tip_dogadjaja"] = event_type
    return TerapijaStatusHistorija.objects.create(
        pacijent=pacijent,
        termin=termin,
        terapija=terapija,
        prethodni_status=previous_status or "",
        novi_status=new_status,
        razlog=(reason or "").strip(),
        prethodno_stanje=previous_state or {},
        novo_stanje=state,
        korisnik=_audit_user(user),
    )


def _appointment_state(termin, *, status=None):
    return {
        "datum": termin.datum.isoformat(),
        "vrijeme": (
            termin.vrijeme.isoformat(timespec="minutes")
            if termin.vrijeme else None
        ),
        "status": status or termin.status,
        "lijek_id": termin.lijek_id,
        "lijek_naziv": (
            str(termin.lijek) if getattr(termin, "lijek", None) else ""
        ),
    }


def _change_appointment_status(
    termin,
    *,
    status,
    reason,
    user,
    old_state,
    new_state,
    event_type=None,
):
    previous = termin.status
    termin.status = status
    termin.save(update_fields=["status", "datum"] if old_state.get("datum") != new_state.get("datum") else ["status"])
    history = record_status_history(
        pacijent=termin.pacijent,
        termin=termin,
        previous_status=previous,
        new_status=status,
        reason=reason,
        user=user,
        previous_state=old_state,
        new_state=new_state,
        event_type=event_type,
    )
    upisi_log(
        user,
        f"Status terapije: {history.novi_status}",
        pacijent=termin.pacijent,
        objekat=termin,
        opis=f"{previous} → {status}; razlog: {reason}",
    )
    return termin


@transaction.atomic
def mark_no_show(
    *,
    termin,
    reason,
    user=None,
    reschedule_date=None,
    scheduling_validation_today=None,
):
    termin = select_for_update_self(
        Termin.objects.select_related("pacijent", "lijek")
    ).get(pk=termin.pk)
    if termin.status != Termin.STATUS_PLANIRANA:
        raise ValueError(
            "Status 'Nije došao' može se postaviti samo na aktivan planirani termin."
        )
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("Unesite razlog zbog kojeg pacijent nije došao.")
    old = _appointment_state(termin)
    _debug_reservations_for_appointment(termin)
    _change_appointment_status(
        termin,
        status=Termin.STATUS_NIJE_DOSAO,
        reason=reason,
        user=user,
        old_state=old,
        new_state=_appointment_state(
            termin,
            status=Termin.STATUS_NIJE_DOSAO,
        ),
        event_type=TerapijaStatusHistorija.DOGADJAJ_NIJE_DOSAO,
    )
    replacement = None
    if reschedule_date:
        _validate_requested_therapy_date(reschedule_date, termin)
        if reschedule_date <= termin.datum:
            raise ValueError("Novi termin mora biti poslije termina na koji pacijent nije došao.")
        replacement, _ = schedule_therapy_appointment(
            pacijent=termin.pacijent,
            lijek=termin.lijek,
            datum=reschedule_date,
            vrijeme=termin.vrijeme,
            user=user,
            reason="Ponovno zakazivanje nakon nedolaska.",
            validation_today=scheduling_validation_today,
        )
    _debug_reservations_for_appointment(termin)
    return termin, replacement


@transaction.atomic
def postpone_therapy(*, termin, reason, user=None, new_date=None):
    termin = select_for_update_self(
        Termin.objects.select_related("pacijent", "lijek")
    ).get(pk=termin.pk)
    if termin.status != Termin.STATUS_PLANIRANA:
        raise ValueError(
            "Samo aktivan planirani termin može se odgoditi ili promijeniti."
        )
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("Unesite razlog odgode terapije.")
    if new_date and new_date == termin.datum:
        # Ponovljeni HTTP zahtjev nakon uspješne promjene termina ne smije
        # kreirati novi događaj niti dirati rezervacije.
        return termin
    old = _appointment_state(termin)
    # Dijagnostički zapis potvrđuje da odgoda pomjera isti Termin i ne kreira
    # novu fizičku rezervaciju. Vrijednosti rezervacija se ovdje ne mijenjaju.
    _debug_reservations_for_appointment(termin)
    if new_date:
        _validate_requested_therapy_date(new_date, termin)
        if new_date <= termin.datum:
            raise ValueError("Novi datum termina mora biti poslije trenutnog datuma.")
        termin.datum = new_date
        status = Termin.STATUS_PLANIRANA
        event_type = TerapijaStatusHistorija.DOGADJAJ_TERMIN_PROMIJENJEN
    else:
        status = Termin.STATUS_ODGODJENA
        event_type = TerapijaStatusHistorija.DOGADJAJ_TERMIN_ODGODJEN
    changed = _change_appointment_status(
        termin,
        status=status,
        reason=reason,
        user=user,
        old_state=old,
        new_state=_appointment_state(termin, status=status),
        event_type=event_type,
    )
    _canonicalize_appointment_reservations(
        termin=changed,
        reason=reason,
        user=user,
    )
    _debug_reservations_for_appointment(changed)
    return changed


def _canonicalize_appointment_reservations(*, termin, reason, user=None):
    """Zadrži samo količinu potrebnu za jednu narednu ambulantnu primjenu.

    Stari migracijski/ručni redovi ostaju u historiji, ali višak više nije
    aktivna fizička rezervacija. Ovdje se ne mijenja centralni saldo i ne
    kreira transakcija zalihe jer se uklanja dupli zapis, a ne stvarna doza.
    """

    from .medication_groups import strict_equivalent_medicine_ids

    base_reservations = PacijentRezervacija.objects.select_for_update().filter(
        pacijent=termin.pacijent,
        lijek_id__in=strict_equivalent_medicine_ids(termin.lijek),
        aktivno=True,
        kolicina__gt=0,
    )
    reservations = list(
        base_reservations.filter(termin=termin).order_by("datum_rezervacije", "id")
    )
    if not reservations:
        # Legacy duplikati nisu vezani za Termin. Koristi ih samo kada ne
        # postoji eksplicitna rezervacija tog termina; druge nevezane količine
        # mogu biti legitimno buduće pokriće pacijenta.
        reservations = list(
            base_reservations.filter(termin__isnull=True).order_by(
                "datum_rezervacije", "id"
            )
        )
    if not reservations:
        return
    required = Decimal(str(
        termin.kolicina_po_terapiji
        if termin.kolicina_po_terapiji is not None
        else termin.pacijent.doza_po_aplikaciji() or 0
    ))
    if required <= 0:
        # Stariji termini nemaju uvijek pohranjenu količinu, a pripadajući
        # protokol može biti nepotpun. U tom slučaju najstariji aktivni red je
        # izvorna rezervacija jedne doze; kasniji redovi su njeni duplikati.
        required = Decimal(str(reservations[0].kolicina or 0))
    commission_remaining = {}
    for reservation in reservations:
        if reservation.komisija_id and reservation.komisija_id not in commission_remaining:
            commission_remaining[reservation.komisija_id] = max(
                Decimal(str(reservation.komisija.preostale_doze or 0)),
                Decimal("0"),
            )
    if commission_remaining:
        # Aktivna rezervacija ne može predstavljati više od još važećeg
        # komisijskog prava. Ovo je samo gornja granica zapisa rezervacije;
        # komisijsko pravo se ovdje ne troši niti pretvara u fizičku zalihu.
        required = min(required, sum(commission_remaining.values(), Decimal("0")))
    if required <= 0:
        return
    remaining = required
    deactivated = []
    for reservation in reservations:
        quantity = Decimal(str(reservation.kolicina or 0))
        if remaining >= quantity:
            remaining -= quantity
            continue
        if remaining > 0:
            # Sačuvaj originalni red kao historijski, a kanonsku aktivnu
            # količinu vodi u novom redu vezanom za isti termin.
            reservation.aktivno = False
            reservation.napomena = (
                f"{reservation.napomena}\nDeaktivirano pri promjeni termina: "
                f"dupli/višak rezervacije ({reason})."
            ).strip()
            reservation.save(update_fields=["aktivno", "napomena"])
            PacijentRezervacija.objects.create(
                pacijent=termin.pacijent,
                lijek=termin.lijek,
                komisija=reservation.komisija,
                termin=termin,
                kolicina=remaining,
                aktivno=True,
                napomena="Kanonska rezervacija prenesena pri promjeni termina.",
            )
            deactivated.append(reservation.pk)
            remaining = Decimal("0")
            continue
        reservation.aktivno = False
        reservation.napomena = (
            f"{reservation.napomena}\nDeaktivirano pri promjeni termina: "
            f"dupli/višak rezervacije ({reason})."
        ).strip()
        reservation.save(update_fields=["aktivno", "napomena"])
        deactivated.append(reservation.pk)
    if deactivated:
        upisi_log(
            user,
            "Usklađene rezervacije nakon promjene termina",
            pacijent=termin.pacijent,
            objekat=termin,
            opis=(
                f"Zadržana je jedna efektivna rezervacija od {required:g}; "
                f"deaktivirani historijski redovi: {', '.join(map(str, deactivated))}. "
                f"Razlog: {reason}"
            ),
        )


@transaction.atomic
def cancel_therapy(*, termin, reason, user=None):
    termin = select_for_update_self(
        Termin.objects.select_related("pacijent", "lijek")
    ).get(pk=termin.pk)
    if termin.status not in {
        Termin.STATUS_PLANIRANA,
        Termin.STATUS_ODGODJENA,
        Termin.STATUS_PAUSIRANA,
    }:
        raise ValueError("Ovaj termin nije moguće otkazati iz trenutnog statusa.")
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("Unesite razlog otkazivanja terapije.")
    old = _appointment_state(termin)
    _debug_reservations_for_appointment(termin)
    changed = _change_appointment_status(
        termin,
        status=Termin.STATUS_OTKAZANA,
        reason=reason,
        user=user,
        old_state=old,
        new_state=_appointment_state(
            termin,
            status=Termin.STATUS_OTKAZANA,
        ),
        event_type=TerapijaStatusHistorija.DOGADJAJ_TERMIN_OTKAZAN,
    )
    _debug_reservations_for_appointment(changed)
    return changed


@transaction.atomic
def pause_patient_therapy(*, pacijent, start_date, reason, user=None, planned_end_date=None):
    pacijent = Pacijent.objects.select_for_update().get(pk=pacijent.pk)
    if pacijent.pauze_terapije.filter(aktivna=True).exists():
        raise ValueError("Pacijent već ima aktivnu pauzu terapije.")
    if planned_end_date and planned_end_date < start_date:
        raise ValueError("Planirani završetak pauze ne može biti prije početka pauze.")
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("Unesite razlog privremene pauze.")
    pause = PauzaTerapije.objects.create(
        pacijent=pacijent,
        datum_pocetka=start_date,
        planirani_datum_zavrsetka=planned_end_date,
        razlog=reason,
        kreirao=_audit_user(user),
    )
    appointments = list(
        Termin.objects.select_for_update().filter(
            pacijent=pacijent,
            status=Termin.STATUS_PLANIRANA,
            datum__gte=start_date,
        )
    )
    previous_appointments = [_appointment_state(item) for item in appointments]
    for appointment in appointments:
        appointment.status = Termin.STATUS_PAUSIRANA
        appointment.save(update_fields=["status"])
    record_status_history(
        pacijent=pacijent,
        termin=appointments[0] if len(appointments) == 1 else None,
        new_status=Termin.STATUS_PAUSIRANA,
        reason=reason,
        user=user,
        previous_state={"termini": previous_appointments},
        new_state={
            "datum_pocetka": start_date.isoformat(),
            "planirani_kraj": (
                planned_end_date.isoformat() if planned_end_date else None
            ),
            "termini": [
                _appointment_state(item, status=Termin.STATUS_PAUSIRANA)
                for item in appointments
            ],
        },
        event_type=TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_PAUSIRANA,
    )
    upisi_log(user, "Privremena pauza terapije", pacijent=pacijent, objekat=pause, opis=reason)
    return pause


@transaction.atomic
def resume_patient_therapy(*, pacijent, resume_date, reason, user=None):
    pacijent = Pacijent.objects.select_for_update().get(pk=pacijent.pk)
    pause = pacijent.pauze_terapije.select_for_update().filter(aktivna=True).first()
    if not pause:
        raise ValueError("Pacijent nema aktivnu pauzu koju je moguće završiti.")
    if resume_date < pause.datum_pocetka:
        raise ValueError("Datum nastavka ne može biti prije početka pauze.")
    pause.aktivna = False
    pause.datum_nastavka = resume_date
    pause.zavrsio = _audit_user(user)
    pause.save(update_fields=["aktivna", "datum_nastavka", "zavrsio"])
    paused = list(Termin.objects.select_for_update().filter(pacijent=pacijent, status=Termin.STATUS_PAUSIRANA))
    previous_appointments = [_appointment_state(item) for item in paused]
    for appointment in paused:
        if appointment.datum < resume_date:
            appointment.datum = resume_date
        appointment.status = Termin.STATUS_PLANIRANA
        appointment.save(update_fields=["status", "datum"])
    record_status_history(
        pacijent=pacijent,
        termin=paused[0] if len(paused) == 1 else None,
        new_status=Termin.STATUS_PLANIRANA,
        reason=(reason or "Terapija nastavljena.").strip(),
        user=user,
        previous_status=Termin.STATUS_PAUSIRANA,
        previous_state={"termini": previous_appointments},
        new_state={
            "datum_nastavka": resume_date.isoformat(),
            "termini": [
                _appointment_state(item, status=Termin.STATUS_PLANIRANA)
                for item in paused
            ],
        },
        event_type=TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_NASTAVLJENA,
    )
    upisi_log(user, "Nastavak terapije nakon pauze", pacijent=pacijent, objekat=pause, opis=reason or "Terapija nastavljena.")
    return pause


@transaction.atomic
def schedule_therapy_appointment(
    *,
    pacijent,
    lijek,
    datum,
    vrijeme,
    user=None,
    reason="Novi termin zakazan.",
    allow_demo_weekend=False,
    kolicina_po_terapiji=None,
    validation_today=None,
):
    """Idempotentno zakaži aktivan termin i zapiši jedan domenski događaj."""

    pacijent = Pacijent.objects.select_for_update().get(pk=pacijent.pk)
    if lijek.oralna_terapija:
        raise ValueError(
            "Oralna terapija se evidentira stvarnim izdavanjem tableta; "
            "terapijski termin se ne kreira."
        )
    if pacijent.na_aktivnoj_pauzi():
        raise ValueError(
            "Pacijent je na privremenoj pauzi i ne može dobiti novi termin."
        )
    from .scheduling import (
        DEMO_WEEKEND_AUDIT_MESSAGE,
        DEMO_WEEKEND_PERMISSION_MESSAGE,
        WEEKEND_MESSAGE,
        demo_weekend_appointments_enabled,
        user_can_create_demo_weekend_appointment,
        validate_new_active_appointment_date,
        validate_therapy_date,
    )

    is_weekend = datum.weekday() >= 5
    demo_weekend_allowed = bool(
        is_weekend
        and allow_demo_weekend
        and user_can_create_demo_weekend_appointment(user)
    )
    if is_weekend and not demo_weekend_allowed:
        if allow_demo_weekend and demo_weekend_appointments_enabled():
            raise ValueError(DEMO_WEEKEND_PERMISSION_MESSAGE)
        raise ValueError(WEEKEND_MESSAGE)
    try:
        validate_therapy_date(
            datum,
            lijek=lijek,
            protokol=pacijent.aktivni_protokol(),
            allow_demo_weekend=demo_weekend_allowed,
        )
    except ValidationError as exc:
        raise ValueError(exc.messages[0]) from exc
    try:
        validate_new_active_appointment_date(datum, today=validation_today)
    except ValidationError as exc:
        raise ValueError(exc.messages[0]) from exc
    if pacijent.trenutni_korak_je_kucna_terapija():
        raise ValueError(
            "Pacijent je na kućnoj terapiji. Novi ambulantni termin se može "
            "zakazati tek nakon kontrolisanog povratka na ambulantnu primjenu."
        )
    existing = Termin.objects.select_for_update().filter(
        pacijent=pacijent,
        lijek=lijek,
        datum=datum,
        vrijeme=vrijeme,
        status=Termin.STATUS_PLANIRANA,
    ).order_by("id").first()
    if existing:
        if (
            kolicina_po_terapiji is not None
            and existing.kolicina_po_terapiji is None
        ):
            existing.kolicina_po_terapiji = Decimal(str(kolicina_po_terapiji))
            existing.save(update_fields=["kolicina_po_terapiji"])
        return existing, False

    if kolicina_po_terapiji is None:
        kolicina_po_terapiji = pacijent.doza_po_aplikaciji()
    kolicina_po_terapiji = Decimal(str(kolicina_po_terapiji or 0))

    termin = Termin(
        pacijent=pacijent,
        lijek=lijek,
        datum=datum,
        vrijeme=vrijeme,
        kolicina_po_terapiji=(
            kolicina_po_terapiji if kolicina_po_terapiji > 0 else None
        ),
        status=Termin.STATUS_PLANIRANA,
    )
    # Model validacija ostaje stroga za sve obične i automatske upise. Samo
    # ovaj eksplicitni, autorizovani ručni demo put dobija privremeni marker;
    # sva polja se i dalje validiraju, a marker se nikada ne sprema u bazu.
    termin._allow_demo_weekend_validation = demo_weekend_allowed
    try:
        termin.full_clean()
    finally:
        delattr(termin, "_allow_demo_weekend_validation")
    termin.save()
    record_status_history(
        pacijent=pacijent,
        termin=termin,
        new_status=Termin.STATUS_PLANIRANA,
        reason=(DEMO_WEEKEND_AUDIT_MESSAGE if demo_weekend_allowed else reason),
        user=user,
        new_state=_appointment_state(termin),
        event_type=TerapijaStatusHistorija.DOGADJAJ_NOVI_TERMIN,
    )
    upisi_log(
        user,
        "Zakazan novi termin terapije",
        pacijent=pacijent,
        objekat=termin,
        opis=(DEMO_WEEKEND_AUDIT_MESSAGE if demo_weekend_allowed else reason),
    )
    return termin, True


def _is_admin(user):
    from dashboard.permissions import je_koordinator_ili_admin

    return je_koordinator_ili_admin(user)


@transaction.atomic
def void_therapy(*, terapija, reason, user):
    if not _is_admin(user):
        raise PermissionError(
            "Samo administrator ili koordinator biološke terapije može "
            "poništiti evidentiranu terapiju."
        )
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("Razlog poništavanja je obavezan.")
    terapija = select_for_update_self(
        Terapija.objects.select_related("pacijent", "lijek")
    ).get(pk=terapija.pk)
    Pacijent.objects.select_for_update().get(pk=terapija.pacijent_id)
    if terapija.workflow_status == Terapija.STATUS_PONISTENA or terapija.ponistena_at:
        raise ValueError("Terapija je već poništena.")
    snapshot = terapija.workflow_snapshot or {}
    is_home_issuance = snapshot.get("vrsta") == "KUCNO_IZDAVANJE"
    is_home_application = snapshot.get("vrsta") == "KUCNA_PRIMJENA"
    if (not is_home_issuance and not snapshot.get("termin_id")) or "zaliha_kolicina" not in snapshot:
        raise ValueError("Terapija nema pouzdan workflow snapshot i ne može se automatski poništiti.")

    quantity = Decimal(str(snapshot["zaliha_kolicina"]))
    stock = Zaliha.objects.select_for_update().get(lijek=terapija.lijek)
    if not is_home_application:
        stock.u_frizideru = Decimal(str(stock.u_frizideru or 0)) + quantity
    if is_home_issuance:
        stock.kod_pacijenata = max(Decimal("0"), Decimal(str(stock.kod_pacijenata or 0)) - quantity)
    elif is_home_application:
        stock.kod_pacijenata = Decimal(str(stock.kod_pacijenata or 0)) + quantity
    stock.save(update_fields=["u_frizideru", "kod_pacijenata", "ukupno"])

    for item in snapshot.get("komisijske_promjene", []):
        commission = Komisija.objects.select_for_update().get(pk=item["komisija_id"])
        commission.preostale_doze = Decimal(str(commission.preostale_doze or 0)) + Decimal(str(item["kolicina"]))
        commission.status = "AKTIVNA"
        commission.save(update_fields=["preostale_doze", "status"])

    for item in snapshot.get("zaduzenja_promjene", []):
        assignment = PacijentZaduzenje.objects.select_for_update().get(pk=item["zaduzenje_id"])
        assignment.preostalo = Decimal(str(assignment.preostalo or 0)) + Decimal(str(item["kolicina"]))
        assignment.aktivno = True
        assignment.save(update_fields=["preostalo", "aktivno"])

    if is_home_issuance and snapshot.get("zaduzenje_izdavanje"):
        item = snapshot["zaduzenje_izdavanje"]
        assignment = PacijentZaduzenje.objects.select_for_update().get(pk=item["zaduzenje_id"])
        amount = Decimal(str(item["kolicina"]))
        assignment.ukupno_zaduzeno = max(Decimal("0"), Decimal(str(assignment.ukupno_zaduzeno or 0)) - amount)
        assignment.preostalo = max(Decimal("0"), Decimal(str(assignment.preostalo or 0)) - amount)
        assignment.aktivno = assignment.preostalo > 0
        assignment.save(update_fields=["ukupno_zaduzeno", "preostalo", "aktivno"])

    for reservation_item in snapshot.get("rezervacijske_promjene", []):
        reservation = PacijentRezervacija.objects.select_for_update().get(
            pk=reservation_item["rezervacija_id"]
        )
        reservation.kolicina = (
            Decimal(str(reservation.kolicina or 0))
            + Decimal(str(reservation_item["kolicina"]))
        )
        reservation.aktivno = True
        reservation.potrosena_at = None
        reservation.save(update_fields=["kolicina", "aktivno", "potrosena_at"])

    for reservation_item in snapshot.get("fazne_rezervacijske_promjene", []):
        reservation = PacijentRezervacija.objects.select_for_update().get(
            pk=reservation_item["rezervacija_id"]
        )
        reservation.kolicina = Decimal(str(reservation.kolicina or 0)) + Decimal(
            str(reservation_item["kolicina"])
        )
        reservation.aktivno = True
        reservation.potrosena_at = None
        reservation.save(update_fields=["kolicina", "aktivno", "potrosena_at"])
    next_phase_reservation_id = snapshot.get("fazna_naredna_rezervacija_id")
    if next_phase_reservation_id:
        next_phase_reservation = PacijentRezervacija.objects.select_for_update().filter(
            pk=next_phase_reservation_id
        ).first()
        if next_phase_reservation:
            next_phase_reservation.kolicina = Decimal("0")
            next_phase_reservation.aktivno = False
            next_phase_reservation.save(update_fields=["kolicina", "aktivno"])

    if not is_home_application: ZalihaTransakcija.objects.create(
        lijek=terapija.lijek,
        tip=ZalihaTransakcija.TIP_POVRAT,
        kolicina=quantity,
        datum=timezone.localdate(),
        pacijent=terapija.pacijent,
        referenca_tip="Poništena terapija",
        referenca_id=terapija.id,
        korisnik=_audit_user(user),
        napomena=f"Administrativno poništavanje terapije: {reason}",
    )

    termin = Termin.objects.select_for_update().filter(pk=snapshot.get("termin_id")).first()
    if termin:
        termin.status = Termin.STATUS_PONISTENA
        termin.save(update_fields=["status"])
    next_appointment = Termin.objects.select_for_update().filter(pk=snapshot.get("sljedeci_termin_id")).first()
    if next_appointment and next_appointment.status in {Termin.STATUS_PLANIRANA, Termin.STATUS_ODGODJENA}:
        next_appointment.status = Termin.STATUS_PONISTENA
        next_appointment.save(update_fields=["status"])

    if snapshot.get("fazni_protokol_id") and snapshot.get("fazni_state_prije"):
        from .phased_protocols import restore_protocol_state

        restore_protocol_state(
            state_id=snapshot["fazni_protokol_id"],
            snapshot=snapshot["fazni_state_prije"],
            user=user,
            reason=reason,
        )

    previous = terapija.workflow_status
    terapija.workflow_status = Terapija.STATUS_PONISTENA
    terapija.razlog_ponistavanja = reason
    terapija.ponistena_at = timezone.now()
    terapija.ponistio = user
    terapija.finansijski_status = Terapija.FINANSIJSKI_PONISTEN
    terapija.save(update_fields=["workflow_status", "razlog_ponistavanja", "ponistena_at", "ponistio", "finansijski_status"])
    record_status_history(
        pacijent=terapija.pacijent,
        termin=termin,
        terapija=terapija,
        previous_status=previous,
        new_status=Terapija.STATUS_PONISTENA,
        reason=reason,
        user=user,
        previous_state={
            "zaliha": str(
                Decimal(str(stock.u_frizideru))
                if is_home_application
                else Decimal(str(stock.u_frizideru)) - quantity
            )
        },
        new_state={"zaliha": str(stock.u_frizideru), "finansijski_status": terapija.finansijski_status},
        event_type=TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_PONISTENA,
    )
    upisi_log(user, "Poništavanje terapije", pacijent=terapija.pacijent, objekat=terapija, opis=reason)
    return terapija
