from django.db import migrations, models
import django.core.validators


def set_hyrimoz_package_size(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    Lijek.objects.filter(naziv__iexact="Hyrimoz").update(package_size_in_doses=2)
    Lijek.objects.filter(zasticeno_ime__iexact="Hyrimoz").update(package_size_in_doses=2)


class Migration(migrations.Migration):
    dependencies = [("patients", "0050_terapija_evidentirao_terapija_finansijama_predao_and_more")]

    operations = [
        migrations.AddField(
            model_name="lijek",
            name="package_size_in_doses",
            field=models.PositiveIntegerField(
                default=1,
                validators=[django.core.validators.MinValueValidator(1)],
                verbose_name="Veličina pakovanja u dozama",
            ),
        ),
        migrations.RunPython(set_hyrimoz_package_size, migrations.RunPython.noop),
    ]
