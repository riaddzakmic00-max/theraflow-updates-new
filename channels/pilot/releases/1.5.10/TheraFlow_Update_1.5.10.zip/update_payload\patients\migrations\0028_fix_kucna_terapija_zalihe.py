from django.db import migrations


def fix_kucna_terapija_zalihe(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    Zaliha = apps.get_model("patients", "Zaliha")

    Lijek.objects.filter(naziv__iexact="Remsima").update(
        kucna_primjena=False,
        nacin_primjene="AMBULANTA",
    )
    Lijek.objects.filter(naziv__iexact="Entyvio").update(
        kucna_primjena=False,
        nacin_primjene="AMBULANTA",
    )
    Lijek.objects.filter(naziv__iexact="Adalimumab").update(
        kucna_primjena=True,
        nacin_primjene="KUCNA_TERAPIJA",
    )

    kucni_lijekovi = Lijek.objects.filter(
        kucna_primjena=True,
        nacin_primjene="KUCNA_TERAPIJA",
    ).values_list("id", flat=True)
    Zaliha.objects.exclude(lijek_id__in=kucni_lijekovi).update(kod_pacijenata=0)


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0027_zaliha_lokacije"),
    ]

    operations = [
        migrations.RunPython(fix_kucna_terapija_zalihe, migrations.RunPython.noop),
    ]
