from django.db.models import Prefetch


def with_workflow_data(queryset):
    """UÄŤitaj read-only workflow relacije u stalnom broju SQL upita."""
    from .models import (
        IndividualniKorakProtokola,
        Komisija,
        PacijentRezervacija,
        PacijentZaduzenje,
        PauzaTerapije,
        PotrebaFizickogPokrica,
        Terapija,
        TerapijskiKorakProtokola,
        Termin,
        Trebovanje,
        ZalihaTransakcija,
    )

    return queryset.select_related(
        "lijek",
        "lijek__terapijski_program",
        "lijek__logisticke_postavke",
        "terapijski_program",
        "terapijski_protokol",
        "individualni_protokol",
        "individualni_protokol__standardni_protokol",
        "migracijski_snapshot",
        "fazni_protokol",
        "fazni_protokol__trenutna_faza",
        "fazni_protokol__iv_lijek",
        "fazni_protokol__sc_lijek",
    ).prefetch_related(
        Prefetch(
            "terapijski_protokol__koraci",
            queryset=TerapijskiKorakProtokola.objects.filter(aktivan=True).order_by(
                "faza", "redoslijed", "sedmica_od_pocetka", "id"
            ),
            to_attr="_workflow_steps",
        ),
        Prefetch(
            "individualni_protokol__koraci",
            queryset=IndividualniKorakProtokola.objects.order_by(
                "faza", "redoslijed", "sedmica_od_pocetka", "id"
            ),
            to_attr="_workflow_steps",
        ),
        Prefetch(
            "terapija_set",
            queryset=Terapija.objects.exclude(workflow_status="PONISTENA").order_by(
                "-datum", "-id"
            ),
            to_attr="_workflow_therapies",
        ),
        Prefetch(
            "komisija_set",
            queryset=Komisija.objects.filter(
                status__in=("AKTIVNA", "BUDUCA", "ODOBRENA"),
                preostale_doze__gt=0,
            ).order_by("datum_odobrenja", "id"),
            to_attr="_workflow_commissions",
        ),
        Prefetch(
            "pacijentzaduzenje_set",
            queryset=PacijentZaduzenje.objects.filter(
                aktivno=True, preostalo__gt=0
            ).order_by("id"),
            to_attr="_workflow_assignments",
        ),
        Prefetch(
            "rezervacije_lijeka",
            queryset=PacijentRezervacija.objects.filter(
                aktivno=True, kolicina__gt=0
            ).select_related("komisija", "trebovanje").order_by(
                "datum_rezervacije", "id"
            ),
            to_attr="_workflow_reservations",
        ),
        Prefetch(
            "pauze_terapije",
            queryset=PauzaTerapije.objects.filter(aktivna=True).order_by(
                "-datum_pocetka", "-id"
            ),
            to_attr="_workflow_pauses",
        ),
        Prefetch(
            "potrebe_fizickog_pokrica",
            queryset=PotrebaFizickogPokrica.objects.filter(
                status=PotrebaFizickogPokrica.STATUS_CEKA,
                preostala_kolicina__gt=0,
            ),
            to_attr="_workflow_physical_needs",
        ),
        Prefetch(
            "trebovanje_set",
            queryset=Trebovanje.objects.filter(
                status__in=(
                    "U_PRIPREMI",
                    "PREDATO",
                    "ODOBRENO",
                    "ZAPRIMLJENO",
                    Trebovanje.STATUS_NACRT,
                    Trebovanje.STATUS_SPREMAN,
                    Trebovanje.STATUS_POSLAN_KOMISIJI,
                    Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
                    Trebovanje.STATUS_CEKA_ISPORUKU,
                )
            ).order_by("-datum_kreiranja", "-id"),
            to_attr="_workflow_requests",
        ),
        Prefetch(
            "zaliha_transakcije",
            queryset=ZalihaTransakcija.objects.filter(
                tip=ZalihaTransakcija.TIP_ZAPRIMANJE
            ).order_by("-datum", "-id"),
            to_attr="_workflow_receipts",
        ),
        Prefetch(
            "termin_set",
            queryset=Termin.objects.filter(
                status=Termin.STATUS_PLANIRANA,
            ).order_by(
                "datum", "vrijeme", "id"
            ),
            to_attr="_workflow_appointments",
        ),
    )
