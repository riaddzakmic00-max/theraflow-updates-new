import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

from .plan_loader import PlanValidationError, safe_relative, sha256_file


class SnapshotError(RuntimeError):
    pass


class FileInstallError(RuntimeError):
    pass


def _target(root, relative, label):
    relative = safe_relative(relative, label)
    target = (Path(root).resolve() / Path(*relative.parts)).resolve()
    root = Path(root).resolve()
    if root not in target.parents:
        raise PlanValidationError(f"{label} izlazi iz application root direktorija.")
    return target


def _copy_snapshot(source, destination, entries, app_root):
    if source.is_symlink():
        raise SnapshotError("Snapshot ne prati simboličke linkove.")
    if source.is_dir():
        destination.mkdir(parents=True, exist_ok=True)
        for child in source.iterdir():
            if child.name in {"__pycache__", ".git"}:
                continue
            _copy_snapshot(child, destination / child.name, entries, app_root)
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination, follow_symlinks=False)
    relative = source.relative_to(app_root).as_posix()
    entries.append({
        "original_path": relative,
        "snapshot_path": relative,
        "size_bytes": destination.stat().st_size,
        "sha256": sha256_file(destination),
        "created_at": datetime.now(timezone.utc).isoformat(),
    })


def create_snapshot(plan, service_config=""):
    app = Path(plan["application_root"]).resolve()
    backup = Path(plan["backup_root"]).resolve()
    snapshot = backup / "application_snapshot"
    if snapshot.exists():
        raise SnapshotError("Application snapshot već postoji.")
    snapshot.mkdir(parents=True)
    preserved = {PurePosixPath(item).parts[0] for item in plan["preserve_paths"]}
    names = set(plan["replace_paths"]) | {"manage.py", "theraflow"}
    if plan.get("collectstatic_required"):
        names.add("staticfiles")
    entries = []
    try:
        for relative in sorted(names):
            top = PurePosixPath(relative).parts[0]
            if top in preserved and top != "staticfiles":
                continue
            source = _target(app, relative, "Snapshot putanja")
            if source.exists():
                _copy_snapshot(source, snapshot / Path(*PurePosixPath(relative).parts), entries, app)
        if service_config:
            (snapshot / "service_config.txt").write_text(service_config[:20000], encoding="utf-8")
        manifest = {
            "created_at": datetime.now(timezone.utc).isoformat(),
            "session_id": plan["session_id"],
            "source_version": plan["current_version"],
            "files": entries,
        }
        manifest_path = backup / "application_snapshot_manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
        for entry in entries:
            candidate = snapshot / Path(*PurePosixPath(entry["snapshot_path"]).parts)
            if not candidate.is_file() or sha256_file(candidate) != entry["sha256"]:
                raise SnapshotError("Application snapshot validacija nije uspjela.")
        return snapshot, manifest_path
    except Exception:
        shutil.rmtree(snapshot, ignore_errors=True)
        raise


def _atomic_copy(source, target):
    if source.is_symlink() or target.is_symlink():
        raise FileInstallError("Simbolički link nije dozvoljen tokom instalacije.")
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.update-{os.getpid()}.tmp")
    try:
        with source.open("rb") as incoming, temporary.open("wb") as outgoing:
            shutil.copyfileobj(incoming, outgoing, 1024 * 1024)
            outgoing.flush()
            os.fsync(outgoing.fileno())
        shutil.copystat(source, temporary, follow_symlinks=False)
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)


def quarantine_deletes(plan):
    app = Path(plan["application_root"]).resolve()
    quarantine = Path(plan["backup_root"]).resolve() / "quarantine"
    moved = []
    for relative in plan["delete_paths"]:
        source = _target(app, relative, "Delete putanja")
        if not source.exists():
            continue
        destination = quarantine / Path(*PurePosixPath(relative).parts)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            raise FileInstallError("Quarantine cilj već postoji.")
        shutil.move(str(source), str(destination))
        moved.append({"original_path": relative, "quarantine_path": destination.relative_to(quarantine).as_posix()})
    if moved:
        (quarantine / "quarantine_manifest.json").write_text(json.dumps({"files": moved}, indent=2), encoding="utf-8")
    return moved


def install_payload(plan):
    payload = Path(plan["payload_root"]).resolve()
    app = Path(plan["application_root"]).resolve()
    preserved = {PurePosixPath(item).parts[0] for item in plan["preserve_paths"]}
    installed = []
    quarantine_deletes(plan)
    for source in payload.rglob("*"):
        if source.is_dir():
            continue
        relative = source.relative_to(payload)
        if relative.parts[0] in preserved:
            raise FileInstallError("Payload pokušava prepisati preserved putanju.")
        target = _target(app, relative.as_posix(), "Install cilj")
        _atomic_copy(source, target)
        installed.append(relative.as_posix())
    return installed
