from decimal import Decimal

from django.db import migrations


SUPPORTED_PRESENTATIONS = (
    (
        "Uzpruvo 130 mg IV",
        {
            "genericki_naziv": "Ustekinumab",
            "zasticeno_ime": "Uzpruvo",
            "jacina_mg": Decimal("130"),
            "put_primjene": "IV",
            "nacin_primjene": "AMBULANTA",
            "kucna_primjena": False,
            "package_size_in_doses": 1,
            "jedinica_terapije": "bočica",
            "jedinica_terapije_mnozina": "bočice",
            "jedinica_zalihe": "bočica",
            "jedinica_zalihe_mnozina": "bočice",
            "aktivan": True,
        },
    ),
    (
        "Uzpruvo 90 mg SC",
        {
            "genericki_naziv": "Ustekinumab",
            "zasticeno_ime": "Uzpruvo",
            "jacina_mg": Decimal("90"),
            "put_primjene": "SC",
            "nacin_primjene": "AMBULANTA",
            "kucna_primjena": False,
            "package_size_in_doses": 1,
            "jedinica_terapije": "šprica",
            "jedinica_terapije_mnozina": "šprice",
            "jedinica_zalihe": "šprica",
            "jedinica_zalihe_mnozina": "šprice",
            "aktivan": True,
        },
    ),
    (
        "Xeljanz 5 mg",
        {
            "genericki_naziv": "Tofacitinib",
            "zasticeno_ime": "Xeljanz",
            "jacina_mg": Decimal("5"),
            "put_primjene": "PO",
            "farmaceutski_oblik": "TABLETA",
            "nacin_primjene": "ORALNA_TERAPIJA",
            "kucna_primjena": False,
            "broj_tableta_u_pakovanju": 56,
            "izdavanje_cijelih_pakovanja": True,
            "package_size_in_doses": 56,
            "jedinica_terapije": "tableta",
            "jedinica_terapije_mnozina": "tablete",
            "jedinica_zalihe": "tableta",
            "jedinica_zalihe_mnozina": "tablete",
            "aktivan": True,
        },
    ),
    (
        "Entecavir 0.5 mg",
        {
            "genericki_naziv": "Entecavir",
            "zasticeno_ime": "Entecavir",
            "jacina_mg": Decimal("0.5"),
            "put_primjene": "PO",
            "farmaceutski_oblik": "TABLETA",
            "nacin_primjene": "ORALNA_TERAPIJA",
            "kucna_primjena": False,
            "broj_tableta_u_pakovanju": 30,
            "izdavanje_cijelih_pakovanja": True,
            "package_size_in_doses": 30,
            "jedinica_terapije": "tableta",
            "jedinica_terapije_mnozina": "tablete",
            "jedinica_zalihe": "tableta",
            "jedinica_zalihe_mnozina": "tablete",
            "aktivan": True,
        },
    ),
    (
        "Tenofovir 245 mg",
        {
            "genericki_naziv": "Tenofovir disoproxil",
            "zasticeno_ime": "Tenofovir",
            "jacina_mg": Decimal("245"),
            "put_primjene": "PO",
            "farmaceutski_oblik": "TABLETA",
            "nacin_primjene": "ORALNA_TERAPIJA",
            "kucna_primjena": False,
            "broj_tableta_u_pakovanju": 30,
            "izdavanje_cijelih_pakovanja": True,
            "package_size_in_doses": 30,
            "jedinica_terapije": "tableta",
            "jedinica_terapije_mnozina": "tablete",
            "jedinica_zalihe": "tableta",
            "jedinica_zalihe_mnozina": "tablete",
            "aktivan": True,
        },
    ),
)


def seed_supported_presentations(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    for name, defaults in SUPPORTED_PRESENTATIONS:
        # Add only missing canonical rows. Existing rows, including an explicitly
        # deactivated one, are deliberately not rewritten or reactivated.
        Lijek.objects.get_or_create(naziv=name, defaults=defaults)


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0079_oral_therapy_phase5"),
    ]

    operations = [
        migrations.RunPython(
            seed_supported_presentations,
            migrations.RunPython.noop,
        ),
    ]
