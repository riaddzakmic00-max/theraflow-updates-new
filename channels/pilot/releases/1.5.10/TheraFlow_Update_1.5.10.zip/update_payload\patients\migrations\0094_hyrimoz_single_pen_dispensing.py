from django.db import migrations


def allow_hyrimoz_single_pen_dispensing(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    hyrimoz = Lijek.objects.filter(zasticeno_ime__iexact="Hyrimoz")
    if not hyrimoz.exists():
        hyrimoz = Lijek.objects.filter(naziv__icontains="Hyrimoz")
    hyrimoz.update(
        package_size_in_doses=2,
        izdavanje_cijelih_pakovanja=False,
    )


class Migration(migrations.Migration):
    dependencies = [
        ("patients", "0093_hyrimoz_whole_package_dispensing"),
    ]

    operations = [
        migrations.RunPython(
            allow_hyrimoz_single_pen_dispensing,
            migrations.RunPython.noop,
        ),
    ]
