import hashlib
import logging
import os
import socket
import shutil
from pathlib import Path
from urllib import error, request
from urllib.parse import urlparse

from packaging.version import InvalidVersion

from theraflow.version import validate_version_identifier
from updates.updater.state_writer import trace_update_step

from .update_checker import ManifestValidationError, validate_manifest
from .update_paths import get_update_paths


logger = logging.getLogger(__name__)
CHUNK_SIZE = 1024 * 1024
SPACE_RESERVE = 50 * 1024 * 1024


def _result(status, message, path=None):
    return {"status": status, "message": message, "path": str(path) if path else None}


def _sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_paths(version, destination=None):
    try:
        safe_version = validate_version_identifier(version)
    except InvalidVersion as exc:
        raise ValueError("Neispravna verzija update paketa.") from exc
    root = Path(destination or get_update_paths().packages).resolve()
    root.mkdir(parents=True, exist_ok=True)
    final_path = (root / f"TheraFlow_Update_{safe_version}.zip").resolve()
    part_path = (root / f"TheraFlow_Update_{safe_version}.zip.part").resolve()
    lock_path = (root / f"TheraFlow_Update_{safe_version}.lock").resolve()
    if any(path.parent != root for path in (final_path, part_path, lock_path)):
        raise ValueError("Neispravna putanja update paketa.")
    return root, final_path, part_path, lock_path


def download_update(manifest, *, destination=None, opener=None, disk_usage=None):
    if not isinstance(manifest, dict) or not manifest.get("version") or not manifest.get("download_url") or not manifest.get("sha256"):
        trace_update_step(3, "FAIL", function_name="download_update", exception=ValueError("Validirani manifest nije dostupan."), exit_code=1)
        return _result("error", "Validirani manifest nije dostupan.")
    trace_session = str(manifest.get("version") or "download")
    url = str(manifest["download_url"])
    if urlparse(url).scheme.lower() != "https":
        trace_update_step(3, "FAIL", session_id=trace_session, function_name="download_update", paths={"download_url": url}, exception=ValueError("Download URL mora koristiti HTTPS."), exit_code=1)
        return _result("invalid_url", "Download URL mora koristiti HTTPS.")
    try:
        manifest = validate_manifest(manifest)
    except ManifestValidationError:
        trace_update_step(3, "FAIL", session_id=trace_session, function_name="download_update", exception=ValueError("Validirani manifest nije dostupan."), exit_code=1)
        return _result("error", "Validirani manifest nije dostupan.")
    expected_hash = manifest["sha256"]
    active_step = 3
    trace_update_step(3, "START", session_id=trace_session, function_name="download_update", paths={"download_url": url, "destination": destination or "default"})
    try:
        root, final_path, part_path, lock_path = _safe_paths(manifest["version"], destination)
        if final_path.exists():
            if _sha256(final_path) == expected_hash:
                trace_update_step(3, "PASS", session_id=trace_session, function_name="download_update", paths={"package": final_path}, message="Paket je već preuzet.", exit_code=0)
                trace_update_step(4, "PASS", session_id=trace_session, function_name="download_update", paths={"package": final_path}, message=f"sha256={expected_hash}", exit_code=0)
                return _result("already_downloaded", "Paket je već preuzet i provjeren.", final_path)
            final_path.unlink()
        try:
            lock_fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(lock_fd)
        except FileExistsError:
            return _result("download_error", "Preuzimanje ovog paketa je već u toku.")
        logger.info("Početak preuzimanja TheraFlow update paketa verzije %s.", manifest["version"])
        opener = opener or request.urlopen
        disk_usage = disk_usage or shutil.disk_usage
        req = request.Request(url, headers={"Accept": "application/zip"})
        try:
            with opener(req, timeout=30) as response:
                if getattr(response, "status", 200) != 200:
                    raise error.HTTPError(url, response.status, "HTTP greška", response.headers, None)
                length_header = response.headers.get("Content-Length") if response.headers else None
                content_length = int(length_header) if length_header else 0
                required = content_length + max(SPACE_RESERVE, content_length // 10)
                if disk_usage(root).free < required:
                    trace_update_step(3, "FAIL", session_id=trace_session, function_name="download_update", paths={"package": final_path}, exception=OSError("Nema dovoljno slobodnog prostora za update paket."), exit_code=1)
                    return _result("insufficient_space", "Nema dovoljno slobodnog prostora za update paket.")
                digest = hashlib.sha256()
                with part_path.open("wb") as target:
                    while True:
                        chunk = response.read(CHUNK_SIZE)
                        if not chunk:
                            break
                        target.write(chunk)
                        digest.update(chunk)
            actual_hash = digest.hexdigest()
            trace_update_step(3, "PASS", session_id=trace_session, function_name="download_update", paths={"package_part": part_path}, exit_code=0)
            active_step = 4
            trace_update_step(4, "START", session_id=trace_session, function_name="download_update", paths={"package_part": part_path})
            if actual_hash != expected_hash:
                part_path.unlink(missing_ok=True)
                trace_update_step(4, "FAIL", session_id=trace_session, function_name="download_update", paths={"package_part": part_path}, exception=ValueError(f"SHA256 mismatch expected={expected_hash} actual={actual_hash}"), exit_code=1)
                logger.warning("SHA-256 provjera update paketa nije uspjela.")
                return _result("checksum_failed", "SHA-256 provjera preuzetog paketa nije uspjela.")
            part_path.replace(final_path)
            trace_update_step(4, "PASS", session_id=trace_session, function_name="download_update", paths={"package": final_path}, message=f"sha256={actual_hash}", exit_code=0)
            logger.info("Update paket je preuzet; SHA-256 provjera je uspješna.")
            return _result("downloaded", "Paket je preuzet i uspješno provjeren.", final_path)
        except error.HTTPError as exc:
            part_path.unlink(missing_ok=True)
            trace_update_step(active_step, "FAIL", session_id=trace_session, function_name="download_update", paths={"package_part": part_path, "package": final_path}, exception=exc, exit_code=1)
            if exc.code == 404:
                return _result("package_not_found", "Update paket nije pronađen na serveru (HTTP 404).")
            if exc.code == 403:
                return _result("package_forbidden", "Pristup update paketu je odbijen (HTTP 403). Paket mora biti javno dostupan bez prijave.")
            return _result("package_http_error", f"Server update paketa vratio je HTTP {exc.code}.")
        except (TimeoutError, socket.timeout) as exc:
            part_path.unlink(missing_ok=True)
            trace_update_step(active_step, "FAIL", session_id=trace_session, function_name="download_update", paths={"package_part": part_path, "package": final_path}, exception=exc, exit_code=1)
            return _result("package_timeout", "Isteklo je vrijeme čekanja pri preuzimanju update paketa.")
        except error.URLError as exc:
            part_path.unlink(missing_ok=True)
            trace_update_step(active_step, "FAIL", session_id=trace_session, function_name="download_update", paths={"package_part": part_path, "package": final_path}, exception=exc, exit_code=1)
            if isinstance(exc.reason, (TimeoutError, socket.timeout)):
                return _result("package_timeout", "Isteklo je vrijeme čekanja pri preuzimanju update paketa.")
            return _result("download_error", "Update paket nije dostupan zbog mrežne ili DNS greške.")
        except Exception as exc:
            part_path.unlink(missing_ok=True)
            trace_update_step(active_step, "FAIL", session_id=trace_session, function_name="download_update", paths={"package_part": part_path, "package": final_path}, exception=exc, exit_code=getattr(exc, "returncode", 1))
            logger.warning("Preuzimanje update paketa nije uspjelo: %s", type(exc).__name__)
            return _result("download_error", "Preuzimanje update paketa nije uspjelo.")
        finally:
            lock_path.unlink(missing_ok=True)
    except ValueError as exc:
        trace_update_step(active_step, "FAIL", session_id=trace_session, function_name="download_update", exception=exc, exit_code=1)
        return _result("error", str(exc))
    except Exception as exc:
        trace_update_step(active_step, "FAIL", session_id=trace_session, function_name="download_update", exception=exc, exit_code=getattr(exc, "returncode", 1))
        logger.exception("Neočekivana greška pri preuzimanju update paketa.")
        return _result("error", "Preuzimanje update paketa nije uspjelo.")
