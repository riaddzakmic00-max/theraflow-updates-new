import json
import time
from urllib import request


class HealthCheckError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def check(url, target_version, attempts=15, delay=2, timeout=3, opener=None):
    if not url.startswith("http://127.0.0.1:") and not url.startswith("http://localhost:"):
        raise HealthCheckError("health_check_failed", "Health check mora koristiti localhost.")
    opener = opener or request.urlopen
    last_code = "health_check_timeout"
    for attempt in range(attempts):
        try:
            with opener(url, timeout=timeout) as response:
                if getattr(response, "status", 200) != 200:
                    last_code = "health_check_failed"
                else:
                    payload = json.loads(response.read().decode("utf-8"))
                    if payload.get("database") != "ok":
                        raise HealthCheckError("database_unavailable", "Baza nije dostupna.")
                    if payload.get("version") != target_version:
                        raise HealthCheckError("version_mismatch", "Aktivna verzija ne odgovara ciljnoj verziji.")
                    if payload.get("backup_scheduler") not in {None, "ok"}:
                        raise HealthCheckError(
                            "backup_scheduler_unavailable",
                            "Automatski backup scheduler nije aktivan.",
                        )
                    if payload.get("status") != "ok":
                        raise HealthCheckError("health_check_failed", "Health schema nije ispravna.")
                    return payload
        except HealthCheckError as exc:
            last_code = exc.code
        except Exception:
            last_code = "health_check_timeout"
        if attempt + 1 < attempts:
            time.sleep(delay)
    raise HealthCheckError(last_code, "TheraFlow health check nije uspio u dozvoljenom roku.")
