from datetime import time, timedelta
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from .individual_protocols import persistable_standard_step
from .medication_groups import medicine_group_q
from .models import (
    Komisija,
    KomisijskiCiklus,
    KucnoIzdavanje,
    Lijek,
    Pacijent,
    PacijentZaduzenje,
    Terapija,
    TerapijskiKorakProtokola,
    Termin,
    Trebovanje,
    Zaliha,
)
from .reset_test_data import DEMO_EVENT_MARKER, reset_demo_data
from .commission_service import approve_cycle, complete_cycle, mark_requests_sent
from .package_sizes import round_up_to_package
from .scheduling import adjust_to_allowed_therapy_date
from .services import confirm_therapy_arrival
from .utils import upisi_log


DEMO_JMBG_PREFIX = "990"
DEMO_MEDICINES = ["Entyvio", "Remsima", "Adalimumab"]


FIRST_NAMES = [
    "Amir", "Lejla", "Nermin", "Amina", "Edin", "Selma", "Haris", "Maja",
    "Kenan", "Azra", "Dino", "Emina", "Tarik", "Sara", "Adnan", "Jasmina",
    "Faruk", "Nedim", "Naida", "Lamija", "Mirza", "Alma", "Semir", "Ilda",
    "Armin", "Sanela", "Emir", "Nejra", "Benjamin", "Hana",
]

LAST_NAMES = [
    "Hadzic", "Delic", "Mesic", "Kovacevic", "Hodzic", "Begovic", "Alic",
    "Spahic", "Imamovic", "Halilovic", "Softic", "Mujkic", "Begic",
    "Saric", "Osmanovic", "Basic", "Lazic", "Mahmutovic", "Cengic", "Buric",
]

DIAGNOSES = [
    ("Colitis ulcerosa", "K51.9"),
    ("Morbus Crohn", "K50.9"),
]


def existing_demo_patients_count():
    return Pacijent.objects.filter(jmbg__startswith=DEMO_JMBG_PREFIX).count()


def _find_demo_medicines():
    medicines = {}
    missing = []

    for name in DEMO_MEDICINES:
        medicine = Lijek.objects.filter(medicine_group_q(name)).first()

        if not medicine or not medicine.aktivni_protokol():
            missing.append(name)
            continue

        medicines[name] = medicine

    return medicines, missing


def _fake_jmbg(index):
    return f"{DEMO_JMBG_PREFIX}{index:010d}"[:13]


def _patient_phase(index):
    if index % 5 in [0, 1]:
        return Pacijent.FAZA_INDUKCIJA
    return Pacijent.FAZA_ODRZAVANJE


def _commission_remaining(index):
    pattern = [0, 1, 2, 3, 4, 6, 8]
    return Decimal(str(pattern[index % len(pattern)]))


def _explicit_protocol_steps(patient):
    protocol = patient.aktivni_protokol()
    if not protocol or not protocol.ima_korake():
        return []

    if patient.pocetna_faza_terapije == Pacijent.FAZA_ODRZAVANJE:
        step = protocol.korak_odrzavanja()
        return [step] if step else []

    return list(protocol.indukcijski_koraci()) + list(protocol.odrzavajuci_koraci())


def _therapy_step_for_order(patient, order_number):
    try:
        return patient.terapijski_korak_za_redni_broj(order_number)
    except Exception:
        return None


def _therapy_phase_for_order(patient, order_number):
    phased_state = patient.aktivni_fazni_protokol()
    if phased_state:
        # Terapija.faza_terapije je VARCHAR(20) machine-status polje. Nikada
        # ne upisuj korisnički label faznog protokola u ovu kolonu.
        return {
            phased_state.FAZA_CEKA_IV: Terapija.UstekinumabFaza.IV_INDUKCIJA,
            phased_state.FAZA_CEKA_PRVU_SC: Terapija.UstekinumabFaza.IV_U_SC_PRIJELAZ,
            phased_state.FAZA_ODRZAVANJE: Terapija.UstekinumabFaza.SC_ODRZAVANJE,
        }[phased_state.faza]
    step = _therapy_step_for_order(patient, order_number)
    if step and getattr(step, "faza", None):
        return step.faza
    try:
        phase = patient.terapijska_faza_za_redni_broj(order_number)
        if len(phase) <= Terapija._meta.get_field("faza_terapije").max_length:
            return phase
    except Exception:
        pass
    return (
        Pacijent.FAZA_ODRZAVANJE
        if patient.pocetna_faza_terapije == Pacijent.FAZA_ODRZAVANJE
        else Pacijent.FAZA_INDUKCIJA
    )


def _therapy_dose_for_step(step):
    if step:
        return Decimal(str(step.broj_jedinica or 1))
    return Decimal("1")


def _therapy_week_offset(patient, order_number):
    steps = _explicit_protocol_steps(patient)
    if patient.pocetna_faza_terapije == Pacijent.FAZA_ODRZAVANJE:
        protocol = patient.aktivni_protokol()
        step = protocol.korak_odrzavanja() if protocol else None
        interval = (
            step.interval_sedmica
            if step and step.interval_sedmica
            else patient.interval_sedmica or (protocol.interval_odrzavanja_sedmica if protocol else 8) or 8
        )
        return (order_number - 1) * interval

    if not steps:
        return (order_number - 1) * (patient.interval_sedmica or 8)

    index = order_number - 1
    if index < len(steps):
        step = steps[index]
        return step.sedmica_od_pocetka or 0

    repeating_step = steps[-1]
    interval = (
        repeating_step.interval_sedmica
        or patient.interval_sedmica
        or patient.aktivni_protokol().interval_odrzavanja_sedmica
        or 8
    )
    start_week = repeating_step.sedmica_od_pocetka or 0
    return start_week + ((order_number - len(steps)) * interval)


def _build_demo_therapy(*, patient, medicine, order_number, datum, serija):
    """Kreiraj neupisani demo zapis bez spremanja EffectiveProtocolStep u FK."""
    step = _therapy_step_for_order(patient, order_number)
    tip_evidencije = Terapija.TIP_AMBULANTA
    if (
        step
        and step.nacin_primjene_koraka
        == TerapijskiKorakProtokola.NACIN_KUCNA_TERAPIJA
    ):
        tip_evidencije = Terapija.TIP_KUCNA_TERAPIJA

    return Terapija(
        pacijent=patient,
        lijek=medicine,
        terapijski_korak=persistable_standard_step(step),
        datum=datum,
        serija=serija,
        kolicina=_therapy_dose_for_step(step),
        doza_mg=step.doza_mg if step else None,
        faza_terapije=_therapy_phase_for_order(patient, order_number),
        interval_sedmica=step.interval_sedmica if step and step.interval_sedmica else None,
        nuspojave="",
        laboratorija="",
        tip_evidencije=tip_evidencije,
        zakljucana=True,
    )


def _record_demo_delivery(*, patient, medicine, commission, quantity, datum, user=None):
    from dashboard.views import promijeni_zalihu

    return promijeni_zalihu(
        lijek=medicine,
        kolicina=quantity,
        korisnik=user,
        pacijent=patient,
        komisija=commission,
        referenca=commission,
        akcija="Demo zaprimanje lijeka",
        opis=(
            f"{DEMO_EVENT_MARKER} {medicine.naziv}: zaprimljeno "
            f"{quantity:g} doza za demo operativni tok."
        ),
        frizider_delta=quantity,
        tip_transakcije="ZAPRIMANJE",
        datum=datum,
    )


def _record_demo_home_issue(
    *,
    patient,
    medicine,
    commission,
    quantity,
    datum,
    sequence,
    user=None,
):
    """Evidentiraj demo kućno izdavanje kroz isti stock helper kao stvarni tok."""
    from dashboard.views import dodijeli_doze_pacijentu
    from .models import ZalihaTransakcija

    last_movement_id = (
        ZalihaTransakcija.objects.order_by("-id")
        .values_list("id", flat=True)
        .first()
        or 0
    )
    assignment = dodijeli_doze_pacijentu(
        patient,
        medicine,
        quantity,
        komisija=commission,
        korisnik=user,
    )
    commission.preostale_doze = max(
        Decimal("0"),
        Decimal(str(commission.preostale_doze or 0)) - quantity,
    )
    if commission.preostale_doze <= 0:
        commission.status = "POTROSENA"
    commission.save(update_fields=["preostale_doze", "status"])

    order_number = patient.terapija_set.count() + 1
    therapy = _build_demo_therapy(
        patient=patient,
        medicine=medicine,
        order_number=order_number,
        datum=datum,
        serija=f"DEMO-HOME-{sequence:03d}",
    )
    therapy.kolicina = quantity
    therapy.tip_evidencije = Terapija.TIP_KUCNA_TERAPIJA
    therapy.finansijski_status = Terapija.FINANSIJSKI_NIJE_KREIRAN
    therapy.workflow_snapshot = {
        "vrsta": "KUCNO_IZDAVANJE",
        "demo": True,
        "zaliha_kolicina": str(quantity),
    }
    therapy.save()
    movement = ZalihaTransakcija.objects.filter(
        id__gt=last_movement_id,
        pacijent=patient,
        lijek=medicine,
        tip=ZalihaTransakcija.TIP_KUCNO_IZDAVANJE,
    ).order_by("-id").first()
    if movement:
        movement.datum = datum
        movement.referenca_tip = "Terapija"
        movement.referenca_id = therapy.pk
        movement.napomena = (
            f"{DEMO_EVENT_MARKER} {medicine.naziv}: izdato "
            f"{quantity:g} doza za kućnu terapiju."
        )
        movement.save(
            update_fields=[
                "datum",
                "referenca_tip",
                "referenca_id",
                "napomena",
            ]
        )
    issue = KucnoIzdavanje.objects.create(
        pacijent=patient,
        lijek=medicine,
        komisija=commission,
        pacijent_zaduzenje=assignment,
        terapija=therapy,
        datum=datum,
        kolicina=quantity,
        serija=f"DEMO-HOME-{sequence:03d}",
        rok_trajanja=datum + timedelta(days=365),
        napomena=f"{DEMO_EVENT_MARKER} Realistično demo izdavanje kućne terapije.",
        korisnik_koji_je_izdao=(
            user if getattr(user, "is_authenticated", False) else None
        ),
    )
    upisi_log(
        user,
        "Demo izdavanje kućne terapije",
        pacijent=patient,
        objekat=issue,
        opis=(
            f"{DEMO_EVENT_MARKER} {medicine.naziv}: izdato "
            f"{quantity:g} doza {datum:%d/%m/%Y}."
        ),
    )
    return therapy, issue


def _schedule_demo_future_therapies(patient, *, today, horizon_days=90):
    if not patient.aktivan or not patient.lijek_id:
        return 0
    interval = max(int(patient.interval_sedmica or 1), 1)
    last_therapy = patient.zadnja_terapija()
    if last_therapy:
        next_date = last_therapy.datum + timedelta(weeks=interval)
        while next_date <= today:
            next_date += timedelta(weeks=interval)
    else:
        next_date = today + timedelta(days=3 + (patient.pk % 18))
    next_date = adjust_to_allowed_therapy_date(
        next_date,
        lijek=patient.lijek,
        protokol=patient.aktivni_protokol(),
    ).datum

    created = 0
    horizon = today + timedelta(days=horizon_days)
    while next_date <= horizon:
        _, was_created = Termin.objects.get_or_create(
            pacijent=patient,
            lijek=patient.lijek,
            datum=next_date,
            defaults={
                "vrijeme": time(8 + (patient.pk % 8), 30 if patient.pk % 2 else 0),
                "status": Termin.STATUS_PLANIRANA,
            },
        )
        created += int(was_created)
        next_date = adjust_to_allowed_therapy_date(
            next_date + timedelta(weeks=interval),
            lijek=patient.lijek,
            protokol=patient.aktivni_protokol(),
        ).datum
    return created


def generate_demo_data(
    patient_count=30,
    reset=False,
    stock=False,
    allow_existing=False,
    user=None,
):
    """Legacy 25–30 patient fixture kept for compatibility with older probes.

    The admin workflow and ``seed_demo_data`` command use Demo Dataset V2.
    New demo scenarios must not be added to this legacy generator.
    """
    patient_count = max(25, min(int(patient_count or 30), 30))
    existing_count = existing_demo_patients_count()

    if existing_count and not allow_existing and not reset:
        raise ValueError(
            "Demo pacijenti vec postoje. Potvrdite da zelite nastaviti ili prvo uradite reset testnih podataka."
        )

    medicines, missing_medicines = _find_demo_medicines()
    if not medicines:
        raise ValueError("Prvo kreirajte terapijske protokole.")

    stats = {
        "pacijenti": 0,
        "termini": 0,
        "terapije": 0,
        "komisije": 0,
        "zaduzenja": 0,
        "zalihe_promijenjene": True,
        "dokumenti": 0,
        "info": [],
        "warnings": [],
    }

    if missing_medicines:
        stats["warnings"].append(
            "Preskoceni lijekovi bez aktivnog protokola: " + ", ".join(missing_medicines)
        )

    today = timezone.localdate()
    medicine_list = list(medicines.values())
    created_patients = []
    patients_by_medicine = {medicine.pk: [] for medicine in medicine_list}

    with transaction.atomic():
        if reset:
            reset_demo_data()

        start_index = existing_demo_patients_count() + 1

        for offset in range(patient_count):
            index = start_index + offset
            medicine = medicine_list[offset % len(medicine_list)]
            diagnosis, mkb = DIAGNOSES[offset % len(DIAGNOSES)]
            phase = _patient_phase(offset)
            protocol = medicine.aktivni_protokol()

            patient = Pacijent.objects.create(
                ime=FIRST_NAMES[offset % len(FIRST_NAMES)],
                prezime=LAST_NAMES[(offset * 3) % len(LAST_NAMES)],
                jmbg=_fake_jmbg(index),
                spol="M" if offset % 2 == 0 else "Z",
                datum_rodenja=today - timedelta(days=365 * (25 + offset % 45)),
                adresa=f"Demo ulica {offset + 1}",
                kanton="Kanton Sarajevo",
                telefon=f"061-000-{offset + 1:03d}",
                dijagnoza=diagnosis,
                mkb_sifra=mkb,
                lijek=medicine,
                terapijski_protokol=protocol,
                pocetna_faza_terapije=phase,
                interval_sedmica=(
                    protocol.korak_odrzavanja().interval_sedmica
                    if protocol and protocol.korak_odrzavanja() and protocol.korak_odrzavanja().interval_sedmica
                    else protocol.interval_odrzavanja_sedmica if protocol else 8
                ),
                aktivan=offset % 11 != 0,
            )
            created_patients.append(patient)
            patients_by_medicine[medicine.pk].append(patient)
            stats["pacijenti"] += 1

        demo_cycle = KomisijskiCiklus.objects.create(
            naziv=f"DEMO-{today:%Y%m%d}-{start_index}",
            status="SIMULACIJA",
            napomena=f"{DEMO_EVENT_MARKER} Realistični završeni komisijski ciklus.",
        )
        approved_by_request = {}
        for patient in created_patients:
            approved_doses = round_up_to_package(
                Decimal(str(patient.doza_po_aplikaciji() or 1)),
                patient.lijek,
            )
            if patient.lijek.nacin_primjene == Lijek.NACIN_KUCNA_TERAPIJA:
                approved_doses = max(Decimal("2"), approved_doses)
            request = Trebovanje.objects.create(
                pacijent=patient,
                lijek=patient.lijek,
                broj_doza=approved_doses,
                status="U_PRIPREMI",
                komisijski_ciklus=demo_cycle,
                napomena=f"{DEMO_EVENT_MARKER} Demo zahtjev kroz stvarni komisijski workflow.",
            )
            approved_by_request[request.pk] = approved_doses
        mark_requests_sent(
            demo_cycle.trebovanja.all(),
            sent_date=today - timedelta(days=115),
            user=user,
        )
        approve_cycle(
            demo_cycle,
            approved_by_request,
            today - timedelta(days=101),
            user=user,
            approval_number=f"DEMO-{today:%Y}",
        )
        stats["komisije"] = len(created_patients)

        delivery_specs = {
            "Entyvio": timedelta(days=19),
            "Remsima": timedelta(days=24),
            "Adalimumab": timedelta(days=31),
        }
        history_offsets = {
            # Najstariji događaj je izvan 90-dnevnog prozora, a najmanje
            # jedan događaj je u posljednjih 30 dana.
            "Entyvio": (94, 63, 35, 7),
            "Remsima": (97, 66, 38, 11),
            "Adalimumab": (92, 61, 27, 5),
        }

        for medicine_name, medicine in medicines.items():
            eligible = [
                patient
                for patient in patients_by_medicine.get(medicine.pk, [])
                if patient.aktivan
            ]
            if not eligible:
                continue
            event_plan = []
            if medicine_name == "Adalimumab":
                quantities = (
                    Decimal("2"),
                    Decimal("2"),
                    Decimal("2"),
                    Decimal("2"),
                )
                for sequence, (days_ago, quantity) in enumerate(
                    zip(history_offsets[medicine_name], quantities),
                    start=1,
                ):
                    event_plan.append(
                        (
                            sequence,
                            eligible[(sequence - 1) % len(eligible)],
                            days_ago,
                            quantity,
                        )
                    )
            else:
                for sequence, days_ago in enumerate(
                    history_offsets[medicine_name],
                    start=1,
                ):
                    patient = eligible[(sequence - 1) % len(eligible)]
                    event_plan.append(
                        (
                            sequence,
                            patient,
                            days_ago,
                            _therapy_dose_for_step(
                                patient.trenutni_korak_terapije()
                            ),
                        )
                    )

            delivery_age = delivery_specs[medicine_name]
            medicine_requests = list(
                demo_cycle.trebovanja.filter(lijek=medicine)
                .select_related("pacijent", "komisija")
                .order_by("id")
            )
            for sequence, request in enumerate(medicine_requests):
                # Dvije fizičke serije po lijeku daju različit i provjerljiv
                # datum posljednje isporuke, dok svaka količina ostaje vezana
                # za stvarno odobrenje konkretnog pacijenta.
                delivery_date = (
                    today - timedelta(days=96)
                    if sequence % 2 == 0
                    else today - delivery_age
                )
                _record_demo_delivery(
                    patient=request.pacijent,
                    medicine=medicine,
                    commission=request.komisija,
                    quantity=Decimal(str(request.odobrene_doze or 0)),
                    datum=delivery_date,
                    user=user,
                )
                request.zaprimljene_doze = request.odobrene_doze
                request.status = "ZAPRIMLJENO"
                request.zaduzenje_kreirano = False
                request.save(
                    update_fields=[
                        "zaprimljene_doze",
                        "status",
                        "zaduzenje_kreirano",
                    ]
                )

            if medicine_name == "Adalimumab":
                for sequence, patient, days_ago, quantity in event_plan:
                    commission = patient.vazece_komisije(lijek=medicine).first()
                    therapy_date = adjust_to_allowed_therapy_date(
                        today - timedelta(days=days_ago),
                        lijek=medicine,
                        protokol=patient.aktivni_protokol(),
                        direction=-1,
                    ).datum
                    _record_demo_home_issue(
                        patient=patient,
                        medicine=medicine,
                        commission=commission,
                        quantity=quantity,
                        datum=therapy_date,
                        sequence=sequence,
                        user=user,
                    )
                    stats["terapije"] += 1
            else:
                for sequence, patient, days_ago, quantity in event_plan:
                    therapy_date = adjust_to_allowed_therapy_date(
                        today - timedelta(days=days_ago),
                        lijek=medicine,
                        protokol=patient.aktivni_protokol(),
                        direction=-1,
                    ).datum
                    appointment = Termin.objects.create(
                        pacijent=patient,
                        lijek=medicine,
                        datum=therapy_date,
                        vrijeme=time(8 + sequence, 0),
                        status=Termin.STATUS_PLANIRANA,
                    )
                    therapy = confirm_therapy_arrival(
                        termin=appointment,
                        primljene_doze=quantity,
                        interval_sedmica=patient.interval_sedmica or 8,
                        korisnik=user,
                        # Legacy generator evidentira historijski događaj i
                        # zatim iz njega gradi demonstracijski slijed termina.
                        # Produkcijska validacija ostaje stroga; samo ovaj
                        # kontrolisani demo poziv koristi datum događaja.
                        scheduling_validation_today=therapy_date,
                    )
                    therapy.serija = f"DEMO-{medicine.pk}-{sequence:03d}"
                    therapy.save(update_fields=["serija"])
                    stats["terapije"] += 1

        Termin.objects.filter(
            pacijent__in=created_patients,
            status=Termin.STATUS_PLANIRANA,
            datum__lte=today,
        ).delete()
        for patient in created_patients:
            stats["termini"] += _schedule_demo_future_therapies(
                patient,
                today=today,
                horizon_days=90,
            )
        stats["termini"] = Termin.objects.filter(
            pacijent__in=created_patients
        ).count()
        stats["zaduzenja"] = PacijentZaduzenje.objects.filter(
            pacijent__in=created_patients
        ).count()
        complete_cycle(
            demo_cycle,
            receipt_date=today - min(delivery_specs.values()),
            user=user,
        )
        KomisijskiCiklus.objects.create(
            naziv=f"DEMO administrativni ciklus {today:%Y-%m}",
            status="ZAPRIMLJENO",
            datum_predaje=today - timedelta(days=50),
            datum_odobrenja=today - timedelta(days=45),
            datum_zaprimanja=today - timedelta(days=45),
            napomena=(
                f"{DEMO_EVENT_MARKER} Administrativni ciklus bez zahtjeva za lijekove."
            ),
        )

    stats["info"].append(
        "Kreirani su zaprimanja, stvarne potrošnje, kućna izdavanja i budući termini."
    )

    return stats
