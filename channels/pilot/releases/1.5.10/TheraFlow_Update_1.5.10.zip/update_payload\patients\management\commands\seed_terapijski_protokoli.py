from django.core.management.base import BaseCommand

from patients.standard_protocols import load_all_standard_protocols


class Command(BaseCommand):
    help = "Kreira standardne terapijske protokole i korake bez dupliranja."

    def handle(self, *args, **options):
        results = load_all_standard_protocols(create_missing_lijek=True)

        for lijek_naziv, protokol, created, koraci_count in results:
            if not protokol:
                self.stdout.write(
                    self.style.WARNING(f"Lijek nije pronađen: {lijek_naziv}")
                )
                continue

            status = "kreiran" if created else "ažuriran"
            self.stdout.write(
                self.style.SUCCESS(
                    f"{lijek_naziv}: standardni protokol {status}, novih koraka {koraci_count}."
                )
            )
