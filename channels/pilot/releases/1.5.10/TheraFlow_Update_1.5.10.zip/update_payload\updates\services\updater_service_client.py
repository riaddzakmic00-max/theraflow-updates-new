import hashlib
import hmac
import json
import os
import subprocess
import uuid
from datetime import datetime, timezone
from pathlib import Path


SERVICE_NAME = "TheraFlowUpdaterService"
ALLOWED_OPERATIONS = frozenset({"install", "rollback"})


class UpdaterServiceClientError(RuntimeError):
    pass


def service_paths():
    root = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "TheraFlow"
    return {
        "root": root,
        "key": root / "config" / "updater_service.key",
        "requests": root / "updates" / "service_requests",
    }


def service_available(run=subprocess.run):
    if os.name != "nt":
        return False
    try:
        result = run(
            ["sc.exe", "query", SERVICE_NAME],
            capture_output=True,
            text=True,
            check=False,
            shell=False,
            timeout=15,
        )
    except (OSError, subprocess.SubprocessError, TypeError):
        return False
    return result.returncode == 0 and "RUNNING" in (result.stdout or "").upper()


def _load_key(path):
    try:
        key = Path(path).read_bytes().strip()
    except OSError as exc:
        raise UpdaterServiceClientError("Updater service ključ nije dostupan.") from exc
    if len(key) < 32:
        raise UpdaterServiceClientError("Updater service ključ nije validan.")
    return key


def _signature(key, request_id, session_id, operation, created_at):
    body = f"{request_id}|{session_id}|{operation}|{created_at}".encode("utf-8")
    return hmac.new(key, body, hashlib.sha256).hexdigest()


def submit_request(session_id, operation):
    if operation not in ALLOWED_OPERATIONS:
        raise UpdaterServiceClientError("Nedozvoljena updater service operacija.")
    try:
        session_id = str(uuid.UUID(str(session_id)))
    except ValueError as exc:
        raise UpdaterServiceClientError("Update session ID nije validan UUID.") from exc

    paths = service_paths()
    key = _load_key(paths["key"])
    request_id = str(uuid.uuid4())
    created_at = datetime.now(timezone.utc).isoformat()
    request = {
        "request_id": request_id,
        "session_id": session_id,
        "operation": operation,
        "created_at": created_at,
        "signature": _signature(key, request_id, session_id, operation, created_at),
    }
    requests = paths["requests"]
    requests.mkdir(parents=True, exist_ok=True)
    temporary = requests / f".{request_id}.tmp"
    destination = requests / f"{request_id}.json"
    temporary.write_text(json.dumps(request, sort_keys=True), encoding="utf-8")
    os.replace(temporary, destination)
    return {"request_id": request_id, "request_path": str(destination)}
