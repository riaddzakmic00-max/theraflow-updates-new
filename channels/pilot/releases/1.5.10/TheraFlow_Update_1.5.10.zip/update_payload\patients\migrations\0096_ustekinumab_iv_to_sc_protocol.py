from django.db import migrations


PROTOCOL_NAME = "Ustekinumab – IV indukcija → SC održavanje"


def ensure_ustekinumab_iv_to_sc_protocol(apps, schema_editor):
    """Dodaj stabilan FK mapping bez diranja historijskih terapija."""

    Lijek = apps.get_model("patients", "Lijek")
    TerapijskiProtokol = apps.get_model("patients", "TerapijskiProtokol")

    iv_products = Lijek.objects.filter(
        genericki_naziv__iexact="Ustekinumab",
        put_primjene="IV",
        jacina_mg=130,
    )
    for medicine in iv_products.iterator():
        protocol, _ = TerapijskiProtokol.objects.get_or_create(
            lijek=medicine,
            naziv=PROTOCOL_NAME,
            defaults={
                "tip_terapije": "KOMBINOVANO",
                "indukcijske_sedmice": "0",
                "interval_odrzavanja_sedmica": 8,
                "doza_po_aplikaciji": 1,
                "napomena": (
                    "Jedna početna IV indukcija. Prva SC doza se računa "
                    "8 sedmica od stvarno potvrđene IV primjene; dalji SC "
                    "interval određuje fazni Ustekinumab protokol."
                ),
                "aktivan": True,
            },
        )
        changed = []
        expected = {
            "tip_terapije": "KOMBINOVANO",
            "indukcijske_sedmice": "0",
            "interval_odrzavanja_sedmica": 8,
            "doza_po_aplikaciji": 1,
            "aktivan": True,
        }
        for field, value in expected.items():
            if getattr(protocol, field) != value:
                setattr(protocol, field, value)
                changed.append(field)
        if changed:
            protocol.save(update_fields=changed)


class Migration(migrations.Migration):
    dependencies = [("patients", "0095_pacijentsaglasnost_izvorna_komisija")]

    operations = [
        migrations.RunPython(
            ensure_ustekinumab_iv_to_sc_protocol,
            migrations.RunPython.noop,
        ),
    ]
