"""Paralelni V2 obračun komisijske potrebe po budućim terapijama.

Produkcijski Komisijski centar i dalje koristi postojeći obračun. Ovaj modul
omogućava provjeru novog rezultata i determinističnu raspodjelu bez upisa.
"""

from dataclasses import dataclass, replace
from datetime import date, timedelta
from decimal import Decimal

from django.conf import settings as django_settings
from django.db.models import Q, Sum
from django.utils import timezone

from .commission_logistics import (
    resolve_logistics_parameters,
    resolve_safety_reserve_policy,
)
from .commission_service import (
    calculate_patient_commission_need,
    patient_commission_coverage,
)
from .future_therapy_planning import (
    generate_future_therapies,
    generate_new_patient_relative_projection,
    is_new_patient_before_first_therapy,
)
from .individual_protocols import get_effective_protocol
from .inventory import (
    inventory_position,
)
from .medication_groups import therapy_group_bucket_key
from .models import Trebovanje
from .package_sizes import package_count, round_up_to_package
from .phased_protocols import phased_planning_configuration


SOURCE_AT_PATIENT = "KOD_PACIJENTA"
SOURCE_RESERVED = "REZERVISANO_U_FRIZIDERU"
SOURCE_FREE_FRIDGE = "SLOBODNO_U_FRIZIDERU"
SOURCE_ACTIVE_COMMISSION = "AKTIVNA_KOMISIJA"
SOURCE_APPROVED_WAITING = "ODOBRENO_CEKA_DOSTAVU"
SOURCE_SUBMITTED = "PREDATO_KOMISIJI"
SOURCE_NEW_COMMISSION = "NOVA_KOMISIJA"
AVAILABLE_UNUSED_APPROVED = "NEISKORISTENO_ODOBRENO_UKUPNO"
AVAILABLE_FREE_FRIDGE = "SLOBODNO_U_FRIZIDERU_DOSTUPNO"
APPROVED_WAITING_AVAILABLE_ON = "_ODOBRENO_CEKA_DOSTUPNO_OD"
SOURCE_PRIORITY = (
    SOURCE_AT_PATIENT,
    SOURCE_RESERVED,
    SOURCE_FREE_FRIDGE,
    SOURCE_ACTIVE_COMMISSION,
    SOURCE_APPROVED_WAITING,
    SOURCE_SUBMITTED,
    SOURCE_NEW_COMMISSION,
)


@dataclass(frozen=True)
class DoseAllocation:
    source: str
    quantity: Decimal


@dataclass(frozen=True)
class TherapyDemandDetail:
    datum_terapije: date
    potrebna_kolicina: Decimal
    izvori_pokrica: tuple[DoseAllocation, ...]
    nedostatak: Decimal
    termin_postoji: bool
    razlog_datuma: str


@dataclass(frozen=True)
class PatientDoseDemand:
    pacijent: object
    lijek: object
    ciljni_datum: date
    broj_buducih_terapija: int
    ukupna_potrebna_kolicina: Decimal
    kolicina_kod_pacijenta: Decimal
    kolicina_rezervisana_u_frizideru: Decimal
    kolicina_slobodne_zalihe: Decimal
    kolicina_pokrivena_aktivnom_komisijom: Decimal
    neiskoristene_odobrene_doze: Decimal
    kolicina_odobrena_nedostavljena: Decimal
    kolicina_odobrena_nedostavljena_rasporedjena: Decimal
    kolicina_vec_predata_komisiji: Decimal
    neto_nedostatak: Decimal
    kolicina_koju_treba_traziti: Decimal
    broj_pakovanja: int
    datum_prve_nepokrivene_terapije: date | None
    detalji: tuple[TherapyDemandDetail, ...]
    dostupno_po_izvoru: dict
    planiranje_moguce: bool
    upozorenje_planiranja: str
    relativna_pocetna_projekcija: bool
    minimalna_potrebna_kolicina: Decimal
    sigurnosna_rezerva_kolicina: Decimal
    sigurnosna_rezerva_primjena: int
    maksimalna_sigurnosna_rezerva_primjena: int
    vec_pokriveno_sa_rezervom: Decimal
    preporucena_sirova_kolicina: Decimal


@dataclass(frozen=True)
class DemandComparison:
    stari_obracun: Decimal
    novi_obracun: Decimal
    razlika: Decimal
    razlog_razlike: str
    feature_flag_aktivan: bool
    produkcijski_rezultat: Decimal
    novi_detalji: PatientDoseDemand


@dataclass(frozen=True)
class CommissionQuantityBreakdown:
    minimal_required: Decimal
    safety_reserve: Decimal
    already_covered: Decimal
    raw_recommendation: Decimal
    recommended_quantity: Decimal


def quantity_breakdown_for_horizon(demand, target_date):
    """Jedina formula za minimum, rezervu, pokriće i komisijsku preporuku."""

    eligible_sources = (
        SOURCE_AT_PATIENT,
        SOURCE_RESERVED,
        SOURCE_ACTIVE_COMMISSION,
        SOURCE_APPROVED_WAITING,
    )
    details = tuple(
        item for item in demand.detalji
        if item.datum_terapije <= target_date
    )
    minimum = sum(
        (
            Decimal(str(
                getattr(
                    item,
                    "potrebna_kolicina",
                    getattr(item, "nedostatak", 0),
                ) or 0
            ))
            for item in details
        ),
        Decimal("0"),
    )
    consumed = {source: Decimal("0") for source in eligible_sources}
    covered_consumption = Decimal("0")
    for detail in details:
        for allocation in getattr(detail, "izvori_pokrica", ()):
            if allocation.source not in eligible_sources:
                continue
            quantity = Decimal(str(allocation.quantity or 0))
            consumed[allocation.source] += quantity
            covered_consumption += quantity

    reserve_available = Decimal("0")
    available_sources = getattr(demand, "dostupno_po_izvoru", {}) or {}
    for source in eligible_sources:
        available = Decimal(str(
            available_sources.get(source, 0) or 0
        ))
        if source == SOURCE_APPROVED_WAITING:
            available_on = available_sources.get(
                APPROVED_WAITING_AVAILABLE_ON
            )
            if available_on and available_on > target_date:
                available = Decimal("0")
        reserve_available += max(
            Decimal("0"),
            available - consumed[source],
        )

    reserve = Decimal(str(
        getattr(demand, "sigurnosna_rezerva_kolicina", 0) or 0
    ))
    covered_reserve = min(reserve, reserve_available)
    already_covered = covered_consumption + covered_reserve
    # Već predat zahtjev nije fizička doza i zato ne zatvara delivery-rizik
    # pojedinačne terapije. Ipak, mora umanjiti novu preporuku kako ista
    # potreba ne bi bila ponovo zatražena u paralelnom nacrtu.
    submitted = Decimal(str(
        getattr(demand, "kolicina_vec_predata_komisiji", 0) or 0
    ))
    submitted_covered = min(
        submitted,
        max(Decimal("0"), minimum + reserve - already_covered),
    )
    already_covered += submitted_covered
    raw = max(
        Decimal("0"),
        minimum + reserve - already_covered,
    )
    recommended = round_up_to_package(raw, demand.lijek)
    return CommissionQuantityBreakdown(
        minimal_required=minimum,
        safety_reserve=reserve,
        already_covered=already_covered,
        raw_recommendation=raw,
        recommended_quantity=recommended,
    )


def demand_for_reliable_delivery_planning(demand):
    """Vrati projekciju u kojoj samo pouzdani izvori zatvaraju terapiju.

    ``AKTIVNA_KOMISIJA`` je administrativno, neiskorišteno pravo. Ono ostaje
    vidljivo na rezultatu zbog audita i legacy workflowa, ali bez konkretnog
    odobrenog trebovanja i pouzdanog datuma isporuke nije fizička niti
    incoming količina. Komisijska eligibility odluka zato mora ponovo
    rasporediti iste terapijske događaje koristeći samo:

    * količinu kod pacijenta;
    * fizički rezervisanu i centralno dodijeljenu slobodnu zalihu;
    * odobreno trebovanje koje ima pouzdan datum raspoloživosti.

    Funkcija ne upisuje ništa i ne mijenja originalni demand rezultat.
    """

    if demand is None or not demand.planiranje_moguce:
        return demand

    available = dict(getattr(demand, "dostupno_po_izvoru", {}) or {})
    incoming_available_on = available.get(APPROVED_WAITING_AVAILABLE_ON)
    reliable_sources = (SOURCE_AT_PATIENT, SOURCE_RESERVED)
    pool = {
        source: Decimal(str(available.get(source, 0) or 0))
        for source in reliable_sources
    }
    # Incoming odobrenje bez datuma nije dovoljno pouzdano da bi pacijent
    # sigurno preskočio trenutni ciklus.
    pool[SOURCE_APPROVED_WAITING] = (
        Decimal(str(available.get(SOURCE_APPROVED_WAITING, 0) or 0))
        if incoming_available_on
        else Decimal("0")
    )
    used = {
        source: Decimal("0")
        for source in (*reliable_sources, SOURCE_APPROVED_WAITING)
    }
    rebuilt_details = []
    for detail in sorted(demand.detalji, key=lambda item: item.datum_terapije):
        required = Decimal(str(detail.potrebna_kolicina or 0))
        remaining = required
        allocations = []
        for source in reliable_sources:
            remaining, allocated = _allocate(
                pool,
                source,
                remaining,
                allocations,
            )
            used[source] += allocated
        if (
            incoming_available_on
            and detail.datum_terapije >= incoming_available_on
        ):
            remaining, allocated = _allocate(
                pool,
                SOURCE_APPROVED_WAITING,
                remaining,
                allocations,
            )
            used[SOURCE_APPROVED_WAITING] += allocated
        if remaining > 0:
            allocations.append(DoseAllocation(SOURCE_NEW_COMMISSION, remaining))
        rebuilt_details.append(replace(
            detail,
            izvori_pokrica=tuple(allocations),
            nedostatak=remaining,
        ))

    rebuilt_details = tuple(rebuilt_details)
    shortage = sum(
        (item.nedostatak for item in rebuilt_details),
        Decimal("0"),
    )
    first_uncovered = next(
        (
            item.datum_terapije
            for item in rebuilt_details
            if item.nedostatak > 0
        ),
        None,
    )
    reliable_available = {
        **available,
        # Aktivno pravo ostaje na zasebnim audit poljima, ali nije izvor
        # pouzdane delivery projekcije.
        SOURCE_ACTIVE_COMMISSION: Decimal("0"),
        SOURCE_APPROVED_WAITING: (
            Decimal(str(available.get(SOURCE_APPROVED_WAITING, 0) or 0))
            if incoming_available_on
            else Decimal("0")
        ),
    }
    preliminary = replace(
        demand,
        kolicina_kod_pacijenta=used[SOURCE_AT_PATIENT],
        kolicina_rezervisana_u_frizideru=used[SOURCE_RESERVED],
        kolicina_slobodne_zalihe=Decimal("0"),
        kolicina_odobrena_nedostavljena_rasporedjena=used[
            SOURCE_APPROVED_WAITING
        ],
        neto_nedostatak=shortage,
        kolicina_koju_treba_traziti=round_up_to_package(
            shortage,
            demand.lijek,
        ),
        broj_pakovanja=package_count(
            round_up_to_package(shortage, demand.lijek),
            demand.lijek,
        ),
        datum_prve_nepokrivene_terapije=first_uncovered,
        detalji=rebuilt_details,
        dostupno_po_izvoru=reliable_available,
        minimalna_potrebna_kolicina=Decimal("0"),
        vec_pokriveno_sa_rezervom=Decimal("0"),
        preporucena_sirova_kolicina=Decimal("0"),
    )
    breakdown = quantity_breakdown_for_horizon(
        preliminary,
        preliminary.ciljni_datum,
    )
    return replace(
        preliminary,
        minimalna_potrebna_kolicina=breakdown.minimal_required,
        vec_pokriveno_sa_rezervom=breakdown.already_covered,
        preporucena_sirova_kolicina=breakdown.raw_recommendation,
        kolicina_koju_treba_traziti=breakdown.recommended_quantity,
        broj_pakovanja=package_count(
            breakdown.recommended_quantity,
            demand.lijek,
        ),
    )


def commission_demand_v2_enabled():
    return bool(getattr(django_settings, "THERAFLOW_COMMISSION_DEMAND_V2_ENABLED", False))


def _submitted_quantity(pacijent, medicine_ids):
    prefetched = getattr(pacijent, "_workflow_requests", None)
    if prefetched is not None:
        requests = [
            item for item in prefetched
            if item.lijek_id in medicine_ids
            and (
                item.status == "PREDATO"
                or (
                    item.tip_zahtjeva == Trebovanje.TIP_VANREDNI
                    and item.status in {
                        Trebovanje.STATUS_NACRT,
                        Trebovanje.STATUS_SPREMAN,
                        Trebovanje.STATUS_POSLAN_KOMISIJI,
                    }
                )
            )
        ]
        return sum((Decimal(str(item.broj_doza or 0)) for item in requests), Decimal("0"))
    return Decimal(str(
        Trebovanje.objects.filter(
            pacijent=pacijent,
            lijek_id__in=medicine_ids,
        ).filter(
            Q(status="PREDATO")
            | Q(
                tip_zahtjeva=Trebovanje.TIP_VANREDNI,
                status__in=(
                    Trebovanje.STATUS_NACRT,
                    Trebovanje.STATUS_SPREMAN,
                    Trebovanje.STATUS_POSLAN_KOMISIJI,
                ),
            )
        ).aggregate(total=Sum("broj_doza"))["total"] or 0
    ))


def _confirmed_delivery_inventory(pacijent):
    """Vrati samo stvarno naručenu, nezaprimljenu količinu i njen datum.

    ``odobrene_doze`` je ukupno komisijsko pravo, dok ``broj_doza`` predstavlja
    količinu konkretnog trebovanja. Kada je odobreno šest, a naručeno četiri,
    samo četiri smiju postati izvor ``ODOBRENO_CEKA_DOSTAVU``. Preostale dvije
    ostaju administrativno pravo koje još nije naručeno.
    """

    requests = getattr(pacijent, "_workflow_requests", None)
    if requests is None:
        requests = Trebovanje.objects.filter(
            pacijent=pacijent,
            status__in=(
                "ODOBRENO",
                Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
                Trebovanje.STATUS_CEKA_ISPORUKU,
            ),
            odobrene_doze__isnull=False,
        ).select_related("komisijski_ciklus")
    medicine_ids = set(pacijent.lijek.equivalent_ids())
    pending_total = Decimal("0")
    delivery_dates = []
    for request in requests:
        if request.status not in {
            "ODOBRENO",
            Trebovanje.STATUS_DJELOMICNO_ODOBRENO,
            Trebovanje.STATUS_CEKA_ISPORUKU,
        } or request.lijek_id not in medicine_ids:
            continue
        approved = Decimal(str(request.odobrene_doze or 0))
        ordered = Decimal(str(request.broj_doza or 0))
        received = Decimal(str(request.zaprimljene_doze or 0))
        pending = max(Decimal("0"), min(approved, ordered) - received)
        if pending <= 0:
            continue
        pending_total += pending
        delivery = request.ocekivana_najranija_isporuka
        if not delivery and request.komisijski_ciklus_id:
            cycle = request.komisijski_ciklus
            delivery = (
                cycle.najkasniji_ocekivani_datum_isporuke
                or cycle.najraniji_ocekivani_datum_isporuke
            )
        if delivery:
            delivery_dates.append(delivery)
    if pending_total <= 0:
        return Decimal("0"), None
    return (
        pending_total,
        max(delivery_dates) if delivery_dates else None,
    )


def _approved_waiting_available_on(pacijent, *, today=None):
    """Datum stvarno najavljene isporuke; bez logističkog nagađanja."""

    return _confirmed_delivery_inventory(pacijent)[1]


def _patient_source_pool(pacijent, *, today):
    medicine_ids = set(pacijent.lijek.equivalent_ids())
    coverage = patient_commission_coverage(pacijent)
    at_patient = Decimal(str(coverage["at_patient"] or 0))
    reserved = Decimal(str(coverage["reserved_in_fridge"] or 0))
    administrative_unphysical = (
        Decimal(str(coverage["unused_approved"] or 0))
        + Decimal(str(coverage["approved_waiting_delivery"] or 0))
    )
    confirmed_delivery, confirmed_delivery_date = (
        _confirmed_delivery_inventory(pacijent)
    )
    approved_waiting = min(administrative_unphysical, confirmed_delivery)
    active_commission = max(
        Decimal("0"),
        administrative_unphysical - approved_waiting,
    )
    # Ukupno preostalo pravo ostaje vidljivo za audit i objaĹˇnjenje. Dio koji
    # je stvarno raspoloĹľiv za novi plan je odvojeni ``active_commission``;
    # povezane fiziÄŤke jedinice se zato ne mogu ponovo alocirati.
    unused_approved_total = (
        Decimal(str(coverage["approved_remaining"] or 0))
        + Decimal(str(coverage["approved_waiting_delivery"] or 0))
    )
    free_available = Decimal(str(
        inventory_position(
            pacijent.lijek,
            today=today,
            include_planned_need=False,
        )["freely_available"] or 0
    ))
    submitted = _submitted_quantity(pacijent, medicine_ids)
    return {
        SOURCE_AT_PATIENT: at_patient,
        SOURCE_RESERVED: reserved,
        SOURCE_ACTIVE_COMMISSION: active_commission,
        SOURCE_APPROVED_WAITING: approved_waiting,
        SOURCE_SUBMITTED: submitted,
        AVAILABLE_UNUSED_APPROVED: unused_approved_total,
        AVAILABLE_FREE_FRIDGE: free_available,
        APPROVED_WAITING_AVAILABLE_ON: (
            confirmed_delivery_date if approved_waiting > 0 else None
        ),
        "linked_approval_overlap_excluded": Decimal(str(
            coverage["linked_overlap_excluded"] or 0
        )),
    }


def _allocate(pool, source, required, allocations):
    available = Decimal(str(pool.get(source, 0) or 0))
    quantity = min(required, available)
    if quantity > 0:
        pool[source] = available - quantity
        allocations.append(DoseAllocation(source, quantity))
    return required - quantity, quantity


def calculate_patient_demands(
    patients,
    *,
    today=None,
    target_date=None,
    interval_changes_by_patient=None,
):
    """Izračunaj pacijentove izvore bez virtualne dodjele slobodne zalihe."""

    today = today or timezone.localdate()
    changes = interval_changes_by_patient or {}
    contexts = {}
    for patient in sorted(list(patients), key=lambda item: item.pk):
        if not patient.aktivan or not patient.lijek_id or patient.na_aktivnoj_pauzi():
            continue
        parameters = resolve_logistics_parameters(patient.lijek)
        patient_target = target_date or (
            today + timedelta(days=parameters.target_coverage_days)
        )
        protocol = get_effective_protocol(patient)
        phased_configuration = phased_planning_configuration(patient)
        planning_possible = (
            phased_configuration.planning_possible
            if phased_configuration is not None
            else protocol is not None
        )
        planning_warning = (
            phased_configuration.reason
            if phased_configuration is not None
            and not phased_configuration.planning_possible
            else ""
        )
        is_new_patient = is_new_patient_before_first_therapy(patient)
        projections = []
        if planning_possible:
            projections = generate_future_therapies(
                patient,
                start_date=today,
                target_date=patient_target,
                interval_changes=changes.get(patient.pk),
            )
            if not projections and is_new_patient:
                projections = generate_new_patient_relative_projection(
                    patient,
                    start_date=today,
                    target_date=patient_target,
                )
        application_quantity = (
            Decimal(str(patient.doza_po_aplikaciji() or 0))
            if planning_possible else Decimal("0")
        )
        if application_quantity <= 0 and projections:
            application_quantity = Decimal(str(
                projections[0].kolicina_lijeka or 0
            ))
        if application_quantity <= 0:
            planning_possible = False
            projections = []
        safety_policy = resolve_safety_reserve_policy(
            patient,
            protocol=protocol,
            application_quantity=application_quantity,
        )
        if (
            phased_configuration is not None
            and phased_configuration.relative_initial_projection
            and is_new_patient
        ):
            # Jednokratna IV indukcija je propisana konkretna fizička količina.
            # Generička rezerva od još jedne primjene bi duplirala tu dozu.
            safety_policy = replace(
                safety_policy,
                applications=0,
                reserve_quantity=Decimal("0"),
                source="PHASED_INITIAL_EXACT_QUANTITY",
            )
        pool = _patient_source_pool(patient, today=today)
        group_key = therapy_group_bucket_key(patient.lijek)
        contexts[patient.pk] = {
            "patient": patient,
            "target": patient_target,
            "projections": projections,
            "pool": pool,
            "initial_pool": dict(pool),
            "details": [],
            "used": {source: Decimal("0") for source in SOURCE_PRIORITY},
            "planning_possible": planning_possible,
            "planning_warning": planning_warning,
            "relative_new_patient_projection": bool(
                is_new_patient
                and projections
                and (
                    phased_configuration is None
                    or phased_configuration.relative_initial_projection
                )
            ),
            "safety_policy": safety_policy,
            "group_key": group_key,
        }

    events = []
    for patient_id, context in contexts.items():
        for index, projection in enumerate(context["projections"]):
            phase_priority = (
                0 if "induk" in (projection.faza_terapije or "").lower() else 1
            )
            confirmed_priority = 0 if projection.termin_postoji else 1
            events.append((
                projection.datum_terapije,
                phase_priority,
                confirmed_priority,
                patient_id,
                index,
                projection,
            ))
    # Najraniji stvarni manjak ima prednost; kada je datum isti, indukcija i
    # već potvrđeni termin imaju stabilnu kliničku prednost. patient_id je
    # posljednji deterministički tie-breaker.
    events.sort(key=lambda item: item[:-1])

    for _, _, _, patient_id, _, projection in events:
        context = contexts[patient_id]
        patient = context["patient"]
        pool = context["pool"]
        required = Decimal(str(projection.kolicina_lijeka or 0))
        remaining = required
        allocations = []

        remaining, used = _allocate(pool, SOURCE_AT_PATIENT, remaining, allocations)
        context["used"][SOURCE_AT_PATIENT] += used
        remaining, used = _allocate(pool, SOURCE_RESERVED, remaining, allocations)
        context["used"][SOURCE_RESERVED] += used

        # Slobodna fizička zaliha postaje pacijentov izvor tek nakon eksplicitne
        # dodjele. Tada se pojavljuje kao SOURCE_RESERVED; ovdje se ne alocira.

        # Aktivno neiskorišteno pravo nije fizička zaliha, ali administrativno
        # pokriva istu potrebu i zato mora spriječiti ponovno traženje doza.
        # Odobrena dolazna količina raspoređuje se tek od procijenjenog datuma.
        for source in (SOURCE_ACTIVE_COMMISSION, SOURCE_APPROVED_WAITING):
            if (
                source == SOURCE_APPROVED_WAITING
                and not context["relative_new_patient_projection"]
                and (
                    not pool.get(APPROVED_WAITING_AVAILABLE_ON)
                    or projection.datum_terapije
                    < pool[APPROVED_WAITING_AVAILABLE_ON]
                )
            ):
                continue
            remaining, used = _allocate(pool, source, remaining, allocations)
            context["used"][source] += used
        if remaining > 0:
            allocations.append(DoseAllocation(SOURCE_NEW_COMMISSION, remaining))
            context["used"][SOURCE_NEW_COMMISSION] += remaining

        context["details"].append(TherapyDemandDetail(
            datum_terapije=projection.datum_terapije,
            potrebna_kolicina=required,
            izvori_pokrica=tuple(allocations),
            nedostatak=remaining,
            termin_postoji=projection.termin_postoji,
            razlog_datuma=projection.razlog_izracuna,
        ))

    results = {}
    for patient_id, context in contexts.items():
        patient = context["patient"]
        details = tuple(context["details"])
        raw_shortage = context["used"][SOURCE_NEW_COMMISSION]
        requested = round_up_to_package(raw_shortage, patient.lijek)
        initial = context["initial_pool"]
        first_uncovered = next(
            (item.datum_terapije for item in details if item.nedostatak > 0),
            None,
        )
        safety_policy = context["safety_policy"]
        preliminary = PatientDoseDemand(
            pacijent=patient,
            lijek=patient.lijek,
            ciljni_datum=context["target"],
            broj_buducih_terapija=len(details),
            ukupna_potrebna_kolicina=sum(
                (item.potrebna_kolicina for item in details), Decimal("0")
            ),
            kolicina_kod_pacijenta=context["used"][SOURCE_AT_PATIENT],
            kolicina_rezervisana_u_frizideru=context["used"][SOURCE_RESERVED],
            kolicina_slobodne_zalihe=Decimal("0"),
            # Informativno administrativno pravo; nije fizičko pokriće dok
            # doze nisu potvrđene za isporuku ili rezervisane pacijentu.
            kolicina_pokrivena_aktivnom_komisijom=initial[
                SOURCE_ACTIVE_COMMISSION
            ],
            neiskoristene_odobrene_doze=initial[AVAILABLE_UNUSED_APPROVED],
            kolicina_odobrena_nedostavljena=initial[SOURCE_APPROVED_WAITING],
            kolicina_odobrena_nedostavljena_rasporedjena=context["used"][
                SOURCE_APPROVED_WAITING
            ],
            kolicina_vec_predata_komisiji=initial[SOURCE_SUBMITTED],
            neto_nedostatak=raw_shortage,
            kolicina_koju_treba_traziti=requested,
            broj_pakovanja=package_count(requested, patient.lijek),
            datum_prve_nepokrivene_terapije=first_uncovered,
            detalji=details,
            dostupno_po_izvoru={
                **initial,
                SOURCE_FREE_FRIDGE: Decimal("0"),
            },
            planiranje_moguce=context["planning_possible"],
            relativna_pocetna_projekcija=context[
                "relative_new_patient_projection"
            ],
            minimalna_potrebna_kolicina=Decimal("0"),
            sigurnosna_rezerva_kolicina=safety_policy.reserve_quantity,
            sigurnosna_rezerva_primjena=safety_policy.applications,
            maksimalna_sigurnosna_rezerva_primjena=(
                safety_policy.maximum_applications
            ),
            vec_pokriveno_sa_rezervom=Decimal("0"),
            preporucena_sirova_kolicina=Decimal("0"),
            upozorenje_planiranja=(
                "" if context["planning_possible"] else (
                    context["planning_warning"]
                    or "Protokol nije kompletno definisan; komisijska potreba nije izračunata."
                )
            ),
        )
        breakdown = quantity_breakdown_for_horizon(
            preliminary,
            context["target"],
        )
        results[patient_id] = replace(
            preliminary,
            minimalna_potrebna_kolicina=breakdown.minimal_required,
            vec_pokriveno_sa_rezervom=breakdown.already_covered,
            preporucena_sirova_kolicina=breakdown.raw_recommendation,
            kolicina_koju_treba_traziti=breakdown.recommended_quantity,
            broj_pakovanja=package_count(
                breakdown.recommended_quantity,
                patient.lijek,
            ),
        )
    return results


def calculate_patient_demand(
    pacijent,
    *,
    today=None,
    target_date=None,
    interval_changes=None,
):
    return calculate_patient_demands(
        [pacijent],
        today=today,
        target_date=target_date,
        interval_changes_by_patient={pacijent.pk: interval_changes},
    ).get(pacijent.pk)


def compare_patient_demand_with_legacy(
    pacijent,
    *,
    today=None,
    target_date=None,
    interval_changes=None,
):
    today = today or timezone.localdate()
    new = calculate_patient_demand(
        pacijent,
        today=today,
        target_date=target_date,
        interval_changes=interval_changes,
    )
    old_data = calculate_patient_commission_need(pacijent, today=today)
    old = Decimal(str(old_data.get("kolicina_za_komisiju") or 0))
    new_quantity = new.kolicina_koju_treba_traziti if new else Decimal("0")
    difference = new_quantity - old
    if difference == 0:
        reason = "Oba obračuna daju istu količinu."
    elif difference > 0:
        reason = (
            "Novi obračun nalazi dodatne nepokrivene terapije unutar ciljnog perioda."
        )
    else:
        reason = (
            "Novi obračun raspoređuje postojeće pokriće po konkretnim datumima terapije."
        )
    source_summary = (
        f"Potreba {new.ukupna_potrebna_kolicina}; pokriveno: "
        f"kod pacijenta {new.kolicina_kod_pacijenta}, "
        f"rezervisano {new.kolicina_rezervisana_u_frizideru}, "
        f"slobodni frižider {new.kolicina_slobodne_zalihe}, "
        f"aktivna komisija {new.kolicina_pokrivena_aktivnom_komisijom}, "
        f"odobreno-neisporučeno {new.kolicina_odobrena_nedostavljena}, "
        f"predato {new.kolicina_vec_predata_komisiji}; "
        f"neto nedostatak {new.neto_nedostatak}, nakon pakovanja {new_quantity}."
    )
    reason = f"{reason} {source_summary}"
    enabled = commission_demand_v2_enabled()
    return DemandComparison(
        stari_obracun=old,
        novi_obracun=new_quantity,
        razlika=difference,
        razlog_razlike=reason,
        feature_flag_aktivan=enabled,
        produkcijski_rezultat=new_quantity if enabled else old,
        novi_detalji=new,
    )
