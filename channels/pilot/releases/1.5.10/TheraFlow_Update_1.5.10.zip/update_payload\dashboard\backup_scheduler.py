import os
import socket
import threading

from django.conf import settings
from django.utils import timezone

from dashboard.postgres_backup import (
    BackupBusyError,
    BackupError,
    TRIGGER_CATCH_UP,
    TRIGGER_SCHEDULED,
    FileLease,
    append_scheduler_log,
    automatic_backup_due,
    ensure_daily_backup,
    next_automatic_backup,
    read_backup_state,
    scheduler_lock_path,
    update_backup_state,
)


class BackupScheduler:
    """Dugotrajni scheduler namijenjen zasebnom Windows servisu."""

    def __init__(self, check_interval=None, stop_event=None):
        self.check_interval = max(
            1,
            int(
                check_interval
                if check_interval is not None
                else getattr(settings, "THERAFLOW_BACKUP_CHECK_INTERVAL_SECONDS", 60)
            ),
        )
        self.stop_event = stop_event or threading.Event()
        self.service_name = getattr(
            settings,
            "THERAFLOW_BACKUP_SCHEDULER_SERVICE_NAME",
            "TheraFlowBackupScheduler",
        )
        self.lease = FileLease(
            scheduler_lock_path(),
            max(self.check_interval * 4, 600),
        )
        self.started_at = None
        self._heartbeat_stop = threading.Event()
        self._heartbeat_thread = None
        self._first_cycle_done = False

    def _state(self, running=True, **extra):
        now = timezone.now()
        existing = read_backup_state().get("scheduler")
        payload = {
            **(existing if isinstance(existing, dict) else {}),
            "running": running,
            "service_name": self.service_name,
            "pid": os.getpid(),
            "host": socket.gethostname(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "heartbeat_at": now.isoformat(),
            "check_interval_seconds": self.check_interval,
            "next_run": next_automatic_backup(now).isoformat(),
            **extra,
        }
        update_backup_state(scheduler=payload)
        if running:
            self.lease.touch()
        return payload

    def run_cycle(self, catch_up=False):
        due = automatic_backup_due()
        self._state(running=True, due=due)
        if not due:
            return None
        trigger_type = TRIGGER_CATCH_UP if catch_up else TRIGGER_SCHEDULED
        append_scheduler_log(
            "scheduled_backup_due",
            service_name=self.service_name,
            pid=os.getpid(),
            trigger_type=trigger_type,
        )
        try:
            path = ensure_daily_backup(trigger_type=trigger_type)
        except BackupBusyError as exc:
            self._state(
                running=True,
                last_scheduled_run_at=timezone.now().isoformat(),
                last_scheduled_result="busy",
                last_scheduled_error=str(exc),
            )
            append_scheduler_log(
                "scheduled_backup_busy",
                service_name=self.service_name,
                pid=os.getpid(),
                error=str(exc),
            )
            return None
        except BackupError as exc:
            self._state(
                running=True,
                last_scheduled_run_at=timezone.now().isoformat(),
                last_scheduled_result="failed",
                last_scheduled_error=str(exc),
            )
            append_scheduler_log(
                "scheduled_backup_failed",
                service_name=self.service_name,
                pid=os.getpid(),
                error=str(exc),
            )
            return None
        except Exception as exc:
            self._state(
                running=True,
                last_scheduled_run_at=timezone.now().isoformat(),
                last_scheduled_result="failed",
                last_scheduled_error=type(exc).__name__,
            )
            append_scheduler_log(
                "scheduled_backup_failed",
                service_name=self.service_name,
                pid=os.getpid(),
                error=type(exc).__name__,
            )
            return None
        self._state(
            running=True,
            last_scheduled_run_at=timezone.now().isoformat(),
            last_scheduled_result="success",
            last_scheduled_path=str(path) if path else "",
            last_scheduled_error="",
        )
        append_scheduler_log(
            "scheduled_backup_succeeded",
            service_name=self.service_name,
            pid=os.getpid(),
            path=str(path) if path else "",
        )
        return path

    def _heartbeat_loop(self):
        interval = min(self.check_interval, 60)
        while not self._heartbeat_stop.wait(interval):
            self._state(running=True)

    def run(self):
        self.lease.acquire()
        self.started_at = timezone.now()
        append_scheduler_log(
            "scheduler_started",
            service_name=self.service_name,
            pid=os.getpid(),
            check_interval_seconds=self.check_interval,
        )
        self._state(running=True)
        self._heartbeat_stop.clear()
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop,
            name="theraflow-backup-heartbeat",
            daemon=True,
        )
        self._heartbeat_thread.start()
        try:
            while not self.stop_event.is_set():
                self.run_cycle(catch_up=not self._first_cycle_done)
                self._first_cycle_done = True
                if self.stop_event.wait(self.check_interval):
                    break
        finally:
            self._heartbeat_stop.set()
            if self._heartbeat_thread:
                self._heartbeat_thread.join(timeout=2)
            self._state(
                running=False,
                stopped_at=timezone.now().isoformat(),
            )
            append_scheduler_log(
                "scheduler_stopped",
                service_name=self.service_name,
                pid=os.getpid(),
            )
            self.lease.release()

    def stop(self):
        self.stop_event.set()


# Privremeni alias radi kompatibilnosti postojećih internih importa.
DailyBackupScheduler = BackupScheduler
