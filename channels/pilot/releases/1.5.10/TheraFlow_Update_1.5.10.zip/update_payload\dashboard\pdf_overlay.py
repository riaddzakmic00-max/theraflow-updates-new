from io import BytesIO
from pathlib import Path

from django.conf import settings
from PyPDF2 import PdfReader, PdfWriter
from reportlab.lib.colors import Color, black, red
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


FONT_DIR = Path(settings.BASE_DIR) / "static" / "fonts"
PDF_FONT_FALLBACK = "DejaVuSans"
PDF_FONT_BOLD = "DejaVuSans-Bold"
FONT_ALIASES = {
    "Helvetica": PDF_FONT_FALLBACK,
    "Helvetica-Bold": PDF_FONT_BOLD,
}


def register_pdf_fonts():
    fonts = {
        PDF_FONT_FALLBACK: FONT_DIR / "DejaVuSans.ttf",
        PDF_FONT_BOLD: FONT_DIR / "DejaVuSans-Bold.ttf",
    }
    for font_name, font_path in fonts.items():
        if font_name not in pdfmetrics.getRegisteredFontNames() and font_path.exists():
            pdfmetrics.registerFont(TTFont(font_name, str(font_path)))


def resolve_pdf_font(font_name):
    register_pdf_fonts()
    font_name = FONT_ALIASES.get(font_name, font_name or PDF_FONT_FALLBACK)
    if font_name not in pdfmetrics.getRegisteredFontNames():
        return PDF_FONT_FALLBACK
    return font_name


register_pdf_fonts()


def draw_text_fit(c, text, x, y, max_width, font_size, font_name=PDF_FONT_FALLBACK, min_font_size=6):
    text = "" if text is None else str(text)
    size = font_size
    font_name = resolve_pdf_font(font_name)

    while size > min_font_size and c.stringWidth(text, font_name, size) > max_width:
        size -= 0.5

    c.setFont(font_name, size)
    c.drawString(x, y, text)
    return size


def draw_debug_grid(c, width, height):
    for x in range(0, int(width) + 1, 20):
        c.setStrokeColor(Color(0.0, 0.45, 0.95, alpha=0.55 if x % 50 == 0 else 0.16))
        c.setLineWidth(0.45 if x % 50 == 0 else 0.2)
        c.line(x, 0, x, height)

    for y in range(0, int(height) + 1, 20):
        c.setStrokeColor(Color(0.95, 0.1, 0.1, alpha=0.55 if y % 50 == 0 else 0.16))
        c.setLineWidth(0.45 if y % 50 == 0 else 0.2)
        c.line(0, y, width, y)

    c.setFont(resolve_pdf_font(PDF_FONT_FALLBACK), 5)
    c.setFillColor(Color(0.0, 0.25, 0.7, alpha=0.85))
    for x in range(0, int(width) + 1, 50):
        c.drawString(x + 1, 4, str(x))
        c.drawString(x + 1, height - 10, str(x))

    c.setFillColor(Color(0.72, 0.0, 0.0, alpha=0.85))
    for y in range(0, int(height) + 1, 50):
        c.drawString(3, y + 2, str(y))
        c.drawRightString(width - 3, y + 2, str(y))

    c.setFillColor(black)


def draw_pdf_text(c, field_name, value, coords, debug=False):
    field = coords[field_name]
    x = field.get("x", 0)
    y = field.get("y", 0)
    font = resolve_pdf_font(field.get("font", PDF_FONT_FALLBACK))
    size = field.get("size", field.get("font_size", 10))
    max_width = field.get("max_width", 220)

    draw_text_fit(c, value, x, y, max_width, size, font)

    if debug:
        c.saveState()
        c.setStrokeColor(red)
        c.setFillColor(red)
        c.setLineWidth(0.7)
        c.line(x - 4, y, x + 4, y)
        c.line(x, y - 4, x, y + 4)
        c.setFont(resolve_pdf_font(PDF_FONT_FALLBACK), 6)
        c.drawString(x + 6, y + 6, f"{field_name} ({x},{y})")
        c.restoreState()


def render_pdf_overlay(template_path, output_path, coords, values, debug=False):
    template_pdf = PdfReader(open(template_path, "rb"))
    writer = PdfWriter()
    fields_by_page = {}

    for field_name, field in coords.items():
        fields_by_page.setdefault(field.get("page", 0), []).append(field_name)

    for page_number, page in enumerate(template_pdf.pages):
        width = float(page.mediabox.width)
        height = float(page.mediabox.height)
        merge_pdf_overlay_page(
            page,
            coords,
            values,
            page_number=page_number,
            debug=debug,
            field_names=fields_by_page.get(page_number, []),
        )
        writer.add_page(page)

    with open(output_path, "wb") as f:
        writer.write(f)

    return output_path


def merge_pdf_overlay_page(page, coords, values, page_number=0, debug=False, field_names=None):
    width = float(page.mediabox.width)
    height = float(page.mediabox.height)
    packet = BytesIO()
    c = canvas.Canvas(packet, pagesize=(width, height))

    if debug:
        draw_debug_grid(c, width, height)

    if field_names is None:
        field_names = [
            field_name
            for field_name, field in coords.items()
            if field.get("page", 0) == page_number
        ]

    for field_name in field_names:
        draw_pdf_text(c, field_name, values.get(field_name, ""), coords, debug=debug)

    c.save()
    packet.seek(0)
    overlay_page = PdfReader(packet).pages[0]
    page.merge_page(overlay_page)
    return page
