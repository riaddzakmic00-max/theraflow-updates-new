import json

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Return the installer-safe initial administrator setup state."

    def handle(self, *args, **options):
        user_model = get_user_model()
        superusers = user_model.objects.filter(is_superuser=True).count()
        active_superusers = user_model.objects.filter(
            is_superuser=True,
            is_active=True,
        ).count()
        active_staff = user_model.objects.filter(
            is_staff=True,
            is_active=True,
        ).count()
        state = "ADMIN_EXISTS" if active_superusers > 0 else "ADMIN_REQUIRED"
        payload = {
            "state": state,
            "superusers": superusers,
            "active_superusers": active_superusers,
            "active_staff": active_staff,
        }
        self.stdout.write(
            "THERAFLOW_ADMIN_STATE_JSON="
            + json.dumps(payload, separators=(",", ":"), sort_keys=True)
        )
