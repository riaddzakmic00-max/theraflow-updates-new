from pathlib import Path

from django.core.management.base import BaseCommand

from patients.commission_validation import (
    compare_active_patient_demands,
    comparison_markdown,
)


class Command(BaseCommand):
    help = "Generiše read-only poređenje starog i V2 komisijskog obračuna."

    def add_arguments(self, parser):
        parser.add_argument("--output", help="Opciona putanja Markdown izvještaja.")

    def handle(self, *args, **options):
        rows = compare_active_patient_demands()
        report = comparison_markdown(rows)
        output = options.get("output")
        if output:
            path = Path(output).resolve()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(report, encoding="utf-8")
            self.stdout.write(self.style.SUCCESS(f"Izvještaj spremljen: {path}"))
        else:
            self.stdout.write(report)
        self.stdout.write(self.style.SUCCESS(f"Upoređeno pacijenata: {len(rows)}"))
