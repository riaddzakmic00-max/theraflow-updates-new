import uuid

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(
            name="UpdateSession",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("target_version", models.CharField(max_length=50)),
                ("status", models.CharField(choices=[("package_downloaded", "Package Downloaded"), ("backup_in_progress", "Backup In Progress"), ("backup_completed", "Backup Completed"), ("staging_in_progress", "Staging In Progress"), ("ready_to_install", "Ready To Install"), ("backup_failed", "Backup Failed"), ("staging_failed", "Staging Failed"), ("validation_failed", "Validation Failed"), ("error", "Error")], default="package_downloaded", max_length=32)),
                ("is_active", models.BooleanField(default=True)),
                ("package_path", models.TextField()),
                ("package_sha256", models.CharField(max_length=64)),
                ("backup_directory", models.TextField(blank=True)),
                ("database_backup_path", models.TextField(blank=True)),
                ("config_backup_path", models.TextField(blank=True)),
                ("staging_directory", models.TextField(blank=True)),
                ("install_plan_path", models.TextField(blank=True)),
                ("manifest_snapshot", models.JSONField(default=dict)),
                ("database_backup_validated", models.BooleanField(default=False)),
                ("staging_validated", models.BooleanField(default=False)),
                ("error_message", models.TextField(blank=True)),
                ("prepared_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("prepared_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="prepared_updates", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ("-created_at",)},
        ),
        migrations.AddConstraint(
            model_name="updatesession",
            constraint=models.UniqueConstraint(condition=models.Q(("is_active", True)), fields=("is_active",), name="updates_only_one_active_session"),
        ),
    ]
