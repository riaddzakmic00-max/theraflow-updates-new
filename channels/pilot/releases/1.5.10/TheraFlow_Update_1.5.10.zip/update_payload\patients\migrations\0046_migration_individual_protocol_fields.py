from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("patients", "0045_individualni_koraci_protokola"),
    ]

    operations = [
        migrations.AlterField(
            model_name="individualniprotokolpacijenta",
            name="razlog_posljednje_izmjene",
            field=models.TextField(blank=True, default=""),
        ),
        migrations.AlterField(
            model_name="pacijent",
            name="pocetna_faza_terapije",
            field=models.CharField(
                choices=[
                    ("INDUKCIJA", "Novi pacijent / počinje terapiju"),
                    ("ODRZAVANJE", "Nastavlja standardni protokol"),
                    ("INDIVIDUALNI", "Nastavlja individualni protokol"),
                ],
                default="INDUKCIJA",
                max_length=20,
            ),
        ),
    ]
