(() => {
    function quantityLabel(quantity, procurementUnit) {
        const integer = Number.isInteger(quantity) ? Math.abs(quantity) : null;
        const lastTwo = integer === null ? null : integer % 100;
        const last = integer === null ? null : integer % 10;
        const vial = procurementUnit === "VIAL";
        if (lastTwo !== null && [11, 12, 13, 14].includes(lastTwo)) {
            return vial ? "bočica" : "doza";
        }
        if (last === 1) return vial ? "bočica" : "doza";
        if ([2, 3, 4].includes(last)) return vial ? "bočice" : "doze";
        return vial ? "bočica" : "doza";
    }

    function updatePackageQuantity(input) {
        const packageSize = Number(input.dataset.packageSize || 1);
        const quantity = Number(input.value || 0);
        const showPackageCount = input.dataset.showPackageCount === "true";
        const valid = packageSize <= 1 || Number.isInteger(quantity / packageSize);
        input.setCustomValidity(
            valid
                ? ""
                : (input.dataset.packageMessage || "Količina mora odgovarati cijelom pakovanju.")
        );

        const output = document.getElementById(input.dataset.packageOutput);
        if (output) {
            if (!valid) {
                output.textContent = "Unos nije cijelo pakovanje";
            } else {
                const unitText = `${quantity} ${quantityLabel(
                    quantity,
                    input.dataset.procurementUnit,
                )}`;
                output.textContent = showPackageCount
                    ? `${unitText} · ${quantity / packageSize} pakovanja`
                    : unitText;
            }
        }
        input.dispatchEvent(new CustomEvent("packagequantitychange", {
            bubbles: true,
            detail: { quantity, packageSize, valid },
        }));
    }

    document.querySelectorAll("[data-package-size]").forEach((input) => {
        if (!input.matches("input")) return;
        updatePackageQuantity(input);
        input.addEventListener("input", () => updatePackageQuantity(input));
        input.addEventListener("change", () => updatePackageQuantity(input));
    });
})();
