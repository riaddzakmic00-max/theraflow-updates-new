import json
import logging
import os
import re
import traceback
from datetime import datetime, timezone
from pathlib import Path


PUBLIC_STATE_FIELDS = {
    "session_id", "current_version", "target_version", "status", "current_step",
    "progress_percent", "started_at", "updated_at", "completed_at", "updater_pid",
    "error_code", "error_message",
    "migration_started", "migration_completed", "service_status", "health_check_status",
    "rollback_type", "rollback_reason", "rollback_started_at", "rollback_completed_at",
    "rollback_trigger", "rollback_error_code", "rollback_error_message",
    "files_restored", "config_restored", "database_restored",
    "previous_version_restored", "manual_action_required", "last_successful_step",
    "last_attempted_step", "failed_step", "step_started_at", "step_completed_at",
    "failed_step_label",
}

PROCESS_STEPS = {
    1: "Manifest loaded",
    2: "Version comparison",
    3: "Update package downloaded",
    4: "SHA256 verified",
    5: "Backup created",
    6: "Stop service",
    7: "Extract package",
    8: "Replace files",
    9: "Run migrations",
    10: "Collectstatic",
    11: "Start service",
    12: "Health check",
    13: "Cleanup",
}

INTERNAL_STEP_TO_PROCESS = {
    "plan_validation": "Pre-install validation",
    "service_stop": "STEP 6 - Stop service",
    "application_backup": "STEP 5 - Backup created (application snapshot)",
    "install": "STEP 8 - Replace files",
    "django_check": "STEP 9 - Run migrations (Django pre-check)",
    "migrate": "STEP 9 - Run migrations",
    "collectstatic": "STEP 10 - Collectstatic",
    "restart": "STEP 11 - Start service",
    "health_check": "STEP 12 - Health check",
    "finalize": "STEP 13 - Cleanup",
}


def process_step_label(step):
    if isinstance(step, int):
        return f"STEP {step} - {PROCESS_STEPS.get(step, 'Unknown')}"
    return INTERNAL_STEP_TO_PROCESS.get(str(step), str(step or "Unknown step"))


def _trace_path(data_root=None):
    if data_root:
        root = Path(data_root)
    else:
        try:
            from django.conf import settings
            root = Path(settings.THERAFLOW_DATA_DIR)
        except Exception:
            root = Path(os.environ.get("PROGRAMDATA", Path.cwd())) / "TheraFlow"
    destination = root.resolve() / "logs" / "update_process.log"
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination


def trace_update_step(
    step,
    event,
    *,
    session_id="none",
    function_name="",
    paths=None,
    exit_code=None,
    exception=None,
    message="",
    data_root=None,
):
    """Upiši jednu potpunu, redaktovanu fazu u zajednički updater log."""
    timestamp = datetime.now(timezone.utc).isoformat()
    label = process_step_label(step)
    path_values = {
        str(key): str(value)
        for key, value in dict(paths or {}).items()
        if value is not None
    }
    exception_type = type(exception).__name__ if exception else ""
    exception_message = safe_message(exception or message)
    if exception and exception.__traceback__:
        traceback_text = "".join(
            traceback.format_exception(type(exception), exception, exception.__traceback__)
        )
    elif exception:
        traceback_text = "".join(traceback.format_stack()[:-1])
    else:
        traceback_text = ""
    lines = [
        (
            f"{timestamp} session={session_id} {label} event={event} "
            f"function={function_name or '-'} exit_code={exit_code if exit_code is not None else '-'} "
            f"paths={json.dumps(path_values, ensure_ascii=False, sort_keys=True)}"
        )
    ]
    if message or exception:
        lines.append(
            f"exception_type={exception_type or '-'} exception_message={exception_message or '-'}"
        )
    if message and exception:
        lines.append(f"context={_redact_text(message)}")
    if traceback_text:
        lines.append("TRACEBACK:")
        lines.append(_redact_text(traceback_text))
    try:
        with _trace_path(data_root).open("a", encoding="utf-8") as handle:
            handle.write("\n".join(lines) + "\n")
    except OSError:
        logging.getLogger(__name__).exception("Zajednički updater trace log nije dostupan.")
    return label


def read_state(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Update state nije validan.")
    return data


def write_state(path, **changes):
    path = Path(path).resolve()
    state = read_state(path) if path.exists() else {}
    if "error_message" in changes:
        changes["error_message"] = safe_message(changes["error_message"])
    if "rollback_error_message" in changes:
        changes["rollback_error_message"] = safe_message(changes["rollback_error_message"])
    state.update(changes)
    state["updated_at"] = datetime.now(timezone.utc).isoformat()
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, path)
    return state


def public_state(state):
    result = {key: state.get(key) for key in PUBLIC_STATE_FIELDS if key in state}
    if "error_message" in result:
        result["error_message"] = safe_message(result["error_message"])
    if "rollback_error_message" in result:
        result["rollback_error_message"] = safe_message(result["rollback_error_message"])
    return result


def safe_message(value):
    value = str(value or "")[:1000]
    value = _redact_text(value)
    return re.sub(r"(?:[A-Za-z]:[\\/]|\\\\)[^\s'\"]+", "[PATH]", value)


def _redact_text(value):
    value = re.sub(r"(?i)(password|secret_key|token)\s*[=:]\s*\S+", r"\1=[REDACTED]", str(value or ""))
    return value
