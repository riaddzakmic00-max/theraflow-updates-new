"""Presentation-only organizacija ekrana Zalihe.

Ovaj modul ne računa zalihe niti komisijske potrebe. On isključivo grupiše i
sortira već izračunate ``StockRiskService`` redove prema kanonskom terapijskom
tipu te definiše četiri sažete metrike za UI.
"""

from dataclasses import dataclass
from decimal import Decimal

from .therapy_regimens import (
    TYPE_HOME_SC,
    TYPE_INFUSION,
    TYPE_ORAL,
    inventory_behavior,
    therapy_regimen_type,
)


@dataclass(frozen=True)
class InventoryGroupDefinition:
    therapy_type: str
    key: str
    title: str
    subtitle: str
    icon: str


INVENTORY_GROUP_DEFINITIONS = (
    InventoryGroupDefinition(
        therapy_type=TYPE_INFUSION,
        key="infusion",
        title="Venske terapije",
        subtitle="Lijekovi za ambulantnu intravensku primjenu",
        icon="bi-droplet-half",
    ),
    InventoryGroupDefinition(
        therapy_type=TYPE_HOME_SC,
        key="home-sc",
        title="SC / potkožne / kućne terapije",
        subtitle="Potkožna primjena i lijekovi koji se izdaju za kućnu terapiju",
        icon="bi-house-heart",
    ),
    InventoryGroupDefinition(
        therapy_type=TYPE_ORAL,
        key="oral",
        title="Oralne terapije / tablete",
        subtitle="Lijekovi koji se izdaju pacijentu za oralnu primjenu",
        icon="bi-capsule-pill",
    ),
)


def _quantity(value):
    return Decimal(str(value or 0))


def row_has_physical_shortfall(row):
    """Fizički manjak ostaje odvojen od komisijske buduće potrebe."""

    return bool(
        row.get("fizicki_manjak_rezervacija")
        or row.get("oralno_bez_fizickog_pokrica")
        or _quantity(row.get("physical_shortfall")) > 0
    )


def _compact_status(row, therapy_type):
    if _quantity(row.get("broj_nevazecih_rezervacija")) > 0:
        return (
            "reservation_review",
            "Potrebno osloboditi rezervaciju",
            "critical",
        )
    if row_has_physical_shortfall(row):
        return "physical_shortfall", "Fizički manjak", "critical"
    if _quantity(row.get("ceka_fizicko_pokrice")) > 0:
        return "awaiting_physical", "Još nije fizički osigurano", "waiting"
    if row.get("treba_komisiju") or _quantity(row.get("za_novu_komisiju")) > 0:
        if row.get("status_css") == "critical" and row.get("status"):
            return "commission", row["status"], "critical"
        return "commission", "Potrebna komisija", "commission"
    if row.get("konfiguracija_nepotpuna") or not row.get("procjena_moguca", True):
        return "configuration", "Konfiguracija nepotpuna", "neutral"
    if not row.get("broj_aktivnih_pacijenata"):
        return "inactive", "Nema aktivnih pacijenata", "neutral"
    source_css = row.get("status_css") or "ok"
    if source_css in {"waiting", "ready", "neutral", "critical"}:
        return "operational", row.get("status") or "Za pregled", source_css
    return "ok", "Uredno", "ok"


def _metric(key, label, value, *, quantity_kind="stock", alert=False):
    return {
        "key": key,
        "label": label,
        "value": value,
        "quantity_kind": quantity_kind,
        "alert": alert,
    }


def _compact_metrics(row, therapy_type, behavior):
    future_uncovered = _metric(
        "future-uncovered",
        "Buduće potrebno",
        row.get("buduca_nepokrivena_potreba", Decimal("0")),
    )
    commission = _metric(
        "commission",
        "Za novu komisiju",
        row.get("za_novu_komisiju", Decimal("0")),
        quantity_kind="commission",
    )
    existing_requests = (
        _metric(
            "existing-requests",
            "Odobreno u postojećim zahtjevima",
            row.get("odobreno_u_postojecim_zahtjevima", Decimal("0")),
        ),
    ) if _quantity(row.get("odobreno_u_postojecim_zahtjevima")) > 0 else ()
    awaiting_receipt = (
        _metric(
            "approved-awaiting-receipt",
            "Odobreno – čeka zaprimanje",
            row.get("odobreno_ceka_zaprimanje", Decimal("0")),
            alert=True,
        ),
    ) if _quantity(row.get("odobreno_ceka_zaprimanje")) > 0 else ()
    if therapy_type == TYPE_HOME_SC:
        return (
            _metric("stock", behavior.stock_label, row.get("u_frizideru", 0)),
            _metric("at-patient", "Kod pacijenata", row.get("kod_pacijenata", 0)),
            _metric("reserved", "Rezervisano", row.get("rezervisano", 0)),
            _metric(
                "awaiting",
                "Još nije fizički osigurano",
                row.get("ceka_fizicko_pokrice", 0),
                alert=_quantity(row.get("ceka_fizicko_pokrice")) > 0,
            ),
            future_uncovered,
            *existing_requests,
            *awaiting_receipt,
            commission,
        )
    if therapy_type == TYPE_ORAL:
        return (
            _metric("stock", behavior.stock_label, row.get("u_frizideru", 0)),
            _metric("at-patient", "Kod pacijenata", row.get("kod_pacijenata", 0)),
            _metric("free", behavior.free_label, row.get("slobodno_raspolozivo", 0)),
            _metric(
                "awaiting",
                "Još nije fizički osigurano",
                row.get("ceka_fizicko_pokrice", 0),
                alert=_quantity(row.get("ceka_fizicko_pokrice")) > 0,
            ),
            future_uncovered,
            *existing_requests,
            *awaiting_receipt,
            commission,
        )
    return (
        _metric("stock", behavior.stock_label, row.get("u_frizideru", 0)),
        _metric("reserved", "Rezervisano (fizički)", row.get("rezervisano", 0)),
        _metric("free", behavior.free_label, row.get("slobodno_raspolozivo", 0)),
        _metric(
            "awaiting",
            "Još nije fizički osigurano",
            row.get("ceka_fizicko_pokrice", 0),
            alert=_quantity(row.get("ceka_fizicko_pokrice")) > 0,
        ),
        future_uncovered,
        *existing_requests,
        *awaiting_receipt,
        commission,
    )


def _priority(row):
    if _quantity(row.get("broj_nevazecih_rezervacija")) > 0 or row_has_physical_shortfall(row):
        return 0
    if _quantity(row.get("ceka_fizicko_pokrice")) > 0:
        return 1
    if _quantity(row.get("odobreno_ceka_zaprimanje")) > 0:
        return 2
    if row.get("treba_komisiju") or _quantity(row.get("za_novu_komisiju")) > 0:
        return 2
    if row.get("konfiguracija_nepotpuna") or not row.get("procjena_moguca", True):
        return 3
    return 4


def _medicine_sort_label(row):
    medicine = row["lijek"]
    return (
        str(getattr(medicine, "brand_name", "") or getattr(medicine, "naziv", "")).casefold(),
        getattr(medicine, "pk", 0) or 0,
    )


def build_inventory_presentation(rows):
    """Vrati grupisane/dekorisane redove bez promjene izvornih kalkulacija."""

    buckets = {item.therapy_type: [] for item in INVENTORY_GROUP_DEFINITIONS}
    for source_row in rows:
        row = dict(source_row)
        therapy_type = therapy_regimen_type(row["lijek"])
        behavior = inventory_behavior(row["lijek"])
        status_key, status_label, status_css = _compact_status(row, therapy_type)
        row.update(
            therapy_type=therapy_type,
            inventory_behavior=behavior,
            inventory_stock_label=behavior.stock_label,
            inventory_reserved_label=behavior.reserved_label,
            inventory_free_label=behavior.free_label,
            inventory_patient_label=behavior.patient_quantity_label,
            inventory_patient_help=behavior.patient_quantity_help,
            kod_pacijenata_primjenjivo=behavior.patient_quantity_applicable,
            kucna_terapija=therapy_type == TYPE_HOME_SC,
            oralna_terapija=therapy_type == TYPE_ORAL,
            compact_metrics=_compact_metrics(row, therapy_type, behavior),
            compact_status_key=status_key,
            compact_status_label=status_label,
            compact_status_css=status_css,
            inventory_priority=_priority(row),
            has_physical_shortfall=row_has_physical_shortfall(row),
        )
        buckets[therapy_type].append(row)

    groups = []
    ordered_rows = []
    for definition in INVENTORY_GROUP_DEFINITIONS:
        group_rows = sorted(
            buckets[definition.therapy_type],
            key=lambda row: (row["inventory_priority"], *_medicine_sort_label(row)),
        )
        ordered_rows.extend(group_rows)
        groups.append({
            "key": definition.key,
            "therapy_type": definition.therapy_type,
            "title": definition.title,
            "subtitle": definition.subtitle,
            "icon": definition.icon,
            "rows": group_rows,
            "broj_lijekova": len(group_rows),
            "broj_urednih": sum(
                1 for row in group_rows if row["compact_status_key"] == "ok"
            ),
            "broj_fizicki_manjak": sum(
                1 for row in group_rows if row["has_physical_shortfall"]
            ),
            "broj_ceka_fizicko_pokrice": sum(
                1 for row in group_rows
                if _quantity(row.get("ceka_fizicko_pokrice")) > 0
            ),
            "broj_za_komisiju": sum(
                1 for row in group_rows if row.get("treba_komisiju")
            ),
        })

    overview = {
        "ukupno_lijekova": len(ordered_rows),
        "lijekovi_sa_fizickim_manjkom": sum(
            1 for row in ordered_rows if row["has_physical_shortfall"]
        ),
        "lijekovi_koji_cekaju_fizicko_pokrice": sum(
            1 for row in ordered_rows
            if _quantity(row.get("ceka_fizicko_pokrice")) > 0
        ),
        "lijekovi_za_komisijsku_pripremu": sum(
            1 for row in ordered_rows if row.get("treba_komisiju")
        ),
        "lijekovi_za_konfiguraciju": sum(
            1 for row in ordered_rows if row.get("konfiguracija_nepotpuna")
        ),
    }
    return {
        "groups": groups,
        "rows": ordered_rows,
        "overview": overview,
    }
