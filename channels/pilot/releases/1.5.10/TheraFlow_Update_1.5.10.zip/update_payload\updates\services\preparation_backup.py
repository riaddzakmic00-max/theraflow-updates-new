import hashlib
import getpass
import json
import logging
import os
import stat
import zipfile
from pathlib import Path

from django.conf import settings
from django.utils import timezone

from dashboard.postgres_backup import (
    BackupError,
    create_postgres_backup_at,
    postgres_settings,
    validate_postgres_backup,
)


logger = logging.getLogger(__name__)
DEFAULT_CRITICAL_CONFIG = ()
DEFAULT_OPTIONAL_CONFIG = (
    "start_theraflow.bat",
    "run_theraflow.py",
    "install_runtime.bat",
    "install_runtime.ps1",
    "service/install_service.bat",
    "service/install_backup_scheduler_service.bat",
    "service/backup_scheduler_service.py",
    "service/install_updater_service.bat",
    "service/restart_service.bat",
    "service/uninstall_service.bat",
    "service/README.md",
    "config/local_settings.py",
)


class ConfigBackupError(RuntimeError):
    def __init__(self, code, message, path=None):
        self.code = code
        self.path = str(path) if path is not None else None
        super().__init__(message)


def canonical_env_file():
    program_data = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))
    return (program_data / "TheraFlow" / "config" / ".env").resolve()


def process_identity():
    identity = getpass.getuser() or "unknown"
    elevated = None
    if os.name == "nt":
        try:
            import ctypes

            elevated = bool(ctypes.windll.shell32.IsUserAnAdmin())
        except (AttributeError, OSError):
            elevated = None
    return {"identity": identity, "elevated": elevated, "pid": os.getpid()}


def _canonical_env_bytes(path):
    path = Path(path).resolve()
    diagnostic = process_identity()
    logger.info(
        "Canonical env validation resolved_path=%s process_identity=%s elevated=%s pid=%s",
        path,
        diagnostic["identity"],
        diagnostic["elevated"],
        diagnostic["pid"],
    )
    try:
        parent_status = path.parent.stat()
    except FileNotFoundError as exc:
        raise ConfigBackupError(
            "canonical_env_directory_not_found",
            f"Direktorij kanonske konfiguracije nije pronađen: {path.parent}",
            path,
        ) from exc
    except PermissionError as exc:
        raise ConfigBackupError(
            "canonical_env_unauthorized",
            f"Proces nema dozvolu za pristup direktoriju kanonske konfiguracije: {path.parent}",
            path,
        ) from exc
    if not stat.S_ISDIR(parent_status.st_mode):
        raise ConfigBackupError(
            "canonical_env_directory_not_found",
            f"Putanja kanonske konfiguracije nije direktorij: {path.parent}",
            path,
        )
    try:
        file_status = path.stat()
        if not stat.S_ISREG(file_status.st_mode):
            raise ConfigBackupError(
                "canonical_env_invalid_content",
                f"Kanonska konfiguracija nije regularan fajl: {path}",
                path,
            )
        payload = path.read_bytes()
    except FileNotFoundError as exc:
        raise ConfigBackupError(
            "canonical_env_file_not_found",
            f"Kanonski produkcijski .env nije pronađen: {path}",
            path,
        ) from exc
    except PermissionError as exc:
        raise ConfigBackupError(
            "canonical_env_unauthorized",
            f"Proces nema dozvolu za čitanje kanonskog produkcijskog .env: {path}",
            path,
        ) from exc
    try:
        text = payload.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ConfigBackupError(
            "canonical_env_invalid_content",
            "Kanonski produkcijski .env nije validan UTF-8 tekst.",
            path,
        ) from exc
    values = {}
    for line_number, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ConfigBackupError(
                "canonical_env_invalid_content",
                f"Kanonski produkcijski .env ima neispravan red {line_number}.",
                path,
            )
        key, value = line.split("=", 1)
        key = key.strip()
        if not key:
            raise ConfigBackupError(
                "canonical_env_invalid_content",
                f"Kanonski produkcijski .env ima prazan ključ u redu {line_number}.",
                path,
            )
        values[key] = value.strip()
    if not values.get("SECRET_KEY"):
        raise ConfigBackupError(
            "canonical_env_invalid_content",
            "Kanonski produkcijski .env nema neprazan SECRET_KEY.",
            path,
        )
    return payload


def sha256_file(path, chunk_size=1024 * 1024):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_source(root, relative):
    relative = Path(relative)
    if relative.is_absolute() or ".." in relative.parts:
        raise ConfigBackupError("application_config_path_invalid", "Neispravna konfiguracijska putanja.")
    if any(part.lower() in {".git", ".venv", "backups", "logs", "__pycache__", "node_modules"} for part in relative.parts):
        raise ConfigBackupError("application_config_path_excluded", "Konfiguracijska putanja je na listi isključenih direktorija.")
    source = (root / relative).resolve()
    if root != source and root not in source.parents:
        raise ConfigBackupError("application_config_path_escape", "Konfiguracijska putanja izlazi iz aplikacijskog direktorija.")
    return source


def create_database_backup(backup_root, current_version, target_version, session_id=None):
    backup_root = Path(backup_root).resolve()
    dump_path = backup_root / "theraflow_database.dump"
    logger.info("Početak update database backupa.")
    create_postgres_backup_at(dump_path)
    validate_postgres_backup(dump_path)
    database = postgres_settings()
    metadata = {
        "created_at": timezone.now().isoformat(),
        "current_version": current_version,
        "target_version": target_version,
        "session_id": str(session_id or ""),
        "database_engine": "postgresql",
        "database_name": str(database.get("NAME", "")),
        "dump_filename": dump_path.name,
        "dump_size_bytes": dump_path.stat().st_size,
        "dump_sha256": sha256_file(dump_path),
        "validation": "pg_restore_list_passed",
    }
    (backup_root / "backup_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    logger.info("Update database backup i pg_restore validacija su uspješni.")
    return dump_path, metadata


def create_config_backup(backup_root, application_root=None, critical=None, optional=None, env_file=None):
    backup_root = Path(backup_root).resolve()
    root = Path(application_root or settings.BASE_DIR).resolve()
    critical = tuple(critical if critical is not None else getattr(settings, "THERAFLOW_UPDATE_CRITICAL_CONFIG", DEFAULT_CRITICAL_CONFIG))
    optional = tuple(optional if optional is not None else getattr(settings, "THERAFLOW_UPDATE_OPTIONAL_CONFIG", DEFAULT_OPTIONAL_CONFIG))
    files = []
    canonical_env = Path(env_file or canonical_env_file()).resolve()
    canonical_payload = _canonical_env_bytes(canonical_env)
    canonical_sha256 = hashlib.sha256(canonical_payload).hexdigest()
    files.append((".env", canonical_env, "canonical_env", canonical_sha256))
    for relative in critical:
        source = _safe_source(root, relative)
        if not source.is_file():
            raise ConfigBackupError("application_config_file_not_found", f"Nedostaje kritični konfiguracijski fajl: {relative}", source)
        files.append((str(Path(relative).as_posix()), source, "application", sha256_file(source)))
    for relative in optional:
        source = _safe_source(root, relative)
        if source.is_file():
            files.append((str(Path(relative).as_posix()), source, "application", sha256_file(source)))

    archive_path = backup_root / "theraflow_config_backup.zip"
    manifest_path = backup_root / "config_backup_manifest.json"
    manifest_entries = []
    logger.info("Početak backupa lokalne TheraFlow konfiguracije.")
    try:
        with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for relative, source, target_scope, source_sha256 in files:
                backup_path = ".env" if target_scope == "canonical_env" else f"application/{relative}"
                archive.write(source, arcname=backup_path)
                manifest_entries.append({
                    "original_path": relative,
                    "backup_path": backup_path,
                    "target_scope": target_scope,
                    "size_bytes": source.stat().st_size,
                    "sha256": source_sha256,
                    "backed_up_at": timezone.now().isoformat(),
                })
        if sha256_file(canonical_env) != canonical_sha256:
            raise ConfigBackupError(
                "canonical_env_changed_during_backup",
                "Kanonski produkcijski .env je promijenjen tokom backupa; update je sigurno zaustavljen.",
                canonical_env,
            )
        manifest = {
            "created_at": timezone.now().isoformat(),
            "files": manifest_entries,
        }
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
        if not archive_path.is_file() or archive_path.stat().st_size == 0:
            raise ConfigBackupError("config_backup_failed", "Backup konfiguracije nije uspješno kreiran.")
    except Exception as exc:
        archive_path.unlink(missing_ok=True)
        manifest_path.unlink(missing_ok=True)
        if isinstance(exc, ConfigBackupError):
            raise
        raise ConfigBackupError("config_backup_failed", "Backup konfiguracije nije uspješno kreiran.") from exc
    logger.info("Backup lokalne TheraFlow konfiguracije je završen.")
    return archive_path, manifest_path, manifest
