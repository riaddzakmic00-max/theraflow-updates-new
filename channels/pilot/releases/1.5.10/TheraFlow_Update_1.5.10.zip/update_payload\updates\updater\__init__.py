"""Standalone TheraFlow updater runtime. Uses only the Python standard library."""
