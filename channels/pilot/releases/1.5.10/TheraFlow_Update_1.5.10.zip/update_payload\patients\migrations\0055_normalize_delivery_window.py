from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import migrations, models


def normalize_delivery_window(apps, schema_editor):
    Settings = apps.get_model("patients", "PostavkeSistema")
    Settings.objects.filter(vrijeme_isporuke_dana__lt=15).update(
        vrijeme_isporuke_dana=18
    )
    Settings.objects.filter(vrijeme_isporuke_dana__gt=20).update(
        vrijeme_isporuke_dana=18
    )


class Migration(migrations.Migration):
    dependencies = [("patients", "0054_komisijskirucniunos")]

    operations = [
        migrations.RunPython(normalize_delivery_window, migrations.RunPython.noop),
        migrations.AlterField(
            model_name="postavkesistema",
            name="vrijeme_isporuke_dana",
            field=models.PositiveIntegerField(
                default=18,
                validators=[MinValueValidator(15), MaxValueValidator(20)],
            ),
        ),
    ]
