from django.db import migrations
from django.db.models import Q


ADALIMUMAB_BRANDS = ("Hyrimoz", "Humira", "Amgevita", "Imraldi", "Yuflyma")


def normalize_hyrimoz_home_capability(apps, schema_editor):
    Lijek = apps.get_model("patients", "Lijek")
    adalimumab = (
        Q(terapijski_program__kljuc="adalimumab")
        | Q(genericki_naziv__iexact="adalimumab")
        | Q(zasticeno_ime__in=ADALIMUMAB_BRANDS)
        | Q(naziv__iexact="adalimumab")
        | Q(naziv__icontains="Hyrimoz")
    )
    Lijek.objects.filter(adalimumab).update(
        kucna_primjena=True,
        nacin_primjene="KUCNA_TERAPIJA",
        put_primjene="SC",
        package_size_in_doses=2,
        izdavanje_cijelih_pakovanja=True,
        jedinica_terapije="pen",
        jedinica_terapije_mnozina="pena",
        jedinica_zalihe="pen",
        jedinica_zalihe_mnozina="penovi",
    )


class Migration(migrations.Migration):
    dependencies = [("patients", "0091_backfill_free_stock_reason_codes")]

    operations = [
        migrations.RunPython(
            normalize_hyrimoz_home_capability,
            migrations.RunPython.noop,
        ),
    ]
