from collections import defaultdict
from datetime import date, datetime, timedelta
from decimal import Decimal

from django.db.models import Min, Sum
from django.urls import reverse
from django.utils import timezone

from .commission_demand import commission_demand_v2_enabled
from .commission_planning import commission_planning_rows
from .commission_service import get_commission_schedule, patients_for_next_commission
from .inventory import zalihe_sa_potrebama
from .medication_groups import (
    equivalent_medicine_ids,
    get_therapy_group,
    strict_equivalent_medicine_ids,
)
from .models import (
    Komisija,
    KomisijskiZahtjev,
    Lijek,
    Pacijent,
    PauzaTerapije,
    PromjenaTerapije,
    Terapija,
    Termin,
    Trebovanje,
)
from .services import izracunaj_status_pacijenta
from .therapy_history import actually_administered_therapy_query


def _decimal(value):
    return Decimal(str(value or 0))


def _patient_item(patient, reason, next_step="Otvori karton pacijenta", **extra):
    return {
        "pacijent": patient,
        "lijek": patient.lijek,
        "razlog": reason,
        "sljedeci_korak": next_step,
        "url": reverse("profil_pacijenta", args=[patient.pk]),
        **extra,
    }


def build_report_data(
    *,
    start,
    end,
    medicine=None,
    therapy_type="",
    phase="",
    patient_status="",
    active_only=True,
    inactive_only=False,
    show_inactive=False,
):
    medicine_ids = equivalent_medicine_ids(medicine) if medicine else []
    patients = Pacijent.objects.select_related(
        "lijek", "terapijski_program", "terapijski_protokol"
    )
    if inactive_only:
        patients = patients.filter(aktivan=False)
    elif active_only:
        patients = patients.filter(aktivan=True)
    if medicine:
        patients = patients.filter(lijek_id__in=medicine_ids)
    patients = list(patients)
    patient_statuses = {patient.pk: izracunaj_status_pacijenta(patient) for patient in patients}
    if patient_status:
        patients = [
            patient for patient in patients
            if patient_statuses[patient.pk].get("status") == patient_status
        ]
    patient_ids = [patient.pk for patient in patients]

    commission_requests = list(
        KomisijskiZahtjev.objects.filter(
            datum_kreiranja__date__gte=start,
            datum_kreiranja__date__lte=end,
        )
        .select_related("pacijent", "komisijski_ciklus")
        .prefetch_related("stavke_lijeka__lijek")
        .order_by("-datum_kreiranja", "-pk")
    )
    if medicine:
        commission_requests = [
            request
            for request in commission_requests
            if any(item.lijek_id in medicine_ids for item in request.stavke_lijeka.all())
        ]

    therapies = Terapija.objects.filter(
        datum__gte=start,
        datum__lte=end,
        workflow_status=Terapija.STATUS_POTVRDJENA,
        is_migration=False,
    ).select_related("pacijent", "lijek")
    if medicine:
        therapies = therapies.filter(lijek_id__in=medicine_ids)
    if therapy_type in {Terapija.TIP_AMBULANTA, Terapija.TIP_KUCNA_TERAPIJA}:
        therapies = therapies.filter(tip_evidencije=therapy_type)
    if phase:
        therapies = therapies.filter(faza_terapije__iexact=phase)
    if active_only or inactive_only or patient_status:
        therapies = therapies.filter(pacijent_id__in=patient_ids)

    ambulatory = therapies.filter(tip_evidencije=Terapija.TIP_AMBULANTA)
    home = therapies.filter(tip_evidencije=Terapija.TIP_KUCNA_TERAPIJA)
    ambulatory_units = _decimal(ambulatory.aggregate(total=Sum("kolicina"))["total"])
    home_units = _decimal(home.aggregate(total=Sum("kolicina"))["total"])

    commission_items = (
        [row for row in commission_planning_rows() if row["kategorija"] == "ukljuciti"]
        if commission_demand_v2_enabled()
        else patients_for_next_commission()
    )
    commission_items = [item for item in commission_items if item["pacijent"].pk in patient_ids]
    commission_by_patient = {item["pacijent"].pk: item for item in commission_items}

    operational = defaultdict(list)
    today = timezone.localdate()
    for patient in patients:
        status = patient_statuses[patient.pk]
        if patient.pk in commission_by_patient:
            need = commission_by_patient[patient.pk]
            operational["commission"].append(_patient_item(
                patient,
                f"Neto potreba {need['izracunata_potreba']:g} doza; za komisiju {need['za_novu_komisiju']:g} doza.",
                "Pripremiti komisijski zahtjev",
                **need,
            ))
        future_exists = Termin.objects.filter(
            pacijent=patient,
            datum__gte=today,
            status=Termin.STATUS_PLANIRANA,
        ).exists()
        if patient.trenutni_korak_je_ambulanta() and not future_exists:
            operational["without_appointment"].append(_patient_item(
                patient, "Nema budućeg planiranog termina.", "Zakazati terapiju"
            ))
        if status.get("status") in {
            "Nema fizičkih doza kod pacijenta", "Nedovoljno kućnih doza",
            "Nema odobrenih doza", "Potrebna nova komisija",
        }:
            operational["without_doses"].append(_patient_item(
                patient, status.get("status_razlog") or status.get("status"),
                "Provjeriti komisiju i raspoložive doze",
                dostupno=status.get("trenutno_dostupno", 0),
                potrebno=status.get("potrebe_komisije", {}).get("ukupno_potrebno", 0),
            ))
        if status.get("status") == "Terapija kasni":
            planned = status.get("sljedeca_terapija")
            operational["late"].append(_patient_item(
                patient, status.get("status_razlog"), "Kontaktirati pacijenta i zakazati termin",
                planirani_datum=planned,
                dana_kasnjenja=(today - planned).days if planned else None,
            ))

    event_terms = Termin.objects.filter(datum__gte=start, datum__lte=end).select_related("pacijent", "lijek")
    if medicine:
        event_terms = event_terms.filter(lijek_id__in=medicine_ids)
    if active_only or inactive_only or patient_status:
        event_terms = event_terms.filter(pacijent_id__in=patient_ids)
    for term in event_terms.filter(status=Termin.STATUS_NIJE_DOSAO):
        operational["no_show"].append(_patient_item(term.pacijent, "Pacijent nije došao na zakazani termin.", "Ponovo zakazati", datum=term.datum))
    for term in event_terms.filter(status=Termin.STATUS_ODGODJENA):
        operational["postponed"].append(_patient_item(term.pacijent, "Terapija je odgođena.", "Provjeriti novi termin", datum=term.datum))
    for term in event_terms.filter(status=Termin.STATUS_OTKAZANA):
        operational["cancelled"].append(_patient_item(term.pacijent, "Termin je otkazan.", "Provjeriti plan terapije", datum=term.datum))
    pauses = PauzaTerapije.objects.filter(aktivna=True).select_related("pacijent", "pacijent__lijek")
    if medicine:
        pauses = pauses.filter(pacijent__lijek_id__in=medicine_ids)
    if active_only or inactive_only or patient_status:
        pauses = pauses.filter(pacijent_id__in=patient_ids)
    for pause in pauses:
        operational["pauses"].append(_patient_item(pause.pacijent, pause.razlog, "Procijeniti nastavak terapije", datum=pause.datum_pocetka))

    months = []
    cursor = start.replace(day=1)
    while cursor <= end:
        next_month = cursor.replace(year=cursor.year + 1, month=1) if cursor.month == 12 else cursor.replace(month=cursor.month + 1)
        month_qs = therapies.filter(datum__gte=cursor, datum__lt=next_month)
        amb = _decimal(month_qs.filter(tip_evidencije=Terapija.TIP_AMBULANTA).aggregate(total=Sum("kolicina"))["total"])
        hom = _decimal(month_qs.filter(tip_evidencije=Terapija.TIP_KUCNA_TERAPIJA).aggregate(total=Sum("kolicina"))["total"])
        months.append({"label": cursor.strftime("%m.%Y"), "ambulantno": amb, "kucno": hom, "ukupno": amb + hom})
        cursor = next_month
    max_month = max([m["ukupno"] for m in months] or [Decimal("1")]) or Decimal("1")
    for month in months:
        month["ambulantno_width"] = int(month["ambulantno"] / max_month * 100)
        month["kucno_width"] = int(month["kucno"] / max_month * 100)

    inventory_rows = zalihe_sa_potrebama()
    if medicine:
        inventory_rows = [row for row in inventory_rows if get_therapy_group(row["lijek"]) == get_therapy_group(medicine)]
    schedule = get_commission_schedule(today=end)
    commission_inventory = []
    drug_activity = []
    for row in inventory_rows:
        drug = row["lijek"]
        # Inventory/procurement totals must follow the physical presentation.
        # In particular, Ustekinumab IV vials and SC pens are never merged.
        group_ids = strict_equivalent_medicine_ids(drug)
        active_count = sum(1 for patient in patients if patient.aktivan and patient.lijek_id in group_ids)
        drug_therapies = therapies.filter(lijek_id__in=group_ids)
        amb = _decimal(drug_therapies.filter(tip_evidencije=Terapija.TIP_AMBULANTA).aggregate(total=Sum("kolicina"))["total"])
        hom = _decimal(drug_therapies.filter(tip_evidencije=Terapija.TIP_KUCNA_TERAPIJA).aggregate(total=Sum("kolicina"))["total"])
        requests = Trebovanje.objects.filter(lijek_id__in=group_ids)
        requested = _decimal(requests.aggregate(total=Sum("broj_doza"))["total"])
        approved = _decimal(requests.aggregate(total=Sum("odobrene_doze"))["total"])
        received = _decimal(requests.aggregate(total=Sum("zaprimljene_doze"))["total"])
        waiting = sum((max(Decimal("0"), _decimal(req.odobrene_doze) - _decimal(req.zaprimljene_doze)) for req in requests.filter(status="ODOBRENO")), Decimal("0"))
        rights = _decimal(Komisija.objects.filter(lijek_id__in=group_ids, status__in=Komisija.VAZECI_STATUSI).aggregate(total=Sum("preostale_doze"))["total"])
        needed = _decimal(row["potreba_do_ocekivane_isporuke"])
        physical = _decimal(row["ukupno_fizicko_stanje"])
        coverage_percent = int(min(physical / needed * 100, Decimal("999"))) if active_count and needed else None
        stockout = row.get("prvi_pacijent_bez_pokrica_datum")
        coverage_weeks = (
            max((stockout - end).days, 0) // 7
            if stockout else None
        )
        item = {
            **row,
            "aktivni_pacijenti": active_count,
            "stvarna_neto_potreba": _decimal(row.get("izracunata_potreba_komisije")),
            "kolicina_za_komisiju": _decimal(row["za_novu_komisiju"]),
            "broj_pakovanja": row.get("broj_pakovanja_komisije", 0),
            "ukupno_trazeno": requested,
            "ukupno_odobreno": approved,
            "fizicki_zaprimljeno": received,
            "odobreno_ceka_isporuku": waiting,
            "primijenjeno_ambulantno": amb,
            "izdano_kucno": hom,
            "ukupno_razduzeno": amb + hom,
            "preostalo_pravo": rights,
            "pokrivenost_procenat": coverage_percent,
            "pokrivenost_sedmica": coverage_weeks,
            "ocekivani_nestanak": stockout,
            "ocekivana_isporuka": schedule.expected_delivery_date,
            "nije_primjenjivo": active_count == 0,
        }
        if show_inactive or active_count or amb or hom or requested or physical or item["kolicina_za_komisiju"]:
            commission_inventory.append(item)
        if active_count or amb or hom:
            total = amb + hom
            drug_activity.append({
                "lijek": drug,
                "aktivni": active_count,
                "ambulantno": amb,
                "kucno": hom,
                "ukupno": total,
                "prosjek_mjesecno": (total / max(len(months), 1)).quantize(Decimal("0.1")),
            })

    phases = defaultdict(lambda: {"indukcija": 0, "odrzavanje": 0})
    for patient in patients:
        key = patient.terapija_za_prikaz
        if "induk" in (patient.terapijska_faza() or "").lower():
            phases[key]["indukcija"] += 1
        else:
            phases[key]["odrzavanje"] += 1
    phase_rows = [{"lijek": key, **value} for key, value in phases.items()]
    first_therapies = actually_administered_therapy_query(
        Terapija.objects.all()
    )
    if medicine:
        first_therapies = first_therapies.filter(lijek_id__in=medicine_ids)
    if active_only or inactive_only or patient_status:
        first_therapies = first_therapies.filter(pacijent_id__in=patient_ids)
    first_therapies = list(first_therapies.values("pacijent_id").annotate(first=Min("datum")))
    new_patients = []
    for month in months:
        month_start = datetime.strptime("01." + month["label"], "%d.%m.%Y").date()
        next_month = month_start.replace(year=month_start.year + 1, month=1) if month_start.month == 12 else month_start.replace(month=month_start.month + 1)
        new_patients.append({"label": month["label"], "broj": sum(1 for item in first_therapies if month_start <= item["first"] < next_month)})

    current_keys = (
        "commission",
        "without_appointment",
        "without_doses",
        "late",
        "pauses",
    )
    period_keys = ("no_show", "postponed", "cancelled")
    current_operational = {
        key: operational.get(key, [])
        for key in current_keys
    }
    period_events = {
        key: operational.get(key, [])
        for key in period_keys
    }
    operational_actions = _operational_action_rows(
        current_operational,
        today=today,
    )

    return {
        "patients": patients,
        "therapies": therapies,
        "operational": dict(operational),
        "operational_counts": {key: len(value) for key, value in operational.items()},
        "current_operational": current_operational,
        "current_operational_counts": {
            key: len(value)
            for key, value in current_operational.items()
        },
        "operational_actions": operational_actions,
        "period_events": period_events,
        "period_counts": {
            key: len(value)
            for key, value in period_events.items()
        },
        "critical_problem_count": (
            len(current_operational["without_doses"])
            + len(current_operational["late"])
            + len(current_operational["pauses"])
        ),
        "commission_items": commission_items,
        "therapy_summary": {
            "broj_terapija": therapies.count(),
            "ambulantno": ambulatory_units,
            "kucno": home_units,
            "ukupno": ambulatory_units + home_units,
        },
        "months": months,
        "drug_activity": drug_activity,
        "commission_inventory": commission_inventory,
        "commission_requests": commission_requests,
        "phase_rows": phase_rows,
        "new_patients": new_patients,
        "therapy_changes": PromjenaTerapije.objects.filter(datum_promjene__gte=start, datum_promjene__lte=end).count(),
        "schedule": schedule,
    }


def _operational_action_rows(current_operational, *, today):
    """Build a deduplicated UI worklist without changing canonical decisions."""
    metadata = {
        "late": {
            "label": "Terapija kasni",
            "priority": 0,
            "status": "Kasni",
            "status_class": "red",
            "action_label": "Otvori karton",
        },
        "without_doses": {
            "label": "Nedovoljno doza",
            "priority": 1,
            "status": "Kritično",
            "status_class": "red",
            "action_label": "Otvori plan pokrivenosti",
        },
        "commission": {
            "label": "Za komisiju",
            "priority": 2,
            "status": "Za komisiju",
            "status_class": "amber",
            "action_label": "Otvori Komisijski centar",
        },
        "without_appointment": {
            "label": "Bez termina",
            "priority": 3,
            "status": "Potrebna akcija",
            "status_class": "blue",
            "action_label": "Novi termin",
        },
        "pauses": {
            "label": "Aktivna pauza",
            "priority": 4,
            "status": "Za pregled",
            "status_class": "gray",
            "action_label": "Otvori karton",
        },
    }
    rows_by_patient = {}
    for category, items in current_operational.items():
        category_meta = metadata[category]
        for item in items:
            patient = item["pacijent"]
            deadline = (
                item.get("planirani_datum")
                or item.get("komisiju_pokrenuti_najkasnije")
                or item.get("datum")
            )
            action_url = item["url"]
            if category == "commission":
                action_url = (
                    f"{reverse('komisijski_centar')}?filter=ukljuciti"
                    f"#pacijent-{patient.pk}"
                )
            elif category == "without_appointment":
                action_url = reverse("novi_termin_pacijent", args=[patient.pk])
            elif category == "without_doses":
                action_url = (
                    f"{reverse('profil_pacijenta', args=[patient.pk])}"
                    "?tab=pokrivenost#pokrivenost"
                )

            candidate = {
                **item,
                "kategorije": [category],
                "potrebna_akcija": category_meta["label"],
                "priority": category_meta["priority"],
                "rok": deadline,
                "status_oznaka": category_meta["status"],
                "status_klasa": category_meta["status_class"],
                "action_label": category_meta["action_label"],
                "action_url": action_url,
                "razlozi": [item["razlog"]],
            }
            existing = rows_by_patient.get(patient.pk)
            if existing is None:
                rows_by_patient[patient.pk] = candidate
                continue

            if category not in existing["kategorije"]:
                existing["kategorije"].append(category)
            if item["razlog"] not in existing["razlozi"]:
                existing["razlozi"].append(item["razlog"])
            if candidate["priority"] < existing["priority"]:
                preserved_categories = existing["kategorije"]
                preserved_reasons = existing["razlozi"]
                existing.update(candidate)
                existing["kategorije"] = preserved_categories
                existing["razlozi"] = preserved_reasons

    for row in rows_by_patient.values():
        row["razlog"] = " · ".join(row["razlozi"])
        if row["rok"] and row["rok"] < today:
            row["status_oznaka"] = "Rok prekoračen"
            row["status_klasa"] = "red"

    return sorted(
        rows_by_patient.values(),
        key=lambda row: (
            row["priority"],
            row["rok"] or date.max,
            str(row["pacijent"]).casefold(),
        ),
    )
