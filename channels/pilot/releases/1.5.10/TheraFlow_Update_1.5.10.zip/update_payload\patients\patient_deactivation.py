"""Sigurna deaktivacija pacijenta bez promjene zajedničke fizičke zalihe."""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from .inventory import release_patient_reservations_to_free_stock
from .models import Pacijent, PacijentRezervacija, Termin
from .utils import upisi_log


@dataclass(frozen=True)
class PatientDeactivationResult:
    patient_id: int
    was_active: bool
    released_quantity: Decimal
    released_reservation_ids: tuple[int, ...]
    cancelled_appointment_ids: tuple[int, ...]


@transaction.atomic
def deactivate_patient_safely(
    *,
    patient_id,
    user=None,
    reason,
    reason_code="",
    event_date: date | None = None,
):
    """Deaktiviraj karton, oslobodi rezervacije i otkaži buduće termine.

    Oslobađanje rezervacije mijenja samo pripadnost fizičke doze. Ukupno
    stanje lijeka u frižideru ostaje nepromijenjeno i doza postaje slobodna.
    """

    reason = (reason or "").strip()
    if not reason:
        raise ValueError("Razlog deaktivacije je obavezan.")
    event_date = event_date or timezone.localdate()
    # Pacijent.lijek je nullable. PostgreSQL ne dopušta FOR UPDATE nad
    # nullable stranom OUTER JOIN-a koji bi napravio select_related("lijek").
    # Zaključavamo samo osnovni Pacijent red; lijekovi se zatim čitaju kroz
    # zaključane, obavezne PacijentRezervacija veze.
    patient = Pacijent.objects.select_for_update().get(pk=patient_id)
    was_active = patient.aktivan

    reservations = list(
        PacijentRezervacija.objects.select_for_update()
        .filter(pacijent=patient, aktivno=True, kolicina__gt=0)
        .select_related("lijek")
        .order_by("lijek_id", "id")
    )
    reservation_ids = tuple(item.pk for item in reservations)
    medicines = []
    seen_medicine_ids = set()
    for reservation in reservations:
        if reservation.lijek_id not in seen_medicine_ids:
            seen_medicine_ids.add(reservation.lijek_id)
            medicines.append(reservation.lijek)

    released = Decimal("0")
    for medicine in medicines:
        released += release_patient_reservations_to_free_stock(
            pacijent=patient,
            lijek=medicine,
            user=user,
            reason=reason,
            reason_code=reason_code,
            reference=patient,
            event_date=event_date,
        )

    pending_appointments = list(
        Termin.objects.select_for_update()
        .filter(
            pacijent=patient,
            datum__gte=event_date,
            status__in=(
                Termin.STATUS_PLANIRANA,
                Termin.STATUS_ODGODJENA,
                Termin.STATUS_PAUSIRANA,
            ),
        )
        .order_by("datum", "id")
    )
    appointment_ids = tuple(item.pk for item in pending_appointments)
    if appointment_ids:
        Termin.objects.filter(pk__in=appointment_ids).update(
            status=Termin.STATUS_OTKAZANA
        )

    if patient.aktivan:
        patient.aktivan = False
        patient.save(update_fields=["aktivan"])

    upisi_log(
        user,
        "Deaktivacija pacijenta",
        pacijent=patient,
        objekat=patient,
        opis=(
            f"Prethodno aktivan={was_active}; novo aktivan=False; "
            f"razlog: {reason}; oslobođeno rezervacija={released:g}; "
            f"otkazani budući termini={len(appointment_ids)}."
        ),
    )
    return PatientDeactivationResult(
        patient_id=patient.pk,
        was_active=was_active,
        released_quantity=released,
        released_reservation_ids=reservation_ids,
        cancelled_appointment_ids=appointment_ids,
    )
