"""Logističko planiranje komisije nad projekcijama budućih terapija.

Servis ne mijenja količinski obračun Komisijskog centra. On samo određuje rok
u kojem postojeći komisijski workflow mora biti pokrenut.
"""

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from math import floor

from django.utils import timezone

from .commission_service import get_settings, patient_commission_coverage
from .future_therapy_planning import generate_future_therapies
from .models import LogistickePostavkeLijeka
from .medication_groups import THERAPY_GROUP_ADALIMUMAB, get_therapy_group
from .package_sizes import package_size_for


STATUS_POKRIVEN = "POKRIVEN"
STATUS_PRATITI = "PRATITI"
STATUS_ZA_KOMISIJU = "ZA_KOMISIJU"
STATUS_KRITICNO = "KRITICNO"
LOGISTICS_STATUSES = (
    STATUS_POKRIVEN,
    STATUS_PRATITI,
    STATUS_ZA_KOMISIJU,
    STATUS_KRITICNO,
)


@dataclass(frozen=True)
class LogisticsParameters:
    target_coverage_days: int
    approval_days: int
    delivery_days: int
    safety_reserve_days: int
    source: str

    @property
    def total_lead_days(self):
        return self.approval_days + self.delivery_days

    @property
    def total_planning_days(self):
        return self.total_lead_days + self.safety_reserve_days


@dataclass(frozen=True)
class SafetyReservePolicy:
    applications: int
    maximum_applications: int
    application_quantity: Decimal
    reserve_quantity: Decimal
    maximum_consumption_days: int | None
    source: str


@dataclass(frozen=True)
class CommissionLogisticsPlan:
    pacijent: object
    lijek: object
    datum_prve_nepokrivene_terapije: date | None
    procijenjeni_datum_pokrivenosti: date | None
    datum_fizicke_pokrivenosti: date | None
    najkasniji_datum_pokretanja_komisije: date | None
    ocekivani_datum_dolaska_lijeka: date
    broj_dana_do_rizika: int | None
    status: str
    postavke: LogisticsParameters
    pokrice: dict
    razlog_statusa: str


def resolve_logistics_parameters(lijek, *, settings=None):
    """Spoji postavke ustanove i opcioni override konkretnog lijeka."""

    settings = settings or get_settings()
    try:
        override = lijek.logisticke_postavke
    except LogistickePostavkeLijeka.DoesNotExist:
        override = None

    def resolved(field, fallback):
        value = getattr(override, field, None) if override else None
        return int(fallback if value is None else value)

    return LogisticsParameters(
        target_coverage_days=resolved(
            "ciljni_broj_dana_pokrivenosti",
            settings.ciljni_broj_dana_pokrivenosti,
        ),
        approval_days=resolved(
            "prosjecno_trajanje_odobrenja_komisije_dana",
            settings.prosjecno_trajanje_odobrenja_komisije_dana,
        ),
        delivery_days=resolved(
            "prosjecno_trajanje_dostave_lijeka_dana",
            settings.vrijeme_isporuke_dana,
        ),
        safety_reserve_days=resolved(
            "sigurnosna_rezerva_dana",
            settings.sigurnosna_rezerva_dana,
        ),
        source="LIJEK" if override else "USTANOVA",
    )


def resolve_safety_reserve_policy(
    pacijent,
    *,
    protocol=None,
    application_quantity=None,
):
    """Klinička rezerva izražena u kompletnim terapijskim primjenama."""

    try:
        medicine_settings = pacijent.lijek.logisticke_postavke
    except LogistickePostavkeLijeka.DoesNotExist:
        medicine_settings = None
    protocol_object = getattr(protocol, "source_object", None)

    def configured(field, default=None):
        protocol_value = getattr(protocol_object, field, None)
        if protocol_value is not None:
            return protocol_value, "PROTOKOL"
        medicine_value = (
            getattr(medicine_settings, field, None)
            if medicine_settings else None
        )
        if medicine_value is not None:
            return medicine_value, "LIJEK"
        return default, "DEFAULT"

    requested, source = configured("sigurnosna_rezerva_primjena", 1)
    requested = max(int(requested or 0), 0)
    maximum, maximum_source = configured(
        "maksimalna_sigurnosna_rezerva_primjena",
        max(requested, 1),
    )
    maximum = max(int(maximum or 0), 0)
    applications = min(requested, maximum)

    maximum_consumption_days = (
        int(medicine_settings.maksimalni_rok_potrosnje_dana)
        if medicine_settings
        and medicine_settings.maksimalni_rok_potrosnje_dana
        else None
    )
    interval_weeks = int(
        getattr(protocol, "interval_odrzavanja_sedmica", 0) or 0
    )
    if maximum_consumption_days and interval_weeks > 0:
        consumable_applications = floor(
            maximum_consumption_days / (interval_weeks * 7)
        )
        applications = min(applications, max(consumable_applications, 0))

    quantity = Decimal(str(application_quantity or 0))
    if quantity <= 0 and protocol:
        quantity = Decimal(str(protocol.doza_po_aplikaciji or 0))
    if get_therapy_group(pacijent.lijek) == THERAPY_GROUP_ADALIMUMAB:
        quantity = Decimal(str(package_size_for(pacijent.lijek)))

    return SafetyReservePolicy(
        applications=applications,
        maximum_applications=maximum,
        application_quantity=quantity,
        reserve_quantity=quantity * applications,
        maximum_consumption_days=maximum_consumption_days,
        source=(
            source
            if source == maximum_source
            else f"{source}+MAX_{maximum_source}"
        ),
    )


def _coverage_dates(projections, available_doses):
    remaining = Decimal(str(available_doses or 0))
    covered_until = None
    for projection in projections:
        required = Decimal(str(projection.kolicina_lijeka or 0))
        if required <= 0:
            continue
        if remaining < required:
            return covered_until, projection.datum_terapije
        remaining -= required
        covered_until = projection.datum_terapije
    return covered_until, None


def determine_logistics_status(
    *,
    today,
    first_uncovered_date,
    latest_start_date,
    expected_arrival_date,
    target_coverage_days,
):
    """Jedino mjesto na kojem se određuju logistički statusi."""

    if first_uncovered_date is None:
        return STATUS_POKRIVEN, "Nema nepokrivene terapije u planskom horizontu."
    if expected_arrival_date >= first_uncovered_date:
        return (
            STATUS_KRITICNO,
            "Ako se postupak pokrene danas, lijek ne bi stigao prije nepokrivene terapije.",
        )
    if latest_start_date <= today:
        return (
            STATUS_ZA_KOMISIJU,
            "Dosegnut je najkasniji sigurni datum za pokretanje komisije.",
        )
    if (first_uncovered_date - today).days <= int(target_coverage_days):
        return (
            STATUS_PRATITI,
            "Prva terapija bez pokrića je unutar ciljnog perioda pokrivenosti.",
        )
    return STATUS_POKRIVEN, "Pokrivenost je duža od ciljnog perioda planiranja."


def calculate_patient_commission_logistics(
    pacijent,
    *,
    today=None,
    settings=None,
    interval_changes=None,
):
    """Izračunaj logističke rokove jednog pacijenta bez upisa u bazu."""

    today = today or timezone.localdate()
    if not pacijent or not pacijent.aktivan or not pacijent.lijek_id:
        return None
    parameters = resolve_logistics_parameters(pacijent.lijek, settings=settings)
    # Deset godina ostavlja dovoljno prostora i za duge intervale/pokrivenost,
    # dok zaštita od 1000 događaja ostaje u servisu Faze 1.
    target_date = today + timedelta(days=max(
        3650,
        parameters.target_coverage_days + parameters.total_planning_days + 365,
    ))
    projections = generate_future_therapies(
        pacijent,
        start_date=today,
        target_date=target_date,
        interval_changes=interval_changes,
    )
    coverage = patient_commission_coverage(pacijent)
    covered_until, first_uncovered = _coverage_dates(
        projections,
        coverage["total_covered"],
    )
    physical_doses = coverage["reserved_in_fridge"] + coverage["at_patient"]
    physical_covered_until, _ = _coverage_dates(projections, physical_doses)

    expected_arrival = today + timedelta(days=parameters.total_lead_days)
    latest_start = (
        first_uncovered - timedelta(days=parameters.total_planning_days)
        if first_uncovered
        else None
    )
    days_to_risk = (latest_start - today).days if latest_start else None
    status, reason = determine_logistics_status(
        today=today,
        first_uncovered_date=first_uncovered,
        latest_start_date=latest_start,
        expected_arrival_date=expected_arrival,
        target_coverage_days=parameters.target_coverage_days,
    )
    return CommissionLogisticsPlan(
        pacijent=pacijent,
        lijek=pacijent.lijek,
        datum_prve_nepokrivene_terapije=first_uncovered,
        procijenjeni_datum_pokrivenosti=covered_until,
        datum_fizicke_pokrivenosti=physical_covered_until,
        najkasniji_datum_pokretanja_komisije=latest_start,
        ocekivani_datum_dolaska_lijeka=expected_arrival,
        broj_dana_do_rizika=days_to_risk,
        status=status,
        postavke=parameters,
        pokrice=coverage,
        razlog_statusa=reason,
    )


def logistics_for_active_patients(*, today=None, settings=None, interval_changes_by_patient=None):
    """Grupni read-only ulaz; još nije spojen na Komisijski centar."""

    from .future_therapy_planning import active_patients_for_planning

    changes = interval_changes_by_patient or {}
    return [
        calculate_patient_commission_logistics(
            patient,
            today=today,
            settings=settings,
            interval_changes=changes.get(patient.pk),
        )
        for patient in active_patients_for_planning()
    ]
