"""Presentation adapter for the unified patient therapy timeline."""

from datetime import datetime, time

from django.utils import timezone
from django.utils.dateparse import parse_date, parse_time

from .models import Terapija, TerapijaStatusHistorija, Termin
from .therapy_history import is_actually_administered_therapy


EVENT_PRESENTATION = {
    TerapijaStatusHistorija.DOGADJAJ_TERMIN_ODGODJEN: (
        "TERMIN ODGOĐEN",
        "amber",
        "bi-calendar2-x",
    ),
    TerapijaStatusHistorija.DOGADJAJ_TERMIN_PROMIJENJEN: (
        "PROMIJENJEN TERMIN",
        "blue",
        "bi-calendar2-week",
    ),
    TerapijaStatusHistorija.DOGADJAJ_NIJE_DOSAO: (
        "NIJE DOŠAO",
        "red",
        "bi-person-x",
    ),
    TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_PAUSIRANA: (
        "PRIVREMENO PAUZIRANA",
        "gray",
        "bi-pause-circle",
    ),
    TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_NASTAVLJENA: (
        "TERAPIJA NASTAVLJENA",
        "green",
        "bi-play-circle",
    ),
    TerapijaStatusHistorija.DOGADJAJ_TERMIN_OTKAZAN: (
        "OTKAZAN TERMIN",
        "gray",
        "bi-x-circle",
    ),
    TerapijaStatusHistorija.DOGADJAJ_NOVI_TERMIN: (
        "ZAKAZAN NOVI TERMIN",
        "blue",
        "bi-calendar-plus",
    ),
    TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_PONISTENA: (
        "TERAPIJA PONIŠTENA",
        "gray",
        "bi-arrow-counterclockwise",
    ),
    TerapijaStatusHistorija.DOGADJAJ_SC_KUCNA_TERAPIJA: (
        "KUĆNA SC TERAPIJA",
        "green",
        "bi-house-heart",
    ),
    TerapijaStatusHistorija.DOGADJAJ_SC_AMBULANTNA_TERAPIJA: (
        "SC PRIMJENA U AMBULANTI",
        "blue",
        "bi-hospital",
    ),
    TerapijaStatusHistorija.DOGADJAJ_KUCNO_IZDAVANJE: (
        "KUĆNA TERAPIJA IZDANA",
        "green",
        "bi-box-arrow-up",
    ),
}


def _first_appointment_state(state):
    state = state or {}
    appointments = state.get("termini") or []
    return appointments[0] if appointments else state


def _state_date(state, *keys):
    state = _first_appointment_state(state)
    for key in keys:
        value = state.get(key)
        if value:
            return parse_date(str(value))
    return None


def _state_time(state):
    value = _first_appointment_state(state).get("vrijeme")
    return parse_time(str(value)) if value else None


def _aware_therapy_sort_date(therapy):
    value = datetime.combine(therapy.datum, time.min)
    return timezone.make_aware(value, timezone.get_current_timezone())


def _event_type(history):
    """Map older status-history rows to the same domain event vocabulary."""

    explicit = (history.novo_stanje or {}).get("tip_dogadjaja")
    if explicit:
        return explicit
    if history.novi_status == Termin.STATUS_ODGODJENA:
        return TerapijaStatusHistorija.DOGADJAJ_TERMIN_ODGODJEN
    if history.novi_status == Termin.STATUS_NIJE_DOSAO:
        return TerapijaStatusHistorija.DOGADJAJ_NIJE_DOSAO
    if history.novi_status == Termin.STATUS_PAUSIRANA:
        return TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_PAUSIRANA
    if history.novi_status == Termin.STATUS_OTKAZANA:
        return TerapijaStatusHistorija.DOGADJAJ_TERMIN_OTKAZAN
    if history.novi_status == Termin.STATUS_PLANIRANA:
        if history.prethodni_status == Termin.STATUS_PAUSIRANA:
            return TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_NASTAVLJENA
        return TerapijaStatusHistorija.DOGADJAJ_NOVI_TERMIN
    if history.novi_status == Terapija.STATUS_PONISTENA:
        return TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_PONISTENA
    return history.novi_status


def build_therapy_timeline(*, therapies, histories):
    """Merge clinical applications and workflow events chronologically."""

    items = []
    actual_count = 0
    for therapy in therapies:
        is_actual = is_actually_administered_therapy(therapy)
        if not is_actual:
            # Kućno izdavanje i poništen administrativni unos nisu dokaz
            # kliničke primjene. Njihovi operativni prikazi ostaju u
            # zaduženjima, odnosno u domenskom statusnom događaju.
            continue
        actual_count += 1
        items.append({
            "kind": "therapy",
            "sort_at": _aware_therapy_sort_date(therapy),
            "therapy": therapy,
            "is_actual": True,
            "label": "EVIDENTIRANA TERAPIJA",
            "badge_class": "green",
        })

    event_count = 0
    for history in histories:
        event_type = _event_type(history)
        if (
            history.terapija_id
            and event_type
            in {
                TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_EVIDENTIRANA,
                Terapija.STATUS_POTVRDJENA,
            }
        ):
            # Stvarna primjena je već prikazana bogatijim Terapija zapisom.
            continue
        presentation = EVENT_PRESENTATION.get(event_type)
        if presentation is None:
            presentation = (
                history.novi_status.replace("_", " ").upper(),
                "gray",
                "bi-clock-history",
            )
        previous_state = history.prethodno_stanje or {}
        new_state = history.novo_stanje or {}
        old_date = _state_date(previous_state, "datum", "datum_pocetka")
        if event_type == TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_PAUSIRANA:
            new_date = parse_date(str(new_state.get("datum_pocetka") or "")) or None
        elif event_type == TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_NASTAVLJENA:
            new_date = parse_date(str(new_state.get("datum_nastavka") or "")) or None
        else:
            new_date = _state_date(
                new_state,
                "datum",
                "datum_nastavka",
                "datum_pocetka",
            )
        medicine = (
            getattr(history.termin, "lijek", None)
            or getattr(history.terapija, "lijek", None)
            or _first_appointment_state(new_state).get("lijek_naziv")
            or _first_appointment_state(previous_state).get("lijek_naziv")
        )
        items.append({
            "kind": "event",
            "sort_at": history.datum_vrijeme,
            "history": history,
            "event_type": event_type,
            "label": presentation[0],
            "badge_class": presentation[1],
            "icon": presentation[2],
            "old_date": old_date,
            "old_time": _state_time(previous_state),
            "new_date": new_date,
            "new_time": _state_time(new_state),
            "medicine": medicine,
            "no_inventory_effect": event_type
            in {
                TerapijaStatusHistorija.DOGADJAJ_TERMIN_ODGODJEN,
                TerapijaStatusHistorija.DOGADJAJ_TERMIN_PROMIJENJEN,
                TerapijaStatusHistorija.DOGADJAJ_NIJE_DOSAO,
                TerapijaStatusHistorija.DOGADJAJ_TERAPIJA_PAUSIRANA,
                TerapijaStatusHistorija.DOGADJAJ_TERMIN_OTKAZAN,
                TerapijaStatusHistorija.DOGADJAJ_SC_KUCNA_TERAPIJA,
                TerapijaStatusHistorija.DOGADJAJ_SC_AMBULANTNA_TERAPIJA,
                TerapijaStatusHistorija.DOGADJAJ_KUCNO_IZDAVANJE,
            },
        })
        event_count += 1

    items.sort(key=lambda item: item["sort_at"], reverse=True)
    return {
        "items": items,
        "actual_therapy_count": actual_count,
        "event_count": event_count,
    }
