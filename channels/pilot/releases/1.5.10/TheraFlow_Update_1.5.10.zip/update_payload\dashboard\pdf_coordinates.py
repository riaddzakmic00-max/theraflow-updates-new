﻿import copy
import json
from pathlib import Path

from django.conf import settings


PDF_COORDS_JSON = Path(settings.BASE_DIR) / "dashboard" / "pdf_coords.json"


FONT_NAME_MAP = {
    "Helvetica": "DejaVuSans",
    "Helvetica-Bold": "DejaVuSans-Bold",
}


PDF_TEMPLATE_MAP = {
    "zahtjev_zavod": "za_zavod.pdf",
    "razduzenje_zavod": "razduzivanje_sablon.pdf",
    "lista_terapije": "lista_terapije.pdf",
}


ZAHTJEV_ZAVOD_COORDS = {
    "lijek_header": {"x": 300, "y": 735, "font": "DejaVuSans-Bold", "size": 10, "max_width": 230},
    "ustanova": {"x": 300, "y": 685, "font": "DejaVuSans", "size": 9, "max_width": 240},
    "ustanova_linija": {"x": 300, "y": 665, "font": "DejaVuSans", "size": 10, "max_width": 220},
    "datum": {"x": 300, "y": 645, "font": "DejaVuSans", "size": 10, "max_width": 120},
    "jmbg": {"x": 300, "y": 610, "font": "DejaVuSans", "size": 10, "max_width": 160},
    "ime_prezime": {"x": 300, "y": 590, "font": "DejaVuSans-Bold", "size": 10, "max_width": 230},
    "spol": {"x": 300, "y": 570, "font": "DejaVuSans", "size": 10, "max_width": 90},
    "datum_rodjenja": {"x": 300, "y": 550, "font": "DejaVuSans", "size": 10, "max_width": 120},
    "adresa": {"x": 300, "y": 530, "font": "DejaVuSans", "size": 9, "max_width": 240},
    "kanton": {"x": 300, "y": 510, "font": "DejaVuSans", "size": 9, "max_width": 180},
    "mkb_sifra": {"x": 300, "y": 475, "font": "DejaVuSans", "size": 10, "max_width": 110},
    "dijagnoza": {"x": 300, "y": 455, "font": "DejaVuSans", "size": 9, "max_width": 250},
    "hitnost_normalno": {"x": 345, "y": 435, "font": "DejaVuSans-Bold", "size": 12, "max_width": 20},
    "doza": {"x": 300, "y": 390, "font": "DejaVuSans", "size": 9, "max_width": 160},
    "lijek": {"x": 300, "y": 370, "font": "DejaVuSans-Bold", "size": 9, "max_width": 240},
    "lijek_genericki": {"x": 300, "y": 350, "font": "DejaVuSans", "size": 9, "max_width": 240},
    "jacina": {"x": 300, "y": 330, "font": "DejaVuSans", "size": 9, "max_width": 160},
    "oblik": {"x": 300, "y": 310, "font": "DejaVuSans", "size": 9, "max_width": 160},
    "broj_trazenih_doza": {"x": 300, "y": 290, "font": "DejaVuSans-Bold", "size": 10, "max_width": 90},
    "lijek_2": {"x": 224, "y": 348, "font": "DejaVuSans-Bold", "size": 9, "max_width": 240},
    "lijek_genericki_2": {"x": 224, "y": 365, "font": "DejaVuSans", "size": 9, "max_width": 240},
    "jacina_2": {"x": 224, "y": 314, "font": "DejaVuSans", "size": 9, "max_width": 160},
    "oblik_2": {"x": 224, "y": 331, "font": "DejaVuSans", "size": 9, "max_width": 160},
    "broj_trazenih_doza_2": {"x": 227, "y": 299, "font": "DejaVuSans-Bold", "size": 10, "max_width": 90},
    "lijek_3": {"x": 224, "y": 232, "font": "DejaVuSans-Bold", "size": 9, "max_width": 240},
    "lijek_genericki_3": {"x": 224, "y": 249, "font": "DejaVuSans", "size": 9, "max_width": 240},
    "jacina_3": {"x": 224, "y": 198, "font": "DejaVuSans", "size": 9, "max_width": 160},
    "oblik_3": {"x": 224, "y": 215, "font": "DejaVuSans", "size": 9, "max_width": 160},
    "broj_trazenih_doza_3": {"x": 227, "y": 183, "font": "DejaVuSans-Bold", "size": 10, "max_width": 90},
    "ljekar": {"x": 300, "y": 150, "font": "DejaVuSans", "size": 9, "max_width": 220},
    "predsjednik_konzilija": {"x": 300, "y": 130, "font": "DejaVuSans", "size": 9, "max_width": 220},
    "clan_konzilija_1": {"x": 300, "y": 108, "font": "DejaVuSans", "size": 9, "max_width": 220},
    "clan_konzilija_2": {"x": 300, "y": 86, "font": "DejaVuSans", "size": 9, "max_width": 220},
    "napomena": {"x": 300, "y": 66, "font": "DejaVuSans", "size": 8, "max_width": 240},
}


RAZDUZENJE_ZAVOD_COORDS = {
    "pacijent": {"x": 340, "y": 584, "font": "DejaVuSans-Bold", "size": 10, "max_width": 210},
    "jmbg": {"x": 340, "y": 558, "font": "DejaVuSans", "size": 10, "max_width": 160},
    "broj_saglasnosti": {"x": 340, "y": 500, "font": "DejaVuSans", "size": 10, "max_width": 180},
    "datum_odobrenja": {"x": 340, "y": 455, "font": "DejaVuSans", "size": 10, "max_width": 130},
    "mkb_sifra": {"x": 340, "y": 365, "font": "DejaVuSans", "size": 10, "max_width": 120},
    "dijagnoza": {"x": 340, "y": 338, "font": "DejaVuSans", "size": 9, "max_width": 210},
    "lijek": {"x": 80, "y": 235, "font": "DejaVuSans", "size": 9, "max_width": 280},
    "kolicina": {"x": 390, "y": 235, "font": "DejaVuSans", "size": 9, "max_width": 70},
    "serija": {"x": 470, "y": 235, "font": "DejaVuSans", "size": 9, "max_width": 70},
    "utroseno": {"x": 545, "y": 235, "font": "DejaVuSans", "size": 9, "max_width": 42},
    "datum_terapije": {"x": 80, "y": 210, "font": "DejaVuSans", "size": 8, "max_width": 100},
    "datum_razduzenja": {"x": 190, "y": 210, "font": "DejaVuSans", "size": 8, "max_width": 100},
    "ljekar": {"x": 300, "y": 150, "font": "DejaVuSans", "size": 9, "max_width": 220},
    "predsjednik_konzilija": {"x": 300, "y": 130, "font": "DejaVuSans", "size": 9, "max_width": 220},
    "clan_konzilija_1": {"x": 300, "y": 108, "font": "DejaVuSans", "size": 9, "max_width": 220},
    "clan_konzilija_2": {"x": 300, "y": 86, "font": "DejaVuSans", "size": 9, "max_width": 220},
}


LISTA_TERAPIJE_COORDS = {
    "datum": {"x": 470, "y": 730, "font": "DejaVuSans-Bold", "size": 10, "max_width": 100},
    "ime_prezime": {"x": 210, "y": 682, "font": "DejaVuSans-Bold", "size": 10, "max_width": 260},
    "datum_rodjenja": {"x": 110, "y": 700, "font": "DejaVuSans-Bold", "size": 10, "max_width": 120},
    "dijagnoza": {"x": 110, "y": 650, "font": "DejaVuSans-Bold", "size": 10, "max_width": 320},
    "lijek": {"x": 365, "y": 545, "font": "DejaVuSans", "size": 10, "max_width": 190},
    "napomena": {"x": 365, "y": 525, "font": "DejaVuSans", "size": 10, "max_width": 190},
}


PDF_FORMS = {
    "zahtjev_zavod": {
        "label": "Zahtjev Zavod",
        "coords": ZAHTJEV_ZAVOD_COORDS,
    },
    "razduzenje_zavod": {
        "label": "Razduzenje Zavod",
        "coords": RAZDUZENJE_ZAVOD_COORDS,
    },
    "lista_terapije": {
        "label": "Lista terapije",
        "coords": LISTA_TERAPIJE_COORDS,
    },
}


def _default_coords():
    return {key: copy.deepcopy(value["coords"]) for key, value in PDF_FORMS.items()}


def normalize_pdf_coord_fonts(coords):
    for fields in coords.values():
        if not isinstance(fields, dict):
            continue
        for field in fields.values():
            if isinstance(field, dict):
                field["font"] = FONT_NAME_MAP.get(field.get("font"), field.get("font", "DejaVuSans"))
    return coords


def load_all_pdf_coords():
    coords = _default_coords()

    if PDF_COORDS_JSON.exists():
        try:
            saved = json.loads(PDF_COORDS_JSON.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            saved = {}

        for form_key, fields in saved.items():
            if form_key not in coords or not isinstance(fields, dict):
                continue
            for field_name, field_coords in fields.items():
                if field_name in coords[form_key] and isinstance(field_coords, dict):
                    coords[form_key][field_name].update(field_coords)

    return normalize_pdf_coord_fonts(coords)


def get_pdf_coords(form_key):
    return load_all_pdf_coords()[form_key]


def save_pdf_coord(form_key, field_name, x, y):
    coords = load_all_pdf_coords()
    coords[form_key][field_name]["x"] = int(x)
    coords[form_key][field_name]["y"] = int(y)
    normalize_pdf_coord_fonts(coords)
    PDF_COORDS_JSON.write_text(
        json.dumps(coords, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return coords[form_key][field_name]
