import re

from packaging.version import InvalidVersion, Version


__version__ = "1.5.9"

_SAFE_VERSION_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]{0,49}$")


def validate_version_identifier(value):
    """Return the public release identifier after strict local validation."""
    value = str(value)
    if not _SAFE_VERSION_RE.fullmatch(value):
        raise InvalidVersion(f"Invalid version: {value!r}")
    parse_version(value)
    return value


def parse_version(value):
    """Parse normal releases and the controlled TheraFlow ``-test`` suffix."""
    value = str(value)
    if value.endswith("-test"):
        value = f"{value[:-5]}.dev0"
    return Version(value)


def version_label(value=None):
    value = validate_version_identifier(value or __version__)
    if value.endswith("-test"):
        return f"v{value[:-5]} TEST UPDATE"
    return f"v{value}"
