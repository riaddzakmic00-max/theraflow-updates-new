import os
import re
import subprocess
from pathlib import Path

from .state_writer import trace_update_step


class DjangoCommandError(RuntimeError):
    def __init__(self, code, message, exit_code=None):
        self.code = code
        self.exit_code = exit_code
        super().__init__(message)


def canonical_env_file():
    program_data = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))
    return (program_data / "TheraFlow" / "config" / ".env").resolve()


def _env_key_names(path):
    names = []
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key and value.strip():
            names.append(key)
    return sorted(set(names))


def clean_environment(env_file=None):
    allowed = ("SystemRoot", "WINDIR", "PATH", "PATHEXT", "COMSPEC", "TEMP", "TMP", "PROGRAMDATA")
    env = {key: os.environ[key] for key in allowed if key in os.environ}
    env_file = Path(env_file or canonical_env_file()).resolve()
    env.update({
        "DJANGO_SETTINGS_MODULE": "config.settings",
        "PYTHONUTF8": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "THERAFLOW_PRODUCTION": "1",
        "THERAFLOW_ENV_FILE": str(env_file),
    })
    return env


def safe_output(value):
    return re.sub(
        r"(?i)(password|secret_key|token)\s*[=:]\s*\S+",
        r"\1=[REDACTED]",
        value or "",
    )


def run_manage(plan, arguments, timeout=600):
    env_file = canonical_env_file()
    checked_paths = [env_file, Path(plan["application_root"]) / ".env"]
    if not env_file.is_file():
        error = DjangoCommandError(
            "canonical_env_missing",
            f"Kanonski produkcijski .env nije pronađen: {env_file}",
            1,
        )
        trace_update_step(
            9,
            "FAIL",
            session_id=plan.get("session_id", "none"),
            function_name="updates.updater.django_commands.run_manage",
            paths={"canonical_env": env_file, "application_env_ignored": checked_paths[1]},
            exception=error,
            exit_code=1,
            data_root=env_file.parents[1],
        )
        raise error

    try:
        discovered_names = _env_key_names(env_file)
    except OSError as exc:
        error = DjangoCommandError("canonical_env_unreadable", f"Kanonski produkcijski .env nije čitljiv: {type(exc).__name__}", 1)
        trace_update_step(
            9, "FAIL", session_id=plan.get("session_id", "none"),
            function_name="updates.updater.django_commands.run_manage",
            paths={"canonical_env": env_file}, exception=exc, exit_code=1,
            data_root=env_file.parents[1],
        )
        raise error from exc

    if "SECRET_KEY" not in discovered_names:
        error = DjangoCommandError("secret_key_missing", "Kanonski produkcijski .env nema konfigurisan SECRET_KEY.", 1)
        trace_update_step(
            9, "FAIL", session_id=plan.get("session_id", "none"),
            function_name="updates.updater.django_commands.run_manage",
            paths={"canonical_env": env_file}, exception=error, exit_code=1,
            message=f"env_keys={','.join(discovered_names)} secret_key_found=false",
            data_root=env_file.parents[1],
        )
        raise error

    child_env = clean_environment(env_file)
    command = [plan["python_executable"], str(Path(plan["application_root"]) / "manage.py"), *arguments]
    trace_update_step(
        9,
        "ENV",
        session_id=plan.get("session_id", "none"),
        function_name="updates.updater.django_commands.run_manage",
        paths={
            "canonical_env": env_file,
            "application_env_ignored": checked_paths[1],
            "manage_py": command[1],
            "working_directory": plan["application_root"],
        },
        message=(
            f"canonical_exists=true env_keys={','.join(discovered_names)} "
            f"secret_key_found=true child_env_keys={','.join(sorted(child_env))}"
        ),
        exit_code=0,
        data_root=env_file.parents[1],
    )
    result = subprocess.run(
        command, cwd=plan["application_root"], env=child_env,
        capture_output=True, text=True, check=False, timeout=timeout, shell=False,
    )
    output = safe_output((result.stdout or "") + "\n" + (result.stderr or ""))
    if result.returncode != 0:
        raise DjangoCommandError("django_command_failed", output or "Django komanda nije uspjela.", result.returncode)
    return {"exit_code": result.returncode, "output": output, "command": ["python", "manage.py", *arguments]}


def django_check(plan):
    try:
        return run_manage(plan, ["check", "--deploy"], timeout=180)
    except DjangoCommandError as exc:
        code = exc.code if exc.code.startswith(("canonical_env_", "secret_key_")) else "django_check_failed"
        raise DjangoCommandError(code, str(exc), exc.exit_code) from exc


def migrate(plan, lock_path):
    lock_path = Path(lock_path)
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(descriptor)
    except FileExistsError as exc:
        raise DjangoCommandError("migration_locked", "Drugi migration proces je aktivan.") from exc
    try:
        try:
            migration_result = run_manage(
                plan, ["migrate", "--noinput"], timeout=900
            )
        except DjangoCommandError as exc:
            code = exc.code if exc.code.startswith(("canonical_env_", "secret_key_")) else "migrations_failed"
            raise DjangoCommandError(code, str(exc), exc.exit_code) from exc
        try:
            gate_result = run_manage(plan, ["check_schema_gate"], timeout=300)
        except DjangoCommandError as exc:
            code = exc.code if exc.code.startswith(("canonical_env_", "secret_key_")) else "schema_gate_failed"
            raise DjangoCommandError(code, str(exc), exc.exit_code) from exc
        migration_result["schema_gate_output"] = gate_result["output"]
        return migration_result
    finally:
        lock_path.unlink(missing_ok=True)


def collectstatic(plan):
    try:
        return run_manage(plan, ["collectstatic", "--noinput"], timeout=600)
    except DjangoCommandError as exc:
        code = exc.code if exc.code.startswith(("canonical_env_", "secret_key_")) else "collectstatic_failed"
        raise DjangoCommandError(code, str(exc), exc.exit_code) from exc
