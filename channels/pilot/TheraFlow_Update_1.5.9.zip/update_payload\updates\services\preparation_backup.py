import hashlib
import json
import logging
import zipfile
from pathlib import Path

from django.conf import settings
from django.utils import timezone

from dashboard.postgres_backup import (
    BackupError,
    create_postgres_backup_at,
    postgres_settings,
    validate_postgres_backup,
)


logger = logging.getLogger(__name__)
DEFAULT_CRITICAL_CONFIG = (".env",)
DEFAULT_OPTIONAL_CONFIG = (
    "start_theraflow.bat",
    "run_theraflow.py",
    "install_runtime.bat",
    "install_runtime.ps1",
    "service/install_service.bat",
    "service/install_backup_scheduler_service.bat",
    "service/backup_scheduler_service.py",
    "service/install_updater_service.bat",
    "service/restart_service.bat",
    "service/uninstall_service.bat",
    "service/README.md",
    "config/local_settings.py",
)


class ConfigBackupError(RuntimeError):
    pass


def sha256_file(path, chunk_size=1024 * 1024):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_source(root, relative):
    relative = Path(relative)
    if relative.is_absolute() or ".." in relative.parts:
        raise ConfigBackupError("Neispravna konfiguracijska putanja.")
    if any(part.lower() in {".git", ".venv", "backups", "logs", "__pycache__", "node_modules"} for part in relative.parts):
        raise ConfigBackupError("Konfiguracijska putanja je na listi isključenih direktorija.")
    source = (root / relative).resolve()
    if root != source and root not in source.parents:
        raise ConfigBackupError("Konfiguracijska putanja izlazi iz aplikacijskog direktorija.")
    return source


def create_database_backup(backup_root, current_version, target_version, session_id=None):
    backup_root = Path(backup_root).resolve()
    dump_path = backup_root / "theraflow_database.dump"
    logger.info("Početak update database backupa.")
    create_postgres_backup_at(dump_path)
    validate_postgres_backup(dump_path)
    database = postgres_settings()
    metadata = {
        "created_at": timezone.now().isoformat(),
        "current_version": current_version,
        "target_version": target_version,
        "session_id": str(session_id or ""),
        "database_engine": "postgresql",
        "database_name": str(database.get("NAME", "")),
        "dump_filename": dump_path.name,
        "dump_size_bytes": dump_path.stat().st_size,
        "dump_sha256": sha256_file(dump_path),
        "validation": "pg_restore_list_passed",
    }
    (backup_root / "backup_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    logger.info("Update database backup i pg_restore validacija su uspješni.")
    return dump_path, metadata


def create_config_backup(backup_root, application_root=None, critical=None, optional=None):
    backup_root = Path(backup_root).resolve()
    root = Path(application_root or settings.BASE_DIR).resolve()
    critical = tuple(critical if critical is not None else getattr(settings, "THERAFLOW_UPDATE_CRITICAL_CONFIG", DEFAULT_CRITICAL_CONFIG))
    optional = tuple(optional if optional is not None else getattr(settings, "THERAFLOW_UPDATE_OPTIONAL_CONFIG", DEFAULT_OPTIONAL_CONFIG))
    files = []
    for relative in critical:
        source = _safe_source(root, relative)
        if not source.is_file():
            raise ConfigBackupError(f"Nedostaje kritični konfiguracijski fajl: {relative}")
        files.append((str(Path(relative).as_posix()), source))
    for relative in optional:
        source = _safe_source(root, relative)
        if source.is_file():
            files.append((str(Path(relative).as_posix()), source))

    archive_path = backup_root / "theraflow_config_backup.zip"
    manifest_path = backup_root / "config_backup_manifest.json"
    manifest_entries = []
    logger.info("Početak backupa lokalne TheraFlow konfiguracije.")
    try:
        with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for relative, source in files:
                archive.write(source, arcname=relative)
                manifest_entries.append({
                    "original_path": relative,
                    "backup_path": relative,
                    "size_bytes": source.stat().st_size,
                    "sha256": sha256_file(source),
                    "backed_up_at": timezone.now().isoformat(),
                })
        manifest = {
            "created_at": timezone.now().isoformat(),
            "files": manifest_entries,
        }
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
        if not archive_path.is_file() or archive_path.stat().st_size == 0:
            raise ConfigBackupError("Backup konfiguracije nije uspješno kreiran.")
    except Exception as exc:
        archive_path.unlink(missing_ok=True)
        manifest_path.unlink(missing_ok=True)
        if isinstance(exc, ConfigBackupError):
            raise
        raise ConfigBackupError("Backup konfiguracije nije uspješno kreiran.") from exc
    logger.info("Backup lokalne TheraFlow konfiguracije je završen.")
    return archive_path, manifest_path, manifest
