import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path

from django.utils import timezone

from updates.models import UpdateSession
from updates.updater.plan_loader import load_and_validate
from updates.updater.snapshot_restore import validate_snapshot

from .preparation_backup import sha256_file
from .update_paths import get_update_paths
from .update_preparation import run_precheck
from .update_state import save_session
from .updater_service_client import service_available, submit_request
from updates.updater.state_writer import trace_update_step, write_state


class UpdaterLaunchError(RuntimeError):
    pass


logger = logging.getLogger(__name__)


def _launch_trace(path, event, **details):
    safe_details = " ".join(f"{key}={value}" for key, value in details.items())
    line = f"{timezone.now().isoformat()} {event} {safe_details}".rstrip()
    with Path(path).open("a", encoding="utf-8") as handle:
        handle.write(line + "\n")
    logger.info("Updater launch: %s %s", event, safe_details)


def _environment(dry_run=False):
    allowed = (
        "SystemRoot",
        "WINDIR",
        "PATH",
        "PATHEXT",
        "COMSPEC",
        "TEMP",
        "TMP",
        "PROGRAMDATA",
    )
    env = {key: os.environ[key] for key in allowed if key in os.environ}
    env.update({"PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1"})
    if dry_run:
        env["THERAFLOW_UPDATER_DRY_RUN"] = "1"
    return env


def launch_updater(session, user, dry_run=False, popen=None):
    if (
        not isinstance(session, UpdateSession)
        or session.status != UpdateSession.READY_TO_INSTALL
        or not session.is_active
    ):
        raise UpdaterLaunchError("Update session nije spreman za instalaciju.")

    plan_path = Path(session.install_plan_path).resolve()
    process_log = plan_path.parent / "updater_process.log"
    trace_update_step("Pre-install validation", "START", session_id=session.pk, function_name="launch_updater", paths={"install_plan": plan_path, "process_log": process_log})
    _launch_trace(process_log, "STEP_START", step="precheck", session=session.pk)
    try:
        run_precheck(session)
    except Exception as exc:
        _launch_trace(
            process_log,
            "STEP_FAIL",
            step="precheck",
            error_type=type(exc).__name__,
            error=str(exc)[:500],
        )
        trace_update_step("Pre-install validation", "FAIL", session_id=session.pk, function_name="launch_updater", paths={"install_plan": plan_path, "process_log": process_log}, exception=exc, exit_code=getattr(exc, "returncode", 1))
        raise UpdaterLaunchError(
            f"Završna provjera pripremljenog updatea nije uspjela: "
            f"{type(exc).__name__}: {exc}"
        ) from exc
    _launch_trace(process_log, "STEP_COMPLETE", step="precheck")
    trace_update_step("Pre-install validation", "PASS", session_id=session.pk, function_name="launch_updater", paths={"install_plan": plan_path, "process_log": process_log}, exit_code=0)

    if (
        not session.install_plan_sha256
        or sha256_file(plan_path) != session.install_plan_sha256
    ):
        trace_update_step("Pre-install validation", "FAIL", session_id=session.pk, function_name="launch_updater", paths={"install_plan": plan_path}, exception=UpdaterLaunchError("Install plan je izmijenjen nakon pripreme."), exit_code=1)
        raise UpdaterLaunchError("Install plan je izmijenjen nakon pripreme.")

    paths = get_update_paths()
    lock_path = paths.sessions / "install.lock"
    try:
        descriptor = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(descriptor, str(session.pk).encode("ascii"))
        os.close(descriptor)
    except FileExistsError as exc:
        trace_update_step("Updater process launch", "FAIL", session_id=session.pk, function_name="launch_updater", paths={"install_lock": lock_path}, exception=exc, exit_code=1)
        raise UpdaterLaunchError("Drugi updater proces je već aktivan.") from exc

    runtime_root = plan_path.parent / "runtime"
    source = Path(__file__).resolve().parents[1] / "updater"
    try:
        _launch_trace(process_log, "STEP_START", step="runtime_copy", source=source.name)
        if runtime_root.exists():
            raise UpdaterLaunchError("Updater runtime već postoji za ovaj session.")
        shutil.copytree(
            source,
            runtime_root / "updater",
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
        _launch_trace(process_log, "STEP_COMPLETE", step="runtime_copy")

        session.status = UpdateSession.INSTALL_STARTING
        session.install_started_by = user
        session.install_started_at = timezone.now()
        session.updater_pid = None
        save_session(
            session,
            ["status", "install_started_by", "install_started_at", "updater_pid"],
        )

        if service_available():
            request = submit_request(session.pk, "install")
            state_path = get_update_paths().sessions / f"{session.pk}.json"
            write_state(
                state_path,
                status="updater_service_queued",
                current_step="Verificirani update je predan TheraFlowUpdaterService servisu",
                execution_owner="TheraFlowUpdaterService",
                updater_request_id=request["request_id"],
                updater_pid=None,
            )
            _launch_trace(
                process_log,
                "STEP_COMPLETE",
                step="service_request",
                request_id=request["request_id"],
            )
            trace_update_step(
                "Updater service request",
                "PASS",
                session_id=session.pk,
                function_name="launch_updater",
                paths={"runtime_root": runtime_root, "process_log": process_log},
                message=f"request_id={request['request_id']}",
                exit_code=0,
            )
            return {
                "status": "install_starting",
                "session_id": str(session.pk),
                "updater_pid": None,
                "execution_owner": "TheraFlowUpdaterService",
                "request_id": request["request_id"],
            }

        command = [sys.executable, "-m", "updater.runner", str(plan_path)]
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(
                subprocess, "CREATE_NEW_PROCESS_GROUP", 0
            )
        popen = popen or subprocess.Popen
        _launch_trace(
            process_log,
            "STEP_START",
            step="process_launch",
            executable=Path(sys.executable).name,
            creationflags=flags,
        )
        with process_log.open("a", encoding="utf-8") as log:
            process = popen(
                command,
                cwd=str(runtime_root),
                env=_environment(dry_run),
                stdout=log,
                stderr=log,
                stdin=subprocess.DEVNULL,
                close_fds=True,
                creationflags=flags,
                shell=False,
            )
        session.updater_pid = process.pid
        save_session(session, ["updater_pid"])
        _launch_trace(
            process_log,
            "STEP_COMPLETE",
            step="process_launch",
            updater_pid=process.pid,
        )
        trace_update_step("Updater process launch", "PASS", session_id=session.pk, function_name="launch_updater", paths={"runtime_root": runtime_root, "process_log": process_log}, message=f"pid={process.pid}", exit_code=0)
        return {
            "status": "install_starting",
            "session_id": str(session.pk),
            "updater_pid": process.pid,
        }
    except UpdaterLaunchError as exc:
        trace_update_step("Updater process launch", "FAIL", session_id=session.pk, function_name="launch_updater", paths={"install_plan": plan_path, "runtime_root": runtime_root, "process_log": process_log}, exception=exc, exit_code=1)
        if (
            session.status == UpdateSession.INSTALL_STARTING
            and session.updater_pid is None
        ):
            session.status = UpdateSession.READY_TO_INSTALL
            save_session(session, ["status"])
        lock_path.unlink(missing_ok=True)
        shutil.rmtree(runtime_root, ignore_errors=True)
        raise
    except Exception as exc:
        _launch_trace(
            process_log,
            "STEP_FAIL",
            step="process_launch",
            error_type=type(exc).__name__,
            error=str(exc)[:500],
        )
        trace_update_step("Updater process launch", "FAIL", session_id=session.pk, function_name="launch_updater", paths={"install_plan": plan_path, "runtime_root": runtime_root, "process_log": process_log}, exception=exc, exit_code=getattr(exc, "returncode", 1))
        if (
            session.status == UpdateSession.INSTALL_STARTING
            and session.updater_pid is None
        ):
            session.status = UpdateSession.READY_TO_INSTALL
            save_session(session, ["status"])
        lock_path.unlink(missing_ok=True)
        shutil.rmtree(runtime_root, ignore_errors=True)
        raise UpdaterLaunchError(
            f"Vanjski updater se nije mogao sigurno pokrenuti: "
            f"{type(exc).__name__}: {exc}"
        ) from exc


def launch_rollback(session, user, popen=None):
    allowed = {
        UpdateSession.ROLLBACK_REQUIRED,
        UpdateSession.INSTALL_FAILED,
        UpdateSession.UPDATE_COMPLETED,
        UpdateSession.MANUAL_RECOVERY_REQUIRED,
    }
    if not isinstance(session, UpdateSession) or session.status not in allowed:
        raise UpdaterLaunchError("Update session nije siguran kandidat za rollback.")
    plan_path = Path(session.install_plan_path).resolve()
    if (
        not session.install_plan_sha256
        or sha256_file(plan_path) != session.install_plan_sha256
    ):
        raise UpdaterLaunchError("Install plan je izmijenjen nakon pripreme.")
    try:
        plan, _state = load_and_validate(plan_path, rollback=True)
        validate_snapshot(plan)
    except Exception as exc:
        raise UpdaterLaunchError(
            "Rollback artefakti nisu prošli sigurnosnu provjeru."
        ) from exc

    paths = get_update_paths()
    launch_lock = paths.sessions / "rollback-launch.lock"
    try:
        descriptor = os.open(launch_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(descriptor, str(session.pk).encode("ascii"))
        os.close(descriptor)
    except FileExistsError as exc:
        raise UpdaterLaunchError("Drugi rollback proces je već aktivan.") from exc

    runtime_root = plan_path.parent / "runtime"
    source = Path(__file__).resolve().parents[1] / "updater"
    process_log = plan_path.parent / "updater_process.log"
    try:
        if not (runtime_root / "updater" / "runner.py").is_file():
            shutil.copytree(
                source,
                runtime_root / "updater",
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
            )
        env = _environment()
        env["THERAFLOW_UPDATER_MODE"] = "rollback"
        if service_available():
            request = submit_request(session.pk, "rollback")
            state_path = get_update_paths().sessions / f"{session.pk}.json"
            write_state(
                state_path,
                status="updater_service_queued",
                current_step="Verificirani rollback je predan TheraFlowUpdaterService servisu",
                execution_owner="TheraFlowUpdaterService",
                updater_request_id=request["request_id"],
                updater_pid=None,
            )
            session.status = UpdateSession.ROLLBACK_STARTING
            session.updater_pid = None
            session.save(update_fields=["status", "updater_pid", "updated_at"])
            return {
                "status": "rollback_starting",
                "session_id": str(session.pk),
                "updater_pid": None,
                "execution_owner": "TheraFlowUpdaterService",
                "request_id": request["request_id"],
            }
        command = [sys.executable, "-m", "updater.runner", str(plan_path)]
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(
                subprocess, "CREATE_NEW_PROCESS_GROUP", 0
            )
        popen = popen or subprocess.Popen
        with process_log.open("a", encoding="utf-8") as log:
            process = popen(
                command,
                cwd=str(runtime_root),
                env=env,
                stdout=log,
                stderr=log,
                stdin=subprocess.DEVNULL,
                close_fds=True,
                creationflags=flags,
                shell=False,
            )
        session.status = UpdateSession.ROLLBACK_STARTING
        session.updater_pid = process.pid
        session.save(update_fields=["status", "updater_pid", "updated_at"])
        return {
            "status": "rollback_starting",
            "session_id": str(session.pk),
            "updater_pid": process.pid,
        }
    except Exception as exc:
        raise UpdaterLaunchError(
            "Vanjski rollback helper se nije mogao sigurno pokrenuti."
        ) from exc
    finally:
        launch_lock.unlink(missing_ok=True)
