param(
    [switch]$ResetOrphanedDatabase,
    [Parameter(Mandatory=$true)]
    [ValidatePattern('^https://')]
    [string]$UpdateManifestUrl
)

Set-StrictMode -Version 3.0
$ErrorActionPreference = "Stop"

$ScriptsRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallRoot = Split-Path -Parent $ScriptsRoot
$AppRoot = Join-Path $InstallRoot "app"
$RuntimeRoot = Join-Path $InstallRoot "runtime"
$ProgramDataRoot = Join-Path $env:ProgramData "TheraFlow"
$ConfigRoot = Join-Path $ProgramDataRoot "config"
$EnvPath = Join-Path $ConfigRoot ".env"
$LogRoot = Join-Path $ProgramDataRoot "logs"
$ApplicationLogRoot = Join-Path $LogRoot "application"
$BackupSchedulerLogRoot = Join-Path $LogRoot "backup_scheduler"
$InstallerLog = Join-Path $LogRoot "install_runtime.log"
$BackupRoot = Join-Path $ProgramDataRoot "backups\installer"
$MutableRuntimeRoot = Join-Path $ProgramDataRoot "runtime"
$StaticRoot = Join-Path $MutableRuntimeRoot "staticfiles"
$MediaRoot = Join-Path $ProgramDataRoot "media"
$DataDirectory = Join-Path $ProgramDataRoot "data"
$PostgresLogRoot = Join-Path $LogRoot "postgresql"
$PostgresBackupRoot = Join-Path $ProgramDataRoot "backups\postgres"
$UpdateBackupRoot = Join-Path $ProgramDataRoot "backups\updates"
$UpdatePackageRoot = Join-Path $ProgramDataRoot "updates\packages"
$UpdateStagingRoot = Join-Path $ProgramDataRoot "updates\staging"
$UpdateSessionRoot = Join-Path $ProgramDataRoot "updates\sessions"
$UpdateRequestRoot = Join-Path $ProgramDataRoot "updates\service_requests"
$HotfixBackupRoot = Join-Path $ProgramDataRoot "hotfix_backups"
$PythonRoot = Join-Path $RuntimeRoot "python"
$PythonExe = Join-Path $PythonRoot "python.exe"
$PythonStatePath = Join-Path $ConfigRoot "python_runtime.json"
$VenvRoot = Join-Path $MutableRuntimeRoot "venv"
$VenvPython = Join-Path $VenvRoot "Scripts\python.exe"
$AppUrl = "http://127.0.0.1:8000/"
$script:FailureCategory = "PREREQUISITE_FAILURE"
$script:EmbeddedDatabaseReady = $false
$script:PrivatePythonExistedBefore = $false
$script:DetectedState = "UNKNOWN"
$script:RunId = [guid]::NewGuid().ToString("N")

Import-Module (Join-Path $ScriptsRoot "installer_runtime\ProductionEnvironment.psm1") -Force

$failureMessages = @{
    PREREQUISITE_FAILURE = "Nedostaje obavezna komponenta ili administratorska dozvola."
    FILE_INSTALLATION_FAILURE = "Aplikacijski ili runtime fajlovi nisu pravilno instalirani."
    PORT_CONFLICT = "Port 5433 koristi druga aplikacija. Instalacija je sigurno prekinuta."
    POSTGRES_INITIALIZATION_FAILURE = "Privatna baza podataka nije mogla biti inicijalizovana."
    POSTGRES_SERVICE_FAILURE = "TheraFlow servis baze podataka nije mogao biti pokrenut."
    DATABASE_SETUP_FAILURE = "TheraFlow baza ili aplikacijski korisnik nisu mogli biti pripremljeni."
    ENV_CONFIGURATION_FAILURE = "Sigurna produkcijska konfiguracija nije mogla biti pripremljena."
    MIGRATION_FAILURE = "Nadogradnja strukture baze nije uspjela. Postojeći podaci su sačuvani."
    STATIC_FILES_FAILURE = "Statički CSS, JavaScript ili slike nisu pravilno pripremljeni."
    APPLICATION_SERVICE_FAILURE = "TheraFlow aplikacijski servis nije mogao biti pokrenut."
    BACKUP_SCHEDULER_SERVICE_FAILURE = "TheraFlow Backup Scheduler servis nije mogao biti instaliran ili pokrenut."
    HEALTH_CHECK_FAILURE = "TheraFlow nije prošao završnu provjeru aplikacije i CSS-a."
}

foreach ($directory in @(
    $ProgramDataRoot, $ConfigRoot, $LogRoot, $ApplicationLogRoot, $BackupSchedulerLogRoot,
    $PostgresLogRoot, $BackupRoot, $PostgresBackupRoot, $UpdateBackupRoot,
    $MutableRuntimeRoot, $MediaRoot, $DataDirectory, $UpdatePackageRoot,
    $UpdateStagingRoot, $UpdateSessionRoot, $UpdateRequestRoot, $HotfixBackupRoot
)) {
    New-Item -ItemType Directory -Force -Path $directory | Out-Null
}

function Write-InstallLog {
    param([string]$Message)
    Add-Content -LiteralPath $InstallerLog -Encoding UTF8 -Value ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message)
}

function Write-ProgressMessage {
    param([string]$Message)
    Write-Host $Message
    Write-InstallLog "PROGRESS: $Message"
}

function Set-FailureCategory {
    param([string]$Category)
    $script:FailureCategory = $Category
    Write-InstallLog "Failure category context: $Category"
}

function Fail-Install {
    param([string]$Message, [string]$Category = $script:FailureCategory)
    $script:FailureCategory = $Category
    Write-InstallLog "ERROR [$Category]: $Message"
    throw $Message
}

function Require-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Fail-Install "Administrator privileges are required." "PREREQUISITE_FAILURE"
    }
}

function Require-Path {
    param([string]$Path, [string]$Description, [string]$Category = "FILE_INSTALLATION_FAILURE")
    if (-not (Test-Path -LiteralPath $Path)) { Fail-Install "Missing $Description`: $Path" $Category }
    Write-InstallLog "Verified $Description`: $Path"
}

function New-SecureToken {
    param([int]$Bytes = 48)
    $buffer = New-Object byte[] $Bytes
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $rng.GetBytes($buffer)
        return [Convert]::ToBase64String($buffer).TrimEnd("=").Replace("+", "-").Replace("/", "_")
    } finally { $rng.Dispose() }
}

function ConvertTo-CommandLineArgument {
    param([string]$Argument)
    if ($null -eq $Argument) { return '""' }
    if ($Argument -notmatch '[\s"]') { return $Argument }
    return '"' + $Argument.Replace('"', '\"') + '"'
}

function Invoke-ProcessLogged {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string[]]$Arguments = @(),
        [Parameter(Mandatory=$true)][string]$SafeDescription,
        [string]$Category = $script:FailureCategory,
        [int[]]$AllowedExitCodes = @(0),
        [switch]$SuppressOutput,
        [switch]$AllowAnyExitCode,
        [string]$WorkingDirectory = ""
    )
    $stdout = Join-Path $env:TEMP ("theraflow_install_stdout_{0}.log" -f [guid]::NewGuid().ToString("N"))
    $stderr = Join-Path $env:TEMP ("theraflow_install_stderr_{0}.log" -f [guid]::NewGuid().ToString("N"))
    try {
        Write-InstallLog "RUN: $SafeDescription"
        $normalizedArguments = @($Arguments | Where-Object { $null -ne $_ -and -not [string]::IsNullOrWhiteSpace([string]$_) })
        $argumentCount = $normalizedArguments.Count
        $argumentLine = (@($normalizedArguments | ForEach-Object { ConvertTo-CommandLineArgument ([string]$_) }) -join " ")
        $effectiveWorkingDirectory = if ([string]::IsNullOrWhiteSpace($WorkingDirectory)) { (Get-Location).Path } else { [IO.Path]::GetFullPath($WorkingDirectory) }
        $argumentListOmitted = $argumentCount -eq 0
        $loggedArgumentList = if ($argumentListOmitted) { "<omitted>" } else { $argumentLine }
        Write-InstallLog "PROCESS: $SafeDescription; FilePath=$FilePath; WorkingDirectory=$effectiveWorkingDirectory; ArgumentCount=$argumentCount; ArgumentList=$loggedArgumentList; ArgumentListOmitted=$argumentListOmitted"
        $startParameters = @{
            FilePath = $FilePath
            Wait = $true
            PassThru = $true
            WindowStyle = "Hidden"
            RedirectStandardOutput = $stdout
            RedirectStandardError = $stderr
            WorkingDirectory = $effectiveWorkingDirectory
        }
        if (-not $argumentListOmitted) { $startParameters["ArgumentList"] = $argumentLine }
        $process = Start-Process @startParameters
        if (-not $SuppressOutput) {
            foreach ($path in @($stdout, $stderr)) {
                if (Test-Path -LiteralPath $path) {
                    Get-Content -LiteralPath $path -ErrorAction SilentlyContinue | ForEach-Object {
                        if (-not [string]::IsNullOrWhiteSpace($_)) { Add-Content -LiteralPath $InstallerLog -Encoding UTF8 -Value $_ }
                    }
                }
            }
        }
        $unsignedExitCode = [uint32]([int64]$process.ExitCode -band 0xffffffffL)
        Write-InstallLog ("EXIT: {0}; decimal={1}; hexadecimal=0x{2:X8}" -f $SafeDescription, $process.ExitCode, $unsignedExitCode)
        if (-not $AllowAnyExitCode -and $AllowedExitCodes -notcontains $process.ExitCode) { Fail-Install "$SafeDescription failed with exit code $($process.ExitCode) (0x$('{0:X8}' -f $unsignedExitCode))." $Category }
        return $process.ExitCode
    } catch {
        if ($_.Exception.Message -like "*$SafeDescription failed*") { throw }
        Fail-Install "Could not execute $SafeDescription`: $($_.Exception.Message)" $Category
    } finally {
        Remove-Item -LiteralPath $stdout, $stderr -Force -ErrorAction SilentlyContinue
    }
}

function Read-EnvLines {
    if (Test-Path -LiteralPath $EnvPath) { return [IO.File]::ReadAllLines($EnvPath, [Text.Encoding]::UTF8) }
    return @("# TheraFlow production configuration")
}

function Set-CanonicalEnvironment {
    param([switch]$AllowNewSecret)
    Set-FailureCategory "ENV_CONFIGURATION_FAILURE"
    $managed = [ordered]@{
        DEBUG = "False"
        THERAFLOW_PRODUCTION = "True"
        THERAFLOW_STATIC_ROOT = $StaticRoot
        THERAFLOW_MEDIA_ROOT = $MediaRoot
        THERAFLOW_DATA_DIR = (Join-Path $ProgramDataRoot "data")
        THERAFLOW_POSTGRES_BIN = (Join-Path $RuntimeRoot "postgresql\bin")
        THERAFLOW_BACKUP_DIR = (Join-Path $ProgramDataRoot "backups\postgres")
        THERAFLOW_BACKUP_LOG = (Join-Path $LogRoot "backup.log")
        THERAFLOW_BACKUP_SCHEDULER_LOG = (Join-Path $BackupSchedulerLogRoot "backup_scheduler.log")
        THERAFLOW_BACKUP_STATE = (Join-Path $ProgramDataRoot "data\backup_scheduler_state.json")
        THERAFLOW_BACKUP_LOCK = (Join-Path $ProgramDataRoot "data\backup_execution.lock")
        THERAFLOW_BACKUP_SCHEDULER_LOCK = (Join-Path $ProgramDataRoot "data\backup_scheduler.lock")
        THERAFLOW_BACKUP_HOUR = "4"
        THERAFLOW_BACKUP_MINUTE = "0"
        THERAFLOW_BACKUP_TIME_ZONE = "Europe/Sarajevo"
        THERAFLOW_BACKUP_CHECK_INTERVAL_SECONDS = "60"
        THERAFLOW_BACKUP_HEARTBEAT_FRESH_SECONDS = "600"
        THERAFLOW_BACKUP_SCHEDULER_SERVICE_NAME = "TheraFlowBackupScheduler"
        THERAFLOW_SERVICE_NAME = "TheraFlow"
        THERAFLOW_HEALTH_CHECK_URL = "http://127.0.0.1:8000/health/update/"
        ADAPTIVE_ASSISTANT_ENABLED = "true"
        ADAPTIVE_ASSISTANT_MODE = "observation"
    }
    $newSecret = if ($AllowNewSecret) { "django-$(New-SecureToken)" } else { "" }
    $environmentResult = Set-TheraFlowCanonicalEnvironment `
        -Path $EnvPath `
        -ManagedValues $managed `
        -GeneratedSecretKey $newSecret `
        -AllowNewSecret:$AllowNewSecret
    if ($environmentResult.SecretKeyAction -eq "generated_new_install") {
        Write-InstallLog "Generated a new SECRET_KEY; value was not logged."
    } else {
        Write-InstallLog "Reusing existing SECRET_KEY; value was not logged."
    }
    $manifestResult = Set-TheraFlowEnvValueIfMissingOrEmpty `
        -Path $EnvPath `
        -Name "THERAFLOW_UPDATE_MANIFEST_URL" `
        -Value $UpdateManifestUrl
    Set-EpSecureAcl -Path $EnvPath
    $env:THERAFLOW_PRODUCTION = "1"
    $env:THERAFLOW_ENV_FILE = $EnvPath
    Write-InstallLog "Canonical production environment prepared: $EnvPath"
    Write-InstallLog "Update manifest configuration: key=THERAFLOW_UPDATE_MANIFEST_URL; state=$($manifestResult.Reason); valueNonEmpty=$(-not [string]::IsNullOrWhiteSpace($manifestResult.Value))"
}

function Invoke-PrivatePythonProbe {
    param([string[]]$Arguments, [string]$Description)
    if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) {
        return [pscustomobject]@{ ExitCode = $null; StdOut = ""; StdErr = ""; Started = $false }
    }
    try {
        $argumentLine = (@($Arguments | ForEach-Object { ConvertTo-CommandLineArgument ([string]$_) }) -join " ")
        $startInfo = [Diagnostics.ProcessStartInfo]::new()
        $startInfo.FileName = $PythonExe
        $startInfo.Arguments = $argumentLine
        $startInfo.WorkingDirectory = $PythonRoot
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        $process = [Diagnostics.Process]::new()
        $process.StartInfo = $startInfo
        if (-not $process.Start()) { throw "Process did not start." }
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $process.WaitForExit()
        $stdout = $stdoutTask.GetAwaiter().GetResult().Trim()
        $stderr = $stderrTask.GetAwaiter().GetResult().Trim()
        $exitCode = $process.ExitCode
        $process.Dispose()
        Write-InstallLog "Python probe [$Description]: exit=$exitCode; stdout=$stdout; stderr=$stderr"
        return [pscustomobject]@{ ExitCode = $exitCode; StdOut = $stdout; StdErr = $stderr; Started = $true }
    } catch {
        Write-InstallLog "Python probe [$Description] could not run: $($_.Exception.Message)"
        return [pscustomobject]@{ ExitCode = $null; StdOut = ""; StdErr = $_.Exception.Message; Started = $false }
    }
}

function Get-PrivatePythonValidation {
    $directoryExists = Test-Path -LiteralPath $PythonRoot -PathType Container
    $exeExists = Test-Path -LiteralPath $PythonExe -PathType Leaf
    Write-InstallLog "Private Python preflight: installationState=$($script:DetectedState); runtimeDirectoryExists=$directoryExists; pythonExeExists=$exeExists; path=$PythonExe"
    if (-not $exeExists) {
        Write-InstallLog "Private Python validation result: INVALID (python.exe missing)."
        return [pscustomobject]@{ Valid = $false; DirectoryExists = $directoryExists; Version = "" }
    }
    $versionProbe = Invoke-PrivatePythonProbe @("--version") "python.exe --version"
    $importProbe = Invoke-PrivatePythonProbe @("-c", "import sys, ssl, sqlite3, venv; raise SystemExit(0 if sys.version_info[:2] == (3, 13) else 1)") "minimal import/version test"
    $versionText = (($versionProbe.StdOut, $versionProbe.StdErr) | Where-Object { $_ } | Select-Object -First 1)
    $valid = $versionProbe.ExitCode -eq 0 -and $versionText -match '^Python 3\.13\.' -and $importProbe.ExitCode -eq 0
    Write-InstallLog "Private Python validation result: $(if ($valid) { 'VALID' } else { 'INVALID' }); version=$versionText; versionExit=$($versionProbe.ExitCode); importExit=$($importProbe.ExitCode)"
    return [pscustomobject]@{ Valid = $valid; DirectoryExists = $directoryExists; Version = $versionText }
}

function Test-PrivatePython {
    return [bool](Get-PrivatePythonValidation).Valid
}

function Save-PrivatePythonState {
    param([string]$Version, [string]$Action)
    $state = [ordered]@{
        path = $PythonRoot
        version = $Version
        installer_sha256 = (Get-FileHash -LiteralPath (Join-Path $RuntimeRoot "installers\python-3.13-amd64.exe") -Algorithm SHA256).Hash
        last_action = $Action
        updated_at = (Get-Date).ToString("o")
    }
    [IO.File]::WriteAllText($PythonStatePath, ($state | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
    Set-EpSecureAcl -Path $PythonStatePath
}

function Test-PrivatePythonMarkerOwned {
    if (-not (Test-Path -LiteralPath $PythonStatePath)) { return $false }
    try {
        $state = Get-Content -LiteralPath $PythonStatePath -Raw | ConvertFrom-Json
        return [IO.Path]::GetFullPath([string]$state.path).TrimEnd('\').Equals([IO.Path]::GetFullPath($PythonRoot).TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)
    } catch { return $false }
}

function Remove-InvalidPrivatePythonRuntime {
    if (-not (Test-Path -LiteralPath $PythonRoot)) { return }
    $expected = [IO.Path]::GetFullPath((Join-Path $RuntimeRoot "python"))
    $actual = [IO.Path]::GetFullPath($PythonRoot)
    if (-not $actual.Equals($expected, [StringComparison]::OrdinalIgnoreCase)) {
        Fail-Install "Refusing to remove unexpected Python runtime path: $actual" "PREREQUISITE_FAILURE"
    }
    $item = Get-Item -LiteralPath $PythonRoot -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
        Fail-Install "Refusing to remove Python runtime because it is a reparse point: $actual" "PREREQUISITE_FAILURE"
    }
    Remove-Item -LiteralPath $PythonRoot -Recurse -Force
    Write-InstallLog "Removed invalid private Python runtime directory safely: $actual"
}

function Invoke-PythonBootstrapper {
    param([ValidateSet("install", "repair", "uninstall")][string]$Action)
    $installer = Join-Path $RuntimeRoot "installers\python-3.13-amd64.exe"
    $setupLog = Join-Path $LogRoot ("python-runtime-{0}-{1}.log" -f $Action, (Get-Date -Format "yyyyMMdd-HHmmss"))
    $arguments = switch ($Action) {
        "install" { @(
            "/quiet", "/norestart", "/log", $setupLog, "InstallAllUsers=1", "TargetDir=$PythonRoot",
            "PrependPath=0", "Include_launcher=0", "InstallLauncherAllUsers=0",
            "AssociateFiles=0", "Shortcuts=0", "Include_pip=1", "Include_test=0",
            "Include_doc=0", "Include_tcltk=0", "SimpleInstall=1"
        ) }
        "repair" { @("/repair", "/quiet", "/norestart", "/log", $setupLog) }
        "uninstall" { @("/uninstall", "/quiet", "/norestart", "/log", $setupLog) }
    }
    Write-InstallLog "Python bootstrapper action=$Action; installer=$installer; target=$PythonRoot; log=$setupLog"
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        $code = Invoke-ProcessLogged -FilePath $installer -Arguments $arguments -SafeDescription "private Python 3.13 $Action" -Category "PREREQUISITE_FAILURE" -AllowAnyExitCode
        $result = Get-PythonInstallerExitMeaning $code
        Write-InstallLog "Python bootstrapper result: action=$Action; attempt=$attempt; decimal=$($result.ExitCode); hexadecimal=$($result.Hex); win32=$($result.Win32Code); meaning=$($result.Meaning)"
        if ($result.Meaning -ne "ANOTHER_INSTALL_RUNNING" -or $attempt -eq 3) { return $result }
        Write-InstallLog "Another MSI installation is running; retrying Python action after 5 seconds."
        Start-Sleep -Seconds 5
    }
}

function Assert-PythonActionSucceeded {
    param([object]$Result, [string]$Action)
    if ($Result.Meaning -in @("SUCCESS", "SUCCESS_RESTART_REQUIRED", "SUCCESS_RESTART_INITIATED")) { return }
    if ($Result.Meaning -eq "INSTALL_LOG_FAILURE") {
        Fail-Install "Python $Action could not open its installer log (1622/$($Result.Hex)). Verify log directory permissions." "PREREQUISITE_FAILURE"
    }
    if ($Result.Meaning -eq "ANOTHER_INSTALL_RUNNING") {
        Fail-Install "Python $Action could not continue because another Windows Installer operation is still running (1618/$($Result.Hex))." "PREREQUISITE_FAILURE"
    }
    Fail-Install "Python $Action failed: decimal=$($Result.ExitCode), hexadecimal=$($Result.Hex), meaning=$($Result.Meaning)." "PREREQUISITE_FAILURE"
}

function Install-PrivatePython {
    Set-FailureCategory "PREREQUISITE_FAILURE"
    $validation = Get-PrivatePythonValidation
    if ($validation.Valid) {
        $script:PrivatePythonExistedBefore = $true
        Save-PrivatePythonState $validation.Version "reused"
        Write-InstallLog "Private Python action: REUSED valid existing runtime; installer was not started."
        return
    }
    $installer = Join-Path $RuntimeRoot "installers\python-3.13-amd64.exe"
    Require-Path $installer "bundled Python installer" "PREREQUISITE_FAILURE"
    $registration = Get-PrivatePythonRegistration -PythonRoot $PythonRoot -LogPath $InstallerLog
    $markerOwned = Test-PrivatePythonMarkerOwned
    # The PythonCore path is authoritative when present. A secure TheraFlow
    # marker may recover ownership only when no competing registered path exists.
    # This prevents a stale marker from repairing/uninstalling an unrelated
    # machine-wide Python that was installed later.
    $markerCanRecoverOwnership = $markerOwned -and $registration.RegisteredPaths.Count -eq 0
    $ownedRegistration = $registration.Owned -or $markerCanRecoverOwnership
    $conflictingRegistration = $registration.Conflicting -and -not $ownedRegistration
    Write-InstallLog "Python registration: owned=$ownedRegistration; markerOwned=$markerOwned; conflicting=$conflictingRegistration; registeredPaths=$($registration.RegisteredPaths -join ';'); msiComponents=$($registration.Components.Count)"
    $plan = Resolve-PrivatePythonPlan -PythonValid $false -RuntimeDirectoryExists $validation.DirectoryExists -OwnedRegistration $ownedRegistration -ConflictingRegistration $conflictingRegistration
    Write-InstallLog "Private Python recovery plan for state $($script:DetectedState): $plan"

    if ($plan -eq "BLOCK_CONFLICT") {
        Fail-Install "A machine-wide Python 3.13 registration exists outside the TheraFlow runtime. It was not modified. Registered paths: $($registration.RegisteredPaths -join '; ')" "PREREQUISITE_FAILURE"
    }
    if ($plan -eq "REPAIR") {
        $repairResult = Invoke-PythonBootstrapper "repair"
        if ($repairResult.Meaning -in @("SUCCESS", "SUCCESS_RESTART_REQUIRED", "SUCCESS_RESTART_INITIATED")) {
            $validation = Get-PrivatePythonValidation
            if ($validation.Valid) {
                Save-PrivatePythonState $validation.Version "repaired"
                Write-InstallLog "Private Python action: REPAIRED registered TheraFlow runtime successfully."
                return
            }
            if ($repairResult.Meaning -ne "SUCCESS") {
                Fail-Install "Python repair requires a Windows restart before validation can complete ($($repairResult.Hex))." "PREREQUISITE_FAILURE"
            }
        }
        Write-InstallLog "Python repair did not restore a valid private runtime; removing only the owned registration through the bundled bootstrapper."
        $uninstallResult = Invoke-PythonBootstrapper "uninstall"
        Assert-PythonActionSucceeded $uninstallResult "uninstall"
        if ($uninstallResult.Meaning -ne "SUCCESS") {
            Fail-Install "Python uninstall requires a Windows restart before clean reinstall ($($uninstallResult.Hex))." "PREREQUISITE_FAILURE"
        }
        Remove-InvalidPrivatePythonRuntime
        $plan = "INSTALL"
    } elseif ($plan -eq "REMOVE_AND_INSTALL") {
        Remove-InvalidPrivatePythonRuntime
        $plan = "INSTALL"
    }

    if ($plan -eq "INSTALL") {
        New-Item -ItemType Directory -Force -Path $PythonRoot | Out-Null
        $installResult = Invoke-PythonBootstrapper "install"
        if ($installResult.Meaning -eq "ANOTHER_VERSION_INSTALLED") {
            $registration = Get-PrivatePythonRegistration -PythonRoot $PythonRoot -LogPath $InstallerLog
            if (-not $registration.Owned) {
                Fail-Install "Python installer found another Python 3.13 registration that is not owned by TheraFlow (1638/$($installResult.Hex)); it was not modified." "PREREQUISITE_FAILURE"
            }
            Write-InstallLog "Python install reported an existing owned registration; switching to repair."
            $installResult = Invoke-PythonBootstrapper "repair"
        }
        Assert-PythonActionSucceeded $installResult "installation"
        $validation = Get-PrivatePythonValidation
        if (-not $validation.Valid) {
            if ($installResult.Meaning -ne "SUCCESS") {
                Fail-Install "Python installation requires a Windows restart before validation can complete ($($installResult.Hex))." "PREREQUISITE_FAILURE"
            }
            Fail-Install "Private Python runtime validation failed after successful installer exit." "PREREQUISITE_FAILURE"
        }
        Save-PrivatePythonState $validation.Version "installed"
        Write-InstallLog "Private Python action: INSTALLED clean private runtime without PATH, launcher or file-association changes."
    }
}

function Install-ApplicationDependencies {
    Set-FailureCategory "PREREQUISITE_FAILURE"
    $wheelhouse = Join-Path $RuntimeRoot "wheels"
    Require-Path (Join-Path $AppRoot "requirements.lock") "locked requirements"
    if (-not (Get-ChildItem -LiteralPath $wheelhouse -Filter "*.whl" -File -ErrorAction SilentlyContinue)) {
        Fail-Install "Offline Python wheelhouse is empty." "PREREQUISITE_FAILURE"
    }
    $venvValid = $false
    if (Test-Path -LiteralPath $VenvPython) {
        try {
            $p = Start-Process -FilePath $VenvPython -ArgumentList '--version' -Wait -PassThru -WindowStyle Hidden
            $venvValid = $p.ExitCode -eq 0
        } catch { $venvValid = $false }
    }
    if (-not $venvValid) {
        if (Test-Path -LiteralPath $VenvRoot) {
            $quarantine = "$VenvRoot.invalid.$(Get-Date -Format 'yyyyMMddHHmmss')"
            Move-Item -LiteralPath $VenvRoot -Destination $quarantine
            Write-InstallLog "Moved invalid private virtual environment to: $quarantine"
        }
        Invoke-ProcessLogged $PythonExe @("-m", "venv", $VenvRoot) "private virtual environment creation" "PREREQUISITE_FAILURE"
    }
    Invoke-ProcessLogged $VenvPython @("-m", "pip", "install", "--disable-pip-version-check", "--no-index", "--find-links", $wheelhouse, "-r", (Join-Path $AppRoot "requirements.lock")) "offline dependency installation" "PREREQUISITE_FAILURE"
    Require-Path $VenvPython "private virtual environment Python"
}

function Install-PrivateDatabase {
    try {
        Install-EmbeddedPostgres -InstallRoot $InstallRoot -ProgramDataRoot $ProgramDataRoot -EnvPath $EnvPath -LogPath $InstallerLog | Out-Null
    } catch {
        $detail = $_.Exception.Message
        $category = if ($detail -match "Port 5433|occupied") {
            "PORT_CONFLICT"
        } elseif ($detail -match "service|Running|register") {
            "POSTGRES_SERVICE_FAILURE"
        } elseif ($detail -match "role|database|authentication|credentials|database.json") {
            "DATABASE_SETUP_FAILURE"
        } elseif ($detail -match "\.env|configuration") {
            "ENV_CONFIGURATION_FAILURE"
        } else {
            "POSTGRES_INITIALIZATION_FAILURE"
        }
        Fail-Install "Embedded PostgreSQL failed: $detail" $category
    }
}

function Invoke-Django {
    param([string[]]$Arguments, [string]$Description, [string]$Category)
    Invoke-ProcessLogged $VenvPython (@((Join-Path $AppRoot "manage.py")) + $Arguments) $Description $Category
}

function New-DatabaseSafetyBackup {
    $postgresBin = Join-Path $RuntimeRoot "postgresql\bin"
    $config = Get-Content -LiteralPath (Join-Path $ConfigRoot "database.json") -Raw -Encoding UTF8 | ConvertFrom-Json
    $backupDir = Join-Path $BackupRoot (Get-Date -Format "yyyyMMdd_HHmmss")
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    Set-EpSecureAcl -Path $backupDir
    $backup = Join-Path $backupDir "theraflow.backup"
    $previous = [Environment]::GetEnvironmentVariable("PGPASSWORD", "Process")
    try {
        [Environment]::SetEnvironmentVariable("PGPASSWORD", [string]$config.DB_PASSWORD, "Process")
        Invoke-ProcessLogged (Join-Path $postgresBin "pg_dump.exe") @("-h", "127.0.0.1", "-p", "5433", "-U", "theraflow_user", "-d", "theraflow", "-Fc", "-f", $backup) "pre-migration database backup (password omitted)" "MIGRATION_FAILURE" -SuppressOutput
        Invoke-ProcessLogged (Join-Path $postgresBin "pg_restore.exe") @("--list", $backup) "pre-migration backup validation" "MIGRATION_FAILURE"
        Set-EpSecureAcl -Path $backup
        Write-InstallLog "Pre-migration database backup created and validated: $backup"
    } finally { [Environment]::SetEnvironmentVariable("PGPASSWORD", $previous, "Process") }
}

function Test-CollectedStaticAssets {
    Set-FailureCategory "STATIC_FILES_FAILURE"
    $required = @(
        @{ Path=(Join-Path $StaticRoot "css\dashboard.css"); Text=".tf-app" },
        @{ Path=(Join-Path $StaticRoot "img\theraflow-horizontal.png"); Text="" },
        @{ Path=(Join-Path $StaticRoot "vendor\bootstrap-icons\bootstrap-icons.min.css"); Text="bootstrap-icons" },
        @{ Path=(Join-Path $StaticRoot "admin\css\base.css"); Text="" }
    )
    foreach ($item in $required) {
        Require-Path $item.Path "collected static asset" "STATIC_FILES_FAILURE"
        if ($item.Text) {
            $content = Get-Content -LiteralPath $item.Path -Raw -ErrorAction Stop
            if ($content -notlike "*$($item.Text)*") { Fail-Install "Static asset content verification failed: $($item.Path)" "STATIC_FILES_FAILURE" }
        }
    }
    Write-InstallLog "Static collection verification passed for application, icon and Django admin assets."
}

function ConvertTo-AdminCheckLogText {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return "<empty>" }
    $sanitized = $Text
    if (Test-Path -LiteralPath $EnvPath) {
        foreach ($line in [IO.File]::ReadAllLines($EnvPath, [Text.Encoding]::UTF8)) {
            if ($line -notmatch '^\s*(SECRET_KEY|DB_PASSWORD|POSTGRES_SUPER_PASSWORD)\s*=\s*(.+)$') { continue }
            $secret = $matches[2].Trim().Trim('"').Trim("'")
            if ($secret) { $sanitized = $sanitized.Replace($secret, "[REDACTED]") }
        }
    }
    $sanitized = ($sanitized -replace "[\r\n]+", " | ").Trim()
    if ($sanitized.Length -gt 4000) { $sanitized = $sanitized.Substring(0, 4000) + "...[truncated]" }
    return $sanitized
}

function Get-InitialAdminSetupState {
    Set-FailureCategory "DATABASE_SETUP_FAILURE"
    $managePath = Join-Path $AppRoot "manage.py"
    Require-Path $VenvPython "private virtual environment Python" "DATABASE_SETUP_FAILURE"
    Require-Path $managePath "Django manage.py" "DATABASE_SETUP_FAILURE"
    $argumentLine = (@(
        $managePath,
        "theraflow_admin_state"
    ) | ForEach-Object { ConvertTo-CommandLineArgument ([string]$_) }) -join " "

    Write-InstallLog "Administrator setup-state command: private Python + Django manage.py theraflow_admin_state (no passwords)."
    Write-InstallLog "Administrator setup-state runtime: python=$VenvPython; manage.py=$managePath; workingDirectory=$AppRoot; DJANGO_SETTINGS_MODULE=config.settings; THERAFLOW_PRODUCTION=1; productionEnv=$EnvPath; database=embedded PostgreSQL from production environment."

    $stdout = ""
    $stderr = ""
    $exitCode = $null
    try {
        $startInfo = [Diagnostics.ProcessStartInfo]::new()
        $startInfo.FileName = $VenvPython
        $startInfo.Arguments = $argumentLine
        $startInfo.WorkingDirectory = $AppRoot
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        $startInfo.EnvironmentVariables["DJANGO_SETTINGS_MODULE"] = "config.settings"
        $startInfo.EnvironmentVariables["THERAFLOW_PRODUCTION"] = "1"
        $startInfo.EnvironmentVariables["THERAFLOW_ENV_FILE"] = $EnvPath
        $process = [Diagnostics.Process]::new()
        $process.StartInfo = $startInfo
        if (-not $process.Start()) { throw "Administrator state process did not start." }
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $process.WaitForExit()
        $stdout = $stdoutTask.GetAwaiter().GetResult()
        $stderr = $stderrTask.GetAwaiter().GetResult()
        $exitCode = $process.ExitCode
        $process.Dispose()
    } catch {
        Write-InstallLog "Administrator setup-state exception: $($_.Exception.Message); stack=$($_.ScriptStackTrace -replace '[\r\n]+', ' | ')"
        Write-InstallLog "Administrator setup-state exit code: $(if ($null -eq $exitCode) { 'NOT_STARTED' } else { $exitCode })"
        Write-InstallLog "Administrator setup-state sanitized stdout: $(ConvertTo-AdminCheckLogText $stdout)"
        Write-InstallLog "Administrator setup-state sanitized stderr: $(ConvertTo-AdminCheckLogText $stderr)"
        Write-InstallLog "Administrator setup-state final resolved state: ADMIN_CHECK_FAILED"
        Fail-Install "Administrator setup-state query failed: $($_.Exception.Message)" "DATABASE_SETUP_FAILURE"
    }

    Write-InstallLog "Administrator setup-state exit code: $exitCode"
    Write-InstallLog "Administrator setup-state sanitized stdout: $(ConvertTo-AdminCheckLogText $stdout)"
    Write-InstallLog "Administrator setup-state sanitized stderr: $(ConvertTo-AdminCheckLogText $stderr)"
    if ($exitCode -ne 0) {
        Write-InstallLog "Administrator setup-state exception: Django management command returned non-zero exit code $exitCode; see sanitized stderr above."
        Write-InstallLog "Administrator setup-state counts: unavailable because the database query failed."
        Write-InstallLog "Administrator setup-state final resolved state: ADMIN_CHECK_FAILED"
        Fail-Install "Administrator setup-state query failed with exit code $exitCode." "DATABASE_SETUP_FAILURE"
    }

    $matches = [regex]::Matches($stdout, '(?m)^THERAFLOW_ADMIN_STATE_JSON=(\{[^\r\n]+\})\s*$')
    if ($matches.Count -ne 1) {
        Write-InstallLog "Administrator setup-state exception: expected exactly one machine-readable result, received $($matches.Count)."
        Write-InstallLog "Administrator setup-state counts: unavailable because the command output was invalid."
        Write-InstallLog "Administrator setup-state final resolved state: ADMIN_CHECK_FAILED"
        Fail-Install "Administrator setup-state query returned no unique machine-readable result." "DATABASE_SETUP_FAILURE"
    }
    try {
        $payload = $matches[0].Groups[1].Value | ConvertFrom-Json
        foreach ($property in @("superusers", "active_superusers", "active_staff")) {
            if ($payload.PSObject.Properties.Match($property).Count -ne 1) { throw "Missing result property: $property" }
        }
        $superusers = [int]$payload.superusers
        $activeSuperusers = [int]$payload.active_superusers
        $activeStaff = [int]$payload.active_staff
        if ($superusers -lt 0 -or $activeSuperusers -lt 0 -or $activeStaff -lt 0) { throw "Negative user count returned." }
    } catch {
        Write-InstallLog "Administrator setup-state parse exception: $($_.Exception.Message)"
        Write-InstallLog "Administrator setup-state final resolved state: ADMIN_CHECK_FAILED"
        Fail-Install "Administrator setup-state result could not be parsed." "DATABASE_SETUP_FAILURE"
    }

    $state = if ($activeSuperusers -gt 0) { "ADMIN_EXISTS" } else { "ADMIN_REQUIRED" }
    Write-InstallLog "Administrator setup-state counts: superusers=$superusers; activeSuperusers=$activeSuperusers; activeStaff=$activeStaff"
    Write-InstallLog "Administrator setup-state final resolved state: $state"
    return $state
}

function Get-InitialApplicationUrl {
    $state = Get-InitialAdminSetupState
    if ($state -eq "ADMIN_EXISTS") {
        Write-InstallLog "Existing active administrator detected; account was not changed."
        return ($AppUrl + "login/")
    }
    if ($state -eq "ADMIN_REQUIRED") {
        Write-InstallLog "No active administrator exists; secure one-time web setup will be opened. No password was generated or logged."
        return ($AppUrl + "setup-first-admin/")
    }
    Fail-Install "Unexpected administrator setup state: $state" "DATABASE_SETUP_FAILURE"
}

function Configure-ApplicationService {
    Set-FailureCategory "APPLICATION_SERVICE_FAILURE"
    $serviceScript = Join-Path $ScriptsRoot "service\install_service.bat"
    Require-Path $serviceScript "TheraFlow service installer" "APPLICATION_SERVICE_FAILURE"
    Invoke-ProcessLogged -FilePath $serviceScript -Arguments @() -SafeDescription "TheraFlow Application service configuration" -Category "APPLICATION_SERVICE_FAILURE" -WorkingDirectory (Split-Path -Parent $serviceScript)

    Set-FailureCategory "BACKUP_SCHEDULER_SERVICE_FAILURE"
    $schedulerScript = Join-Path $ScriptsRoot "service\install_backup_scheduler_service.bat"
    Require-Path $schedulerScript "TheraFlow Backup Scheduler service installer" "BACKUP_SCHEDULER_SERVICE_FAILURE"
    & icacls.exe $BackupSchedulerLogRoot /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)(F)" "*S-1-5-32-544:(OI)(CI)(F)" /C /Q | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Fail-Install "Protected scheduler log directory ACL could not be configured: $BackupSchedulerLogRoot" "BACKUP_SCHEDULER_SERVICE_FAILURE"
    }
    Write-InstallLog "Backup Scheduler log ACL verified for SYSTEM and Administrators."
    Invoke-ProcessLogged -FilePath $schedulerScript -Arguments @() -SafeDescription "TheraFlowBackupScheduler service configuration" -Category "BACKUP_SCHEDULER_SERVICE_FAILURE" -WorkingDirectory (Split-Path -Parent $schedulerScript)
    $script:BackupSchedulerReady = $true
}

function Test-CompleteInstallation {
    Set-FailureCategory "HEALTH_CHECK_FAILURE"
    foreach ($required in @(
        (Join-Path $AppRoot "manage.py"), $PythonExe,
        (Join-Path $RuntimeRoot "postgresql\bin\postgres.exe"), $EnvPath,
        (Join-Path $StaticRoot "css\dashboard.css")
    )) { Require-Path $required "final required file" "HEALTH_CHECK_FAILURE" }

    $databaseService = Get-CimInstance Win32_Service -Filter "Name='TheraFlowPostgres'" -ErrorAction SilentlyContinue
    if ($null -eq $databaseService -or $databaseService.State -ne "Running" -or [string]$databaseService.PathName -notlike "*$([IO.Path]::GetFullPath((Join-Path $RuntimeRoot 'postgresql')))*") {
        Fail-Install "TheraFlowPostgres service verification failed." "POSTGRES_SERVICE_FAILURE"
    }
    $appService = Get-CimInstance Win32_Service -Filter "Name='TheraFlow'" -ErrorAction SilentlyContinue
    if (
        $null -eq $appService -or $appService.State -ne "Running" -or
        [string]$appService.DisplayName -ne "TheraFlow Application" -or
        [string]$appService.PathName -notlike "*$([IO.Path]::GetFullPath((Join-Path $RuntimeRoot 'nssm')))*"
    ) {
        Fail-Install "TheraFlow Application service verification failed." "APPLICATION_SERVICE_FAILURE"
    }
    $updaterService = Get-CimInstance Win32_Service -Filter "Name='TheraFlowUpdaterService'" -ErrorAction SilentlyContinue
    if (
        $null -eq $updaterService -or $updaterService.State -ne "Running" -or
        [string]$updaterService.DisplayName -ne "TheraFlow Update Service" -or
        [string]$updaterService.PathName -notlike "*$([IO.Path]::GetFullPath((Join-Path $RuntimeRoot 'nssm')))*"
    ) {
        Fail-Install "TheraFlowUpdaterService restricted service verification failed." "APPLICATION_SERVICE_FAILURE"
    }
    $backupSchedulerService = Get-CimInstance Win32_Service -Filter "Name='TheraFlowBackupScheduler'" -ErrorAction SilentlyContinue
    if (
        $null -eq $backupSchedulerService -or $backupSchedulerService.State -ne "Running" -or
        [string]$backupSchedulerService.DisplayName -ne "TheraFlow Backup Scheduler" -or
        [string]$backupSchedulerService.PathName -notlike "*$([IO.Path]::GetFullPath((Join-Path $RuntimeRoot 'nssm')))*"
    ) {
        $script:BackupSchedulerReady = $false
        Fail-Install "TheraFlowBackupScheduler service verification failed." "BACKUP_SCHEDULER_SERVICE_FAILURE"
    } else {
        $script:BackupSchedulerReady = $true
    }

    Invoke-Django @("check") "final Django system check" "HEALTH_CHECK_FAILURE"
    Invoke-Django @("migrate", "--check") "final Django migration check" "HEALTH_CHECK_FAILURE"
    $deadline = (Get-Date).AddSeconds(120)
    $lastError = ""
    while ((Get-Date) -lt $deadline) {
        try {
            $login = Invoke-WebRequest -UseBasicParsing -Uri ($AppUrl + "login/") -TimeoutSec 5
            $css = Invoke-WebRequest -UseBasicParsing -Uri ($AppUrl + "static/css/dashboard.css") -TimeoutSec 5
            $health = Invoke-WebRequest -UseBasicParsing -Uri ($AppUrl + "health/update/") -TimeoutSec 5
            $healthPayload = $health.Content | ConvertFrom-Json
            if (
                $login.StatusCode -eq 200 -and
                $css.StatusCode -eq 200 -and
                [string]$css.Content -like "*.tf-app*" -and
                $health.StatusCode -eq 200
            ) {
                if ([string]$healthPayload.backup_scheduler -ne "ok" -or -not $script:BackupSchedulerReady) {
                    Fail-Install "Backup Scheduler health check failed: $($healthPayload.backup_scheduler)." "BACKUP_SCHEDULER_SERVICE_FAILURE"
                }
                Write-InstallLog "Complete health check passed: application, static files and backup scheduler are ready."
                return
            }
            $lastError = "login=$($login.StatusCode), css=$($css.StatusCode), health=$($health.StatusCode), backup_scheduler=$($healthPayload.backup_scheduler)"
        } catch {
            $lastError = $_.Exception.GetType().Name
        }
        Write-InstallLog "Application health check retry: $lastError"
        Start-Sleep -Seconds 4
    }
    Fail-Install "Application health check timed out ($lastError)." "HEALTH_CHECK_FAILURE"
}

function Stop-ApplicationAfterFailure {
    $schedulerService = Get-Service -Name "TheraFlowBackupScheduler" -ErrorAction SilentlyContinue
    if ($null -ne $schedulerService -and $schedulerService.Status -ne "Stopped") {
        try { Stop-Service -Name "TheraFlowBackupScheduler" -Force -ErrorAction Stop; Write-InstallLog "Stopped backup scheduler service after failed verification." } catch { Write-InstallLog "Could not stop backup scheduler service after failure: $($_.Exception.Message)" }
    }
    $service = Get-Service -Name "TheraFlow" -ErrorAction SilentlyContinue
    if ($null -ne $service -and $service.Status -ne "Stopped") {
        try { Stop-Service -Name "TheraFlow" -Force -ErrorAction Stop; Write-InstallLog "Stopped application service after failed verification." } catch { Write-InstallLog "Could not stop application service after failure: $($_.Exception.Message)" }
    }
}

try {
    Write-InstallLog ""
    Write-InstallLog "=== TheraFlow Phase 2 complete installation ==="
    Write-InstallLog "Installer run id: $script:RunId"
    Write-InstallLog "TheraFlow Installer Build: 3.4.7"
    Write-InstallLog "TheraFlow Application Version: 1.5.8"
    Write-InstallLog "Embedded PostgreSQL Mode: Enabled"
    Write-InstallLog "Database Port: 5433"
    Require-Admin
    Write-ProgressMessage "Installing TheraFlow application..."
    foreach ($path in @(
        (Join-Path $AppRoot "manage.py"), (Join-Path $AppRoot "run_theraflow.py"),
        (Join-Path $ScriptsRoot "installer_runtime\EmbeddedPostgres.psm1"),
        (Join-Path $ScriptsRoot "installer_runtime\PrivatePython.psm1"),
        (Join-Path $RuntimeRoot "postgresql\bin\postgres.exe"),
        (Join-Path $RuntimeRoot "nssm\nssm.exe")
    )) { Require-Path $path "installer payload" }

    Import-Module (Join-Path $ScriptsRoot "installer_runtime\EmbeddedPostgres.psm1") -Force
    Import-Module (Join-Path $ScriptsRoot "installer_runtime\InstallationState.psm1") -Force
    Import-Module (Join-Path $ScriptsRoot "installer_runtime\PrivatePython.psm1") -Force
    $state = Get-TheraFlowInstallationState -InstallRoot $InstallRoot -ProgramDataRoot $ProgramDataRoot -LogPath $InstallerLog
    $script:DetectedState = $state.State
    $isCompletelyNewInstallation = $state.State -eq "CLEAN_INSTALL" -and -not (Test-Path -LiteralPath $EnvPath -PathType Leaf)
    Set-CanonicalEnvironment -AllowNewSecret:$isCompletelyNewInstallation
    Write-InstallLog "Orphaned database reset option selected: $ResetOrphanedDatabase"
    if ($state.State -eq "PORT_CONFLICT") { Fail-Install "Port 5433 is occupied by a non-TheraFlow process." "PORT_CONFLICT" }
    switch ($state.OrphanedClusterClassification) {
        "EMPTY_OR_INCOMPLETE_CLUSTER" {
            Reset-EmbeddedPostgresOrphanedState -InstallRoot $InstallRoot -ProgramDataRoot $ProgramDataRoot -LogPath $InstallerLog -Classification $_ | Out-Null
        }
        "VALID_CLUSTER_MISSING_CREDENTIALS" {
            if (-not $ResetOrphanedDatabase) {
                Fail-Install "An old valid TheraFlow database was found without valid database.json credentials. No data was changed. To delete this test/local database, re-run setup and explicitly select the warned orphaned-database reset option." "DATABASE_SETUP_FAILURE"
            }
            Reset-EmbeddedPostgresOrphanedState -InstallRoot $InstallRoot -ProgramDataRoot $ProgramDataRoot -LogPath $InstallerLog -Classification $_ -ExplicitDataLossConsent | Out-Null
        }
        "ORPHANED_TEST_CLUSTER" {
            if (-not $ResetOrphanedDatabase) {
                Fail-Install "An orphaned TheraFlow test cluster was found without valid credentials. It was preserved. Re-run setup with the warned reset option only if all local TheraFlow data may be deleted." "DATABASE_SETUP_FAILURE"
            }
            Reset-EmbeddedPostgresOrphanedState -InstallRoot $InstallRoot -ProgramDataRoot $ProgramDataRoot -LogPath $InstallerLog -Classification $_ -ExplicitDataLossConsent | Out-Null
        }
        "UNKNOWN_CLUSTER" {
            Fail-Install "An unknown non-empty PostgreSQL directory exists at the TheraFlow data path. Automatic reset is disabled and no files were changed." "DATABASE_SETUP_FAILURE"
        }
        "VALID_CLUSTER_WITH_CREDENTIALS" { }
        default { Fail-Install "Unknown orphaned-cluster classification: $($state.OrphanedClusterClassification)" "DATABASE_SETUP_FAILURE" }
    }

    Install-PrivatePython
    Install-ApplicationDependencies

    Write-ProgressMessage "Configuring secure database..."
    Set-FailureCategory "POSTGRES_INITIALIZATION_FAILURE"
    Install-PrivateDatabase
    $script:EmbeddedDatabaseReady = $true
    Invoke-ProcessLogged "powershell.exe" @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
        (Join-Path $ScriptsRoot "installer_runtime\complete_embedded_postgres.ps1"),
        "-ProgramDataRoot", $ProgramDataRoot
    ) "embedded PostgreSQL preservation checkpoint" "DATABASE_SETUP_FAILURE"

    Set-FailureCategory "DATABASE_SETUP_FAILURE"
    Invoke-Django @("check", "--database", "default") "Django database connection/system check" "DATABASE_SETUP_FAILURE"
    New-DatabaseSafetyBackup

    Set-FailureCategory "MIGRATION_FAILURE"
    Invoke-Django @("showmigrations", "--plan") "Django migration plan" "MIGRATION_FAILURE"
    Invoke-Django @("migrate", "--noinput") "Django migrations" "MIGRATION_FAILURE"
    Invoke-Django @("migrate", "--check") "Django migration completion check" "MIGRATION_FAILURE"
    Invoke-Django @("check_schema_gate") "full database schema gate" "MIGRATION_FAILURE"

    Set-FailureCategory "STATIC_FILES_FAILURE"
    Invoke-Django @("collectstatic", "--noinput", "--clear") "Django static collection" "STATIC_FILES_FAILURE"
    Test-CollectedStaticAssets
    $initialUrl = Get-InitialApplicationUrl

    Write-ProgressMessage "Preparing application services..."
    Configure-ApplicationService
    Write-ProgressMessage "Finalizing installation..."
    Test-CompleteInstallation
    Write-InstallLog "TheraFlow complete installation verification succeeded."
    Write-InstallLog "FINAL SUCCESS [runId=$script:RunId]: all required installation phases passed."
    Write-Host "TheraFlow je uspjesno instaliran."
    Start-Process $initialUrl
    exit 0
} catch {
    Write-InstallLog "FINAL FAILURE [$script:FailureCategory] [runId=$script:RunId]: $($_.Exception.Message)"
    Stop-ApplicationAfterFailure
    if (-not $script:EmbeddedDatabaseReady) {
        $rollback = Join-Path $ScriptsRoot "installer_runtime\rollback_embedded_postgres.ps1"
        if (Test-Path -LiteralPath $rollback) {
            try {
                & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $rollback -InstallRoot $InstallRoot -ProgramDataRoot $ProgramDataRoot -LogPath $InstallerLog
            } catch { Write-InstallLog "First-install rollback error: $($_.Exception.Message)" }
        }
        if (Test-Path -LiteralPath $PythonRoot) {
            $rollbackPython = Get-PrivatePythonValidation
            if ($rollbackPython.Valid) {
                Write-InstallLog "Rollback policy: preserved valid private Python runtime and its MSI registration for safe reuse on the next attempt."
            } else {
                Write-InstallLog "Rollback policy: preserved incomplete private Python runtime and MSI state for controlled repair on the next attempt; files were not deleted independently."
            }
        }
    } else {
        Write-InstallLog "Database and credentials preserved because embedded database setup had completed."
    }
    $message = if ($failureMessages.ContainsKey($script:FailureCategory)) { $failureMessages[$script:FailureCategory] } else { "Instalacija nije uspjesno zavrsena." }
    Write-Host ""
    Write-Host $message
    Write-Host ""
    Write-Host "Detalji su sacuvani u:"
    Write-Host $InstallerLog
    exit 1
}
