"""Restricted LocalSystem worker for verified TheraFlow update sessions."""

import hashlib
import hmac
import json
import logging
import os
import shutil
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path


APP_ROOT = Path(__file__).resolve().parent.parent
DATA_ROOT = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "TheraFlow"
KEY_PATH = DATA_ROOT / "config" / "updater_service.key"
REQUEST_ROOT = DATA_ROOT / "updates" / "service_requests"
SESSION_ROOT = DATA_ROOT / "updates" / "sessions"
LOG_PATH = DATA_ROOT / "logs" / "updater_service.log"
ALLOWED_OPERATIONS = frozenset({"install", "rollback"})
REQUEST_FIELDS = frozenset({"request_id", "session_id", "operation", "created_at", "signature"})


class RequestValidationError(RuntimeError):
    pass


def configure_logging():
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        filename=LOG_PATH,
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        encoding="utf-8",
    )


def _load_key():
    key = KEY_PATH.read_bytes().strip()
    if len(key) < 32:
        raise RequestValidationError("Updater service ključ nije validan.")
    return key


def _signature(key, request):
    body = "{request_id}|{session_id}|{operation}|{created_at}".format(**request).encode("utf-8")
    return hmac.new(key, body, hashlib.sha256).hexdigest()


def validate_request(path):
    path = Path(path).resolve()
    root = REQUEST_ROOT.resolve()
    if path.parent != root or path.suffix != ".processing":
        raise RequestValidationError("Request nije u dozvoljenom direktoriju.")
    request = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(request, dict) or set(request) != REQUEST_FIELDS:
        raise RequestValidationError("Request schema nije dozvoljena.")
    if request["operation"] not in ALLOWED_OPERATIONS:
        raise RequestValidationError("Operacija nije dozvoljena.")
    request_id = str(uuid.UUID(request["request_id"]))
    session_id = str(uuid.UUID(request["session_id"]))
    if path.stem != request_id:
        raise RequestValidationError("Request ID i naziv fajla se ne podudaraju.")
    created = datetime.fromisoformat(request["created_at"].replace("Z", "+00:00"))
    if created.tzinfo is None:
        created = created.replace(tzinfo=timezone.utc)
    age = abs((datetime.now(timezone.utc) - created).total_seconds())
    if age > 300:
        raise RequestValidationError("Updater zahtjev je istekao.")
    if not hmac.compare_digest(request["signature"], _signature(_load_key(), request)):
        raise RequestValidationError("Potpis updater zahtjeva nije validan.")
    return request_id, session_id, request["operation"]


def execute_request(session_id, operation):
    # Putanja se uvijek izvodi iz validiranog UUID-a; request je ne može zadati.
    session_dir = (SESSION_ROOT / session_id).resolve()
    if session_dir.parent != SESSION_ROOT.resolve():
        raise RequestValidationError("Session putanja nije dozvoljena.")
    plan_path = session_dir / "install_plan.json"
    runtime_root = session_dir / "runtime"
    updater_source = APP_ROOT / "updates" / "updater"
    if not plan_path.is_file():
        raise RequestValidationError("Validirani install plan nije pronađen.")

    sys.path.insert(0, str(APP_ROOT))
    from updates.updater.plan_loader import load_and_validate

    load_and_validate(plan_path, rollback=operation == "rollback")
    runtime_package = runtime_root / "updater"
    if not runtime_package.is_dir():
        shutil.copytree(updater_source, runtime_package, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))

    env = {
        key: os.environ[key]
        for key in ("SystemRoot", "WINDIR", "PATH", "PATHEXT", "COMSPEC", "TEMP", "TMP", "PROGRAMDATA")
        if key in os.environ
    }
    env.update({
        "PYTHONUTF8": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "THERAFLOW_PRODUCTION": "1",
        "THERAFLOW_ENV_FILE": str(DATA_ROOT / "config" / ".env"),
    })
    if operation == "rollback":
        env["THERAFLOW_UPDATER_MODE"] = "rollback"
    command = [sys.executable, "-m", "updater.runner", str(plan_path)]
    logging.info("Executing verified operation=%s session=%s", operation, session_id)
    return subprocess.run(
        command,
        cwd=runtime_root,
        env=env,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        check=False,
        shell=False,
        timeout=3600,
    )


def process_one(path):
    processing = path.with_suffix(".processing")
    session_id = None
    try:
        os.replace(path, processing)
        request_id, session_id, operation = validate_request(processing)
        result = execute_request(session_id, operation)
        status = "completed" if result.returncode == 0 else "failed"
        response = {
            "request_id": request_id,
            "session_id": session_id,
            "operation": operation,
            "status": status,
            "exit_code": result.returncode,
            "completed_at": datetime.now(timezone.utc).isoformat(),
        }
        logging.info("Verified operation finished request=%s exit_code=%s", request_id, result.returncode)
    except Exception as exc:
        logging.exception("Rejected or failed updater service request: %s", type(exc).__name__)
        if session_id:
            try:
                sys.path.insert(0, str(APP_ROOT))
                from updates.updater.state_writer import write_state

                state_path = SESSION_ROOT / f"{session_id}.json"
                if state_path.is_file():
                    write_state(
                        state_path,
                        status="updater_service_failed",
                        current_step="TheraFlowUpdaterService nije izvršio zahtjev",
                        error_code="updater_service_failed",
                        error_message=f"{type(exc).__name__}: {exc}",
                        failed_step="updater_service_dispatch",
                        completed_at=datetime.now(timezone.utc).isoformat(),
                    )
            except Exception:
                logging.exception("Could not persist updater service failure state.")
        response = {
            "status": "rejected",
            "error_type": type(exc).__name__,
            "completed_at": datetime.now(timezone.utc).isoformat(),
        }
    response_path = REQUEST_ROOT / f"{processing.stem}.response.json"
    response_path.write_text(json.dumps(response, sort_keys=True), encoding="utf-8")
    processing.unlink(missing_ok=True)
    return response


def main():
    configure_logging()
    REQUEST_ROOT.mkdir(parents=True, exist_ok=True)
    logging.info("TheraFlowUpdaterService restricted service started.")
    while True:
        for path in sorted(REQUEST_ROOT.glob("*.json")):
            if path.name.endswith(".response.json"):
                continue
            process_one(path)
            # NSSM ponovo pokreće servis kako bi sljedeći update koristio
            # upravo instaliranu verziju ograničenog service enginea.
            logging.info("Request processed; restarting worker through NSSM.")
            return
        time.sleep(1)


if __name__ == "__main__":
    main()
